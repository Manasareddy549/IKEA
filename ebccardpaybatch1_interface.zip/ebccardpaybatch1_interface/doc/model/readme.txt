In this folder you need to save your RSM project including RSM model file and transformations.
