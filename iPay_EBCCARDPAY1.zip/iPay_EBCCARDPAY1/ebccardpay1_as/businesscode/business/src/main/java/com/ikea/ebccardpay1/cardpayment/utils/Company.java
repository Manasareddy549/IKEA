package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.Serializable;

public class Company implements Serializable, Cloneable {
	private static final long serialVersionUID = 2767777827846225001L;

	public Company() {
		super();
	}

	public Company(String companyCode, String companyName) {
		super();
		mCompanyCode = companyCode;
		mCompanyName = companyName;
	}

	public Object clone() {
		return new Company(mCompanyCode, mCompanyName);
	}

	private String mCompanyCode;
	private String mCompanyName;

	public String getCompanyCode() {
		return mCompanyCode;
	}

	public void setCompanyCode(String companyCode) {
		mCompanyCode = companyCode;
	}

	public String getCompanyName() {
		return mCompanyName;
	}

	public void setCompanyName(String companyName) {
		mCompanyName = companyName;
	}

}
