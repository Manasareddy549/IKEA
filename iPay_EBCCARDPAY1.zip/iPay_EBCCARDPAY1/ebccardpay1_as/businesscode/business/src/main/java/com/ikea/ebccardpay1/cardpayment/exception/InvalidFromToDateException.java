/*
 * Created on 2007-okt-26
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *
 */
public class InvalidFromToDateException extends ReportException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3935244891053458411L;


	/**
	 * 
	 */
	public InvalidFromToDateException() {
		super();

	}

	/**
	 * @param pMessage
	 */
	public InvalidFromToDateException(String pMessage) {
		super(pMessage);

	}


	public ApplicationError createApplicationError() {
		
		return new EbcCardPay1ApplError.InvalidFromToDate();
	}

}
