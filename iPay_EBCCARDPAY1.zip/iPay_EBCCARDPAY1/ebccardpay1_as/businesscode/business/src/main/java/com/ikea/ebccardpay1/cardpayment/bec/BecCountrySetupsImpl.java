/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.CountrySetup;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountrySetup;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.CountrySetups;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountrySetup;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
/**
 * @author anms
 *
 */
public class BecCountrySetupsImpl implements BecCountrySetups {


	// Dependencies injected at creation of this BEC
	private BecCountrySetup mBecCountrySetup;
	private BefCountrySetup mBefCountrySetup;
	private CountrySetups mCountrySetups;

	// Entities that this BEC operates on

	// Related Bec's that this Bec delegates work to

	List<VoCountrySetup> mVoCountrySetupList = null;

	/**
	 * 
	 */
	public BecCountrySetupsImpl(
		BecCountrySetup pBecCountrySetup,
		BefCountrySetup pBefCountrySetup,
		CountrySetups pCountrySetups) {

		super();

		mBecCountrySetup = pBecCountrySetup;
		mBefCountrySetup = pBefCountrySetup;
		mCountrySetups = pCountrySetups;
	}
	
	void validate() {
		notNull(mBecCountrySetup);
		notNull(mBefCountrySetup);
		notNull(mCountrySetups);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountrySetups#init(com.ikea.ebccardpay1.cardpayment.vo.VoCountrySetup)
	 */
	public BecCountrySetups init(List<VoCountrySetup> pVoCountrySetupList) {

		mVoCountrySetupList = pVoCountrySetupList;

		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountrySetups#manage()
	 */
	public void manage()
		throws IkeaException, ValueMissingException, CountrySetupException {

		requireVoCountrySetupList();

		// Mange on each of the VoCountrySetup
		for (VoCountrySetup vVoCountrySetup : mVoCountrySetupList) {
			// Let singel BEC do the management
			mBecCountrySetup.manage(vVoCountrySetup);

			// Copy new VO
			ValueObjects.assignFromMap(
				vVoCountrySetup,
				ValueObjects.assignToMap(mBecCountrySetup.getVoCountrySetup()));
		}
		mCountrySetups.reloadCache();
	}


	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountrySetups#getVoCountrySetupList()
	 */
	public List<VoCountrySetup> getVoCountrySetupList()
		throws ValueMissingException {

		requireVoCountrySetupList();

		return mVoCountrySetupList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountrySetups#findAllCountrySetups()
	 */
	public List<VoCountrySetup> findAllCountrySetups()
		throws IkeaException, ValueMissingException {

		List<VoCountrySetup> vVoList = new ArrayList<VoCountrySetup>();

		// Find all
		List<CountrySetup> vList = mBefCountrySetup.findAll();

		for (Iterator<CountrySetup> i = vList.iterator(); i.hasNext();) {
			CountrySetup vCountrySetup = (CountrySetup) i.next();

			// Let singel BEC do the extraction to VO
			mBecCountrySetup.init(vCountrySetup);
			vVoList.add(mBecCountrySetup.getVoCountrySetup());
		}

		return vVoList;
	}

	// -----------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireVoCountrySetupList() throws ValueMissingException {
		if (mVoCountrySetupList == null)
			throw new ValueMissingException("Tried to use BecCountrySetups without required List<VoCountrySetup>.");
	}

}
