/*
 * Created on 2007-jan-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class ReferenceAlreadyAcknowledged extends ReferenceCheckException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1602722664921854758L;

	/**
	 * @param pMessage
	 * @param pReference
	 */
	public ReferenceAlreadyAcknowledged(
		String pSourceSystem,
		String pReference)
		//String pSalesDay)
	{
		super(pSourceSystem, pReference);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.CardPayException#createApplicationError()
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ReferenceAlreadyAcknowledged(
			mSourceSystem,
			mReference,
			mSalesDay);
	}

}
