/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefCampaign;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public class BecCampaignsImpl implements BecCampaigns {

	private final static Logger mCategory = LoggerFactory
    .getLogger(BecCampaignsImpl.class);

	// Dependencies injected at creation of this BEC
	private BecCampaign mBecCampaign;
	private BefCampaign mBefCampaign;
	private TimeSource mTimeSource;
	
	 private BefTransaction mBefTransaction = null;
		
		private UtilsFactory mUtilsFactory=null;
		
		

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	// Entities that this BEC operates on

	// Related Bec's that this Bec delegates work to
	
	public List<Campaign> campainList;
	
	

	/**
	 * 
	 */
	public BecCampaignsImpl(
		BecCampaign pBecCampaign,
		BefCampaign pBefCampaign,
		TimeSource pTimeSource,BefTransaction pBefTransaction,UtilsFactory pUtilsFactory) {
		super();

		mBecCampaign = pBecCampaign;
		mBefCampaign = pBefCampaign;
		mTimeSource = pTimeSource;
		mBefTransaction = pBefTransaction;
		mUtilsFactory = pUtilsFactory;
	}
	
	void validate() {
		Validate.notNull(mBecCampaign);
		Validate.notNull(mBefCampaign);
		Validate.notNull(mTimeSource);
		Validate.notNull(mBefTransaction);
		Validate.notNull(mUtilsFactory);
		
		
	}

	public BecCampaigns init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#findCurrentCampaigns()
	 */
	public List<VoCampaign> findCurrentCampaigns()
		throws IkeaException, ValueMissingException {

		List<VoCampaign> vVoList = new ArrayList<VoCampaign>();

		// Get campaigns for the logged in users country
		// We can not know the correct sales day so just take a day in the past.
		DateTime vNow = new DateTime(mTimeSource.currentDate());
		DateTime vYesterday = vNow.minusDays(1);
		List<Campaign> vList =
			mBefCampaign.findByCurrent(
				countryCodeForUser(),
				vYesterday.toDate());

		for (Iterator<Campaign> i = vList.iterator(); i.hasNext();) {
			Campaign vCampaign = (Campaign) i.next();

			// Let singel BEC do the extraction to VO
			mBecCampaign.init(vCampaign);
			VoCampaign vVoCampaign = mBecCampaign.getVoCampaign();

			vVoList.add(vVoCampaign);
		}
		return vVoList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaigns#findUnprocessedCampaigns()
	 */
	public List<Campaign> findUnprocessedCampaigns() {
		return mBefCampaign.findByUnprocessed();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaigns#findCampaigns(com.ikea.ebccardpay1.cardpayment.vo.VoCampaignSearch)
	 */
	public List<VoCampaign> findCampaigns(VoCampaignSearch pVoCampaignSearch)
		throws ValueMissingException {

		List<VoCampaign> vVoList = new ArrayList<VoCampaign>();

		List<Campaign> vList =
			mBefCampaign.findBySearch(
				pVoCampaignSearch.getBuType(),
				pVoCampaignSearch.getBuCode(),
				pVoCampaignSearch.getCountryCode(),
				pVoCampaignSearch.getNameLike(),
				pVoCampaignSearch.getIntervalOnFromDate(),
				pVoCampaignSearch.getIntervalOnUntilDate());

		for (Iterator<Campaign> i = vList.iterator(); i.hasNext();) {
			Campaign vCampaign = (Campaign) i.next();

			// Let singel BEC do the extraction to VO
			mBecCampaign.init(vCampaign);
			vVoList.add(mBecCampaign.getVoCampaign());
		}

		return vVoList;
	}

	// -----------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser()
		throws ValueMissingException, IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException("Tried to use BecCampaigns without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}
	
}
