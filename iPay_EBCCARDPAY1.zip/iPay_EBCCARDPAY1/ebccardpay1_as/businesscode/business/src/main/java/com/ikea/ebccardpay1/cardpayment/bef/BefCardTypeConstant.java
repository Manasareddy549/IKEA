/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefCardTypeConstant extends Bef<CardTypeConstant>{

}