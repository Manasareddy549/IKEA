/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalTempCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.Publisher;
import com.ikea.ebccardpay1.cardpayment.utils.PublisherImpl;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * 
 */
public class BecFactoryImpl implements BecFactory, InitializingBean {

	BefFactory mBefFactory = null;
	TimeSource mTimeSource = null;
	Constants mConstants = null;
	EbcEnvironment mEbcEnvironment = null;
	Units mUnits = null;
	UtilsFactory mUtilsFactory = null;
	EncryptionDecryption mEncryptionDecryption=null;
	@Autowired
	BsContext mBsContext;
	Publisher mPublisher=null;
	
	@Autowired
	EbcProperties mEbcProperties;
	
	private final static Logger cat =
        LoggerFactory.getLogger(BecFactoryImpl.class.getName());
	
	protected BecFactoryImpl(BefFactory befFactory, TimeSource timeSource,
			Constants constants, EbcEnvironment ebcEnvironment, Units units,
			UtilsFactory utilsFactory, EncryptionDecryption encryptionDecryption,Publisher publisher ) {

		// Save all the info so we can create BECs when asked for
		mBefFactory = befFactory;
		mTimeSource = timeSource;
		mConstants = constants;
		mEbcEnvironment = ebcEnvironment;
		mUnits = units;
		mUtilsFactory = utilsFactory;
		mEncryptionDecryption = encryptionDecryption;
		mPublisher = publisher;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCampaign()
	 */
		public BecCampaign createBecCampaign() {
		BecCampaignImpl bc = new BecCampaignImpl(mBefFactory.getBefCampaign(),
				mBefFactory.getBefAmount(), mBefFactory.getBefCardNumber(),
				mTimeSource, mEbcEnvironment, createBecCard(),
				createBecCardRange(), createBecCampaignLimitation(),
				createBecCardNumber(), mBsContext, mBefFactory.getBefTransaction(),mUtilsFactory,mBefFactory.getBefRange(),this,mBefFactory.getBefCard());

		bc.validate();
		
		return bc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCampaigns()
	 */
	public BecCampaigns createBecCampaigns() {
		BecCampaignsImpl bec = new BecCampaignsImpl(createBecCampaign(),
				mBefFactory.getBefCampaign(), mTimeSource,mBefFactory.getBefTransaction(),mUtilsFactory);
		bec.validate();
		
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCard()
	 */
	public BecCard createBecCard() {
		
		cat.info("creating the card");
		
	BecCardImpl bec = new BecCardImpl(this, createBecTransactions(),
				mBefFactory.getBefCard(), mBefFactory.getBefLifeCycle(),
				mBefFactory.getBefAuthorization(),
				mUtilsFactory.getCountrySetups(), mTimeSource, mConstants,mBefFactory.getBefTransaction(),mUtilsFactory,mBefFactory.getBefAmount()
				,mEncryptionDecryption,mBefFactory.getBefReservedCardHistory());

		bec.validate();
		
		cat.info("Card creation is endeed");
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCards()
	 */
	public BecCards createBecCards() {
		BecCardsImpl bec = new BecCardsImpl(mBefFactory.getBefRange(),
				mBefFactory.getBefActivation(), this);
		bec.validate();
		
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecAmount()
	 */
	public BecAmount createBecAmount() {
		BecAmountImpl bec = new BecAmountImpl(mBefFactory.getBefAmount(),
				createBecTransaction(), mBefFactory.getBefIpayBusinessUnits());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecAmounts()
	 */
	public BecAmounts createBecAmounts() {
		BecAmountsImpl bec = new BecAmountsImpl(this, mUnits,
				mUtilsFactory.createPriorityEvaluator(), mEbcProperties, mBefFactory.getBefIpayBusinessUnits(),mUtilsFactory);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCardNumber()
	 */
	public BecCardNumber createBecCardNumber() {
		BecCardNumberImpl bec = new BecCardNumberImpl(mBefFactory.getBefCardNumber(), mConstants,mEncryptionDecryption);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecKPI()
	 */
	public BecKPI createBecKPI() {
		BecKPIImpl bec = new BecKPIImpl(mBefFactory.getBefKPI(), mTimeSource, mUnits, mBefFactory.getBefIpayBusinessUnits());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecReport()
	 */
	public BecReport createBecReport() {
		BecReportImpl bec = new BecReportImpl(mBefFactory.getBefReport(), mEncryptionDecryption,mBefFactory.getBefBsLog(),mEbcProperties);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecTransaction()
	 */
	public BecTransaction createBecTransaction() {
		BecTransactionImpl bec =  new BecTransactionImpl(mBefFactory.getBefTransaction(), mBefFactory.getBefReasonCodeTransaction(),
				mConstants, mUtilsFactory,mPublisher, mEncryptionDecryption);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecTransactions()
	 */
	public BecTransactions createBecTransactions() {
		BecTransactionsImpl bec = new BecTransactionsImpl(this, mUtilsFactory, mUnits,
				mTimeSource, mBefFactory.getBefTransactionFilter(),
				mBefFactory.getBefTransaction(),
				mBefFactory.getBefAuthorization(),
				mBefFactory.getBefIpayBusinessUnits(),
				mEncryptionDecryption,
				mEbcProperties, createBecReservedCardHistory());
		bec.validate();
		return bec;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecReferenceCheck()
	 */
	// IRW changes
	public BecReferenceCheck createBecReferenceCheck() {

		BecReferenceCheckImpl bec = new BecReferenceCheckImpl(createBecTransactions(),
				mBefFactory.getBefReferenceCheck(), this, mEbcProperties, mBefFactory.getBefReservedCardHistory(),
				mBefFactory.getBefTransaction(),
				mBefFactory.getBefCard(),
				mBefFactory.getBefAmount(), mPublisher,mEncryptionDecryption, createBecReservedCardHistory());
		bec.validate();
		return bec;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecReservedCardHistory()
	 */
	// IRW changes

	public BecReservedCardHistory createBecReservedCardHistory() {

		BecReservedCardHistoryImpl bec = new BecReservedCardHistoryImpl(
				mBefFactory.getBefReservedCardHistory(), mConstants, this, mEbcProperties, mUtilsFactory,
				mBefFactory.getBefTransactionFilter(), mBefFactory.getBefAmount(), mBefFactory.getBefReferenceCheck());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecReferenceChecks
	 * ()
	 */
	public BecReferenceChecks createBecReferenceChecks() {
		BecReferenceChecksImpl bec = new BecReferenceChecksImpl(mBefFactory.getBefReferenceCheck(),
				this, mUtilsFactory);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCardRange()
	 */
	public BecRange createBecCardRange() {
		BecRangeImpl bec = new BecRangeImpl(createBecCardNumber(),
				mBefFactory.getBefRange());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCampaignLimitation
	 * ()
	 */
	public BecCampaignLimitation createBecCampaignLimitation() {
		BecCampaignLimitationImpl bec = new BecCampaignLimitationImpl(
				mBefFactory.getBefCampaignLimitation());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecMassLoad()
	 */
	public BecMassLoad createBecMassLoad() {
		BecMassLoadImpl bec = new BecMassLoadImpl(mBefFactory.getBefMassLoad(),
				mBefFactory.getBefAmount(), mBefFactory.getBefRange(),
				mBefFactory.getBefCardNumber(), mUnits, mTimeSource,
				mEbcEnvironment, createBecCard(), createBecTransaction(),
				mUtilsFactory, this, mBsContext, mEbcProperties,mBefFactory.getBefTransaction(),createBecCardNumber(),mBefFactory.getBefCard(),mUtilsFactory.getCountrySetups());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecMassLoads()
	 */
	public BecMassLoads createBecMassLoads() {
		BecMassLoadsImpl bec = new BecMassLoadsImpl(createBecMassLoad(),
				mBefFactory.getBefMassLoad());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecBonus()
	 */
	public BecBonusCode createBecBonusCode() {
		BecBonusCodeImpl bec = new BecBonusCodeImpl(mBefFactory.getBefBonusCode(), mTimeSource, mBsContext);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecBonuses()
	 */
	public BecBonusCodes createBecBonusCodes() {
		BecBonusCodesImpl bec = new BecBonusCodesImpl(createBecBonusCode(),
				mBefFactory.getBefBonusCode());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecBonus()
	 */
	public BecBonus createBecBonus() {
		BecBonusImpl bec =  new BecBonusImpl(this, mUtilsFactory, mBefFactory.getBefBonus(),
				mTimeSource, mBefFactory.getBefAmount(), mBsContext);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecBonuses()
	 */
	public BecBonuses createBecBonuses() {
		BecBonusesImpl bec = new BecBonusesImpl(createBecBonus(), mBefFactory.getBefBonus(),
				createBecCardNumber());
		bec.validate();
		return bec;
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCountrySetup()
	 */
	public BecCountrySetup createBecCountrySetup() {
		BecCountrySetupImpl bec = new BecCountrySetupImpl(mBefFactory.getBefCountrySetup());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCountrySetups()
	 */
	public BecCountrySetups createBecCountrySetups() {
		BecCountrySetupsImpl bec =  new BecCountrySetupsImpl(createBecCountrySetup(),
				mBefFactory.getBefCountrySetup(),
				mUtilsFactory.getCountrySetups());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecExternalCard()
	 */
	public BecExternalCard createBecExternalCard() {
		BecExternalCardImpl bec = new BecExternalCardImpl(mBefFactory.getBefExternalCard(),
				createBecExternalCardSystem(), this, mUtilsFactory, mUnits);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecExternalCardSystem
	 * ()
	 */
	public BecExternalCardSystem createBecExternalCardSystem() {
		BecExternalCardSystemImpl bec = new BecExternalCardSystemImpl(
				mBefFactory.getBefExternalCardSystem(), this, mConstants,
				mUnits);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecMainCurrency()
	 */
	public BecMainCurrency createBecMainCurrency() {
		BecMainCurrencyImpl bec =  new BecMainCurrencyImpl(mBefFactory.getBefMainCurrency(), this,
				mTimeSource);
		bec.validate();
		return bec;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecMainCurrencies()
	 */
	public BecMainCurrencies createBecMainCurrencies() {
		BecMainCurrenciesImpl bec = new BecMainCurrenciesImpl(createBecMainCurrency());
		bec.validate();
		return bec;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecExchangeRate()
	 */
	public BecExchangeRate createBecExchangeRate() {
		BecExchangeRateImpl bec = new BecExchangeRateImpl(mBefFactory.getBefExchangeRate(), this,
				mBefFactory.getBefMainCurrency(), mTimeSource);
		bec.validate();
		return bec;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecExchangeRates()
	 */
	public BecExchangeRates createBecExchangeRates() {
		BecExchangeRatesImpl bec = new BecExchangeRatesImpl(createBecExchangeRate(), this,
				mBefFactory.getBefExchangeRate(),
				mBefFactory.getBefExchangeRateSpread(), mTimeSource, mUnits);
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCountries()
	 */
	public BecCountries createBecCountries() {
		BecCountriesImpl bec = new BecCountriesImpl(mBefFactory.getBefCountry(),
				createBecCountry());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecCountry()
	 */
	public BecCountry createBecCountry() {
		BecCountryImpl bec = new BecCountryImpl(mBefFactory.getBefCountry(), mTimeSource,
				mUnits, createBecMainCurrencies(), createBecExchangeRates());
		
		bec.validate();
		return bec;
		
	}

	// No references in code. Becs are autowired.
//	public BecMultipleSingleLoad createBecMultipleSingleLoad() {
//		return new BecMultipleSingleLoadImpl();
//	}
//
//	public BecMultipleSingleLoads createBecMultipleSingleLoads() {
//		return new BecMultipleSingleLoadsImpl();
//	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecReferenceCheck()
	 */
	public BecUnacknowledgedTimeout createBecUnacknowledgedTimeout() {

		BecUnacknowledgedTimeoutImpl bec = new BecUnacknowledgedTimeoutImpl(
				mBefFactory.getBefUnacknowledgedTimeout());
		bec.validate();
		return bec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecFactory#createBecSarecReport()
	 */
	public BecSarecReport createBecSarecReport() {
		BecSarecReportImpl bec = new BecSarecReportImpl(mBefFactory.getBefSarecReport(), mTimeSource, mUnits, mBefFactory.getBefIpayBusinessUnits());
		bec.validate();
		return bec;
	}
	
	
	public BecExternalTempCard createBecExternalTempCard() {
		BecExternalTempCardImpl bec = new BecExternalTempCardImpl(
				mBefFactory.getBefExternalTempCard(),
				mBefFactory.getBefExternalCardSystem(),
				mBefFactory.getBefExternalCard(),
				this, 
				mUtilsFactory,
				mUnits,
				mConstants);
		
		
		bec.validate();
		
		
		return bec;
	}
	
	//@Override
	public void afterPropertiesSet() throws Exception {

		Validate.notNull(mBefFactory);
		Validate.notNull(mTimeSource);
		Validate.notNull(mConstants);
		Validate.notNull(mEbcEnvironment);
		Validate.notNull(mUnits);
		Validate.notNull(mUtilsFactory);
		Validate.notNull(mBsContext);
		Validate.notNull(mEbcProperties);
	}
	//
}
