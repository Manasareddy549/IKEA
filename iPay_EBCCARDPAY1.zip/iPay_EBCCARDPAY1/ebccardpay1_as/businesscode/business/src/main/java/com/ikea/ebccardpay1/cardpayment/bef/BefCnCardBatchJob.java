package com.ikea.ebccardpay1.cardpayment.bef;

import java.sql.Blob;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.CnCardBatchJob;

public interface BefCnCardBatchJob extends Bef<CnCardBatchJob>{

	
	public List<Object[]> registerCard(String pActiveDate,String pCountry,int pRecordCount) throws ParseException;
	
	public List<CnCardBatchJob> getBlobFilesToRegister(String pIds);
	
	public List<Object[]> getTransactions(String pSalesDay,String pCountry);
	
	public Blob createChinaBlobFile(String pStringData);
	
	public List<CnCardBatchJob> findByFlowNumber(String flowNumber);
	
	public void deleteBatchJob(long cnJobId);
	
	public List<Object[]> getCreditTransaction(long card_id,Date dateToIgnore);
}
