/*
 * Created on 2006-maj-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.exception.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;

/**
 * @author anms
 *
 */
public interface BecCardNumber {

	/**
	 * 
	 * @param pCardNumbeId
	 * @return
	 */
	public BecCardNumber init(long pCardNumbeId);

	/**
	 * Creates the card number object based on a card number string.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 */
	public void createCardNumber(String pCardNumberString)
		throws InvalidCardNumberException;

	/**
	 * Creates the cardnumber object based on the cardnumber string 
	 * and also includes the verificationcode
	 * @param pCardNumberString
	 * @param pVerificationCode
	 */
	public void createCardNumber(
		String pCardNumberString,
		String pVerificationCode)
		throws InvalidCardNumberException;

	/**
	 * 
	 * @param pIssuer
	 * @param pCardTypeDigit
	 * @param pAccountNumber
	 * @throws InvalidCardNumberException
	 */
	public void createCardNumber(
		String pIssuer,
		int pCardTypeDigit,
		long pAccountNumber)
		throws InvalidCardNumberException;

	/**
	 * Finds the card number based on a card number string.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 * @throws CardNumberNotFoundException if the card number was not found.
	 */
	public void findCardNumber(String pCardNumberString)
		throws InvalidCardNumberException, CardNumberNotFoundException;

	/**
	 * Creates a card number string.
	 * @param pCardNumber
	 * @return the string
	 */
	public String composeCardNumberString(CardNumber pCardNumber);

	/**
	 * Takes a card number string and split it into parts (issuer, type, account number and check digit).
	 * The parts are validated and the check digit is verified.
	 * @param pCardNumberString
	 * @return the card number split in parts
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 */
	public VoCardNumber splitCardNumber(String pCardNumberString)
		throws InvalidCardNumberException;

	/**
	 * Gets the card number object.
	 * @return the card number object.
	 */
	public CardNumber getCardNumber();

	/**
	 * Validates if it is a valid issuer number. 
	 * @param pIssuer the issuer number
	 * @throws InvalidCardIssuerException if the issuer is not a valid one for iPay
	 */
	public void checkValidIssuer(String pIssuer)
		throws InvalidCardIssuerException;

	/**
	 * Checks that it is a valid card type for iPay
	 * @param pCardTypeDigit
	 * @throws InvalidCardTypeDigitException
	 */
	public void checkCardTypeDigit(int pCardTypeDigit)
		throws InvalidCardTypeDigitException;

}
