/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 * InvalidCardNumberException is thrown if 
 * the card number string does not match the regexp, 
 * the check didgit is not correct or 
 * the card type didgit is not supported.
 */
public class InvalidCardNumberException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -777398756236848253L;

	public InvalidCardNumberException() {
		super();
	}
	public InvalidCardNumberException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidCardNumber();
	}
}
