package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anagc
 */
public class WrongOrderException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4743374531032157732L;

	public WrongOrderException() {
		super();
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.WrongOrder();
	}
}
