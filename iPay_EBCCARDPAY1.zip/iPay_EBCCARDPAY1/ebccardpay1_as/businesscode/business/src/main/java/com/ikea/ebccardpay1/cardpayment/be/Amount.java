/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Amount extends BusinessEntity {
	/**										
	 * Storage: AMOUNT_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mAmountId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private Card mCard;
	private MassLoad mMassLoad;
	private Campaign mCampaign;
	private java.util.Set<Transaction> mTransactions = new java.util.LinkedHashSet<Transaction>(0);
	private BonusCode mBonusCode;
	private Bonus mBonus;
	private MultipleSingleLoad mMultipleSingleLoad;
	private IpayBusinessUnits mIpayBusinessUnits;

	/**										
	 * Data								
	 */										
	private String mAmountType;
	private java.math.BigDecimal mCurrentAmount;
	private java.math.BigDecimal mPriority;
	private java.math.BigDecimal mOriginalAmount;
	private String mBuType;
	private String mBuCode;
	private String mBalanceState;

	/**											
	 * @return Returns the amountId.													
	 */											
	public long getAmountId() {
		return mAmountId;
	}
	/**
	 * @param pAmountId The amountId to set.
	 */
	public void setAmountId(long pAmountId) {
		mAmountId = pAmountId;
	}

	/**											
	 * @return Returns the amountType.													
	 */											
	public String getAmountType() {
		return mAmountType;
	}
	/**
	 * @param pAmountType The amountType to set.
	 */
	public void setAmountType(String pAmountType) {
		mAmountType = pAmountType;
	}

	/**											
	 * @return Returns the currentAmount.													
	 */											
	public java.math.BigDecimal getCurrentAmount() {
		return mCurrentAmount;
	}
	/**
	 * @param pCurrentAmount The currentAmount to set.
	 */
	public void setCurrentAmount(java.math.BigDecimal pCurrentAmount) {
		mCurrentAmount = pCurrentAmount;
	}

	/**											
	 * @return Returns the priority.													
	 */											
	public java.math.BigDecimal getPriority() {
		return mPriority;
	}
	/**
	 * @param pPriority The priority to set.
	 */
	public void setPriority(java.math.BigDecimal pPriority) {
		mPriority = pPriority;
	}

	/**											
	 * @return Returns the originalAmount.													
	 */											
	public java.math.BigDecimal getOriginalAmount() {
		return mOriginalAmount;
	}
	/**
	 * @param pOriginalAmount The originalAmount to set.
	 */
	public void setOriginalAmount(java.math.BigDecimal pOriginalAmount) {
		mOriginalAmount = pOriginalAmount;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the balanceState.													
	 */											
	public String getBalanceState() {
		return mBalanceState;
	}
	/**
	 * @param pBalanceState The balanceState to set.
	 */
	public void setBalanceState(String pBalanceState) {
		mBalanceState = pBalanceState;
	}

	/**											
	 * @return Returns the card.													
	 */											
	public Card getCard() {
		return mCard;
	}
	/**
	 * @param pCard The card to set.
	 */
	public void setCard(Card pCard) {
		mCard = pCard;
	}

	/**											
	 * @return Returns the massLoad.													
	 */											
	public MassLoad getMassLoad() {
		return mMassLoad;
	}
	/**
	 * @param pMassLoad The massLoad to set.
	 */
	public void setMassLoad(MassLoad pMassLoad) {
		mMassLoad = pMassLoad;
	}

	/**											
	 * @return Returns the campaign.													
	 */											
	public Campaign getCampaign() {
		return mCampaign;
	}
	/**
	 * @param pCampaign The campaign to set.
	 */
	public void setCampaign(Campaign pCampaign) {
		mCampaign = pCampaign;
	}

	/**											
	 * @return Returns the transactions.													
	 */											
	public java.util.Set<Transaction> getTransactions() {
		return mTransactions;
	}
	/**
	 * @param pTransactions The transactions to set.
	 */
	public void setTransactions(java.util.Set<Transaction> pTransactions) {
		mTransactions = pTransactions;
	}

	/**											
	 * @return Returns the bonusCode.													
	 */											
	public BonusCode getBonusCode() {
		return mBonusCode;
	}
	/**
	 * @param pBonusCode The bonusCode to set.
	 */
	public void setBonusCode(BonusCode pBonusCode) {
		mBonusCode = pBonusCode;
	}

	/**											
	 * @return Returns the bonus.													
	 */											
	public Bonus getBonus() {
		return mBonus;
	}
	/**
	 * @param pBonus The bonus to set.
	 */
	public void setBonus(Bonus pBonus) {
		mBonus = pBonus;
	}

	/**
	 * Connect Card.
	 * @param pCard
	 */
	public void connectCard(Card pCard) {
		setCard(pCard);
		if(pCard != null) {
			pCard.getAmounts().add(this);
		}
	}

	/**
	 * Disconnect Card.
	 */
	public void disconnectCard() {
		if(getCard() != null) {
			getCard().getAmounts().remove(this);
		}
		setCard(null);
	}

	/**
	 * Connect MassLoad.
	 * @param pMassLoad
	 */
	public void connectMassLoad(MassLoad pMassLoad) {
		setMassLoad(pMassLoad);
		if(pMassLoad != null) {
			pMassLoad.getAmounts().add(this);
		}
	}

	/**
	 * Disconnect MassLoad.
	 */
	public void disconnectMassLoad() {
		if(getMassLoad() != null) {
			getMassLoad().getAmounts().remove(this);
		}
		setMassLoad(null);
	}

	/**
	 * Connect Campaign.
	 * @param pCampaign
	 */
	public void connectCampaign(Campaign pCampaign) {
		setCampaign(pCampaign);
		if(pCampaign != null) {
			pCampaign.getAmounts().add(this);
		}
	}

	/**
	 * Disconnect Campaign.
	 */
	public void disconnectCampaign() {
		if(getCampaign() != null) {
			getCampaign().getAmounts().remove(this);
		}
		setCampaign(null);
	}

	/**
	 * Connect a Transaction.
	 * @param pTransaction
	 */
	public void connectTransaction(Transaction pTransaction) {
		getTransactions().add(pTransaction);
		if(pTransaction != null) {
			pTransaction.setAmount(this);
		}
	}

	/**
	 * Disconnect a Transaction.
	 * @param pTransaction
	 */
	public void disconnectTransaction(Transaction pTransaction) {
		if(pTransaction != null) {
			pTransaction.setAmount(null);
		}
		getTransactions().remove(pTransaction);
	}

	/**
	 * Connect BonusCode.
	 * @param pBonusCode
	 */
	public void connectBonusCode(BonusCode pBonusCode) {
		setBonusCode(pBonusCode);
		if(pBonusCode != null) {
			pBonusCode.getAmount().add(this);
		}
	}

	/**
	 * Disconnect BonusCode.
	 */
	public void disconnectBonusCode() {
		if(getBonusCode() != null) {
			getBonusCode().getAmount().remove(this);
		}
		setBonusCode(null);
	}

	/**
	 * Connect Bonus.
	 * @param pBonus
	 */
	public void connectBonus(Bonus pBonus) {
		setBonus(pBonus);
		if(pBonus != null) {
			pBonus.setAmount(this);
		}
	}

	/**
	 * Disconnect Bonus.
	 */
	public void disconnectBonus() {
		if(getBonus() != null) {
			getBonus().setAmount(null);
		}
		setBonus(null);
	}


	public MultipleSingleLoad getMultipleSingleLoad() {
		return mMultipleSingleLoad;
	}

	public void setMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad) {
		mMultipleSingleLoad = pMultipleSingleLoad;
	}

	/**
	 * Connect MassLoad.
	 * @param pMassLoad
	 */
	public void connectMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad) {
		setMultipleSingleLoad(pMultipleSingleLoad);
		if(pMultipleSingleLoad != null) {
			pMultipleSingleLoad.getAmounts().add(this);
		}
	}

	/**
	 * Disconnect MassLoad.
	 */
	public void disconnectMultipleSingleLoad() {
		if(getMultipleSingleLoad() != null) {
			getMultipleSingleLoad().getAmounts().remove(this);
		}
		setMultipleSingleLoad(null);
	}

	/**											
	 * @return Returns the IpayBusinessUnit.													
	 */											
	public IpayBusinessUnits getIpayBusinessUnits() {
		return mIpayBusinessUnits;
	}
	/**
	 * @param pIpayBusinessUnits The IpayBusinessUnits to set.
	 */
	public void setIpayBusinessUnits(IpayBusinessUnits pIpayBusinessUnits) {
		mIpayBusinessUnits = pIpayBusinessUnits;
	}
	
	/**
	 * Connect IpayBusinessUnits.
	 * @param pIpayBusinessUnits
	 */
	public void connectIpayBusinessUnits(IpayBusinessUnits pIpayBusinessUnits) {
		setIpayBusinessUnits(pIpayBusinessUnits);
		if(pIpayBusinessUnits != null) {
			pIpayBusinessUnits.getAmount().add(this);
		}
	}

	/**
	 * Disconnect IpayBusinessUnits.
	 */
	public void disconnectpIpayBusinessUnits() {
		if(getIpayBusinessUnits() != null) {
			getIpayBusinessUnits().getAmount().remove(this);
		}
		setIpayBusinessUnits(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mAmountId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("amountId", CodeGeneration.toObject(mAmountId));
		vMap.put("amountType", CodeGeneration.toObject(mAmountType));
		vMap.put("currentAmount", CodeGeneration.toObject(mCurrentAmount));
		vMap.put("priority", CodeGeneration.toObject(mPriority));
		vMap.put("originalAmount", CodeGeneration.toObject(mOriginalAmount));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("balanceState", CodeGeneration.toObject(mBalanceState));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("amountId")) mAmountId = CodeGeneration.objectTolong(pMap.get("amountId"));
		if(pMap.containsKey("amountType")) mAmountType = CodeGeneration.objectToString(pMap.get("amountType"));
		if(pMap.containsKey("currentAmount")) mCurrentAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("currentAmount"));
		if(pMap.containsKey("priority")) mPriority = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("priority"));
		if(pMap.containsKey("originalAmount")) mOriginalAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("originalAmount"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("balanceState")) mBalanceState = CodeGeneration.objectToString(pMap.get("balanceState"));
	}
}
