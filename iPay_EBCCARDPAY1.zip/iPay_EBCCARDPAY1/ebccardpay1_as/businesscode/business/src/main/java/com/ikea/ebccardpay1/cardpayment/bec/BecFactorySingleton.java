///*
// * Created on 2006-maj-12
// *
// */
//package com.ikea.ebccardpay1.cardpayment.bec;
//
//import com.ikea.ebccardpay1.cardpayment.bef.BefFactorySingleton;
//import com.ikea.ebccardpay1.cardpayment.utils.ConstantsImpl;
//import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactorySingleton;
//import com.ikea.framework.common.TimeSourceBean;
//import com.ikea.framework.exception.IkeaException;
//
///**
// * @author anms
// *
// */
//public class BecFactorySingleton {
//    protected static BecFactory sInstance;
//
//    /**
//     * Don't construct - it is a singleton.
//     */
//    private BecFactorySingleton() {
//    }
//
//    /**
//     *
//     * @return
//     * @throws IkeaException
//     */
//    synchronized public static BecFactory getInstance() throws IkeaException {
//
//        if (sInstance == null) {
//            sInstance = new BecFactoryImpl(
//                    BefFactorySingleton.getInstance(),
//                    TimeSourceBean.sInstance,
//                    new ConstantsImpl(BefFactorySingleton.getInstance()
//                            .getBefCardTypeConstant(), BefFactorySingleton
//                            .getInstance().getBefSourceSystemConstant(),
//                            BefFactorySingleton.getInstance().getBefConstants()),
//                    utilsFactory.getEbcEnvironment(),
//                    utilsFactory.getUnits(),
//                    utilsFactory);
//        }
//
//        return sInstance;
//    }
//
//    /**
//     * Use this setter before the first invocation of the getter
//     * to prevent the creation of a default instance.
//     *
//     * @param pFactory Null to reset the singleton
//     */
//    public static void setInstance(BecFactory pFactory) {
//        sInstance = pFactory;
//    }
//
//}
