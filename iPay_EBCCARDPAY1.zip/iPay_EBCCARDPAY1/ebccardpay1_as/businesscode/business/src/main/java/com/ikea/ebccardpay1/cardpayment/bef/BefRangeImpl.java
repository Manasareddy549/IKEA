/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefRangeImpl extends BefAbstract<Range> implements BefRange {

	private final static Logger mCategory_addCardNumbers =
		LoggerFactory.getLogger(BefRangeImpl.class.getName() + ".addCardNumbers");

	private final static Logger mCategory_findCurrent =
		LoggerFactory.getLogger(BefRangeImpl.class.getName() + ".findCurrent");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefRangeImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefRange#addCardNumbers(com.ikea.ebccardpay1.cardpayment.be.Range, java.util.List)
	 */
	public void addCardNumbers(Range pRange, List<CardNumber> pCardNumbers) {

		Session vSession = mSessionFactory.getCurrentSession();

		vSession.flush();

		String vSql =
			"insert into card_number_range_t(range_id, card_number_id) values (:range_id, :card_number_id)";

		if (mCategory_addCardNumbers.isDebugEnabled()) {
			mCategory_addCardNumbers.debug("SQL: " + vSql);
		}

		SQLQuery vQuery = vSession.createSQLQuery(vSql);
		int vInserted = 0;

		for (CardNumber vCardNumber : pCardNumbers) {
		
			vQuery.setLong("range_id", pRange.getRangeId());
			vQuery.setLong("card_number_id", vCardNumber.getCardNumberId());

			if (mCategory_addCardNumbers.isDebugEnabled()) {
				mCategory_addCardNumbers.debug(
					"Param: range id "
						+ pRange.getRangeId()
						+ " card number id "
						+ vCardNumber.getCardNumberId());
			}

			vInserted += vQuery.executeUpdate();
			vSession.flush();
		}
		mCategory_addCardNumbers.info(
			"Inserted "
				+ vInserted
				+ " card numbers into range id "
				+ pRange.getRangeId());
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefRange#findByCurrent(java.lang.String)
	 */
	public List<Range> findByCurrent(String pCountryCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		GenericCriteria<Range> vCriteria = new GenericCriteria<Range>(vSession.createCriteria(Range.class));

		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		// added to restrict Gift cards in Campaign Segments, defect-IKEA01072485 -anagc
		//vCriteria.add(Restrictions.not(Restrictions.like("header","SELP"+"%")));
		
		ArrayList<String> vStates = new ArrayList<String>();
		vStates.add(Constants.IMPORT_STATE_CONSTANT_STARTED);
		vStates.add(Constants.IMPORT_STATE_CONSTANT_COMPLETED);
		vStates.add(Constants.IMPORT_STATE_CONSTANT_FAILED);

		vCriteria.add(Restrictions.in("importState", vStates));

		vCriteria.add(
			Restrictions.sqlRestriction(
				"{alias}.created_Date_Time > (sysdate - 15)"));

		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findCurrent.isDebugEnabled()) {
			mCategory_findCurrent.debug("Criteria: " + vCriteria.toString());
		}

		List<Range> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findCurrent.debug("No ranges found.");
		} else {
			mCategory_findCurrent.debug("Found " + vList.size() + " ranges.");
		}
		return vList;
	}

	@Override
	protected Class<Range> getBusinessEntityClass() {
		return Range.class;
	}
}
