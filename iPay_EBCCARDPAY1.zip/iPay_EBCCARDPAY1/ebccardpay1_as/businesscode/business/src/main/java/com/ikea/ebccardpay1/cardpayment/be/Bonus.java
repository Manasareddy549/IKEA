/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Bonus extends BusinessEntity {
	/**										
	 * Storage: BONUS_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mBonusId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private BonusCode mBonusCode;
	private Amount mAmount;
	private int mReasonCodeId;

	/**										
	 * Data								
	 */										
	private String mCountryCode;
	private java.math.BigDecimal mBonusAmount;
	private String mCurrencyCode;
	private String mAmountType;
	private java.util.Date mAuthorizedDateTime;
	private String mAuthorizedBy;

	/**											
	 * @return Returns the bonusId.													
	 */											
	public long getBonusId() {
		return mBonusId;
	}
	/**
	 * @param pBonusId The bonusId to set.
	 */
	public void setBonusId(long pBonusId) {
		mBonusId = pBonusId;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the bonusAmount.													
	 */											
	public java.math.BigDecimal getBonusAmount() {
		return mBonusAmount;
	}
	/**
	 * @param pBonusAmount The bonusAmount to set.
	 */
	public void setBonusAmount(java.math.BigDecimal pBonusAmount) {
		mBonusAmount = pBonusAmount;
	}

	/**											
	 * @return Returns the currencyCode.													
	 */											
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	/**
	 * @param pCurrencyCode The currencyCode to set.
	 */
	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	/**											
	 * @return Returns the amountType.													
	 */											
	public String getAmountType() {
		return mAmountType;
	}
	/**
	 * @param pAmountType The amountType to set.
	 */
	public void setAmountType(String pAmountType) {
		mAmountType = pAmountType;
	}

	/**											
	 * @return Returns the authorizedDateTime.													
	 */											
	public java.util.Date getAuthorizedDateTime() {
		return mAuthorizedDateTime;
	}
	/**
	 * @param pAuthorizedDateTime The authorizedDateTime to set.
	 */
	public void setAuthorizedDateTime(java.util.Date pAuthorizedDateTime) {
		mAuthorizedDateTime = pAuthorizedDateTime;
	}

	/**											
	 * @return Returns the authorizedBy.													
	 */											
	public String getAuthorizedBy() {
		return mAuthorizedBy;
	}
	/**
	 * @param pAuthorizedBy The authorizedBy to set.
	 */
	public void setAuthorizedBy(String pAuthorizedBy) {
		mAuthorizedBy = pAuthorizedBy;
	}

	/**											
	 * @return Returns the bonusCode.													
	 */											
	public BonusCode getBonusCode() {
		return mBonusCode;
	}
	/**
	 * @param pBonusCode The bonusCode to set.
	 */
	public void setBonusCode(BonusCode pBonusCode) {
		mBonusCode = pBonusCode;
	}

	/**											
	 * @return Returns the amount.													
	 */											
	public Amount getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The amount to set.
	 */
	public void setAmount(Amount pAmount) {
		mAmount = pAmount;
	}

	/**
	 * Connect BonusCode.
	 * @param pBonusCode
	 */
	public void connectBonusCode(BonusCode pBonusCode) {
		setBonusCode(pBonusCode);
		if(pBonusCode != null) {
			pBonusCode.getBonus().add(this);
		}
	}

	/**
	 * Disconnect BonusCode.
	 */
	public void disconnectBonusCode() {
		if(getBonusCode() != null) {
			getBonusCode().getBonus().remove(this);
		}
		setBonusCode(null);
	}

	/**
	 * Connect Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		setAmount(pAmount);
		if(pAmount != null) {
			pAmount.setBonus(this);
		}
	}

	/**
	 * Disconnect Amount.
	 */
	public void disconnectAmount() {
		if(getAmount() != null) {
			getAmount().setBonus(null);
		}
		setAmount(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	
	/**											
	 * @return Returns the reasonCode.													
	 */	
	public int getReasonCodeId() {
		return mReasonCodeId;
	}
	/**
	 * @param pReasonCode The reasonCode to set.
	 */
	public void setReasonCodeId(int pReasonCodeId) {
	    mReasonCodeId = pReasonCodeId;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mBonusId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("bonusId", CodeGeneration.toObject(mBonusId));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("bonusAmount", CodeGeneration.toObject(mBonusAmount));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("amountType", CodeGeneration.toObject(mAmountType));
		vMap.put("authorizedDateTime", CodeGeneration.toObject(mAuthorizedDateTime));
		vMap.put("authorizedBy", CodeGeneration.toObject(mAuthorizedBy));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("reasonCodeId", CodeGeneration.toObject(mReasonCodeId));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("bonusId")) mBonusId = CodeGeneration.objectTolong(pMap.get("bonusId"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("bonusAmount")) mBonusAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("bonusAmount"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("amountType")) mAmountType = CodeGeneration.objectToString(pMap.get("amountType"));
		if(pMap.containsKey("authorizedDateTime")) mAuthorizedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("authorizedDateTime"));
		if(pMap.containsKey("authorizedBy")) mAuthorizedBy = CodeGeneration.objectToString(pMap.get("authorizedBy"));
	}
}
