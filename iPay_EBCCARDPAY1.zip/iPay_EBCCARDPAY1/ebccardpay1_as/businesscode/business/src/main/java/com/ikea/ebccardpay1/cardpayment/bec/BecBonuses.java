/*
 * Created on 2007-apr-16
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecBonuses {

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecBonuses init(UserEnvironment pUserEnvironment);

	/**
	 * 
	 * @return
	 */
	public List<VoBonusOnCard> findUnauthorized()
		throws IkeaException, ValueMissingException;
		

	public List<VoBonusComplete> findBonusLoads(VoBonusSearch pVoBonusSearch) throws ValueMissingException;


}
