/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCode;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeSearch;
import com.ikea.ebcframework.exception.IkeaException;
import java.util.List;

/**
 * @author anms
 *
 */
public interface BecBonusCodes {

	/**
	 * @param pVoBonusCodeList
	 * @return
	 */
	public BecBonusCodes init(List<VoBonusCode> pVoBonusCodeList);

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecBonusCodes init(UserEnvironment pUserEnvironment);

	/**
	 * @throws IkeaException
	 * @throws ValueMissingException
	 * @throws BonusCodeException
	 */
	public void manage()
		throws IkeaException, ValueMissingException, BonusCodeException;

	/**
	 * @return
	 */
	public List<VoBonusCode> getVoBonusCodeList() throws ValueMissingException;

	/**
	 * @return
	 * @throws IkeaException
	 */
	public List<VoBonusCodeBriefRef> findCurrentBonusCodes()
		throws IkeaException, ValueMissingException;

	/**
	 * @return
	 * @throws IkeaException
	 */
	public List<VoBonusCode> findBonuses(VoBonusCodeSearch pVoBonusCodeSearch)
		throws IkeaException, ValueMissingException;

}
