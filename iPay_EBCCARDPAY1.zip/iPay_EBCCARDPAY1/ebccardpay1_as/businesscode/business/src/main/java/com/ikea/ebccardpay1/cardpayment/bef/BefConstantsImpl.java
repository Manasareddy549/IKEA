/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;

/**
 * @author anms
 * @author tpon
 */
public class BefConstantsImpl implements BefConstants {

	private final static Logger mLog = LoggerFactory.getLogger(BefConstantsImpl.class);

	// Must order the constants alfabeticly to make unit tests work
	private final static String SELECT_CARD_TYPE_CONSTANT = "select CARD_TYPE from CARD_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_CARD_STATE_CONSTANT = "select CARD_STATE from CARD_STATE_CONSTANT_T order by 1";

	private final static String SELECT_CAMPAIGN_STATE_CONSTANT = "select CAMPAIGN_STATE from CAMPAIGN_STATE_CONSTANT_T order by 1";

	private final static String SELECT_AMOUNT_TYPE_CONSTANT = "select AMOUNT_TYPE from AMOUNT_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_EXCHANGE_MODE_CONSTANT = "select EXCHANGE_MODE from EXCHANGE_MODE_CONSTANT_T order by 1";

	private final static String SELECT_SOURCE_SYSTEM_CONSTANT = "select SOURCE_SYSTEM from SOURCE_SYSTEM_CONSTANT_T order by 1";

	private final static String SELECT_LIFE_CYCLE_TYPE_CONSTANT = "select LIFE_CYCLE_TYPE from LIFE_CYCLE_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_TRANSACTION_TYPE_CONSTANT = "select TRANSACTION_TYPE from TRANSACTION_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_RESPONSE_TYPE_CONSTANT = "select RESPONSE_TYPE from RESPONSE_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_PARAMETER_TYPE_CONSTANT = "select PARAMETER_TYPE from PARAMETER_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_FINANCIAL_TYPE_CONSTANT = "select FINANCIAL_TYPE from FINANCIAL_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_KPI_TYPE_CONSTANT = "select KPI_TYPE from KPI_TYPE_CONSTANT_T order by 1";

	private final static String SELECT_KPI_TYPE_FOR_CALCULATION = "select KPI_TYPE from KPI_TYPE_CONSTANT_T where CALCULATE='Y' order by CALCULATION_ORDER";

	private final static String SELECT_LOAD_REASON_CODE_CONSTANT = "select LOAD_REASON_DESCRIPTION from REASON_CODE_T order by 1";

	private final static String SELECT_REDEEM_REASON_CODE_CONSTANT = "select REDEEM_REASON_DESCRIPTION from REASON_CODE_T order by 1";
	
	private final static String SELECT_CUSTOMER_TYPE_CONSTANT = "select CUSTOMER_TYPE from CUSTOMER_TYPE_T order by 1";

	private SessionFactory mSessionFactory = null;

	
	public BefConstantsImpl(SessionFactory pSessionFactory) {
		mSessionFactory = pSessionFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getCampaignStateConstants
	 * ()
	 */
	public List<String> getCampaignStateConstants() {
		return getConstants(SELECT_CAMPAIGN_STATE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getCardTypeConstants()
	 */
	public List<String> getCardTypeConstants() {
		return getConstants(SELECT_CARD_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getCardStateConstants()
	 */
	public List<String> getCardStateConstants() {
		return getConstants(SELECT_CARD_STATE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getAmountTypeConstants
	 * ()
	 */
	public List<String> getAmountTypeConstants() {
		return getConstants(SELECT_AMOUNT_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getSourceSystemConstants
	 * ()
	 */
	public List<String> getSourceSystemConstants() {
		return getConstants(SELECT_SOURCE_SYSTEM_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seel
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getLifeCycleTypeConstants
	 * ()
	 */
	public List<String> getLifeCycleTypeConstants() {
		return getConstants(SELECT_LIFE_CYCLE_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getParameterTypeConstants
	 * ()
	 */
	public List<String> getParameterTypeConstants() {
		return getConstants(SELECT_PARAMETER_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getTransactionTypeConstants
	 * ()
	 */
	public List<String> getTransactionTypeConstants() {
		return getConstants(SELECT_TRANSACTION_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getResponseTypeConstants
	 * ()
	 */
	public List<String> getResponseTypeConstants() {
		return getConstants(SELECT_RESPONSE_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getFinancialTypeConstants
	 * ()
	 */
	public List<String> getFinancialTypeConstants() {
		return getConstants(SELECT_FINANCIAL_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getKpiTypeConstants()
	 */
	public List<String> getKpiTypeConstants() {
		return getConstants(SELECT_KPI_TYPE_CONSTANT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getKpiTypesToCalculate
	 * ()
	 */
	public List<String> getKpiTypesToCalculate() {
		return getConstants(SELECT_KPI_TYPE_FOR_CALCULATION);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefConstants#getExchangeModeConstants
	 * ()
	 */
	public List<String> getExchangeModeConstants() {
		return getConstants(SELECT_EXCHANGE_MODE_CONSTANT);
	}
	
	public List<String> getLoadReasonCodeConstants() {
		return getConstants(SELECT_LOAD_REASON_CODE_CONSTANT);
	}
	
	public List<String> getRedeemReasonCodeConstants() {
		return getConstants(SELECT_REDEEM_REASON_CODE_CONSTANT);
	}
	
	public List<String> getCustomerTypeConstants() {
		return getConstants(SELECT_CUSTOMER_TYPE_CONSTANT);
	}


	private List<String> getConstants(String pSelectString) {

		Session vSession = mSessionFactory.getCurrentSession();

		if (mLog.isDebugEnabled()) {
			mLog.debug("SQL: " + pSelectString);
		}

		return new GenericQuery<String>(vSession.createSQLQuery(pSelectString))
				.list();

	}

}
