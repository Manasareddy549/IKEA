/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeModeConstant;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefExchangeModeConstantImpl
	extends BefAbstract<ExchangeModeConstant> implements BefExchangeModeConstant {

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefExchangeModeConstantImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);

	}

	@Override
	protected Class<ExchangeModeConstant> getBusinessEntityClass() {
		return ExchangeModeConstant.class;
	}

}
