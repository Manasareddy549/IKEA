/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.rmi.dgc.VMID;

import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpay1.cardpayment.vo.VoEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoOriginator;
import com.ikea.ebccardpay1.cardpayment.vo.VoReference;
import com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem;
import com.ikea.ebcframework.persistence.keygenerator.IkeaKeyGenerator;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.common.TimeSource;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 * 
 */
public class UtilsFactoryImpl implements UtilsFactory, InitializingBean {

	private Units mUnits = null;
	private TimeSource mTimeSource = null;
	private Currencies mCurrenciesImpl = null;
	private CountrySetups mCountrySetupsImpl = null;
	private EbcEnvironment mEbcEnvironment = null;
	private PriorityEvaluator mPriorityEvaluator;
	private UserEnvironmentCache mUserEnvironmentCache;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;
	private BefFactory mBefFactory = null;

	@Autowired
	private BsContext mBsContext;
	@Autowired
	private IkeaKeyGenerator mIkeaKeyGenerator;

	/**
	 * 
	 * @param pTimeSource
	 * @throws IkeaException
	 */
	public UtilsFactoryImpl(EbcEnvironment pEbcEnvironment, Units pUnits,
			Currencies pCurrencies, CountrySetups pCountrySetups,
			TimeSource pTimeSource, UserEnvironmentCache pUserEnvironmentCache,
			BefFactory pBefFactory)
			throws IkeaException {

		mEbcEnvironment = pEbcEnvironment;
		mUnits = pUnits;
		mCurrenciesImpl = pCurrencies;
		mCountrySetupsImpl = pCountrySetups;
		mTimeSource = pTimeSource;
		mUserEnvironmentCache = pUserEnvironmentCache;
		mBefFactory = pBefFactory;
	}

	//@Override
	public void afterPropertiesSet() throws Exception {
		notNull(mEbcEnvironment);
		notNull(mUnits);
		notNull(mCurrenciesImpl);
		notNull(mCountrySetupsImpl);
		notNull(mTimeSource);
		notNull(mUserEnvironmentCache);
		notNull(mBsContext);
		notNull(mIkeaKeyGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#createUserEnvironment
	 * ()
	 */
	public UserEnvironment createUserEnvironment() {
		return mUserEnvironmentCache
				.fetch(mBsContext.getUserProfile().getUID());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createTransactionEnvironment(boolean,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoOriginator,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoReference,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoEnvironment)
	 */
	public TransactionEnvironment createTransactionEnvironment(String pSwiped,
			VoOriginator pVoOriginator, VoReference pVoReference,
			VoSourceSystem pVoSourceSystem, VoEnvironment pVoEnvironment) {

		return new TransactionEnvironmentImpl(pVoReference.getReference(),
				pVoSourceSystem.getSourceSystem(),
				pVoReference.getTransmissionDateTime(),
				(pVoEnvironment != null ? pVoEnvironment.getAutoAcknowledge()
						: true), pVoOriginator.getEmployee(),
				pVoOriginator.getPointOfSale(), pVoOriginator.getReceipt(),
				pSwiped,
				(pVoEnvironment != null ? pVoEnvironment.getAckTimeOut() : 0),
				mBsContext, mIkeaKeyGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createTransactionEnvironment(java.lang.String,
	 * com.ikea.ebccardpay1.cardpayment.be.Transaction)
	 */
	public TransactionEnvironment createTransactionEnvironment(
			String pSourceSystem, Transaction pTransaction) {

		return new TransactionEnvironmentImpl(new VMID().toString(),
				pSourceSystem, mTimeSource.currentDate(), true, mBsContext
						.getUserProfile().getUID(),
				(pTransaction != null ? pTransaction.getPointOfSale() : null),
				null,
				(pTransaction != null ? pTransaction.getSwiped() : "N"), 0,
				mBsContext, mIkeaKeyGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createTransactionEnvironment(boolean,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoOriginator,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem)
	 */
	public TransactionEnvironment createTransactionEnvironment(String pSwiped,
			VoOriginator pVoOriginator, VoSourceSystem pVoSourceSystem) {

		return new TransactionEnvironmentImpl(new VMID().toString(),
				pVoSourceSystem.getSourceSystem(), mTimeSource.currentDate(),
				true, pVoOriginator.getEmployee(),
				pVoOriginator.getPointOfSale(), pVoOriginator.getReceipt(),
				pSwiped, 0, mBsContext, mIkeaKeyGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createTransactionEnvironment
	 * (com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem)
	 */
	public TransactionEnvironment createTransactionEnvironment(
			VoSourceSystem pVoSourceSystem) {

		return new TransactionEnvironmentImpl(new VMID().toString(),
				pVoSourceSystem.getSourceSystem(), mTimeSource.currentDate(),
				true, null, null, null, "N", 0, mBsContext, mIkeaKeyGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createBusinessUnitEnvironment
	 * (com.ikea.ebccardpay1.cardpayment.vo.VoOriginator)
	 */
	public BusinessUnitEnvironment createBusinessUnitEnvironment(
			VoOriginator pVoOriginator) {

		return new BusinessUnitEnvironmentImpl(pVoOriginator.getBuType(),
				pVoOriginator.getBuCode(), mUnits, mTimeSource,
				mBefFactory.getBefIpayBusinessUnits());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createBusinessUnitEnvironment
	 * (com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit)
	 */
	public BusinessUnitEnvironment createBusinessUnitEnvironment(
			VoBusinessUnit pVoBusinessUnit) {

		return new BusinessUnitEnvironmentImpl(pVoBusinessUnit.getBuType(),
				pVoBusinessUnit.getBuCode(), mUnits, mTimeSource,
				mBefFactory.getBefIpayBusinessUnits());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createBusinessUnitEnvironment
	 * (com.ikea.ebccardpay1.cardpayment.be.Transaction)
	 */
	public BusinessUnitEnvironment createBusinessUnitEnvironment(
			Transaction pTransaction) {

		return new BusinessUnitEnvironmentImpl(pTransaction.getBuType(),
				pTransaction.getBuCode(), mUnits, mTimeSource,
				mBefFactory.getBefIpayBusinessUnits());
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createBusinessUnitEnvironment
	 * (com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory)
	 */
	public BusinessUnitEnvironment createBusinessUnitEnvironment(
			ReservedCardHistory pReservedCardHistory) {

		return new BusinessUnitEnvironmentImpl(pReservedCardHistory.getBuType(),
				pReservedCardHistory.getBuCode(), mUnits, mTimeSource,
				mBefFactory.getBefIpayBusinessUnits());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#
	 * createBusinessUnitEnvironment(java.lang.String, java.lang.String)
	 */
	public BusinessUnitEnvironment createBusinessUnitEnvironment(
			String pBuType, String pBuCode) {

		return new BusinessUnitEnvironmentImpl(pBuType, pBuCode, mUnits,
				mTimeSource,mBefFactory.getBefIpayBusinessUnits());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#getEbcEnvironment()
	 */
	public EbcEnvironment getEbcEnvironment() {
		return mEbcEnvironment;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#createVoLoadAmount()
	 */
	public VoLoadAmount createVoLoadAmount() {
		return new VoLoadAmount();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#getUnits()
	 */
	public Units getUnits() {
		return mUnits;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory#getCurrencies()
	 */
	public Currencies getCurrencies() {
		return mCurrenciesImpl;
	}

	public CountrySetups getCountrySetups() {
		return mCountrySetupsImpl;
	}

	public PriorityEvaluator createPriorityEvaluator() {
		if (mPriorityEvaluator == null) {
			mPriorityEvaluator = new DefaultPriorityEvaluator();
		}
		return mPriorityEvaluator;
	}
	public BefIpayBusinessUnits getBefIpayBusinessUnits() {
		return mBefIpayBusinessUnits;
	}
}