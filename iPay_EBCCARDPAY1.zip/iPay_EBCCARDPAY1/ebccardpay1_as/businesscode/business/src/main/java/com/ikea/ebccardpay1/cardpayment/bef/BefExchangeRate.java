/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefExchangeRate extends Bef<ExchangeRate>{

	public ExchangeRate findBySearch(String pFromCurrency, String pToCurrency, java.util.Date pLocalDate, long pCountryId);

	public java.util.List<ExchangeRate> findCurrent(long pCountryId);

}