package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;








import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalTempCard;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidAmountTypeException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidExternalSourceSystemException;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTemp;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTempOutput;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTempStatus;



public interface BecExternalTempCard {
	
	public BecExternalTempCard init(ExternalTempCard pExternalTempCard);
	
	public List<VoExternalCardTempOutput> importExternalCards(
			List<VoExternalCardTemp> pVoExternalCardTempList,VoExternalCardTempStatus pVoExternalCardTempStatus);

	public List<VoExternalCardTempOutput> createCardsAndTransfer(
			VoExternalCardTempStatus externalCardTempStatus);

	public List<VoExternalCardTempOutput> updateCardStatus(
			VoExternalCardTempStatus externalCardTempStatus);
	
	public boolean createOrUpdateSourceSystem(
			VoExternalCardSystem externalCardSystem) throws InvalidExternalSourceSystemException, InvalidCardNumberException, InvalidAmountTypeException;
}
