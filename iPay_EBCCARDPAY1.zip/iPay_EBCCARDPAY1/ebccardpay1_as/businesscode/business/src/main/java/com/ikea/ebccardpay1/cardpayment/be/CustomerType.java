package com.ikea.ebccardpay1.cardpayment.be;


import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;


public class CustomerType extends BusinessEntity {
	/**										
	 * Storage: CUSTOMER_TYPE_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private int mCustomerTypeId;

	/**										
	 * Common attributes	
	 */										
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;

	/**										
	 * Data								
	 */										
	private String mCustomerType;
	
	
	
	public int getCustomerTypeId() {
		return mCustomerTypeId;
	}

	public void setCustomerTypeId(int mCustomerTypeId) {
		this.mCustomerTypeId = mCustomerTypeId;
	}

	public String getCreatedBy() {
		return mCreatedBy;
	}

	public void setCreatedBy(String mCreatedBy) {
		this.mCreatedBy = mCreatedBy;
	}

	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	public void setCreatedDateTime(java.util.Date mCreatedDateTime) {
		this.mCreatedDateTime = mCreatedDateTime;
	}

	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	public void setUpdatedBy(String mUpdatedBy) {
		this.mUpdatedBy = mUpdatedBy;
	}

	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	public void setUpdatedDateTime(java.util.Date mUpdatedDateTime) {
		this.mUpdatedDateTime = mUpdatedDateTime;
	}

	

	public String getCustomerType() {
		return mCustomerType;
	}

	public void setCustomerType(String mCustomerType) {
		this.mCustomerType = mCustomerType;
	}

	
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mCustomerTypeId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("customerTypeId", CodeGeneration.toObject(mCustomerTypeId));
		vMap.put("customerType", CodeGeneration.toObject(mCustomerType));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	 /*(non-Javadoc)
	  @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)*/
	 
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("customerTypeId")) mCustomerTypeId = CodeGeneration.objectToInteger(pMap.get("customerTypeId"));
		if(pMap.containsKey("customerType")) mCustomerType = CodeGeneration.objectToString(pMap.get("customerType"));
	}


}

