package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.JobCreatorSchedule;
import com.ikea.common.TimeSource;

/**
 * @author Henrik Reinhold
 *
 */
public class BefJobCreatorScheduleImpl extends BefAbstract<JobCreatorSchedule> implements BefJobCreatorSchedule {

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefJobCreatorScheduleImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<JobCreatorSchedule> getBusinessEntityClass() {
		return JobCreatorSchedule.class;
	}
}
