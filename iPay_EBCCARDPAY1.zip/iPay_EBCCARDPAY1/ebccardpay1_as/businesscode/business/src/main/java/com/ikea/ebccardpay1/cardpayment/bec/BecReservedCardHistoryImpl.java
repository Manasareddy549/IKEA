package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.TransactionFilter;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransactionFilter;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebccardpay1.common.Amounts;
import com.ikea.ebccardpay1.common.Constants;
import com.ikea.ebcframework.services.EbcProperties;

@Component
public class BecReservedCardHistoryImpl implements BecReservedCardHistory, InitializingBean {

	private final static Logger mCategory = LoggerFactory.getLogger(BecReservedCardHistoryImpl.class);

	private BefReservedCardHistory mBefReservedCardHistory;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;
	private Constants mConstants = null;
	private BecFactory mBecFactory = null;
	private Card mCard;
	private Amount mAmount = null;
	private MassLoad mMassLoad = null;
	private EbcProperties mEbcProperties;
	private UtilsFactory mUtilsFactory;
	Collection<ReservedCardHistory> mReservedCardHistorys = null;
	ReservedCardHistory mReservedCardHistory = null;
	private BefTransactionFilter mBefTransactionFilter;
	private BefAmount mBefAmount=null;
	private BefReferenceCheck mBefReferenceCheck;

	/**
	 * Dependecy injection
	 * 
	 */

	protected BecReservedCardHistoryImpl(BefReservedCardHistory pBefReservedCardHistory, Constants pConstants,
			BecFactory pBecFactory, EbcProperties pEbcProperties, UtilsFactory pUtilsFactory,
			BefTransactionFilter pBefTransactionFilter, BefAmount pBefAmount, BefReferenceCheck pBefReferenceCheck) {

		mBefReservedCardHistory = pBefReservedCardHistory;
		mConstants = pConstants;
		mBecFactory = pBecFactory;
		mEbcProperties = pEbcProperties;
		mUtilsFactory = pUtilsFactory;
		mBefTransactionFilter = pBefTransactionFilter;
		mBefAmount = pBefAmount;
		mBefReferenceCheck = pBefReferenceCheck;
	}

	void validate() {
		notNull(mBefReservedCardHistory);
		notNull(mConstants);
		notNull(mBecFactory);
		notNull(mBecFactory);
	}

	public BecReservedCardHistory init(ReservedCardHistory pReservedCardHistory,
			BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment) {

		mReservedCardHistory = pReservedCardHistory;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReservedCardHistory#init(long)
	 */
	public BecReservedCardHistory init(long pTransactionNo) {

		initTransactions(mBefReservedCardHistory.findByTransactionNos(pTransactionNo));

		if (mReservedCardHistorys.size() > 0) {
			ReservedCardHistory vReservedCardHistory = (ReservedCardHistory) mReservedCardHistorys.iterator().next();
			initBusinessUnitEnvironment(mUtilsFactory.createBusinessUnitEnvironment(vReservedCardHistory));
		}
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#initTransactions
	 * (java.util.Collection)
	 */
	public BecReservedCardHistory initTransactions(Collection<ReservedCardHistory> pReservedCardHistorys) {

		mReservedCardHistorys = pReservedCardHistorys;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#init(com.ikea.
	 * ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */

	public BecReservedCardHistory init(Card pCard, Amount pAmount, BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mAmount = pAmount;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	public void createReservedTransaction(VoRequestAmount pVoRequestAmount, BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange, boolean pInsufficientAmount, String pCardNumberString, BigDecimal pRate)
			throws ValueMissingException {

		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();
		requireAmountIfNotZero(pCardBalanceChange);
		
		BigDecimal reservedBalance = new BigDecimal(0.0);
		ReservedCardHistory reservedCardHistory = mBefReservedCardHistory.create();
		reservedCardHistory.setOriginalUnAuthorizeAmount(pVoRequestAmount.getRequestAmount());
		reservedCardHistory.setCurrentAuthorizeAmount(reservedBalance);
		reservedCardHistory.setRemainingUnAuthorizeAmount(pVoRequestAmount.getRequestAmount());
		reservedCardHistory.setSourceSystem(mTransactionEnvironment.getSourceSystem());
		reservedCardHistory.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
		reservedCardHistory.setCancelled(false);
		reservedCardHistory.setBuType(mBusinessUnitEnvironment.getBuType());
		reservedCardHistory.setBuCode(mBusinessUnitEnvironment.getBuCode());
		reservedCardHistory.setEmployee(mTransactionEnvironment.getEmployee().trim());
		reservedCardHistory.setCountryCode(mBusinessUnitEnvironment.getCountryCode());
		reservedCardHistory.setTransactionNo(mTransactionEnvironment.getTransactionNo());
		reservedCardHistory.setPointOfSale(mTransactionEnvironment.getPointOfSale());
		reservedCardHistory.setReceipt(mTransactionEnvironment.getReceipt());
		reservedCardHistory.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
		reservedCardHistory.setReference(mTransactionEnvironment.getReference());
		reservedCardHistory.setReservedTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_RESERVED);
		reservedCardHistory.setCurrencyCode(pVoRequestAmount.getCurrencyCode());
		reservedCardHistory.setTotalAmount(pVoRequestAmount.getTotalAmount());
		reservedCardHistory.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
		reservedCardHistory.setSwiped(mTransactionEnvironment.getSwiped());
		reservedCardHistory.setCardBalanceChange(pCardBalanceChange);
		if(pRate != null) {
		reservedCardHistory.setExchangeRate(pRate);
		}
		String vCountryCode = mCard.getCountryCode();
		if (vCountryCode != null && !vCountryCode.equals(mBusinessUnitEnvironment.getCountryCode())) {
			reservedCardHistory.setCrossBorder(true);
		}
		if (pInsufficientAmount) {
			reservedCardHistory.setInsufficientAmount(true);
		}
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			reservedCardHistory.setCrossCurrency(true);
		}

		if (mCard != null) {
			reservedCardHistory.setCard(mCard);
		}
		/*
		 * if (pointOfSaleContext()) { // Use setCard and not connectCard - we do not
		 * want to read all transactions // into a set before inserting the new one if
		 * we do not have to. reservedCardHistory.setCard(mCard); }
		 */
		if (mAmount != null) {
			reservedCardHistory.setAmount(mAmount);
		}

		mCard.setLastTransactionDateTime(reservedCardHistory.getCreatedDateTime());

		mBefReservedCardHistory.save(reservedCardHistory);
	}
	
	protected void requireAmountIfNotZero(BigDecimal pAmount) throws ValueMissingException {
		if (pAmount != null && !Amounts.isZero(pAmount) && mAmount == null)
			throw new ValueMissingException(
					"Tried to use BecReservedCard without required Amount. Need to specify Amount if not a zero transaction.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException("Tried to use BecCard without required Card.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment() throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required BusinessUnitEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment() throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required TransactionEnvironment.");
	}

	/**
	 * @param pBusinessUnitEnvironment
	 * @return
	 */
	protected BecReservedCardHistory initBusinessUnitEnvironment(BusinessUnitEnvironment pBusinessUnitEnvironment) {

		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReservedCardHistorys#
	 * cancelReservedCardHistorys()
	 */
	public void cancelReservedCardHistorys() throws ValueMissingException, AmountException {

		requireTransactions();

		for (Iterator<ReservedCardHistory> i = mReservedCardHistorys.iterator(); i.hasNext();) {
			ReservedCardHistory vReservedCardHistory = (ReservedCardHistory) i.next();

			mCategory.info("Cancelling transaction no " + vReservedCardHistory.getTransactionNo() + " "
					+ vReservedCardHistory.getReservedTransactionType());

			// Check if a zero transactions (redemption of a card with balance
			// zero)
			if (vReservedCardHistory.getAmount() != null) {
				// Undo the transaction
				undoAmount(vReservedCardHistory);
			}

			// Mark ReservedCardHistory transaction
			BecReservedCardHistory vBecReservedCardHistory = mBecFactory.createBecReservedCardHistory()
					.init(vReservedCardHistory, mBusinessUnitEnvironment, mTransactionEnvironment);
			vBecReservedCardHistory.cancelTransaction();
		}
	}

	/**
	 * @param pTransaction
	 * @throws ValueMissingException
	 */
	protected void undoAmount(ReservedCardHistory pReservedCardHistory) throws ValueMissingException, AmountException {

		if (pReservedCardHistory.getAmount() == null
				&& Amounts.isZero(pReservedCardHistory.getRemainingUnAuthorizeAmount())) {
			// No amount connected to this transaction since it is a zero
			// tranaction. Just return.
			mCategory.info("No amount connected to reservedcardhistory id "
					+ pReservedCardHistory.getReservedHistoryId() + " skipping undo.");
			return;
		}

		BecAmount vBecAmount = mBecFactory.createBecAmount().init(null, pReservedCardHistory.getAmount(),
				mBusinessUnitEnvironment, mTransactionEnvironment);
		// Undo load or redeem transaction.
		if (Constants.TRANSACTION_TYPE_CONSTANT_RESERVED.equals(pReservedCardHistory.getReservedTransactionType())) {

			VoRedeemAmount vVoRedeemAmount = new VoRedeemAmount();
			vVoRedeemAmount.setRedeemAmount(pReservedCardHistory.getCardBalanceChange());
			mCategory.info("Undoing redeem of " + vVoRedeemAmount.getRedeemAmount());
			vBecAmount.undoRedeem(vVoRedeemAmount);
		} else {
			throw new IllegalStateException("Internal error: Transaction type "
					+ pReservedCardHistory.getReservedTransactionType() + " can not be canceled.");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#cancelTransaction()
	 */
	public void cancelTransaction() throws ValueMissingException {

		requireTransaction();

		// Set financial type to none so this transaction will not be included in KPI
		mReservedCardHistory.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_NONE);
		mReservedCardHistory.setCancelled(true);

		saveTransaction(mReservedCardHistory);
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactions() throws ValueMissingException {
		if (mReservedCardHistorys == null)
			throw new ValueMissingException("Tried to use BecReservedCardHistory without required Transactions.");
	}

	protected void requireTransaction() throws ValueMissingException {
		if (mReservedCardHistory == null)
			throw new ValueMissingException("Tried to use BecReservedCardHistory without required Transaction.");
	}

	/**
	 * 
	 * @param pReservedCardHistory
	 */
	protected void saveTransaction(ReservedCardHistory pReservedCardHistory) {

		if (mCategory.isInfoEnabled()) {
			mCategory.debug("Creating transaction no " + pReservedCardHistory.getTransactionNo() + " "
					+ pReservedCardHistory.getReservedTransactionType() + " "
					+ pReservedCardHistory.getRemainingUnAuthorizeAmount());
		}
		// We will explicitly call save here since we are not using connect due to
		// performance reasons.
		mBefReservedCardHistory.save(pReservedCardHistory);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub

	}

	protected boolean pointOfSaleContext() {
		return mTransactionEnvironment != null && mConstants.isPointOfSale(mTransactionEnvironment.getSourceSystem());
	}

	public Card createVoidAuthorizeRedeemTransaction(String pReference, String pSourceSystem,
			BusinessUnitEnvironment mBusinessUnitEnvironment, TransactionEnvironment mTransactionEnvironment,
			boolean pWaitingAck, boolean pManual) throws ValueMissingException, TransactionException {

		ReservedCardHistory vReservedCardHistory = mBefReservedCardHistory.findByRefrence(pReference);

		if (vReservedCardHistory == null) {
			throw new TransactionException("No transactions found to void");
		} else if (vReservedCardHistory.isCancelled()) {

			throw new TransactionException("Transaction is already cancelled");
		}
		// Check if this transaction has already been Voided.

		TransactionFilter vTransactionFilter = mBefTransactionFilter
				.findByTransactionNo(vReservedCardHistory.getTransactionNo());

		if (vTransactionFilter != null && vTransactionFilter.getVoided()) {
			throw new TransactionException("You can not void a transaction that has already been voided.");
		}
		if(vReservedCardHistory.getOriginalUnAuthorizeAmount().compareTo(vReservedCardHistory.getRemainingUnAuthorizeAmount())==0) {
		ReservedCardHistory reservedCardHistory = mBefReservedCardHistory.create();
		reservedCardHistory.setOriginalUnAuthorizeAmount(vReservedCardHistory.getOriginalUnAuthorizeAmount());
		reservedCardHistory.setCurrentAuthorizeAmount(BigDecimal.ZERO);
		reservedCardHistory.setRemainingUnAuthorizeAmount(BigDecimal.ZERO);
		reservedCardHistory.setSourceSystem(mTransactionEnvironment.getSourceSystem());
		reservedCardHistory.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
		reservedCardHistory.setCancelled(false);
		reservedCardHistory.setBuType(vReservedCardHistory.getBuType());
		reservedCardHistory.setBuCode(vReservedCardHistory.getBuCode());
		reservedCardHistory.setEmployee(mTransactionEnvironment.getEmployee().trim());
		reservedCardHistory.setCountryCode(vReservedCardHistory.getCountryCode());
		reservedCardHistory.setTransactionNo(mTransactionEnvironment.getTransactionNo());
		reservedCardHistory.setPointOfSale(vReservedCardHistory.getPointOfSale());
		reservedCardHistory.setReceipt(vReservedCardHistory.getReceipt());
		reservedCardHistory.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
		reservedCardHistory.setReference(mTransactionEnvironment.getReference());
		reservedCardHistory.setReservedTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_VOID_RESERVED);
		reservedCardHistory.setCurrencyCode(vReservedCardHistory.getCurrencyCode());
		reservedCardHistory.setTotalAmount(vReservedCardHistory.getTotalAmount());
		reservedCardHistory.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);
		reservedCardHistory.setSwiped(vReservedCardHistory.getSwiped());

		reservedCardHistory.setCrossBorder(vReservedCardHistory.isCrossBorder());

		reservedCardHistory.setInsufficientAmount(vReservedCardHistory.isInsufficientAmount());

		reservedCardHistory.setCrossCurrency(vReservedCardHistory.isCrossCurrency());

		reservedCardHistory.setCard(vReservedCardHistory.getCard());

		reservedCardHistory.setAmount(vReservedCardHistory.getAmount());
		
		String trnNo = ""+vReservedCardHistory.getTransactionNo();
		reservedCardHistory.setVoidedTransactionNo(trnNo);
		reservedCardHistory.setCardBalanceChange(BigDecimal.ZERO);
		if(vReservedCardHistory.getExchangeRate() != null) {
		
			reservedCardHistory.setExchangeRate(vReservedCardHistory.getExchangeRate());
		}
		
		
		mBefReservedCardHistory.save(reservedCardHistory);
		
		vReservedCardHistory.setRemainingUnAuthorizeAmount(BigDecimal.ZERO);
		vReservedCardHistory.setCardBalanceChange(BigDecimal.ZERO);
		mBefReservedCardHistory.save(vReservedCardHistory);
		
		//updated current amount (currentAmount + reverseAmount)
		Amount amount = mBefAmount.findByAmountId(vReservedCardHistory.getAmount().getAmountId());
		
		if(vReservedCardHistory.isCrossCurrency() && vReservedCardHistory.getExchangeRate() != null) {
		amount.setCurrentAmount(amount.getCurrentAmount().add(vReservedCardHistory.getOriginalUnAuthorizeAmount().multiply(vReservedCardHistory.getExchangeRate())));
		}else if(!reservedCardHistory.isCrossCurrency() && reservedCardHistory.getExchangeRate() == null){
			amount.setCurrentAmount(amount.getCurrentAmount().add(vReservedCardHistory.getOriginalUnAuthorizeAmount()));
		}else {
			throw new TransactionException("Cross currency is set to "+vReservedCardHistory.isCrossCurrency() + " and exchange rate is set to "+ vReservedCardHistory.getExchangeRate());
		}

		mBefAmount.save(amount);
		

		if(pWaitingAck) {
			ReferenceCheck vReferenceCheck =
					//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
					mBefReferenceCheck.findByReference(pReference, pSourceSystem);
			
			vReferenceCheck.setWaitingAck(false);
			mBefReferenceCheck.save(vReferenceCheck);
		}
		
		
					
					// Create new reference
					ReferenceCheck referenceCheck = mBefReferenceCheck.create();
					referenceCheck.setWaitingAck(false);
					referenceCheck.setReference(mTransactionEnvironment.getReference());
					referenceCheck.setSourceSystem(mTransactionEnvironment.getSourceSystem());
					referenceCheck.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

					// Set info for identifi�ing the receipt
					referenceCheck.setBuType(vReservedCardHistory.getBuType());
					referenceCheck.setBuCode(vReservedCardHistory.getBuCode());

					referenceCheck.setPointOfSale(vReservedCardHistory.getPointOfSale());
					
					referenceCheck.setReceipt(vReservedCardHistory.getReceipt());
					

					referenceCheck.setTransactionNo(reservedCardHistory.getTransactionNo());
					referenceCheck.setCard(reservedCardHistory.getCard());
					referenceCheck.setAckTimeout(0);
					
					mBefReferenceCheck.save(referenceCheck);
					
					
					// Create a transaction filter on the original transaction
					TransactionFilter transactionFilter = mBefTransactionFilter
							.create();
					transactionFilter.setVoided(true);
					transactionFilter.setTransactionNo(vReservedCardHistory.getTransactionNo());
					mBefTransactionFilter.save(transactionFilter);
					
		return vReservedCardHistory.getCard();
		}else {
			throw new TransactionException("Transaction is partially authorized so void not allowed");
		}
		
	}
}
