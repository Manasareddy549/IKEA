/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;
import static org.apache.commons.lang.Validate.notNull;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.be.MainCurrency;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountry;
import com.ikea.ebccardpay1.cardpayment.exception.CountryException;
import com.ikea.ebccardpay1.cardpayment.exception.CountryNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountryKey;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;
import com.ikea.common.TimeSource;
import com.ikea.mdsd.ValueObjects;

/**
 * @author dalq
 * 
 * 
 */
public class BecCountryImpl implements BecCountry {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecCountryImpl.class);

	// Entities that this BEC operates on
	private Country mCountry;
	private VoCountry mVoCountry;
	private List<VoMainCurrency> mVoMainCurrencyList;
	private List<VoExchangeRate> mVoExchangeRatesList;

	// Dependencies injected at creation of this BEC
	private TimeSource mTimeSource = null;
	private Units mUnits;
	private BefCountry mBefCountry = null;
	private BecMainCurrencies mBecMainCurrencies = null;
	private BecExchangeRates mBecExchangeRates = null;

	/**
	 * 
	 * @param pBefCountry
	 * @param pTimeSource
	 * @param pUnits
	 * @param pBecMainCurrencies
	 * @param pBecExchangeRates
	 */
	public BecCountryImpl(BefCountry pBefCountry, TimeSource pTimeSource,
			Units pUnits, BecMainCurrencies pBecMainCurrencies,
			BecExchangeRates pBecExchangeRates) {

		mBefCountry = pBefCountry;
		mTimeSource = pTimeSource;
		mUnits = pUnits;
		mBecMainCurrencies = pBecMainCurrencies;
		mBecExchangeRates = pBecExchangeRates;
	}
	
	void validate() {
		notNull(mBefCountry);
		notNull(mTimeSource);
		notNull(mUnits);
		notNull(mBecMainCurrencies);
		notNull(mBecExchangeRates);
				
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#init(com.ikea.ebccardpay1
	 * .cardpayment.vo.VoCountry)
	 */
	public BecCountry init(VoCountry pVoCountry) throws ValueMissingException {
		// requireCountry();
		// ValueObjects.assignToBusinessEntity(mCountry, pVoCountry);
		mVoCountry = pVoCountry;
		return this;

	}

	public BecCountry init(List<VoMainCurrency> pVoMainCurrencyList,
			List<VoExchangeRate> pVoExchangeRatesList)
			throws ValueMissingException {
		mVoMainCurrencyList = pVoMainCurrencyList;
		mVoExchangeRatesList = pVoExchangeRatesList;
		return this;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Country)
	 */
	public BecCountry init(Country pCountry) {
		mCountry = pCountry;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#findCountry(java.lang
	 * .String)
	 */
	public void findCountry(String pCountryCode)
			throws CountryNotFoundException {

		// Lookup country
		mCountry = mBefCountry.findByCountryCode(pCountryCode);

		if (mCountry == null) {
			throw new CountryNotFoundException("Country '" + pCountryCode
					+ "' is not enabled for exchange.");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#findExchangeRateCountry
	 * (com.ikea.ebccardpay1.cardpayment.vo.VoCountryKey)
	 */
	public void findCountry(VoCountryKey pCountryKey) {

		mCountry = mBefCountry.findByPrimaryKey(pCountryKey.getCountryId());

	}

	public Country getCountry() {
		return mCountry;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountry#getVoCountry()
	 */
	public VoCountry getVoCountry() throws ValueMissingException {
		requireCountry();

		VoCountry vVoCountry = new VoCountry();
		// Set MainCurrency closest to current UTC time.
		calculateAndSetMainCurrencyNow(vVoCountry);

		ValueObjects.assignToValueObject(vVoCountry, mCountry);
		mCategory.debug("Added Country " + vVoCountry.getCountryCode() + " "
				+ vVoCountry.getExchangeMode());

		return vVoCountry;
	}

	public VoCountry getVoCountrySubs() throws ValueMissingException {
		VoCountry vVoCountry = new VoCountry();
		// Set MainCurrency closest to current UTC time.
		calculateAndSetMainCurrencyNow(vVoCountry);

		ValueObjects.assignToValueObject(vVoCountry, mCountry);
		mCategory.debug("Added Country " + vVoCountry.getCountryCode() + " "
				+ vVoCountry.getExchangeMode());

		vVoCountry.setVoMainCurrencyList(mVoMainCurrencyList);
		vVoCountry.setVoExchangeRateList(mVoExchangeRatesList);

		return vVoCountry;

	}

	/**
	 * @param pVoCountry
	 */
	protected void calculateAndSetMainCurrencyNow(VoCountry pVoCountry) {
		Set<MainCurrency> vMainCurrencies = mCountry.getMainCurrencies();
		int vCounter = 1;

		if (vMainCurrencies != null) {
			Date vDate = new Date();
			Date vLastDate = new Date();
			vLastDate = null;
			// FromDate not earlier than today (without time)

			Date currentDate = Dates.withoutTime(new DateTime(mTimeSource
					.currentDate()));

			for (Iterator<MainCurrency> i = vMainCurrencies.iterator(); i
					.hasNext();) {
				MainCurrency vMainCurrency = (MainCurrency) i.next();
				// Get FromDate from list
				vDate = vMainCurrency.getFromDate();

				if (vCounter == 1 || vLastDate == null) {
					if ((vDate.before(currentDate))
							|| (vDate.compareTo(currentDate) == 0)) {
						vLastDate = vDate;
						pVoCountry.setMainCurrencyNow(vMainCurrency
								.getCurrencyCode());

						mCategory.info("Found first MainCurrency: "
								+ vMainCurrency.getCurrencyCode() + " Date:"
								+ vMainCurrency.getFromDate().toString());
					}
				} else {

					// Set the date most close to current date but not date in
					// the future -
					if (vDate.after(vLastDate)
							&& (vDate.before(currentDate) || vDate
									.compareTo(currentDate) == 0)) {
						// Found more current date
						vLastDate = vDate;
						pVoCountry.setMainCurrencyNow(vMainCurrency
								.getCurrencyCode());

						mCategory.info("Found more current MainCurrency: "
								+ vMainCurrency.getCurrencyCode() + " Date:"
								+ vMainCurrency.getFromDate().toString());
					}
				}

				vCounter++;
			}

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#getVoCountryComplete()
	 */
	public VoCountry getVoCountryComplete() throws ValueMissingException {
		requireCountry();

		// Collect VoCountry object
		VoCountry vVoCountry = getVoCountry();

		// Collect current exchange rates for country
		List<ExchangeRate> vExchangeRates = mBecExchangeRates
				.findCurrentExchangeRates(mCountry.getCountryId());

		// ExchangeRate handling
		List<VoExchangeRate> vVoExchangeRatesList = mBecExchangeRates
				.getVoExchangeRateList(vExchangeRates);

		// Set ExchangeRateStatus to enable different colour
		createStatus(vVoExchangeRatesList);

		// Set ExchangeRateList in VO
		vVoCountry.setVoExchangeRateList(vVoExchangeRatesList);

		// MainCurrency handling
		List<VoMainCurrency> vVoMainCurrencyList = new ArrayList<VoMainCurrency>();

		Set<MainCurrency> vMainCurrencies = mCountry.getMainCurrencies();

		for (Iterator<MainCurrency> i = vMainCurrencies.iterator(); i.hasNext();) {
			MainCurrency vMainCurrency = (MainCurrency) i.next();
			VoMainCurrency vVoMainCurrency = new VoMainCurrency();
			ValueObjects.assignToValueObject(vVoMainCurrency, vMainCurrency);
			vVoMainCurrencyList.add(vVoMainCurrency);
			mCategory.info("Added VOMainCurrency to VoCountry CurrencyCode: "
					+ vVoMainCurrency.getCurrencyCode() + " Rate:"
					+ vVoMainCurrency.getFromDate());

		}
		// Set MainCurrencyList in VO
		vVoCountry.setVoMainCurrencyList(vVoMainCurrencyList);

		return vVoCountry;
	}

	/**
	 * Finds out which of the collected exchange rates that are current
	 * 
	 * @param pExchangeRates
	 * @return List of exchangerates with status flag added
	 */
	protected List<VoExchangeRate> createStatus(
			List<VoExchangeRate> pExchangeRates) {
		HashMap<String, VoExchangeRate> vHashMap = new HashMap<String, VoExchangeRate>();

		// Get current date
		Date currentDate = Dates.withoutTime(new DateTime(mTimeSource
				.currentDate()));

		// Loop through exchanges rate to find out which ones that are current
        for(VoExchangeRate vVoExchangeRate : pExchangeRates){

			// Check if the from-to rate exist
			if (vHashMap.containsKey(vVoExchangeRate.getFromCurrencyCode()
					+ vVoExchangeRate.getToCurrencyCode())) {
				// Get fromDate for a specific from-to rate
				VoExchangeRate tmpVoExchangeRates = (VoExchangeRate) vHashMap
						.get(vVoExchangeRate.getFromCurrencyCode()
								+ vVoExchangeRate.getToCurrencyCode());
				// Set the date closest to todays date as current currency
				if (vVoExchangeRate.getFromDate().after(
						tmpVoExchangeRates.getFromDate())
						&& (vVoExchangeRate.getFromDate().before(currentDate) || vVoExchangeRate
								.getFromDate().compareTo(currentDate) == 0)) {

					// Set new current currency
					vHashMap.put(vVoExchangeRate.getFromCurrencyCode()
							+ vVoExchangeRate.getToCurrencyCode(),
							vVoExchangeRate);
				}

			} else { // new from-to rate
				// Only set current currency if it not in future
				if ((vVoExchangeRate.getFromDate().before(currentDate))
						|| (vVoExchangeRate.getFromDate()
								.compareTo(currentDate) == 0)) {
					vHashMap.put(vVoExchangeRate.getFromCurrencyCode()
							+ vVoExchangeRate.getToCurrencyCode(),
							vVoExchangeRate);
				}
			}
		}
		return setExchangeRateStatus(vHashMap, pExchangeRates);
	}

	/**
	 * 
	 * @param pCurrent
	 * @param pExchangeRates
	 * @return A list with the correct status set for each exchange rate, PAST
	 *         CURRENT or FUTURE
	 */
	protected List<VoExchangeRate> setExchangeRateStatus(
			HashMap<String, VoExchangeRate> pCurrent,
			List<VoExchangeRate> pExchangeRates) {

		// Get current date without time
		Date currentDate = Dates.withoutTime(new DateTime(mTimeSource
				.currentDate()));

		List<VoExchangeRate> vVoExchangeRateList = new ArrayList<VoExchangeRate>();

		// Iterate once more to set the status constant in ExchangeRateStatus
		for(VoExchangeRate vVoExchangeRate : pExchangeRates){
			VoExchangeRate vCurrentVoExchangeRate = (VoExchangeRate) pCurrent
					.get(vVoExchangeRate.getFromCurrencyCode()
							+ vVoExchangeRate.getToCurrencyCode());

			if ((vCurrentVoExchangeRate != null)
					&& vVoExchangeRate.getExchangeRateId() == vCurrentVoExchangeRate
							.getExchangeRateId()) {
				vVoExchangeRate
						.setExchangeRateStatus(Constants.EXCHANGE_RATE_STATE_CURRENT);
				mCategory.info("ExchangeRateStatus set for "
						+ vVoExchangeRate.getExchangeRateId() + " Status = "
						+ vVoExchangeRate.getExchangeRateStatus());
			} else if (vVoExchangeRate.getFromDate().after(currentDate)) {
				vVoExchangeRate
						.setExchangeRateStatus(Constants.EXCHANGE_RATE_STATE_FUTURE);
				mCategory.info("ExchangeRateStatus set for "
						+ vVoExchangeRate.getExchangeRateId() + " Status = "
						+ vVoExchangeRate.getExchangeRateStatus());

			} else {
				vVoExchangeRate
						.setExchangeRateStatus(Constants.EXCHANGE_RATE_STATE_PAST);
				mCategory.info("ExchangeRateStatus set for "
						+ vVoExchangeRate.getExchangeRateId() + " Status = "
						+ vVoExchangeRate.getExchangeRateStatus());
			}

			vVoExchangeRateList.add(vVoExchangeRate);

		}

		return vVoExchangeRateList;

	}

	/**
	 * @param vVoCountry
	 */
	protected void updateCountry(VoCountry vVoCountry) throws CountryException,
			ValueMissingException {

		// Check values
		checkValues(vVoCountry.getCountryCode(), vVoCountry.getExchangeMode());

		mCategory.info("Update Country - countryCode:"
				+ vVoCountry.getCountryCode());

		// Find Country in dB
        VoCountryKey voCountryKey = new VoCountryKey();
        voCountryKey.setCountryId(vVoCountry.getCountryId());
		findCountry(voCountryKey);

		// Assign new values from VO to entity
		ValueObjects.assignToBusinessEntity(mCountry, vVoCountry);

		mBefCountry.save(mCountry);

	}

	/**
	 * @param vVoCountry
	 */
	protected void createCountry(VoCountry vVoCountry) throws CountryException,
			ValueMissingException {

		checkValues(vVoCountry.getCountryCode(), vVoCountry.getExchangeMode());

		mCategory.info("Create new Country - countryCode:"
				+ vVoCountry.getCountryCode());

		// Create new Country
		mCountry = mBefCountry.create();

		// Assign to VO to Entity
		ValueObjects.assignToBusinessEntity(mCountry, vVoCountry);

		// Save Country
		mBefCountry.save(mCountry);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountry#findOrCreate(com.ikea
	 * .ebccardpay1.cardpayment.vo.VoCountry)
	 */
	public void manage(VoCountry pVoCountry) throws CountryException,
			ValueMissingException {
		if (Constants.OBJECT_STATE_NEW.equals(pVoCountry.getObjectState())) {
			createCountry(pVoCountry);
		} else if (Constants.OBJECT_STATE_MODIFIED.equals(pVoCountry
				.getObjectState())) {
			updateCountry(pVoCountry);
		} else if (Constants.OBJECT_STATE_READ.equals(pVoCountry
				.getObjectState())) {
			// Sub entities are changed
			updateCountry(pVoCountry);
		} else {
			throw new ValueMissingException(
					"Illegal Object State set! Can not handle '"
							+ pVoCountry.getObjectState() + "'.");
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountry#manageAll()
	 */
	public void manageAll() throws InvalidFromDateException,
			InvalidFromCurrencyException, InvalidToCurrencyException,
			ValueMissingException {
		requireVoCountry();
        VoCountryKey voCountryKey = new VoCountryKey();
        voCountryKey.setCountryId(mVoCountry.getCountryId());
		findCountry(voCountryKey);

		// Alse manage changes of VoCountry
		// manage(mVoCountry);

		// Process the subentities for Country

		// Handle insert, update, delete for List<VoMainCurrency>
		mBecMainCurrencies.init(mVoCountry.getVoMainCurrencyList());
		mBecMainCurrencies.init(mVoCountry);
		mBecMainCurrencies.manage();
		mVoCountry.setVoMainCurrencyList(mBecMainCurrencies
				.getMainCurrencyList());

		// Handle insert, update, delete for ExchangeRates
		mBecExchangeRates.init(mVoCountry.getVoExchangeRateList());
		mBecExchangeRates.init(mVoCountry);
		mBecExchangeRates.manage();
		mVoCountry.setVoExchangeRateList(mBecExchangeRates
				.getVoExchangeRateList());

		// Initialize the sub VO
		init(mBecMainCurrencies.getMainCurrencyList(), mBecExchangeRates
				.getVoExchangeRateList());

	}

	/**
	 * 
	 */
	protected void checkValues(String pCountryCode, String pExchangeMode)
			throws ValueMissingException, CountryException {

		if ((pCountryCode == null) || (pCountryCode.length() == 0)) {
			throw new CountryException("The country code must not be empty.");
		}

		mUnits.checkValidCountryCode(pCountryCode);
		if (pExchangeMode == null || pExchangeMode.equals("")) {
			throw new ValueMissingException("'No exchange mode set'.");
		}

	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCountry() throws ValueMissingException {
		if (mCountry == null)
			throw new ValueMissingException(
					"Tried to use BecCountry without required Country.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireVoCountry() throws ValueMissingException {
		if (mVoCountry == null)
			throw new ValueMissingException(
					"Tried to use BecCountry without required VoCountry.");
	}

}
