/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class AuthorizationException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4503371327011489043L;

	public AuthorizationException() {
		super();
	}
	public AuthorizationException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidAuthorization();
	}
}
