package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

public interface BefReservedCardHistory extends Bef<ReservedCardHistory> {

	public ReservedCardHistory findByTransactionNo(long pTransactionNo);
	public List<ReservedCardHistory> findByTransactionNos(long pTransactionNo);
	public List<ReservedCardHistory> getCurrentAuthorizeAmountList(Card card);
	public ReservedCardHistory findByRefrence(String refrence);
}
