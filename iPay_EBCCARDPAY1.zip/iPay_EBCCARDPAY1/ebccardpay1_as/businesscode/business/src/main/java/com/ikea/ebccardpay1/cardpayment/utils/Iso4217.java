package com.ikea.ebccardpay1.cardpayment.utils;

public class Iso4217 {

	String mCountryName;
	String mCurrencyName;
	String mCurrencyCode;
	int mDecimals;
	String mCountryCode;

	public Iso4217(String pCountryCode, String pCountryName,
			String pCurrencyName, String pCurrencyCode) {

		this(pCountryCode, pCountryName, pCurrencyName, pCurrencyCode, 2);
	}

	public Iso4217(String pCountryCode, String pCountryName,
			String pCurrencyName, String pCurrencyCode, int pDecimals) {

		mCountryName = pCountryName;
		mCurrencyName = pCurrencyName;
		mCurrencyCode = pCurrencyCode;
		mDecimals = pDecimals;
		mCountryCode = pCountryCode;

	}

}
