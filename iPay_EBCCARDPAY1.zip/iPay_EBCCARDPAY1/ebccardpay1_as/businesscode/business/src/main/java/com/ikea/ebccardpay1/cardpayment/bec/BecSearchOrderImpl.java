package com.ikea.ebccardpay1.cardpayment.bec;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.NoCardsAttachedException;
import com.ikea.ebccardpay1.cardpayment.exception.WrongOrderException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardEntry;
import com.ikea.ebccardpay1.cardpayment.vo.VoSearchOrder;

public class BecSearchOrderImpl implements BecSearchOrder{

	private final static String ORDER_NUMBER_REGEXP ="^[0-9]{9,10}$";

	@Autowired
	private BefTransaction mBefTransaction;

	@Autowired
	private BecCardNumberImpl mBecCardNumber;


	@Override
	public List<VoCardEntry> searchOrder(VoSearchOrder pVoSearchOrder) throws WrongOrderException, NoCardsAttachedException {
		// TODO Auto-generated method stub

		String mReciept=validateOrderNumber(pVoSearchOrder.getOrderNumber());
		
		String mBuType=pVoSearchOrder.getBuType();
		String mBuCode=pVoSearchOrder.getBuCode();
		String mSalesDay=null;
		if(pVoSearchOrder.getSalesDate()!=null)
		{
			mSalesDay=validateDate(pVoSearchOrder.getSalesDate());
		}
		

		List<Transaction> mTransactionList= mBefTransaction.findByReciept(mReciept, mBuType, mBuCode, mSalesDay);
		if(mTransactionList.size()<1)
		{
			throw new NoCardsAttachedException();
		}
		
		List<VoCardEntry> mVoCardEntryList= new ArrayList<VoCardEntry>();
		Set<String> mSet = new HashSet<String>();
		for(Transaction mTransaction:mTransactionList)
		{
			
			String icard=mBecCardNumber.composeCardNumberString(mTransaction.getCard().getCardNumber());
			mSet.add(icard);

		}
		
		for(String icard:mSet)
		{
			VoCardEntry mVoCardEntry= new VoCardEntry();
			mVoCardEntry.setCardNumberString(icard);
			mVoCardEntryList.add(mVoCardEntry);
		}
		
		return mVoCardEntryList;

	}

	private String validateDate(Date pDate)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		sdf.setLenient(false);


		return sdf.format(pDate);


	}

	private String validateOrderNumber(long pOrder) throws WrongOrderException
	{
		String mReciept=Long.toString(pOrder); 
		if(mReciept.matches(ORDER_NUMBER_REGEXP))
		{
			return mReciept;
		}
		else{
			throw new WrongOrderException(); 
		}
	}




}
