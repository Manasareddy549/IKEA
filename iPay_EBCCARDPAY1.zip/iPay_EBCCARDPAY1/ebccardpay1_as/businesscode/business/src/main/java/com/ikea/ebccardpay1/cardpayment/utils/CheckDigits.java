package com.ikea.ebccardpay1.cardpayment.utils;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

/**
 */
public class CheckDigits {

	/**
	 * Generates a valid check digit using Luhn (a.k.a Mod 10) formula. 
	 * @param pNumberWithoutCheck the number without the check digit
	 * @return
	 */
	public static int getValidCheckDigit(String pNumberWithoutCheck) {

		int sum = 0;
		int nDigits = pNumberWithoutCheck.length();
		int parity = nDigits % 2;
		for (int i = 0; i < nDigits; i++) {

			int digit = Integer.parseInt("" + pNumberWithoutCheck.charAt(i));
			if (!(i % 2 == parity)) {
				// It is a digit on a an ODD index (1,3,5,7,9,...) from the end, then multiplicate with 2.
				digit = digit * 2;
			}
			if (digit > 9) {
				// The digit is more then two digits, then reduce 9
				digit = digit - 9;
			}
			sum += digit;

		}
		sum = sum % 10;
		if (sum > 0)
			sum = 10 - sum;
		return sum;
	}

	/**
	 * Validates if it is a valid number using Luhn (a.k.a Mod 10) formula. 
	 * @param pNumberWithCheck the number including the check digit
	 * @return
	 */
	public static boolean isValidCheckDigit(String pNumberWithCheck) {

		int sum = 0;
		int nDigits = pNumberWithCheck.length();
		int parity = nDigits % 2;
		for (int i = 0; i < nDigits; i++) {

			int digit = Integer.parseInt("" + pNumberWithCheck.charAt(i));
			if (i % 2 == parity) {
				// It is a digit on a an ODD index (1,3,5,7,9,...) from the end, then multiplicate with 2.
				digit = digit * 2;
			}
			if (digit > 9) {
				// The digit is more then two digits, then reduce 9
				digit = digit - 9;
			}
			sum += digit;

		}
		return (sum % 10) == 0;
	}

	/**
	 * @param pMax
	 * @return
	 */
	public static final int randomInt(int pMax) {
		return new Double(Math.random() * pMax).intValue();
	}

	/**
	 * @param pFromCardNumberString
	 * @param pUntilCardNumberString
	 * @return
	 */
	public static final String[] generateCardNumbers(
		String pFromCardNumberString,
		String pUntilCardNumberString) {

		if (!isValidCheckDigit(pFromCardNumberString)) {
			throw new RuntimeException("Not correct check digit! Internal error.");
		}
		if (!CheckDigits.isValidCheckDigit(pUntilCardNumberString)) {
			throw new RuntimeException("Not correct check digit! Internal error.");
		}

		String vFromCardNumberStringNC =
			pFromCardNumberString.substring(
				0,
				pFromCardNumberString.length() - 1);
		long vRawFromCardNumber = Long.parseLong(vFromCardNumberStringNC);

		String vUntilCardNumberStringNC =
			pUntilCardNumberString.substring(
				0,
				pUntilCardNumberString.length() - 1);
		long vRawUntilCardNumber = Long.parseLong(vUntilCardNumberStringNC);

		List<String> vList = new LinkedList<String>();
		for (long i = vRawFromCardNumber; i <= vRawUntilCardNumber; i++) {

			String vCardNumber = "" + i + getValidCheckDigit("" + i);

			if (!isValidCheckDigit(vCardNumber)) {
				throw new RuntimeException("Not correct check digit! Internal error.");
			}

			vList.add(vCardNumber);
		}

		return (String[]) vList.toArray(new String[1]);
	}

	/**
	 * @param pAmount
	 * @return
	 */
	public static final String generateAuthorizationNumber(String pAmount) {

		int[] vRot = { 2, 3, 4, 5, 6, 7, 8, 9, 0, 1 };

		StringBuffer vNumber = new StringBuffer();

		// ROT13 shift all digits
		for (int i = 0; i < pAmount.length(); i++) {
			char vCh = pAmount.charAt(i);
			if (vCh >= '0' && vCh <= '9') {
				vNumber.append(vRot[vCh - '0']);
			}
		}

		// Add or truncate to 4 digits
		if (vNumber.length() > 4) {
			vNumber.setLength(4);
		} else if (vNumber.length() < 4) {
			while (vNumber.length() < 4) {
				vNumber.insert(0, randomInt(9));
			}
		}

		// Append check digit
		vNumber.append(getValidCheckDigit(vNumber.toString()));

		return vNumber.toString();
	}

	/**
	 * 
	 * @return randomized authorizationnumber as String 5digits
	 */
	public static final String generateAuthorizationNumber() {

		StringBuffer vNumber = new StringBuffer();

		// Randomize 4 digits to get unique authorizenumber
		if (vNumber.length() > 4) {
			vNumber.setLength(4);
		} else if (vNumber.length() < 4) {
			while (vNumber.length() < 4) {
				vNumber.insert(0, randomInt(9));
			}
		}

		// Append check digit
		vNumber.append(getValidCheckDigit(vNumber.toString()));

		return vNumber.toString();
	}
}
