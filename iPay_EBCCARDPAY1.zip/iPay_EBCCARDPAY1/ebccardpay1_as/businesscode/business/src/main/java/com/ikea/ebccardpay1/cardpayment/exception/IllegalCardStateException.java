/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author anms
 */
public class IllegalCardStateException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5067049831372319807L;
	public IllegalCardStateException() {
		super();
	}
	public IllegalCardStateException(String pMessage) {
		super(pMessage);
	}
	
}
