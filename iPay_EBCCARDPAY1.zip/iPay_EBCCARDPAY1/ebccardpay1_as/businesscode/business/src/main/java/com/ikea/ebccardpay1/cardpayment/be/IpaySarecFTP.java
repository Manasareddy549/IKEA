package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

/**
 * @author moans1
 *
 */
public class IpaySarecFTP extends BusinessEntity {
	/**										
	 * Storage: IPAY_SAREC_FTP_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mSarecId;
	
	/**										
	 * Data								
	 */		
	private String mSarecServer;
	private String mSarecUser;
	private String mSarecPassword;
	private int mSarecPort;
	private String mSarecPrivateKeyFile;
	private String mSarecFTPLocation;
	private String mSarecDecommission;
	
	

	/**										
	 * Common attributes	
	 */		
	private int mVersionNo;
	private java.util.Date mCreatedDateTime;
	private java.util.Date mUpdatedDateTime;
	private String mCreatedBy;
	private String mUpdatedBy;
	
	/**
	 * @return Returns the reportId
	 */
	public long getSarecId() {
		return mSarecId;
	}

	/**
	 * @param sarecId The sarecId to set
	 */
	public void setSarecId(long pSarecId) {
		mSarecId = pSarecId;
	}

	/**
	 * @return Returns the sarecServer
	 */
	public String getSarecServer() {
		return mSarecServer;
	}

	/**
	 * @param sarecServer The sarecServer to set
	 */
	public void setSarecServer(String pSarecServer) {
		mSarecServer = pSarecServer;
	}

	/**
	 * @return Returns the sarecUser
	 */
	public String getSarecUser() {
		return mSarecUser;
	}

	/**
	 * @param sarecUser The sarecUser to set
	 */
	public void setSarecUser(String pSarecUser) {
		mSarecUser = pSarecUser;
	}

	/**
	 * @return Returns the sarecPassword
	 */
	public String getSarecPassword() {
		return mSarecPassword;
	}

	/**
	 * @param sarecPassword The sarecPassword to set
	 */
	public void setSarecPassword(String pSarecPassword) {
		mSarecPassword = pSarecPassword;
	}

	/**
	 * @return Returns the sarecPort
	 */
	public int getSarecPort() {
		return mSarecPort;
	}

	/**
	 * @param sarecPort The sarecPort to set
	 */
	public void setSarecPort(int pSarecPort) {
		mSarecPort = pSarecPort;
	}
	
	/**
	 * @return Returns the sarecPrivateKeyFile
	 */
	public String getSarecPrivateKeyFile() {
		return mSarecPrivateKeyFile;
	}

	/**
	 * @param sarecPrivateKeyFile The sarecPrivateKeyFile to set
	 */
	public void setSarecPrivateKeyFile(String pSarecPrivateKeyFile) {
		mSarecPrivateKeyFile = pSarecPrivateKeyFile;
	}

	/**
	 * @return Returns the sarecFTPLocation
	 */
	public String getSarecFTPLocation() {
		return mSarecFTPLocation;
	}

	/**
	 * @param sarecFTPLocation The sarecFTPLocation to set
	 */
	public void setSarecFTPLocation(String pSarecFTPLocation) {
		mSarecFTPLocation = pSarecFTPLocation;
	}
	
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**
	 * @return Returns the createdDateTime
	 */
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	/**
	 * @param createdDateTime The createdDateTime to set
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**
	 * @return Returns the updatedDateTime
	 */
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	/**
	 * @param updatedDateTime The updatedDateTime to set
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/**
	 * @return Returns the createdBy
	 */
	public String getCreatedBy() {
		return mCreatedBy;
	}

	/**
	 * @param createdBy The createdBy to set
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**
	 * @return Returns the updatedBy
	 */
	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	/**
	 * @param updatedBy The updatedBy to set
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}
	
	public String getSarecDecommission() {
		return mSarecDecommission;
	}

	public void setSarecDecommission(String pSarecDecommission) {
		mSarecDecommission = pSarecDecommission;
	}

}
