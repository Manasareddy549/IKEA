/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadFilter;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadSearch;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 *
 */
public class BecMassLoadsImpl implements BecMassLoads {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecMassLoadsImpl.class);

	// Dependencies injected at creation of this BEC
	private BecMassLoad mBecMassLoad;
	private BefMassLoad mBefMassLoad;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;
	private VoMassLoadFilter mVoMassLoadFilter;

	// Entities that this BEC operates on

	// Related Bec's that this Bec delegates work to

	/**
	 * 
	 */
	public BecMassLoadsImpl(
		BecMassLoad pBecMassLoad,
		BefMassLoad pBefMassLoad) {
		super();

		mBecMassLoad = pBecMassLoad;
		mBefMassLoad = pBefMassLoad;
	}

	void validate() {
		notNull(mBecMassLoad);
		notNull(mBefMassLoad);
	}
	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads#init(com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment)
	 */
	public BecMassLoads init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads#init(com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadFilter)
	 */
	public BecMassLoads init(VoMassLoadFilter pVoMassLoadFilter) {

		mVoMassLoadFilter = pVoMassLoadFilter;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads#findCurrentMassLoads()
	 */
	public List<VoMassLoad> findCurrentMassLoads()
		throws IkeaException, ValueMissingException {

		List<VoMassLoad> vVoList = new ArrayList<VoMassLoad>();
		List<MassLoad> vList;

		// MassLoad view filtered by massLoad state. Input from client.
		if (mVoMassLoadFilter != null
			&& mVoMassLoadFilter.getMassLoadState() != null
			&& !mVoMassLoadFilter.getMassLoadState().equals("")) {
			mCategory.info(
				"Filter parameter received state = "
					+ mVoMassLoadFilter.getMassLoadState());
			vList =
				mBefMassLoad.findByCurrentFilter(
					countryCodeForUser(),
					mVoMassLoadFilter.getMassLoadState());
		} else {
			mCategory.info("No filter parameter, collect all posts");
			// Get Mass Load for the logged in users country without filter.SLOW!!!
			vList = mBefMassLoad.findByCurrent(countryCodeForUser());
		}
		for (Iterator<MassLoad> i = vList.iterator(); i.hasNext();) {
			MassLoad vMassLoad = (MassLoad) i.next();

			// Let singel BEC do the extraction to VO
			mBecMassLoad.init(vMassLoad);
			VoMassLoad vVoMassLoad = mBecMassLoad.getVoMassLoad();

			vVoList.add(vVoMassLoad);
		}

		return vVoList;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads#findUnprocessedMassLoads()
	 */
	public List<MassLoad> findUnprocessedMassLoads() {
		return mBefMassLoad.findByUnprocessed();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads#findMassLoads(com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadSearch)
	 */
	public List<VoMassLoad> findMassLoads(VoMassLoadSearch pVoMassLoadSearch)
		throws ValueMissingException {

		List<VoMassLoad> vVoList = new ArrayList<VoMassLoad>();

		List<MassLoad> vList =
			mBefMassLoad.findBySearch(
				pVoMassLoadSearch.getNameLike(),
				pVoMassLoadSearch.getBuType(),
				pVoMassLoadSearch.getBuCode(),
				pVoMassLoadSearch.getCountryCode(),
				-1,
				null,
				pVoMassLoadSearch.getCreatedDateTime());

		for (Iterator<MassLoad> i = vList.iterator(); i.hasNext();) {
			MassLoad vMassLoad = (MassLoad) i.next();

			// Let singel BEC do the extraction to VO
			mBecMassLoad.init(vMassLoad);
			vVoList.add(mBecMassLoad.getVoMassLoad());
		}

		return vVoList;
	}

	public List<VoBonusComplete> findMassLoadBonuses(VoBonusSearch pVoBonusSearch)
		throws ValueMissingException {

		List<VoBonusComplete> vMassLoadBonusList = new LinkedList<VoBonusComplete>();

		List<MassLoad> vList =
			mBefMassLoad.findBySearch(
				null,
				null,
				pVoBonusSearch.getBuCode(),
				pVoBonusSearch.getCountryCode(),
				pVoBonusSearch.getBonusCodeId(),
				pVoBonusSearch.getAuthorizedDateTime(),
				null);

		for (Iterator<MassLoad> i = vList.iterator(); i.hasNext();) {
			MassLoad vMassLoad = (MassLoad) i.next();

			// Let singel BEC do the extraction to VO
			mBecMassLoad.init(vMassLoad);

			VoBonusComplete vVoBonusComplete =
				mBecMassLoad.getVoMassLoadBonus();

			// Map values that are not mapped automatic
			vVoBonusComplete.setStatus(vMassLoad.getMassLoadState());

			// Set the values for VoBonusCodeBrief
			if (vMassLoad.getBonusCode() != null) {
				VoBonusCodeBrief vVoBonusCodeBrief = new VoBonusCodeBrief();
				ValueObjects.assignToValueObject(
					vVoBonusCodeBrief,
					vMassLoad.getBonusCode());

				vVoBonusComplete.setVoBonusCodeBrief(vVoBonusCodeBrief);
			}

			// Add VO to TreeSet
			vMassLoadBonusList.add(vVoBonusComplete);
		}

		return vMassLoadBonusList;
	}

	// -----------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser()
		throws ValueMissingException, IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException("Tried to use BecMassLoads without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

}
