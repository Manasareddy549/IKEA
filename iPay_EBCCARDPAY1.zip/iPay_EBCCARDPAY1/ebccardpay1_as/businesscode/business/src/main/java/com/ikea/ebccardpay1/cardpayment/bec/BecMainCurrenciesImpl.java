/*
 * Created on 2007-sep-03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.Validate;

import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;

/**
 * @author dalq
 *
 *
 */
public class BecMainCurrenciesImpl implements BecMainCurrencies {


	// Dependencies injected at creation of this BEC
	private BecMainCurrency mBecMainCurrency;

	// Entities that this BEC operates on
	List<VoMainCurrency> mVoMainCurrencyList = null;

	// Dependencies that need to be set with init
	private VoCountry mVoCountry = null;

	/**
	 * 
	 */
	public BecMainCurrenciesImpl(BecMainCurrency pBecMainCurrency) {

		mBecMainCurrency = pBecMainCurrency;
	}

	void validate() {
		Validate.notNull(mBecMainCurrency);
	}
	/**
	 * 
	 */
	public BecMainCurrenciesImpl() {
		super();
	}

	public BecMainCurrencies init(List<VoMainCurrency> pVoMainCurrencyList) {
		mVoMainCurrencyList = pVoMainCurrencyList;
		return this;

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrencies#init(com.ikea.ebccardpay1.cardpayment.vo.VoCountry)
	 */
	public void init(VoCountry pVoCountry) {
		mVoCountry = pVoCountry;

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrencies#manage()
	 */
	public void manage()
		throws InvalidFromDateException, ValueMissingException {

		requireVoMainCurrencyList();

		// Set connected Country 
		mBecMainCurrency.init(mVoCountry);


		//Initialize a new ArrayList to fill
		init(new ArrayList<VoMainCurrency>());

        // Manage on each VoMainCurrency
		for(VoMainCurrency vVoMainCurrency : mVoMainCurrencyList){

			// Handle in single BEC
			mBecMainCurrency.manage(vVoMainCurrency);

			//Add modified VO to VO List
			mVoMainCurrencyList.add(
				mBecMainCurrency.getVoMainCurrency());

		}

	}


	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrencies#getMainCurrencyList()
	 */
	public List<VoMainCurrency> getMainCurrencyList()
		throws ValueMissingException {
		requireVoMainCurrencyList();
		return mVoMainCurrencyList;
	}

	/**
	 * 
	 */
	protected void requireVoMainCurrencyList() throws ValueMissingException {
		if (mVoMainCurrencyList == null) {
			throw new ValueMissingException("Tried to use BecMainCurrencies without required List<VoMainCurrency>.");
		}

	}

}
