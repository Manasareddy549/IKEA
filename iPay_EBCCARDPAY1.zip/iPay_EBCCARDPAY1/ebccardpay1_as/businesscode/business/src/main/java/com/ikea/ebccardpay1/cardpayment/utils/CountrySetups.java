/*
 * Created on 2007-apr-27
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;

/**
 * @author anms
 *
 */
public interface CountrySetups {

	/**
	 * 
	 * @param pCountryCode
	 * @param pCardType
	 * @return zero if not specified
	 * @throws CountrySetupException
	 */
	public int getExpireDays(String pCountryCode, String pCardType)
		throws CountrySetupException;

	/**
	 * 
	 *
	 */
	public void reloadCache();
}
