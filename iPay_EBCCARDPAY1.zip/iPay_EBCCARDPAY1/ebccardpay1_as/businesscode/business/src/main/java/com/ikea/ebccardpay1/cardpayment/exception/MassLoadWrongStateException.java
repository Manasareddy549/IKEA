/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class MassLoadWrongStateException extends MassLoadException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2320161305475369451L;

	public MassLoadWrongStateException() {
		super();
	}
	public MassLoadWrongStateException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.MassLoadWrongState();
	}
}
