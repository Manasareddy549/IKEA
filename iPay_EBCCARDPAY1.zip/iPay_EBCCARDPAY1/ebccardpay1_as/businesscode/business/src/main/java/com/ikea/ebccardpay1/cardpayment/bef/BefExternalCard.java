/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefExternalCard extends Bef<ExternalCard>{

	public java.util.List<ExternalCard> findByExternal(String pExternalCardNumberString, ExternalCardSystem pExternalCardSystem);

	public int deleteNotCompleted(ExternalCardSystem pExternalCardSystem);

}