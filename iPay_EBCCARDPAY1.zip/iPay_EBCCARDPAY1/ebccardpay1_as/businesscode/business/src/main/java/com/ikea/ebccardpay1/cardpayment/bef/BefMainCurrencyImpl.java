/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.MainCurrency;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefMainCurrencyImpl extends BefAbstract<MainCurrency> implements BefMainCurrency {

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefMainCurrencyImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<MainCurrency> getBusinessEntityClass() {
		// TODO Auto-generated method stub
		return MainCurrency.class;
	}

}
