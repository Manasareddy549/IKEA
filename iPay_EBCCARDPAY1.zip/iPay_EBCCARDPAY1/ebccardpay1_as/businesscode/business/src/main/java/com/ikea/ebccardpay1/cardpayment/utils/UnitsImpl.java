package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ikea.ebcframework.client.BsExecuter;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.eicywp01.client.bs.BsGetPerson;
import com.ikea.eicywp01.client.vo.VoPersonKey;
import com.ikea.common.TimeSource;
import com.ikea.ebcframework.exception.IkeaException;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 */
public class UnitsImpl implements Units, InitializingBean {

	private final static Logger mCategory = LoggerFactory.getLogger(UnitsImpl.class);

	/**
	 * Dependencies
	 */
	private TimeSource mTimeSource;

	UnitsCache mUnitsCache;

    @Autowired
    private BsExecuter bsExecuter;
	/**
	 * Dependency injection
	 */
//	public UnitsImpl(TimeSource pTimeSource) {
//
//		mTimeSource = pTimeSource;
//		
//	}

	/**
	 * Dependency injection
	 */
	public UnitsImpl(TimeSource pTimeSource, UnitsCache pUnitsCache) {

		mTimeSource = pTimeSource;
		mUnitsCache = pUnitsCache;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#closedStores()
	 */
	public List<VoBusinessUnit> closedStores() {
		List<VoBusinessUnit> vList = new ArrayList<VoBusinessUnit>();

		Date vUTC = mTimeSource.currentDate();

		// Loop over BU
		for (Unit vUnit : mUnitsCache.all()) {
			DateTime vDateTime = Dates.localDateTime(vUTC, vUnit.getTimeZone());
			if (mCategory.isDebugEnabled()) {
				mCategory.debug("Now in local time for " + vUnit.getBuType()
						+ vUnit.getBuCode() + " : "
						+ CardPaymentLogger.jodaToString(vDateTime));
			}

			int vHour = vDateTime.hourOfDay().get();

			// Check to see if local time is between 03:00 and 06:59
			if (vHour >= 3 && vHour <= 6) {
				VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
				vVoBusinessUnit.setBuType(vUnit.getBuType());
				vVoBusinessUnit.setBuCode(vUnit.getBuCode());
				vVoBusinessUnit.setCountryCode(vUnit.getCountryCode());
				vVoBusinessUnit.setSiteName(vUnit.getSiteName());
				vVoBusinessUnit.setCompanyCode(vUnit.getCompanyCode());
				vVoBusinessUnit.setCompanyName(vUnit.getCompanyName());
				vList.add(vVoBusinessUnit);
			}
		}
		if (mCategory.isInfoEnabled()) {
			mCategory
					.info("Closed stores (local time is between 03:00 and 07:00 right now): "
							+ CardPaymentLogger.buListToString(vList));
		}

		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#closedStores()
	 */
	public List<VoBusinessUnit> allStores() {
		List<VoBusinessUnit> vList = new ArrayList<VoBusinessUnit>();

		// Loop over B
		for (Unit vUnit : mUnitsCache.all()) {
			VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
			vVoBusinessUnit.setBuType(vUnit.getBuType());
			vVoBusinessUnit.setBuCode(vUnit.getBuCode());
			vVoBusinessUnit.setCountryCode(vUnit.getCountryCode());
			vVoBusinessUnit.setSiteName(vUnit.getSiteName());
			vVoBusinessUnit.setCompanyCode(vUnit.getCompanyCode());
			vVoBusinessUnit.setCompanyName(vUnit.getCompanyName());
			vList.add(vVoBusinessUnit);
		}

		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#allCountryCodes()
	 */
	public List<String> allCountryCodes() {
		List<String> vList = new ArrayList<String>();

		// Loop over BU
		for (Unit vUnit : mUnitsCache.all()) {
			if (!vList.contains(vUnit.getCountryCode())) {
				vList.add(vUnit.getCountryCode());
			}
		}

		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#getCountryCode(java.lang.String,
	 *      java.lang.String)
	 */
	public String getCountryCode(String pBuType, String pBuCode)
			throws BusinessUnitException {

		Unit vUnit = mUnitsCache.fetch(pBuType, pBuCode);
		return vUnit.getCountryCode();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#isValidBusinessUnit(java.lang.String,
	 *      java.lang.String)
	 */
	public void checkValidBusinessUnit(String pBuType, String pBuCode)
			throws BusinessUnitException {

		mUnitsCache.fetch(pBuType, pBuCode);
		if (mCategory.isDebugEnabled()) {
			mCategory.debug(pBuType + " " + pBuCode + " is a valid BU code");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#checkValidCountryCode(java.lang.String)
	 */
	public void checkValidCountryCode(String pCountryCode)
			throws BusinessUnitException {

		List<String> vList = allCountryCodes();
		if (!vList.contains(pCountryCode)) {
			throw new BusinessUnitException("Country code '" + pCountryCode
					+ "' is not a valid country code in iPay");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#getSiteName(java.lang.String,
	 *      java.lang.String)
	 */
	public String getSiteName(String pBuType, String pBuCode)
			throws BusinessUnitException {

		Unit vUnit = mUnitsCache.fetch(pBuType, pBuCode);
		return vUnit.getSiteName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#getTimeZone(java.lang.String,
	 *      java.lang.String)
	 */
	public String getTimeZone(String pBuType, String pBuCode)
			throws BusinessUnitException {

		Unit vUnit = mUnitsCache.fetch(pBuType, pBuCode);
		return vUnit.getTimeZone();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#getUnitForUser(java.lang.String)
	 */
	public VoBusinessUnit getUnitForUser(String pUserName) throws IkeaException {
		mCategory.debug("Running getUnitForUser");

		// Create person key VO
		VoPersonKey vVoPersonKey = new VoPersonKey();
		vVoPersonKey.setUid(pUserName);

		// Create service
		BsGetPerson vBsGetPerson = new BsGetPerson();

		// Set input VO
		vBsGetPerson.setVoPersonKey(vVoPersonKey);

		// Execute service
		mCategory.debug("Calling EICYWP");
        bsExecuter.executeBs(vBsGetPerson);
		mCategory.debug("Returned from EICYWP");

		// Create business unit VO
		VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
		vVoBusinessUnit.setBuType("STO");

		if (vBsGetPerson.getVoPersonDetail() == null) {
            throw new IkeaException("The user " + pUserName+ " does not have an entry in CDS/IKEA People.");
//			throw new IkeaException(UnitsImpl.class, "The user " + pUserName
//					+ " does not have an entry in CDS/IKEA People.");
//
		}

		// Get country and BU for the user in CDS
		vVoBusinessUnit.setCountryCode(vBsGetPerson.getVoPersonDetail()
				.getCountryCode());
		if (vBsGetPerson.getVoPersonDetail().getVoSite() != null) {
			vVoBusinessUnit.setSiteName(vBsGetPerson.getVoPersonDetail()
					.getVoSite().getSiteName());
		} else {
			mCategory.info("User " + pUserName
					+ " does not have a site in CDS/IKEA People.");
		}
		if (vBsGetPerson.getVoPersonDetail().getVoBusinessUnit() != null) {
			vVoBusinessUnit.setBuType(vBsGetPerson.getVoPersonDetail()
					.getVoBusinessUnit().getBusinessUnitType());
			vVoBusinessUnit.setBuCode(vBsGetPerson.getVoPersonDetail()
					.getVoBusinessUnit().getBusinessUnitCode());
		} else {
			mCategory.info("User " + pUserName
					+ " does not have a Business Unit set in CDS/IKEA People.");
		}

		//Get Unit from cache and retrieve company information 
		Unit vUnit =mUnitsCache.fetch(vVoBusinessUnit.getBuType(), vVoBusinessUnit.getBuCode());
		if (vUnit!=null) {
			vVoBusinessUnit.setCompanyCode(vUnit.getCompanyCode());
			vVoBusinessUnit.setCompanyName(vUnit.getCompanyName());
		}
	
		mCategory.debug("Returning from getUnitForUser [" + vVoBusinessUnit
				+ "]");

		return vVoBusinessUnit;
	}

	public List<VoBusinessUnit> getUnitsForCountryCode(String pCountryCode) {
		if (mCategory.isDebugEnabled()) {
			mCategory.debug("Getting Units for Country: " + pCountryCode);
		}
		ArrayList<VoBusinessUnit> vUnitsPerSpecifiedCountryCode = new ArrayList<VoBusinessUnit>();
		for (Unit vUnit : mUnitsCache.all()) {
			if (vUnit.getCountryCode().equals(pCountryCode)) {
				VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
				vVoBusinessUnit.setBuType(vUnit.getBuType());
				vVoBusinessUnit.setBuCode(vUnit.getBuCode());
				vVoBusinessUnit.setCountryCode(vUnit.getCountryCode());
				vVoBusinessUnit.setSiteName(vUnit.getSiteName());
				vVoBusinessUnit.setCompanyCode(vUnit.getCompanyCode());
				vVoBusinessUnit.setCompanyName(vUnit.getCompanyName());
				vUnitsPerSpecifiedCountryCode.add(vVoBusinessUnit);
			}
		}
		return vUnitsPerSpecifiedCountryCode;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#getCountryCode(java.lang.String,
	 *      java.lang.String)
	 */
	public String getCompanyCode(String pBuType, String pBuCode)
			throws BusinessUnitException {
		//UnitsCacheImpl unitsCache = (UnitsCacheImpl)mIkeaCacheFactory.getCache(UnitsCacheImpl.class.getName(), null);
		Unit vUnit = mUnitsCache.fetch(pBuType, pBuCode);
		return vUnit.getCompanyCode();
	}

	//@Override
	public void afterPropertiesSet() throws Exception {
		Validate.notNull(mUnitsCache);
		Validate.notNull(mTimeSource);
		Validate.notNull(bsExecuter);
		mCategory.info("UnitsImpl validated all member variables set.");
		
	}
}
