/*
 * Created on 2006-dec-13
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class InvalidCardIssuerException extends InvalidCardNumberException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3963163411483523196L;

	/**
	 * 
	 */
	public InvalidCardIssuerException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public InvalidCardIssuerException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidCardIssuer();
	}

}
