/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.IllegalAmountStateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidForeignCardException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 */
public interface BecAmounts {

	/**
	 * @param pCard
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecAmounts init(
		Card pCard,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * 
	 * @param pVoLoadAmount
	 * @param pTransactionEnvironment
	 * @throws IllegalAmountTypeException
	 * @throws IllegalAmountStateException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException 
	 * @throws InvalidForeignCardException 
	 */
	public void loadAmount(VoLoadAmount pVoLoadAmount,String pSourceSystem, String pCardNumberString)
		throws AmountException, CurrencyException, ValueMissingException, IkeaException, InvalidCardException, InvalidForeignCardException;

	/**
	 * 
	 * @param pVoRequestAmount
	 * @param pVoRedeemAmount
	 * @param mCardNumberString 
	 * @param pTransactionEnvironment
	 * @throws IllegalAmountTypeException
	 * @throws IllegalAmountStateException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException 
	 * @throws InvalidForeignCardException 
	 */
	public void redeemAmount(
		VoRequestAmount pVoRequestAmount,
		VoRedeemAmount pVoRedeemAmount, String pCardNumberString)
		throws AmountException, CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException;
	
	public void redeemAmountReserved(
			VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemAmount, String pCardNumberString)
			throws AmountException, CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException;
	
	public void redeemAmountManual(
			VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemAmount,
			VoManualTransaction pVoManualTransaction, String pCardNumberString)
			throws AmountException, CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException;


	/**
	 * @param pCampaign
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException 
	 */
	public void loadCampaign(Campaign pCampaign)
		throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException;
	
	public void CampaignLoadtransaction(Campaign pCampaign) throws Exception;

	/**
	 * @param pMassLoad
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException 
	 */
	public void loadMassLoad(MassLoad pMassLoad)
		throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException;

	/**
	 * 
	 * @param pBonus
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException 
	 */
	public void loadBonus(Bonus pBonus)
		throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException;


	/**
	 * 
	 * @param pMultipleSingleLoad
	 * @throws ValueMissingException 
	 * @throws AmountException 
	 * @throws CurrencyException 
	 * @throws IkeaException 
	 */
	void loadMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pAmountValue) throws CurrencyException, CardPayException, ValueMissingException, IkeaException;

	/**
	 * Finds the amounts that are currently active for the card. Campaigns will need
	 * a lot of information in order to determine if they are active.
	 * 
	 * @param pCalculationTime
	 * @param pTotalAmount The total amount on the reciept in order to compare
	 *                     with the minimum purchase amount. Pass null and the campaign
	 *                     is always included
	 * @param pBuType The BU of the unit that requests balance in order to compare with
	 *                the list of limitations.  Pass null and the campaign is always included
	 * @param pBuCode The BU of the unit that requests balance in order to compare with
	 *                the list of limitations.  Pass null and the campaign is always included
	 * @return
	 */
	public List<Amount> findActiveAmounts(
		Date pCalculationTime,
		BigDecimal pTotalAmount,
		String pBuType,
		String pBuCode)
		throws ValueMissingException;
	
	/**
	 * @param pMassLoad
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException
	 * - by anagc on 02-16-2016 
	 */
	public void withdrawMassLoad(MassLoad pMassLoad)
		throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException;
		
		public void redeemAmount(List<Amount> amouts) throws AmountException, CurrencyException, ValueMissingException, InvalidCardException, IkeaException;

	public void expireCampign(Campaign pCampaign)
			throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException,TransactionException;
			
			public void withdrawnCampign(Campaign pCampaign)
			throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException,TransactionException;
			
			 public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction , Campaign pCampaign) throws Exception;
			
			public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction , Campaign pCampaign) throws Exception;
			
			public void CampaignDebiTransaction(Campaign pCampaign,String sales_Day)throws Exception;
			
			public void withdrawnSingleLoad(MultipleSingleLoad pMultipleSingleLoad) throws ValueMissingException, CurrencyException, AmountException, TransactionException;

}