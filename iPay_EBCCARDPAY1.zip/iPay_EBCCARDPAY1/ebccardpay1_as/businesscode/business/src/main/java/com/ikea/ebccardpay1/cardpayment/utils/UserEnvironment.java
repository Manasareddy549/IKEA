/*
 * Created on 2007-jun-19
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.HashSet;
import java.util.Set;

import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;

/**
 * @author anms
 * @author Henrik Reinhold
 */
public class UserEnvironment {

	private String mUserId = null;
	private VoBusinessUnit mVoBusinessUnit = null;
	private Set<String> mPrivsWithRealm = new HashSet<String>();
	
	public UserEnvironment(String pUserId, VoBusinessUnit pVoBusinessUnit,
			Set<String> pPrivsWithRealm) {
		super();
		mUserId = pUserId;
		mVoBusinessUnit = pVoBusinessUnit;
		mPrivsWithRealm = pPrivsWithRealm;
	}

	
	/**
	 * Gets the user id for the user that initiated this request
	 * @return String User id
	 */
	public String getUserId(){
		return mUserId;
	}

	/**
	 * Gets the country code for the current user 
	 * (the country the user is connected to in CDS/Ikea People)
	 * @return String Country code
	 */
	public String getCountryCode(){
		return mVoBusinessUnit.getCountryCode();
	}

	/**
	 * Check if the user has the privilege in CDS
	 * 
	 * @param pPrivWithRealm Name of the privilege to check for
	 * @return true if the user has the privilege
	 */
	public boolean hasPrivilege(String pPrivWithRealm) {
		return mPrivsWithRealm.contains(pPrivWithRealm);
	}

	/**
	 * Get the business unit for the current user
	 * 
	 * @return VoBusinessUnit The users business unit
	 */
	public VoBusinessUnit getBusinessUnit(){
		return mVoBusinessUnit;
	}

}
