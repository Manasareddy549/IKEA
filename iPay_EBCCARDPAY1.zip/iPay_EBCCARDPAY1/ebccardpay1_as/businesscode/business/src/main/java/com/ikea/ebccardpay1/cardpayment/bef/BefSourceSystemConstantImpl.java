/*
 * Created on 2007-feb-21
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.SourceSystemConstant;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefSourceSystemConstantImpl extends
		BefAbstract<SourceSystemConstant> implements BefSourceSystemConstant {

	/**
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefSourceSystemConstantImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<SourceSystemConstant> getBusinessEntityClass() {
		return SourceSystemConstant.class;
	}

}
