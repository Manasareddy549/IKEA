package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.common.TimeSource;

/**
 * @author moans1
 *
 */
public class BecSarecReportImpl implements BecSarecReport {

	private final static Logger mCategory = LoggerFactory.getLogger(BecSarecReportImpl.class);

	// Dependencies injected at creation of this BEC
	private BefSarecReport mBefSarecReport = null;
	private TimeSource mTimeSource = null;
	private Units mUnits = null;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	/**
	 * Dependency injection
	 */
	protected BecSarecReportImpl(BefSarecReport pBefSarecReport, TimeSource pTimeSource, Units pUnits,BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefSarecReport= pBefSarecReport;
		mTimeSource = pTimeSource;
		mUnits = pUnits;
		mBefIpayBusinessUnits=pBefIpayBusinessUnits;
	}
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecSarecReport#findUngeneratedSarecReportDates(java.lang.String, java.lang.String)
	 */
	public List<String> findUngeneratedSarecReportDates(String pBuType,
			String pBuCode,
			BefIpayBusinessUnits pBefIpayBusinessUnits) {
		List<String> vList = new LinkedList<String>();

		String vTimeZoneId = mUnits.getTimeZone(pBuType, pBuCode);

		DateTime vGenerationDateTime =
			Dates.localDateTime(mTimeSource.currentDate(), vTimeZoneId);

		mCategory.info(
			"Generation date for "
				+ pBuType
				+ pBuCode
				+ " in local time: "
				+ CardPaymentLogger.jodaToString(vGenerationDateTime));

		// Find the last batch date for this BU
		String vLastSarecSalesdate =
			mBefSarecReport.findLastSarecReport(pBuType, pBuCode);

		if (vLastSarecSalesdate == null) {
			// If this is a new BU that we have not generated Sarec Report for, assume only previous day
			int vBreakhour = 0;

			IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(pBuType, pBuCode);

			if(vIpayBusinessUnits!=null){	
				if(	vIpayBusinessUnits.getBreakHour()!=null){

					vBreakhour= Integer.parseInt(vIpayBusinessUnits.getBreakHour());

				}else{
					vBreakhour=3;
				}
			}
			mCategory.info(
					"Break hour for"
						+ pBuType
						+ pBuCode
						+ ": "
						+ vBreakhour);
			
			if (!Dates.passedBreakingPoint(vGenerationDateTime, vBreakhour)) {
				// We are still in the last minutes(hours) of the previous sales day
				// -> We can not generate for this date, go back one.
				vGenerationDateTime = Dates.withPrevDay(vGenerationDateTime);
			}
			vGenerationDateTime = Dates.withPrevDay(vGenerationDateTime);
			vList.add(Dates.formatDate(vGenerationDateTime));
		} else {

			mCategory.info(
				"Last Sarec Report date found for "
					+ pBuType
					+ pBuCode
					+ ": "
					+ vLastSarecSalesdate);

			DateTime vNextSarecReportDate =
				Dates.parseDate(vLastSarecSalesdate, vTimeZoneId);
			int vBreakhour = 0;

			IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(pBuType, pBuCode);

			if(vIpayBusinessUnits!=null){	
				if(	vIpayBusinessUnits.getBreakHour()!=null){

					vBreakhour= Integer.parseInt(vIpayBusinessUnits.getBreakHour());

				}else{
					vBreakhour=3;
				}
			}
			mCategory.info(
					"Break hour for"
						+ pBuType
						+ pBuCode
						+ ": "
						+ vBreakhour);
			// First set the breaking hour then go one day forward to next Sarec Report date
			vNextSarecReportDate = Dates.withBreakPoint(vNextSarecReportDate,vBreakhour);
			vNextSarecReportDate = Dates.withNextDay(vNextSarecReportDate);

			mCategory.debug(
				"Next Sarec Report date beginning : "
					+ CardPaymentLogger.jodaToString(vNextSarecReportDate));

			// Back one day (can not generate this day until we have passed breaking hour of the next)
			vGenerationDateTime = Dates.withPrevDay(vGenerationDateTime);

			// Add days to batch date until we reach one day before generation date
			while (vNextSarecReportDate.isBefore(vGenerationDateTime)) {
				mCategory.debug(
					"Adding because "
						+ CardPaymentLogger.jodaToString(vNextSarecReportDate)
						+ " is before "
						+ CardPaymentLogger.jodaToString(vGenerationDateTime));
				vList.add(Dates.formatDate(vNextSarecReportDate));
				vNextSarecReportDate = Dates.withNextDay(vNextSarecReportDate);
				mCategory.debug(
					"Next Sarec Report date beginning: "
						+ CardPaymentLogger.jodaToString(vNextSarecReportDate));
			}
		}
		return vList;
	}
	public void validate() {
		notNull(mBefSarecReport);
		notNull(mTimeSource);
		notNull(mUnits);
		
	}

}
