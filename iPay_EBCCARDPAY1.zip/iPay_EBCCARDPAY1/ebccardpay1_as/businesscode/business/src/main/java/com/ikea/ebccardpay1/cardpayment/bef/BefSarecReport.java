package com.ikea.ebccardpay1.cardpayment.bef;

import java.sql.Blob;

import com.ikea.ebccardpay1.cardpayment.be.IpaySarecReport;
import com.ikea.ebccardpay1.cardpayment.exception.ReportException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author moans1
 *
 */
public interface BefSarecReport extends Bef<IpaySarecReport> {
	
	public Blob generate(String pBuType, String pBuCode, String pSalesday) throws IkeaException, ReportException, ValueMissingException;
	
	public Blob generateS4hana(String pBuType, String pBuCode, String pSalesDay) throws IkeaException, ReportException, ValueMissingException;

	public String findLastSarecReport(String pBuType, String pBuCode);

	public int deleteSaarecReport(String pBuType, java.util.List<String> pStores);

	public void transferSarecReport();

}
