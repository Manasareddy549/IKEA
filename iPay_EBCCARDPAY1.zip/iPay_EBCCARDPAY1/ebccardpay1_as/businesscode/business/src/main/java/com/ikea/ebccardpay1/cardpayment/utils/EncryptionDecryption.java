package com.ikea.ebccardpay1.cardpayment.utils;

import com.vormetric.pkcs11.wrapper.CK_MECHANISM;

public interface EncryptionDecryption {
	
	public String encrypt(final String inputData);
	public String decrypt(final String encryptedData);
	public CK_MECHANISM getMechanism();

}
