/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefBonus extends Bef<Bonus>{

	public java.util.List<Bonus> findByUnauthorized(String pCountryCode);

	public java.util.List<Bonus> findBySearch(String pBuType, String pBuCode, long pBonusCode, String pCountryCode, java.util.Date pAuthorizedDateTime);

}