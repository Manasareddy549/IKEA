package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;

import com.ikea.ebcframework.client.BsExecuter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccbd1.client.bs.BsFindExcrtsByValidAt;
import com.ikea.ebccbd1.client.bs.BsFindParents1;
import com.ikea.ebccbd1.client.bs.BsGetBuFull;
import com.ikea.ebccbd1.client.bs.BsGetCompFunc;
import com.ikea.ebccbd1.client.vo.VoBuFull;
import com.ikea.ebccbd1.client.vo.VoCluGet;
import com.ikea.ebccbd1.client.vo.VoCluStrMember;
import com.ikea.ebccbd1.client.vo.VoCluStrMember;
import com.ikea.ebccbd1.client.vo.VoCompCompFuncDetails;
import com.ikea.ebccbd1.client.vo.VoCompFuncGet;
import com.ikea.ebccbd1.client.vo.VoExcrtByValidAt;
import com.ikea.ebccbd1.client.vo.VoExcrtByValidAt;
import com.ikea.ebccbd1.client.vo.VoExcrtFind;
import com.ikea.ebccbd1.client.vo.VoStructureGet;
import com.ikea.ebccbd1.client.vo.VoStructureGet;
import com.ikea.ebccbd1.client.vo.VoStructureResult;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.spring.BeanFactory;

import org.springframework.beans.factory.annotation.Autowired;

public class CbdServiceBsImpl implements CbdService {

	private static final Logger mLog = LoggerFactory.getLogger(CbdServiceBsImpl.class);

	private Date mValidAt = new Date();

    
	public CbdExchangeRatesForCurrencies getExchangeRatesForCurrencies(
			Set<String> pCurrencyCodes) throws IkeaException {
		CbdExchangeRatesForCurrencies vExchangeRates = new CbdExchangeRatesForCurrencies();
		for (String vCurrencyCode : pCurrencyCodes) {

			BsFindExcrtsByValidAt vBsFindExcrtsByValidAt = new BsFindExcrtsByValidAt();
			VoExcrtFind vVoExcrtFind = new VoExcrtFind();
			vVoExcrtFind.setConvertFromCurCode(vCurrencyCode);
			vVoExcrtFind.setExcrtType("SPOT");

			vBsFindExcrtsByValidAt.setVoExcrtFindIn(vVoExcrtFind);
            BsExecuter bsExecuter = BeanFactory.getBsExecuter();
			bsExecuter.executeBs(vBsFindExcrtsByValidAt);

			if (getApplicationErrorList(vBsFindExcrtsByValidAt) == null
					|| getApplicationErrorList(vBsFindExcrtsByValidAt)
							.isEmpty()) {
				List<VoExcrtByValidAt> vVoExcrtFindOutList = vBsFindExcrtsByValidAt.getVoExcrtFindOutList();

				if (vVoExcrtFindOutList != null
						&& !(vVoExcrtFindOutList.isEmpty())) {
					vExchangeRates.setExchangeRatesForCurrency(vCurrencyCode,
							convertToCurrencyCodeAndRate(vVoExcrtFindOutList,
									pCurrencyCodes));
				}

			} else {
				for (ApplicationError vError : getApplicationErrorList(vBsFindExcrtsByValidAt)) {

					mLog
							.warn("Error when collecting currency exchange rate for "
									+ vCurrencyCode
									+ " from CBD: "
									+ vError.getMessage());
				}
			}
		}

		return vExchangeRates;
	}

	@SuppressWarnings("unchecked")
	private List<ApplicationError> getApplicationErrorList(
			BsFindExcrtsByValidAt vBsFindExcrtsByValidAt) {
		return vBsFindExcrtsByValidAt.getApplicationErrors();
	}

	public CbdExchangeRates convertToCurrencyCodeAndRate(
			List<VoExcrtByValidAt> vVoExcrtFindOutList, Set<String> pCurrencies) {
		CbdExchangeRates vCbdExchangeRates = new CbdExchangeRates();

		for (VoExcrtByValidAt vVoExcrtByValidAt : vVoExcrtFindOutList) {
			if (!vVoExcrtByValidAt.getConvertFromCurCode().equals(
					vVoExcrtByValidAt.getConvertToCurCode())
					&& pCurrencies.contains(vVoExcrtByValidAt
							.getConvertToCurCode())) {

				vCbdExchangeRates.setExchangeRate(vVoExcrtByValidAt
						.getConvertToCurCode(), new Double(vVoExcrtByValidAt
						.getExchangeRate()));
			}

		}
		return vCbdExchangeRates;
	}

//	@SuppressWarnings("unchecked")
//	private List<VoExcrtByValidAt> getList(
//			List<VoExcrtByValidAt> vVoExcrtFindOutList) {
//		return vVoExcrtFindOutList.getCollection();
//	}

	public Company getCompanyForBusinessUnit(String pBuType, String pBuCode)
			throws IkeaException {

		BsGetBuFull vBsGetBuFull = setupBsGetBuFull(pBuType, pBuCode);
		BsExecuter bsExecuter = BeanFactory.getBsExecuter();
		bsExecuter.executeBs(vBsGetBuFull);
		if (logError("Error getting BU[" + pBuType + ", " + pBuCode + "]",
				getApplicationErrorList(vBsGetBuFull)))
			return null;

		String vClassUnitCode = extractClassUnitCode(pBuType, //
				vBsGetBuFull.getVoBuFullOut());
		if (vClassUnitCode == null) {
			mLog.warn("No ClassUnitCode found for [" + pBuType + ", " + pBuCode
					+ "]");
			return null;
		}

		BsGetCompFunc vBsGetCompFunc = setupBsGetCompFunc(vClassUnitCode);
        bsExecuter.executeBs(vBsGetCompFunc);
		if (logError("Error getting CompFunc for BU[" + pBuType + ", "
				+ pBuCode + "], ClassUnitCode " + vClassUnitCode,
				getApplicationErrorList(vBsGetCompFunc)))
			return null;

		String parentBuCode = extractParentBuCode(vBsGetCompFunc
				.getVoCompCompFuncOut());

		BsFindParents1 vBsFindParents1 = setupBsFindParents1(vClassUnitCode);

        bsExecuter.executeBs(vBsFindParents1);
		if (logError("Error finding Parents for BU[" + pBuType + ", " + pBuCode
				+ "], ClassUnitCode " + vClassUnitCode,
				getApplicationErrorList(vBsFindParents1)))
			return null;

		return extractCompany(parentBuCode, vBsFindParents1);
	}

	public BsGetBuFull setupBsGetBuFull(String pBuType, String pBuCode) {
		BsGetBuFull vBsGetBuFull = new BsGetBuFull();
		VoCluGet vVoCluGet = new VoCluGet();
		vVoCluGet.setClutType(pBuType);
		vVoCluGet.setCluCode(pBuCode);
		vVoCluGet.setValidAt(mValidAt);
		vBsGetBuFull.setVoCluGetIn(vVoCluGet);
		return vBsGetBuFull;
	}

	public String extractClassUnitCode(String pBuType, VoBuFull pVoBuFull) {
		String legClassUnitCode = null;
		String orgClassUnitCode = null;
		List<VoCluStrMember> vVoCluStrMemberList = pVoBuFull.getVoBuStructure()
				.getVoCluStrParentList(); // or that
		for (VoCluStrMember member : vVoCluStrMemberList) {
			if (member.getStructureType().equals("LEG"))
				legClassUnitCode = member.getClassUnitCode();
			if (member.getStructureType().equals("ORG"))
				orgClassUnitCode = member.getClassUnitCode();
		}
		return pBuType.equals("STO") ? legClassUnitCode : orgClassUnitCode;
	}

	public BsGetCompFunc setupBsGetCompFunc(String pClassUnitCode) {
		BsGetCompFunc vBsGetCompFunc = new BsGetCompFunc();
		VoCompFuncGet vVoCompFuncGet = new VoCompFuncGet();
		vVoCompFuncGet.setCUTClass("CF");
		vVoCompFuncGet.setCUTType("RET");
		vVoCompFuncGet.setCompFuncCode(pClassUnitCode);
		vVoCompFuncGet.setValidAt(mValidAt);
		vBsGetCompFunc.setVoCompFuncGetIn(vVoCompFuncGet);
		return vBsGetCompFunc;
	}

	public String extractParentBuCode(
			VoCompCompFuncDetails pVoCompCompFuncDetails) {
		return pVoCompCompFuncDetails.getBUCode();
	}

	public BsFindParents1 setupBsFindParents1(String pClassUnitCode) {
		BsFindParents1 vBsFindParents1 = new BsFindParents1();
		List<VoStructureGet> vVoStructureGetList = new ArrayList<VoStructureGet>();
		VoStructureGet vVoStructureGet = new VoStructureGet();
		vVoStructureGet.setClassType("CF");
		vVoStructureGet.setClassUnitType("RET");
		vVoStructureGet.setClassUnitCode(pClassUnitCode);
		vVoStructureGet.setStructureType("CFUNC");
		vVoStructureGet.setClassTypeFound("BU");
		vVoStructureGet.setClassUnitTypeFound("COM");
		vVoStructureGetList.add(vVoStructureGet);
//        VoStructureGetList
		vBsFindParents1.setVoFindParents1InList(vVoStructureGetList);
		return vBsFindParents1;
	}

	public Company extractCompany(String parentBuCode,
			BsFindParents1 pBsFindParents1) {
		Company vCompany = null;
        List<VoStructureResult> parents = pBsFindParents1.getVoFindParents1OutList();
		if (parents.size() > 0) {
			vCompany = new Company();
			vCompany.setCompanyCode(parentBuCode);
			vCompany.setCompanyName(parents.get(0).getClassUnitNameFound());
		}
		return vCompany;
	}

	@SuppressWarnings("unchecked")
	private List<ApplicationError> getApplicationErrorList(
			BsGetBuFull pBsGetBuFull) {
		return pBsGetBuFull.getApplicationErrors();
	}

	@SuppressWarnings("unchecked")
	private List<ApplicationError> getApplicationErrorList(
			BsGetCompFunc pBsGetCompFunc) {
		return pBsGetCompFunc.getApplicationErrors();
	}

	@SuppressWarnings("unchecked")
	private List<ApplicationError> getApplicationErrorList(
			BsFindParents1 pBsFindParents1) {
		return pBsFindParents1.getApplicationErrors();
	}

//	@SuppressWarnings("unchecked")
//	private List<VoCluStrMember> getList(List<VoCluStrMember> pVoCluStrMemberList) {
//		return pVoCluStrMemberList.getCollection();
//	}

//	@SuppressWarnings("unchecked")
//	private List<VoStructureResult> getList(BsFindParents1 pBsFindParents1) {
//		return pBsFindParents1.getVoFindParents1OutList;
//	}

	private boolean logError(String text, List<ApplicationError> list) {
		if (list == null || list.isEmpty())
			return false;
		for (ApplicationError vError : list) {
			mLog.warn(text + ": " + vError.getMessage());
		}
		return true;
	}

	public Date getValidAt() {
		return mValidAt;
	}

	public void setValidAt(Date validAt) {
		mValidAt = validAt;
	}
}
