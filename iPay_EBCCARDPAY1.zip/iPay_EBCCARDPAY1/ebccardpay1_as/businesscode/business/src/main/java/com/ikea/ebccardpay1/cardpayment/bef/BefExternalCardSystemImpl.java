/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefExternalCardSystemImpl extends BefAbstract<ExternalCardSystem> implements BefExternalCardSystem {

	private final static Logger mCategory_findByName =
		LoggerFactory.getLogger(
			BefExternalCardSystemImpl.class.getName() + ".findByName");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefExternalCardSystemImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefExternalCardSystem#findByName(java.lang.String, java.lang.String)
	 */
	public ExternalCardSystem findByName(String pExternalCardSystemName, String pImportState) {

		Session vSession = mSessionFactory.getCurrentSession();

		GenericCriteria<ExternalCardSystem> vCriteria = new GenericCriteria<ExternalCardSystem>(vSession.createCriteria(ExternalCardSystem.class));
		vCriteria.add(Restrictions.eq("name", pExternalCardSystemName));

		if (pImportState !=null) {
			vCriteria.add(Restrictions.ne("importState", pImportState));
		}

		ExternalCardSystem vExternalCardSystem = vCriteria.uniqueResult();		

		if (vExternalCardSystem == null) {
			mCategory_findByName.info("No external card system by this name" +  pExternalCardSystemName + "found.");
		} else {
			mCategory_findByName.info("Found external card system by this name: " +  pExternalCardSystemName);
		}
		return vExternalCardSystem;
	}

	@Override
	protected Class<ExternalCardSystem> getBusinessEntityClass() {
		return ExternalCardSystem.class;
	}

	//@Override
	public ExternalCardSystem findByNameOnly(String pExternalCardSystemName) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		GenericCriteria<ExternalCardSystem> vCriteria = new GenericCriteria<ExternalCardSystem>(vSession.createCriteria(ExternalCardSystem.class));
		vCriteria.add(Expression.eq("name", pExternalCardSystemName));


		ExternalCardSystem vExternalCardSystem = vCriteria.uniqueResult();		

		if (vExternalCardSystem == null) {
			mCategory_findByName.info("No external card system by this name" +  pExternalCardSystemName + "found.");
		} else {
			mCategory_findByName.info("Found external card system by this name: " +  pExternalCardSystemName);
		}
		return vExternalCardSystem;
	}



}
