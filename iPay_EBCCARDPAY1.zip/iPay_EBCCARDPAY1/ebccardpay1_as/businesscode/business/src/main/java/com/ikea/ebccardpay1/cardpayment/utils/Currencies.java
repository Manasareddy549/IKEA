/*
 * Created on 2007-jan-25
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.vo.VoCurrency;

import java.util.List;

/**
 * @author anms
 *
 */
public interface Currencies {

	/**
	 * Retrieves a list of currency codes with name and decaimals.
	 * 
	 * @return A list of VoCurrency
	 */
	public List<VoCurrency> allVoCurrency();

	/**
	 * Retrieves a currency code with name and decaimals for a specific Country Code.
	 * 
	 * @return A list of VoCurrency
	 */
	public List<VoCurrency> getCurrencyForCountry(String pCountryCode);
	
	/**
	 * Retrieves all valid Currency codes  .
	 * 
	 * @return A list of Currency Codes
	 */
	
	public List<String>	allCurrencyCodes();

}
