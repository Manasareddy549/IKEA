/*
 * Created on 2006-aug-28
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.error.ApplicationErrorParam;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebccardpay1.common.*;
/**
 * @author anms
 *
 */
public abstract class EbcCardPay1ApplError extends ApplicationError {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5310526744219577390L;

	private final static Logger mLog = LoggerFactory.getLogger(EbcCardPay1ApplError.class);

	private static final String EBCNAME = "EBCCARDPAY1";

	protected EbcCardPay1ApplError(
			int pApplicationErrorCode,
			String pMessage) {

		super(EBCNAME, pApplicationErrorCode, pMessage);
		mLog.info(
				"Created application error '"
						+ pMessage
						+ "' with application error code '"
						+ pApplicationErrorCode
						+ "' and class '"
						+ this.getClass()
						+ "'.");
	}

	protected EbcCardPay1ApplError(
			int pApplicationErrorCode,
			String pMessage,
			String pParamKey1,
			String pParamValue1,
			String pParamKey2,
			String pParamValue2) {

		this(pApplicationErrorCode, pMessage);
		try {
			this.addParam(new ApplicationErrorParam(pParamKey1, pParamValue1));
			this.addParam(new ApplicationErrorParam(pParamKey2, pParamValue2));
		} catch (IkeaException e) {
			throw new IllegalStateException("This will never happen. It is wrong that ApplicationErrorParam throws IkeaException!");
		}
		mLog.info(
				"Created application error param key '"
						+ pParamKey1
						+ "' and value '"
						+ pParamValue1
						+ "'.");
		mLog.info(
				"Created application error param key '"
						+ pParamKey2
						+ "' and value '"
						+ pParamValue2
						+ "'.");
	}

	// *******************************************************************************************

	/**
	 * 
	 */
	public static class DetailedApplError extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6529548259843231714L;

		public DetailedApplError(String pDetails) {
			super(ApplicationErrorCodes.NON_TRANSLATABLE, pDetails);
		};
	}

	/**
	 * 
	 */
	public static class InvalidInput extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1382965031076375767L;
		public InvalidInput(String pDetails) {
			super(
					ApplicationErrorCodes.INVALID_INPUT_GENERAL,
					"Missing required input value. " + pDetails);
		};
		protected InvalidInput(int pApplicationErrorCode, String pMessage) {
			super(pApplicationErrorCode, pMessage);
		};
	}

	/**
	 * Misssing required card number string as input.
	 */
	public static class MissingCardNumber extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2097521015792811019L;

		public MissingCardNumber() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CARD_NUMBER,
					"Missing card number as input.");
		};
	}
	/**
	 * Misssing required swiped string as input.
	 */
	public static class MissingSwiped extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2097521015792811019L;

		public MissingSwiped() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_SWIPED,
					"Missing swiped as input.");
		};
	}
	/**
	 * Misssing required as input.
	 */
	public static class MissingBusinessUnit extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 9104678328460321582L;

		public MissingBusinessUnit() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BU,
					"Missing business unit as input.");
		};
	}
	/**
	 * Misssing required source system as input.
	 */
	public static class MissingSourceSystem extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2030147209970048500L;

		public MissingSourceSystem() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_SOURCE_SYSTEM,
					"Missing source system as input.");
		};
	}
	/**
	 * Misssing required source system as input.
	 */
	public static class MissingCapture extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2030147209970048500L;

		public MissingCapture() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CAPTURE,
					"Missing capture as input.");
		};
	}
	/**
	 * Misssing required source system as input.
	 */
	public static class MissingReverse extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2030147209970048500L;

		public MissingReverse() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_REVERSE,
					"Missing reverse amount as input.");
		};
	}
	/**
	 * Misssing required originator as input.
	 */
	public static class MissingOriginator extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 451020006782378081L;

		public MissingOriginator() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_ORIGINATOR,
					"Missing originator as input.");
		};
	}
	/**
	 * Misssing required point of sale as input.
	 */
	public static class MissingPointOfSale extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -734002167149630280L;

		public MissingPointOfSale() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_POINT_OF_SALE,
					"Missing point of sale as input.");
		};
	}
	/**
	 * Misssing required Reference as input.
	 */
	public static class MissingReference extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 738769542858057421L;

		public MissingReference() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_REFERENCE,
					"Missing reference as input.");
		};
	}
	/**
	 * Misssing required ReferenceList as input.
	 */
	public static class MissingReferenceList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2019737651293510431L;

		public MissingReferenceList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_REFERENCE,
					"Missing reference list as input.");
		};
	}
	/**
	 * Misssing required TransmissionDate as input.
	 */
	public static class MissingTransmissionDate extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1944232554865502510L;

		public MissingTransmissionDate() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_TRANSMISSION_DATE,
					"Missing transmission date as input.");
		};
	}
	/**
	 * Misssing required Environment as input.
	 */
	public static class MissingEnvironment extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 9131978441998271499L;

		public MissingEnvironment() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_ENVIRONMENT,
					"Missing environment as input.");
		};
	}
	/**
	 * Misssing required amount as input.
	 */
	public static class MissingAmount extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -7971240249521436640L;

		public MissingAmount() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_AMOUNT,
					"Missing amount as input.");
		};
	}

	/**
	 * Misssing required bu type as input.
	 */
	public static class MissingBuType extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -7769509170917993420L;

		public MissingBuType() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BU_TYPE,
					"Missing business unit type as input.");
		};
	}
	/**
	 * Misssing required bu code as input.
	 */
	public static class MissingBuCode extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3770824971664465429L;

		public MissingBuCode() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BU_CODE,
					"Missing business unit code as input.");
		};
	}
	/**
	 * Misssing required KPI interval as input.
	 */
	public static class MissingKPIInterval extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5567787142215735303L;

		public MissingKPIInterval() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_KPI_INTERVAL,
					"Missing KPI interval as input.");
		};
	}
	/**
	 * Misssing required KPI time zone as input.
	 */
	public static class MissingKPITimeZone extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -8004913176466904333L;

		public MissingKPITimeZone() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_KPI_TIME_ZONE,
					"Missing KPI time zone as input.");
		};
	}
	/**
	 * Misssing required report key as input.
	 */
	public static class MissingReportKey extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3108540721039652602L;

		public MissingReportKey() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_REPORT_KEY,
					"Missing report key as input.");
		};
	}
	/**
	 * Misssing required report parameter list as input.
	 */
	public static class MissingReportParameterList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8707035486482422573L;

		public MissingReportParameterList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_REPORT_PARAM_LIST,
					"Missing report parameter list as input.");
		};
	}
	/**
	 * Misssing required description as input.
	 */
	public static class MissingDescription extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1036259092507656944L;

		public MissingDescription() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_DESCRIPTION,
					"Missing description as input.");
		};
	}
	/**
	 * Misssing required transaction no as input.
	 */
	public static class MissingTransactionNo extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2563907678232756499L;

		public MissingTransactionNo() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_TRANSACTION_NO,
					"Missing transaction no as input.");
		};
	}
	/**
	 * Misssing required card number list as input.
	 */
	public static class MissingCardNumberList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 4400947747797091510L;

		public MissingCardNumberList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CARD_NUMBER_LIST,
					"Missing card number list no as input.");
		};
	}
	/**
	 * Misssing required card range name as input.
	 */
	public static class MissingCardRangeName extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3143363873109424084L;

		public MissingCardRangeName() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CARD_RANGE_NAME,
					"Missing card range name as input.");
		};
	}
	/**
	 * Misssing required card range file name as input.
	 */
	public static class MissingCardRangeFileName extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5827826599948253309L;

		public MissingCardRangeFileName() {
			super(
					ApplicationErrorCodes
					.INVALID_INPUT_MISSING_CARD_RANGE_FILE_NAME,
					"Missing card range file name as input.");
		};
	}
	/**
	 * Misssing required card range header as input.
	 */
	public static class MissingCardRangeHeader extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2628375718021185903L;

		public MissingCardRangeHeader() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CARD_RANGE_HEADER,
					"Missing card range header as input.");
		};
	}
	/**
	 * Misssing required country code as input.
	 */
	public static class MissingCountryCode extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2626252996588895896L;

		public MissingCountryCode() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_COUNTRY_CODE,
					"Missing country code as input.");
		};
	}
	/**
	 * Misssing required checksum as input.
	 */
	public static class MissingChecksum extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2961637343269916471L;

		public MissingChecksum() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CHECKSUM,
					"Missing checksum as input.");
		};
	}
	/**
	 * Misssing required currency code as input.
	 */
	public static class MissingCurrencyCode extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 107640796004572214L;

		public MissingCurrencyCode() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CURRENCY_CODE,
					"Missing currency code as input.");
		};
	}
	/**
	 * Misssing required transaction type as input.
	 */
	public static class MissingTransactionType extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1222108877354876844L;

		public MissingTransactionType() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_TRANSACTION_TYPE,
					"Missing transaction type as input.");
		};
	}
	/**
	 * Misssing required campaign as input.
	 */
	public static class MissingCampaign extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -8497044762127604584L;

		public MissingCampaign() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CAMPAIGN,
					"Missing campaign as input.");
		};
	}
	/**
	 * Misssing required mass load as input.
	 */
	public static class MissingMassLoad extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2721581592972758466L;

		public MissingMassLoad() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_MASS_LOAD,
					"Missing mass load as input.");
		};
	}

	/**
	 * Misssing required bonus list as input.
	 */
	public static class MissingBonusCodeList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8265484808391710975L;

		public MissingBonusCodeList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BONUS_CODE_LIST,
					"Missing bonus code list as input.");
		};
	}
	/**
	 * Misssing required bonus list as input.
	 */
	public static class MissingBonusCodeSearch extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1342818225468308917L;

		public MissingBonusCodeSearch() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BONUS_CODE_SEARCH,
					"Missing bonus code search object as input.");
		};
	}

	/**
	 * Misssing required bonus as input.
	 */
	public static class MissingBonus extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8395270605093493728L;

		public MissingBonus() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BONUS_ON_CARD,
					"Missing bonus on card as input.");
		};
	}

	/**
	 * Misssing required bonus as input.
	 */
	public static class MissingBonusKeyList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1271209082020996876L;

		public MissingBonusKeyList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_BONUS_KEY_LIST,
					"Missing bonus key list as input.");
		};
	}

	/**
	 * Misssing required country setup list as input.
	 */
	public static class MissingCountrySetupList extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 4501321981723648081L;

		public MissingCountrySetupList() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_COUNTRY_SETUP_LIST,
					"Missing country setup list as input.");
		};
	}

	/**
	 * Misssing required Campaign Search as input.
	 */
	public static class MissingCampaignSearch extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 550069164728180011L;

		public MissingCampaignSearch() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_CAMPAIGN_SEARCH,
					"Missing campaign search object as input.");
		};
	}

	/**
	 * Misssing required Mass Load Search as input.
	 */
	public static class MissingMassLoadSearch extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1364160825480806022L;

		public MissingMassLoadSearch() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_MASS_LOAD_SEARCH,
					"Missing mass load search object as input.");
		};
	}

	// *******************************************************************************************
	/**
	 * 
	 */
	public static class InvalidCard extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1881184000557568762L;

		public InvalidCard() {
			super(ApplicationErrorCodes.INVALID_CARD_GENERAL, "Invalid card.");
		};
	}

	/**
	 * Card number invalid
	 */
	public static class InvalidCardNumber extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5635785050267708104L;

		public InvalidCardNumber() {
			super(
					ApplicationErrorCodes.INVALID_CARD_INVALID_NUMBER,
					"Invalid card number.");
		};
	}

	/**
	 * VerificationCode invalid (cvv)
	 */
	public static class InvalidVerificationCode extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2703752980097749890L;

		public InvalidVerificationCode() {
			super(
					ApplicationErrorCodes.INVALID_VERIFICATION_CODE,
					"Invalid verification code.");
		};
	}




	/**
	 * Card issuer invalid
	 */
	public static class InvalidCardIssuer extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 5480593206210056260L;

		public InvalidCardIssuer() {
			super(
					ApplicationErrorCodes.INVALID_CARD_INVALID_ISSUER,
					"Invalid card issuer.");
		};
	}
	/**
	 * Card type digit invalid
	 */
	public static class InvalidCardTypeDigit extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1087447130406040371L;

		public InvalidCardTypeDigit() {
			super(
					ApplicationErrorCodes.INVALID_CARD_INVALID_TYPE_DIGIT,
					"Invalid card type digit. ");
		};
	}
	/**
	 * Card type digit invalid
	 */
	public static class InvalidCardCheckDigit extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -6594171312973050370L;

		public InvalidCardCheckDigit() {
			super(
					ApplicationErrorCodes.INVALID_CARD_INVALID_CHECK_DIGIT,
					"Invalid card check digit.");
		};
	}
	/**
	 * Card number invalid
	 */
	public static class DuplicateCard extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6102379838309217263L;

		public DuplicateCard() {
			super(
					ApplicationErrorCodes.INVALID_CARD_DUPLICATE_CARD,
					"Duplicate card.");
		};

	}
	/**
	 * Blocked card
	 */
	public static class BlockedCard extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3804694564812969511L;

		public BlockedCard() {
			super(
					ApplicationErrorCodes.INVALID_CARD_BLOCKED_CARD,
					"Operation not supported for blocked card.");
		};

	}
	/**
	 * Expired card
	 */
	public static class ExpiredCard extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 316609103582116186L;

		public ExpiredCard() {
			super(
					ApplicationErrorCodes.INVALID_CARD_EXPIRED_CARD,
					"Operation not supported for expired card.");
		};

	}
	/**
	 * Not found
	 */
	public static class CardNotFound extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8507828850869351347L;

		public CardNotFound() {
			super(
					ApplicationErrorCodes.INVALID_CARD_NOT_FOUND,
					"Card not found.");
		};

	}

	// *******************************************************************************************
	/**
	 * Amount, currency or amount type is invalid
	 */
	public static class InvalidAmount extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2139799245978483250L;

		public InvalidAmount() {
			super(
					ApplicationErrorCodes.INVALID_AMOUNT_GENERAL,
					"Invalid amount.");
		};
	}

	// *******************************************************************************************
	/**
	 * Authorization is invalid
	 */
	public static class InvalidAuthorization extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -6109087831037616694L;

		public InvalidAuthorization() {
			super(
					ApplicationErrorCodes.INVALID_AUTHORIZATION_GENERAL,
					"Invalid authorization.");
		};
	}

	// *******************************************************************************************
	/**
	 * Privileges is insuffcient
	 */
	public static class InsufficientPrivileges extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3350639842062314701L;

		public InsufficientPrivileges() {
			super(
					ApplicationErrorCodes.INSUFFICIENT_PRIVILEGES,
					"Insufficient privileges.");
		};
	}

	// *******************************************************************************************

	/**
	 * Four Eyes Violation
	 */
	public static class FourEyes extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -6970347848150090653L;

		public FourEyes() {
			super(ApplicationErrorCodes.FOUR_EYES, "Four eyes violation.");
		};
	}

	// *******************************************************************************************

	/**
	 * Campaign is invalid
	 */
	public static class InvalidCampaign extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 7940353333408792114L;

		public InvalidCampaign() {
			super(
					ApplicationErrorCodes.INVALID_CAMPAIGN_GENERAL,
					"Invalid campaign.");
		};
	}

	/**
	 * Campaign is not Authorized
	 */
	public static class CampaignWrongState extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 16168244405641366L;

		public CampaignWrongState() {
			super(
					ApplicationErrorCodes.CAMPAIGN_WRONG_STATE,
					"Campaign is in wrong state.");
		};
	}

	// *******************************************************************************************

	/**
	 * Mass Load is invalid
	 */
	public static class InvalidMassLoad extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3557362104106720691L;

		public InvalidMassLoad() {
			super(
					ApplicationErrorCodes.INVALID_MASS_LOAD_GENERAL,
					"Invalid mass load.");
		};
	}

	/**
	 * Mass Load is not Authorized
	 */
	public static class MassLoadWrongState extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -8849320496795284134L;

		public MassLoadWrongState() {
			super(
					ApplicationErrorCodes.MASS_LOAD_WRONG_STATE,
					"Mass load is in wrong state.");
		};
	}

	// *******************************************************************************************

	/**
	 * Bonus is invalid
	 */
	public static class InvalidBonusCode extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 5706325711204146664L;

		public InvalidBonusCode() {
			super(
					ApplicationErrorCodes.INVALID_BONUS_CODE_GENERAL,
					"Invalid bonus code.");
		};
	}

	public static class DuplicateBonusCode extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 702841577215767228L;

		public DuplicateBonusCode() {
			super(
					ApplicationErrorCodes.INVALID_BONUS_CODE_DUPLICATE,
					"Duplicate bonus code.");
		};
	}

	// *******************************************************************************************

	/**
	 * Country Setup is invalid
	 */
	public static class InvalidCountrySetup extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 7181999130002937083L;

		public InvalidCountrySetup() {
			super(
					ApplicationErrorCodes.INVALID_COUNTRY_SETUP_GENERAL,
					"Invalid country setup.");
		};
	}

	// *******************************************************************************************
	/**
	 * Transaction is invalid
	 */
	public static class InvalidTransaction extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1812350742019306842L;

		public InvalidTransaction() {
			super(
					ApplicationErrorCodes.INVALID_TRANSACTION_GENERAL,
					"Invalid transaction.");
		};
	}

	// *******************************************************************************************
	/**
	 * Refrerence check
	 */
	public static class ReferenceAlreadyExists extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -643898126089957549L;

		public ReferenceAlreadyExists(
				String pSourceSystem,
				String pReference) {
			super(
					ApplicationErrorCodes.INVALID_REFERENCE_CHECK_GENERAL,
					"Reference already exists.",
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_SOURCE_SYSTEM,
					pSourceSystem,
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_REFERENCE,
					pReference);
		};
	}
	/**
	 * Refrerence check
	 */
	public static class ReferenceAlreadyAcknowledged
	extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -904537891915850665L;

		public ReferenceAlreadyAcknowledged(
				String pSourceSystem,
				String pReference,
				String pSalesDay) {
			super(
					ApplicationErrorCodes.REFERENCE_CHECK_ALREADY_ACKNOWLEDGED,
					"Reference already acknowledged.",
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_SOURCE_SYSTEM,
					pSourceSystem,
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_REFERENCE,
					pReference);
		};
	}
	
	/**
	 * Refrerence check
	 */
	public static class ReferenceCancelled
	extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -904537891915850665L;

		public ReferenceCancelled(
				String pSourceSystem,
				String pReference,
				String pSalesDay) {
			super(
					ApplicationErrorCodes.REFERENCE_CHECK_CANCELLED,
					"Reference is cancelled.",
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_SOURCE_SYSTEM,
					pSourceSystem,
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_REFERENCE,
					pReference);
		};
	}
	
	/**
	 * Refrerence check
	 */
	public static class ReferenceNotFound extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8483791555655100546L;

		public ReferenceNotFound(
				String pSourceSystem,
				String pReference,
				String pSalesDay) {
			super(
					ApplicationErrorCodes.REFERENCE_CHECK_NOT_FOUND,
					"Reference not found.",
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_SOURCE_SYSTEM,
					pSourceSystem,
					ApplicationErrorCodes.REFERENCE_CHECK_PARAM_KEY_REFERENCE,
					pReference);
		};
	}

	/**
	 * Refrerence check
	 */
	public static class RangeNotFound extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -7187493071432365666L;

		public RangeNotFound() {
			super(
					ApplicationErrorCodes.INVALID_CAMPAIGN_GENERAL,
					"Range not found.");
		};
	}


	// *******************************************************************************************
	/**
	 * Date set as from date can never be set before todays date.
	 */
	public static class InvalidFromDate extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -4547594913284849500L;

		public InvalidFromDate() {
			super(
					ApplicationErrorCodes.INVALID_FROM_DATE,
					"The from date cannot be earlier than todays date.");
		};
	}

	// *******************************************************************************************
	/**
	 * An exchange rate from currency must exist as main currency.
	 */
	public static class InvalidFromCurrency extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 7138126784044217499L;

		public InvalidFromCurrency() {
			super(
					ApplicationErrorCodes.INVALID_FROM_CURRENCY,
					"Invalid from currency.");
		};
	}

	// *******************************************************************************************
	/**
	 * An exchange rate to currency cannot be the same as from currency.
	 */
	public static class InvalidToCurrency extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 4268247832165069260L;

		public InvalidToCurrency() {
			super(
					ApplicationErrorCodes.INVALID_TO_CURRENCY,
					"Invalid from date to currency");
		};
	}

	// *******************************************************************************************

	/**
	 * Report is invalid
	 */
	public static class InvalidReport extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 8320429998123113141L;

		public InvalidReport() {
			super(
					ApplicationErrorCodes.INVALID_REPORT_GENERAL,
					"Invalid report.");
		};
	}

	// *******************************************************************************************
	/**
	 * An From date cannot be greater than To date.
	 */
	public static class InvalidFromToDate extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = -2079267608721230311L;

		public InvalidFromToDate() {
			super(
					ApplicationErrorCodes.INVALID_FROM_DATE,
					"Invalid from date, from date greater than to date");
		};
	}

	// *******************************************************************************************
	/**
	 * Authorization amount is invalid. No authorization available when card balance is '0'.
	 */
	public static class InvalidAuthorizationAmount extends EbcCardPay1ApplError {
		/**
		 * 
		 */
		private static final long serialVersionUID = 6592207138736222311L;

		public InvalidAuthorizationAmount() {
			super(
					ApplicationErrorCodes.INVALID_AUTHORIZATION_AMOUNT,
					"Invalid authorization. Card balance is '0'.");
		};
	}

	/**
	 * Missing required Multiple Single Load as input.
	 */
	public static class MissingMultipleSingleLoad extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3599759823282593159L;

		public MissingMultipleSingleLoad() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_MULTIPLE_SINGLE_LOAD,
					"Missing multiple single load as input.");
		};
	}

	/**
	 * Misssing required Multiple Single Load Search as input.
	 */
	public static class MissingMultipleSingleLoadSearch extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -9013234491331907050L;

		public MissingMultipleSingleLoadSearch() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_MULTIPLE_SINGLE_LOAD_SEARCH,
					"Missing multiple single load search object as input.");
		};
	}

	/**
	 * Misssing required Multiple Single Load Key as input.
	 */
	public static class MissingMultipleSingleLoadKey extends InvalidInput {
		/**
		 * 
		 */
		private static final long serialVersionUID = -9013234491331907050L;

		public MissingMultipleSingleLoadKey() {
			super(
					ApplicationErrorCodes.INVALID_INPUT_MISSING_MULTIPLE_SINGLE_LOAD_KEY,
					"Missing multiple single load key object as input.");
		};
	}

	/* PR-IKEA01082411 use one Error Code for all Foreign cards exception
	public static class InvalidPromotionalCard extends EbcCardPay1ApplError {
		private static final long serialVersionUID = 2139799245978483250L;

		public InvalidPromotionalCard() {
			super(
					ApplicationErrorCodes.PROMOTIONAL_CARD_NOT_VALID,
					"Card is not supported for this country. Please try other card");
		}

	};
	 */
	// Created Application Error Invalid Foreign code and Error Message Modified
	public static class InvalidForeignCard extends EbcCardPay1ApplError {
		private static final long serialVersionUID = 2139799245978483250L;

		public InvalidForeignCard() {
			super(
					ApplicationErrorCodes.INVALID_FOREIGN_CARD,
					"This Card is not valid for this Country. Please try other Cards ");
		}

	};

	public static class InvalidExternalSourceSystem extends EbcCardPay1ApplError {
		private static final long serialVersionUID = 2139799245978483250L;

		public InvalidExternalSourceSystem() {
			super(
					ApplicationErrorCodes.INVALID_EXTERNAL_SOURCE_SYSTEM,
					"External Source System cannot be configured with provided details");
		}

	};

	public static class WrongOrder extends EbcCardPay1ApplError {

		/**
		 * 
		 */
		private static final long serialVersionUID = 6102379838309217263L;

		public WrongOrder() {
			super(
					ApplicationErrorCodes.WRONG_ISELL_ORDER,
					"Wrong iSell order number");
		};

	}

	public static class NocardsAttached extends EbcCardPay1ApplError {

		/**
		 * 
		 */
		private static final long serialVersionUID = 6102379838309217263L;

		public NocardsAttached() {
			super(
					ApplicationErrorCodes.NoCardsAttached,
					"No iPay Cards Attached to the Given Order");
		};

	}

	public static class InvalidPosDate extends EbcCardPay1ApplError {

		/**
		 * 
		 */
		private static final long serialVersionUID = 6102379838309217263L;

		public InvalidPosDate() {
			super(
					ApplicationErrorCodes.WRONG_POS_EXPIRE_DATE,
					"Invalid Expire Date Received from Pos Machine");
		};

	}

}
