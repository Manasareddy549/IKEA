package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

public class BusinessUnitEnvironmentImpl implements BusinessUnitEnvironment {

	/**
	 * Dependency
	 */
	String mBuType;
	String mBuCode;
	Units mUnits;
	TimeSource mTimeSource;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;
	/*
	 * Internals
	 */
	String mSalesDay = null;
	Date mSalesDateTime = null;

	/**
	 * Dependency injection
	 */
	protected BusinessUnitEnvironmentImpl(
		String pBuType,
		String pBuCode,
		Units pUnits,
		TimeSource pTimeSource,BefIpayBusinessUnits pBefIpayBusinessUnits) {

		mBuType = pBuType;
		mBuCode = pBuCode;
		mUnits = pUnits;
		mTimeSource = pTimeSource;
		mBefIpayBusinessUnits=pBefIpayBusinessUnits;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getBuType()
	 */
	public String getBuType() {
		return mBuType;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getBuCode()
	 */
	public String getBuCode() {
		return mBuCode;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getCountryCode()
	 */
	public String getCountryCode() {
		return mUnits.getCountryCode(getBuType(), getBuCode());
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getSalesDateTime()
	 */
	public Date getSalesDateTime() {
		if (mSalesDateTime == null) {
			mSalesDateTime = mTimeSource.currentDate();
		}
		return mSalesDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getSalesDay()
	 */
	public String getSalesDay() {

		if (mSalesDay == null) {
			// Calculate the sales day once and then reuse the result through out this transaction so we get the same.
			// Updated by srder to pass parameter iPayBusinessunits
			mSalesDay =
				Dates.calculateSalesDay(
					mUnits,
					getSalesDateTime(),
					mBuType,
					mBuCode,
					mBefIpayBusinessUnits);
		}

		return mSalesDay;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment#getCountryCode()
	 */
	public String getCompanyCode() {
		return mUnits.getCompanyCode(getBuType(), getBuCode());
	}
	public BefIpayBusinessUnits getBefIpayBusinessUnits() {
		return mBefIpayBusinessUnits;
	}
}
