package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author saic
 * @author hned
 *
 */
public class BefMultipleSingleLoadImpl extends BefAbstract<MultipleSingleLoad> implements BefMultipleSingleLoad {

	private final static Logger mLog_findByUnauthorized = LoggerFactory
			.getLogger(BefBonusImpl.class.getName() + ".findByUnauthorized");

	private final static Logger mLog_findBySearch = LoggerFactory
			.getLogger(BefMultipleSingleLoadImpl.class.getName()
					+ ".findBySearch");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefMultipleSingleLoadImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefMultipleSingleLoad#findBySearch(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<MultipleSingleLoad> findBySearch(
		String pNameLike,
		String pBuType,
		String pBuCode,
		String pCountryCode,
		Date pCreatedDateTime) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MultipleSingleLoad> vCriteria = new GenericCriteria<MultipleSingleLoad>(vSession.createCriteria(MultipleSingleLoad.class));

		if (pNameLike != null && pNameLike.length() > 0) {
			vCriteria.add(Restrictions.like("name", "%" + pNameLike + "%"));
		}
		if (pBuType != null && pBuType.length() > 0) {
			vCriteria.add(Restrictions.eq("buType", pBuType));
		}
		if (pBuCode != null && pBuCode.length() > 0) {
			vCriteria.add(Restrictions.eq("buCode", pBuCode));
		}
		if (pCountryCode != null && pCountryCode.length() > 0) {
			vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		}

		if (pCreatedDateTime != null) {
			vCriteria.add(Restrictions.ge("createdDateTime", pCreatedDateTime));
		}

		if (mLog_findBySearch.isDebugEnabled()) {
			mLog_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<MultipleSingleLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mLog_findBySearch.info("No mass loads found.");
		} else {
			mLog_findBySearch.info(
				"Found " + vList.size() + " mass loads.");
		}

		return vList;
	}
	
	public List<MultipleSingleLoad> findByUnauthorized(String pCountryCode) {
		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MultipleSingleLoad> vCriteria = new GenericCriteria<MultipleSingleLoad>(vSession
				.createCriteria(MultipleSingleLoad.class));
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria.add(Restrictions.isNull("authorizedDateTime"));

		// To get just one per bonus
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mLog_findByUnauthorized.isDebugEnabled()) {
			mLog_findByUnauthorized.debug("Criteria: "
					+ vCriteria.toString());
		}

		List<MultipleSingleLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mLog_findByUnauthorized.info("No multiple single loads found.");
		} else {
			mLog_findByUnauthorized.info("Found " + vList.size()
					+ " multiple single loads.");
		}
		return vList;
	}

	@Override
	protected Class<MultipleSingleLoad> getBusinessEntityClass() {
		return MultipleSingleLoad.class;
	}

}
