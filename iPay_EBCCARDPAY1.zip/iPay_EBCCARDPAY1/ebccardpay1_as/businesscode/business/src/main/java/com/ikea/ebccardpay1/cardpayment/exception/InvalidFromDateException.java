/*
 * Created on 2007-sep-06
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *
 */
public class InvalidFromDateException extends CurrencyException {


	/**
	 * 
	 */
	private static final long serialVersionUID = 7782787161435502311L;

	public InvalidFromDateException(String pMessage) {
		super(pMessage);
	}

	/**
	 * 
	 */
	public InvalidFromDateException() {
		super();

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.exception.MainCurrencyException#createApplicationError()
	 */
	public ApplicationError createApplicationError() {
		
		return new EbcCardPay1ApplError.InvalidFromDate();
	}


}
