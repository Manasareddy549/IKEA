package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.BsLog;

public class BefBsLogImpl extends BefAbstract<BsLog> implements BefBsLog{
	
	private final static Logger mLogger_findByReference =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByReference");

	private final static Logger mLogger_findByOriginator =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByOriginator");
	
	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefBsLogImpl(
			SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<BsLog> getBusinessEntityClass() {
		return BsLog.class;
	}

}
