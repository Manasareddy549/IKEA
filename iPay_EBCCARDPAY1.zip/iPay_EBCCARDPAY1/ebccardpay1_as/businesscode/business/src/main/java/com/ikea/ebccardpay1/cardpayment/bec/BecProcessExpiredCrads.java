package com.ikea.ebccardpay1.cardpayment.bec;



public interface BecProcessExpiredCrads {

	public int getCardSize() throws Exception;

	public void processExpiredCards();
	
	


	
	
}
