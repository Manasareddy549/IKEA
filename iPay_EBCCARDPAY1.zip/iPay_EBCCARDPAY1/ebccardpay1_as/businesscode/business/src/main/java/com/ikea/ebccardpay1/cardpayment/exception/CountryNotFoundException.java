/*
 * Created on 2007-sep-10
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author dalq
 *
 *
 */
public class CountryNotFoundException extends CurrencyException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 959753564290184081L;

	/**
	 * 
	 */
	public CountryNotFoundException() {
		super();

	}

	/**
	 * 
	 * @param pMessage
	 */
	public CountryNotFoundException(String pMessage) {
		super(pMessage);
	}

}
