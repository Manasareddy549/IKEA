package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoadInitial;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author Henrik Reinhold
 *
 */
public interface BecMultipleSingleLoad {

	MultipleSingleLoad loadCards(VoMultipleSingleLoadInitial pVoMultipleSingleLoadInitial)throws IkeaException,InvalidCardNumberException;
	
	MultipleSingleLoad authorize(long pMultipleSingleLoadId)throws ValueMissingException, CardPayException, IkeaException;

	void delete(long pMultipleSingleLoadId);
	
}
