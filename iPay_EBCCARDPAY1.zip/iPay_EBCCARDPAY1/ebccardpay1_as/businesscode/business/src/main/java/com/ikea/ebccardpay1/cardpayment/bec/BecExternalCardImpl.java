/*
 * Created on 2007-aug-09
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCard;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.ExternalCardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
/**
 * @author anms
 *
 */
public class BecExternalCardImpl implements BecExternalCard {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecExternalCardImpl.class);

	// Dependencies injected at creation of this BEC
	private BefExternalCard mBefExternalCard;
	private BecExternalCardSystem mBecExternalCardSystem;
	private BecFactory mBecFactory;
	private UtilsFactory mUtilsFactory;
	private Units mUnits;

	// Entities that this BEC operates on
	private ExternalCard mExternalCard;

	// Related Bec's that this Bec delegates work to (not dependancy injected, created when needed)
	private BecCard mBecCard;

	/**
	 * 
	 */
	public BecExternalCardImpl(
		BefExternalCard pBefExternalCard,
		BecExternalCardSystem pBecExternalCardSystem,
		BecFactory pBecFactory,
		UtilsFactory pUtilsFactory,
		Units pUnits) {

		super();
		mBefExternalCard = pBefExternalCard;
		mBecExternalCardSystem = pBecExternalCardSystem;
		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
		mUnits = pUnits;
	}
	
	void validate() {
		notNull(mBefExternalCard);
		notNull(mBecExternalCardSystem);
		notNull(mBecFactory);
		notNull(mUtilsFactory);
		notNull(mUnits);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#init(com.ikea.ebccardpay1.cardpayment.be.ExternalCard)
	 */
	public BecExternalCard init(ExternalCard pExternalCard) {

		mExternalCard = pExternalCard;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#init(String)
	 */
	public BecExternalCard init(String pExternalCardSystemName) {

		mBecExternalCardSystem.init(pExternalCardSystemName);
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#findExternal(java.lang.String)
	 */
	public void findExternal(String pExternalCardNumberString)
		throws ExternalCardNotFoundException, InvalidCardNumberException {

		mCategory.info("Finding card based on external card number");
		List<ExternalCard> vList =
			mBefExternalCard.findByExternal(
				pExternalCardNumberString,
				mBecExternalCardSystem.getExternalCardSystem());

		if (vList == null || vList.size() == 0) {
			throw new ExternalCardNotFoundException("External card number not found.");
		}

		if (vList.size() > 1) {
			String vSystem = "";
			if (mBecExternalCardSystem.getExternalCardSystem() != null) {
				vSystem += " and external card system '"
					+ mBecExternalCardSystem.getExternalCardSystem().getName()
					+ "'";
			}
			throw new InvalidCardNumberException(
				"Found more than one external card for card number string '"
					+ pExternalCardNumberString
					+ "' "
					+ vSystem);
		}

		mExternalCard = vList.get(0);

		if (!Constants
			.IMPORT_STATE_CONSTANT_COMPLETED
			.equals(mExternalCard.getExternalCardSystem().getImportState())) {
			mCategory.info(
				"Found external card but import state is '"
					+ mExternalCard.getExternalCardSystem().getImportState()
					+ "'. Can not use this card, will send back ExternalCardNotFoundException to requester.");
			throw new InvalidCardNumberException(
				"Found external card but import state is '"
					+ mExternalCard.getExternalCardSystem().getImportState()
					+ "'.");
		}
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#getExternalCard()
	 */
	public ExternalCard getExternalCard() {
		return mExternalCard;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#createInternalFromExternal()
	 */
	public Card createInternalFromExternal()
		throws ValueMissingException, InvalidCardNumberException, IkeaException {

		requireExternalCard();
		setupBecCard();
		mBecCard.createFromExternal(
			internalCardNumber(),
			mExternalCard,
			mExternalCard.getExternalCardSystem());
		String source=mExternalCard.getExternalCardSystem().getName();
		if(source.equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_GIVEX) || source.equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_VALUE_LINK))
		{
		loadFromExternal();
		}
		else{
			loadFromExternalSourceSystem();
		}
		mExternalCard.connectCard(mBecCard.getCard());
		return mBecCard.getCard();
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void setupBecCard() throws ValueMissingException {

		requireExternalCard();
		BusinessUnitEnvironment vBusinessUnitEnvironment =
			mUtilsFactory.createBusinessUnitEnvironment(
				mExternalCard.getBuType(),
				mExternalCard.getBuCode());
		TransactionEnvironment vTransactionEnvironment =
			mUtilsFactory.createTransactionEnvironment(
				Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL,
				null);
		mBecCard =
			mBecFactory.createBecCard().init(
				vBusinessUnitEnvironment,
				vTransactionEnvironment);
	}

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 * @throws InvalidCardNumberException
	 */
	protected CardNumber internalCardNumber()
		throws ValueMissingException, InvalidCardNumberException {

		requireExternalCard();
		mCategory.info(
			"Getting next available card number for this external card system");
		mBecExternalCardSystem.init(mExternalCard.getExternalCardSystem());
		return mBecExternalCardSystem.nextAvailableInternalNumber();
	}

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 */
	protected void loadFromExternal() throws ValueMissingException, IkeaException {

		mCategory.info("Loading with amount from external card");
		requireExternalCard();
		requireBecCard();
		try {
			VoLoadAmount pVoLoadAmount = new VoLoadAmount();
			pVoLoadAmount.setAmountType(
				Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
			pVoLoadAmount.setCurrencyCode(mExternalCard.getCurrencyCode());
			pVoLoadAmount.setLoadAmount(mExternalCard.getOriginalBalance());
			
			mBecCard.loadExternalAmount(pVoLoadAmount,"Valuex/Givex");
		} catch (CardPayException e) {
			// It should not go wrong when converting an external to an internal, but if it does abort.
			throw new RuntimeException(
				"Failed to load amount to the internal card for this external card number '"
					+ mExternalCard.getCardNumberString()
					+ "'.",
				e);
		}
	}
	
	protected void loadFromExternalSourceSystem() throws ValueMissingException, IkeaException {

		mCategory.info("Loading with amount from external card");
		requireExternalCard();
		requireBecCard();
		try {
			VoLoadAmount pVoLoadAmount = new VoLoadAmount();
			pVoLoadAmount.setAmountType(mExternalCard.getExternalCardSystem().getAmountType());
			pVoLoadAmount.setCurrencyCode(mExternalCard.getCurrencyCode());
			pVoLoadAmount.setLoadAmount(mExternalCard.getOriginalBalance());
			mBecCard.loadExternalAmount(pVoLoadAmount,Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL);
		} catch (CardPayException e) {
			// It should not go wrong when converting an external to an internal, but if it does abort.
			throw new RuntimeException(
				"Failed to load amount to the internal card for this external card number '"
					+ mExternalCard.getCardNumberString()
					+ "'.",
				e);
		}
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#createExternalCard(com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard, com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem)
	 */
	public void createExternalCard(
		VoExternalCard pVoExternalCard,
		ExternalCardSystem pExternalCardSystem)
		throws InvalidCardNumberException, ValueMissingException {

		// Create new Entity object
		mExternalCard = mBefExternalCard.create();
		// Copy VO object to Entity
		ValueObjects.assignToBusinessEntity(mExternalCard, pVoExternalCard);

		// Check card number string with the regexp before save
		checkNumberRegExp(pExternalCardSystem.getCardNumberPattern());

		// Check BU
		checkBu();

		// Connect ExternalCard to applied ExternalCardSystem	
		mExternalCard.setExternalCardSystem(pExternalCardSystem);
		// Save ExternalCard
		mBefExternalCard.save(mExternalCard);
		if (mCategory.isDebugEnabled()) {
			mCategory.debug(
				"ExternalCard saved:  CardNumber:"
					+ pVoExternalCard.getCardNumberString()
					+ " OriginalBalance:"
					+ pVoExternalCard.getOriginalBalance()
					+ " CurrencyCode:"
					+ pVoExternalCard.getCurrencyCode());
		}
	}

	/**
	 * 
	 * @param pExternalCardNumber
	 * @param pRegExp
	 * @throws InvalidCardNumberException
	 */
	protected void checkNumberRegExp(String pRegExp)
		throws InvalidCardNumberException, ValueMissingException {

		requireExternalCard();

		// Do not check if regexp is not provided
		if (pRegExp == null) {
			return;
		}

		// Does the external card number match the regexp?
		if (!mExternalCard.getCardNumberString().matches(pRegExp)) {
			throw new InvalidCardNumberException(
				"The external card number string '"
					+ mExternalCard.getCardNumberString()
					+ "' does not match the regexp '"
					+ pRegExp
					+ "'.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void checkBu() throws ValueMissingException {

		requireExternalCard();
		mUnits.checkValidBusinessUnit(
			mExternalCard.getBuType(),
			mExternalCard.getBuCode());
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireExternalCard() throws ValueMissingException {
		if (mExternalCard == null)
			throw new ValueMissingException("Tried to use BecExternalCard without required ExternalCard.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBecCard() throws ValueMissingException {
		if (mBecCard == null)
			throw new ValueMissingException("Tried to use method in BecExternalCard without required BecCard.");
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCard#deleteNotCompleted(com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem)
	 */
	public int deleteNotCompleted(ExternalCardSystem mExternalCardSystem) {
		// Delete not completed external cards
		return mBefExternalCard.deleteNotCompleted(mExternalCardSystem);

	}

}
