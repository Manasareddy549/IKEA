package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.HashMap;
import java.util.Map;

public class CbdExchangeRatesForCurrencies {

	private Map<String, CbdExchangeRates> ratesForCurrencies = new HashMap<String, CbdExchangeRates>();
	
	public void setExchangeRatesForCurrency(String currencyCode, CbdExchangeRates rates){
		ratesForCurrencies.put(currencyCode, rates);
	}
	
	public CbdExchangeRates getRatesForCurrency(String currencyCode){
		return ratesForCurrencies.get(currencyCode);
	}
	
}
