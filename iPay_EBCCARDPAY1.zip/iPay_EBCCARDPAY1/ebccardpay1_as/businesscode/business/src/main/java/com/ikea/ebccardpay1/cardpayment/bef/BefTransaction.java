/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefTransaction extends Bef<Transaction>{

	public java.util.List<Transaction> findByTransactionNo(long pTransactionNo);
	
	public Transaction findByTransactionNumber(long pTransactionNo);

	public java.util.List<Transaction> findByOriginator(String pBuType, String pBuCode, String pSourceSystem, String pPointOfSale, String pSalesDay, String pReceipt, Card pCard);

	public java.util.List<Transaction> findByReference(String pReference, String pSourceSystem);
	
	public void deleteLoadCampaignTransaction(Campaign pCampaign) throws Exception;
	
	public void deleteByMassload(MassLoad pMassLoad) throws Exception;
	
	public java.util.List<Transaction> findByReciept(String pReciept,String pBuType, String pBuCode,String psalesDay);

	
	}