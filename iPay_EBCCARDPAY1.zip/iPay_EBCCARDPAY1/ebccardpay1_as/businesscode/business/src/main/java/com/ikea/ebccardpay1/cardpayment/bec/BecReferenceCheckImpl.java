package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.be.UnacknowledgedTimeout;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceAlreadyAcknowledged;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceAlreadyExistsException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCancelled;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCancelled;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceNotFound;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.Publisher;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.entities.Data;
import com.ikea.ebccardpay1.cardpayment.utils.entities.EBCPAYLOAD;
import com.ikea.ebccardpay1.cardpayment.vo.VoCapture;
import com.ikea.ebccardpay1.cardpayment.vo.VoEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoReferenceAckTimeOut;
import com.ikea.ebccardpay1.cardpayment.vo.VoReferenceSpecifier;
import com.ikea.ebccardpay1.cardpayment.vo.VoReverse;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;

public class BecReferenceCheckImpl implements BecReferenceCheck {

	private final static Logger mCategory =
			LoggerFactory.getLogger(BecReferenceCheckImpl.class);

	/**
	 * Dependencies
	 */
	private BefReferenceCheck mBefReferenceCheck;

	// Entities that this BEC operates on
	private Card mCard;
	private Amount mAmount = null;
	private MassLoad mMassLoad  = null;
	// Related Bec's that this Bec delegates work to
	BecTransactions mBecTransactions = null;
	BecReservedCardHistory mBecReservedCardHistory = null;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;
	private BecFactory mBecFactory = null;
	private EncryptionDecryption mEncryptionDecryption = null;

	private Publisher mPublisher = null;
	private EbcProperties mEbcProperties;
	private BefTransaction mBefTransaction = null;
	private BefReservedCardHistory mBefReservedCardHistory=null;
	private BefCard mBefCard=null;
	private BefAmount mBefAmount=null;


	/**
	 * Dependecy injection
	 *  
	 */

	protected BecReferenceCheckImpl(
			BecTransactions pBecTransactions,
			BefReferenceCheck pBefReferenceCheck,
			BecFactory pBecFactory, EbcProperties pEbcProperties, BefReservedCardHistory pBefReservedCardHistory,
			BefTransaction pBefTransaction,
			BefCard pBefCard, BefAmount pBefAmount,Publisher pPublisher, EncryptionDecryption pEncryptionDecryption,
			BecReservedCardHistory pBecReservedCardHistory) {

		mBecTransactions = pBecTransactions;
		mBefReferenceCheck = pBefReferenceCheck;
		mBecFactory = pBecFactory;
		mEbcProperties = pEbcProperties;
		mBefReservedCardHistory = pBefReservedCardHistory;
		mBefTransaction = pBefTransaction;
		mBefCard = pBefCard;
		mBefAmount = pBefAmount;
		mPublisher = pPublisher;
		mEncryptionDecryption = pEncryptionDecryption;
		mBecReservedCardHistory = pBecReservedCardHistory;
	}

	void validate() {
		notNull(mBecTransactions);
		notNull(mBefReferenceCheck);
		notNull(mBecFactory);
		notNull(mBecFactory);
		notNull(mBefReservedCardHistory);
		notNull(mBefTransaction);
		notNull(mBefCard);
		notNull(mBefAmount);
		notNull(mPublisher);
		notNull(mBecReservedCardHistory);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#init(com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecReferenceCheck init(
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		return init(null, pBusinessUnitEnvironment, pTransactionEnvironment);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#init(com.ikea.ebccardpay1.cardpayment.be.Card, com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecReferenceCheck init(
			Card pCard,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		mBecTransactions.init(
				mBusinessUnitEnvironment,
				mTransactionEnvironment);

		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#checkAndCreate()
	 */
	public void checkAndCreate(boolean pManual)
			throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException {

		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Check if Reference already exists
		if(!mTransactionEnvironment.getSourceSystem().equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL))
		{
			checkReferences();

			// Create new reference
			ReferenceCheck vReferenceCheck = mBefReferenceCheck.create();
			vReferenceCheck.setWaitingAck(
					!mTransactionEnvironment.getAutoAcknowledge());
			vReferenceCheck.setReference(mTransactionEnvironment.getReference());
			vReferenceCheck.setSourceSystem(
					mTransactionEnvironment.getSourceSystem());
			vReferenceCheck.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

			// Set info for identifi�ing the receipt
			vReferenceCheck.setBuType(mBusinessUnitEnvironment.getBuType());
			vReferenceCheck.setBuCode(mBusinessUnitEnvironment.getBuCode());

			vReferenceCheck.setPointOfSale(
					mTransactionEnvironment.getPointOfSale());
			if (pManual) {
				vReferenceCheck.setReceipt("manual");
			} else {
				vReferenceCheck.setReceipt(mTransactionEnvironment.getReceipt());
			}

			vReferenceCheck.setTransactionNo(
					mTransactionEnvironment.getTransactionNo());
			vReferenceCheck.setCard(mCard);
			if(!mTransactionEnvironment.getAutoAcknowledge()){

				long timeOutValueInSeconds =mTransactionEnvironment.getAckTimeout();

				UnacknowledgedTimeout vUnacknowledgedTimeout =null;
				BecUnacknowledgedTimeout vBecUnacknowledgedTimeout = mBecFactory.createBecUnacknowledgedTimeout();
				try {
					vUnacknowledgedTimeout =vBecUnacknowledgedTimeout.getUnacknowledgedTimeout(mBusinessUnitEnvironment.getBuCode(),mBusinessUnitEnvironment.getBuType(),mTransactionEnvironment.getSourceSystem());

				} catch (UnacknowledgedTimeoutException e) {
					throw new UnacknowledgedTimeoutException("Ecxeption occured in UnacknowledgegTimeout");
				}
				if (timeOutValueInSeconds>0){
					vReferenceCheck.setAckTimeout(timeOutValueInSeconds);
				}else if (vUnacknowledgedTimeout!=null && vUnacknowledgedTimeout.getTimeoutSec()>0){
					vReferenceCheck.setAckTimeout(vUnacknowledgedTimeout.getTimeoutSec());
				}
				//hard coding the AckTimeOut to one hour
				else{
					vReferenceCheck.setAckTimeout(3600);
				}

			}
			mBefReferenceCheck.save(vReferenceCheck);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#checkAndCreate()
	 */
	public void checkAndCreateVoid(boolean pManual)
			throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException {

		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Check if Reference already exists
		if(!mTransactionEnvironment.getSourceSystem().equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL))
		{
			checkReferences();

			// Create new reference
			ReferenceCheck vReferenceCheck = mBefReferenceCheck.create();
			vReferenceCheck.setWaitingAck(false);
			vReferenceCheck.setReference(mTransactionEnvironment.getReference());
			vReferenceCheck.setSourceSystem(
					mTransactionEnvironment.getSourceSystem());
			vReferenceCheck.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

			// Set info for identifi�ing the receipt
			vReferenceCheck.setBuType(mBusinessUnitEnvironment.getBuType());
			vReferenceCheck.setBuCode(mBusinessUnitEnvironment.getBuCode());

			vReferenceCheck.setPointOfSale(
					mTransactionEnvironment.getPointOfSale());
			if (pManual) {
				vReferenceCheck.setReceipt("manual");
			} else {
				vReferenceCheck.setReceipt(mTransactionEnvironment.getReceipt());
			}

			vReferenceCheck.setTransactionNo(
					mTransactionEnvironment.getTransactionNo());
			vReferenceCheck.setCard(mCard);
			if(!mTransactionEnvironment.getAutoAcknowledge()){

				long timeOutValueInSeconds =mTransactionEnvironment.getAckTimeout();

				UnacknowledgedTimeout vUnacknowledgedTimeout =null;
				BecUnacknowledgedTimeout vBecUnacknowledgedTimeout = mBecFactory.createBecUnacknowledgedTimeout();
				try {
					vUnacknowledgedTimeout =vBecUnacknowledgedTimeout.getUnacknowledgedTimeout(mBusinessUnitEnvironment.getBuCode(),mBusinessUnitEnvironment.getBuType(),mTransactionEnvironment.getSourceSystem());

				} catch (UnacknowledgedTimeoutException e) {
					throw new UnacknowledgedTimeoutException("Ecxeption occured in UnacknowledgegTimeout");
				}
				if (timeOutValueInSeconds>0){
					vReferenceCheck.setAckTimeout(timeOutValueInSeconds);
				}else if (vUnacknowledgedTimeout!=null && vUnacknowledgedTimeout.getTimeoutSec()>0){
					vReferenceCheck.setAckTimeout(vUnacknowledgedTimeout.getTimeoutSec());
				}
				//hard coding the AckTimeOut to one hour
				else{
					vReferenceCheck.setAckTimeout(3600);
				}

			}
			mBefReferenceCheck.save(vReferenceCheck);
		}
	}
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#isReferenceWaitingForAcknowledgement()
	 */
	public boolean isReferenceWaitingForAcknowledgement(VoReferenceSpecifier pVoReferenceSpecifier)
			throws ReferenceCheckException, ValueMissingException {

		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();
		// Find the old reference, we must be within the same source system and salesDay
		String vRef = pVoReferenceSpecifier.getReference();
		String vSource = mTransactionEnvironment.getSourceSystem();
		String vSalesDay;
		if(filterSourceSystemForTransmissionDate()){
			vSalesDay = mBusinessUnitEnvironment.getSalesDay();
		}else{
			vSalesDay = (mTransactionEnvironment.getTransmissionDateTime()).toString();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			vSalesDay = formatter.format(mTransactionEnvironment.getTransmissionDateTime());
		}
		ReferenceCheck vReferenceCheck =
				//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
				mBefReferenceCheck.findByReference(vRef, vSource);
		if (vReferenceCheck == null) {
			throw new ReferenceNotFound(vSource, vRef);
		}else if (vReferenceCheck.getWaitingAck()) {
			return true; 
		}  
		return false;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#acknowledge()
	 */
	public void acknowledge(VoReferenceSpecifier pVoReferenceSpecifier, VoCapture pVoCapture)
			throws ReferenceCheckException, ValueMissingException, AmountException {

		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();
		
		// Find the old reference, we must be within the same source system and salesDay
		String vRef = pVoReferenceSpecifier.getReference();
		String vSource = mTransactionEnvironment.getSourceSystem();
		String vSalesDay;
		if(filterSourceSystemForTransmissionDate()){
			vSalesDay = mBusinessUnitEnvironment.getSalesDay();
		}else{
			vSalesDay = (mTransactionEnvironment.getTransmissionDateTime()).toString();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			vSalesDay = formatter.format(mTransactionEnvironment.getTransmissionDateTime());
		}
		ReferenceCheck vReferenceCheck =
				//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
				mBefReferenceCheck.findByReference(vRef, vSource);

		if (vReferenceCheck == null) {
			throw new ReferenceNotFound(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck() && !vReferenceCheck.getCancelled()) {
			throw new ReferenceAlreadyAcknowledged(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck() && vReferenceCheck.getCancelled()){
			throw new ReferenceCancelled(vSource, vRef);
		}
		checkReferences_Ack_Reverse(vReferenceCheck);
		// This transaction is now acknowledged
		
	
		
		ReservedCardHistory reservedCardHistory = mBefReservedCardHistory.findByRefrence(vReferenceCheck.getReference());
		if(null == pVoCapture) {
			pVoCapture = new VoCapture();
			pVoCapture.setCaptureAmount(reservedCardHistory.getRemainingUnAuthorizeAmount());
		}
		if(pVoCapture.getCaptureAmount() == null || BigDecimal.ZERO.compareTo(pVoCapture.getCaptureAmount())==0){
			pVoCapture.setCaptureAmount(reservedCardHistory.getRemainingUnAuthorizeAmount());
			
		} 
		
		if(pVoCapture.getCaptureAmount().compareTo(reservedCardHistory.getRemainingUnAuthorizeAmount()) <= 0) {
			
			reservedCardHistory.setCurrentAuthorizeAmount(reservedCardHistory.getCurrentAuthorizeAmount().add(pVoCapture.getCaptureAmount()));
			reservedCardHistory.setRemainingUnAuthorizeAmount(reservedCardHistory.getRemainingUnAuthorizeAmount().subtract(pVoCapture.getCaptureAmount()));
			
			if(reservedCardHistory.getExchangeRate() != null) {
			reservedCardHistory.setCardBalanceChange(reservedCardHistory.getCardBalanceChange().subtract(pVoCapture.getCaptureAmount().multiply(reservedCardHistory.getExchangeRate())));
			}else if(reservedCardHistory.getExchangeRate() == null){
				reservedCardHistory.setCardBalanceChange(reservedCardHistory.getCardBalanceChange().subtract(pVoCapture.getCaptureAmount()));
			}else {
				throw new AmountException("Cross currency is set to "+reservedCardHistory.isCrossCurrency() + " and exchange rate is set to "+ reservedCardHistory.getExchangeRate());
			}
			mBefReservedCardHistory.save(reservedCardHistory);
			
			if(BigDecimal.ZERO.compareTo(reservedCardHistory.getRemainingUnAuthorizeAmount())==0)
			{
				
			reservedCardHistory.setCardBalanceChange(BigDecimal.ZERO);
			mBefReservedCardHistory.save(reservedCardHistory);
			
			vReferenceCheck.setWaitingAck(false);
			mBefReferenceCheck.save(vReferenceCheck);
			
			mCategory.info(
					"Acknowledged "
							+ vReferenceCheck.getSourceSystem()
							+ " "
							+ vReferenceCheck.getReference()
							+ " "
							+ vReferenceCheck.getSalesDay());
			}
			Card mCard = mBefCard.findByCardId(reservedCardHistory.getCard().getCardId());
			Amount mAmount = mBefAmount.findByAmountId(reservedCardHistory.getAmount().getAmountId());
				
				
			// Create transaction
			Transaction vTransaction = mBefTransaction.create();

			vTransaction.setSourceSystem(reservedCardHistory.getSourceSystem());
			vTransaction.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
			vTransaction.setCancelled(false);
			vTransaction.setBuType(reservedCardHistory.getBuType());
			vTransaction.setBuCode(reservedCardHistory.getBuCode());
			
			if(reservedCardHistory.getEmployee() != null) {
				vTransaction.setEmployee(reservedCardHistory.getEmployee());
			}
			
			vTransaction.setCountryCode(reservedCardHistory.getCountryCode());
			vTransaction.setSwiped(reservedCardHistory.getSwiped());
			vTransaction.setTransactionNo(mTransactionEnvironment.getTransactionNo());
			vTransaction.setPointOfSale(reservedCardHistory.getPointOfSale());
			vTransaction.setReceipt(reservedCardHistory.getReceipt());
			vTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
			
			
			
			vTransaction.setCard(mCard);
			vTransaction.setAmount(mAmount);
			

			
			//mCard.setLastTransactionDateTime(vTransaction.getCreatedDateTime());
			
			// Redeem values
			vTransaction.setBalanceChange(pVoCapture.getCaptureAmount());
			if(reservedCardHistory.getExchangeRate() != null) {
				vTransaction.setCardBalanceChange(pVoCapture.getCaptureAmount().multiply(reservedCardHistory.getExchangeRate()));
			}else {
				vTransaction.setCardBalanceChange(pVoCapture.getCaptureAmount());
			}
			vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
			 /*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");  
			 LocalDateTime now = LocalDateTime.now(); 
			 String refrence = dtf.format(now) +" "+ reservedCardHistory.getReference();*/
			  
			vTransaction.setReference(mTransactionEnvironment.getReference());
			vTransaction.setRequestedAmount(pVoCapture.getCaptureAmount());
			vTransaction.setRequestedCurrencyCode(reservedCardHistory.getCurrencyCode());
			vTransaction.setTotalAmount(reservedCardHistory.getTotalAmount());
			vTransaction.setCrossBorder(reservedCardHistory.isCrossBorder());		
			vTransaction.setInsufficientAmount(reservedCardHistory.isInsufficientAmount());
			vTransaction.setCrossCurrency(reservedCardHistory.isCrossCurrency());
			vTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);
			if(reservedCardHistory.getVoidedTransactionNo() != null) {
				vTransaction.setVoidedTransactionNo(Long.parseLong(reservedCardHistory.getVoidedTransactionNo()));
			}
			
			mBefTransaction.save(vTransaction);
			
			// Create new reference
			ReferenceCheck referenceCheck = mBefReferenceCheck.create();
			referenceCheck.setWaitingAck(false);
			referenceCheck.setReference(mTransactionEnvironment.getReference());
			referenceCheck.setSourceSystem(mTransactionEnvironment.getSourceSystem());
			referenceCheck.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

			referenceCheck.setBuType(reservedCardHistory.getBuType());
			referenceCheck.setBuCode(reservedCardHistory.getBuCode());

			referenceCheck.setPointOfSale(reservedCardHistory.getPointOfSale());
			
			referenceCheck.setReceipt(reservedCardHistory.getReceipt());
			

			referenceCheck.setTransactionNo(vTransaction.getTransactionNo());
			referenceCheck.setCard(mCard);
			referenceCheck.setAckTimeout(0);
			
			mBefReferenceCheck.save(referenceCheck);
		
		
			
			/*
			 * Publish data to RabbitMQ for BsRedeem
			 */

			if (vTransaction.getTransactionId() != 0L) {
				try {
					SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
				Data data = new Data();
				EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
				
				String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
						+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();
				
				String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
						+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
						+ mCard.getCardNumber().getCheckDigit();
				
				data.setAccountNumber(pCardNumberString);
				data.setAccountNumberEnc(cardNumberEnc);
				data.setTransactionType(vTransaction.getTransactionType());
				if (null != vTransaction.getTransmissionDateTime())
					data.setTransactionDateTime(formatter.format(vTransaction.getTransmissionDateTime()));

				data.setTransactionId(vTransaction.getTransactionId());
				vEBCPAYLOAD.setData(data);

				
				mPublisher.publishMessage(vEBCPAYLOAD);
				} catch (Exception e) {
					mCategory.info("Exception in EBCPayload code block.");
					mCategory.info(e.getMessage());
				}
			}
			
		}else {
			
				throw new AmountException("Capture amount should be less than or equal to Remaining unauthorize amount, REMAINING_UNAUTHORIZE_AMOUNT = " + reservedCardHistory.getRemainingUnAuthorizeAmount());
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#acknowledge()
	 */
	public void reverseAmount(VoReferenceSpecifier pVoReferenceSpecifier, VoReverse pVoReverse)
			throws ReferenceCheckException, ValueMissingException, AmountException {

		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();
		// Find the old reference, we must be within the same source system and salesDay
		String vRef = pVoReferenceSpecifier.getReference();
		String vSource = mTransactionEnvironment.getSourceSystem();
		String vSalesDay;
		if(filterSourceSystemForTransmissionDate()){
			vSalesDay = mBusinessUnitEnvironment.getSalesDay();
		}else{
			vSalesDay = (mTransactionEnvironment.getTransmissionDateTime()).toString();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			vSalesDay = formatter.format(mTransactionEnvironment.getTransmissionDateTime());
		}
		ReferenceCheck vReferenceCheck =
				//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
				mBefReferenceCheck.findByReference(vRef, vSource);

		if (vReferenceCheck == null) {
			throw new ReferenceNotFound(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck() && !vReferenceCheck.getCancelled()) {
			throw new ReferenceAlreadyAcknowledged(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck() && vReferenceCheck.getCancelled()){
			throw new ReferenceCancelled(vSource, vRef);
		}
		checkReferences_Ack_Reverse(vReferenceCheck);
		// This transaction is now acknowledged
		
	
		
		ReservedCardHistory reservedCardHistory = mBefReservedCardHistory.findByRefrence(vReferenceCheck.getReference());
		 
		if(null == pVoReverse) {
			pVoReverse = new VoReverse();
			pVoReverse.setReverseAmount(reservedCardHistory.getRemainingUnAuthorizeAmount());

		}
		if(pVoReverse.getReverseAmount() == null){
			pVoReverse.setReverseAmount(reservedCardHistory.getRemainingUnAuthorizeAmount());
			
		} 
		if(pVoReverse.getReverseAmount().compareTo(reservedCardHistory.getRemainingUnAuthorizeAmount()) <= 0) {
			
			
			BigDecimal remainingUnAuthorizeAmount = reservedCardHistory.getRemainingUnAuthorizeAmount().subtract(pVoReverse.getReverseAmount());
			reservedCardHistory.setRemainingUnAuthorizeAmount(remainingUnAuthorizeAmount);

			if(reservedCardHistory.getExchangeRate() != null) {
				reservedCardHistory.setCardBalanceChange(reservedCardHistory.getCardBalanceChange().subtract(pVoReverse.getReverseAmount().multiply(reservedCardHistory.getExchangeRate())));
				}else if(reservedCardHistory.getExchangeRate() == null){
					reservedCardHistory.setCardBalanceChange(reservedCardHistory.getCardBalanceChange().subtract(pVoReverse.getReverseAmount()));
				}else {
					throw new AmountException("Cross currency is set to "+reservedCardHistory.isCrossCurrency() + " and exchange rate is set to "+ reservedCardHistory.getExchangeRate());
				}

			mBefReservedCardHistory.save(reservedCardHistory);
			
			if(BigDecimal.ZERO.compareTo(reservedCardHistory.getRemainingUnAuthorizeAmount())==0)
			{
				
			reservedCardHistory.setCardBalanceChange(BigDecimal.ZERO);
			mBefReservedCardHistory.save(reservedCardHistory);
			
			vReferenceCheck.setWaitingAck(false);
			mBefReferenceCheck.save(vReferenceCheck);
			
			mCategory.info(
					"Acknowledged "
							+ vReferenceCheck.getSourceSystem()
							+ " "
							+ vReferenceCheck.getReference()
							+ " "
							+ vReferenceCheck.getSalesDay());
			}
			
			//updated current amount (currentAmount + reverseAmount)
			Amount amount = mBefAmount.findByAmountId(reservedCardHistory.getAmount().getAmountId());
			
			
			if(reservedCardHistory.getExchangeRate() != null) {
				
				amount.setCurrentAmount(amount.getCurrentAmount().add(pVoReverse.getReverseAmount().multiply(reservedCardHistory.getExchangeRate())));

				}else if(reservedCardHistory.getExchangeRate() == null){

					amount.setCurrentAmount(amount.getCurrentAmount().add(pVoReverse.getReverseAmount()));
					
				}else {
					throw new AmountException("Cross currency is set to "+reservedCardHistory.isCrossCurrency() + " and exchange rate is set to "+ reservedCardHistory.getExchangeRate());
				}
			
			mBefAmount.save(amount);
			
			
			// Create transaction in reservedCardHistory
			
			//Transaction vTransaction = mBefTransaction.create();
			ReservedCardHistory vReservedCardHistory = mBefReservedCardHistory.create();
			
			vReservedCardHistory.setReservedTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_REVERSE_REDEEM);
			vReservedCardHistory.setCard(reservedCardHistory.getCard());
			
			/* DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");  
			 LocalDateTime now = LocalDateTime.now(); 
			 String refrence = dtf.format(now) +" "+ reservedCardHistory.getReference();*/
			vReservedCardHistory.setReference(mTransactionEnvironment.getReference());;
			
			vReservedCardHistory.setOriginalUnAuthorizeAmount(pVoReverse.getReverseAmount());
			vReservedCardHistory.setCurrentAuthorizeAmount(BigDecimal.ZERO);
			vReservedCardHistory.setRemainingUnAuthorizeAmount(BigDecimal.ZERO);
			vReservedCardHistory.setCurrencyCode(reservedCardHistory.getCurrencyCode());
			
			vReservedCardHistory.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);
			vReservedCardHistory.setSourceSystem(reservedCardHistory.getSourceSystem());
			vReservedCardHistory.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
			vReservedCardHistory.setCancelled(false);
			vReservedCardHistory.setBuType(reservedCardHistory.getBuType());
			vReservedCardHistory.setBuCode(reservedCardHistory.getBuCode());
			vReservedCardHistory.setCountryCode(reservedCardHistory.getCountryCode());
			
			vReservedCardHistory.setAmount(reservedCardHistory.getAmount());
			
			vReservedCardHistory.setSwiped(reservedCardHistory.getSwiped());
			
			vReservedCardHistory.setEmployee(mTransactionEnvironment.getEmployee());
			
			vReservedCardHistory.setTransactionNo(mTransactionEnvironment.getTransactionNo());
			
			vReservedCardHistory.setInsufficientAmount(reservedCardHistory.isInsufficientAmount());
			vReservedCardHistory.setCrossBorder(reservedCardHistory.isCrossBorder());
			vReservedCardHistory.setCrossCurrency(reservedCardHistory.isCrossCurrency());
			
			vReservedCardHistory.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
			vReservedCardHistory.setTotalAmount(reservedCardHistory.getTotalAmount());
			
			vReservedCardHistory.setPointOfSale(mTransactionEnvironment.getPointOfSale());
			vReservedCardHistory.setReceipt(reservedCardHistory.getReceipt());
			
			String trnNo = ""+reservedCardHistory.getTransactionNo();
			vReservedCardHistory.setVoidedTransactionNo(trnNo);
			
			if(reservedCardHistory.getExchangeRate() != null) {
				vReservedCardHistory.setCardBalanceChange(pVoReverse.getReverseAmount().multiply(reservedCardHistory.getExchangeRate()));
				}else if(reservedCardHistory.getExchangeRate() == null){
				vReservedCardHistory.setCardBalanceChange(pVoReverse.getReverseAmount());
				}else {
					throw new AmountException("Cross currency is set to "+reservedCardHistory.isCrossCurrency() + " and exchange rate is set to "+ reservedCardHistory.getExchangeRate());
				}
			
			mBefReservedCardHistory.save(vReservedCardHistory);
			
			// Create new reference
						ReferenceCheck referenceCheck = mBefReferenceCheck.create();
						referenceCheck.setWaitingAck(false);
						referenceCheck.setReference(mTransactionEnvironment.getReference());
						referenceCheck.setSourceSystem(mTransactionEnvironment.getSourceSystem());
						referenceCheck.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

						// Set info for identifi�ing the receipt
						referenceCheck.setBuType(vReservedCardHistory.getBuType());
						referenceCheck.setBuCode(vReservedCardHistory.getBuCode());

						referenceCheck.setPointOfSale(vReservedCardHistory.getPointOfSale());
						
						referenceCheck.setReceipt(vReservedCardHistory.getReceipt());
						

						referenceCheck.setTransactionNo(vReservedCardHistory.getTransactionNo());
						referenceCheck.setCard(reservedCardHistory.getCard());
						referenceCheck.setAckTimeout(0);
						
						mBefReferenceCheck.save(referenceCheck);
			
		}else {
			
				throw new AmountException("Reverse amount should be less than or equal to Remaining unauthorize amount, REMAINING_UNAUTHORIZE_AMOUNT = " + reservedCardHistory.getRemainingUnAuthorizeAmount());
		}
	}

	public void acknowledgeWaitingTransactions(ReferenceCheck pReferenceCheck)
			throws ReferenceCheckException, ValueMissingException {

		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();
		// Find the old reference, we must be within the same source system and salesDay
		String vRef = pReferenceCheck.getReference();
		String vSource = pReferenceCheck.getSourceSystem();
		String vSalesDay;
		if(filterSourceSystemForTransmissionDate()){
			vSalesDay = mBusinessUnitEnvironment.getSalesDay();
		}else{
			vSalesDay = pReferenceCheck.getSalesDay();
			//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			//vSalesDay = formatter.format(mTransactionEnvironment.getTransmissionDateTime());
		}
		ReferenceCheck vReferenceCheck =
				//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
				mBefReferenceCheck.findByReference(vRef, vSource);

		if (vReferenceCheck == null) {
			throw new ReferenceNotFound(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck()) {
			throw new ReferenceAlreadyAcknowledged(vSource, vRef);
		}

		// This transaction is now acknowledged
		vReferenceCheck.setWaitingAck(false);
		mBefReferenceCheck.save(vReferenceCheck);
		mCategory.info(
				"Acknowledged "
						+ vReferenceCheck.getSourceSystem()
						+ " "
						+ vReferenceCheck.getReference()
						+ " "
						+ vReferenceCheck.getSalesDay());
	}




	public void resetAckTimeOut(VoReferenceAckTimeOut pVoReferenceAckTimeOut)
			throws ReferenceCheckException, ValueMissingException {

		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Find the old reference, we must be within the same source system and salesDay
		String vRef = pVoReferenceAckTimeOut.getReference();
		String vSource = mTransactionEnvironment.getSourceSystem();
		String vSalesDay;
		if(filterSourceSystemForTransmissionDate()){
			vSalesDay = mBusinessUnitEnvironment.getSalesDay();
		}else{
			vSalesDay = (mTransactionEnvironment.getTransmissionDateTime()).toString();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			vSalesDay = formatter.format(mTransactionEnvironment.getTransmissionDateTime());
		}
		ReferenceCheck vReferenceCheck =
				//mBefReferenceCheck.findByReference(vRef, vSource, vSalesDay);
				mBefReferenceCheck.findByReference(vRef, vSource);

		if (vReferenceCheck == null) {
			throw new ReferenceNotFound(vSource, vRef);
		} else if (!vReferenceCheck.getWaitingAck()) {
			throw new ReferenceAlreadyAcknowledged(vSource, vRef);
		}
		//pVoReferenceSpecifier.setAckTimeOut(pVoReferenceSpecifier.getAckTimeOut());
		vReferenceCheck.setAckTimeout(pVoReferenceAckTimeOut.getAckTimeOut());
		mBefReferenceCheck.save(vReferenceCheck);
		mCategory.info(
				"resetAckTimeOut "
						+ vReferenceCheck.getSourceSystem()
						+ " "
						+ vReferenceCheck.getReference()
						+ " "
						+ vReferenceCheck.getSalesDay());
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#undoUnAcknowledged()
	 */
	public void cancelUnacknowledged()
			throws ValueMissingException, AmountException, ReferenceCheckException {
		mCategory.info("Searching for unacknowledged transactions");
		requireCard();

		// Get the reference checks for this card.
		Set<ReferenceCheck> vExistingRefs = mCard.getReferenceCheck();

		if (vExistingRefs == null) {
			return;
		}

		// It is important that we do the cancels in the right order!
		// Put the references in a tree map to get them sorted by created date (what happens if two is registered at the same second?)
		// We can not use the ID since different instances of the EBC will have different ranges for IDs.
		TreeMap<Date, ReferenceCheck> vSorted = new TreeMap<Date, ReferenceCheck>();
		for (Iterator<ReferenceCheck> i = vExistingRefs.iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();
			vSorted.put(vReferenceCheck.getCreatedDateTime(), vReferenceCheck);
		}
		ArrayList<ReferenceCheck> vList = new ArrayList<ReferenceCheck>(vSorted.values());
		for (int i = vList.size() - 1; i >= 0; i--) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) vList.get(i);
			if (mCategory.isDebugEnabled()) {
				mCategory.debug(CardPaymentLogger.referenceCheckToString(vReferenceCheck));
			}

			// If we are in the same receipt then we shall not undo the previous unacknowleged transaction on this receipt!
			if (notAutoAcknowledgeAndSameReceipt(vReferenceCheck)) {
				// We have found a previous transaction that are connected to this receipt, skip it.
				// All unacknowledged transactions on a receipt will be acknowledged at the end of the receipt.
				mCategory.info(
						"Reference "
								+ vReferenceCheck.getSourceSystem()
								+ " "
								+ vReferenceCheck.getReference()
								+ " is on the same receipt and we are not in auto acknowlegde mode -> do NOT cancel. All the transactions connected to the same receipt will be acknowledged at the end of the receipt.");
				continue;
			}

			// Undo unacknowledged (that is NOT part of this receipt)
			/*	if (vReferenceCheck.getWaitingAck()) {
				cancelTransaction(vReferenceCheck);
			}*/
			
			//PAYM-4075 - The pending authorization should not be automatically captured from NON-POS systems.
			/*if ((vReferenceCheck.getWaitingAck())&&(vReferenceCheck.getSourceSystem().equalsIgnoreCase("IRW")
					||vReferenceCheck.getSourceSystem().equalsIgnoreCase("ISELL")|| vReferenceCheck.getSourceSystem().equalsIgnoreCase("IME")||vReferenceCheck.getSourceSystem().equalsIgnoreCase("IPPCAPI"))) {

				acknowledgeWaitingTransactions(vReferenceCheck);
			}*/
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#cancelTransaction()
	 */
	public void cancelTransaction(ReferenceCheck pReferenceCheck)
			throws ValueMissingException, AmountException {

		if (mCategory.isInfoEnabled()) {
			mCategory.info(
					"Cancelling transaction no "
							+ pReferenceCheck.getTransactionNo()
							+ " with reference "
							+ pReferenceCheck.getSourceSystem()
							+ " "
							+ pReferenceCheck.getReference()
							+ " for card "
							/*+ CardPaymentLogger.cardNumberToString(
							pReferenceCheck.getCard().getCardNumber())*/);
		}
		
		ReservedCardHistory mReservedCardHistory = mBefReservedCardHistory.findByTransactionNo(pReferenceCheck.getTransactionNo());
		Transaction mTransaction = mBefTransaction.findByTransactionNumber(pReferenceCheck.getTransactionNo());

		if(mReservedCardHistory != null && "AUTHORIZE_REDEEM".equals(mReservedCardHistory.getReservedTransactionType())) {
			mBecReservedCardHistory.init(pReferenceCheck.getTransactionNo());
			mBecReservedCardHistory.cancelReservedCardHistorys();
			
			// Set the refrence to cancelled and not waiting acknowledgement
			pReferenceCheck.setCancelled(true);
			pReferenceCheck.setWaitingAck(false);
			mBefReferenceCheck.save(pReferenceCheck);
		}
		else if(mTransaction != null) {
			mBecTransactions.init(pReferenceCheck.getTransactionNo());
			mBecTransactions.cancelTransactions();
			
			// Set the refrence to cancelled and not waiting acknowledgement
			pReferenceCheck.setCancelled(true);
			pReferenceCheck.setWaitingAck(false);
			mBefReferenceCheck.save(pReferenceCheck);
		}
		
	}

	// ---------- Internal methods, must be protected so unit tests can access them ----------

	/**
	 * Is this refrence from the same receipt as the current transaction?
	 * @param pReferenceCheck
	 * @return
	 */
	protected boolean notAutoAcknowledgeAndSameReceipt(ReferenceCheck pReferenceCheck) {

		// We might end up here even if we are not in a transaction from the POS so we can
		// not be sure that mTransactionEnvironment is set.
		if (mTransactionEnvironment == null
				|| mBusinessUnitEnvironment == null) {
			// We are not in a transaction scope, we are not in a receipt at all.
			return false;
		}

		// If we in an auto acknowledge mode then cancel all unacknowledged
		if (mTransactionEnvironment.getAutoAcknowledge()) {
			return false;
		}

		/*String vCurrentSourceSystem = mTransactionEnvironment.getSourceSystem();
		String vCurrentBuType = mBusinessUnitEnvironment.getBuType();
		String vCurrentBuCode = mBusinessUnitEnvironment.getBuCode();
		String vCurrentPointOfSale = mTransactionEnvironment.getPointOfSale();
		String vCurrentReceipt = mTransactionEnvironment.getReceipt();
		String vCurrentSalesDay = mBusinessUnitEnvironment.getSalesDay();

		if (pReferenceCheck.getSourceSystem().equals(vCurrentSourceSystem)
				&& pReferenceCheck.getBuType().equals(vCurrentBuType)
				&& pReferenceCheck.getBuCode().equals(vCurrentBuCode)
				&& pReferenceCheck.getPointOfSale().equals(vCurrentPointOfSale)
				&& pReferenceCheck.getReceipt().equals(vCurrentReceipt)
				&& pReferenceCheck.getSalesDay().equals(vCurrentSalesDay)) {
			return true;
		}*/
		return true;
	}

	/**
	 * Checks all references connected to the card and if a matching refrence found then throw excpetion.
	 * If unacknowledged transactions are found then undo them.
	 * @throws ValueMissingException
	 * @throws ReferenceAlreadyExistsException
	 */
	protected void checkReferences()
			throws ValueMissingException, ReferenceAlreadyExistsException {

		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Get the reference checks for this card.
		// 99% of the cases when we get the same reference again it will be on the same card.
		// Rest will be caught with the constraint in the database.
		Set<ReferenceCheck> vExistingRefs = mCard.getReferenceCheck();
		String vSourceSystem = mTransactionEnvironment.getSourceSystem();
		String vReference = mTransactionEnvironment.getReference();
		String vSalesDay = mBusinessUnitEnvironment.getSalesDay();

		if (vExistingRefs == null) {
			// No references exists for this card.
			return;
		}
		if (vSourceSystem == null) {
			throw new ValueMissingException("Tried to use BecCard without required SourceSystem.");
		}
		if (vReference == null) {
			throw new ValueMissingException("Tried to use BecCard without required Reference.");
		}
		if (vSalesDay == null) {
			throw new ValueMissingException("Tried to use BecCard without required SalesDay.");
		}

		for (Iterator<ReferenceCheck> i = vExistingRefs.iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();

			// Unique reference consists of "Reference-SourceSystem-SalesDay"
			if (vSourceSystem.equals(vReferenceCheck.getSourceSystem())
					&& vReference.equals(vReferenceCheck.getReference())
					&& vSalesDay.equals(vReferenceCheck.getSalesDay())) {
				throw new ReferenceAlreadyExistsException(
						vSourceSystem,
						vReference);
			}
		}
	}
	protected void checkReferences_Ack_Reverse(ReferenceCheck pReferenceCheck)
			throws ValueMissingException, ReferenceAlreadyExistsException {
		
		mCard = mBefCard.findByCardId(pReferenceCheck.getCard().getCardId());
		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Get the reference checks for this card.
		// 99% of the cases when we get the same reference again it will be on the same card.
		// Rest will be caught with the constraint in the database.
		
		Set<ReferenceCheck> vExistingRefs = mCard.getReferenceCheck();
		String vSourceSystem = mTransactionEnvironment.getSourceSystem();
		String vReference = mTransactionEnvironment.getReference();
		String vSalesDay = mBusinessUnitEnvironment.getSalesDay();

		if (vExistingRefs == null) {
			// No references exists for this card.
			return;
		}
		if (vSourceSystem == null) {
			throw new ValueMissingException("Tried to use BecCard without required SourceSystem.");
		}
		if (vReference == null) {
			throw new ValueMissingException("Tried to use BecCard without required Reference.");
		}
		if (vSalesDay == null) {
			throw new ValueMissingException("Tried to use BecCard without required SalesDay.");
		}

		for (Iterator<ReferenceCheck> i = vExistingRefs.iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();

			// Unique reference consists of "Reference-SourceSystem-SalesDay"
			if (vSourceSystem.equals(vReferenceCheck.getSourceSystem())
					&& vReference.equals(vReferenceCheck.getReference())
					&& vSalesDay.equals(vReferenceCheck.getSalesDay())) {
				throw new ReferenceAlreadyExistsException(
						vSourceSystem,
						vReference);
			}
		}
	}
	
	public void checkUnacknowledgeRedeemReferences()
			throws ValueMissingException, AmountException {

		requireCard();
		requireTransactionEnvironment();
		requireBusinessUnitEnvironment();

		// Get the reference checks for this card.
		// 99% of the cases when we get the same reference again it will be on the same card.
		// Rest will be caught with the constraint in the database.
		Set<ReferenceCheck> vExistingRefs = mCard.getReferenceCheck();
		

		if (vExistingRefs == null) {
			// No references exists for this card.
			return;
		}
		

		for (Iterator<ReferenceCheck> i = vExistingRefs.iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();

			if (vReferenceCheck.getWaitingAck()) {
				throw new AmountException("Card has pending unacknowledge transaction - transaction no:"+vReferenceCheck.getReceipt()+". You can't reload the card");
			}
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException("Tried to use BecCard without required Card.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment()
			throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required BusinessUnitEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment()
			throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required TransactionEnvironment.");
	}

	public VoEnvironment calculateTransactionAckDateTime()
			throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException {
		ReferenceCheck vReferenceCheck = mBefReferenceCheck.create();
		VoEnvironment vVoEnvironment = new VoEnvironment();
		UnacknowledgedTimeout vUnacknowledgedTimeout =null;
		BecUnacknowledgedTimeout vBecUnacknowledgedTimeout = mBecFactory.createBecUnacknowledgedTimeout();
		try {
			vUnacknowledgedTimeout =vBecUnacknowledgedTimeout.getUnacknowledgedTimeout(mBusinessUnitEnvironment.getBuCode(),mBusinessUnitEnvironment.getBuType(),mTransactionEnvironment.getSourceSystem());

		} catch (UnacknowledgedTimeoutException e) {
			throw e;
		}
		Date pDate=null;
		DateTime CorrectedDate=null;
		DateTime pDateTime=null;
		String pAckTimeOutDate;
		pDate = vReferenceCheck.getCreatedDateTime();
		pDateTime=Dates.getDateTime(pDate);

		if (vUnacknowledgedTimeout!=null && vUnacknowledgedTimeout.getTimeoutSec()>0){
			long pAckTimeout=vUnacknowledgedTimeout.getTimeoutSec();
			CorrectedDate=Dates.withAddedAckTime(pDateTime, pAckTimeout);
			pAckTimeOutDate=CorrectedDate.toString("yyyy-MM-dd HH:mm:ss z");

		}
		else{
			CorrectedDate=Dates.withAddedAckTime(pDateTime,3600);
			pAckTimeOutDate=CorrectedDate.toString("yyyy-MM-dd HH:mm:ss z");
		}
		vVoEnvironment.setTransactionAckTimeoutDateTime(pAckTimeOutDate);
		return vVoEnvironment;
	}
	protected boolean filterSourceSystemForTransmissionDate() throws ReferenceCheckException, ValueMissingException{
		requireTransactionEnvironment();
		String vSource = mTransactionEnvironment.getSourceSystem();
		mCategory.info("filter_source : "+vSource);

		String vHost = mEbcProperties.getString("FilterSourceSystemForTransmissionDate","NOSOURCE");
		//vHost = "TPNet,CALYPSO";
		ArrayList<String> vHostList = new  ArrayList<String>(Arrays.asList(vHost.split(",")));
		mCategory.info("filter_source_salesday: "+vHostList);
		return vHostList.contains(vSource);
	}

	
}
