/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class ExternalCardSystem extends BusinessEntity {
	/**										
	 * Storage: EXTERNAL_CARD_SYSTEM_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mExternalCardSystemId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<ExternalCard> mExternalCards = new java.util.LinkedHashSet<ExternalCard>(0);

	/**										
	 * Data								
	 */										
	private String mName;
	private String mCountryCode;
	private String mAmountType;
	private String mCardNumberPattern;
	private long mCurrentAccountNumber;
	private long mInitialAccountNumber;
	private long mMaxAccountNumber;
	private String mIssuer;
	private int mCardTypeDigit;
	private String mImportState;

	/**											
	 * @return Returns the externalCardSystemId.													
	 */											
	public long getExternalCardSystemId() {
		return mExternalCardSystemId;
	}
	/**
	 * @param pExternalCardSystemId The externalCardSystemId to set.
	 */
	public void setExternalCardSystemId(long pExternalCardSystemId) {
		mExternalCardSystemId = pExternalCardSystemId;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the amountType.													
	 */											
	public String getAmountType() {
		return mAmountType;
	}
	/**
	 * @param pAmountType The amountType to set.
	 */
	public void setAmountType(String pAmountType) {
		mAmountType = pAmountType;
	}

	/**											
	 * @return Returns the cardNumberPattern.													
	 */											
	public String getCardNumberPattern() {
		return mCardNumberPattern;
	}
	/**
	 * @param pCardNumberPattern The cardNumberPattern to set.
	 */
	public void setCardNumberPattern(String pCardNumberPattern) {
		mCardNumberPattern = pCardNumberPattern;
	}

	/**											
	 * @return Returns the currentAccountNumber.													
	 */											
	public long getCurrentAccountNumber() {
		return mCurrentAccountNumber;
	}
	/**
	 * @param pCurrentAccountNumber The currentAccountNumber to set.
	 */
	public void setCurrentAccountNumber(long pCurrentAccountNumber) {
		mCurrentAccountNumber = pCurrentAccountNumber;
	}

	/**											
	 * @return Returns the initialAccountNumber.													
	 */											
	public long getInitialAccountNumber() {
		return mInitialAccountNumber;
	}
	/**
	 * @param pInitialAccountNumber The initialAccountNumber to set.
	 */
	public void setInitialAccountNumber(long pInitialAccountNumber) {
		mInitialAccountNumber = pInitialAccountNumber;
	}

	/**											
	 * @return Returns the maxAccountNumber.													
	 */											
	public long getMaxAccountNumber() {
		return mMaxAccountNumber;
	}
	/**
	 * @param pMaxAccountNumber The maxAccountNumber to set.
	 */
	public void setMaxAccountNumber(long pMaxAccountNumber) {
		mMaxAccountNumber = pMaxAccountNumber;
	}

	/**											
	 * @return Returns the issuer.													
	 */											
	public String getIssuer() {
		return mIssuer;
	}
	/**
	 * @param pIssuer The issuer to set.
	 */
	public void setIssuer(String pIssuer) {
		mIssuer = pIssuer;
	}

	/**											
	 * @return Returns the cardTypeDigit.													
	 */											
	public int getCardTypeDigit() {
		return mCardTypeDigit;
	}
	/**
	 * @param pCardTypeDigit The cardTypeDigit to set.
	 */
	public void setCardTypeDigit(int pCardTypeDigit) {
		mCardTypeDigit = pCardTypeDigit;
	}

	/**											
	 * @return Returns the importState.													
	 */											
	public String getImportState() {
		return mImportState;
	}
	/**
	 * @param pImportState The importState to set.
	 */
	public void setImportState(String pImportState) {
		mImportState = pImportState;
	}

	/**											
	 * @return Returns the externalCards.													
	 */											
	public java.util.Set<ExternalCard> getExternalCards() {
		return mExternalCards;
	}
	/**
	 * @param pExternalCards The externalCards to set.
	 */
	public void setExternalCards(java.util.Set<ExternalCard> pExternalCards) {
		mExternalCards = pExternalCards;
	}

	/**
	 * Connect a ExternalCard.
	 * @param pExternalCard
	 */
	public void connectExternalCard(ExternalCard pExternalCard) {
		getExternalCards().add(pExternalCard);
		if(pExternalCard != null) {
			pExternalCard.setExternalCardSystem(this);
		}
	}

	/**
	 * Disconnect a ExternalCard.
	 * @param pExternalCard
	 */
	public void disconnectExternalCard(ExternalCard pExternalCard) {
		if(pExternalCard != null) {
			pExternalCard.setExternalCardSystem(null);
		}
		getExternalCards().remove(pExternalCard);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mExternalCardSystemId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("externalCardSystemId", CodeGeneration.toObject(mExternalCardSystemId));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("amountType", CodeGeneration.toObject(mAmountType));
		vMap.put("cardNumberPattern", CodeGeneration.toObject(mCardNumberPattern));
		vMap.put("currentAccountNumber", CodeGeneration.toObject(mCurrentAccountNumber));
		vMap.put("initialAccountNumber", CodeGeneration.toObject(mInitialAccountNumber));
		vMap.put("maxAccountNumber", CodeGeneration.toObject(mMaxAccountNumber));
		vMap.put("issuer", CodeGeneration.toObject(mIssuer));
		vMap.put("cardTypeDigit", CodeGeneration.toObject(mCardTypeDigit));
		vMap.put("importState", CodeGeneration.toObject(mImportState));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("externalCardSystemId")) mExternalCardSystemId = CodeGeneration.objectTolong(pMap.get("externalCardSystemId"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("amountType")) mAmountType = CodeGeneration.objectToString(pMap.get("amountType"));
		if(pMap.containsKey("cardNumberPattern")) mCardNumberPattern = CodeGeneration.objectToString(pMap.get("cardNumberPattern"));
		if(pMap.containsKey("currentAccountNumber")) mCurrentAccountNumber = CodeGeneration.objectTolong(pMap.get("currentAccountNumber"));
		if(pMap.containsKey("initialAccountNumber")) mInitialAccountNumber = CodeGeneration.objectTolong(pMap.get("initialAccountNumber"));
		if(pMap.containsKey("maxAccountNumber")) mMaxAccountNumber = CodeGeneration.objectTolong(pMap.get("maxAccountNumber"));
		if(pMap.containsKey("issuer")) mIssuer = CodeGeneration.objectToString(pMap.get("issuer"));
		if(pMap.containsKey("cardTypeDigit")) mCardTypeDigit = CodeGeneration.objectToint(pMap.get("cardTypeDigit"));
		if(pMap.containsKey("importState")) mImportState = CodeGeneration.objectToString(pMap.get("importState"));
	}
}
