/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;



/**
 * @author anms
 *
 */
public interface BecFactory {

	/**
	 * 
	 * @return
	 */
	public BecCampaign createBecCampaign();

	/**
	 * 
	 * @return
	 */
	public BecCampaigns createBecCampaigns();

	/**
	 * 
	 * @return
	 */
	public BecCard createBecCard();

	/**
	 * 
	 * @return
	 */
	public BecCards createBecCards();

	/**
	 * @return
	 */
	public BecAmount createBecAmount();

	/**
	 * 
	 * @return
	 */
	public BecAmounts createBecAmounts();

	/**
	 * 
	 * @return
	 */
	public BecCardNumber createBecCardNumber();

	/**
	 * 
	 * @return
	 */
	public BecKPI createBecKPI();

	/**
	 * 
	 * @return
	 */
	public BecReport createBecReport();

	/**
	 * 
	 * @param pCard
	 * @param pAmount
	 * @return
	 */
	public BecTransaction createBecTransaction();

	/**
	 * 
	 * @param pCard
	 * @param pAmount
	 * @return
	 */
	public BecTransactions createBecTransactions();

	/**
	 * 
	 * @return
	 */
	public BecReferenceCheck createBecReferenceCheck();

	/**
	 * 
	 * @return
	 */
	public BecReferenceChecks createBecReferenceChecks();
	
	/**
	 * 
	 * @return
	 */
	public BecReservedCardHistory createBecReservedCardHistory();

	/**
	 * 
	 * @return
	 */
	public BecRange createBecCardRange();

	/**
	 * 
	 * @return
	 */
	public BecCampaignLimitation createBecCampaignLimitation();

	/**
	 * 
	 * @return
	 */
	public BecMassLoad createBecMassLoad();

	/**
	 * 
	 * @return
	 */
	public BecMassLoads createBecMassLoads();

	/**
	 * 
	 * @return
	 */
	public BecBonusCode createBecBonusCode();

	/**
	 * 
	 * @return
	 */
	public BecBonusCodes createBecBonusCodes();

	/**
	 * 
	 * @return
	 */
	public BecBonus createBecBonus();

	/**
	 * 
	 * @return
	 */
	public BecBonuses createBecBonuses();

	/**
	 * 
	 * @return
	 */
	public BecCountrySetup createBecCountrySetup();

	/**
	 * 
	 * @return
	 */
	public BecCountrySetups createBecCountrySetups();

	/**
	 * 
	 * @return
	 */
	public BecExternalCard createBecExternalCard();

	/**
	 * 
	 * @return
	 */
	public BecExternalCardSystem createBecExternalCardSystem();
	

	/**
	 * 
	 * @return
	 */
	public BecCountries createBecCountries();
	
	
	/**
	 * 
	 * @return
	 */
	public BecCountry createBecCountry();
	
	
	/**
	 * 
	 * @return
	 */	
	public BecMainCurrency createBecMainCurrency();
		
		
	/**
	 * 
	 * @return
	 */	
	public BecMainCurrencies createBecMainCurrencies();
			
	/**
	 * 
	 * @return
	 */
	public BecExchangeRate createBecExchangeRate();	
	
	/**
	 * 
	 * @return
	 */
	public BecExchangeRates createBecExchangeRates();

	/**
	 * 
	 * @return
	 */
	//BecMultipleSingleLoad createBecMultipleSingleLoad();

	/**
	 * 
	 * @return
	 */
	//BecMultipleSingleLoads createBecMultipleSingleLoads();
	
	/**
	 * 
	 * @return
	 */
	public BecUnacknowledgedTimeout createBecUnacknowledgedTimeout();

	
	/**
	 * 
	 * @return
	 */
	public BecSarecReport createBecSarecReport();
	
	public BecExternalTempCard createBecExternalTempCard();
	
}
