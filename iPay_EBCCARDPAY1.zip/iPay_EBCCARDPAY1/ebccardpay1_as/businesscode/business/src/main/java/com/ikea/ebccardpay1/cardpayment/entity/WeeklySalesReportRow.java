package com.ikea.ebccardpay1.cardpayment.entity;

import java.math.BigDecimal;

/**
 * 
 * @author Henrik Reinhold
 * 
 * Accessory need to be capitalized in order fore Hibernate to make the
 * mapping dynamically. Ugly but not much to do about it...
 * 
 */
public class WeeklySalesReportRow {

	String countryCode;
	String buCode;
	String buType;
	String currencyCode;
	BigDecimal amountInLocalCurrency;
	BigDecimal numberOfLoadTransactions;

	public String getCOUNTRYCODE() {
		return countryCode;
	}

	public void setCOUNTRYCODE(String pCountryCode) {
		countryCode = pCountryCode;
	}

	public String getBUCODE() {
		return buCode;
	}

	public void setBUCODE(String pBuCode) {
		buCode = pBuCode;
	}

	public String getBUTYPE() {
		return buType;
	}

	public void setBUTYPE(String pBuType) {
		buType = pBuType;
	}

	public String getCURRENCYCODE() {
		return currencyCode;
	}

	public void setCURRENCYCODE(String pCurrencyCode) {
		currencyCode = pCurrencyCode;
	}

	public BigDecimal getAMOUNTINLOCALCURRENCY() {
		return amountInLocalCurrency;
	}

	public void setAMOUNTINLOCALCURRENCY(BigDecimal pAmountInLocalCurrency) {
		amountInLocalCurrency = pAmountInLocalCurrency;
	}

	public BigDecimal getNUMBEROFLOADTRANSACTIONS() {
		return numberOfLoadTransactions;
	}

	public void setNUMBEROFLOADTRANSACTIONS(BigDecimal pNumberOfLoadTransactions) {
		numberOfLoadTransactions = pNumberOfLoadTransactions;
	}

}
