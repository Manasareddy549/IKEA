package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.utils.entities.EBCPAYLOAD;

public interface Publisher {
	
	public void publishMessage(EBCPAYLOAD pEBCPAYLOAD);

	void publishMessage(List<EBCPAYLOAD> pEBCPayloadList);

}
