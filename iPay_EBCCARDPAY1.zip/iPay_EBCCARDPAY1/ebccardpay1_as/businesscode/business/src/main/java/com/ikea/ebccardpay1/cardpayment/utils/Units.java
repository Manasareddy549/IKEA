package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.exception.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebcframework.exception.IkeaException;

/**
 */
public interface Units {

	/**
	 * Retrieves a list of stores that are currently closed. A closed store is defined as
	 * where the local time is between 03:00 and 06:59
	 * 
	 * @return A list of VoBusinessUnit which is the bu code
	 */
	public List<VoBusinessUnit> closedStores();

	/**
	 * Retrieves a list of stores
	 * 
	 * @return A list of VoBusinessUnit which is the bu code
	 */
	public List<VoBusinessUnit> allStores();

	/**
	 * Retrieves a list of country codes (only including countries that has got at least one store)
	 * 
	 * @return A list of strings which is the country code
	 */
	public List<String> allCountryCodes();
	

	/**
	 * Fetch all BUs for a specific CountryCode
	 * @param countryCode The country code for which BUs are requested
	 * @return a <code>Collection</code> populated with objects of <code>Unit</code>
	 */
	public List<VoBusinessUnit> getUnitsForCountryCode(String countryCode);
	

	/**
	 * Retrieve the country code for a given BU
	 * 
	 * @param pBuType The Business Unit Type
	 * @param pBuCode The Business Unit Code
	 * @return A two letter ISO code for the country
	 */
	public String getCountryCode(String pBuType, String pBuCode)
		throws BusinessUnitException;

	/**
	 * Checks if the BU exists
	 * @param pBuType
	 * @param pBuCode
	 * @throws BusinessUnitException if the BU does not exists (not a valid BU)
	 */
	public void checkValidBusinessUnit(String pBuType, String pBuCode)
		throws BusinessUnitException;

	/**
	 * 
	 * @param pCountryCode
	 * @throws BusinessUnitException if the country code is not a valid country code in iPay (has a BU)
	 */
	public void checkValidCountryCode(String pCountryCode)
		throws BusinessUnitException;
	/**
	 * 
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 * @throws BusinessUnitException
	 */
	public String getSiteName(String pBuType, String pBuCode)
		throws BusinessUnitException;

	/**
	 * Retrieve the time zone for a given BU
	 * 
	 * @param pBuType The Business Unit Type
	 * @param pBuCode The Business Unit Code
	 * @return A Java time zone identifier
	 */
	public String getTimeZone(String pBuType, String pBuCode)
		throws BusinessUnitException;

	/**
	 * Retireves the Business Unit information for a user
	 * 
	 * @param pUserName
	 * @return
	 */
	public VoBusinessUnit getUnitForUser(String pUserName)
		throws IkeaException;

	/**
	 * Retrieve the Company code for a given BU
	 * 
	 * @param pBuType The Business Unit Type
	 * @param pBuCode The Business Unit Code
	 * @return A two letter ISO code for the country
	 */
	public String getCompanyCode(String pBuType, String pBuCode)
		throws BusinessUnitException;

}
