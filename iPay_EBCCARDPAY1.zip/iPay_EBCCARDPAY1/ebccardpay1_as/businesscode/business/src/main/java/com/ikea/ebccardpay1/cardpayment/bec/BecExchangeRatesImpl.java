/*
 * Created on 2007-sep-03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.bec;
import static org.apache.commons.lang.Validate.notNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.bef.BefExchangeRate;
import com.ikea.ebccardpay1.cardpayment.bef.BefExchangeRateSpread;
import com.ikea.ebccardpay1.cardpayment.exception.CountryNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ExchangeRateNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.common.TimeSource;
import com.ikea.mdsd.ValueObjects;

/**
 * @author dalq
 * 
 * 
 */
public class BecExchangeRatesImpl implements BecExchangeRates {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecExchangeRatesImpl.class);

	// Dependencies injected at creation of this BEC
	private BecExchangeRate mBecExchangeRate;
	private BecFactoryImpl mBecFactoryImpl;
	private BefExchangeRate mBefExchangeRate;
	private BefExchangeRateSpread mBefExchangeRateSpread;
	private TimeSource mTimeSource = null;
	private Units mUnits = null;

	// Entities that this BEC operates on
	List<VoExchangeRate> mVoExchangeRateList = null;

	// Dependencies that need to be set with init
	private VoCountry mVoCountry = null;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;

	/**
	 * @param pBecExchangeRate
     * @param pBecFactoryImpl
     * @param pBefExchangeRate
     * @param pBefExchangeRateSpread
     * @param pTimeSource
     * @param pUnits
	 */
	public BecExchangeRatesImpl(BecExchangeRate pBecExchangeRate,
			BecFactoryImpl pBecFactoryImpl, BefExchangeRate pBefExchangeRate,
			BefExchangeRateSpread pBefExchangeRateSpread,
			TimeSource pTimeSource, Units pUnits) {

		mBecExchangeRate = pBecExchangeRate;
		mBecFactoryImpl = pBecFactoryImpl;
		mBefExchangeRate = pBefExchangeRate;
		mBefExchangeRateSpread = pBefExchangeRateSpread;
		mTimeSource = pTimeSource;
		mUnits = pUnits;
	}

	void validate() {
		notNull(mBecExchangeRate);
		notNull(mBecFactoryImpl);
		notNull(mBefExchangeRate);
		notNull(mBefExchangeRateSpread);
		notNull(mTimeSource);
		notNull(mUnits);
	}
	/**
	 * 
	 */
	public BecExchangeRatesImpl() {
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#init(com.ikea.
	 * ebccardpay1.cardpayment.utils.BusinessUnitEnvironment)
	 */
	public BecExchangeRates init(
			BusinessUnitEnvironment pBusinessUnitEnvironment) {
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#init(com.ikea.
	 * ebccardpay1.cardpayment.vo.VoCountry)
	 */
	public BecExchangeRates init(VoCountry pVoCountry) {
		mVoCountry = pVoCountry;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#init(com.ikea.
	 * ebccardpay1.cardpayment.vo.VoExchangeRates)
	 */
	public BecExchangeRates init(List<VoExchangeRate> pVoExchangeRateList) {
		mVoExchangeRateList = pVoExchangeRateList;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#manage()
	 */
	public void manage() throws InvalidFromDateException,
			InvalidFromCurrencyException, InvalidToCurrencyException,
			ValueMissingException {

		requireVoExchangeRatesList();

		// Set connected Country
		mBecExchangeRate.init(mVoCountry);

		// Mange on each of the VoExchangeRates

		// Initialize a new ArrayList to fill
		init(new ArrayList<VoExchangeRate>());
		for (VoExchangeRate vVoExchangeRate : mVoExchangeRateList) {

			// Handle in single BEC
			mBecExchangeRate.manage(vVoExchangeRate);

			// Add modified VO to VO List
			mVoExchangeRateList.add(mBecExchangeRate
					.getVoExchangeRate());

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#getVoExchangeRatesList
	 * ()
	 */

	public List<VoExchangeRate> getVoExchangeRateList()
			throws ValueMissingException {
		requireVoExchangeRatesList();
		return mVoExchangeRateList;
	}

	public List<VoExchangeRate> getVoExchangeRateList(List<ExchangeRate> pExchangeRateList)
			throws ValueMissingException {
		List<VoExchangeRate> vVoExchangeRatesList = new ArrayList<VoExchangeRate>();

		for (ExchangeRate vExchangeRate : pExchangeRateList) {
			
			VoExchangeRate vVoExchangeRates = new VoExchangeRate();
			ValueObjects.assignToValueObject(vVoExchangeRates, vExchangeRate);
			vVoExchangeRates
					.setExchangeRate(getRateWithAddedSpread(vVoExchangeRates
									.getExchangeRate()));
			vVoExchangeRatesList.add(vVoExchangeRates);
			mCategory.info("Added VOExchangeRate to VoCountry ID: "
					+ vVoExchangeRates.getExchangeRateId() + " Rate:"
					+ vVoExchangeRates.getExchangeRate());

		}
		
		return vVoExchangeRatesList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#getExchangeRate
	 * (java.lang.String, java.lang.String)
	 */
	public BigDecimal getExchangeRate(String pFromCurrency, String pToCurrency)
			throws ValueMissingException, CountryNotFoundException,
			ExchangeRateNotFoundException {
		//

		if ("".equals(pFromCurrency) || "".equals(pToCurrency)) {
			throw new ValueMissingException(
					"Invalid input parameters 'From currency' code or 'To currency code'.");
		}

		requireBusinessUnitEnvironment();

		// Is this country enabled for cross-currency?
		// Check and get country
		Country vCountry = checkCountry();

		// Get current UTC time
		Date vLocalDate = mTimeSource.currentDate();

		// Convert to local date without time before search
		vLocalDate = Dates.convertToLocalDate(mUnits, vLocalDate,
				mBusinessUnitEnvironment.getBuType(), mBusinessUnitEnvironment
						.getBuCode());

		// Find current rate
		ExchangeRate vExchangeRate = mBefExchangeRate
				.findBySearch(pFromCurrency, pToCurrency, vLocalDate, vCountry
						.getCountryId());

		if (vExchangeRate == null) {
			throw new ExchangeRateNotFoundException(
					"No exchange rate for country '"
							+ mBusinessUnitEnvironment.getCountryCode()
							+ "' with currency codes From: '" + pFromCurrency
							+ "' To: '" + pToCurrency + "'.");
		}

		BigDecimal vRate = getRateWithAddedSpread(vExchangeRate
				.getExchangeRate());

		return vRate;
	}

	/**
	 * 
	 */
	protected Country checkCountry() throws CountryNotFoundException {

		String vCountryCode = mBusinessUnitEnvironment.getCountryCode();
		mCategory.info("Check if this country is enabled for exchange "
				+ vCountryCode);

		// Lookup Country
		BecCountry vBecCountry = mBecFactoryImpl.createBecCountry();
		vBecCountry.findCountry(vCountryCode);
		Country vCountry = vBecCountry.getCountry();
		return vCountry;
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment()
			throws ValueMissingException {
		if (mBusinessUnitEnvironment == null) {
			throw new ValueMissingException(
					"Tried to use BecExchangeRates without required BusinessUnitEnvironment.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireVoExchangeRatesList() throws ValueMissingException {
		if (mVoExchangeRateList == null) {
			throw new ValueMissingException(
					"Tried to use BecExchangeRates without required List<VoExchangeRates>.");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecExchangeRates#
	 * findCurrentExchangeRates(long)
	 */
	public List<ExchangeRate> findCurrentExchangeRates(long pCountryId) {
		// Collects the current exchangerates for a specific country.
		return mBefExchangeRate.findCurrent(pCountryId);
	}

	protected BigDecimal getRateWithAddedSpread(BigDecimal pRate) {
		BigDecimal vExchangeRateSpread = mBefExchangeRateSpread.findCurrent()
				.getExchangeRateSpread();
		BigDecimal vRate = pRate.multiply(BigDecimal.ONE
				.add(vExchangeRateSpread));
		return vRate;

	}

}
