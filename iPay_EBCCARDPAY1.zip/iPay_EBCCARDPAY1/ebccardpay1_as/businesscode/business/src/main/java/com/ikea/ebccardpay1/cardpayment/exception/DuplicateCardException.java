/*
 * Created on 2006-aug-04
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 * DuplicateCardException is thrown if a card object exists in the databse with the given card number.
 */
public class DuplicateCardException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8632360758008322583L;

	public DuplicateCardException() {
		super();
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.DuplicateCard();
	}

}
