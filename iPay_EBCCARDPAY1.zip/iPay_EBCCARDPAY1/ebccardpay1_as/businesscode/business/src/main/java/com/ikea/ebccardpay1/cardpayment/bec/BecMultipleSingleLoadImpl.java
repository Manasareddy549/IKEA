package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefMultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefRange;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.ExpiredCardException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardCheckDigitException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.MultipleSingleLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoadInitial;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoadInitialCardAmount;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.common.TimeSource;
import com.ikea.ebcframework.exception.IkeaException;

public class BecMultipleSingleLoadImpl implements BecMultipleSingleLoad {

	private static final int MAX_ERROR_MESSAGE_LENGTH = 4000;
	private static final String TO_LARGE_ERROR_MESSAGE_ENDING = "...[unable to save all errors]";
     
	protected SessionFactory mSessionFactory = null;
	
	private static final Logger mLog = LoggerFactory
			.getLogger(BecMultipleSingleLoadImpl.class);

	@Autowired
	private BecCard mBecCard;

	@Autowired
	private BecTransaction mBecTransaction;

	@Autowired
	private BefMultipleSingleLoad mBefMultipleSingleLoad;

	@Autowired
	private BefAmount mBefAmount;

	@Autowired
	private TimeSource mTimeSource;

	@Autowired
	private BefRange mBefRange;

	@Autowired
	private BefCard mBefCard;

	@Autowired
	private UtilsFactory mUtilsFactory;



	private MultipleSingleLoad mMultipleSingleLoad;


	@Autowired
	private BsContext bsContext;

	@SuppressWarnings("unchecked")
	public MultipleSingleLoad loadCards(VoMultipleSingleLoadInitial pVoMultipleSingleLoadInitial){

		BusinessUnitEnvironment vBusinessUnitEnvironment = mUtilsFactory
				.createBusinessUnitEnvironment(pVoMultipleSingleLoadInitial
						.getBuType(), pVoMultipleSingleLoadInitial.getBuCode());

		MultipleSingleLoad vMultipleSingleLoad = mBefMultipleSingleLoad.create();

		vMultipleSingleLoad.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_CASH);
		vMultipleSingleLoad.setBuCode(pVoMultipleSingleLoadInitial.getBuCode());
		vMultipleSingleLoad.setBuType(pVoMultipleSingleLoadInitial.getBuType());
		vMultipleSingleLoad.setCountryCode(pVoMultipleSingleLoadInitial.getCountryCode());
		vMultipleSingleLoad.setCurrencyCode(pVoMultipleSingleLoadInitial.getCurrencyCode());
		vMultipleSingleLoad.setName(pVoMultipleSingleLoadInitial.getName());
		vMultipleSingleLoad.setExpiryDate(pVoMultipleSingleLoadInitial.getExpiryDate());
		vMultipleSingleLoad.setInitiatedAmount(Amounts.amount(0));
		vMultipleSingleLoad.setReasonCode(pVoMultipleSingleLoadInitial.getReasonCode());
		vMultipleSingleLoad.setCompanyName(pVoMultipleSingleLoadInitial.getCompanyName());
		vMultipleSingleLoad.setCustomerType(pVoMultipleSingleLoadInitial.getCustomerType());
		//		vMultipleSingleLoad
		//		.setMultipleLoadState(Constants.MULTIPLE_STATE_CONSTANT_INITIATED);
		mBefMultipleSingleLoad.save(vMultipleSingleLoad);


		StringBuffer vErrorMessage = new StringBuffer();
		List<VoMultipleSingleLoadInitialCardAmount> vCardAmountList = pVoMultipleSingleLoadInitial.getVoMultipleSingleLoadInitialCardAmountList();
//code changes for #PKE000000127992 - card duplicacy Fix - Starts
				Set<String> cardSet=null;
				for (VoMultipleSingleLoadInitialCardAmount vInitialItem : vCardAmountList) {
					cardSet= new HashSet<String>(); 
					cardSet.add(vInitialItem.getCardNumberString());
				validateAmount(vInitialItem.getAmount());
				validateCard(vInitialItem.getCardNumberString());
				}
				// Ends
		for (VoMultipleSingleLoadInitialCardAmount vInitialItem : vCardAmountList) {
			try {
				validateAmount(vInitialItem.getAmount());
				BigDecimal vAmountValue = Amounts.amount(vInitialItem.getAmount());
				/*
				// Modified Promotional card Functionality, Defect-IKEA01072486 -anagc
				int card_type_digit=Integer.parseInt(Character.toString(vInitialItem.getCardNumberString().charAt(6)));
				if(card_type_digit==0 ||card_type_digit==9 ||card_type_digit==1 ||card_type_digit==3){
					throw new MultipleSingleLoadException("Campaign, QPC, Voucher and Family cards cannot be loaded through Multiple Single Load.");
				}
				 */
				
				TransactionEnvironment vTransactionEnvironment = mUtilsFactory
						.createTransactionEnvironment(
								Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
				mBecCard.init(vBusinessUnitEnvironment, vTransactionEnvironment);
				mBecCard.init(vInitialItem.getCardNumberString(), vBusinessUnitEnvironment);
				//String ReservedAmount = validateCardForReservedAmount(vInitialItem.getCardNumberString());
				
				Card vCard = mBecCard.getCard();
				Set<Amount> amountSet=null;
               /* if (vCard != null && vCard.getAmounts() != null) {
                      amountSet =  vCard.getAmounts();
                      for(Amount amount: amountSet){
                             if (amount.getMultipleSingleLoad()!=null) {
                                    MultipleSingleLoad singleload = amount.getMultipleSingleLoad();
                                    if (singleload.getAuthorizedBy()==null) {
                                    	throw new AmountException(
                        						"Card has reserved amount on it, you cannot initiate new singleload on same card");
                                           //appendErrorMessage(vErrorMessage, vInitialItem, vCard.getCardNumber().getAccountNumber(),
                                             //           "Card has reserved amount on it, you cannot initiate new singleload on same card");
                                    }else { continue;}
                             }else {continue;}
                      }
                } else*/
                	if (vCard != null &&
						vCard.getCurrencyCode() != null &&
						!vCard.getCurrencyCode().equalsIgnoreCase(vMultipleSingleLoad.getCurrencyCode())) {
					appendErrorMessage(vErrorMessage, vInitialItem, vMultipleSingleLoad.getCurrencyCode(),
							"Card is bound to another currency than the current load request");
				} else {
					if (vCard != null && vCard.getAmounts() != null) {
	                      amountSet =  vCard.getAmounts();
	                      for(Amount amount: amountSet){
	                             if (amount.getMultipleSingleLoad()!=null) {
	                                    MultipleSingleLoad singleload = amount.getMultipleSingleLoad();
	                                    if (singleload.getAuthorizedBy()==null) {
	                                    	throw new AmountException(
	                        						"Card has reserved amount on it, you cannot initiate new singleload on same card");
	                                           //appendErrorMessage(vErrorMessage, vInitialItem, vCard.getCardNumber().getAccountNumber(),
	                                             //           "Card has reserved amount on it, you cannot initiate new singleload on same card");
	                                    }else {
	                                    	continue;
	                                    }
	                             }else {
	                            	 continue;
	                             }
	                      }
	                }
					mBecCard.loadMultipleSingleLoad(vMultipleSingleLoad, vAmountValue);

					vMultipleSingleLoad.addInitiatedAmount(vAmountValue);
					vMultipleSingleLoad.increaseInitiatedCount();
				}
			} 
			catch (InvalidCardCheckDigitException checkException){ 
				mLog.info("Could not load card with cardnumber: "
						+ vInitialItem.getCardNumberString() + " with amount: " + vInitialItem.getAmount());
				appendErrorMessage(vErrorMessage, vInitialItem, vMultipleSingleLoad.getCurrencyCode(), "Invalid check digit in card number");
			} 
			catch (Exception e) {
				mLog.info("Could not load card with cardnumber: "
						+ vInitialItem.getCardNumberString() + " with amount: " + vInitialItem.getAmount());
				appendErrorMessage(vErrorMessage, vInitialItem, vMultipleSingleLoad.getCurrencyCode(), e.getMessage());
			}

		}

		if (vErrorMessage.length() > 0){
			vMultipleSingleLoad.setInitiateErrorMessages(vErrorMessage.toString());
		}

		return vMultipleSingleLoad;
	}
	
	private void validateCard(String cardNumberString) {
		if (!Pattern.matches("[0-9]*",cardNumberString)){
			throw new IllegalArgumentException("Card isn't formatted correctly");
		}		
	} 

	protected void validateAmount(String pAmount) {
		if (!Pattern.matches("([0-9]*\\.?[0-9]*)",pAmount)){
			throw new IllegalArgumentException("Amount isn't formatted correctly");
		}
	}
	
	/*public String validateCardForReservedAmount(String cardNumberString) {
		
		//String Issuer = cardNumberString.substring(0, 6);
		char cardType = cardNumberString.charAt(6);
		String accountNumber = cardNumberString.substring(7, 18);
		char checkSum = cardNumberString.charAt(18);
		
		 Session vSession = mSessionFactory.getCurrentSession();

			String vHql = "from CardNumber where accountNumber = :accountNumber and CardTypeDigit = :CardTypeDigit and CheckDigit =:CheckDigit ";

			if (mLog.isDebugEnabled()) {
				mLog.debug("HQL: " + vHql);			
			}              		

			CardNumber vCardNumber = (CardNumber)(vSession.createQuery(vHql).setParameter("accountNumber", accountNumber).setParameter("CardTypeDigit", cardType).setParameter("CheckDigit", checkSum).uniqueResult());
			
			if (vCardNumber == null) {
				mLog.debug("No cardmumber found");
			}
			
			long cardNumberId = vCardNumber.getCardNumberId();
			
			String cHql = "from CardNumber where cardNumberId = :cardNumberId ";
			
			if (mLog.isDebugEnabled()) {
				mLog.debug("HQL: " + cHql);			
			} 
			Card vCard = (Card)(vSession.createQuery(cHql).setParameter("cardNumberId", cardNumberId).uniqueResult());
			
			long cardId = vCard.getCardId();
			
			String aHql = "from Amount where cardId = :cardId ";
			
			Amount vAmount = (Amount)(vSession.createQuery(aHql).setParameter("cardId", cardId).uniqueResult());
			
			if(vAmount!=null) {
				
				String Reserve = vAmount.getAmountType();
				return Reserve;
			}
			else {
			return null;
			}
			
			
		}*/

	public MultipleSingleLoad authorize(long pMultipleSingleLoadId) throws ValueMissingException, CardPayException, IkeaException {
		MultipleSingleLoad vMultipleSingleLoad = mBefMultipleSingleLoad
				.findByPrimaryKey(pMultipleSingleLoadId);

		IkeaUserProfile vIkeaUserProfile = bsContext
				.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new ValueMissingException("User Profile could not be found");
		}
		String vUserId = vIkeaUserProfile.getUID().toLowerCase();

		verifyFourEyes(vMultipleSingleLoad.getCreatedBy(), vMultipleSingleLoad.getUpdatedBy(), vUserId);

		// Authorize the MultipleSingleLoad
		String user=vMultipleSingleLoad.getAuthorizedBy();
		if(user!= null){
			throw new AmountException("The Single load has already been Authorised.");
		}
		else{

			vMultipleSingleLoad.setAuthorizedBy(vUserId);
			vMultipleSingleLoad.setAuthorizedDateTime(mTimeSource.currentDate());
			//			vMultipleSingleLoad.setSingleLoadState(Constants.MULTIPLE_STATE_CONSTANT_WITHDRAWN);

			// Create transactions for each amount/card
			BigDecimal vLoadedAmount = new BigDecimal(0l);
			vLoadedAmount.setScale(Amounts.SCALE);
			for (Amount vAmount : vMultipleSingleLoad.getAmounts()) {
				// Create transaction
				mBecTransaction.createMultipleSingleLoadTransaction(vAmount,vMultipleSingleLoad);
				vLoadedAmount = vLoadedAmount.add(vAmount.getCurrentAmount());
				Card mCard=vAmount.getCard();
				if(vMultipleSingleLoad.getExpiryDate() !=null)
				{
					Date vLocalDate = mTimeSource.currentDate();
					
					if(vMultipleSingleLoad.getExpiryDate().compareTo(vLocalDate)>=0){
						mCard.setExpireDate(vMultipleSingleLoad.getExpiryDate());
						mBefCard.update(mCard);
					}
					else{
						throw new ExpiredCardException("Expiry Date cannot be set before the current Date");
					}
					
					
				}

			}
			this.mBecTransaction.publishTransactions();
		}
		return vMultipleSingleLoad;
	}

	public void delete(long pMultipleSingleLoadId) {
		MultipleSingleLoad vMultipleSingleLoad = mBefMultipleSingleLoad
				.findByPrimaryKey(pMultipleSingleLoadId);

		for (Amount vAmount : vMultipleSingleLoad.getAmounts()) {
			mBefAmount.delete(vAmount);
		}

		mBefMultipleSingleLoad.delete(vMultipleSingleLoad);
	}

	protected void verifyFourEyes(String pCreatedBy, String pUpdatedBy, String pCurrentUserId)
			throws ValueMissingException, FourEyesException {

		// The same person can not initiate/edit AND authorize a mass load
		if (pCurrentUserId.equals(pCreatedBy.toLowerCase())) {
			throw new FourEyesException(
					"The same user can not both initiate and authorize the single load.");
		}
		if (pUpdatedBy != null && pCurrentUserId.equals(pUpdatedBy.toLowerCase())) {
			throw new FourEyesException(
					"The same user can not both update and authorize the single load.");
		}
	}

	private void appendErrorMessage(StringBuffer vErrorMessage,
			VoMultipleSingleLoadInitialCardAmount vInitialItem, String pCurrencyCode, String pErrorMessage) {
		StringBuffer vAppendString = new StringBuffer();
		vAppendString.append(vInitialItem.getCardNumberString()).append(": ").append(
				vInitialItem.getAmount()).append(" ").append(pCurrencyCode).append(" : ").append(pErrorMessage).append(
						"\n");

		if ((vErrorMessage.length() + vAppendString.length()) < MAX_ERROR_MESSAGE_LENGTH) {
			vErrorMessage.append(vAppendString);
		} else {
			if ((vErrorMessage.length() + TO_LARGE_ERROR_MESSAGE_ENDING.length()) > MAX_ERROR_MESSAGE_LENGTH) {
				vErrorMessage.setLength(MAX_ERROR_MESSAGE_LENGTH - TO_LARGE_ERROR_MESSAGE_ENDING.length());
			}
			vErrorMessage.append(TO_LARGE_ERROR_MESSAGE_ENDING);
		}
	}

}
