/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadFilter;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecMassLoads {

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecMassLoads init(UserEnvironment pUserEnvironment);


	/**
	 * 
	 * @param pVoMassLoadFilter
	 * @return
	 */
	public BecMassLoads init(VoMassLoadFilter pVoMassLoadFilter);

	/**
	 * @return
	 * @throws IkeaException
	 */
	public List<VoMassLoad> findCurrentMassLoads()
		throws IkeaException, ValueMissingException;

	/**
	 * @return
	 */
	public List<MassLoad> findUnprocessedMassLoads();

	/**
	 * @param pVoMassLoadSearch
	 * @return
	 * @throws ValueMissingException
	 */
	public List<VoMassLoad> findMassLoads(VoMassLoadSearch pVoMassLoadSearch)
		throws ValueMissingException;

	/**
	 * 
	 * @param pVoBonusSearch
	 * @return
	 * @throws ValueMissingException
	 */
	public List<VoBonusComplete> findMassLoadBonuses(VoBonusSearch pVoBonusSearch)
		throws ValueMissingException;

}
