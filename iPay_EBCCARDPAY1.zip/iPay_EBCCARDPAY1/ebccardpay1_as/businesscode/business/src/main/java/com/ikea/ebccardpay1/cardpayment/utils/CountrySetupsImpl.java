/*
 * Created on 2007-apr-27
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.InitializingBean;

import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.common.TimeSource;

/**
 * @author anms
 *
 */
public class CountrySetupsImpl implements CountrySetups, InitializingBean {

	/**
	 * Dependencies
	 */
	TimeSource mTimeSource;
	CountrySetupCache mCountrySetupCache;

	/**
	 * Dependency injection
	 */
	public CountrySetupsImpl(TimeSource pTimeSource, CountrySetupCache pCountrySetupCache) {

		mTimeSource = pTimeSource;
		mCountrySetupCache = pCountrySetupCache;
	}

	//@Override
	public void afterPropertiesSet() throws Exception {
		Validate.notNull(mTimeSource);
		Validate.notNull(mCountrySetupCache);

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.CountrySetups#getExpireDays(java.lang.String, java.lang.String)
	 */
	public int getExpireDays(String pCountryCode, String pCardType)
			throws CountrySetupException {

		Integer vExpireDays = mCountrySetupCache.fetch(pCountryCode, pCardType);
		if (vExpireDays != null) {
			return vExpireDays.intValue();
		}
		return 0;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.CountrySetups#invalidateCache()
	 */
	public void reloadCache() {
		mCountrySetupCache.reload();
	}



}
