/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import java.math.BigDecimal;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class ExchangeRateSpread extends BusinessEntity {
	/**										
	 * Storage: EXCHANGE_RATE_SPREAD_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mSpreadId;
	
	/**										
	 * Spread		
	 */										
	private BigDecimal mExchangeRateSpread;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;


	/**											
	 * @return Returns the exchangeRateSpread.													
	 */											
	public java.math.BigDecimal getExchangeRateSpread() {
		return mExchangeRateSpread;
	}
	/**
	 * @param pExchangeRate The exchangeRateSpread to set.
	 */
	public void setExchangeRateSpread(java.math.BigDecimal pExchangeRate) {
		mExchangeRateSpread = pExchangeRate;
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**
	 * 
	 * @return
	 */
	public long getSpreadId() {
		return mSpreadId;
	}
	
	/**
	 * 
	 * @param pSpreadId
	 */
	public void setSpreadId(long pSpreadId) {
		mSpreadId = pSpreadId;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mSpreadId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("spreadId", CodeGeneration.toObject(mSpreadId));
		vMap.put("exchangeRateSpread", CodeGeneration.toObject(mExchangeRateSpread));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("exchangeRateSpread")) mExchangeRateSpread = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("exchangeRate"));
	}
}
