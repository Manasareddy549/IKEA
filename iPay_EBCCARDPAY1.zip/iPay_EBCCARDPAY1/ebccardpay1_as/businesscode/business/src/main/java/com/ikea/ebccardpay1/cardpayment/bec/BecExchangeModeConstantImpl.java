/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

/**
 * @author dalq
 *
 *
 */
public class BecExchangeModeConstantImpl implements BecExchangeModeConstant {

	/**
	 * 
	 */
	public BecExchangeModeConstantImpl() {
		super();

	}

}
