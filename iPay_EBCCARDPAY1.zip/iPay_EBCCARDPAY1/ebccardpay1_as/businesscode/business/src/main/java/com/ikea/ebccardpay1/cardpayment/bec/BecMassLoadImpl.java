package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.be.ReasonCode;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefRange;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.CardNumberNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.MassLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.MassLoadWrongStateException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.CheckDigits;
import com.ikea.ebccardpay1.cardpayment.utils.CountrySetups;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebccardpay1.client.bs.BsProcessMassLoad;
import com.ikea.ebccardpay1.client.vo.VoMassLoadKey;
import com.ikea.ebccardpay1.common.Amounts;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.ebcframework.spring.BeanFactory;
import com.ikea.mdsd.ValueObjects;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.Validate;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class BecMassLoadImpl
  implements BecMassLoad, InitializingBean
{
  private static final Logger mCategory = LoggerFactory.getLogger(BecMassLoadImpl.class);
  private BefMassLoad mBefMassLoad;
  private BefAmount mBefAmount;
  private BefRange mBefRange;
  private BefCardNumber mBefCardNumber;
  private BefCard mBefCard;
  private TimeSource mTimeSource;
  private Units mUnits;
  private UtilsFactory mUtilsFactory;
  private EbcEnvironment mEbcEnvironment;
  private BsContext mBsContext;
  private EbcProperties mEbcProperties;
  private BefTransaction mBefTransaction;
  private UserEnvironment mUserEnvironment;
  private CountrySetups mCountrySetups = null;
  private MassLoad mMassLoad;
  private BecCard mBecCard = null;
  private BecTransaction mBecTransaction = null;
  private BecFactory mBecFactory;
  private DateFormat sDateFormat = new SimpleDateFormat("MM-dd-yyyy");

  private final String toLargeLockMessageEnding = "...[unable to save all errors]";
  private final int maxLockMessageSize = 4000;
  private BecCardNumber mBecCardNumber = null;

  public BecMassLoadImpl(BefMassLoad pBefMassLoad, BefAmount pBefAmount, BefRange pBefRange, BefCardNumber pBefCardNumber, Units pUnits, TimeSource pTimeSource, EbcEnvironment pEbcEnvironment, BecCard pBecCard, BecTransaction pBecTransaction, UtilsFactory pUtilsFactory, BecFactory pBecFactory, BsContext pBsContext, EbcProperties pEbcProperties, BefTransaction pBefTransaction, BecCardNumber pBecCardNumber, BefCard pBefCard, CountrySetups pCountrySetups)
  {
    this.mBefMassLoad = pBefMassLoad;
    this.mBefAmount = pBefAmount;
    this.mBefRange = pBefRange;
    this.mBefCardNumber = pBefCardNumber;
    this.mUnits = pUnits;
    this.mTimeSource = pTimeSource;
    this.mEbcEnvironment = pEbcEnvironment;
    this.mBecCard = pBecCard;
    this.mBecTransaction = pBecTransaction;
    this.mUtilsFactory = pUtilsFactory;
    this.mBecFactory = pBecFactory;
    this.mBsContext = pBsContext;
    this.mEbcProperties = pEbcProperties;
    this.mBefTransaction = pBefTransaction;
    this.mBecCardNumber = pBecCardNumber;
    this.mBefCard = pBefCard;
    this.mCountrySetups = pCountrySetups;
  }

  void validate()
  {
    Validate.notNull(this.mBefMassLoad);
    Validate.notNull(this.mBefAmount);
    Validate.notNull(this.mBefRange);
    Validate.notNull(this.mBefCardNumber);
    Validate.notNull(this.mUnits);
    Validate.notNull(this.mTimeSource);
    Validate.notNull(this.mEbcEnvironment);
    Validate.notNull(this.mBecCard);
    Validate.notNull(this.mBecTransaction);
    Validate.notNull(this.mUtilsFactory);
    Validate.notNull(this.mBecFactory);
    Validate.notNull(this.mBsContext);
    Validate.notNull(this.mEbcProperties);
    Validate.notNull(this.mBefTransaction);
    Validate.notNull(this.mBecCardNumber);
    Validate.notNull(this.mBefCard);
    Validate.notNull(this.mCountrySetups);
  }

  public void afterPropertiesSet() throws Exception
  {
    validate();
  }

  public BecMassLoad init(long pMassLoadId)
  {
    this.mMassLoad = ((MassLoad)this.mBefMassLoad.findByPrimaryKey(pMassLoadId));
    return this;
  }

  public BecMassLoad init(MassLoad pMassLoad)
  {
    this.mMassLoad = pMassLoad;
    return this;
  }

  public BecMassLoad init(UserEnvironment pUserEnvironment)
  {
    this.mUserEnvironment = pUserEnvironment;
    return this;
  }

  public MassLoad getMassLoad()
    throws ValueMissingException
  {
    requireMassLoad();
    return this.mMassLoad;
  }

  public VoMassLoad getVoMassLoad()
    throws ValueMissingException
  {
    requireMassLoad();

    if (this.mMassLoad.isBusinessEntityDeleted()) {
      return null;
    }

    VoMassLoad vVoMassLoad = new VoMassLoad();
    ValueObjects.assignToValueObject(vVoMassLoad, this.mMassLoad);
    mCategory.debug(new StringBuilder().append("Added mass load ").append(vVoMassLoad.getMassLoadId()).append(" ").append(vVoMassLoad.getName()).toString());

    if (this.mMassLoad.getBonusCode() != null) {
      VoBonusCodeBriefRef vVoBonusCodeBriefRef = new VoBonusCodeBriefRef();
      ValueObjects.assignToValueObject(vVoBonusCodeBriefRef, this.mMassLoad.getBonusCode());

      vVoMassLoad.setVoBonusCodeBriefRef(vVoBonusCodeBriefRef);
    }

    Map vMap = this.mBefAmount.usageByMassLoad(this.mMassLoad);

    vVoMassLoad.setUsageAmount((BigDecimal)vMap.get("usageAmount"));
    vVoMassLoad.setTotalAmount((BigDecimal)vMap.get("totalAmount"));
    try {
      Range mRange = (Range)this.mBefRange.findByPrimaryKey(this.mMassLoad.getRange().getRangeId());

      if (mRange.getHeader() != null)
      {
        String[] vDate = new String(mRange.getHeader()).split(";");
        try {
          vVoMassLoad.setExpiryDate(this.sDateFormat.parse(vDate[1]));
        }
        catch (ParseException e) {
          vVoMassLoad.setExpiryDate(null);
        }
      }
      else
      {
        vVoMassLoad.setExpiryDate(null);
      }

    }
    catch (Exception localException)
    {
    }

    return vVoMassLoad;
  }

  public VoBonusComplete getVoMassLoadBonus()
    throws ValueMissingException
  {
    requireMassLoad();

    if (this.mMassLoad.isBusinessEntityDeleted()) {
      return null;
    }

    VoBonusComplete vVoBonusComplete = new VoBonusComplete();
    ValueObjects.assignToValueObject(vVoBonusComplete, this.mMassLoad);
    mCategory.debug(new StringBuilder().append("Added mass load ").append(vVoBonusComplete.getBonusId()).append(" ").append(vVoBonusComplete.getCountryCode()).toString());

    Map vMap = this.mBefAmount.usageByMassLoad(this.mMassLoad);

    vVoBonusComplete.setUsageAmount((BigDecimal)vMap.get("usageAmount"));
    vVoBonusComplete.setTotalAmount((BigDecimal)vMap.get("totalAmount"));

    return vVoBonusComplete;
  }

  public void manage(VoMassLoad pVoMassLoad)
    throws IkeaException, InvalidCardNumberException, RangeNotFoundException, MassLoadException, ValueMissingException
  {
    if ("NEW".equals(pVoMassLoad.getObjectState()))
      createMassLoad(pVoMassLoad);
    else if ("MOD".equals(pVoMassLoad.getObjectState()))
    {
      updateMassLoad(pVoMassLoad);
    } else if ("READ".equals(pVoMassLoad.getObjectState()))
    {
      updateMassLoad(pVoMassLoad);
    } else if ("REM".equals(pVoMassLoad.getObjectState()))
    {
      removeMassLoad(pVoMassLoad);
    }
    else throw new ValueMissingException(new StringBuilder().append("Illegal Object State set! Can not handle '").append(pVoMassLoad.getObjectState()).append("'.").toString());
  }

  public void lock()
    throws ValueMissingException, MassLoadException
  {
    requireMassLoad();

    checkState("INITIATED");

    triggerProcessing("LOCKED");
  }

  public void unlock()
    throws ValueMissingException, MassLoadException
  {
    requireMassLoad();

    checkState("LOCKED");

    triggerProcessing("INITIATED");
  }

  public void authorize()
    throws ValueMissingException, MassLoadException, FourEyesException, IkeaException
  {
    requireMassLoad();

    IkeaUserProfile vIkeaUserProfile = this.mBsContext.getUserProfile();
    if (vIkeaUserProfile == null) {
      throw new ValueMissingException("User Profile could not be found");
    }
    String VUserId = vIkeaUserProfile.getUID().toLowerCase();

    checkState("LOCKED");
    checkCountry();

    if (VUserId.equals(this.mMassLoad.getCreatedBy().toLowerCase())) {
      throw new FourEyesException("The same user can not both initiate and authorize the mass load.");
    }

    if (VUserId.equals(this.mMassLoad.getUpdatedBy().toLowerCase())) {
      throw new FourEyesException("The same user can not both update and authorize the mass load.");
    }

    this.mMassLoad.setMassLoadState("AUTHORIZED");

    this.mMassLoad.setAuthorizedDateTime(this.mTimeSource.currentDate());
    this.mMassLoad.setAuthorizedBy(VUserId);
  }

  public void release()
    throws ValueMissingException, MassLoadException, FourEyesException, IkeaException
  {
    requireMassLoad();

    IkeaUserProfile vIkeaUserProfile = this.mBsContext.getUserProfile();
    if (vIkeaUserProfile == null) {
      throw new ValueMissingException("User Profile could not be found");
    }
    String vUserId = vIkeaUserProfile.getUID().toLowerCase();

    checkState("AUTHORIZED");
    checkCountry();

    if (vUserId.equals(this.mMassLoad.getAuthorizedBy())) {
      throw new FourEyesException("The same user can not both authorize and release the mass load.");
    }

    triggerProcessing("RELEASED");
  }

  public void posRelease(long massloadId, String BuCode, String BuType, String CountryCode, String EmployeeId)
    throws ValueMissingException, MassLoadException, FourEyesException, IkeaException
  {
    requireMassLoad();

    VoMassLoadKey vVoMassLoadKey = new VoMassLoadKey();
    vVoMassLoadKey.setMassLoadId(this.mMassLoad.getMassLoadId());

    String pButype = BuType;
    String pBuCode = BuCode;
    String pCountryCode = CountryCode;

    String cardnumber = this.mMassLoad.getFromCardNumberString();

    if (cardnumber.charAt(6) != '2') {
      mCategory.info(new StringBuilder().append("Card Type Digit ").append(cardnumber.charAt(6)).toString());
      throw new MassLoadException("Only Giftcard massload are allowed to process...!");
    }

    mCategory.info(new StringBuilder().append("Card Type Digit is ").append(cardnumber.charAt(6)).append(" which is Gift Card").toString());

    checkState("AUTHORIZED");

    if ((!pCountryCode.equalsIgnoreCase(this.mMassLoad.getCountryCode())) || (!pButype.equalsIgnoreCase(this.mMassLoad.getBuType())) || (!pBuCode.equalsIgnoreCase(this.mMassLoad.getBuCode())))
    {
      throw new MassLoadException(new StringBuilder().append("The Mass Load belongs to the country code '").append(this.mMassLoad.getCountryCode()).append("' BU type '").append(this.mMassLoad.getBuType()).append("' and ").append("Bu Code '").append(this.mMassLoad.getBuCode()).append("'. Your country code '").append(pCountryCode).append("' BU type '").append(pButype).append("' and Bu Code is '").append(pBuCode).append("'.").toString());
    }

    BusinessUnitEnvironment vBusinessUnitEnvironment = this.mUtilsFactory.createBusinessUnitEnvironment(this.mMassLoad.getBuType(), this.mMassLoad.getBuCode());

    TransactionEnvironment vTransactionEnvironment = this.mUtilsFactory.createTransactionEnvironment("TPNet", null);

    this.mMassLoad.setWishedUserId(EmployeeId);

    this.mMassLoad.setLockMessages(null);
    this.mMassLoad.setWishedMassLoadState("RELEASED");
    processTransactions(true, vBusinessUnitEnvironment, vTransactionEnvironment);
  }

  public void posWithdraw(long massloadId, String BuCode, String BuType, String CountryCode, String EmployeeId)
    throws ValueMissingException, MassLoadException, IkeaException
  {
    requireMassLoad();

    VoMassLoadKey vVoMassLoadKey = new VoMassLoadKey();
    vVoMassLoadKey.setMassLoadId(this.mMassLoad.getMassLoadId());

    String pButype = BuType;
    String pBuCode = BuCode;
    String pCountryCode = CountryCode;

    String cardnumber = this.mMassLoad.getFromCardNumberString();

    if (cardnumber.charAt(6) != '2') {
      mCategory.info(new StringBuilder().append("Card Type Digit ").append(cardnumber.charAt(6)).toString());
      throw new MassLoadException("Only Giftcard massload are allowed to process...!");
    }

    mCategory.info(new StringBuilder().append("Card Type Digit is ").append(cardnumber.charAt(6)).append(" which is Gift Card").toString());

    checkState("AUTHORIZED", "RELEASED");

    if ((!pCountryCode.equalsIgnoreCase(this.mMassLoad.getCountryCode())) || (!pButype.equalsIgnoreCase(this.mMassLoad.getBuType())) || (!pBuCode.equalsIgnoreCase(this.mMassLoad.getBuCode())))
    {
      throw new MassLoadException(new StringBuilder().append("The Mass Load belongs to the country code '").append(this.mMassLoad.getCountryCode()).append("' BU type '").append(this.mMassLoad.getBuType()).append("' and ").append("Bu Code '").append(this.mMassLoad.getBuCode()).append("'. Your country code '").append(pCountryCode).append("' BU type '").append(pButype).append("' and Bu Code is '").append(pBuCode).append("'.").toString());
    }

    BusinessUnitEnvironment vBusinessUnitEnvironment = this.mUtilsFactory.createBusinessUnitEnvironment(this.mMassLoad.getBuType(), this.mMassLoad.getBuCode());

    TransactionEnvironment vTransactionEnvironment = this.mUtilsFactory.createTransactionEnvironment("TPNet", null);

    this.mMassLoad.setWishedUserId(EmployeeId);

    this.mMassLoad.setLockMessages(null);
    this.mMassLoad.setWishedMassLoadState("WITHDRAWN");
    processWithdrawnMassload(vBusinessUnitEnvironment, vTransactionEnvironment);
  }

  public void withdraw()
    throws ValueMissingException, MassLoadException, IkeaException
  {
    requireMassLoad();

    IkeaUserProfile vIkeaUserProfile = this.mBsContext.getUserProfile();
    if (vIkeaUserProfile == null) {
      throw new ValueMissingException("User Profile could not be found");
    }

    checkState("AUTHORIZED", "RELEASED");

    checkCountry();

    triggerProcessing("WITHDRAWN");
  }

  @Transactional(propagation=Propagation.REQUIRES_NEW)
  public int process(long pMassLoadId)
    throws FourEyesException, ValueMissingException, MassLoadException, IkeaException
  {
    init(pMassLoadId);
    requireMassLoad();

    int vCount = 0;

    boolean isProcessing = "PROCESSING".equals(this.mMassLoad.getMassLoadState());

    if (!isProcessing) {
      mCategory.info("Will not process Mass Load since it is not in processing state. Aborting.");

      return 0;
    }

    boolean isWishedLocked = "LOCKED".equals(this.mMassLoad.getWishedMassLoadState());

    boolean isWishedInitiated = "INITIATED".equals(this.mMassLoad.getWishedMassLoadState());

    boolean isWishedReleased = "RELEASED".equals(this.mMassLoad.getWishedMassLoadState());

    boolean isWishedWithdrawn = "WITHDRAWN".equals(this.mMassLoad.getWishedMassLoadState());

    IkeaUserProfile vIkeaUserProfile = this.mBsContext.getUserProfile();
    if (vIkeaUserProfile == null) {
      throw new ValueMissingException("User Profile could not be found");
    }
    String vUserId = vIkeaUserProfile.getUID();

    BusinessUnitEnvironment vBusinessUnitEnvironment = this.mUtilsFactory.createBusinessUnitEnvironment(this.mMassLoad.getBuType(), this.mMassLoad.getBuCode());

    TransactionEnvironment vTransactionEnvironment = this.mUtilsFactory.createTransactionEnvironment("IPAY", null);

    if (isWishedLocked) {
      vCount = processLock(vBusinessUnitEnvironment, vTransactionEnvironment);
    }
    else if (isWishedInitiated) {
      vCount = processUnlock(vBusinessUnitEnvironment, vTransactionEnvironment);
    }
    else if (isWishedReleased)
    {
      if (vUserId.equals(this.mMassLoad.getAuthorizedBy())) {
        throw new FourEyesException("The same user can not both authorize and release the mass load.");
      }

      vCount = processTransactions(true, vBusinessUnitEnvironment, vTransactionEnvironment);
    }
    else if (isWishedWithdrawn) {
      vCount = processWithdrawnMassload(vBusinessUnitEnvironment, vTransactionEnvironment);
    }
    else
    {
      mCategory.info("No wished state set in processing");
    }

    this.mBefMassLoad.save(this.mMassLoad);

    return vCount;
  }

  protected int processTransactions(boolean pIsRelease, BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment)
    throws IkeaException, ValueMissingException
  {
    int vCount = (int)this.mMassLoad.getLockCount();

    StringBuffer vMessages = new StringBuffer();

    if (this.mMassLoad.getLockMessages() != null) {
      vMessages.append(this.mMassLoad.getLockMessages());
    }

    this.mMassLoad.setReleasedDateTime(this.mTimeSource.currentDate());
    this.mMassLoad.setReleasedBy(this.mMassLoad.getWishedUserId());

    this.mMassLoad.setLockCount(this.mMassLoad.getLockCount());
    this.mMassLoad.setLockMessages(vMessages.toString());

    this.mMassLoad.setCurrentCardNumberId(0L);
    this.mMassLoad.setMassLoadState(this.mMassLoad.getWishedMassLoadState());
    this.mMassLoad.setWishedMassLoadState(null);
    this.mMassLoad.setWishedUserId(null);
    Range vRange = this.mMassLoad.getRange();
    String[] headerSplit = vRange.getHeader().split(";");
    String indate = headerSplit[1];

    List<CardNumber> vList = this.mBefCardNumber.findByRangeId(vRange.getRangeId());

    for (CardNumber vCardNumber : vList)
    {
      Card vCard = (Card)this.mBefCard.findByPrimaryKey(vCardNumber.getCard().getCardId());
      try {
        if (indate.equalsIgnoreCase(" "))
        {
          vCard = resetExpireDate(vCard);
        }
        else {
          try {
            vCard.setExpireDate(Dates.withoutTime(new DateTime(this.sDateFormat.parse(headerSplit[1]))));
          }
          catch (ParseException e) {
            vCard = resetExpireDate(vCard);
          }
        }
        this.mBefCard.update(vCard);
      }
      catch (CountrySetupException e)
      {
        mCategory.info(e.getMessage());
      }

    }

    try
    {
      getMassLoadedTransactions(pBusinessUnitEnvironment, pTransactionEnvironment);
    }
    catch (Exception e)
    {
      mCategory.info(e.getMessage());
    }

    return vCount;
  }

  public void getMassLoadedTransactions(BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment) throws Exception {
    List<Transaction> massLoadedTranscations = this.mBefMassLoad.getMassLoadedTranscation(this.mMassLoad);
    for (Transaction pTransaction : massLoadedTranscations) {
      this.mBecTransaction.init(pTransaction, pBusinessUnitEnvironment, pTransactionEnvironment);
      this.mBecTransaction.setMassLoad(this.mMassLoad);
      this.mBecTransaction.updateMassLoadedTransactions(pTransaction);
    }
    this.mBecTransaction.publishTransactions();
  }

  protected int processUnlock(BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment)
    throws ValueMissingException
  {
    requireMassLoad();
    int vCount = 0;
    try {
      this.mBefTransaction.deleteByMassload(this.mMassLoad);
      vCount = this.mBefAmount.deleteByMassLoad(this.mMassLoad);
    }
    catch (Exception e)
    {
      mCategory.warn(new StringBuilder().append("Error when processing unlock of mass load id '").append(this.mMassLoad.getMassLoadId()).append("' card number id '").append("'. ").append(e.getMessage()).toString());
    }

    this.mMassLoad.setLockCount(0L);
    this.mMassLoad.setLockMessages(new StringBuilder().append("Deleted ").append(vCount).append(" amounts.").toString());

    this.mMassLoad.setCurrentCardNumberId(0L);
    this.mMassLoad.setMassLoadState(this.mMassLoad.getWishedMassLoadState());
    this.mMassLoad.setWishedMassLoadState(null);
    this.mMassLoad.setWishedUserId(null);

    return -1 * vCount;
  }

  protected int processLock(BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment)
    throws ValueMissingException, IkeaException
  {
    requireMassLoad();

    int vCount = 0;
    int vErrorCount = 0;
    int vMaxCount = getMaxCardsInOneProcess();

    StringBuffer vMessages = new StringBuffer();

    if (this.mMassLoad.getRange() == null)
    {
      Range vRange = (Range)this.mBefRange.create();
      vRange.setCountryCode(this.mMassLoad.getCountryCode());
      vRange.setName(this.mMassLoad.getName());
      vRange.setImportState("MASSLOAD");
      this.mBefRange.save(vRange);
      this.mMassLoad.setRange(vRange);
    }
    Range vRange = this.mMassLoad.getRange();

    String vFromCardNumberString = this.mMassLoad.getFromCardNumberString();
    if (this.mMassLoad.getCurrentCardNumberId() != 0L)
    {
      BecCardNumber vBecCardNumber = this.mBecFactory.createBecCardNumber().init(this.mMassLoad.getCurrentCardNumberId());

      vFromCardNumberString = vBecCardNumber.composeCardNumberString(vBecCardNumber.getCardNumber());

      mCategory.info(new StringBuilder().append("Current card number string ").append(vFromCardNumberString).toString());
    }

    String[] vCardNumbers = CheckDigits.generateCardNumbers(vFromCardNumberString, this.mMassLoad.getUntilCardNumberString());

    mCategory.info(new StringBuilder().append("Locking ").append(vCardNumbers.length).append(" card numbers [").append(vFromCardNumberString).append("->").append(this.mMassLoad.getUntilCardNumberString()).append("]").toString());

    List vList = new LinkedList();

    for (int i = 0; i < vCardNumbers.length; i++) {
      String vCardNumber = vCardNumbers[i];
      try
      {
        this.mBecCard.init(pBusinessUnitEnvironment, pTransactionEnvironment);
        this.mBecCard.init(vCardNumber, pBusinessUnitEnvironment);

        if (vCount >= vMaxCount) {
          mCategory.info(new StringBuilder().append("Aborting since we have processed max number of ").append(vMaxCount).toString());

          this.mMassLoad.setLockCount(this.mMassLoad.getLockCount() + vCount);
          this.mMassLoad.setLockMessages(vMessages.toString());
          this.mMassLoad.setCurrentCardNumberId(this.mBecCard.getCardNumber().getCardNumberId());

          mCategory.info(new StringBuilder().append("Current card number id:").append(this.mMassLoad.getCurrentCardNumberId()).toString());

          return vCount;
        }

        this.mBecCard.loadMassLoad(this.mMassLoad);
        BecCardNumber vBecCardNumber = this.mBecFactory.createBecCardNumber();
        vBecCardNumber.findCardNumber(vCardNumber);
        Card vCard = vBecCardNumber.getCardNumber().getCard();
        Amount vAmount = findAmount(this.mMassLoad, vCard);
        this.mBecTransaction.init(vCard, vAmount, pBusinessUnitEnvironment, pTransactionEnvironment);

        this.mBecTransaction.setMassLoad(this.mMassLoad);

        pTransactionEnvironment = this.mUtilsFactory.createTransactionEnvironment("IPAY", null);

        this.mBecTransaction.createMassLoadTransaction(this.mMassLoad);

        vList.add(this.mBecCard.getCardNumber());
        vCount++;
      } catch (CardPayException e) {
        mCategory.warn(new StringBuilder().append("Error when processing lock of mass load id '").append(this.mMassLoad.getMassLoadId()).append("'. ").append(e.getMessage()).toString());

        appendLockMessage(vMessages, vCardNumber, e.getMessage());

        vErrorCount++;
      }

    }

    this.mMassLoad.setCurrentCardNumberId(0L);
    this.mMassLoad.setLockCount(this.mMassLoad.getLockCount() + vCount);
    this.mMassLoad.setLockMessages(vMessages.toString());

    this.mMassLoad.setMassLoadState(this.mMassLoad.getWishedMassLoadState());
    this.mMassLoad.setWishedMassLoadState(null);
    this.mMassLoad.setWishedUserId(null);

    return vCount;
  }

  protected void appendLockMessage(StringBuffer vMessages, String vCardNumber, String errorMessage)
  {
    if (vMessages.indexOf("...[unable to save all errors]") != -1) {
      return;
    }
    String appendingString = new StringBuilder().append(CardPaymentLogger.cardNumberToString(vCardNumber)).append(": ").append(errorMessage).append("\n").toString();

    if (vMessages.length() + appendingString.length() < 4000) {
      vMessages.append(appendingString);
    } else {
      if (vMessages.length() + "...[unable to save all errors]".length() > 4000) {
        vMessages.setLength(4000 - "...[unable to save all errors]".length());
      }
      vMessages.append("...[unable to save all errors]");
    }
  }

  protected void checkState(String pWishedState)
    throws ValueMissingException, MassLoadException
  {
    checkState(pWishedState, null);
  }

  protected void checkState(String pWishedState1, String pWishedState2)
    throws ValueMissingException, MassLoadException
  {
    requireMassLoad();

    boolean vInWishedState1 = pWishedState1 != null ? pWishedState1.equals(this.mMassLoad.getMassLoadState()) : false;

    boolean vInWishedState2 = pWishedState2 != null ? pWishedState2.equals(this.mMassLoad.getMassLoadState()) : false;

    if ((!vInWishedState1) && (!vInWishedState2))
      throw new MassLoadWrongStateException(new StringBuilder().append("Mass Load needs to be in state '").append(pWishedState1).append(pWishedState2 != null ? new StringBuilder().append("' or '").append(pWishedState2).toString() : "").append("'. Current state for '").append(this.mMassLoad.getName()).append("' is '").append(this.mMassLoad.getMassLoadState()).append("'.").toString());
  }

  protected void checkCountry()
    throws ValueMissingException, MassLoadException, IkeaException
  {
    if (filterUserToAllowMassload()) {
      requireMassLoad();

      String pCountryCode = countryCodeForUser();

      if (!pCountryCode.equalsIgnoreCase(this.mMassLoad.getCountryCode()))
        throw new MassLoadException(new StringBuilder().append("The Mass Load belongs to the country code '").append(this.mMassLoad.getCountryCode()).append("'. Your country code is '").append(pCountryCode).append("'.").toString());
    }
  }

  protected void checkCardNumber()
    throws ValueMissingException, InvalidCardNumberException
  {
    requireMassLoad();
    BecCardNumber vBecCardNumber = this.mBecFactory.createBecCardNumber();

    vBecCardNumber.splitCardNumber(this.mMassLoad.getFromCardNumberString());
    vBecCardNumber.splitCardNumber(this.mMassLoad.getUntilCardNumberString());
  }

  protected void createMassLoad(VoMassLoad pVoMassLoad)
    throws IkeaException, RangeNotFoundException, MassLoadException, InvalidCardNumberException, ValueMissingException
  {
    this.mUnits.checkValidBusinessUnit(pVoMassLoad.getBuType(), pVoMassLoad.getBuCode());

    mCategory.info(new StringBuilder().append("Crreating new Mass Load '").append(pVoMassLoad.getName()).append("'.").toString());

    this.mMassLoad = ((MassLoad)this.mBefMassLoad.create());
    ValueObjects.assignToBusinessEntity(this.mMassLoad, pVoMassLoad);

    checkCardNumber();
    
    //ReasonCode reasonCode = (ReasonCode)(pVoMassLoad.getReasonCode());

    this.mMassLoad.setMassLoadState("INITIATED");

    this.mMassLoad.setCountryCode(countryCodeForUser());
    this.mMassLoad.setAuthorizedBy(null);
    this.mMassLoad.setAuthorizedDateTime(null);
    this.mMassLoad.setReleasedBy(null);
    this.mMassLoad.setReleasedDateTime(null);
    this.mMassLoad.setWithdrawnBy(null);
    this.mMassLoad.setWithdrawnDateTime(null);
    this.mMassLoad.setReasonCode(pVoMassLoad.getReasonCode());
    this.mMassLoad.setCompanyName(pVoMassLoad.getCompanyName());
    this.mMassLoad.setCustomerType(pVoMassLoad.getCustomerType());

    manageBonusCode(pVoMassLoad.getVoBonusCodeBriefRef());

    BusinessUnitEnvironment vBusinessUnitEnvironment = this.mUtilsFactory.createBusinessUnitEnvironment(this.mMassLoad.getBuType(), this.mMassLoad.getBuCode());

    int vCount = 0;
    int vErrorCount = 0;
    int vMaxCount = getMaxCardsInOneProcess();

    StringBuffer vMessages = new StringBuffer();
    if (this.mMassLoad.getLockMessages() != null) {
      vMessages.append(this.mMassLoad.getLockMessages());
    }
    if (this.mMassLoad.getRange() == null)
    {
      Range vRange = (Range)this.mBefRange.create();
      vRange.setCountryCode(this.mMassLoad.getCountryCode());
      vRange.setName(this.mMassLoad.getName());
      if (pVoMassLoad.getExpiryDate() == null)
      {
        vRange.setHeader("MassLoadExpiryDate; ");
      }
      else {
        vRange.setHeader(new StringBuilder().append("MassLoadExpiryDate;").append(this.sDateFormat.format(pVoMassLoad.getExpiryDate())).toString());
      }

      vRange.setImportState("MASSLOAD");

      String vFromCardNumberString = this.mMassLoad.getFromCardNumberString();

      String[] vCardNumbers = CheckDigits.generateCardNumbers(vFromCardNumberString, this.mMassLoad.getUntilCardNumberString());

      for (String vCardNumber : vCardNumbers)
      {
        BecCard vBecCard = this.mBecFactory.createBecCard();
        try
        {
          vBecCard.createCard(vCardNumber);

          vRange.connectCardNumber(vBecCard.getCard().getCardNumber());
        }
        catch (DuplicateCardException e)
        {
          BecCardNumber vBecCardNumber = this.mBecFactory.createBecCardNumber();
          try {
            vBecCardNumber.findCardNumber(vCardNumber);
            vRange.connectCardNumber(vBecCardNumber.getCardNumber());
          }
          catch (InvalidCardNumberException e1) {
            mCategory.info(e1.getMessage());
          }
          catch (CardNumberNotFoundException e1) {
            mCategory.info(e1.getMessage());
          }

        }
        catch (InvalidCardNumberException e)
        {
          throw new MassLoadException(new StringBuilder().append("Invalid Card Number ").append(vCardNumber).append("Kindly remove the card and try again.").toString());
        }

      }

      this.mBefRange.save(vRange);
      this.mMassLoad.setRange(vRange);
    }
    this.mMassLoad.setCurrentCardNumberId(0L);
    this.mBefMassLoad.save(this.mMassLoad);
  }

  protected void updateMassLoad(VoMassLoad pVoMassLoad)
    throws ValueMissingException, RangeNotFoundException, MassLoadException, IkeaException
  {
    mCategory.info(new StringBuilder().append("Updating Mass Load '").append(pVoMassLoad.getName()).append("'.").toString());

    init(pVoMassLoad.getMassLoadId());

    checkState("INITIATED");
    checkCountry();
    ValueObjects.assignToBusinessEntity(this.mMassLoad, pVoMassLoad);

    List crdNumberList = this.mBefCardNumber.findByRangeId(this.mMassLoad.getRange().getRangeId());

    Range vRange = (Range)this.mBefRange.findByPrimaryKey(this.mMassLoad.getRange().getRangeId());
    if (!this.mMassLoad.getName().equals(pVoMassLoad.getName()))
      vRange.setName(pVoMassLoad.getName());
    String vFromCardNumberString = pVoMassLoad.getFromCardNumberString();

    String[] vCardNumbers = CheckDigits.generateCardNumbers(vFromCardNumberString, pVoMassLoad.getUntilCardNumberString());

    for (String vCardNumber : vCardNumbers)
    {
      BecCard vBecCard = this.mBecFactory.createBecCard();
      try
      {
        vBecCard.createCard(vCardNumber);

        vRange.connectCardNumber(vBecCard.getCard().getCardNumber());
      }
      catch (DuplicateCardException e)
      {
        BecCardNumber vBecCardNumber = this.mBecFactory.createBecCardNumber();
        try {
          vBecCardNumber.findCardNumber(vCardNumber);
          vRange.connectCardNumber(vBecCardNumber.getCardNumber());
        }
        catch (InvalidCardNumberException e1) {
          mCategory.info(e.getMessage());
        }
        catch (CardNumberNotFoundException e1) {
          mCategory.info(e.getMessage());
        }

      }
      catch (InvalidCardNumberException e)
      {
        throw new MassLoadException(new StringBuilder().append("Invalid Card Number ").append(vCardNumber).append("Kindly remove the card and try again.").toString());
      }

    }

    if (pVoMassLoad.getExpiryDate() != null)
    {
      vRange.setHeader(new StringBuilder().append("MassLoadExpiryDate;").append(this.sDateFormat.format(pVoMassLoad.getExpiryDate())).toString());
    }
    else
    {
      vRange.setHeader("MassLoadExpiryDate; ");
    }

    this.mBefRange.update(vRange);
    this.mBefMassLoad.saveOrUpdate(this.mMassLoad);
  }

  protected void manageBonusCode(VoBonusCodeBriefRef pVoBonusCodeBriefRef)
    throws ValueMissingException, MassLoadException
  {
    requireMassLoad();

    if (pVoBonusCodeBriefRef == null)
    {
      return;
    }

    if ("NEW".equals(pVoBonusCodeBriefRef.getObjectState()))
    {
      BecBonusCode vBecBonusCode = this.mBecFactory.createBecBonusCode().init(pVoBonusCodeBriefRef.getBonusCodeId());

      this.mMassLoad.setBonusCode(vBecBonusCode.getBonusCode());
    }
    else if (!"READ".equals(pVoBonusCodeBriefRef.getObjectState()))
    {
      if ("REM".equals(pVoBonusCodeBriefRef.getObjectState()))
      {
        if (this.mMassLoad.getBonusCode() != null)
          this.mMassLoad.disconnectBonusCode();
      }
      else
        throw new MassLoadException(new StringBuilder().append("Illegal Object State set! Can not handle '").append(pVoBonusCodeBriefRef.getObjectState()).append("'.").toString());
    }
  }

  protected Amount findAmount(MassLoad pMassLoad, Card pCard)
  {
    if (pMassLoad != null) {
      Iterator i = pCard.getAmounts().iterator();
      while (i.hasNext()) {
        Amount vAmount = (Amount)i.next();

        if ((vAmount != null) && (pMassLoad.equals(vAmount.getMassLoad())))
        {
          return vAmount;
        }
      }
    }

    return null;
  }

  protected void removeProperty(Map<String, Object> pMap, String pProperty)
    throws ValueMissingException
  {
    pMap.remove(pProperty);
  }

  protected void removeMassLoad(VoMassLoad pVoMassLoad)
    throws ValueMissingException, RangeNotFoundException, MassLoadException, IkeaException
  {
    mCategory.info(new StringBuilder().append("Deleting Mass Load '").append(pVoMassLoad.getName()).append("'.").toString());

    init(pVoMassLoad.getMassLoadId());

    checkState("INITIATED");
    checkCountry();

    this.mBefMassLoad.delete(this.mMassLoad);
  }

  protected String countryCodeForUser()
    throws ValueMissingException, IkeaException
  {
    if (this.mUserEnvironment == null) {
      throw new ValueMissingException("Tried to use BecMassLoad without required UserEnvironment.");
    }

    return this.mUserEnvironment.getCountryCode();
  }

  protected void triggerProcessing(String pWishedState)
    throws ValueMissingException, MassLoadException
  {
    requireMassLoad();
    try
    {
      VoMassLoadKey vVoMassLoadKey = new VoMassLoadKey();
      vVoMassLoadKey.setMassLoadId(this.mMassLoad.getMassLoadId());

      BsProcessMassLoad vBsProcessMassLoad = new BsProcessMassLoad();
      vBsProcessMassLoad.setVoMassLoadKey(vVoMassLoadKey);
      vBsProcessMassLoad.setWishedState(pWishedState);
      BsExecuter bsExecuter = BeanFactory.getBsExecuter();
      bsExecuter.executeBsAsync(vBsProcessMassLoad);
    } catch (IkeaException e) {
      mCategory.error(e.getMessage());
      throw new MassLoadException(new StringBuilder().append("Could not start processing. ").append(e.toString()).toString());
    }
  }

  protected int getMaxCardsInOneProcess()
  {
    return this.mEbcEnvironment.getMaxCardsInMassLoadProcessing();
  }

  protected void requireMassLoad()
    throws ValueMissingException
  {
    if (this.mMassLoad == null)
      throw new ValueMissingException("Tried to use BecMassLoad without required Mass Load.");
  }

  @Transactional(propagation=Propagation.REQUIRES_NEW)
  public void prepareForProcessing(String pWishedState, long pMassLoadId)
    throws ValueMissingException, MassLoadException
  {
    init(pMassLoadId);
    requireMassLoad();

    if ("LOCKED".equals(pWishedState))
      checkState("INITIATED");
    else if ("INITIATED".equals(pWishedState))
    {
      checkState("LOCKED");
    } else if ("RELEASED".equals(pWishedState))
    {
      checkState("AUTHORIZED");
    } else if ("WITHDRAWN".equals(pWishedState))
    {
      checkState("RELEASED", "AUTHORIZED");
    }
    else throw new IllegalArgumentException(new StringBuilder().append("Trying to process to a unknown state: ").append(pWishedState).toString());

    IkeaUserProfile vIkeaUserProfile = this.mBsContext.getUserProfile();
    if (vIkeaUserProfile == null) {
      throw new ValueMissingException("User Profile could not be found");
    }

    this.mMassLoad.setLockCount(0L);
    this.mMassLoad.setLockMessages(null);
    this.mMassLoad.setWishedMassLoadState(pWishedState);
    this.mMassLoad.setWishedUserId(vIkeaUserProfile.getUID());
    this.mMassLoad.setMassLoadState("PROCESSING");

    this.mBefMassLoad.save(this.mMassLoad);
  }

  protected boolean filterUserToAllowMassload() throws ValueMissingException
  {
    String vUserId = this.mUserEnvironment.getUserId();
    mCategory.info(new StringBuilder().append("filter_User : ").append(vUserId).toString());
    this.mUserEnvironment.getCountryCode();

    String vHost = this.mEbcProperties.getString("filterUserToAllowMassload", "NOSOURCE");

    ArrayList vHostList = new ArrayList(Arrays.asList(vHost.split(",")));

    mCategory.info(new StringBuilder().append("UsersToAllowMassload: ").append(vHostList).toString());
    if (vHostList.contains(vUserId)) {
      return false;
    }
    return true;
  }

  protected int processWithdrawnMassload(BusinessUnitEnvironment pBusinessUnitEnvironment, TransactionEnvironment pTransactionEnvironment)
    throws IkeaException, ValueMissingException
  {
    int vCount = 0;
    int vErrorCount = 0;

    StringBuffer vMessages = new StringBuffer();

    if (this.mMassLoad.getLockMessages() != null) {
      vMessages.append(this.mMassLoad.getLockMessages());
    }

    Range vRange = this.mMassLoad.getRange();

    Collection vRanges = new ArrayList();
    vRanges.add(vRange);

    List vList = this.mBefCardNumber.findByRange(vRanges, this.mMassLoad.getCurrentCardNumberId(), 0);

    for (Iterator j = vList.iterator(); j.hasNext(); ) {
      BigDecimal vId = (BigDecimal)j.next();
      long vCardNumberId = vId.longValue();

      CardNumber vCardNumber = (CardNumber)this.mBefCardNumber.findByPrimaryKey(vCardNumberId);

      if (vCount >= getMaxCardsInOneProcess())
      {
        this.mMassLoad.setLockCount(this.mMassLoad.getLockCount() + vCount);
        this.mMassLoad.setLockMessages(vMessages.toString());
        this.mMassLoad.setCurrentCardNumberId(vCardNumber.getCardNumberId());
        mCategory.info(new StringBuilder().append("Current card number id:").append(this.mMassLoad.getCurrentCardNumberId()).toString());

        return vCount;
      }

      try
      {
        Card vCard = vCardNumber.getCard();
        Amount vAmount = findAmount(this.mMassLoad, vCard);
        if (vAmount == null)
        {
          mCategory.debug("No amount found");
        }
        else {
          mCategory.debug(new StringBuilder().append(vAmount.getAmountId()).append(":").append(vAmount.getCurrentAmount()).toString());
          if (!Amounts.isZero(vAmount.getCurrentAmount()))
          {
            this.mBecCard.init(vCardNumber, pBusinessUnitEnvironment);
            this.mBecTransaction.init(vCard, vAmount, pBusinessUnitEnvironment, pTransactionEnvironment);

            this.mBecTransaction.setMassLoad(this.mMassLoad);

            pTransactionEnvironment = this.mUtilsFactory.createTransactionEnvironment("IPAY", null);

            if (vAmount.getCurrentAmount().doubleValue() > 0.0D) {
              this.mBecTransaction.createWithdrawMassLoadTransaction(this.mMassLoad);

              this.mBecCard.withdrawMassLoad(this.mMassLoad);
            }
            vCount++;
          }
        }
      } catch (CardPayException e) {
        mCategory.warn(new StringBuilder().append("Error when processing withdrawn of mass load id '").append(this.mMassLoad.getMassLoadId()).append("' card number id '").append(vCardNumber.getCardNumberId()).append("'. Card number string '").append(CardPaymentLogger.cardNumberToString(vCardNumber)).append("'. ").append(e.getMessage()).toString());

        vMessages.append(new StringBuilder().append(this.mBecFactory.createBecCardNumber().composeCardNumberString(vCardNumber)).append(": ").append(e.getMessage()).append("\n").toString());

        vErrorCount++;
        if (vErrorCount > 100) {
          throw new IkeaException(new StringBuilder().append("Found more than 100 errors when processing withdrawn of mass load id '").append(this.mMassLoad.getMassLoadId()).append("'. Aborting.").toString());
        }

      }

    }
    this.mBecTransaction.publishTransactions();

    this.mMassLoad.setWithdrawnDateTime(this.mTimeSource.currentDate());
    this.mMassLoad.setWithdrawnBy(this.mMassLoad.getWishedUserId());

    this.mMassLoad.setLockCount(this.mMassLoad.getLockCount() + vCount);
    this.mMassLoad.setLockMessages(vMessages.toString());

    this.mMassLoad.setCurrentCardNumberId(0L);
    this.mMassLoad.setMassLoadState(this.mMassLoad.getWishedMassLoadState());
    this.mMassLoad.setWishedMassLoadState(null);
    this.mMassLoad.setWishedUserId(null);

    return vCount;
  }

  private Card resetExpireDate(Card mCard)
    throws CountrySetupException, ValueMissingException
  {
    if ((mCard.getCountryCode() != null) && (mCard.getCountryCode().length() > 0))
    {
      mCategory.info(new StringBuilder().append("Get expireDate for country  ").append(mCard.getCountryCode()).append(".").toString());

      int vExpireDays = this.mCountrySetups.getExpireDays(mCard.getCountryCode(), mCard.getCardType());

      if (vExpireDays > 0) {
        mCategory.info(new StringBuilder().append("Resetting expire date to ").append(vExpireDays).append(" days from now.").toString());

        DateTime vNow = new DateTime(this.mTimeSource.currentDate());
        DateTime vExpireDate = vNow.plusDays(vExpireDays);

        mCard.setExpireDate(Dates.withoutTime(vExpireDate));
      } else if (vExpireDays == 0) {
        mCard.setExpireDate(null);
      }
    }
    return mCard;
  }
}
