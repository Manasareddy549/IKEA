/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

public class Range extends BusinessEntity {
	/**										
	 * Storage: RANGE_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mRangeId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<CardNumber> mCardNumbers = new java.util.LinkedHashSet<CardNumber>(0);
	private MassLoad mMassLoad;
	private java.util.Set<Campaign> mCampaigns = new java.util.LinkedHashSet<Campaign>(0);
	private Activation mActivation;

	/**										
	 * Data								
	 */										
	private String mName;
	private String mHeader;
	private String mFileName;
	private long mCount;
	private long mChecksum;
	private String mCountryCode;
	private String mImportState;

	/**											
	 * @return Returns the rangeId.													
	 */											
	public long getRangeId() {
		return mRangeId;
	}
	/**
	 * @param pRangeId The rangeId to set.
	 */
	public void setRangeId(long pRangeId) {
		mRangeId = pRangeId;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the header.													
	 */											
	public String getHeader() {
		return mHeader;
	}
	/**
	 * @param pHeader The header to set.
	 */
	public void setHeader(String pHeader) {
		mHeader = pHeader;
	}

	/**											
	 * @return Returns the fileName.													
	 */											
	public String getFileName() {
		return mFileName;
	}
	/**
	 * @param pFileName The fileName to set.
	 */
	public void setFileName(String pFileName) {
		mFileName = pFileName;
	}

	/**											
	 * @return Returns the count.													
	 */											
	public long getCount() {
		return mCount;
	}
	/**
	 * @param pCount The count to set.
	 */
	public void setCount(long pCount) {
		mCount = pCount;
	}

	/**											
	 * @return Returns the checksum.													
	 */											
	public long getChecksum() {
		return mChecksum;
	}
	/**
	 * @param pChecksum The checksum to set.
	 */
	public void setChecksum(long pChecksum) {
		mChecksum = pChecksum;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the importState.													
	 */											
	public String getImportState() {
		return mImportState;
	}
	/**
	 * @param pImportState The importState to set.
	 */
	public void setImportState(String pImportState) {
		mImportState = pImportState;
	}

	/**											
	 * @return Returns the cardNumbers.													
	 */											
	public java.util.Set<CardNumber> getCardNumbers() {
		return mCardNumbers;
	}
	/**
	 * @param pCardNumbers The cardNumbers to set.
	 */
	public void setCardNumbers(java.util.Set<CardNumber> pCardNumbers) {
		mCardNumbers = pCardNumbers;
	}

	/**											
	 * @return Returns the massLoad.													
	 */											
	public MassLoad getMassLoad() {
		return mMassLoad;
	}
	/**
	 * @param pMassLoad The massLoad to set.
	 */
	public void setMassLoad(MassLoad pMassLoad) {
		mMassLoad = pMassLoad;
	}

	/**											
	 * @return Returns the campaigns.													
	 */											
	public java.util.Set<Campaign> getCampaigns() {
		return mCampaigns;
	}
	/**
	 * @param pCampaigns The campaigns to set.
	 */
	public void setCampaigns(java.util.Set<Campaign> pCampaigns) {
		mCampaigns = pCampaigns;
	}

	/**											
	 * @return Returns the activation.													
	 */											
	public Activation getActivation() {
		return mActivation;
	}
	/**
	 * @param pActivation The activation to set.
	 */
	public void setActivation(Activation pActivation) {
		mActivation = pActivation;
	}

	/**
	 * Connect a CardNumber.
	 * @param pCardNumber
	 */
	public void connectCardNumber(CardNumber pCardNumber) {
		getCardNumbers().add(pCardNumber);
		if(pCardNumber != null) {
			pCardNumber.getRanges().add(this);
		}
	}

	/**
	 * Disconnect a CardNumber.
	 * @param pCardNumber
	 */
	public void disconnectCardNumber(CardNumber pCardNumber) {
		if(pCardNumber != null) {
			pCardNumber.getRanges().remove(this);
		}
		getCardNumbers().remove(pCardNumber);
	}

	/**
	 * Connect MassLoad.
	 * @param pMassLoad
	 */
	public void connectMassLoad(MassLoad pMassLoad) {
		setMassLoad(pMassLoad);
		if(pMassLoad != null) {
			pMassLoad.setRange(this);
		}
	}

	/**
	 * Disconnect MassLoad.
	 */
	public void disconnectMassLoad() {
		if(getMassLoad() != null) {
			getMassLoad().setRange(null);
		}
		setMassLoad(null);
	}

	/**
	 * Connect a Campaign.
	 * @param pCampaign
	 */
	public void connectCampaign(Campaign pCampaign) {
		getCampaigns().add(pCampaign);
		if(pCampaign != null) {
			pCampaign.getRanges().add(this);
		}
	}

	/**
	 * Disconnect a Campaign.
	 * @param pCampaign
	 */
	public void disconnectCampaign(Campaign pCampaign) {
		if(pCampaign != null) {
			pCampaign.getRanges().remove(this);
		}
		getCampaigns().remove(pCampaign);
	}
	
	/**
	 * Connect Activation.
	 * @param pActivation
	 */
	public void connectActivation(Activation pActivation) {
		setActivation(pActivation);
		if(pActivation != null) {
			pActivation.setRange(this);
		}
	}

	/**
	 * Disconnect Activation.
	 */
	public void disconnectActivation() {
		if(getActivation() != null) {
			getActivation().setRange(null);
		}
		setActivation(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mRangeId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("rangeId", CodeGeneration.toObject(mRangeId));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("header", CodeGeneration.toObject(mHeader));
		vMap.put("fileName", CodeGeneration.toObject(mFileName));
		vMap.put("count", CodeGeneration.toObject(mCount));
		vMap.put("checksum", CodeGeneration.toObject(mChecksum));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("importState", CodeGeneration.toObject(mImportState));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("rangeId")) mRangeId = CodeGeneration.objectTolong(pMap.get("rangeId"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("header")) mHeader = CodeGeneration.objectToString(pMap.get("header"));
		if(pMap.containsKey("fileName")) mFileName = CodeGeneration.objectToString(pMap.get("fileName"));
		if(pMap.containsKey("count")) mCount = CodeGeneration.objectTolong(pMap.get("count"));
		if(pMap.containsKey("checksum")) mChecksum = CodeGeneration.objectTolong(pMap.get("checksum"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("importState")) mImportState = CodeGeneration.objectToString(pMap.get("importState"));
	}


}
