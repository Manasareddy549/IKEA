/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefReferenceCheckImpl extends BefAbstract<ReferenceCheck> implements BefReferenceCheck {

	private final static Logger mLogger_findByReference =
		LoggerFactory.getLogger(
				BefReferenceCheckImpl.class.getName() + ".findByReference");

	private final static Logger mLogger_deleteAcknowledged =
		LoggerFactory.getLogger(
				BefReferenceCheckImpl.class.getName()
				+ ".deleteAcknowledgedOlderThan");

	private final static Logger mLogger_findByWaitingAckOlderThan =
		LoggerFactory.getLogger(
				BefReferenceCheckImpl.class.getName()
				+ ".findByWaitingAckOlderThan");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefReferenceCheckImpl(
			SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck#deleteAcknowledged(java.lang.String, java.util.List)
	 */
	public int deleteAcknowledged(String pBuType, List<String> pStores) {

		Session vSession = mSessionFactory.getCurrentSession();

		//Set criteria createdDateTime to get references older than 3days (No need to use local time)
		String vHql =
			"delete from ReferenceCheck where waitingAck=:waitingAck and buType=:buType and createdDateTime < sysdate - 3 and buCode in (:buCodes) ";

		if (mLogger_deleteAcknowledged.isDebugEnabled()) {
			mLogger_deleteAcknowledged.debug("HQL: " + vHql);
		}

		int vDeletedEntries =
			vSession
			.createQuery(vHql)
			.setBoolean("waitingAck", false)
			.setString("buType", pBuType)
			.setParameterList("buCodes", pStores)
			.executeUpdate();
		vSession.flush();

		if (mLogger_deleteAcknowledged.isDebugEnabled()) {
			mLogger_deleteAcknowledged.debug(
					"Deleted "
					+ vDeletedEntries
					+ " acknowledged entries from ReferenceCheck that for BU type "
					+ pBuType
					+ " "
					+ pStores
					+ ".");
		}
		return vDeletedEntries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck#findByReference(java.lang.String)
	 */
	public ReferenceCheck findByReference(
			String pReference,
			String pSourceSystem
			//String pSalesDay
			) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from ReferenceCheck where reference=:reference and sourceSystem = :sourceSystem";

		if (mLogger_findByReference.isDebugEnabled()) {
			mLogger_findByReference.debug("HQL: " + vHql);
		}

		ReferenceCheck vReferenceCheck =
			(ReferenceCheck) vSession
			.createQuery(vHql)
			.setParameter("reference", pReference)
			.setParameter("sourceSystem", pSourceSystem)
			//.setParameter("salesDay", pSalesDay)
			.uniqueResult();

		if (vReferenceCheck == null) {
			mLogger_findByReference.debug("No references found.");
		}
		return vReferenceCheck;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck#findByReference(java.lang.String)
	 */
	/*public List<ReferenceCheck> findByWaitingAckOlderThan(int pMinutes) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from ReferenceCheck where waitingAck=:waitingAck and createdDateTime < (sysdate -(:pMinutes / (24*60))) ";

		if (mLogger_findByWaitingAckOlderThan.isDebugEnabled()) {
			mLogger_findByWaitingAckOlderThan.debug("HQL: " + vHql);
		}

		List<ReferenceCheck> vList =
			new GenericQuery<ReferenceCheck>(vSession
				.createQuery(vHql)
				.setBoolean("waitingAck", true)
				.setInteger("pMinutes", pMinutes))
				.list();

		if (vList == null || vList.size() == 0) {
			mLogger_findByWaitingAckOlderThan.debug("No references found.");
		}
		return vList;
	}*/
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck#findByReference(java.lang.String)
	 */
	public List<ReferenceCheck> findByWaitingAckOlderThan(int pMinutes) {

		Session vSession = mSessionFactory.getCurrentSession();
		//Date currentDate=new Date();

		String vHql =
			"from ReferenceCheck where waitingAck=:waitingAck and createdDateTime < (sysdate-(ackTimeout/(24*60*60)))";
		if (mLogger_findByWaitingAckOlderThan.isDebugEnabled()) {
			mLogger_findByWaitingAckOlderThan.debug("HQL: " + vHql);
			
		}
		List<ReferenceCheck> vList =
			new GenericQuery<ReferenceCheck>(vSession
					.createQuery(vHql)
					.setCharacter("waitingAck",'Y'))
					//.setTime("cDate",currentDate))
					.list();

		if (vList == null || vList.size() == 0) {
			mLogger_findByWaitingAckOlderThan.debug("No references found.");
		}
		return vList;
	}

	@Override
	protected Class<ReferenceCheck> getBusinessEntityClass() {
		return ReferenceCheck.class;
	}

}
