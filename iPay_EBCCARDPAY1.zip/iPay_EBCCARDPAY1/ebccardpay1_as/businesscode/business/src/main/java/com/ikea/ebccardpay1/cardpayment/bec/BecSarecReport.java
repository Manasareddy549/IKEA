package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

/**
 *
 */
public interface BecSarecReport {

	/**
	 * Evaluates the dates that needs to be generated
	 * 
	 * @param pBuType
	 * @param pBuCode
	 * @param pBefIpayBusinessUnits
	 * @return List<String>
	 */
	List<String>findUngeneratedSarecReportDates(String pBuType,
			String pBuCode,
			BefIpayBusinessUnits pBefIpayBusinessUnits);
}
