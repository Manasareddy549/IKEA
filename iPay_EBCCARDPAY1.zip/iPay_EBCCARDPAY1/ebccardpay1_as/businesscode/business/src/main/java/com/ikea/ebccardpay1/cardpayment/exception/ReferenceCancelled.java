package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

public class ReferenceCancelled extends ReferenceCheckException {

	private static final long serialVersionUID = -1602722664921854758L;

	public ReferenceCancelled(String pSourceSystem, String pReference) {
		super(pSourceSystem, pReference);

	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ReferenceCancelled(mSourceSystem, mReference, mSalesDay);
	}

}
