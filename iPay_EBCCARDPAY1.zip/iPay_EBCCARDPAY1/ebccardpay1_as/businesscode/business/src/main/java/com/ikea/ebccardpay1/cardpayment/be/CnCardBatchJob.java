package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

/**
 * @author anagc
 *
 */
public class CnCardBatchJob extends BusinessEntity {
	private long cnBatchJobId;
	private String batchType;
	private String salesDay;
	private String jobExecutionIds;
	private long transactionCount;	
	private java.sql.Blob blobFile;
	private String flowNumber;
	private String fileStatus;
	private String md5String;
	private String status;
	private String errorMessage;

	/**										
	 * Common attributes	
	 */
	private int versionNo;
	private String createdBy;
	private java.util.Date createdDateTime;
	private String updatedBy;
	private java.util.Date updatedDateTime;



	public int getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(int versionNo) {
		this.versionNo = versionNo;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public java.util.Date getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(java.util.Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public java.util.Date getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(java.util.Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public long getCnBatchJobId() {
		return cnBatchJobId;
	}
	public void setCnBatchJobId(long cnBatchJobId) {
		this.cnBatchJobId = cnBatchJobId;
	}
	public String getSalesDay() {
		return salesDay;
	}
	public void setSalesDay(String salesDay) {
		this.salesDay = salesDay;
	}
	public String getJobExecutionIds() {
		return jobExecutionIds;
	}
	public void setJobExecutionIds(String jobExecutionIds) {
		this.jobExecutionIds = jobExecutionIds;
	}
	public long getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(long transactionCount) {
		this.transactionCount = transactionCount;
	}
	public java.sql.Blob getBlobFile() {
		return blobFile;
	}
	public void setBlobFile(java.sql.Blob blobFile) {
		this.blobFile = blobFile;
	}
	
	public String getFlowNumber() {
		return flowNumber;
	}
	public void setFlowNumber(String flowNumber) {
		this.flowNumber = flowNumber;
	}
	public String getMd5String() {
		return md5String;
	}
	public void setMd5String(String md5String) {
		this.md5String = md5String;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	public String getBatchType() {
		return batchType;
	}
	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
}