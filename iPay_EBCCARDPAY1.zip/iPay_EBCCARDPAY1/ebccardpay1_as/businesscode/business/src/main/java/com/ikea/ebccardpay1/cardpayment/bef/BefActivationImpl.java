/*
 * Created on 2007-feb-05
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Activation;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefActivationImpl extends BefAbstract<Activation> implements BefActivation{

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefActivationImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<Activation> getBusinessEntityClass() {
		return Activation.class;
	}

}
