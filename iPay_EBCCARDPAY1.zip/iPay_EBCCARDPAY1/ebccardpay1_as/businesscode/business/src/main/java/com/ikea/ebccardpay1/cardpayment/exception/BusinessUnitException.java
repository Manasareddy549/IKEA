/*
 * Created on 2007-jan-25
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author anms
 *
 */
public class BusinessUnitException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2028617769313681021L;
	/**
	 * 
	 */
	public BusinessUnitException() {
		super();
	}
	/**
	 * 
	 */
	public BusinessUnitException(String pMessage) {
		super(pMessage);
	}
}
