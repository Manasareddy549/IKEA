/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.orm.hibernate4.HibernateCallback;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Report;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReportRow;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.ebccardpay1.cardpayment.utils.ReportParameter;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportResults;
import com.ikea.common.TimeSource;

/**
 * @author anms
 *
 */
public class BefReportImpl extends BefAbstract<Report> implements BefReport {

	private final static Logger mLogger_retrieveReport =
		LoggerFactory.getLogger(BefReportImpl.class.getName() + ".retrieveReport");

	public BefReportImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReport#retrieveReport(java.lang.String, java.lang.String, java.util.List)
	 */
	public java.util.List<Map<String, Object>> retrieveReport(
		String pQuery1,
		String pQuery2,
		java.util.List<ReportParameter> pParameters) {

		// Create session
		Session vSession = mSessionFactory.getCurrentSession();

		// Generate parameters
		StringBuffer vHQL = new StringBuffer();
		for (ReportParameter vReportParameter : pParameters) {
			
			String vOp = vReportParameter.getOperator();

			// Check operator value to determine how to generate the HQL
			if (ReportParameter.OPERATOR_SUBSTRING.equals(vOp)) {
				vHQL.append(" and substring(");
				vHQL.append(vReportParameter.getColumnName());
				vHQL.append(",1,");
				vHQL.append(((String) vReportParameter.getValue()).length());
				vHQL.append(") = :");
				vHQL.append(vReportParameter.getVariableName());
			} else if (ReportParameter.OPERATOR_IN.equals(vOp)) {
				vHQL.append(" and ");
				vHQL.append(vReportParameter.getColumnName());
				vHQL.append(" in (:");
				vHQL.append(vReportParameter.getVariableName());
				vHQL.append(")");
			} else {
				vHQL.append(" and ");
				vHQL.append(vReportParameter.getColumnName());
				vHQL.append(" ");
				vHQL.append(vReportParameter.getOperator());
				vHQL.append(" :");
				vHQL.append(vReportParameter.getVariableName());
			}
		}
		String vHqlQuery = pQuery1 + " " + vHQL + " " + pQuery2;

		if (mLogger_retrieveReport.isDebugEnabled()) {
			mLogger_retrieveReport.debug("Dynamic built HQL: " + vHqlQuery);
		}

		// Create query
		GenericQuery<Map<String, Object>> vQuery = new GenericQuery<Map<String,Object>>(vSession.createQuery(vHqlQuery));

		// Set parameters
		for (ReportParameter vReportParameter : pParameters) {

			// Extract useful information
			String vName = vReportParameter.getVariableName();
			String vOp = vReportParameter.getOperator();

			// Only set parameter if we have a parameter name
			if (vName != null && vName.length() > 0) {

				// Check operator to see if we have a list or a singular value
				if (ReportParameter.OPERATOR_IN.equals(vOp)) {
					vQuery.setParameterList(
						vName,
						vReportParameter.getValues());
				} else {
					if (vReportParameter.getObjectValue() != null
						&& vReportParameter.isUseObject()) {
						vQuery.setParameter(
							vName,
							vReportParameter.getObjectValue());
					} else {

						vQuery.setParameter(vName, vReportParameter.getValue());
					}
				}
			}
		}

		List<Map<String, Object>> vResult = vQuery.list();

		if (mLogger_retrieveReport.isDebugEnabled()) {
			mLogger_retrieveReport.debug(
				"Found " + vResult.size() + " rows.");
		}

		return vResult;
	}
	
	public List<Map<String, Object>> retrieveAdocReport(String pQuery){
		
		// Create session
		Session vSession = mSessionFactory.getCurrentSession();
		
		// Create query
		//GenericQuery<Map<String, Object>> vQuery = new GenericQuery<Map<String,Object>>(vSession.createQuery(pQuery));
		
		SQLQuery vQuery =  vSession.createSQLQuery(pQuery);
		
		vQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		List<Map<String,Object>> vResult=vQuery.list();
		
		if (mLogger_retrieveReport.isDebugEnabled()) {
			mLogger_retrieveReport.debug(
				"Found " + vResult.size() + " rows.");
		}

		return vResult;
	}
	
	public VoReportResults retrieveCardDetails(VoCardNumber vVoCardNumber){
		
		// Create session
		Session vSession = mSessionFactory.getCurrentSession();
		
		String vHql = "from CardNumber where issuer = :issuer and cardTypeDigit = :CardTypeDigit and accountNumberEnc = :accountNumber and  checkDigit =:CheckDigit ";
		
		CardNumber vCardNumber = (CardNumber)(vSession.createQuery(vHql).setParameter("issuer", vVoCardNumber.getIssuer()).setParameter("accountNumber", vVoCardNumber.getAccountNumber()).setParameter("CardTypeDigit", vVoCardNumber.getCardTypeDigit()).setParameter("CheckDigit", vVoCardNumber.getCheckDigit()).uniqueResult());
		
		Card vCard = vCardNumber.getCard();
		
		VoReportResults vVoReportResults =
				new VoReportResults();
		if (vCardNumber.getVerificationCodeEnc() != null && !vCardNumber.getVerificationCodeEnc().equals("")) {
			
			vVoReportResults.setCardNumberId(vCardNumber.getCardNumberId());
			vVoReportResults.setVerificationCode(vCardNumber.getVerificationCodeEnc());
			vVoReportResults.setCardId(vCard.getCardId());
			vVoReportResults.setCardState(vCard.getCardState());
		}else {
			vVoReportResults.setCardNumberId(vCardNumber.getCardNumberId());
			vVoReportResults.setCardId(vCard.getCardId());
			vVoReportResults.setCardState(vCard.getCardState());
		}
		
		if (mLogger_retrieveReport.isDebugEnabled()) {
			mLogger_retrieveReport.debug(
				"Found " + vVoReportResults + " rows.");
		}

		return vVoReportResults;
	}

	@Override
	protected Class<Report> getBusinessEntityClass() {
		return Report.class;
	}

	@SuppressWarnings("unchecked")
	public WeeklySalesReport retrieveSalesReportByWeek(final String pYear,
			final String pWeek) {
		WeeklySalesReport vWeeklySalesReport = new WeeklySalesReport();
		vWeeklySalesReport.setYear(pYear);
		vWeeklySalesReport.setWeek(pWeek);
		
		List<WeeklySalesReportRow> vReportRows = (List<WeeklySalesReportRow>) mHibernateTemplate.execute(new HibernateCallback() {
		
			public Object doInHibernate(Session pSession)
					{
				return pSession.createSQLQuery(
						"SELECT   c.country_code countryCode ,a.BU_CODE buCode, " +
						"  a.BU_TYPE buType, c.currency_code currencyCode, " +
						"  SUM (a.original_amount) AS amountInLocalCurrency, " +
						"  COUNT (a.original_amount) numberOfLoadTransactions " +
						"FROM amount_t a, card_t c " +
						"WHERE a.card_id = c.card_id " +
						"  AND TO_CHAR (a.created_date_time, 'IW') = :WEEK " +
						"  AND TO_CHAR (a.created_date_time, 'YYYY') = :YEAR " +
						"  AND C.CARD_TYPE = 'GIFT' " +
						"GROUP BY c.country_code, " +
						"  a.BU_CODE,  " +
						"  a.BU_TYPE, " +
						"  c.currency_code, " +
						"  TO_CHAR (a.created_date_time, 'IW') " +
						"ORDER BY c.country_code, " +
						"  a.BU_CODE,  " +
						"  a.BU_TYPE, " +
						"  c.currency_code, " +
						"  TO_CHAR (a.created_date_time, 'IW') ")
						.setString("WEEK", pWeek)
						.setString("YEAR", pYear)
						.setResultTransformer(
								Transformers.aliasToBean(WeeklySalesReportRow.class)).list();
			}
		});
		
		vWeeklySalesReport.addAll(vReportRows);
		
		return vWeeklySalesReport;
	}
}
