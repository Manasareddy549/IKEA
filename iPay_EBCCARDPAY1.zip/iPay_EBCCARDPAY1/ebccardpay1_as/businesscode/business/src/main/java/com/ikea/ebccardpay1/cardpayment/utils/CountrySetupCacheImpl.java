/*
 * Created on 2007-apr-26
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.cache.CacheReadOnlyException;
import com.ikea.cache.PrefetchCache;
import com.ikea.ebccardpay1.cardpayment.be.CountrySetup;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountrySetup;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public class CountrySetupCacheImpl
extends PrefetchCache
implements CountrySetupCache {

	private final static Logger mCategory =
			LoggerFactory.getLogger(CountrySetupCacheImpl.class);

	private BefFactory befFactory;

	private Iterator<CountrySetup> mIterator;

	/**
	 * Creates this cache. Must be public. Do not create your own instances,
	 * use getInstance!
	 * @see #getInstance
	 */
	public CountrySetupCacheImpl() {
		super();
	}

	/**
	 * Gets the instance of this cache (only one subset).
	 * @return a cache for information
	 */
	public static CountrySetupCacheImpl getInstance() {
		return (CountrySetupCacheImpl) getCache(
				CountrySetupCacheImpl.class.getName(),
				null);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.CountrySetupCache#reload()
	 */
	public void reload() {

		try {
			mCategory.info("Invalidating cache to force a reload.");
			invalidate();
		} catch (CacheReadOnlyException e) {
			mCategory.error(
					"Internal error. Could not trigger invalidate of country set-up cache!",
					e);
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#fetchSingle(java.lang.String)
	 */
	protected Object fetchSingle(String pKey) throws Exception {
		BefCountrySetup vBef = getBefCountry();
		String[] vSplit = pKey.split("-");
		CountrySetup vCountrySetup = vBef.findByUnique(vSplit[0], vSplit[1]);
		if (vCountrySetup == null) {
			throw new CountrySetupException(
					"No country setup info for combination of "
							+ vSplit[0]
									+ " and "
									+ vSplit[1]
											+ ".");
		}
		return new Integer(vCountrySetup.getExpireDays());
	}

	/**
	 * @param pCountryCode
	 * @param pCardType
	 * @return
	 */
	protected String key(String pCountryCode, String pCardType) {
		return pCountryCode + "-" + pCardType;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.CountrySetupCache#fetch(java.lang.String, java.lang.String)
	 */
	public Integer fetch(String pCountryCode, String pCardType)
			throws CountrySetupException {
		Integer vExpireDays = null;
		if (mCategory.isDebugEnabled()) {
			mCategory.debug(
					"Fetching info for " + key(pCountryCode, pCardType) + ".");
		}
		try {
			vExpireDays = (Integer) fetchObject(key(pCountryCode, pCardType));
		} catch (Exception e) {
			throw new CountrySetupException(
					"Could not get country set up info for combination of "
							+ pCountryCode
							+ " and "
							+ pCardType
							+ ". Cause: "
							+ e.toString());
		}
		if (vExpireDays == null) {
			mCategory.info(
					"No country setup info  for combination of "
							+ pCountryCode
							+ " and "
							+ pCardType
							+ ".");
		}
		return vExpireDays;
	}
	/**
	 * Fetches the next object in the build process.
	 * @param pObjectKey a placeholder for the key. Append the key here as a string
	 * @return the object to cache with the key string value
	 * @throws Exception if some errors occurs
	 */
	protected Object fetchNext(StringBuffer pObjectKey) throws Exception {
		Object vObject = null;

		if (mIterator != null) {
			if (mIterator.hasNext()) {

				CountrySetup vCountrySetup = (CountrySetup) mIterator.next();
				// Create the key
				pObjectKey.append(
						key(
								vCountrySetup.getCountryCode(),
								vCountrySetup.getCardType()));
				vObject = new Integer(vCountrySetup.getExpireDays());
				mCategory.debug("Adding [" + pObjectKey + ", " + vObject + "]");
			}
		}
		return vObject;
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#newObject(java.lang.String, java.io.ByteArrayInputStream)
	 */
	protected Object newObject(String arg0, ByteArrayInputStream arg1)
			throws IOException {
		// Using default
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#objectToBytes(java.lang.Object, java.io.ByteArrayOutputStream)
	 */
	protected void objectToBytes(Object arg0, ByteArrayOutputStream arg1)
			throws IOException {
		// Using default
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#load()
	 */
	protected void load() throws Exception {
		mCategory.info("Loading...");
		super.load();
		mCategory.info("Loading done.");
	}

	/**
	 * Prepares for the building of the cache.
	 *
	 * @param pSubset the subset to build the cache for
	 * @return	Estimated number of objects this cache will contain. Return 0 if the number is unknown. Negative values are ignored.
	 * @throws Exception if some errors occurs
	 * @see #fetchNext
	 * @see #finalizeBuild
	 */
	//@Transactional(readOnly=true)
	protected int prepareBuild(String pSubset) throws Exception {

		mCategory.info("Building Country Setup cache...");

		BefCountrySetup vBef = getBefCountry();
		List<CountrySetup> vList = vBef.findAll();
		mIterator = vList.iterator();

		return vList.size();
	}

	private BefCountrySetup getBefCountry() throws IkeaException {
		return befFactory.getBefCountrySetup();
	}

	/**
	 * Cleans up after the build process. This method will allways bee
	 * called, even if some exception occurs.
	 * Close connections and release other resourses.
	 * @throws Exception if some errors occurs
	 */
	protected void finalizeBuild() throws Exception {

		// Nothing to do.
		mCategory.info("Building Country Setup cache done.");
	}
	/**
	 * Gets the time out property. If zero it is never invalidated.
	 * @return the number of minutes the cache is valid, before it is reloaded
	 */
	protected int getTimeoutProp() {
		// 60 * 12 = Reload twice in one day.
		// 60 = Reload every hour.
		return 60;
	}

	/**
	 * 
	 */
	public String toString() {
		StringBuffer vBuff = new StringBuffer(this.getClass().getName());

		if (getInstance() != null
				|| getInstance().ivInstances != null
				|| getInstance().ivInstances.values() != null) {

			// Country set-up sorted by country code
			for (String vKey : getSortedKeys()) {	
				vBuff.append("\r");
				vBuff.append(vKey);
				vBuff.append("\t");
				try {
					vBuff.append(getInstance().fetchObject(vKey));
				} catch (Exception e) {
					mCategory.error(
							"Internal error. Could not get set-up for country code "
									+ vKey);
				}
			}
		}

		return vBuff.toString();
	}

	@SuppressWarnings("unchecked")
	private Set<String> getSortedKeys() {
		Map vSortedMap = new TreeMap();
		vSortedMap.putAll(getInstance().ivInstances);
		return vSortedMap.keySet();
	}

	public void setBefFactory(BefFactory befFactory){
		this.befFactory = befFactory;
	}
}
