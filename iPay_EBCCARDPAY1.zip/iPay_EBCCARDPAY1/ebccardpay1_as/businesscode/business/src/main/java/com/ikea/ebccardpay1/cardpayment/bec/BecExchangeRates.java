/*
 * Created on 2007-sep-03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.exception.CountryNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ExchangeRateNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;

/**
 * @author dalq
 *
 *
 */
public interface BecExchangeRates {

	/**
	 * 
	 * @param pVoExchangeRatesList
	 * @return BecExchangeRates
	 */
	public BecExchangeRates init(List<VoExchangeRate> pVoExchangeRateList);

	/**
	 * @param mVoCountry
	 */
	public BecExchangeRates init(VoCountry pVoCountry);

	/**
	 * 
	 * @param pBusinessUnitEnvironment
	 */
	public BecExchangeRates init(BusinessUnitEnvironment pBusinessUnitEnvironment);

	/**
	 * 
	 * @throws ValueMissingException
	 */
	public void manage()
		throws
			InvalidFromDateException,
			ValueMissingException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException;

	/**
	 * 
	 * @param pVoRequestAmount
	 * @return
	 * @throws ValueMissingException
	 */
	public BigDecimal getExchangeRate(String pFromCurrency, String pToCurrency)
		throws
			ValueMissingException,
			CountryNotFoundException,
			ExchangeRateNotFoundException;

	/**
	 * 
	 * @return List<VoExchangeRates>
	 * @throws ValueMissingException
	 */
	public List<VoExchangeRate> getVoExchangeRateList()
		throws ValueMissingException;
	
	/**
	 * 
	 * @param pVoRequestAmount
	 * @return List<VoExchangeRates>
	 */
	public List<VoExchangeRate> getVoExchangeRateList(List<ExchangeRate> pExchangeRateList)
		throws ValueMissingException;

	/**
	 * 
	 * @param pCountryId
	 * @return
	 */
	public List<ExchangeRate> findCurrentExchangeRates(long pCountryId);


}
