package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;

public interface BusinessUnitEnvironment {

	/**
	 * 
	 * @return
	 */
	public abstract String getBuType();

	/**
	 * 
	 * @return
	 */
	public abstract String getBuCode();

	/**
	 * 
	 * @return
	 */
	public abstract String getCountryCode();

	/**
	 * Gets the sales day for this transaction
	 * @return
	 */
	public String getSalesDay();

	/**
	 * 
	 * @return
	 */
	public Date getSalesDateTime();
	
	/**
	 * Gets the CompanyCode for this transaction
	 * @return
	 */
	public String getCompanyCode();

}
