/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class KPI extends BusinessEntity {
	/**										
	 * Storage: KPI_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mKpiId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */		
	private IpayBusinessUnits mIpayBusinessUnits;
	private IpayBusinessUnits mFromIpayBusinessUnits;
	
	/**										
	 * Data								
	 */										
	private String mKpiType;
	private String mKpiInterval;
	private String mCardType;
	private String mFromCountryCode;
	private String mBuType;
	private String mBuCode;
	private String mFromCurrencyCode;
	private String mEmployee;
	private java.math.BigDecimal mCreditAmount;
	private java.math.BigDecimal mDebitAmount;
	private long mCreditCount;
	private long mDebitCount;
	private String mSourceSystem;
	private String mToCountryCode;
	private String mToCurrencyCode;
	private String mKpiTimeZone;
	private java.math.BigDecimal mCardDebitAmount;
	private java.math.BigDecimal mCardCreditAmount;	
	private String mFromBuType;
	private String mFromBuCode;

	/**											
	 * @return Returns the kpiId.													
	 */											
	public long getKpiId() {
		return mKpiId;
	}
	/**
	 * @param pKpiId The kpiId to set.
	 */
	public void setKpiId(long pKpiId) {
		mKpiId = pKpiId;
	}

	/**											
	 * @return Returns the kpiType.													
	 */											
	public String getKpiType() {
		return mKpiType;
	}
	/**
	 * @param pKpiType The kpiType to set.
	 */
	public void setKpiType(String pKpiType) {
		mKpiType = pKpiType;
	}

	/**											
	 * @return Returns the kpiInterval.													
	 */											
	public String getKpiInterval() {
		return mKpiInterval;
	}
	/**
	 * @param pKpiInterval The kpiInterval to set.
	 */
	public void setKpiInterval(String pKpiInterval) {
		mKpiInterval = pKpiInterval;
	}

	/**											
	 * @return Returns the cardType.													
	 */											
	public String getCardType() {
		return mCardType;
	}
	/**
	 * @param pCardType The cardType to set.
	 */
	public void setCardType(String pCardType) {
		mCardType = pCardType;
	}

	/**											
	 * @return Returns the fromCountryCode.													
	 */											
	public String getFromCountryCode() {
		return mFromCountryCode;
	}
	/**
	 * @param pFromCountryCode The fromCountryCode to set.
	 */
	public void setFromCountryCode(String pFromCountryCode) {
		mFromCountryCode = pFromCountryCode;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the fromCurrencyCode.													
	 */											
	public String getFromCurrencyCode() {
		return mFromCurrencyCode;
	}
	/**
	 * @param pFromCurrencyCode The fromCurrencyCode to set.
	 */
	public void setFromCurrencyCode(String pFromCurrencyCode) {
		mFromCurrencyCode = pFromCurrencyCode;
	}

	/**											
	 * @return Returns the employee.													
	 */											
	public String getEmployee() {
		return mEmployee;
	}
	/**
	 * @param pEmployee The employee to set.
	 */
	public void setEmployee(String pEmployee) {
		mEmployee = pEmployee;
	}

	/**											
	 * @return Returns the creditAmount.													
	 */											
	public java.math.BigDecimal getCreditAmount() {
		return mCreditAmount;
	}
	/**
	 * @param pCreditAmount The creditAmount to set.
	 */
	public void setCreditAmount(java.math.BigDecimal pCreditAmount) {
		mCreditAmount = pCreditAmount;
	}

	/**											
	 * @return Returns the debitAmount.													
	 */											
	public java.math.BigDecimal getDebitAmount() {
		return mDebitAmount;
	}
	/**
	 * @param pDebitAmount The debitAmount to set.
	 */
	public void setDebitAmount(java.math.BigDecimal pDebitAmount) {
		mDebitAmount = pDebitAmount;
	}

	/**											
	 * @return Returns the creditCount.													
	 */											
	public long getCreditCount() {
		return mCreditCount;
	}
	/**
	 * @param pCreditCount The creditCount to set.
	 */
	public void setCreditCount(long pCreditCount) {
		mCreditCount = pCreditCount;
	}

	/**											
	 * @return Returns the debitCount.													
	 */											
	public long getDebitCount() {
		return mDebitCount;
	}
	/**
	 * @param pDebitCount The debitCount to set.
	 */
	public void setDebitCount(long pDebitCount) {
		mDebitCount = pDebitCount;
	}

	/**											
	 * @return Returns the sourceSystem.													
	 */											
	public String getSourceSystem() {
		return mSourceSystem;
	}
	/**
	 * @param pSourceSystem The sourceSystem to set.
	 */
	public void setSourceSystem(String pSourceSystem) {
		mSourceSystem = pSourceSystem;
	}

	/**											
	 * @return Returns the toCountryCode.													
	 */											
	public String getToCountryCode() {
		return mToCountryCode;
	}
	/**
	 * @param pToCountryCode The toCountryCode to set.
	 */
	public void setToCountryCode(String pToCountryCode) {
		mToCountryCode = pToCountryCode;
	}

	/**											
	 * @return Returns the toCurrencyCode.													
	 */											
	public String getToCurrencyCode() {
		return mToCurrencyCode;
	}
	/**
	 * @param pToCurrencyCode The toCurrencyCode to set.
	 */
	public void setToCurrencyCode(String pToCurrencyCode) {
		mToCurrencyCode = pToCurrencyCode;
	}

	/**											
	 * @return Returns the kpiTimeZone.													
	 */											
	public String getKpiTimeZone() {
		return mKpiTimeZone;
	}
	/**
	 * @param pKpiTimeZone The kpiTimeZone to set.
	 */
	public void setKpiTimeZone(String pKpiTimeZone) {
		mKpiTimeZone = pKpiTimeZone;
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}


	public java.math.BigDecimal getCardDebitAmount() {
		return mCardDebitAmount;
	}
	
	public void setCardDebitAmount(java.math.BigDecimal pCardDebitAmount) {
		mCardDebitAmount = pCardDebitAmount;
	}
	
	public java.math.BigDecimal getCardCreditAmount() {
		return mCardCreditAmount;
	}
	
	public void setCardCreditAmount(java.math.BigDecimal pCardCreditAmount) {
		mCardCreditAmount = pCardCreditAmount;
	}
	
	/**											
	 * @return Returns the fromBuCode.													
	 */											
	public String getFromBuCode() {
		return mFromBuCode;
	}
	/**
	 * @param pFromBuCode The FromBuCode to set.
	 */
	public void setFromBuCode(String pFromBuCode) {
		mFromBuCode = pFromBuCode;
	}

	/**											
	 * @return Returns the fromBuType.													
	 */											
	public String getFromBuType() {
		return mFromBuType;
	}
	/**
	 * @param pFromBuType The fromBuType to set.
	 */
	public void setFromBuType(String pFromBuType) {
		mFromBuType = pFromBuType;
	}

	/**											
	 * @return Returns the IpayBusinessUnit.													
	 */											
	public IpayBusinessUnits getIpayBusinessUnits() {
		return mIpayBusinessUnits;
	}
	/**
	 * @param pIpayBusinessUnits The IpayBusinessUnits to set.
	 */
	public void setIpayBusinessUnits(IpayBusinessUnits pIpayBusinessUnits) {
		mIpayBusinessUnits = pIpayBusinessUnits;
	}

	/**											
	 * @return Returns the fromIpayBusinessUnits.													
	 */											
	public IpayBusinessUnits getFromIpayBusinessUnits() {
		return mFromIpayBusinessUnits;
	}
	/**
	 * @param pFromIpayBusinessUnits The fromIpayBusinessUnits to set.
	 */
	public void setFromIpayBusinessUnits(IpayBusinessUnits pFromIpayBusinessUnits) {
		mFromIpayBusinessUnits = pFromIpayBusinessUnits;
	}
	
	/**
	 * Connect IpayBusinessUnits.
	 * @param pIpayBusinessUnits
	 */
	public void connectIpayBusinessUnits(IpayBusinessUnits pIpayBusinessUnits) {
		setIpayBusinessUnits(pIpayBusinessUnits);
		if(pIpayBusinessUnits != null) {
			pIpayBusinessUnits.getKpi().add(this);
		}
	}

	/**
	 * Disconnect IpayBusinessUnits.
	 */
	public void disconnectpIpayBusinessUnits() {
		if(getIpayBusinessUnits() != null) {
			getIpayBusinessUnits().getKpi().remove(this);
		}
		setIpayBusinessUnits(null);
	}
	
	/**
	 * Connect FromIpayBusinessUnits.
	 * @param pFromIpayBusinessUnits
	 */
	public void connectFromIpayBusinessUnits(IpayBusinessUnits pFromIpayBusinessUnits) {
		setFromIpayBusinessUnits(pFromIpayBusinessUnits);
		if(pFromIpayBusinessUnits != null) {
			pFromIpayBusinessUnits.getKpi().add(this);
		}
	}

	/**
	 * Disconnect FromIpayBusinessUnits.
	 */
	public void disconnectFromIpayBusinessUnits() {
		if(getFromIpayBusinessUnits() != null) {
			getFromIpayBusinessUnits().getKpi().remove(this);
		}
		setFromIpayBusinessUnits(null);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mKpiId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("kpiId", CodeGeneration.toObject(mKpiId));
		vMap.put("kpiType", CodeGeneration.toObject(mKpiType));
		vMap.put("kpiInterval", CodeGeneration.toObject(mKpiInterval));
		vMap.put("cardType", CodeGeneration.toObject(mCardType));
		vMap.put("fromCountryCode", CodeGeneration.toObject(mFromCountryCode));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("fromCurrencyCode", CodeGeneration.toObject(mFromCurrencyCode));
		vMap.put("employee", CodeGeneration.toObject(mEmployee));
		vMap.put("creditAmount", CodeGeneration.toObject(mCreditAmount));
		vMap.put("debitAmount", CodeGeneration.toObject(mDebitAmount));
		vMap.put("creditCount", CodeGeneration.toObject(mCreditCount));
		vMap.put("debitCount", CodeGeneration.toObject(mDebitCount));
		vMap.put("sourceSystem", CodeGeneration.toObject(mSourceSystem));
		vMap.put("toCountryCode", CodeGeneration.toObject(mToCountryCode));
		vMap.put("toCurrencyCode", CodeGeneration.toObject(mToCurrencyCode));
		vMap.put("kpiTimeZone", CodeGeneration.toObject(mKpiTimeZone));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("cardDebitAmount", CodeGeneration.toObject(mCardDebitAmount));
		vMap.put("cardCreditAmount", CodeGeneration.toObject(mCardCreditAmount));
		vMap.put("fromBuType", CodeGeneration.toObject(mFromBuType));
		vMap.put("fromBuCode", CodeGeneration.toObject(mFromBuCode));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("kpiId")) mKpiId = CodeGeneration.objectTolong(pMap.get("kpiId"));
		if(pMap.containsKey("kpiType")) mKpiType = CodeGeneration.objectToString(pMap.get("kpiType"));
		if(pMap.containsKey("kpiInterval")) mKpiInterval = CodeGeneration.objectToString(pMap.get("kpiInterval"));
		if(pMap.containsKey("cardType")) mCardType = CodeGeneration.objectToString(pMap.get("cardType"));
		if(pMap.containsKey("fromCountryCode")) mFromCountryCode = CodeGeneration.objectToString(pMap.get("fromCountryCode"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("fromCurrencyCode")) mFromCurrencyCode = CodeGeneration.objectToString(pMap.get("fromCurrencyCode"));
		if(pMap.containsKey("employee")) mEmployee = CodeGeneration.objectToString(pMap.get("employee"));
		if(pMap.containsKey("creditAmount")) mCreditAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("creditAmount"));
		if(pMap.containsKey("debitAmount")) mDebitAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("debitAmount"));
		if(pMap.containsKey("creditCount")) mCreditCount = CodeGeneration.objectTolong(pMap.get("creditCount"));
		if(pMap.containsKey("debitCount")) mDebitCount = CodeGeneration.objectTolong(pMap.get("debitCount"));
		if(pMap.containsKey("sourceSystem")) mSourceSystem = CodeGeneration.objectToString(pMap.get("sourceSystem"));
		if(pMap.containsKey("toCountryCode")) mToCountryCode = CodeGeneration.objectToString(pMap.get("toCountryCode"));
		if(pMap.containsKey("toCurrencyCode")) mToCurrencyCode = CodeGeneration.objectToString(pMap.get("toCurrencyCode"));
		if(pMap.containsKey("kpiTimeZone")) mKpiTimeZone = CodeGeneration.objectToString(pMap.get("kpiTimeZone"));
		if(pMap.containsKey("cardCreditAmount")) mCardCreditAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("cardCreditAmount"));
		if(pMap.containsKey("cardDebitAmount")) mCardDebitAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("cardDebitAmount"));
		if(pMap.containsKey("fromBuType")) mFromBuType = CodeGeneration.objectToString(pMap.get("fromBuType"));
		if(pMap.containsKey("fromBuCode")) mFromBuCode = CodeGeneration.objectToString(pMap.get("fromBuCode"));
	}
}
