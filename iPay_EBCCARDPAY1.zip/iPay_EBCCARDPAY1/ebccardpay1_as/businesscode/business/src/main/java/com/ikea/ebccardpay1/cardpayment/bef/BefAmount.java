/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.math.BigDecimal;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;

public interface BefAmount extends Bef<Amount>{

	public int deleteByCampaign(Campaign pCampaign);

	public java.util.Map<BigDecimal, BigDecimal> usageByCampaign(Campaign pCampaign);

	public int deleteByMassLoad(MassLoad pMassLoad);

	public java.util.Map<BigDecimal, BigDecimal> usageByMassLoad(MassLoad pMassLoad);

	public java.util.Map<BigDecimal, BigDecimal> usageByBonus(Bonus pBonus);
	
	public Amount findByAmountId(long amountId);

}