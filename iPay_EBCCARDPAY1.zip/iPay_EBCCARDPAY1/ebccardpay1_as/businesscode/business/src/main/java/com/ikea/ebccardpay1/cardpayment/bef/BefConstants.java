/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

/**
 * @author anms
 *
 */
public interface BefConstants {

	/**
	 * Get all card type constants.
	 * @return list of card type strings
	 */
	public List<String> getCardTypeConstants();

	/**
	 * Get all card state constants.
	 * @return list of card state strings
	 */
	public List<String> getCardStateConstants();

	/**
	 * Get all amount type constants.
	 * @return list of amount type strings
	 */
	public List<String> getAmountTypeConstants();

	/**
	 * Get all source system constants.
	 * @return list of source system strings
	 */
	public List<String> getSourceSystemConstants();

	/**
	 * Get all life cycle type constants.
	 * @return list of life cycle type strings
	 */
	public List<String> getLifeCycleTypeConstants();

	/**
	 * Get all transaction type constants.
	 * @return list of transaction type strings
	 */
	public List<String> getTransactionTypeConstants();

	/**
	 * Get all response type constants.
	 * @return list of response type strings
	 */
	public List<String> getResponseTypeConstants();

	/**
	 * Get all financial type constants.
	 * @return list of financial type strings
	 */
	public List<String> getFinancialTypeConstants();

	/**
	 * Get all KPI (Key Performance Index) type constants.
	 * @return list of KIP type strings
	 */
	public List<String> getKpiTypeConstants();

	/**
	 * Get KPI (Key Performance Index) types to do calculations for.
	 * @return list of KIP type strings
	 */
	public List<String> getKpiTypesToCalculate();

	/**
	 * Get all campaign state constants
	 * @return list of campaign state constants
	 */
	public List<String> getCampaignStateConstants();

	/**
	 * Get all parameter type constants
	 * @return list of parameter type constants
	 */
	public List<String> getParameterTypeConstants();
	
	/**
	 * Get all exchange mode constants
	 * @return list of exchange modes
	 */
	public List<String> getExchangeModeConstants();
	
	public List<String> getLoadReasonCodeConstants(); 
	
	public List<String> getRedeemReasonCodeConstants();
	
	public List<String> getCustomerTypeConstants();

}
