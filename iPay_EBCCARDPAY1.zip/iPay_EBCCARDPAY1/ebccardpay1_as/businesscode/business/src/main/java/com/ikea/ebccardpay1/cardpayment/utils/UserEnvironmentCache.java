package com.ikea.ebccardpay1.cardpayment.utils;


/**
 * @author dalq
 * @author Henrik Reinhold
 *
 */
public interface UserEnvironmentCache {

	/**
	 * 
	 * @param mUserId
	 * @return UserEnvironment for the given user
	 */
	UserEnvironment fetch(String mUserId);

}
