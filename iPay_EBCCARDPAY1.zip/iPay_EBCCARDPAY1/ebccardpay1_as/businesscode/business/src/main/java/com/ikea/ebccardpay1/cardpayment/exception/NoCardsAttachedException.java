package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class NoCardsAttachedException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4743374531032157732L;

	public NoCardsAttachedException() {
		super();
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.NocardsAttached();
	}
}