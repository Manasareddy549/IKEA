/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class CampaignWrongStateException extends CampaignException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2548365859377851035L;

	public CampaignWrongStateException() {
		super();
	}
	public CampaignWrongStateException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.CampaignWrongState();
	}
}
