/*
 * Created on 2007-nov-21
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.Parameter;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromToDateException;
import com.ikea.ebccardpay1.common.Constants;

/**
 * @author dalq
 *
 *
 */
public class Restrictions {

	private final static Logger mCategory =
		LoggerFactory.getLogger(Restrictions.class);

	/**
	 * 
	 */
	public Restrictions() {
		super();
	}

	/**
	 * 
	 * @param pParameter
	 * @param pValue
	 * @throws InvalidFromToDateException
	 */
	public void checkRestrictions(Parameter pParameter, String pValue)
		throws InvalidFromToDateException {

		mCategory.info(
			"Params value: pParameter=" + pParameter + " pValue=" + pValue);

		String vRestrictions = pParameter.getRestrictions();
		mCategory.info("Restriction" + vRestrictions);

		//Check LAST_TRANSACTION_DATE_TIME
		if (pParameter
			.getParameterType()
			.equals(
				Constants
					.PARAMETER_TYPE_CONSTANT_LAST_TRANSACTION_DATE_TIME)) {
			DateTime vDateValue = Dates.parseDate(pValue);
			DateTime vMaxValue =
				(DateTime) Dates.getDateTime(
					Dates.withoutTime(Dates.getDateTime(new Date())));
			if (vRestrictions != null) {
				vMaxValue =
					vMaxValue.minusDays(Integer.parseInt(vRestrictions));
				mCategory.info(
					"MaxValue - of last transaction date:" + vMaxValue);
			}
			// Check restriction
			checkDate(vMaxValue, vDateValue);
		} else if (
			pParameter.getParameterType().equals(
				Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_MONTH)) {

		}

	}

	/**
	 * 
	 * @param pRestrictionValue
	 * @param pValueToCheck
	 * @throws InvalidFromToDateException
	 */
	protected void checkDate(
		DateTime pRestrictionValue,
		DateTime pValueToCheck)
		throws InvalidFromToDateException {

		if (!Dates
			.withoutTime(pRestrictionValue)
			.after(Dates.withoutTime(pValueToCheck))) {
			throw new InvalidFromToDateException(
				"Last transaction date is to close to current day, must be before "
					+ "'"
					+ Dates.formatDate(pRestrictionValue)
					+ "'");
		}

	}

}
