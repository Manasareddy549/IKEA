/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;

public interface BefCampaign extends Bef<Campaign>{

	public java.util.List<Campaign> findByCurrent(String pCountryCode, java.util.Date pTodaysSalesDay);

	public java.util.List<Campaign> findByUnprocessed();

	public int connectRange(long pCampaignId, long pRangeId);

	public int disconnectRange(long pCampaignId, long pRangeId);

	public java.util.List<Campaign> findBySearch(String pBuType, String pBuCode, String pCountryCode, String pNameLike, java.util.Date pIntervalOnFromDate, java.util.Date pIntervalOnUntilDate);
	
	public List<Campaign> findExpiredCampaigns(Date pExpireDateFrom,Date pExpireDateUpto);
	 public List<Transaction> getCampaignLoadTransactions(Campaign pCampaign) throws Exception;

}