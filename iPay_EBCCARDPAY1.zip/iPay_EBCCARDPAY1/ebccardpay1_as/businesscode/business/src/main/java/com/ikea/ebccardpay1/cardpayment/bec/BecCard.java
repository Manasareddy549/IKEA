/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.BlockedCardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.ExpiredCardException;
import com.ikea.ebccardpay1.cardpayment.exception.ExternalCardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.IllegalCardStateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidForeignCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode;
import com.ikea.ebccardpay1.cardpayment.exception.PosDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardEntry;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardHistory;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecCard {

	/**
	 * @param pBusinessUnitEnvironment
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecCard init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * 
	 * @param pCard
	 * @return
	 */
	public BecCard init(Card pCard);

	/**
	 * Prepares the Bec by providing a Card Number. The Card it self does not need to exist.
	 * 
	 * 
	 * @param pCardNumber
	 */
	public BecCard init(CardNumber pCardNumber);

	/**
	 * Prepares the Bec by providing a Card Number. The Card it self does not need to exist.
	 * 
	 * 
	 * @param pCardNumber
	 */
	public BecCard init(CardNumber pCardNumber, BusinessUnitEnvironment pBusinessUnitEnvironment);

	/**
	 * @param pCardNumberString
	 * @param pBusinessUnitEnvironment
	 * @return
	 */
	public BecCard init(
		String pCardNumberString,
		BusinessUnitEnvironment pBusinessUnitEnvironment)
		throws InvalidCardNumberException;

	/**
	 * @return
	 */
	public Card getCard();
	/**
	 * @return
	 */
	public CardNumber getCardNumber();

	/**
	 * Creates the card based on a card number string.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 * @throws DuplicateCardException if a card with this card number already exists in the database.
	 * @throws ValueMissingException if the TransactionEnvironment is not set.
	 * @throws IkeaException if unexpected errors
	 */
	public void createCard(String pCardNumberString)
		throws
			InvalidCardNumberException,
			DuplicateCardException,
			ValueMissingException,
			IkeaException;

	/**
	 * 
	 * @param pCardNumber
	 * @param pExternalCard
	 * @param pExternalCardSystem
	 * @throws InvalidCardNumberException
	 * @throws ValueMissingException
	 */
	public void createFromExternal(
		CardNumber pCardNumber,
		ExternalCard pExternalCard,
		ExternalCardSystem pExternalCardSystem)
		throws InvalidCardNumberException, ValueMissingException;

	/**
	 * Finds the card based on a card number string. Searching internal cards first and then external card numbers.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 * @throws CardNotFoundException if a card with this card number can not be found (not in this EBC nor in the old)
	 * @throws ValueMissingException if the TransactionEnvironment is not set.
	 * @throws IkeaException if unexpected errors
	 * @throws ReferenceCheckException 
	 */
	public void findCard(String pCardNumberString)
		throws
			InvalidCardNumberException,
			CardNotFoundException,
			ValueMissingException,
			IkeaException, ReferenceCheckException;

	/**
	 * Finds the card based on the cardId. 
	 * @param pCardId
	 */
	public void findCard(long pCardId);

	/**
	 * Finds the card based on a card number string. If the external card system is set then using it.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 * @throws CardNotFoundException if a card with this card number can not be found (not in this EBC nor in the old)
	 * @throws ValueMissingException if the TransactionEnvironment is not set.
	 * @throws IkeaException if unexpected errors
	 * @throws ReferenceCheckException 
	 */
	public void findCard(VoCardEntry pVoCardEntry)
		throws
			InvalidCardNumberException,
			CardNotFoundException,
			ValueMissingException,
			IkeaException, ReferenceCheckException;

	/**
	 * Loads the current card with a given amount
	 * 
	 * @param pVoLoadAmount
	 * @param pVoReference
	 * @throws CardException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException if you do not have a Card or a TransactionEnvironment set
	 * @throws ReferenceCheckException if a transaction has already been executed with the same reference
	 * @throws BlockedCardException if the card is blocked
	 * @throws IkeaException 
	 * @throws InvalidForeignCardException 
	 */
	public void loadAmount(VoLoadAmount pVoLoadAmount,long pPosExpiryDate)
			throws
				CardException,
				BlockedCardException,
				CurrencyException,
				AmountException,
				CountrySetupException,
				ValueMissingException,
				ReferenceCheckException, IkeaException, InvalidForeignCardException, PosDateException;


	/**
	 * 
	 * @param pVoLoadAmount
	 * @throws CardException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws CountrySetupException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidForeignCardException 
	 */
	public void loadExternalAmount(VoLoadAmount pVoLoadAmount,String pSourceSystem)
		throws
			CardException,
			CurrencyException,
			AmountException,
			CountrySetupException,
			ValueMissingException, IkeaException, InvalidForeignCardException;

	/**
	 * Reddems the current card with a requested amount
	 * 
	 * @param pVoRequestAmount
	 * @param pVoRedeemAmount
	 * @param pManual Set if manual redemption
	 * @throws CardException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException if you do not have a Card or a TransactionEnvironment set
	 * @throws ReferenceCheckException if a transaction has already been executed with the same reference
	 * @throws BlockedCardException if the card is blocked
	 * @throws IkeaException 
	 * @throws InvalidForeignCardException 
	 */
	public void redeemAmount(
		VoRequestAmount pVoRequestAmount,
		VoRedeemAmount pVoRedeemAmount,
		boolean pManual)
		throws
			CardException,
			BlockedCardException,
			CurrencyException,
			AmountException,
			ValueMissingException,
			ReferenceCheckException, IkeaException, InvalidForeignCardException;

	/**
	 * @param pCampaign
	 * @throws ValueMissingException
	 * @throws BlockedCardException
	 * @throws ExpiredCardException
	 * @throws IllegalCardStateException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws IkeaException
	 * @throws InvalidCardException 
	 */
	public void loadCampaign(Campaign pCampaign)
		throws
			ValueMissingException,
			BlockedCardException,
			ExpiredCardException,
			IllegalCardStateException,
			InvalidCardNumberException,
			CurrencyException,
			AmountException,
			CountrySetupException,
			IkeaException, InvalidCardException;
			
			public void CampaignLoadtransaction(Campaign pCampaign) throws Exception;

	/**
	 * @param pMassLoad
	 * @throws ValueMissingException
	 * @throws BlockedCardException
	 * @throws ExpiredCardException
	 * @throws IllegalCardStateException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws IkeaException
	 * @throws InvalidCardException 
	 */
	public void loadMassLoad(MassLoad pMassLoad)
		throws
			ValueMissingException,
			BlockedCardException,
			ExpiredCardException,
			IllegalCardStateException,
			InvalidCardNumberException,
			CurrencyException,
			AmountException,
			CountrySetupException,
			IkeaException, InvalidCardException;

	/**
	 * 
	 * @param pMultipleSingleLoad
	 * @param pBusinessUnitEnvironment 
	 * @throws ValueMissingException 
	 * @throws IllegalArgumentException 
	 * @throws CardException 
	 * @throws CardPayException 
	 * @throws IkeaException 
	 */
	public void loadMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pAmountValue) throws IllegalArgumentException, ValueMissingException, CardException, CardPayException, IkeaException;
	
	/**
	 * 
	 * @param pVoBonusOnCard
	 * @throws ValueMissingException
	 * @throws BlockedCardException
	 * @throws ExpiredCardException
	 * @throws IllegalCardStateException
	 * @throws InvalidCardNumberException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws IkeaException
	 * @throws InvalidCardException 
	 */
	public void loadBonus(Bonus pBonus)
		throws
			ValueMissingException,
			BlockedCardException,
			ExpiredCardException,
			IllegalCardStateException,
			InvalidCardNumberException,
			CurrencyException,
			AmountException,
			CountrySetupException,
			IkeaException, InvalidCardException;

	/**
	 * @throws IllegalArgumentException
	 * @throws ValueMissingException
	 */
	public void block(String pDescription)
		throws
			IllegalArgumentException,
			ValueMissingException,
			ExpiredCardException,
			AmountException,
			BlockedCardException;

	/**
	 * @param pVoManualTransaction
	 * @throws CardException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws ReferenceCheckException
	 * @throws TransactionException
	 * @throws IkeaException 
	 * @throws InvalidForeignCardException 
	 */
	public void manual(VoManualTransaction pVoManualTransaction)
		throws
			CardException,
			CurrencyException,
			AmountException,
			ValueMissingException,
			ReferenceCheckException,
			TransactionException, IkeaException, InvalidForeignCardException;

	/**
	 * Calculate the balance of the current card.
	 * @return
	 * @throws ValueMissingException if you do not have a Card or a TransactionEnvironment set
	 */
	public VoCard calculateBalance() throws ValueMissingException;

	/**
	 * Calculate the balance of the current card.
	 * @return
	 * @throws ValueMissingException if you do not have a Card or a TransactionEnvironment set
	 */
	public VoCardComplete calculateCompleteBalance()
		throws ValueMissingException;

	/**
	 * Get card history for current card (transactions, life cycle events and all amounts).
	 * No migration is attempted.
	 * @param pCardNumberString
	 * @return
	 * @throws ValueMissingException if you do not have a Card set
	 */
	public VoCardHistory retrieveCardHistory() throws ValueMissingException;

	/**
	 * Sets the country code on the card and evaluate expire date. This is normally done automatically
	 * at first load.
	 * 
	 * @param pCountryCode The country code to assign to the card
	 * @throws ValueMissingException
	 * @throws CountrySetupException
	 */
	public void assignToCountryCode(String pCountryCode)
		throws ValueMissingException, CountrySetupException;

	/**
	 * Resets the expire date when a new LOAD request is made. 
	 * Start from todays date and add upp the days from country setup.
	 * 
	 * @throws CountrySetupException
	 * @throws ValueMissingException
	 */
	public void resetExpireDate()
		throws CountrySetupException, ValueMissingException;

	/**
	 * Sets the expire date. This is automatically done at first load or when calling assigntoCountryCode.
	 * @param pDate The expire date
	 * @throws ValueMissingException
	 */
	public void setExpireDate(Date pDate) throws ValueMissingException;

	/**
	 * Checks the verificationCode. If applied from request and any verficationcode
	 * exists in iPay database for this cardnumber verify that they match. 
	 * @param entry
	 */
	public void checkVerificationCode(String pVerificationCode,String pSourceCode)
		throws InvalidVerificationCode;

		/**
	 * Finds the card based on a card number string. Searching internal cards first and then external card numbers.
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match the regexp, the check didgit is not correct, or the card type didgit is not supported.
	 * @throws CardNotFoundException if a card with this card number can not be found (not in this EBC nor in the old)
	 * @throws ValueMissingException if the TransactionEnvironment is not set.
	 * @throws IkeaException if unexpected errors
	 */
	public void findCardForBalanceCheck(String pCardNumberString)
		throws
			InvalidCardNumberException,
			CardNotFoundException,
			ValueMissingException,
			IkeaException;
	
	/**
	 * @param pMassLoad
	 * @throws ValueMissingException
	 * @throws BlockedCardException
	 * @throws ExpiredCardException
	 * @throws IllegalCardStateException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws IkeaException
	 * @throws InvalidCardException 
	 * - by anagc on 02-16-2016
	 */
	public void withdrawMassLoad(MassLoad pMassLoad)
		throws
			ValueMissingException,
			BlockedCardException,
			ExpiredCardException,
			IllegalCardStateException,
			InvalidCardNumberException,
			CurrencyException,
			AmountException,
			CountrySetupException,
			IkeaException, InvalidCardException;

	
	public boolean getExpiredCards(String pFromDate , String pToDate) throws Exception;
	
	public int getCardSize(String pFromDate , String pToDate);
	
	public void processExpiredCards(CopyOnWriteArrayList<Card> crdlist , int start , int range);
	
	public void setCardList(CopyOnWriteArrayList<Card> crdlist);
	
	public CopyOnWriteArrayList<Card> getCardList();
	
	public Collection<Card> getExpCards() throws Exception;
	public void expireCampaign(Campaign pCampaign)
			throws
				ValueMissingException,
				BlockedCardException,
				ExpiredCardException,
				IllegalCardStateException,
				InvalidCardNumberException,
				CurrencyException,
				AmountException,
				CountrySetupException,
				IkeaException, InvalidCardException,TransactionException;
	
	public void expiredCardProcessing() throws Exception;
	public void withdrawnCampaign(Campaign pCampaign)
			throws
				ValueMissingException,
				BlockedCardException,
				ExpiredCardException,
				IllegalCardStateException,
				InvalidCardNumberException,
				CurrencyException,
				AmountException,
				CountrySetupException,
				IkeaException, InvalidCardException, TransactionException;
	 public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction ,Campaign pCampaign) throws Exception;
	
	 public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction ,Campaign pCampaign) throws Exception;
	
	 public void CampaignDebiTransaction(Campaign pCampaign , String sales_Day) throws Exception;
	 
	 public void saveMassLoadCard(MassLoad pMassLoad)throws IllegalArgumentException, ValueMissingException, InvalidCardNumberException;
	 
	 public void saveCampaignCard(Campaign pCampaign)  throws IllegalArgumentException, ValueMissingException, InvalidCardNumberException;
	 
	 public void addMassLoadExpiry(Date pExpiryDate)throws ExpiredCardException;
	 
	 public void setMassLoadExpiryFromMap(java.util.Map<String, Object> map , List<CardNumber> pCardNumberList);
	 
	 public Card tryExternalCardNumber(String pCardNumberString) throws ValueMissingException, InvalidCardNumberException,
		ExternalCardNotFoundException, IkeaException;
	 
	 public void withdrawnSingleLoad(MultipleSingleLoad pMultipleSingleLoad) throws CurrencyException, AmountException, TransactionException, ValueMissingException;

	public BecCard init(BusinessUnitEnvironment vBusinessUnitEnvironment,
			TransactionEnvironment vTransactionEnvironment, String cardNumberString);

}
