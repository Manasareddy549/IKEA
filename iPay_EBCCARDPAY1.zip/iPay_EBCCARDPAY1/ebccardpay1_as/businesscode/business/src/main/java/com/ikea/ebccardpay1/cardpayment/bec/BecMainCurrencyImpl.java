/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountryKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.MainCurrency;
import com.ikea.ebccardpay1.cardpayment.bef.BefMainCurrency;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;
import com.ikea.common.TimeSource;
import com.ikea.mdsd.ValueObjects;

/**
 * @author dalq
 *
 *
 */
public class BecMainCurrencyImpl implements BecMainCurrency {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecMainCurrencyImpl.class);

	// Entities that this BEC operates on
	private MainCurrency mMainCurrency;
	//private List<VoMainCurrency> mVoMainCurrencyList

	//	Dependencies injected at creation of this BEC
	private BefMainCurrency mBefMainCurrency = null;
	private BecFactory mBecFactory = null;
	private TimeSource mTimeSource = null;

	// Dependencies that need to be set with init
	private VoCountry mVoCountry = null;

	/**
	 * 
	 * @param pBefMainCurrency
	 * @param pBecFactory
	 */
	public BecMainCurrencyImpl(
		BefMainCurrency pBefMainCurrency,
		BecFactory pBecFactory,
		TimeSource pTimeSource) {

		mBefMainCurrency = pBefMainCurrency;
		mBecFactory = pBecFactory;
		mTimeSource = pTimeSource;

	}

	void validate() {
		notNull(mBefMainCurrency);
		notNull(mBecFactory);
		notNull(mTimeSource);
	}
	/**
	 * 
	 *
	 */
	public BecMainCurrencyImpl() {
		super();

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrency#init(com.ikea.ebccardpay1.cardpayment.vo.VoCountry)
	 */
	public void init(VoCountry pVoCountry) {
		mVoCountry = pVoCountry;

	}

	/**
	 * 
	 * @param pMainCurrencyId
	 * @return this
	 */
	public BecMainCurrency init(long pMainCurrencyId) {
		mMainCurrency = mBefMainCurrency.findByPrimaryKey(pMainCurrencyId);
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrency#getVoMainCurrency()
	 */
	public VoMainCurrency getVoMainCurrency() throws ValueMissingException {
		requireMainCurrency();

		VoMainCurrency vVoMainCurrency = new VoMainCurrency();

		ValueObjects.assignToValueObject(vVoMainCurrency, mMainCurrency);
		mCategory.debug(
			"Return VoMainCurrency "
				+ vVoMainCurrency.getCurrencyCode()
				+ " "
				+ vVoMainCurrency.getFromDate());

		return vVoMainCurrency;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecMainCurrency#manage(com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency)
	 */
	public void manage(VoMainCurrency pVoMainCurrency)
		throws ValueMissingException, InvalidFromDateException {

		if (Constants
			.OBJECT_STATE_NEW
			.equals(pVoMainCurrency.getObjectState())) {
			createMainCurrency(pVoMainCurrency);
		} else if (
			Constants.OBJECT_STATE_MODIFIED.equals(
				pVoMainCurrency.getObjectState())) {
			updateMainCurrency(pVoMainCurrency);
		} else if (
			Constants.OBJECT_STATE_READ.equals(
				pVoMainCurrency.getObjectState())) {
			// Sub entities are changed
			updateMainCurrency(pVoMainCurrency);
		} else {
			throw new ValueMissingException(
				"Illegal Object State set! Can not handle '"
					+ pVoMainCurrency.getObjectState()
					+ "'.");
		}

	}

	/**
	 * @param pVoMainCurrency
	 */
	protected void removeMainCurrency(VoMainCurrency pVoMainCurrency)
		throws ValueMissingException {
		// Find MainCurrency in dB
		init(pVoMainCurrency.getMainCurrencyId());
		requireMainCurrency();
		mCategory.info(
			"Deleting MainCurrency '"
				+ pVoMainCurrency.getCurrencyCode()
				+ "'.");

		mBefMainCurrency.delete(mMainCurrency);

	}

	/**
	 * @param pVoMainCurrency
	 */
	protected void updateMainCurrency(VoMainCurrency pVoMainCurrency)
		throws InvalidFromDateException, ValueMissingException {

		// Check input values
		checkValues(pVoMainCurrency);

		// Find MainCurrency in dB
		init(pVoMainCurrency.getMainCurrencyId());
		requireMainCurrency();

		mCategory.info(
			"Update MainCurrency - currencyCode:"
				+ pVoMainCurrency.getCurrencyCode());

		// Assign new values from VO to entity
		ValueObjects.assignToBusinessEntity(mMainCurrency, pVoMainCurrency);

		mBefMainCurrency.save(mMainCurrency);

	}

	/**
	 * @param pVoMainCurrency
	 */
	protected void createMainCurrency(VoMainCurrency pVoMainCurrency)
		throws InvalidFromDateException, ValueMissingException {

		// Check input values
		checkValues(pVoMainCurrency);

		mCategory.info(
			"Create new MainCurrency - CurrencyCode:"
				+ pVoMainCurrency.getCurrencyCode());
		// Create new MainCurrency 
		mMainCurrency = mBefMainCurrency.create();

		// Assign to VO to Entity
		ValueObjects.assignToBusinessEntity(mMainCurrency, pVoMainCurrency);

		// Get the Country to connect with
		BecCountry vBecCountry = mBecFactory.createBecCountry();
        VoCountryKey voCountryKey = new VoCountryKey();
        voCountryKey.setCountryId(mVoCountry.getCountryId());
		vBecCountry.findCountry(voCountryKey);
		mMainCurrency.setCountry(vBecCountry.getCountry());

		// Save MainCurrency
		mBefMainCurrency.save(mMainCurrency);

	}

	/**
	 * @param pVoMainCurrency
	 */
	protected void checkValues(VoMainCurrency pVoMainCurrency)
		throws InvalidFromDateException, ValueMissingException {

		// Currency code must not be empty
		if ((pVoMainCurrency.getCurrencyCode() == null)
			|| (pVoMainCurrency.getCurrencyCode().length() == 0)) {
			throw new ValueMissingException("Currency code must not be empty");
		}

		if ((pVoMainCurrency.getFromDate() == null)
			|| (pVoMainCurrency.getFromDate().equals(""))) {
			throw new ValueMissingException("From date must not be empty");
		}

		//FromDate not earlier than today (without time)
		DateTime vNow = new DateTime(mTimeSource.currentDate());
		if (pVoMainCurrency.getFromDate().before(Dates.withoutTime(vNow))) {

			throw new InvalidFromDateException(
				"From date '"
					+ pVoMainCurrency.getFromDate()
					+ "' is not valid. Cannot be earlier than today '"
					+ Dates.withoutTime(vNow)
					+ "'.");
		}

	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireMainCurrency() throws ValueMissingException {
		if (mMainCurrency == null) {
			throw new ValueMissingException("Tried to use BecMainCurrency without required MainCurrency.");
		}

	}

}
