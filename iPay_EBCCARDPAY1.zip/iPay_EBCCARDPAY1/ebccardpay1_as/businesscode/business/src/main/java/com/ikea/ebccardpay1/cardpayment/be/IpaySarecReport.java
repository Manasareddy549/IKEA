package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

/**
 * @author moans1
 *
 */
public class IpaySarecReport extends BusinessEntity {
	/**										
	 * Storage: IPAY_SAREC_REPORT_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mReportId;
	
	/**										
	 * Data								
	 */		
	private String mBuCode;
	private String mBuType;
	private String mSalesDate;
	private String mStatus;
	
	/**										
	 * Common attributes	
	 */		
	private int mVersionNo;
	private java.util.Date mCreatedDateTime;
	private java.util.Date mUpdatedDateTime;
	private String mCreatedBy;
	private String mUpdatedBy;
	
	/**
	 * BLOB File
	 */

	private java.sql.Blob mSarecFile;
	private java.sql.Blob mS4hanaFile;

	

	/**
	 * @return Returns the reportId
	 */
	public long getReportId() {
		return mReportId;
	}

	/**
	 * @param reportId The reportId to set
	 */
	public void setReportId(long pReportId) {
		mReportId = pReportId;
	}

	/**
	 * @return Returns the buCode
	 */
	public String getBuCode() {
		return mBuCode;
	}

	/**
	 * @param buCode The buCode to set
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**
	 * @return Returns the buType
	 */
	public String getBuType() {
		return mBuType;
	}

	/**
	 * @param buType The buType to set
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**
	 * @return Returns the salesDate
	 */
	public String getSalesDate() {
		return mSalesDate;
	}

	/**
	 * @param salesDate The salesDate to set
	 */
	public void setSalesDate(String pSalesDate) {
		mSalesDate = pSalesDate;
	}

	/**
	 * @return Returns the status
	 */
	public String getStatus() {
		return mStatus;
	}

	/**
	 * @param status The status to set
	 */
	public void setStatus(String pStatus) {
		mStatus = pStatus;
	}
	
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**
	 * @return Returns the createdDateTime
	 */
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	/**
	 * @param createdDateTime The createdDateTime to set
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**
	 * @return Returns the updatedDateTime
	 */
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	/**
	 * @param updatedDateTime The updatedDateTime to set
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/**
	 * @return Returns the createdBy
	 */
	public String getCreatedBy() {
		return mCreatedBy;
	}

	/**
	 * @param createdBy The createdBy to set
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**
	 * @return Returns the updatedBy
	 */
	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	/**
	 * @param updatedBy The updatedBy to set
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**
	 * @return Returns the sarecFile
	 */
	public java.sql.Blob getSarecFile() {
		return mSarecFile;
	}

	/**
	 * @param saarecFile The sarecFile to set
	 */
	public void setSarecFile(java.sql.Blob pSarecFile) {
		mSarecFile = pSarecFile;
	}
	
	public java.sql.Blob getS4hanaFile() {
		return mS4hanaFile;
	}

	public void setS4hanaFile(java.sql.Blob pS4hanaFile) {
		mS4hanaFile = pS4hanaFile;
	}
}
