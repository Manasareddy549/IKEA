package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Collection;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationAmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.ReverseAmountCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoAuthorization;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionKey;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransaction;
import com.ikea.ebcframework.exception.IkeaException;

import java.util.List;

public interface BecTransactions {

	/**
	 * Prepares the controller for use, by finding a collection of transactions to act
	 * upon through a transaction number
	 * 
	 * @param pTransactionNo The transaction number
	 */
	public BecTransactions init(long pTransactionNo);

	/**
	 * Prepares the controller for use, by finding a collection of transactions to act
	 * upon through a reference
	 * 
	 * @param pReference The reference
	 * @param pSourceSystem The source system
	 */
	public BecTransactions init(
		String pReference,
		String pSourceSystem,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * Prepares the controller for use, by finding a collection of transactions to act
	 * upon through originator settings
	 * 
	 * @param pBuType The business unit type
	 * @param pBuCode The business unit code
	 * @param pSourceSystem The source system
	 * @param pPointOfSale The point of sale designator
	 * @param pCardNumberString The card number to look for
	 * @throws ReferenceCheckException 
	 */
	public BecTransactions init(
		String pBuType,
		String pBuCode,
		String pSourceSystem,
		String pPointOfSale,
		String pCardNumberString,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment)
		throws
			CardNotFoundException,
			InvalidCardNumberException,
			ValueMissingException,
			IkeaException, ReferenceCheckException;

	/**
	 * Prepares the controller for use, by finding a collection of transactions to act
	 * upon through originator settings
	 * 
	 * @param pAmount
	 * @param pCardNumberString
	 * @param pReceipt
	 * @throws ReferenceCheckException 
	 */
	public BecTransactions init(
		BigDecimal pAmount,
		String pCurrencyCode,
		String pBuType,
		String pBuCode,
		String pSourceSystem,
		String pPointOfSale,
		String pReceipt,
		String pCardNumberString,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment)
		throws
			CardNotFoundException,
			InvalidCardNumberException,
			ValueMissingException,
			IkeaException, ReferenceCheckException;

	/**
	 * Prepares the controller for use
	 * 
	 * @param pBusinessUnitEnvironment
	 * @param pTransactionEnvironment
	 */
	public BecTransactions init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * Prepares the controller for use, by providing a collection of transactions to act
	 * upon
	 * 
	 * @param pTransactions A collection of transactions
	 */
	public BecTransactions initTransactions(Collection<Transaction> pTransactions);

	/**
	 * Prepares the controller for use, by providing a card number string
	 * 
	 * @param pCardNumberString A card number for identifying a card
	 * @throws ReferenceCheckException 
	 */
	public BecTransactions initCard(String pCardNumberString)
		throws
			CardNotFoundException,
			InvalidCardNumberException,
			ValueMissingException,
			IkeaException, ReferenceCheckException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public Card getCard() throws ValueMissingException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public VoTransactionKey getVoTransactionKey() throws ValueMissingException;

	/**
	 * Cancels the current transactions
	 * 
	 * @throws ValueMissingException
	 */
	public void cancelTransactions()
		throws ValueMissingException, AmountException;

	/**
	 * Voids the current transactions
	 * 
	 * @param pSourceSystem The source system that want's to void
	 * @param pManual True if this is a manual void
	 * @throws ValueMissingException
	 * @throws UnacknowledgedTimeoutException 
	 */
	public Card voidTransactions(
		String pSourceSystem,
		boolean pManual, boolean pWaitingAck)
		throws
			AuthorizationAmountException,
			TransactionException,
			AuthorizationException,
			ValueMissingException,
			AmountException,
			ReferenceCheckException,
			IkeaException, UnacknowledgedTimeoutException;
	
	/**
	 * Voids the current transactions
	 * 
	 * @param pSourceSystem The source system that want's to void
	 * @param pManual True if this is a manual void
	 * @throws ValueMissingException
	 * @throws UnacknowledgedTimeoutException 
	 */
	public VoAuthorization voidManualTransactions(
		String pSourceSystem,
		boolean pManual)
		throws
			AuthorizationAmountException,
			TransactionException,
			AuthorizationException,
			ValueMissingException,
			AmountException,
			ReferenceCheckException,
			IkeaException, UnacknowledgedTimeoutException;

	/**
	 * Authorize the current set of transactions by generating an authorization number
	 * 
	 * @throws AuthorizationException
	 * @throws ValueMissingException
	 */
	public VoAuthorization authorizeTransactions()
		throws
			AuthorizationException,
			AuthorizationAmountException,
			ValueMissingException;

	/**
	 * Compresses the current collection of Transaction objects into into a list of
	 * VoTransactionBrief value objects. The compression adds up the balance change
	 * and card balance change and returns one value object for each transaction no,
	 * regardless of how many transactions that were involved.
	 * 
	 * @return A list of VoTransactionBrief
	 */
	public List<VoTransactionBrief> compressBrief() throws ValueMissingException;

	/**
	 * Compresses the current collection of Transaction objects into into a list of
	 * VoTransactionCard value objects. The compression adds up the balance change
	 * and card balance change and returns one value object for each transaction no,
	 * regardless of how many transactions that were involved.
	 * 
	 * @return A list of VoTransactionCard
	 */
	public List<VoTransactionCard> compressCard() throws ValueMissingException;

	/**
	 * Compresses the current collection of Transaction objects into into a list of
	 * VoTransaction + VoTransactionDetail value objects. The compression adds up the balance change
	 * and card balance change and returns one value object for each transaction no,
	 * regardless of how many transactions that were involved. The expanded list of
	 * detailed transactions are added to the VoTransaction as VoTransactionDetail
	 * 
	 * @return A list of VoTransaction
	 */
	public List<VoTransaction> compressDetailed() throws ValueMissingException;

	/**
	 * Compresses the current collection of Transaction objects into into a list of
	 * VoReportTransaction value objects. The compression adds up the balance change
	 * and card balance change and returns one value object for each transaction no,
	 * regardless of how many transactions that were involved.
	 * 
	 * @return A list of VoReportTransaction
	 */
	public List<VoReportTransaction> compressReport()
		throws ValueMissingException;


}
