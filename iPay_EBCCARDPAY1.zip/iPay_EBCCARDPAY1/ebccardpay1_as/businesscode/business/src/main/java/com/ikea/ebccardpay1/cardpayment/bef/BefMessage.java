package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.Message;

public interface BefMessage extends Bef<Message>{


	
}