/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardBusinessKey;
import com.ikea.ebcframework.exception.IkeaException;

import java.util.List;

/**
 * @author anms
 *
 */
public interface BecCards {

	/**
	 * @param pBusinessUnitEnvironment
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecCards init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pVoCardBusinessKeyList
	 * @return
	 * @throws InvalidCardNumberException
	 * @throws DuplicateCardException
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	public List<VoCardBusinessKey> activate(List<VoCardBusinessKey> pVoCardBusinessKeyList)
		throws
			InvalidCardNumberException,
			DuplicateCardException,
			ValueMissingException,
			IkeaException;
}
