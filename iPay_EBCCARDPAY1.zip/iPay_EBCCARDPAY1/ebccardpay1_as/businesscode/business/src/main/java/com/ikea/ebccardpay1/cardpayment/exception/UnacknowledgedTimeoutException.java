/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;


public class UnacknowledgedTimeoutException extends CardException{

	private static final long serialVersionUID = -7271851178153844845L;
	public UnacknowledgedTimeoutException()
	{
		super("");

	}
	public UnacknowledgedTimeoutException(String pMessage) {
		super(pMessage);
	}
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ExpiredCard();
	}

}

