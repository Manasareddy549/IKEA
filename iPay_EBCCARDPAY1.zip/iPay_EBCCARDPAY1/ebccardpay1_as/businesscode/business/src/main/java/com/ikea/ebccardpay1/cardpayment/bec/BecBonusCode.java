/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.BonusCode;
import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCode;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecBonusCode {

	/**
	 * 
	 * @param pBonusCodeId
	 * @return
	 */
	public BecBonusCode init(long pBonusCodeId);

	/**
	 * 
	 * @param pBonusCode
	 * @return
	 */
	public BecBonusCode init(BonusCode pBonusCode);

	/**
	 * 
	 * @return
	 */
	public BonusCode getBonusCode();

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoBonusCode getVoBonusCode() throws ValueMissingException;

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoBonusCodeBriefRef getVoBonusCodeBriefRef()
		throws ValueMissingException;

	/**
	 * @param pVoBonusCode
	 * @throws IkeaException
	 */
	public void manage(VoBonusCode pVoBonusCode)
		throws IkeaException, ValueMissingException, BonusCodeException;

}
