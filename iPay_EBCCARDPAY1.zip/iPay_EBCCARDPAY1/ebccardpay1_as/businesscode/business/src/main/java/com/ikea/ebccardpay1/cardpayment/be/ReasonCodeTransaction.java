/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

public class ReasonCodeTransaction extends BusinessEntity {
	/**										
	 * Storage: REASON_CODE_TRANSACTION_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mTransactionId;

	

	/**										
	 * Data								
	 */										
	private int mReasonCodeId;
	private String mCustomerType;
	private String mCompanyName;
	private boolean mThirdPartySales;
	
	
	

	public int getReasonCodeId() {
		return mReasonCodeId;
	}

	public void setReasonCodeId(int mReasonCodeId) {
		this.mReasonCodeId = mReasonCodeId;
	}

	
	public long getTransactionId() {
		return mTransactionId;
	}

	public void setTransactionId(long mTransactionId) {
		this.mTransactionId = mTransactionId;
	}

	public String getCustomerType() {
		return mCustomerType;
	}

	public void setCustomerType(String pCustomerType) {
		mCustomerType = pCustomerType;
	}

	public String getCompanyName() {
		return mCompanyName;
	}

	public void setCompanyName(String pCompanyName) {
		mCompanyName = pCompanyName;
	}
	
	public boolean getThirdPartySales() {
		return mThirdPartySales;
	}

	public void setThirdPartySales(boolean pThirdPartySales) {
		mThirdPartySales = pThirdPartySales;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("reasonCodeId", CodeGeneration.toObject(mReasonCodeId));
		vMap.put("transactionId", CodeGeneration.toObject(mTransactionId));
		vMap.put("customerType", CodeGeneration.toObject(mCustomerType));
		vMap.put("companyName", CodeGeneration.toObject(mCompanyName));
		vMap.put("thirdPartySales", CodeGeneration.toObject(mThirdPartySales));
		return vMap;
	}

	 /*(non-Javadoc)
	  @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)*/
	 
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("reasonCodeId")) mReasonCodeId = CodeGeneration.objectToInteger(pMap.get("reasonCodeId"));
		if(pMap.containsKey("transactionId")) mTransactionId = CodeGeneration.objectTolong(pMap.get("transactionId"));
		if(pMap.containsKey("customerType")) mCustomerType = CodeGeneration.objectToString(pMap.get("customerType"));
		if(pMap.containsKey("companyName")) mCompanyName = CodeGeneration.objectToString(pMap.get("companyName"));
		if(pMap.containsKey("thirdPartySales")) mThirdPartySales = CodeGeneration.objectToboolean(pMap.get("thirdPartySales"));
	}


}
