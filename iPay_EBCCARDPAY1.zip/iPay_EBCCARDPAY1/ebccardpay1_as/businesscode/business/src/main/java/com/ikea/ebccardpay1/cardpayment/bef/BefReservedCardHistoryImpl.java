package com.ikea.ebccardpay1.cardpayment.bef;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.CopyOnWriteArrayList;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.ebccardpay1.common.Constants;
import java.util.List;
/**
 * @author vikum27
 */
public class BefReservedCardHistoryImpl extends BefAbstract<ReservedCardHistory> implements BefReservedCardHistory {

	private final static Logger mLog = LoggerFactory.getLogger(BefReservedCardHistoryImpl.class);
	private final static Logger mCategory_findByReservedHistoryId = LoggerFactory
			.getLogger(BefReservedCardHistoryImpl.class.getName()
					+ ".findByReservedHistoryId");
	protected BefReservedCardHistoryImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Class<ReservedCardHistory> getBusinessEntityClass() {
		return ReservedCardHistory.class;
	}
	
	public List<ReservedCardHistory> getCurrentAuthorizeAmountList(Card pCard) {
		Session vSession = mSessionFactory.getCurrentSession();

		return new GenericQuery<ReservedCardHistory>(vSession
				.createQuery("from ReservedCardHistory where card=:card")
				.setEntity("card", pCard))
				.list();
	}
	public ReservedCardHistory findByRefrence(String pRefrence) {
		Session vSession = mSessionFactory.getCurrentSession();

		ReservedCardHistory vReservedCardHistory = (ReservedCardHistory) vSession
				.createQuery("from ReservedCardHistory where reference=:reference")
				.setParameter("reference", pRefrence)
				.uniqueResult();
				
				if (vReservedCardHistory == null) {
					mLog.debug("No record found.");
				}
		return vReservedCardHistory;
				
	}
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory#findByTransactionNo(long)
	 */
	public ReservedCardHistory findByTransactionNo(long pTransactionNo) {

		Session vSession = mSessionFactory.getCurrentSession();

		
		ReservedCardHistory vReservedCardHistory = (ReservedCardHistory) vSession
				.createQuery("from ReservedCardHistory where transactionNo=:transactionNo")
				.setParameter("transactionNo", pTransactionNo)
				.uniqueResult();
		
		if (vReservedCardHistory == null) {
			mLog.debug("No record found.");
		}
		
		return vReservedCardHistory;
	}
	
	public List<ReservedCardHistory> findByTransactionNos(long pTransactionNo) {

		Session vSession = mSessionFactory.getCurrentSession();

		return new GenericQuery<ReservedCardHistory>(vSession
				.createQuery(
						"from ReservedCardHistory" + " where transactionNo=:transactionNo")
				.setLong("transactionNo", pTransactionNo))
				.list();
	}
}
