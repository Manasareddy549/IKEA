/*
 * Created on 2007-aug-09
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.exception.ExternalCardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecExternalCard {

	/**
	 * 
	 * @param pExternalCard
	 * @return
	 */
	public BecExternalCard init(ExternalCard pExternalCard);

	/**
	 * 
	 * @param pExternalCardSystemName
	 * @return
	 */
	public BecExternalCard init(String pExternalCardSystemName);

	/**
	 * 
	 * @param pExternalCardNumberString
	 */
	public void findExternal(String pExternalCardNumberString)
		throws ExternalCardNotFoundException, InvalidCardNumberException;

	/**
	 * 
	 * @return
	 */
	public ExternalCard getExternalCard();

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 */
	public Card createInternalFromExternal()
		throws ValueMissingException, InvalidCardNumberException, IkeaException;

	/**
	 * 
	 * @param pVoExternalCard
	 * @param pExternalCardSystem
	 */
	public void createExternalCard(
		VoExternalCard pVoExternalCard,
		ExternalCardSystem pExternalCardSystem)
		throws InvalidCardNumberException, ValueMissingException;

	/**
	 * @param mExternalCardSystem
	 * @return number of deleted records
	 */
	public int deleteNotCompleted(ExternalCardSystem mExternalCardSystem);

}
