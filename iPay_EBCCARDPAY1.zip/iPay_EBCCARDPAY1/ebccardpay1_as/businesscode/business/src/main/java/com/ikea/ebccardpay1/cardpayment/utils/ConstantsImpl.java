/*
 * Created on 2006-maj-29
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CardTypeConstant;
import com.ikea.ebccardpay1.cardpayment.be.ReasonCode;
import com.ikea.ebccardpay1.cardpayment.be.SourceSystemConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardTypeConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefConstants;
import com.ikea.ebccardpay1.cardpayment.bef.BefReasonCode;
import com.ikea.ebccardpay1.cardpayment.bef.BefSourceSystemConstant;
import com.ikea.ebccardpay1.common.*;


/**
 * @author anms
 *
 */
public class ConstantsImpl implements Constants {

	private final static Logger mLog = LoggerFactory.getLogger(ConstantsImpl.class);

	private BefSourceSystemConstant mBefSourceSystemConstant = null;
	private Hashtable<String, SourceSystemConstant> mSourceSystems = null;

	private BefCardTypeConstant mBefCardTypeConstant = null;
	private Hashtable<Integer, String> mCardTypeDigits = null;
	
	private BefReasonCode mBefLaodReasonCodeConstant = null;
	private Hashtable<String, ReasonCode> mLaodReasonCodes = null;
	
	private BefReasonCode mBefRedeemReasonCodeConstant = null;
	private Hashtable<String, ReasonCode> mRedeemReasonCodes = null;

	private BefConstants mBefConstants = null;

	public ConstantsImpl(
		BefCardTypeConstant pBefCardTypeConstant,
		BefSourceSystemConstant pBefSourceSystemConstant,
		BefConstants pBefConstants,
		BefReasonCode pBefReasonCode) {

		mBefCardTypeConstant = pBefCardTypeConstant;
		mBefSourceSystemConstant = pBefSourceSystemConstant;
		mBefConstants = pBefConstants;
		mBefLaodReasonCodeConstant = pBefReasonCode;
		mBefRedeemReasonCodeConstant = pBefReasonCode;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Constants#getCardType(int)
	 */
	public String getCardType(int pCardTypeDigit)
		throws CardTypeDigitNotFoundException {

		if (mCardTypeDigits == null) {
			getAllCardTypes();
		}
		String vCardType =
			(String) mCardTypeDigits.get(new Integer(pCardTypeDigit));
		if (vCardType == null) {
			throw new CardTypeDigitNotFoundException(
				"Could not find card type for card type digit '"
					+ pCardTypeDigit
					+ "'.");
		}

		return vCardType;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Constants#validateWithDatabase()
	 */
	public void validateConstants() {

		// Validate that all constants used in code exists in database.
		List<?> vActual = null;

		List<String> vExpectedConstants = new ArrayList<String>();
		// Call BEF

		// AmountTypeConstants
		vExpectedConstants = getAmountTypeConstants();
		vActual = mBefConstants.getAmountTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"AmountType");

		// CampaignStateConstants
		vExpectedConstants = getCampaignStateConstants();
		vActual = mBefConstants.getCampaignStateConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"CampaignState");

		// CardStateConstants
		vExpectedConstants = getCardStateConstants();
		vActual = mBefConstants.getCardStateConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"CardState");

		// CardTypeConstants
		vExpectedConstants = getCardTypeConstants();
		vActual = mBefConstants.getCardTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"CardType");

		// ExchangeModeConstants
		vExpectedConstants = getExchangeModeConstants();
		vActual = mBefConstants.getExchangeModeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"ExchangeMode");

		// FinancialTypeConstants
		vExpectedConstants = getFinancialTypeConstants();
		vActual = mBefConstants.getFinancialTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"FinancialType");

		// KPITypeConstants
		vExpectedConstants = getKpiTypeConstants();
		vActual = mBefConstants.getKpiTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"KPIType");

		// LifeCycleTypeConstants
		vExpectedConstants = getLifeCycleTypeConstants();
		vActual = mBefConstants.getLifeCycleTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"LifeCycleType");

		// ParameterTypeConstants
		vExpectedConstants = getParameterTypeConstants();
		vActual = mBefConstants.getParameterTypeConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"ParameterType");

		// SourceSystemConstants
		vExpectedConstants = getSourceSystemConstants();
		vActual = mBefConstants.getSourceSystemConstants();
		checkConstantMatch(
			vExpectedConstants.toString(),
			vActual.toString(),
			"SourceSystem");

		// TransactionTypeConstants
		vExpectedConstants = getTransactionTypeConstants();
		vActual = mBefConstants.getTransactionTypeConstants();
		
		// SourceSystemConstants
		vExpectedConstants = getSourceSystemConstants();
		vActual = mBefConstants.getSourceSystemConstants();
		checkConstantMatch(
				vExpectedConstants.toString(),
				vActual.toString(),
				"SourceSystem");

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Constants#isPointOfSale()
	 */
	public boolean isPointOfSale(String pSourceSystem) {

		if (mSourceSystems == null) {
			getAllSourceSystems();
		}
		SourceSystemConstant vSourceSystem =
			(SourceSystemConstant) mSourceSystems.get(pSourceSystem);
		if (vSourceSystem == null) {
			throw new IllegalStateException(
				"Could not find source system '" + pSourceSystem + "'.");
		}

		return vSourceSystem.getPointOfSale();
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Constants#checkValidAmountType(java.lang.String)
	 */
	public void checkValidAmountType(String pAmountType)
		throws AmountTypeNotSupportedException {
		List<?> vAmountTypes = getAmountTypeConstants();

		if (!vAmountTypes.contains(pAmountType)) {
			throw new AmountTypeNotSupportedException(
				"Amount type '" + pAmountType + "' is not valid.");
		}
	}

	// ----------------------------------------------------------------------------------------

	/**
	 * Get all the card types from database
	 */
	protected synchronized void getAllCardTypes() {
		if (mCardTypeDigits == null) {

			Hashtable<Integer, String> vTemp = new Hashtable<Integer, String>();

			for (Iterator<?> i = mBefCardTypeConstant.findAll().iterator();
				i.hasNext();
				) {
				CardTypeConstant vCardTypeConstant =
					(CardTypeConstant) i.next();
				vTemp.put(
					new Integer(vCardTypeConstant.getCardTypeDigit()),
					vCardTypeConstant.getCardType());

			}
			// Must assign the complete hash table in one operation
			// so we do not get syncronization errors!
			mCardTypeDigits = vTemp;
		}
	}

	/**
	 * Get all the source systems from database
	 */
	protected synchronized void getAllSourceSystems() {
		if (mSourceSystems == null) {

			Hashtable<String, SourceSystemConstant> vTemp = new Hashtable<String, SourceSystemConstant>();

			for (Iterator<?> i = mBefSourceSystemConstant.findAll().iterator();
				i.hasNext();
				) {
				SourceSystemConstant vSourceSystemConstant =
					(SourceSystemConstant) i.next();
				vTemp.put(
					vSourceSystemConstant.getSourceSystem(),
					vSourceSystemConstant);
				// Do we need to disconnect the POJO from Hibernate?

			}
			// Must assign the complete hash table in one operation
			// so we do not get syncronization errors!
			mSourceSystems = vTemp;
		}
	}
	
	/**
	 * Get all the load reason codes from database
	 */
	protected synchronized void getAllLoadReasonCodes() {
		if (mLaodReasonCodes == null) {

			Hashtable<String, ReasonCode> vTemp = new Hashtable<String, ReasonCode>();

			for (Iterator<?> i = mBefLaodReasonCodeConstant.findAll().iterator();
				i.hasNext();
				) {
				ReasonCode vReasonCode =
					(ReasonCode) i.next();
				vTemp.put(
						vReasonCode.getLoadReasonDescription(),
						vReasonCode);
				// Do we need to disconnect the POJO from Hibernate?

			}
			// Must assign the complete hash table in one operation
			// so we do not get syncronization errors!
			mLaodReasonCodes = vTemp;
		}
	}
	
	/**
	 * Get all the redeem reason codes from database
	 */
	protected synchronized void getAllRedeemReasonCodes() {
		if (mRedeemReasonCodes == null) {

			Hashtable<String, ReasonCode> vTemp = new Hashtable<String, ReasonCode>();

			for (Iterator<?> i = mBefRedeemReasonCodeConstant.findAll().iterator();
				i.hasNext();
				) {
				ReasonCode vReasonCode =
					(ReasonCode) i.next();
				vTemp.put(
						vReasonCode.getRedeemReasonDescription(),
						vReasonCode);
				// Do we need to disconnect the POJO from Hibernate?

			}
			// Must assign the complete hash table in one operation
			// so we do not get syncronization errors!
			mRedeemReasonCodes = vTemp;
		}
	}
	/**
	 * For test cases only!
	 */
	protected Hashtable<Integer, String> getCardTypeDigits() {
		return mCardTypeDigits;
	}

	/**
	 * For test cases only!
	 */
	protected void setCardTypeDigits(Hashtable<Integer, String> pCardTypeDigits) {
		mCardTypeDigits = pCardTypeDigits;

	}
	/**
	 * For test cases only!
	 */
	protected Hashtable<String, SourceSystemConstant> getSourceSystems() {
		return mSourceSystems;
	}

	/**
	 * For test cases only!
	 */
	protected void setSourceSystems(Hashtable<String, SourceSystemConstant> pSourceSystems) {
		mSourceSystems = pSourceSystems;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getAmountTypeConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.AMOUNT_TYPE_CONSTANT_CASH);
		vExpected.add(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);

		return vExpected;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getCampaignStateConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.CAMPAIGN_STATE_CONSTANT_AUTHORIZED);
		vExpected.add(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
		vExpected.add(Constants.CAMPAIGN_STATE_CONSTANT_LOCKED);
		vExpected.add(Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING);
		vExpected.add(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN);

		return vExpected;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getCardStateConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.CARD_STATE_CONSTANT_ACTIVE);
		vExpected.add(Constants.CARD_STATE_CONSTANT_ARCHIVED);
		vExpected.add(Constants.CARD_STATE_CONSTANT_BLOCKED);
		vExpected.add(Constants.CARD_STATE_CONSTANT_BOUND);
		vExpected.add(Constants.CARD_STATE_CONSTANT_EXPIRED);
		vExpected.add(Constants.CARD_STATE_CONSTANT_INACTIVE);

		return vExpected;
	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getCardTypeConstants() {
		return Arrays.asList(CARD_TYPE_ALL_CONSTANTS);
	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getFinancialTypeConstants() {
		return Arrays.asList(FINANCIAL_TYPE_ALL_CONSTANTS);
	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getKpiTypeConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.KPI_TYPE_CONSTANT_COUNTRY);
		vExpected.add(Constants.KPI_TYPE_CONSTANT_DEBT);
		vExpected.add(Constants.KPI_TYPE_CONSTANT_EMPLOYEE);
		vExpected.add(Constants.KPI_TYPE_CONSTANT_MIGRATION);
		vExpected.add(Constants.KPI_TYPE_CONSTANT_STORE);

		return vExpected;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getLifeCycleTypeConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_ACTIVATED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_ARCHIVED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_BLOCKED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_CAMPAIGN);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_EXPIRED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_INACTIVATED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_MASS_LOAD);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_MIGRATED);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_MULTIPLE_SINGLE_LOAD);
		vExpected.add(Constants.LIFE_CYCLE_TYPE_CONSTANT_TRANSACTION);
		return vExpected;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getParameterTypeConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_BU_CODE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_BU_TYPE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_CARD_TYPE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_COUNTRY_CODE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_FROM_COUNTRY_CODE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_DATE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_DATE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_MONTH);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_MONTH);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_DATE);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_MONTH);
		vExpected.add(
			Constants.PARAMETER_TYPE_CONSTANT_LAST_TRANSACTION_DATE_TIME);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_SALES_DAY);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_SOURCE_SYSTEM);
		vExpected.add(Constants.PARAMETER_TYPE_CONSTANT_TO_COUNTRY_CODE);

		return vExpected;

	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getSourceSystemConstants() {
		return Arrays.asList(SOURCE_SYSTEM_ALL_CONSTANTS);
	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getExchangeModeConstants() {
		return Arrays.asList(EXCHANGE_MODE_ALL_CONSTANTS);
	}

	/**
	 * @return List of the constants used
	 */
	public List<String> getTransactionTypeConstants() {
		List<String> vExpected = new ArrayList<String>();
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_BONUS_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_EXTERNAL_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_MASS_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_MIGRATION_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_MULTIPLE_SINGLE_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_VOID_LOAD);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_VOID_REDEEM);
		vExpected.add(Constants.TRANSACTION_TYPE_CONSTANT_WITHDRAW_MASS_LOAD);

		return vExpected;

	}

	protected void checkConstantMatch(
		String pCodeConstants,
		String pDBConstants,
		String pGroup) {
		if (!pCodeConstants.equals(pDBConstants)) {

			mLog.warn(
				"List of "
					+ pGroup
					+ " constants is wrong. Constants from code "
					+ pCodeConstants
					+ "  ,  found in DB "
					+ pDBConstants);

		}

	}

}
