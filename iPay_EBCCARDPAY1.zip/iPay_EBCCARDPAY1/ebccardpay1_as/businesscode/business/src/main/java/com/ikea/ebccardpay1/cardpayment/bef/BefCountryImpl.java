/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefCountryImpl extends BefAbstract<Country> implements BefCountry {

	private final static Logger mCategory_findByName =
		LoggerFactory.getLogger(BefCountryImpl.class.getName() + ".findByName");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCountryImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	public Country findByCountryCode(String pCountryCode) {
		Session vSession = mSessionFactory.getCurrentSession();

		Criteria vCriteria = vSession.createCriteria(Country.class);
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));

		Country vCountry = (Country) vCriteria.uniqueResult();

		if (vCountry == null) {
			mCategory_findByName.info(
				"No country found by this country code: " + pCountryCode + ".");
		} else {
			mCategory_findByName.info(
				"Found country for this country code: " + pCountryCode);
		}

		return vCountry;

	}

	@Override
	protected Class<Country> getBusinessEntityClass() {
		return Country.class;
	}

}
