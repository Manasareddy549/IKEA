/*
 * Created on 2006-jun-07
 *
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.utils;

/**
 * @author anms
 *
 */
public interface EbcEnvironment {
	

	public String MAX_CARDS_IN_CAMPAIGN_PROCESSING_PROP = "max.cards.in.campaign.processing";
	public int MAX_CARDS_IN_CAMPAIGN_PROCESSING_DEFAULT = 1000;
	
	public String MAX_CARDS_IN_MASS_LOAD_PROCESSING_PROP = "max.cards.in.mass.load.processing";
	public int MAX_CARDS_IN_MASS_LOAD_PROCESSING_DEFAULT = 100;
	

	/**
	 * Returns the maximun number of cards that we will process during one transaction when processing a lock campaign.
	 * @return
	 */
	public int getMaxCardsInCampaignProcessing();

	/**
	 * Returns the maximun number of cards that we will process during one transaction when processing a lock or release mass load.
	 * @return
	 */
	public int getMaxCardsInMassLoadProcessing();

}
