package com.ikea.ebccardpay1.cardpayment.bef;


import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.ReasonCode;
import com.ikea.common.TimeSource;

public class BefReasonCodeImpl extends
BefAbstract<ReasonCode> implements BefReasonCode {
	/**
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefReasonCodeImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<ReasonCode> getBusinessEntityClass() {
		return ReasonCode.class;
	}

}
