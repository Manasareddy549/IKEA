/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.be;


import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class UnacknowledgedTimeout extends BusinessEntity {
	/**										
	 * Storage: UNACKNOWLEDGED_TIMEOUT_T											
	 */										

	
	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;
	private int mUnacknowledgedTimeoutId;
	private long mTimeoutSec;


	/**										
	 * Data								
	 */										
	
	private String mSourceSystem;
	private String mBuType;
	private String mBuCode;
	

	
	

	/**											
	 * @return Returns the sourceSystem.													
	 */											
	public String getSourceSystem() {
		return mSourceSystem;
	}
	/**
	 * @param pSourceSystem The sourceSystem to set.
	 */
	public void setSourceSystem(String pSourceSystem) {
		mSourceSystem = pSourceSystem;
	}

										
	
	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	
	
	
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	/**
	 * @param mUnacknowledgedTimeout the mUnacknowledgedTimeout to set
	 */
	public void setUnacknowledgedTimeoutId(int pUnacknowledgedTimeoutId) {
		mUnacknowledgedTimeoutId = pUnacknowledgedTimeoutId;
	}
	/**
	 * @return the mUnacknowledgedTimeout
	 */
	public int getUnacknowledgedTimeoutId() {
		return mUnacknowledgedTimeoutId;
	}
	/**
	 * @param mTimeoutSec the mTimeoutSec to set
	 */
	public void setTimeoutSec(long mTimeoutSec) {
		this.mTimeoutSec = mTimeoutSec;
	}
	/**
	 * @return the mTimeoutSec
	 */
	public long getTimeoutSec() {
		return mTimeoutSec;
	}
	

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("sourceSystem", CodeGeneration.toObject(mSourceSystem));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("unacknowledgedTimeoutId", CodeGeneration.toObject(mUnacknowledgedTimeoutId));
		vMap.put("timeoutSec", CodeGeneration.toObject(mTimeoutSec));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
				
		if(pMap.containsKey("sourceSystem")) mSourceSystem = CodeGeneration.objectToString(pMap.get("sourceSystem"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		
	}
	
	
	}
