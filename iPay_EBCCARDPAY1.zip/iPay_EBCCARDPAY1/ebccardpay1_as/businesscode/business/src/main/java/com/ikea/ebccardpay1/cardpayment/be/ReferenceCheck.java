/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class ReferenceCheck extends BusinessEntity {
	/**										
	 * Storage: REFERENCE_CHECK_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mReferenceCheckId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private Card mCard;

	/**										
	 * Data								
	 */										
	private String mReference;
	private String mSourceSystem;
	private String mSalesDay;
	private String mBuType;
	private String mBuCode;
	private String mPointOfSale;
	private String mReceipt;
	private boolean mWaitingAck;
	private long mTransactionNo;
	private boolean mCancelled;
	private long mAckTimeout;
	

	/**											
	 * @return Returns the referenceCheckId.													
	 */											
	public long getReferenceCheckId() {
		return mReferenceCheckId;
	}
	/**
	 * @param pReferenceCheckId The referenceCheckId to set.
	 */
	public void setReferenceCheckId(long pReferenceCheckId) {
		mReferenceCheckId = pReferenceCheckId;
	}

	/**											
	 * @return Returns the reference.													
	 */											
	public String getReference() {
		return mReference;
	}
	/**
	 * @param pReference The reference to set.
	 */
	public void setReference(String pReference) {
		mReference = pReference;
	}

	/**											
	 * @return Returns the sourceSystem.													
	 */											
	public String getSourceSystem() {
		return mSourceSystem;
	}
	/**
	 * @param pSourceSystem The sourceSystem to set.
	 */
	public void setSourceSystem(String pSourceSystem) {
		mSourceSystem = pSourceSystem;
	}

	/**											
	 * @return Returns the salesDay.													
	 */											
	public String getSalesDay() {
		return mSalesDay;
	}
	/**
	 * @param pSalesDay The salesDay to set.
	 */
	public void setSalesDay(String pSalesDay) {
		mSalesDay = pSalesDay;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the pointOfSale.													
	 */											
	public String getPointOfSale() {
		return mPointOfSale;
	}
	/**
	 * @param pPointOfSale The pointOfSale to set.
	 */
	public void setPointOfSale(String pPointOfSale) {
		mPointOfSale = pPointOfSale;
	}

	/**											
	 * @return Returns the receipt.													
	 */											
	public String getReceipt() {
		return mReceipt;
	}
	/**
	 * @param pReceipt The receipt to set.
	 */
	public void setReceipt(String pReceipt) {
		mReceipt = pReceipt;
	}

	/**											
	 * @return Returns the waitingAck.													
	 */											
	public boolean getWaitingAck() {
		return mWaitingAck;
	}
	/**
	 * @param pWaitingAck The waitingAck to set.
	 */
	public void setWaitingAck(boolean pWaitingAck) {
		mWaitingAck = pWaitingAck;
	}

	/**											
	 * @return Returns the transactionNo.													
	 */											
	public long getTransactionNo() {
		return mTransactionNo;
	}
	/**
	 * @param pTransactionNo The transactionNo to set.
	 */
	public void setTransactionNo(long pTransactionNo) {
		mTransactionNo = pTransactionNo;
	}

	/**											
	 * @return Returns the cancelled.													
	 */											
	public boolean getCancelled() {
		return mCancelled;
	}
	/**
	 * @param pCancelled The cancelled to set.
	 */
	public void setCancelled(boolean pCancelled) {
		mCancelled = pCancelled;
	}

	/**											
	 * @return Returns the card.													
	 */											
	public Card getCard() {
		return mCard;
	}
	/**
	 * @param pCard The card to set.
	 */
	public void setCard(Card pCard) {
		mCard = pCard;
	}

	/**
	 * Connect Card.
	 * @param pCard
	 */
	public void connectCard(Card pCard) {
		setCard(pCard);
		if(pCard != null) {
			pCard.getReferenceCheck().add(this);
		}
	}

	/**
	 * Disconnect Card.
	 */
	public void disconnectCard() {
		if(getCard() != null) {
			getCard().getReferenceCheck().remove(this);
		}
		setCard(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	/**
	 * @param mAckTimeout the mAckTimeout to set
	 */
	public void setAckTimeout(long pAckTimeout) {
		mAckTimeout = pAckTimeout;
	}
	/**
	 * @return the mAckTimeout
	 */
	public long getAckTimeout() {
		return mAckTimeout;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mReferenceCheckId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("referenceCheckId", CodeGeneration.toObject(mReferenceCheckId));
		vMap.put("reference", CodeGeneration.toObject(mReference));
		vMap.put("sourceSystem", CodeGeneration.toObject(mSourceSystem));
		vMap.put("salesDay", CodeGeneration.toObject(mSalesDay));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("pointOfSale", CodeGeneration.toObject(mPointOfSale));
		vMap.put("receipt", CodeGeneration.toObject(mReceipt));
		vMap.put("waitingAck", CodeGeneration.toObject(mWaitingAck));
		vMap.put("transactionNo", CodeGeneration.toObject(mTransactionNo));
		vMap.put("cancelled", CodeGeneration.toObject(mCancelled));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("ackTimeout", CodeGeneration.toObject(mAckTimeout));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("referenceCheckId")) mReferenceCheckId = CodeGeneration.objectTolong(pMap.get("referenceCheckId"));
		if(pMap.containsKey("reference")) mReference = CodeGeneration.objectToString(pMap.get("reference"));
		if(pMap.containsKey("sourceSystem")) mSourceSystem = CodeGeneration.objectToString(pMap.get("sourceSystem"));
		if(pMap.containsKey("salesDay")) mSalesDay = CodeGeneration.objectToString(pMap.get("salesDay"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("pointOfSale")) mPointOfSale = CodeGeneration.objectToString(pMap.get("pointOfSale"));
		if(pMap.containsKey("receipt")) mReceipt = CodeGeneration.objectToString(pMap.get("receipt"));
		if(pMap.containsKey("waitingAck")) mWaitingAck = CodeGeneration.objectToboolean(pMap.get("waitingAck"));
		if(pMap.containsKey("transactionNo")) mTransactionNo = CodeGeneration.objectTolong(pMap.get("transactionNo"));
		if(pMap.containsKey("cancelled")) mCancelled = CodeGeneration.objectToboolean(pMap.get("cancelled"));
		if(pMap.containsKey("ackTimeout")) mAckTimeout = CodeGeneration.objectTolong(pMap.get("ackTimeout"));
	}
	
}
