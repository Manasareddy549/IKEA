package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.cardpayment.utils.entities.Data;
import com.ikea.ebccardpay1.cardpayment.utils.entities.EBCPAYLOAD;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.HibernateException;
import org.joda.time.DateTime;

import java.text.SimpleDateFormat;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.ebccardpay1.common.*;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import static org.apache.commons.lang.Validate.notNull;

public class BecTransactionImpl implements BecTransaction, InitializingBean {

	private final static Logger mCategory = LoggerFactory.getLogger(BecTransactionImpl.class);

	// Dependencies injected at creation of this BEC
	private BefTransaction mBefTransaction = null;
	private BefReasonCodeTransaction mBefReasonCodeTransaction = null;
	private Constants mConstants = null;
	private SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
	private Card mCard = null;
	private Amount mAmount = null;
	private MassLoad mMassLoad = null;
	private Transaction mTransaction = null;
	private Campaign mCampaign = null;
	private ReasonCodeTransaction mReasonCodeTransaction = null;
	//@Autowired
	//EbcProperties mEbcProperties;

	// VO that this BEC operates on

	// Related Bec's that this Bec delegates work to

	private TransactionEnvironment mTransactionEnvironment = null;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	
	private Publisher mPublisher = null;

	private UtilsFactory mUtilsFactory;
	
	private EncryptionDecryption mEncryptionDecryption = null;
	//private EbcProperties mEbcProperties;

	private List<EBCPAYLOAD> mEBCPayloadList = new ArrayList<>();

	/**
	 * Dependecy injection
	 */
	protected BecTransactionImpl(BefTransaction pBefTransaction, BefReasonCodeTransaction pBefReasonCodeTransaction,
			Constants pConstants, UtilsFactory pUtilsFactory,Publisher pPublisher, EncryptionDecryption pEncryptionDecryption) {

		mBefTransaction = pBefTransaction;
		mBefReasonCodeTransaction = pBefReasonCodeTransaction;
		mConstants = pConstants;
		mUtilsFactory = pUtilsFactory;
		mPublisher = pPublisher;
		mEncryptionDecryption = pEncryptionDecryption;
		
	}

	void validate() {
		notNull(mBefTransaction);
		notNull(mConstants);
		notNull(mUtilsFactory);
		notNull(mPublisher);
	}

	// @Override
	public void afterPropertiesSet() throws Exception {
		validate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Card, com.ikea.ebccardpay1.cardpayment.be.Amount,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecTransaction init(Card pCard, Amount pAmount, BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mAmount = pAmount;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Transaction,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecTransaction init(Transaction pTransaction, BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mTransaction = pTransaction;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#getTransaction()
	 */
	public Transaction getTransaction() {
		return mTransaction;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#setAmount(Amount)
	 */
	public void setAmount(Amount pAmount) {
		mAmount = pAmount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#setMassLoad(com.ikea.
	 * ebccardpay1.cardpayment.be.MassLoad)
	 */
	public void setMassLoad(MassLoad pMassLoad) {
		mMassLoad = pMassLoad;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createLoadTransaction(
	 * java.math.BigDecimal, java.lang.String)
	 */
	public void createLoadTransaction(BigDecimal pLoadAmount, String pCurrencyCode,
			BigDecimal pBalanceChangeInCardCurrency, String pSourceSystem, VoLoadAmount pVoLoadAmount, String pCardNumberString)
			throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pLoadAmount);

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Load values
		mTransaction.setBalanceChange(pLoadAmount);
		// Cardbalance may differ from balancechange if it is a Cross Currency load
		mTransaction.setCardBalanceChange(pBalanceChangeInCardCurrency);

		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pLoadAmount);
		mTransaction.setRequestedCurrencyCode(pCurrencyCode);

		// Set Cross Border flag
		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		// Set Cross Currency flag
		if (!mCard.getCurrencyCode().equals(pCurrencyCode)) {
			mTransaction.setCrossCurrency(true);
		}

		// Set SourceSystem ID
		if (Constants.SOURCE_SYSTEM_CONSTANT_ICARD.equals(mTransaction.getSourceSystem())) {
			// Special conditions for migration transactions.
			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_MIGRATION_LOAD);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_NONE);
		} else if (Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL.equals(mTransaction.getSourceSystem())) {
			// Special conditions for external load transactions.
			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXTERNAL_LOAD);
			if (pSourceSystem.equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL)) {
				mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);
			} else {
				mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_NONE);
			}

		} else {
			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_LOAD);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);
		}

		saveTransaction(mTransaction);
		
		
		if (pVoLoadAmount.getCustomerType() != null || pVoLoadAmount.getCompanyName() != null
				|| pVoLoadAmount.getThirdPartySales() != false) {
			String customerType = pVoLoadAmount.getCustomerType();
			String business = "Business";
			String privatetype = "Private";
			int thirdPartySalesReasonCode = 99;
			mReasonCodeTransaction = createDefaultReasonCodeTransaction();
			mReasonCodeTransaction.setTransactionId(mTransaction.getTransactionId());

			if (pVoLoadAmount.getCustomerType() != null || pVoLoadAmount.getCompanyName() != null) {
				if (customerType.equals(business) && pVoLoadAmount.getCompanyName().isEmpty()) {
					throw new ValueMissingException("You should provide Company name  when Customer type is Business");
				} else if (customerType.equals(privatetype) && !pVoLoadAmount.getCompanyName().isEmpty()) {
					throw new ValueMissingException("You can not provide Company name  when Customer type is Private");
				} else {
					mReasonCodeTransaction.setCompanyName(pVoLoadAmount.getCompanyName());
					mReasonCodeTransaction.setCustomerType(pVoLoadAmount.getCustomerType());
				}
			}
			if (pVoLoadAmount.getThirdPartySales() != false) {
				mReasonCodeTransaction.setThirdPartySales(pVoLoadAmount.getThirdPartySales());
				mReasonCodeTransaction.setReasonCodeId(thirdPartySalesReasonCode);
			}
			mBefReasonCodeTransaction.save(mReasonCodeTransaction);
		}
		
		/*
		* Publish data to RabbitMQ for BsLoad
		*/
		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));
			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createRedeemTransaction(
	 * com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount, java.math.BigDecimal,
	 * boolean)
	 */
	public void createRedeemTransaction(VoRequestAmount pVoRequestAmount, BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange, boolean pInsufficientAmount, String pCardNumberString)
			throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pCardBalanceChange);

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Redeem values
		mTransaction.setBalanceChange(pTransactionBalanceChange);
		mTransaction.setCardBalanceChange(pCardBalanceChange);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pVoRequestAmount.getRequestAmount());
		mTransaction.setRequestedCurrencyCode(pVoRequestAmount.getCurrencyCode());
		mTransaction.setTotalAmount(pVoRequestAmount.getTotalAmount());

		String vCountryCode = mCard.getCountryCode();
		if (vCountryCode != null && !vCountryCode.equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		if (pInsufficientAmount) {
			mTransaction.setInsufficientAmount(true);
		}
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mTransaction.setCrossCurrency(true);
		}

		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);

		saveTransaction(mTransaction);

		/*
		 * Publish data to RabbitMQ for BsRedeem
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			
			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createRedeemTransaction(
	 * com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount, java.math.BigDecimal,
	 * boolean)
	 */
	public void createRedeemTransactionManual(VoRequestAmount pVoRequestAmount, BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange, boolean pInsufficientAmount, String pCardNumberString) throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pCardBalanceChange);

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Redeem values
		mTransaction.setBalanceChange(pTransactionBalanceChange);
		mTransaction.setCardBalanceChange(pCardBalanceChange);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pVoRequestAmount.getRequestAmount());
		mTransaction.setRequestedCurrencyCode(pVoRequestAmount.getCurrencyCode());
		mTransaction.setTotalAmount(pVoRequestAmount.getTotalAmount());

		String vCountryCode = mCard.getCountryCode();
		if (vCountryCode != null && !vCountryCode.equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		if (pInsufficientAmount) {
			mTransaction.setInsufficientAmount(true);
		}
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mTransaction.setCrossCurrency(true);
		}

		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);

		saveTransaction(mTransaction);
		
		/*
		 * Publish data to RabbitMQ
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			
			mPublisher.publishMessage(vEBCPAYLOAD);
			
			}catch(Exception e) {
				
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

	}

	public void createRedeemTransactionManual(VoRequestAmount pVoRequestAmount, BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange, boolean pInsufficientAmount, VoManualTransaction pVoManualTransaction, String pCardNumberString)
			throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pCardBalanceChange);

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Redeem values
		mTransaction.setBalanceChange(pTransactionBalanceChange);
		mTransaction.setCardBalanceChange(pCardBalanceChange);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pVoRequestAmount.getRequestAmount());
		mTransaction.setRequestedCurrencyCode(pVoRequestAmount.getCurrencyCode());
		mTransaction.setTotalAmount(pVoRequestAmount.getTotalAmount());

		String vCountryCode = mCard.getCountryCode();
		if (vCountryCode != null && !vCountryCode.equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		if (pInsufficientAmount) {
			mTransaction.setInsufficientAmount(true);
		}
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mTransaction.setCrossCurrency(true);
		}

		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);

		saveTransaction(mTransaction);
		
		if (pVoManualTransaction.getReasonCode() > 0) {
			mReasonCodeTransaction = createDefaultReasonCodeTransaction();
			mReasonCodeTransaction.setTransactionId(mTransaction.getTransactionId());
			mReasonCodeTransaction.setReasonCodeId(pVoManualTransaction.getReasonCode());
			mBefReasonCodeTransaction.save(mReasonCodeTransaction);
		}

		/*
		 * Publish data to RabbitMQ
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			
			mPublisher.publishMessage(vEBCPAYLOAD);
			
			}catch(Exception e) {
				
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}
		
		

	}

	// @Override
	public void CampaignLoadtransaction(Campaign pCampaign, Amount pAmount) throws Exception {

		CopyOnWriteArrayList<Transaction> expiredTransactions = new CopyOnWriteArrayList<Transaction>();
		// List<Transaction> expiredTransactions = new ArrayList<Transaction>();
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		if (pCampaign != null && pCampaign.getAmounts() != null) {

			if (pAmount.getCard() != null && pAmount.getBuCode() != null && pAmount.getBuType() != null
					&& pAmount.getCurrentAmount() != null && pAmount.getCurrentAmount().doubleValue() > 0) {
				Transaction vTransaction = mBefTransaction.create();
				vTransaction.setBalanceChange(pAmount.getCurrentAmount());
				vTransaction.setBuCode(pAmount.getBuCode());
				vTransaction.setBuType(pAmount.getBuType());
				vTransaction.setCountryCode(pAmount.getCard().getCountryCode());
				vTransaction.setSwiped("N");
				vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
				vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
				vTransaction.setCard(pAmount.getCard());
				vTransaction.setCampaign(pCampaign);
				vTransaction.setCardBalanceChange(pAmount.getCurrentAmount());
				vTransaction.setTransmissionDateTime(vTransactionEnvironment.getTransmissionDateTime());
				vTransaction.setInsufficientAmount(false);
				vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);
				vTransaction.setTransactionType(Constants.CAMPAIGN_LOAD);
				vTransaction.setReference(vTransactionEnvironment.getReference());
				vTransaction.setRequestedAmount(pAmount.getCurrentAmount());
				vTransaction.setSourceSystem("IPAY");
				// vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
				vTransaction.setSalesDay("1900-01-01");
				vTransaction.setReceipt(vTransactionEnvironment.getReceipt());
				vTransaction.setPointOfSale(vTransactionEnvironment.getPointOfSale());
				vTransaction.setCrossBorder(false);
				vTransaction.setCrossCurrency(false);
				vTransaction.setVoidedTransactionNo(0);
				vTransaction.setCancelled(false);
				if (pAmount.getCard().getCurrencyCode() != null && !pAmount.getCard().getCurrencyCode().isEmpty())
					vTransaction.setRequestedCurrencyCode(pAmount.getCard().getCurrencyCode());
				else
					vTransaction.setRequestedCurrencyCode("");
				vTransaction.setAmount(pAmount);
				expiredTransactions.add(vTransaction);

			}

			// }//End of for loop
		}

		if (expiredTransactions != null && !expiredTransactions.isEmpty()) {
			for (Transaction transaction : expiredTransactions) {
				saveTransaction(transaction);

				if (pCampaign.getReasonCode() > 0) {
					mReasonCodeTransaction = createDefaultReasonCodeTransaction();
					mReasonCodeTransaction.setTransactionId(transaction.getTransactionId());
					mReasonCodeTransaction.setReasonCodeId(pCampaign.getReasonCode());
					mReasonCodeTransaction.setCompanyName(pCampaign.getCompanyName());
					mReasonCodeTransaction.setCustomerType(pCampaign.getCustomerType());
					mBefReasonCodeTransaction.save(mReasonCodeTransaction);
				}
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createVoidTransaction()
	 */
	public void createVoidTransaction(Transaction pOriginal) throws TransactionException, ValueMissingException {

		// Check if load
		boolean vIsLoad = Constants.TRANSACTION_TYPE_CONSTANT_LOAD.equals(pOriginal.getTransactionType());

		// Check if redeem
		boolean vIsRedeem = Constants.TRANSACTION_TYPE_CONSTANT_REDEEM.equals(pOriginal.getTransactionType());

		if (!vIsLoad && !vIsRedeem) {
			throw new TransactionException("Invalid transation type for void, only load and redeem are supported");
		}

		requireTransactionEnvironment();

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Copy values from original
		mTransaction.assignFromMap(pOriginal.assignToMap());

		// Reset values
		mTransaction.setTransactionId(0);
		mTransaction.setEmployee(mTransactionEnvironment.getEmployee().trim());
		mTransaction.setTransactionNo(mTransactionEnvironment.getTransactionNo());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setVoidedTransactionNo(pOriginal.getTransactionNo());

		// PKE000000154974 fix

		mTransaction.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
		mTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

		// Set void data
		if (vIsLoad) {

			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_VOID_LOAD);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		} else if (vIsRedeem) {

			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_VOID_REDEEM);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);

		}

		saveTransaction(mTransaction);

		/*
		 * Publish data to RabbitMQ 
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			mCard = mTransaction.getCard();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createVoidTransaction()
	 */
	public void createVoidManualTransaction(Transaction pOriginal) throws TransactionException, ValueMissingException {

		// Check if load
		boolean vIsLoad = Constants.TRANSACTION_TYPE_CONSTANT_LOAD.equals(pOriginal.getTransactionType());

		// Check if redeem
		boolean vIsRedeem = Constants.TRANSACTION_TYPE_CONSTANT_REDEEM.equals(pOriginal.getTransactionType());

		if (!vIsLoad && !vIsRedeem) {
			throw new TransactionException("Invalid transation type for void, only load and redeem are supported");
		}

		requireTransactionEnvironment();

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Copy values from original
		mTransaction.assignFromMap(pOriginal.assignToMap());

		// Reset values
		mTransaction.setTransactionId(0);
		mTransaction.setEmployee(mTransactionEnvironment.getEmployee().trim());
		mTransaction.setTransactionNo(mTransactionEnvironment.getTransactionNo());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setVoidedTransactionNo(pOriginal.getTransactionNo());

		// PKE000000154974 fix

		mTransaction.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
		mTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

		// Set void data
		if (vIsLoad) {

			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_VOID_LOAD);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		} else if (vIsRedeem) {

			mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_VOID_REDEEM);
			mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);

		}

		saveTransaction(mTransaction);

		/*
		 * Publish data to RabbitMQ 
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			mCard = mTransaction.getCard();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			}catch(Exception e) {
				
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#
	 * createBonusLoadTransaction(com.ikea.ebccardpay1.cardpayment.be.Bonus)
	 */
	public void createBonusLoadTransaction(Bonus pBonus) throws TransactionException, ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pBonus.getBonusAmount());

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Load values
		mTransaction.setBalanceChange(pBonus.getBonusAmount());
		// Same as balance change since cross currency is only applicable for redeem
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pBonus.getBonusAmount());
		mTransaction.setRequestedCurrencyCode(pBonus.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_BONUS_LOAD);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);

		saveTransaction(mTransaction);
		
		/*
		 * Publish data to RabbitMQ 
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			
			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

		if (pBonus.getReasonCodeId() > 0) {
			mReasonCodeTransaction = createDefaultReasonCodeTransaction();
			mReasonCodeTransaction.setTransactionId(mTransaction.getTransactionId());
			mReasonCodeTransaction.setReasonCodeId(pBonus.getReasonCodeId());
			mBefReasonCodeTransaction.save(mReasonCodeTransaction);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#createMassLoadTransaction
	 * (com.ikea.ebccardpay1.cardpayment.be.MassLoad)
	 */
	public void createMassLoadTransaction(MassLoad pMassLoad) throws TransactionException, ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pMassLoad.getAmount());
		requireMassLoad();

		// Create transaction
		mTransaction = createDefaultTransaction();
		mTransaction.setSalesDay("1900-01-01");

		// Load values
		mTransaction.setBalanceChange(pMassLoad.getAmount());
		// Same as balance change since cross currency is only applicable for redeem
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pMassLoad.getAmount());
		mTransaction.setRequestedCurrencyCode(pMassLoad.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_MASS_LOAD);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);

		saveTransaction(mTransaction);

		if (pMassLoad.getReasonCode() > 0) {

			mReasonCodeTransaction = createDefaultReasonCodeTransaction();
			mReasonCodeTransaction.setTransactionId(mTransaction.getTransactionId());
			mReasonCodeTransaction.setReasonCodeId(pMassLoad.getReasonCode());
			mReasonCodeTransaction.setCompanyName(pMassLoad.getCompanyName());
			mReasonCodeTransaction.setCustomerType(pMassLoad.getCustomerType());
			mBefReasonCodeTransaction.save(mReasonCodeTransaction);
		}
	}

	private ReasonCodeTransaction createDefaultReasonCodeTransaction() throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();

		// Create reasoncodetransaction
		ReasonCodeTransaction vReasonCodeTransaction = mBefReasonCodeTransaction.create();

		vReasonCodeTransaction.setTransactionId(1234);
		// vReasonCodeTransaction.setReasonCodeId(0);

		// TODO Auto-generated method stub
		return vReasonCodeTransaction;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#
	 * createWithdrawMassLoadTransaction(com.ikea.ebccardpay1.cardpayment.be.
	 * MassLoad) - modified by anagc 8 mar 2016
	 */
	public void createWithdrawMassLoadTransaction(MassLoad pMassLoad)
			throws TransactionException, ValueMissingException {

		requireMassLoad();
		requireCard();
		requireAmount();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pMassLoad.getAmount());

		// Create transaction
		mTransaction = createDefaultTransaction();
		if (pMassLoad.getReleasedDateTime() == null) {

			mTransaction.setSalesDay("1900-01-01");
		}

		// Make a debit transaction on the remaining amount (even if it is zero).
		mTransaction.setBalanceChange(calculateBalance(pMassLoad, mCard));
		// Same as balance change since cross currency is only applicable for redeem
		// Card and transaction currency will never be different for mass loads.
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pMassLoad.getAmount());
		if (Amounts.isLess(calculateBalance(pMassLoad, mCard), pMassLoad.getAmount())) {
			mTransaction.setInsufficientAmount(true);
		}
		mTransaction.setRequestedCurrencyCode(pMassLoad.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_WITHDRAW_MASS_LOAD);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		saveTransaction(mTransaction);

		/*
		 * Added ebcpayload in the list to process
		 */
		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);
			mEBCPayloadList.add(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransaction#cancelTransaction()
	 */
	public void cancelTransaction() throws ValueMissingException {

		requireTransaction();

		// Set financial type to none so this transaction will not be included in KPI
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_NONE);
		mTransaction.setCancelled(true);

		saveTransaction(mTransaction);
	}

	// ---------- Internal methods, must be protected so unit tests can access them
	// ----------

	/**
	 * Create a transaction that records a load of an amount
	 * 
	 */
	protected Transaction createDefaultTransaction() throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();

		// Create transaction
		Transaction vTransaction = mBefTransaction.create();

		vTransaction.setSourceSystem(mTransactionEnvironment.getSourceSystem());
		vTransaction.setTransmissionDateTime(mTransactionEnvironment.getTransmissionDateTime());
		vTransaction.setCancelled(false);
		vTransaction.setBuType(mBusinessUnitEnvironment.getBuType());
		vTransaction.setBuCode(mBusinessUnitEnvironment.getBuCode());
		vTransaction.setEmployee(mTransactionEnvironment.getEmployee().trim());
		vTransaction.setCountryCode(mBusinessUnitEnvironment.getCountryCode());
		vTransaction.setSwiped(mTransactionEnvironment.getSwiped());
		vTransaction.setTransactionNo(mTransactionEnvironment.getTransactionNo());
		vTransaction.setPointOfSale(mTransactionEnvironment.getPointOfSale());
		vTransaction.setReceipt(mTransactionEnvironment.getReceipt());

		vTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());

		if (pointOfSaleContext()) {
			// Use setCard and not connectCard - we do not want to read all transactions
			// into a set before inserting the new one if we do not have to.
			vTransaction.setCard(mCard);
		} else {
			vTransaction.connectCard(mCard);
		}
		if (mAmount != null) {
			vTransaction.setAmount(mAmount);
		}

		if (mMassLoad != null) {
			vTransaction.setMassLoad(mMassLoad);
		}

		mCard.setLastTransactionDateTime(vTransaction.getCreatedDateTime());

		return vTransaction;
	}

	/**
	 * Are we processing a request from a POS System? Some operations like cancel
	 * unacknowledged and migarte cards are only valid if we come from a POS.
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	protected boolean pointOfSaleContext() {
		return mTransactionEnvironment != null && mConstants.isPointOfSale(mTransactionEnvironment.getSourceSystem());
	}

	/**
	 * 
	 * @param pTransaction
	 */
	protected void saveTransaction(Transaction pTransaction) {

		if (mCategory.isInfoEnabled()) {
			mCategory.debug("Creating transaction no " + pTransaction.getTransactionNo() + " "
					+ pTransaction.getTransactionType() + " " + pTransaction.getBalanceChange());
		}
		// We will explicitly call save here since we are not using connect due to
		// performance reasons.
		mBefTransaction.save(pTransaction);
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireAmountIfNotZero(BigDecimal pAmount) throws ValueMissingException {
		if (pAmount != null && !Amounts.isZero(pAmount) && mAmount == null)
			throw new ValueMissingException(
					"Tried to use BecTransaction without required Amount. Need to specify Amount if not a zero transaction.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null) {
			mCategory.debug("Tried to use BecTransaction without required Card.");

			throw new ValueMissingException("Tried to use BecTransaction without required Card.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireAmount() throws ValueMissingException {
		if (mAmount == null) {
			mCategory.debug("Tried to use BecTransaction without required Amount.");
			throw new ValueMissingException("Tried to use BecTransaction without required Amount.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireMassLoad() throws ValueMissingException {
		if (mMassLoad == null)
			throw new ValueMissingException("Tried to use BecTransaction without required MassLoad.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransaction() throws ValueMissingException {
		if (mTransaction == null)
			throw new ValueMissingException("Tried to use BecTransaction without required Transaction.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment() throws ValueMissingException {
		if (mBusinessUnitEnvironment == null) {
			mCategory.debug("Tried to use BecTransaction without required Business Unit Environment.");
			throw new ValueMissingException("Tried to use BecTransaction without required Business Unit Environment.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment() throws ValueMissingException {
		if (mTransactionEnvironment == null) {
			mCategory.debug("Tried to use BecTransaction without required Transaction Environment.");

			throw new ValueMissingException("Tried to use BecTransaction without required Transaction Environment.");
		}
	}

	public void createMultipleSingleLoadTransaction(Amount pAmount, MultipleSingleLoad pMultipleSingleLoad)
			throws ValueMissingException, IkeaException {

		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		// Create transaction
		Transaction vTransaction = mBefTransaction.create();

		vTransaction.setSourceSystem(vTransactionEnvironment.getSourceSystem());
		vTransaction.setTransmissionDateTime(vTransactionEnvironment.getTransmissionDateTime());
		vTransaction.setCancelled(false);
		vTransaction.setBuType(pAmount.getMultipleSingleLoad().getBuType());
		vTransaction.setBuCode(pAmount.getMultipleSingleLoad().getBuCode());
		vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
		vTransaction.setCountryCode(pAmount.getMultipleSingleLoad().getCountryCode());
		vTransaction.setSwiped("N");
		vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
		vTransaction.setReceipt(vTransactionEnvironment.getReceipt());
		
		//PAYM-8320 - iPay: Apply correct sales date on cards loaded using single load.
		
		//vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
		
		vTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
		
		vTransaction.connectCard(pAmount.getCard());
		pAmount.getCard().setLastTransactionDateTime(vTransaction.getCreatedDateTime());

		vTransaction.setAmount(pAmount);

		vTransaction.setBalanceChange(pAmount.getCurrentAmount());
		vTransaction.setCardBalanceChange(vTransaction.getBalanceChange());
		vTransaction.setReference(vTransactionEnvironment.getReference());
		vTransaction.setRequestedAmount(pAmount.getCurrentAmount());
		vTransaction.setRequestedCurrencyCode(pAmount.getMultipleSingleLoad().getCurrencyCode());

		vTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_MULTIPLE_SINGLE_LOAD);
		vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_CREDIT);

		saveTransaction(vTransaction);
		
		/*
		 * Added ebcpayload in the list to process
		 */
		if (vTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			mCard=pAmount.getCard();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(vTransaction.getTransactionType());
			if (null != vTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(vTransaction.getTransmissionDateTime()));

			data.setTransactionId(vTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);
			mEBCPayloadList.add(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}


		if (pMultipleSingleLoad.getReasonCode() > 0) {

			ReasonCodeTransaction vReasonCodeTransaction = mBefReasonCodeTransaction.create();

			vReasonCodeTransaction.setTransactionId(vTransaction.getTransactionId());
			vReasonCodeTransaction.setReasonCodeId(pMultipleSingleLoad.getReasonCode());
			vReasonCodeTransaction.setCompanyName(pMultipleSingleLoad.getCompanyName());
			vReasonCodeTransaction.setCustomerType(pMultipleSingleLoad.getCustomerType());
			mBefReasonCodeTransaction.save(vReasonCodeTransaction);
		}

	}

	/**
	 * @return
	 * @throws Exception added on 8 mar 2016
	 */

	protected BigDecimal calculateBalance(MassLoad pMassLoad, Card pCard) {

		if (pMassLoad != null) {
			for (Iterator<Amount> i = pCard.getAmounts().iterator(); i.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (vAmount != null && pMassLoad.equals(vAmount.getMassLoad())) {

					return vAmount.getCurrentAmount();
				} else
					return pMassLoad.getAmount();
			}
		}

		return null;
	}

	// @Override
	public void createExpiredTransaction(Campaign pCampaign, BigDecimal pBalanceChange)
			throws TransactionException, ValueMissingException {
		// TODO Auto-generated method stub
		mCampaign = pCampaign;
		requireCampaign();
		requireCard();
		requireAmount();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pCampaign.getAmount());

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Make a debit transaction on the remaining amount (even if it is zero).
		mTransaction.setBalanceChange(pBalanceChange);
		// Same as balance change since cross currency is only applicable for redeem
		// Card and transaction currency will never be different for mass loads.
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pCampaign.getAmount());
		mTransaction.setEmployee("EXPIREJOB");
		mTransaction.setCampaign(pCampaign);
		if (Amounts.isLess(pBalanceChange, pCampaign.getAmount())) {
			mTransaction.setInsufficientAmount(true);
		}
		mTransaction.setRequestedCurrencyCode(pCampaign.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CAMPAIGN);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		saveTransaction(mTransaction);
		
		
	}

	private void requireCampaign() throws ValueMissingException {
		// TODO Auto-generated method stub
		if (mCampaign == null) {
			mCategory.debug("Tried to use BecTransaction without required Campaign.");
			throw new ValueMissingException("Tried to use BecTransaction without required Campaign.");
		}
	}

	// @Override
	public void createRedeemTransaction(BigDecimal pTransactionBalanceChange, BigDecimal pCardBalanceChange,
			boolean insufficientAmount, Amount pAmount, Card pCard, BigDecimal vCurrentAmount)
			throws ValueMissingException {

		requireCard();
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
		Transaction vTransaction = mBefTransaction.create();
		vTransaction.setBuCode(pAmount.getBuCode());
		vTransaction.setBuType(pAmount.getBuType());
		vTransaction.setCountryCode(pCard.getCountryCode());
		vTransaction.setSwiped("N");
		// vTransaction.setTransactionNo(0);
		vTransaction.setCard(pCard);
		vTransaction.setTransmissionDateTime(new Date());
		vTransaction.setInsufficientAmount(false);
		vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
		vTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
		vTransaction.setSourceSystem("IPAY");
		vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
		vTransaction.setCrossBorder(false);
		vTransaction.setCrossCurrency(false);
		vTransaction.setVoidedTransactionNo(0);
		vTransaction.setCancelled(false);
		if (pCard.getCurrencyCode() != null && !pCard.getCurrencyCode().isEmpty())
			vTransaction.setRequestedCurrencyCode(pCard.getCurrencyCode());
		else
			vTransaction.setRequestedCurrencyCode("");

		vTransaction.setBalanceChange(vCurrentAmount);
		vTransaction.setCardBalanceChange(vCurrentAmount);
		pAmount.setCurrentAmount(new BigDecimal(0));

		vTransaction.setRequestedAmount(vCurrentAmount);
		vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
		vTransaction.setEmployee(Constants.EXPIRE_CARD_JOB);
		vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
		vTransaction.setReference(vTransactionEnvironment.getReference());

		vTransaction.setCreatedDateTime(new Date());
		vTransaction.setAmount(pAmount);
		saveTransaction(vTransaction);

	}

	public void createWithdrawnTransaction(Campaign pCampaign, BigDecimal pBalanceChange)
			throws TransactionException, ValueMissingException {
		// TODO Auto-generated method stub
		mCampaign = pCampaign;
		requireCampaign();
		requireCard();
		requireAmount();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		requireAmountIfNotZero(pCampaign.getAmount());

		// Create transaction
		mTransaction = createDefaultTransaction();

		// Make a debit transaction on the remaining amount (even if it is zero).
		mTransaction.setBalanceChange(pBalanceChange);
		// Same as balance change since cross currency is only applicable for redeem
		// Card and transaction currency will never be different for mass loads.
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pCampaign.getAmount());
		// mTransaction.setEmployee("EXP");
		mTransaction.setCampaign(pCampaign);
		if (Amounts.isLess(pBalanceChange, pCampaign.getAmount())) {
			mTransaction.setInsufficientAmount(true);
		}
		mTransaction.setRequestedCurrencyCode(pCampaign.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_WITHDRAWN_CAMPAIGN_LOAD);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		saveTransaction(mTransaction);
	}

	// @Override
	public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction, Campaign pCampaign)
			throws TransactionException, ValueMissingException {

		mTransaction = pTransaction;
		mTransaction.setSalesDay(pCampaign.getIntervalStartDate().toString());
		mTransaction.setUpdatedDateTime(new Date());
		
		/*
		 * Publish data to RabbitMQ 
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			mCard = mTransaction.getCard();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}

	}

	// @Override
	public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction, Campaign pCampaign)
			throws TransactionException, ValueMissingException {

		mTransaction = pTransaction;
		mTransaction.setSalesDay("1900-01-01");
		mTransaction.setUpdatedDateTime(new Date());
		
		/*
		 * Publish data to RabbitMQ 
		 */

		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			mCard = mTransaction.getCard();
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();
			
			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));

			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);

			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}


	}

	// @Override
	public void CampaignDebiTransaction(Campaign pCampaign, Amount pAmount, String sales_Day) throws Exception {

		CopyOnWriteArrayList<Transaction> expiredTransactions = new CopyOnWriteArrayList<Transaction>();
		// List<Transaction> expiredTransactions = new ArrayList<Transaction>();
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		if (pAmount.getCard() != null && pAmount.getBuCode() != null && pAmount.getBuType() != null
				&& pAmount.getCurrentAmount() != null && pAmount.getCurrentAmount().doubleValue() > 0) {
			Transaction vTransaction = mBefTransaction.create();
			vTransaction.setBalanceChange(pAmount.getCurrentAmount());
			vTransaction.setBuCode(pAmount.getBuCode());
			vTransaction.setBuType(pAmount.getBuType());
			vTransaction.setCountryCode(pAmount.getCard().getCountryCode());
			vTransaction.setSwiped("N");
			vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
			vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
			vTransaction.setCard(pAmount.getCard());
			vTransaction.setCampaign(pCampaign);
			vTransaction.setCardBalanceChange(pAmount.getCurrentAmount());
			vTransaction.setTransmissionDateTime(vTransactionEnvironment.getTransmissionDateTime());
			vTransaction.setInsufficientAmount(false);
			vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
			vTransaction.setTransactionType(Constants.WITHDRAW_CAMPAIGN_LOAD);
			vTransaction.setReference(vTransactionEnvironment.getReference());
			// vTransaction.setRequestedAmount(amount.getCurrentAmount());
			vTransaction.setRequestedAmount(pCampaign.getAmount());
			vTransaction.setSourceSystem("IPAY");
			vTransaction.setSalesDay(sales_Day);
			vTransaction.setReceipt(vTransactionEnvironment.getReceipt());
			vTransaction.setPointOfSale(vTransactionEnvironment.getPointOfSale());
			vTransaction.setCrossBorder(false);
			vTransaction.setCrossCurrency(false);
			vTransaction.setVoidedTransactionNo(0);
			vTransaction.setCancelled(false);
			if (pAmount.getCard().getCurrencyCode() != null && !pAmount.getCard().getCurrencyCode().isEmpty())
				vTransaction.setRequestedCurrencyCode(pAmount.getCard().getCurrencyCode());
			else
				vTransaction.setRequestedCurrencyCode("");
			pAmount.setCurrentAmount(new BigDecimal(0));
			vTransaction.setAmount(pAmount);

			expiredTransactions.add(vTransaction);

		}

		if (expiredTransactions != null && !expiredTransactions.isEmpty()) {
			for (Transaction transaction : expiredTransactions) {
				saveTransaction(transaction);
				
				/*
				 * Publish data to RabbitMQ
				 */

				if (transaction.getTransactionId() != 0L) {
					try {
					Data data = new Data();
					EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
					mCard = pAmount.getCard();
					String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
							+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

					String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
							+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
							+ mCard.getCardNumber().getCheckDigit();

					data.setAccountNumber(pCardNumberString);
					data.setAccountNumberEnc(cardNumberEnc);
					data.setTransactionType(transaction.getTransactionType());
					if (null != transaction.getTransmissionDateTime())
						data.setTransactionDateTime(formatter.format(transaction.getTransmissionDateTime()));
					
					data.setTransactionId(transaction.getTransactionId());
					vEBCPAYLOAD.setData(data);

					mPublisher.publishMessage(vEBCPAYLOAD);
					} catch (Exception e) {
						mCategory.info("Exception in EBCPayload code block.");
						mCategory.info(e.getMessage());
					}
				}
			}
		}

	}

	public void updateMassLoadedTransactions(Transaction pTransaction)
			throws TransactionException, ValueMissingException {

		mTransaction = pTransaction;
		mTransaction.setSalesDay(mBusinessUnitEnvironment.getSalesDay());
		mTransaction.setUpdatedDateTime(new Date());

		/*
		 * Added ebcpayload in the list to process
		 */
		if ("RELEASED".equalsIgnoreCase(mTransaction.getMassLoad().getMassLoadState())) {
			if (mTransaction.getTransactionId() != 0L) {
				try {
				Data data = new Data();
				EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
				mCard = mTransaction.getCard();
				String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
						+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

				String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
						+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
						+ mCard.getCardNumber().getCheckDigit();

				data.setAccountNumber(pCardNumberString);
				data.setAccountNumberEnc(cardNumberEnc);
				data.setTransactionType(mTransaction.getTransactionType());
				if (null != mTransaction.getTransmissionDateTime())
					data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));
				
				data.setTransactionId(mTransaction.getTransactionId());
				vEBCPAYLOAD.setData(data);
				mEBCPayloadList.add(vEBCPAYLOAD);
				} catch (Exception e) {
					mCategory.info("Exception in EBCPayload code block.");
					mCategory.info(e.getMessage());
				}
			}
		}

	}

	public void createWithdrawnMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pOriginalAmount,
			BigDecimal pBigDecimal) throws TransactionException, ValueMissingException {

		requireCard();
		requireAmount();
		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();

		mTransaction = createDefaultTransaction();

		// Make a debit transaction on the remaining amount (even if it is zero).
		mTransaction.setBalanceChange(pBigDecimal);
		// Same as balance change since cross currency is only applicable for redeem
		// Card and transaction currency will never be different for mass loads.
		mTransaction.setCardBalanceChange(mTransaction.getBalanceChange());
		mTransaction.setReference(mTransactionEnvironment.getReference());
		mTransaction.setRequestedAmount(pOriginalAmount);

		if (Amounts.isLess(pBigDecimal, pMultipleSingleLoad.getInitiatedAmount())) {
			mTransaction.setInsufficientAmount(true);
		}
		mTransaction.setRequestedCurrencyCode(pMultipleSingleLoad.getCurrencyCode());

		if (!mCard.getCountryCode().equals(mBusinessUnitEnvironment.getCountryCode())) {
			mTransaction.setCrossBorder(true);
		}
		mTransaction.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_WITHDRAWN_MULTIPLE_SINGLE_LOAD);
		mTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);

		saveTransaction(mTransaction);

		/*
		 * Publish data to RabbitMQ for WithdrawnMultipleSingleLoad
		 */
		if (mTransaction.getTransactionId() != 0L) {
			try {
			Data data = new Data();
			EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
			
			String cardNumberEnc = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mCard.getCardNumber().getAccountNumberEnc() + mCard.getCardNumber().getCheckDigit();

			String pCardNumberString = mCard.getCardNumber().getIssuer() + mCard.getCardNumber().getCardTypeDigit()
					+ mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
					+ mCard.getCardNumber().getCheckDigit();

			data.setAccountNumber(pCardNumberString);
			data.setAccountNumberEnc(cardNumberEnc);
			data.setTransactionType(mTransaction.getTransactionType());
			if (null != mTransaction.getTransmissionDateTime())
				data.setTransactionDateTime(formatter.format(mTransaction.getTransmissionDateTime()));
			
			data.setTransactionId(mTransaction.getTransactionId());
			vEBCPAYLOAD.setData(data);
			mPublisher.publishMessage(vEBCPAYLOAD);
			} catch (Exception e) {
				mCategory.info("Exception in EBCPayload code block.");
				mCategory.info(e.getMessage());
			}
		}
	}
	
	@Override
	public void publishTransactions() {
		if(!mEBCPayloadList.isEmpty()) {
			mPublisher.publishMessage(mEBCPayloadList);
			mEBCPayloadList.clear();
		}
	}


}
