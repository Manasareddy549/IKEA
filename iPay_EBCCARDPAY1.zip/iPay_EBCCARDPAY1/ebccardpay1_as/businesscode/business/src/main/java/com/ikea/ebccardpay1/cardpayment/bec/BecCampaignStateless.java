/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignValidity;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecCampaignStateless {

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCampaign getVoCampaign(Campaign pCampaign) throws ValueMissingException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCampaignValidity getVoCampaignValidity(Campaign pCampaign)
		throws ValueMissingException;

	/**
	 * @param vVoCampaign
	 * @throws IkeaException
	 */
	public void manage(VoCampaign vVoCampaign)
		throws
			IkeaException,
			ValueMissingException,
			RangeNotFoundException,
			CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void lock(Campaign pCampaign) throws ValueMissingException, CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void unlock(Campaign pCampaign) throws ValueMissingException, CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void authorize(Campaign pCampaign)
		throws
			ValueMissingException,
			CampaignException,
			FourEyesException,
			IkeaException;

	/**
	 * @throws ValueMissingException
	 */
	public void withdraw(Campaign pCampaign)
		throws ValueMissingException, CampaignException, IkeaException;

	/**
	 * @throws ValueMissingException
	 */
	public int process(Long pCampaignId)
		throws ValueMissingException, CampaignException, IkeaException;

}
