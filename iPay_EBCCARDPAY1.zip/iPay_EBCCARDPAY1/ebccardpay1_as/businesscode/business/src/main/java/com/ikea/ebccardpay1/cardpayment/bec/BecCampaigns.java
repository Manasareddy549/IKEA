/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecCampaigns {

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecCampaigns init(UserEnvironment pUserEnvironment);

	/**
	 * @return
	 * @throws IkeaException
	 */
	public List<VoCampaign> findCurrentCampaigns()
		throws IkeaException, ValueMissingException;

	/**
	 * @return
	 */
	public List<Campaign> findUnprocessedCampaigns();

	/**
	 * @param pVoCampaignSearch
	 * @return
	 * @throws ValueMissingException
	 */
	public List<VoCampaign> findCampaigns(VoCampaignSearch pVoCampaignSearch)
		throws ValueMissingException;
	
	
}
