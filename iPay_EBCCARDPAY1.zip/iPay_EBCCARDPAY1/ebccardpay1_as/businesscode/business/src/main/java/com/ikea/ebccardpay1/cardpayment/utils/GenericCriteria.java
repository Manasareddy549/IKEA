package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.ResultTransformer;

@SuppressWarnings("unchecked")
public class GenericCriteria<T> implements Criteria{
    Criteria mCriteria;

    public GenericCriteria(Criteria pCriteria){
    	mCriteria = pCriteria;
    }
    
	public Criteria add(Criterion criterion) {
		return mCriteria.add(criterion);
	}

	public Criteria addOrder(Order order) {
		return mCriteria.addOrder(order);
	}

	public Criteria createAlias(String associationPath, String alias,
			int joinType) throws HibernateException {
		return mCriteria.createAlias(associationPath, alias, joinType);
	}

	public Criteria createAlias(String associationPath, String alias)
			throws HibernateException {
		return mCriteria.createAlias(associationPath, alias);
	}

	public Criteria createCriteria(String associationPath, int joinType)
			throws HibernateException {
		return mCriteria.createCriteria(associationPath, joinType);
	}

	public Criteria createCriteria(String associationPath, String alias,
			int joinType) throws HibernateException {
		return mCriteria.createCriteria(associationPath, alias, joinType);
	}

	public Criteria createCriteria(String associationPath, String alias)
			throws HibernateException {
		return mCriteria.createCriteria(associationPath, alias);
	}

	public Criteria createCriteria(String associationPath)
			throws HibernateException {
		return mCriteria.createCriteria(associationPath);
	}

	public String getAlias() {
		return mCriteria.getAlias();
	}

	public List<T> list() throws HibernateException {
		return mCriteria.list();
	}

	public ScrollableResults scroll() throws HibernateException {
		return mCriteria.scroll();
	}

	public ScrollableResults scroll(ScrollMode scrollMode)
			throws HibernateException {
		return mCriteria.scroll(scrollMode);
	}

	public Criteria setCacheable(boolean cacheable) {
		return mCriteria.setCacheable(cacheable);
	}

	public Criteria setCacheMode(CacheMode cacheMode) {
		return mCriteria.setCacheMode(cacheMode);
	}

	public Criteria setCacheRegion(String cacheRegion) {
		return mCriteria.setCacheRegion(cacheRegion);
	}

	public Criteria setComment(String comment) {
		return mCriteria.setComment(comment);
	}

	public Criteria setFetchMode(String associationPath, FetchMode mode)
			throws HibernateException {
		return mCriteria.setFetchMode(associationPath, mode);
	}

	public Criteria setFetchSize(int fetchSize) {
		return mCriteria.setFetchSize(fetchSize);
	}

	public Criteria setFirstResult(int firstResult) {
		return mCriteria.setFirstResult(firstResult);
	}

	public Criteria setFlushMode(FlushMode flushMode) {
		return mCriteria.setFlushMode(flushMode);
	}

	public Criteria setLockMode(LockMode lockMode) {
		return mCriteria.setLockMode(lockMode);
	}

	public Criteria setLockMode(String alias, LockMode lockMode) {
		return mCriteria.setLockMode(alias, lockMode);
	}

	public Criteria setMaxResults(int maxResults) {
		return mCriteria.setMaxResults(maxResults);
	}

	public Criteria setProjection(Projection projection) {
		return mCriteria.setProjection(projection);
	}

	public Criteria setResultTransformer(ResultTransformer resultTransformer) {
		return mCriteria.setResultTransformer(resultTransformer);
	}

	public Criteria setTimeout(int timeout) {
		return mCriteria.setTimeout(timeout);
	}

	public T uniqueResult() throws HibernateException {
		return (T) mCriteria.uniqueResult();
	}
 ////////////////////

	//@Override
	public Criteria addQueryHint(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createAlias(String arg0, String arg1, JoinType arg2) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createAlias(String arg0, String arg1, JoinType arg2, Criterion arg3) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createAlias(String arg0, String arg1, int arg2, Criterion arg3) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createCriteria(String arg0, JoinType arg1) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createCriteria(String arg0, String arg1, JoinType arg2) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createCriteria(String arg0, String arg1, JoinType arg2, Criterion arg3) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Criteria createCriteria(String arg0, String arg1, int arg2, Criterion arg3) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public boolean isReadOnly() {
		// TODO Auto-generated method stub
		return false;
	}

	//@Override
	public boolean isReadOnlyInitialized() {
		// TODO Auto-generated method stub
		return false;
	}

	//@Override
	public Criteria setReadOnly(boolean arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}

