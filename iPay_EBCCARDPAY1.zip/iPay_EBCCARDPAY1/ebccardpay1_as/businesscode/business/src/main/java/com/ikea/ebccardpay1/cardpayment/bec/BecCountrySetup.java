/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CountrySetup;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountrySetup;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecCountrySetup {

	/**
	 * 
	 * @param pCountrySetupId
	 * @return
	 */
	public BecCountrySetup init(long pCountrySetupId);

	/**
	 * 
	 * @param pCountrySetup
	 * @return
	 */
	public BecCountrySetup init(CountrySetup pCountrySetup);

	/**
	 * 
	 * @return
	 */
	public CountrySetup getCountrySetup();

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCountrySetup getVoCountrySetup() throws ValueMissingException;

	/**
	 * @param vVoBonus
	 * @throws IkeaException
	 */
	public void manage(VoCountrySetup pVoCountrySetup)
		throws IkeaException, ValueMissingException, CountrySetupException;

}
