package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

public class MultipleSingleLoadException extends CardPayException {

	/**
	 * Created in 3.9 release, Defect-IKEA01072486 -anagc
	 */

	public MultipleSingleLoadException() {
		super();
	}
	public MultipleSingleLoadException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidMassLoad();
	}
}

