/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;


import com.ikea.mdsd.ValueObjects;
import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefCampaign;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefRange;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignException;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignLimitationNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignWrongStateException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNumberNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.CheckDigits;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.UnitsCacheImpl;
import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;

import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRangeRef;
import com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.ebcframework.spring.BeanFactory;
import com.ikea.ebccardpay1.cardpayment.exception.BlockedCardException;
import com.ikea.ebccardpay1.cardpayment.exception.ExpiredCardException;
import com.ikea.ebccardpay1.cardpayment.exception.IllegalCardStateException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardException;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.ikea.ebccardpay1.client.bs.BsProcessCampaign;
import com.ikea.ebccardpay1.client.vo.VoCampaignKey;

/**
 * @author anms
 */
public class BecCampaignImpl implements BecCampaign,InitializingBean{

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecCampaignImpl.class);

	// Dependencies injected at creation of this BEC
	private BefCampaign mBefCampaign;
	private BefAmount mBefAmount;
	private BefCardNumber mBefCardNumber;
	private TimeSource mTimeSource;
	private EbcEnvironment mEbcEnvironment;
	private BecFactory mBecFactory;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	// Entities that this BEC operates on
	private Campaign mCampaign;

	// Related Bec's that this Bec delegates work to
	private BecCard mBecCard = null;
	private BecRange mBecRange = null;
	private BecCampaignLimitation mBecCampaignLimitation = null;
	private BecCardNumber mBecCardNumber;
	private BefRange mBefRange;
	//    @Autowired
	//    private BsExecuter bsExecuter;

	private BsContext mBsContext;

	private BefTransaction mBefTransaction = null;

	private UtilsFactory mUtilsFactory=null;
	
	private EncryptionDecryption mEncryptionDecryption = null;

	//private BecTransaction mBecTransaction;

	public static CopyOnWriteArrayList<Campaign> crdlist = null;

	private BefCard mBefCard;

	/**
	 *
	 */
	public BecCampaignImpl(BefCampaign pBefCampaign, BefAmount pBefAmount,
			BefCardNumber pBefCardNumber, TimeSource pTimeSource,
			EbcEnvironment pEbcEnvironment, BecCard pBecCard,
			BecRange pBecRange, BecCampaignLimitation pBecCampaignLimitation, BecCardNumber pBecCardNumber, BsContext pBsContext ,
			BefTransaction pBefTransaction,UtilsFactory pUtilsFactory,BefRange pBefRange,BecFactory pBecFactory,
			BefCard pBefCard) {

		super();



		mBefCampaign = pBefCampaign;
		mBefAmount = pBefAmount;
		mBefCardNumber = pBefCardNumber;
		mTimeSource = pTimeSource;
		mEbcEnvironment = pEbcEnvironment;
		mBecCard = pBecCard;
		mBecRange = pBecRange;
		mBecCampaignLimitation = pBecCampaignLimitation;
		mBecCardNumber = pBecCardNumber;
		mBsContext = pBsContext;
		mBefTransaction = pBefTransaction;
		mUtilsFactory = pUtilsFactory;
		mBefRange = pBefRange;
		mBecFactory=pBecFactory;
		mBefCard = pBefCard;

	}

	void validate() {
		Validate.notNull(mBefCampaign);
		Validate.notNull(mBefAmount);
		Validate.notNull(mBefCardNumber);
		Validate.notNull(mTimeSource);
		Validate.notNull(mEbcEnvironment);
		Validate.notNull(mBecCard);
		Validate.notNull(mBecRange);
		Validate.notNull(mBecCampaignLimitation);
		Validate.notNull(mBecCardNumber);
		Validate.notNull(mBsContext);
		Validate.notNull(mBefTransaction);
		Validate.notNull(mUtilsFactory);
		Validate.notNull(mBefRange);
		Validate.notNull(mBecFactory);
		Validate.notNull(mBefCard);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#init(long)
	 */
	public BecCampaign init(long pCampaignId) {
		mCampaign = mBefCampaign.findByPrimaryKey(pCampaignId);
		return this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Campaign)
	 */
	public BecCampaign init(Campaign pCampaign) {
		mCampaign = pCampaign;
		return this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#init(com.ikea.ebccardpay1
	 * .cardpayment.utils.UserEnvironment)
	 */
	public BecCampaign init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#getCampaign()
	 */
	public Campaign getCampaign() throws ValueMissingException {
		requireCampaign();
		return mCampaign;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#getVoCampaign()
	 */
	public VoCampaign getVoCampaign() throws ValueMissingException {

		requireCampaign();

		if (mCampaign.isBusinessEntityDeleted()) {
			return null;
		}

		VoCampaign vVoCampaign = new VoCampaign();
		assignToVoCampaign(vVoCampaign, mCampaign);

		mCategory.debug("Added campaign " + vVoCampaign.getCampaignId() + " "
				+ vVoCampaign.getName());

		// Add ranges
		vVoCampaign.setVoCardRangeRefList(new ArrayList<VoCardRangeRef>());
		Set<Range> vRanges = mCampaign.getRanges();
		if (vRanges != null) {

			for (Iterator<Range> i = vRanges.iterator(); i.hasNext(); ) {
				Range vRange = (Range) i.next();
				VoCardRangeRef vVoCardRangeRef = new VoCardRangeRef();
				ValueObjects.assignToValueObject(vVoCardRangeRef, vRange);
				vVoCampaign.getVoCardRangeRefList().add(
						vVoCardRangeRef);
				if(vVoCardRangeRef.getImportState().equals(Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE))
				{
					try{
						String[] fromTo=vRange.getHeader().split(";");
						vVoCampaign.setFromCardNumberString(fromTo[1]);
						vVoCampaign.setUntilCardNumberString(fromTo[2]);
					}
					catch(Exception e)
					{
						mCategory.debug("No header Found " + vVoCampaign.getCampaignId() + " "
								+ vVoCampaign.getName());
					}
				}
				mCategory.debug("Added range " + vVoCardRangeRef.getName());
			}
		}
		// Add campaign limitaions (BUs)
		vVoCampaign.setVoCampaignLimitationList(mCampaign.getVoCampaignLimitationList());

		Map<BigDecimal, BigDecimal> vMap = mBefAmount
				.usageByCampaign(mCampaign);
		vVoCampaign.setUsageAmount(vMap.get("usageAmount"));
		vVoCampaign.setTotalAmount(vMap.get("totalAmount"));

		return vVoCampaign;
	}


	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#manage(com.ikea.ebccardpay1
	 * .cardpayment.vo.VoCampaign)
	 */
	public void manage(VoCampaign pVoCampaign) throws IkeaException,
	ValueMissingException, RangeNotFoundException, CampaignException {

		if (Constants.OBJECT_STATE_NEW.equals(pVoCampaign.getObjectState())) {
			createCampaign(pVoCampaign);
		} else if (Constants.OBJECT_STATE_MODIFIED.equals(pVoCampaign
				.getObjectState())) {
			updateCampaign(pVoCampaign);
		} else if (Constants.OBJECT_STATE_READ.equals(pVoCampaign
				.getObjectState())) {
			// Sub entities are changed
			updateCampaign(pVoCampaign);
		} else if (Constants.OBJECT_STATE_REMOVED.equals(pVoCampaign
				.getObjectState())) {
			removeCampaign(pVoCampaign);
		} else {
			throw new ValueMissingException(
					"Illegal Object State set! Can not handle '"
							+ pVoCampaign.getObjectState() + "'."
					);
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#lock()
	 */
	public void lock() throws ValueMissingException, CampaignException {

		requireCampaign();

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
		checkRanges(mCampaign.getRanges());

		checkPastStartDate();

		triggerProcessing(Constants.CAMPAIGN_STATE_CONSTANT_LOCKED);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#unlock()
	 */
	public void unlock() throws ValueMissingException, CampaignException {

		requireCampaign();

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_LOCKED,
				Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING);

		triggerProcessing(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#authorize()
	 */
	public void authorize() throws ValueMissingException, CampaignException,
	FourEyesException, IkeaException {

		requireCampaign();

		IkeaUserProfile vIkeaUserProfile = mBsContext
				.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new ValueMissingException("User Profile could not be found");
		}
		String VUserId = vIkeaUserProfile.getUID().toLowerCase();

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_LOCKED);
		checkPastStartDate();
		checkCountry();

		// The same person can not initiate/edit AND authorize a campaign
		if (VUserId.equals(mCampaign.getCreatedBy().toLowerCase())) {
			throw new FourEyesException(
					"The same user can not both initiate and authorize the campaign.");
		}
		if (VUserId.equals(mCampaign.getUpdatedBy().toLowerCase())) {
			throw new FourEyesException(
					"The same user can not both update and authorize the campaign.");
		}

		mCampaign
		.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_AUTHORIZED);
		mCampaign.setAuthorizedDateTime(mTimeSource.currentDate());
		mCampaign.setAuthorizedBy(VUserId);
		try {
			updateExpireDate();
			updateCampaignLoadTransactions_Aouthorization(mCampaign);
		} catch (Exception e) {
			mCategory.info(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#withdraw()
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#withdraw()
	 */
	public void withdraw(VoCampaign pVoCampaign) throws ValueMissingException, CampaignException,
	IkeaException {
		requireCampaign();
		IkeaUserProfile vIkeaUserProfile = mBsContext
				.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new ValueMissingException("User Profile could not be found");
		}
		String VUserId = vIkeaUserProfile.getUID().toLowerCase();

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_AUTHORIZED);
		checkRanges(mCampaign.getRanges());
		//triggerProcessing(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN);
		processWithdrawn(pVoCampaign,VUserId);
		mBefCampaign.update(mCampaign);

	}

	public int amountWithdrawn() throws IkeaException, ValueMissingException{

		Collection<Range> vRanges = mCampaign.getRanges();
		List<BigDecimal> vList = mBefCardNumber.findByRange(vRanges, mCampaign
				.getCurrentCardNumberId(), -1);
		int vCount = 0;
		for(Iterator<BigDecimal> j = vList.iterator(); j.hasNext();){
			BigDecimal vId = (BigDecimal) j.next();
			long vCardNumberId = vId.longValue();

			CardNumber vCardNumber = mBefCardNumber
					.findByPrimaryKey(vCardNumberId);

			if (vCount >= getMaxCardsInOneProcess()) {
				// We have processed enough for this transaction -> return
				//   mCampaign.setLockCount(mCampaign.getLockCount() + vCount);
				// mCampaign.setLockMessages(vMessages.toString());
				mCampaign.setCurrentCardNumberId(vCardNumber.getCardNumberId());

				return vCount;
			}

			try {
				mBecCard.init(vCardNumber);
				mBecCard.loadCampaign(mCampaign);
				vCount++;
			} catch (BlockedCardException e) {

				mCategory.info(e.getMessage());
			} catch (ExpiredCardException e) {

				mCategory.info(e.getMessage());
			} catch (IllegalCardStateException e) {

				mCategory.info(e.getMessage());
			} catch (InvalidCardNumberException e) {

				mCategory.info(e.getMessage());
			} catch (CurrencyException e) {

				mCategory.info(e.getMessage());
			} catch (InvalidCardException e) {

				mCategory.info(e.getMessage());
			} catch (AmountException e) {

				mCategory.info(e.getMessage());
			} catch (CountrySetupException e) {

				mCategory.info(e.getMessage());
			}


		}

		try {
			//mBecCard.CampaignLoadtransaction(mCampaign);
			//campaignTransaction_Withdrawal(mCampaign);
		} catch (Exception e) {
			mCategory.info(e.getMessage());
		}

		mBefCampaign.save(mCampaign);
		return vCount;
	}


	/*
	 * (non-Javadoc)
	 *
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaign#process()
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public int process(long pCampaignId)
			throws ValueMissingException, CampaignException, IkeaException {

		init(pCampaignId);
		requireCampaign();

		mCategory.info("Processing campaign '" + mCampaign.getName() + "'.");

		boolean isProcessing = Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING
				.equals(mCampaign.getCampaignState());

		if (!isProcessing) {
			mCategory
			.info("Will not process Campaign since it is not in processing state. Aborting.");
			return 0;
		}

		boolean isWishedLocked = Constants.CAMPAIGN_STATE_CONSTANT_LOCKED
				.equals(mCampaign.getWishedCampaignState());
		boolean isWishedInitiated = Constants.CAMPAIGN_STATE_CONSTANT_INITIATED
				.equals(mCampaign.getWishedCampaignState());
		boolean isWishedWithdrawn = Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN
				.equals(mCampaign.getWishedCampaignState());

		int vCount = 0;
		if (isWishedLocked) {
			vCount = processLock();
		} else if (isWishedInitiated) {
			vCount = processUnlock();
		}
		else if (isWishedWithdrawn) {
			//vCount = processWithdrawn();
		}

		mBefCampaign.save(mCampaign);

		return vCount;
	}

	/**
	 * @return
	 */
	protected int processLock() throws ValueMissingException, IkeaException {
		requireCampaign();

		int vCount = 0;
		int vErrorCount = 0;
		int vMaxLockmessageLength = 1000;

		StringBuffer vMessages = new StringBuffer();
		
		if (mCampaign.getLockCount() == 0) {
			// Reset if first batch
			vMessages = new StringBuffer();
		}

		// Retrieve a list of ranges
		Collection<Range> vRanges = mCampaign.getRanges();
		// Retrieve card number ids
		List<BigDecimal> vList = mBefCardNumber.findByRange(vRanges, mCampaign
				.getCurrentCardNumberId(), 0);
		BusinessUnitEnvironment vBusinessUnitEnvironment =
				mUtilsFactory.createBusinessUnitEnvironment(
						new ArrayList<CampaignLimitation>(mCampaign.getCampaignLimitations()).get(0).getBuType(),
						new ArrayList<CampaignLimitation>(mCampaign.getCampaignLimitations()).get(0).getBuCode());
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		for (Iterator<BigDecimal> j = vList.iterator(); j.hasNext(); ) {
			BigDecimal vId = (BigDecimal) j.next();
			long vCardNumberId = vId.longValue();

			CardNumber vCardNumber = mBefCardNumber
					.findByPrimaryKey(vCardNumberId);

			if (vCount >= getMaxCardsInOneProcess()) {
				// We have processed enough for this transaction -> return
				mCampaign.setLockCount(mCampaign.getLockCount() + vCount);
				mCampaign.setLockMessages(vMessages.toString());
				mCampaign.setCurrentCardNumberId(vCardNumber.getCardNumberId());

				return vCount;
			}

			if (processedLoad(vCardNumber)) {
				mCategory.debug("Already processed card number id "
						+ vCardNumber.getCardNumberId() + ". Skipping.");
			} else {
				mCategory.debug("Processing card number id "
						+ vCardNumber.getCardNumberId() + ".");

				// Initialize card and load the campaign
				try {
					//mBecCard.init(vCardNumber);
					mBecCard.init(vBusinessUnitEnvironment, vTransactionEnvironment);
					mBecCard.init(vCardNumber, vBusinessUnitEnvironment);

					mBecCard.loadCampaign(mCampaign);
					vCount++;
				} catch (CardPayException e) {
					// Only catch card pay exceptions that we could do something
					// about.
					mCategory.warn("Error when processing campaign id '"
							+ mCampaign.getCampaignId()
							+ "' and card number id '"
							+ vCardNumber.getCardNumberId()
							+ "'. Card number string '"
							+ CardPaymentLogger.cardNumberToString(vCardNumber)
							+ "'. "+e.getMessage());
					vMessages.append(mBecCardNumber
							.composeCardNumberString(vCardNumber)
							+ ": " + e.getMessage() + "\n");
					if (vMessages.length() >= vMaxLockmessageLength) {
						// Truncate the lock message string if too long
						vMessages = new StringBuffer(vMessages.substring(0,
								vMaxLockmessageLength - 15));
						vMessages.append("\n<truncated>");
					}
					vErrorCount++;
					if (vErrorCount > 100) {
						throw new IkeaException(
								"Found more than 100 errors when processing campaign id "
										+ mCampaign.getCampaignId()
										+ ". Aborting."
								);
					}
				}
			}
		}
		try {
			mBecCard.CampaignLoadtransaction(mCampaign);
		} catch (Exception e) {
			mCategory.info(e.getMessage());
		}
		mCampaign.setLockCount(mCampaign.getLockCount() + vCount);
		mCampaign.setLockMessages(vMessages.toString());

		// Reset processing values
		mCampaign.setCurrentCardNumberId(0);
		mCampaign.setCampaignState(mCampaign.getWishedCampaignState());
		mCampaign.setWishedCampaignState(null);

		return vCount;
	}

	/**
	 * @param vCardNumber
	 * @return
	 * @throws ValueMissingException
	 */
	protected boolean processedLoad(CardNumber vCardNumber)
			throws ValueMissingException {

		requireCampaign();

		if (vCardNumber.getCard() == null) {
			return false;
		}
		if (vCardNumber.getCard().getAmounts() == null) {
			return false;
		}
		// Is any of the amounts connected to this campaign?
		for (Iterator<Amount> i = vCardNumber.getCard().getAmounts().iterator(); i
				.hasNext(); ) {
			Amount vAmount = (Amount) i.next();
			if (vAmount.getCampaign() != null
					&& vAmount.getCampaign().equals(mCampaign)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return
	 */
	protected int processUnlock() throws ValueMissingException {
		requireCampaign();

		// Delete all in one query.

		try {
			mBefTransaction.deleteLoadCampaignTransaction(mCampaign);
		} catch (Exception e) {

			mCategory.info(e.getMessage());
		}
		int vCount = mBefAmount.deleteByCampaign(mCampaign);
		mCampaign.setLockCount(0);
		mCampaign.setLockMessages("Deleted " + vCount + " amounts.");

		// Reset processing values
		mCampaign.setCurrentCardNumberId(0);
		mCampaign.setCampaignState(mCampaign.getWishedCampaignState());
		mCampaign.setWishedCampaignState(null);
		return (-1) * vCount;
	}

	// -----------------------------------------------------

	protected int processWithdrawn(VoCampaign pCampaign,String vIkeaUser) throws ValueMissingException, CampaignException {

		requireCampaign();
		int vCount = 0;
		int vErrorCount = 0;
		mCategory.debug(String.valueOf(mCampaign.getCampaignId()));
		mCampaign.setWishedCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN);
		try {
			if(Constants.OBJECT_STATE_REMOVED.equals(pCampaign
					.getObjectState()))
			{
				mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_AUTHORIZED);
				cancelCampaign(pCampaign);

				//mCampaign.setWishedCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAW);
				mCampaign.setWishedCampaignState(null);
			}
			else{

				mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_AUTHORIZED);

				// Loop over the range
				Collection<Range> vRanges = mCampaign.getRanges();
				// Retrieve card number ids

				List<BigDecimal> vList = mBefCardNumber.findByRange(vRanges, mCampaign
						.getCurrentCardNumberId(), 0);


				List<Transaction> transactionList= mBefCampaign.getCampaignLoadTransactions(mCampaign);
				ArrayList<Card> cardSet=new ArrayList();
				for(Transaction pTransaction:transactionList)
				{
					cardSet.add(pTransaction.getCard());
				}
				campaignTransaction_Withdrawal(transactionList,cardSet,"WITHDRAW");


				mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN);
			}
		}
		catch(CampaignException e){
			throw new CampaignException(e.getMessage());
		}
		catch (Exception e) {
			mCategory
			.warn("Error when processing withdrawn of Campaign '"
					+ mCampaign.getCampaignId() +" " +e.getMessage());
			vErrorCount++;
			if (vErrorCount > 100) {
				throw new IkeaException(
						"Found more than 100 errors when processing withdrawn of mass load id '"
								+ mCampaign.getCampaignId()
								+ "'. Aborting.");
			}
		}

		//		

		//mCampaign.setLockCount(mCampaign.getLockCount() + vCount);
		//mCampaign.setLockMessages(vMessages.toString());

		// Reset processing values
		mCampaign.setCurrentCardNumberId(0);
		//mCampaign.setCampaignState(mCampaign.getWishedCampaignState());
		mCampaign.setWishedCampaignState(null);
		return vCount;


	}





	/**
	 *
	 */
	protected void checkState(String pWishedState)
			throws ValueMissingException, CampaignException {

		requireCampaign();

		boolean vInWishedState = pWishedState.equals(mCampaign
				.getCampaignState());

		if (!vInWishedState) {
			throw new CampaignWrongStateException(
					"Campaign needs to be in state '" + pWishedState
					+ "'. Current state for '" + mCampaign.getName()
					+ "' is '" + mCampaign.getCampaignState() + "'."
					);
		}
	}

	/**
	 *
	 */
	protected void checkState(String pWishedStateFirst,
			String pWishedStateSecond) throws ValueMissingException,
	CampaignException {

		requireCampaign();

		boolean vInWishedStateFirst = pWishedStateFirst.equals(mCampaign
				.getCampaignState());

		boolean vInWishedStateSecond = pWishedStateSecond.equals(mCampaign
				.getCampaignState());

		if (!vInWishedStateFirst && !vInWishedStateSecond) {
			throw new CampaignWrongStateException(
					"Campaign needs to be in state '" + pWishedStateFirst
					+ "' or '" + pWishedStateSecond
					+ "'. Current state for '" + mCampaign.getName()
					+ "' is '" + mCampaign.getCampaignState() + "'."
					);
		}
	}

	/**
	 *
	 */
	protected void checkCountry() throws ValueMissingException,
	CampaignException, IkeaException {

		requireCampaign();

		String pCountryCode = countryCodeForUser();

		if (!pCountryCode.equalsIgnoreCase(mCampaign.getCountryCode())) {
			throw new CampaignException(
					"The Campaign belongs to the country code '"
							+ mCampaign.getCountryCode()
							+ "'. Your country code is '" + pCountryCode + "'."
					);
		}
	}

	/**
	 *
	 */
	protected void checkRanges(Collection<Range> pRanges)
			throws ValueMissingException, CampaignException {
		requireCampaign();

		for (Iterator<Range> i = pRanges.iterator(); i.hasNext(); ) {
			Range vRange = (Range) i.next();

			boolean vIsCompleted = Constants.IMPORT_STATE_CONSTANT_COMPLETED
					.equals(vRange.getImportState());

			if (!vIsCompleted) {
				if (!vIsCompleted) {
					vIsCompleted = Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE
							.equals(vRange.getImportState());
				}
				else{
					throw new CampaignException(
							"All ranges needs to be completed before locking. Range '"
									+ vRange.getName() + "' is in state '"
									+ vRange.getImportState() + "'."
							);
				}
			}
		}
	}

	/**
	 * @throws ValueMissingException
	 * @throws CampaignException
	 */
	protected void checkPastStartDate() throws ValueMissingException,
	CampaignException {
		requireCampaign();

		// Interval start date needs to be greater than today
		Date vToday = new Date();
		if (mCampaign.getIntervalStartDate() != null
				&& mCampaign.getIntervalStartDate().before(vToday)) {
			throw new CampaignException(
					"Campaign start date must be after today's date");
		}

	}

	/**
	 * @param pVoCampaign
	 * @throws IkeaException
	 */
	protected void createCampaign(VoCampaign pVoCampaign) throws IkeaException,
	ValueMissingException, RangeNotFoundException, CampaignException {

		mCategory.info("Creating new campaign '" + pVoCampaign.getName()
		+ "'.");

		mCampaign = mBefCampaign.create();


		if(pVoCampaign.getVoCardRangeRefList().size()==0)
		{
			pVoCampaign=createOrUpdateRange(pVoCampaign,"CREATE");	
		}
		else{
			Set<Range> rangelist= new HashSet<Range>();
			for(VoCardRangeRef mVoCardRangeRef:pVoCampaign.getVoCardRangeRefList())
			{
				Range mRange=mBefRange.findByPrimaryKey(mVoCardRangeRef.getRangeId());
				rangelist.add(mRange);
			}
			mCampaign.setRanges(rangelist);
		}

		assignToCampaign(mCampaign, pVoCampaign);

		// Set attributes that can not be set from the client
		mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);

		mCampaign.setCountryCode(countryCodeForUser());
		mCampaign.setAuthorizedBy(null);
		mCampaign.setAuthorizedDateTime(null);
		mCampaign.setWithdrawnBy(null);
		mCampaign.setWithdrawnDateTime(null);
		mCampaign.setReasonCode(pVoCampaign.getReasonCode());
		mCampaign.setCompanyName(pVoCampaign.getCompanyName());
		mCampaign.setCustomerType(pVoCampaign.getCustomerType());
		checkConstraints();
		// Connect ranges (can not insert directly with SQL since campaign
		// object is not flushed to db jet)



		// Connect campaign limitations (BUs)
		mBefCampaign.save(mCampaign);
		pVoCampaign.setCampaignId(mCampaign.getCampaignId());
		//updateRanges(pVoCampaign);
		updateLimitations(pVoCampaign);



	}

	/**
	 * @param pVoCampaign
	 */
	protected void updateCampaign(VoCampaign pVoCampaign)
			throws ValueMissingException, RangeNotFoundException,
			CampaignException, IkeaException {
		mCategory.debug("Updating campaign '" + pVoCampaign.getName() + "'.");

		init(pVoCampaign.getCampaignId());

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
		checkCountry();
		Set<Range>cRangeList=mCampaign.getRanges();
		assignToCampaign(mCampaign, pVoCampaign);
		checkConstraints();
		if(!mCampaign.getName().equals(pVoCampaign.getName()))
			mCampaign.setName(pVoCampaign.getName());

		if(pVoCampaign.getVoCardRangeRefList().size()>0 && 
				pVoCampaign.getFromCardNumberString().length()<1 && pVoCampaign.getUntilCardNumberString().length()<1)
		{
			mCategory.debug("Updating campaign Segments '" + pVoCampaign.getName() + "'.");
			for(Range cRange:cRangeList)
			{
				if(cRange.getImportState().equalsIgnoreCase(Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE))
				{
					mCategory.debug("disconnect campaign '" + pVoCampaign.getName() + "'.");
					mBefCampaign.disconnectRange(mCampaign.getCampaignId(),
							cRange.getRangeId());
				}

			}
			updateRanges(pVoCampaign);
		}
		else if(pVoCampaign.getVoCardRangeRefList().size()<1 && 
				pVoCampaign.getFromCardNumberString().length()>1 && pVoCampaign.getUntilCardNumberString().length()>1)
		{
			mCategory.debug("Updating campaign Range'" + pVoCampaign.getName() + "'.");
			boolean requireRange=false;
			for(Range cRange:cRangeList)
			{
				if(cRange.getImportState().equalsIgnoreCase(Constants.IMPORT_STATE_CONSTANT_COMPLETED))
				{
					mCategory.debug("disconnect campaign segment '" + pVoCampaign.getName() + "'.");
					mBefCampaign.disconnectRange(mCampaign.getCampaignId(),
							cRange.getRangeId());
					requireRange=true;

				}

				if(cRange.getImportState().equalsIgnoreCase(Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE))
				{
					mCategory.debug("Updating campaign range '" + pVoCampaign.getName() + "'.");
					pVoCampaign=createOrUpdateRange(pVoCampaign,"UPDATE");
				}

			}
			if(requireRange)
			{
				mCategory.debug("create campaign range '" + pVoCampaign.getName() + "'.");
				pVoCampaign=createOrUpdateRange(pVoCampaign,"CREATE");
			}

		}
		else if(pVoCampaign.getVoCardRangeRefList().size()>1 && 
				pVoCampaign.getFromCardNumberString().length()>1 && pVoCampaign.getUntilCardNumberString().length()>1)
		{
			for(VoCardRangeRef cRange:pVoCampaign.getVoCardRangeRefList())
			{
				if(cRange.getObjectState().equalsIgnoreCase("REM"))
				{
					mCategory.debug("disconnect campaign segment '" + pVoCampaign.getName() + "'.");
					mBefCampaign.disconnectRange(mCampaign.getCampaignId(),
							cRange.getRangeId());

				}

				if(cRange.getObjectState().equalsIgnoreCase("NEW"))
				{
					mCategory.debug("disconnect campaign segment '" + pVoCampaign.getName() + "'.");
					mBefCampaign.connectRange(mCampaign.getCampaignId(),
							cRange.getRangeId());

				}
			}

		}
		else{
			//dont make any changes, as it is connected to Campaign Segment
		}
		updateLimitations(pVoCampaign);


		mBefCampaign.save(mCampaign);
	}


	/**
	 * Check logical constraints of campaign
	 *
	 * @throws ValueMissingException
	 */
	protected void checkConstraints() throws ValueMissingException,
	CampaignException {
		requireCampaign();

		// Check interval dates
		if (mCampaign.getIntervalStartDate() != null
				&& mCampaign.getIntervalEndDate() != null) {
			if (mCampaign.getIntervalEndDate().before(
					mCampaign.getIntervalStartDate())) {
				throw new CampaignException(
						"End date must be after start date!");
			}
			//Defect-IKEA01072482 - campaign Until date cannot be same as start date -anagc
			if (mCampaign.getIntervalEndDate().equals(
					mCampaign.getIntervalStartDate())) {
				throw new CampaignException(
						"End date cannot be same as start date, it has to be after start date.");
			}
		}

		// Check time interval
		if (mCampaign.getFromTime() != null && mCampaign.getUntilTime() != null) {
			if (mCampaign.getUntilTime().compareTo(mCampaign.getFromTime()) <= 0) {
				throw new CampaignException(
						"Until time must be after from time!");
			}
		}

		// Check week days
		if (!mCampaign.getMonday() && !mCampaign.getTuesday()
				&& !mCampaign.getWednesday() && !mCampaign.getThursday()
				&& !mCampaign.getFriday() && !mCampaign.getSaturday()
				&& !mCampaign.getSunday()) {
			throw new CampaignException(
					"At least one of the week days must be set!");
		}
	}

	/**
	 * @param pCampaign
	 * @param pVoCampaign
	 * @throws ValueMissingException
	 */
	protected static void assignToCampaign(Campaign pCampaign,
			VoCampaign pVoCampaign) throws ValueMissingException {

		Map<String, Object> vMap = ValueObjects.assignToMap(pVoCampaign);

		// Remove the properties that are not allowed to set from the client
		removeProperty(vMap, "campaignState");
		removeProperty(vMap, "processing");
		removeProperty(vMap, "countryCode");
		removeProperty(vMap, "authorizedBy");
		removeProperty(vMap, "authorizedDateTime");
		removeProperty(vMap, "withdrawnBy");
		removeProperty(vMap, "withdrawnDateTime");
		removeProperty(vMap, "fromTime");
		removeProperty(vMap, "untilTime");

		pCampaign.assignFromMap(vMap);

		// Special handling for fromTime and untilTime
		if (pVoCampaign.getFromTime() != null) {
			DateTime vDateTime = new DateTime(pVoCampaign.getFromTime());
			pCampaign.setFromTime(Dates.formatTime(vDateTime, false));
		}
		if (pVoCampaign.getUntilTime() != null) {
			DateTime vDateTime = new DateTime(pVoCampaign.getUntilTime());
			pCampaign.setUntilTime(Dates.formatTime(vDateTime, false));
		}
	}

	/**
	 * @param pVoCampaign
	 * @param pCampaign
	 * @throws ValueMissingException
	 */
	protected static void assignToVoCampaign(VoCampaign pVoCampaign,
			Campaign pCampaign) throws ValueMissingException {

		Map<String, Object> vMap = pCampaign.assignToMap();

		removeProperty(vMap, "fromTime");
		removeProperty(vMap, "untilTime");

		ValueObjects.assignFromMap(pVoCampaign, vMap);

		// Special handling for fromTime and untilTime
		if (pCampaign.getFromTime() != null) {
			pVoCampaign.setFromTime(Dates.parseTime(
					pCampaign.getFromTime() + ":00").toDate());
		}
		if (pCampaign.getUntilTime() != null) {
			pVoCampaign.setUntilTime(Dates.parseTime(
					pCampaign.getUntilTime() + ":00").toDate());
		}
	}


	/**
	 * @param pMap
	 * @param pProperty
	 * @throws ValueMissingException
	 */
	protected static void removeProperty(Map<String, Object> pMap,
			String pProperty) throws ValueMissingException {
		// Should we check if it exsists first?
		pMap.remove(pProperty);
	}

	/**
	 * @param pVoCampaign
	 */
	protected void updateRanges(VoCampaign pVoCampaign)
			throws ValueMissingException, RangeNotFoundException,
			CampaignException {
		requireCampaign();

		// Can only use this method when we have a campaign and range ID already
		// in the db,
		// since we are accessing the connection table bretween then with direct
		// SQL statements.

		if (pVoCampaign.getVoCardRangeRefList() != null) {

			for (VoCardRangeRef vVoCardRangeRef : pVoCampaign.getVoCardRangeRefList()) {
				if (vVoCardRangeRef.getRangeId() == 0) {
					throw new CampaignException(
							"RangeId can not be zero when connecting a range to a campaign! It is zero for range '"
									+ vVoCardRangeRef.getName() + "'."
							);
				}
				// mBecRange.init(vVoCardRangeRef.getRangeId());
				if (Constants.OBJECT_STATE_REMOVED.equals(vVoCardRangeRef
						.getObjectState())) {

					mBefCampaign.disconnectRange(mCampaign.getCampaignId(),
							vVoCardRangeRef.getRangeId());

				} else if (Constants.OBJECT_STATE_NEW.equals(vVoCardRangeRef
						.getObjectState())) {

					mBefCampaign.connectRange(mCampaign.getCampaignId(),
							vVoCardRangeRef.getRangeId());
				}
				// else no change
			}
		}
	}

	/**
	 * @param pVoCampaign
	 */
	protected void updateLimitations(VoCampaign pVoCampaign)
			throws ValueMissingException, CampaignLimitationNotFoundException {
		requireCampaign();

		UnitsCacheImpl unitscache = UnitsCacheImpl.getInstance();
		String vVobuCode = null;
		String vVobuType = null;

		String cachebuCode = null;

		if (pVoCampaign.getVoCampaignLimitationList() != null && pVoCampaign.getVoCampaignLimitationList().size()!=0) {

			for (VoCampaignLimitation vVoCampaignLimitation : pVoCampaign.getVoCampaignLimitationList()) {
				//vVoCampaignLimitation.setObjectState(pVoCampaign.getObjectState());
				if(vVoCampaignLimitation !=null){
					vVobuCode = vVoCampaignLimitation.getBuCode();
					vVobuType = vVoCampaignLimitation.getBuType();
					cachebuCode = unitscache.fetch(vVobuType, vVobuCode).getBuCode();
				}

				if (Constants.OBJECT_STATE_NEW.equals(vVoCampaignLimitation
						.getObjectState())) {

					if(vVobuCode!=null && !vVobuCode.isEmpty() && cachebuCode.equalsIgnoreCase(vVobuCode))
					{

						mBecCampaignLimitation.create(vVoCampaignLimitation
								.getBuType(), vVoCampaignLimitation.getBuCode());	
					}
					else{
						throw new BusinessUnitException("Invalid Business Unit, Please enter the valid Business Unit");
					}
					mCampaign.connectCampaignLimitation(mBecCampaignLimitation
							.getCampaignLimitation());


					mBecCampaignLimitation.save();

				}

				else if (Constants.OBJECT_STATE_REMOVED
						.equals(vVoCampaignLimitation.getObjectState())) {

					if (vVoCampaignLimitation.getCampaignLimitationId() == 0) {
						throw new CampaignLimitationNotFoundException(
								"Can not remove a campaign limitation with CampaignLimitationId zero! It is zero for '"
										+ vVoCampaignLimitation.getBuType()
										+ " "
										+ vVoCampaignLimitation.getBuCode()
										+ "'."
								);
					}

					mBecCampaignLimitation.init(vVoCampaignLimitation
							.getCampaignLimitationId());
					mCampaign
					.disconnectCampaignLimitation(mBecCampaignLimitation
							.getCampaignLimitation());
					mBecCampaignLimitation.delete();
				} // else do nothing
			}
		}

		else{
			throw new BusinessUnitException("Business Unit is empty,Please enter the valid business unit.");
		}
	}

	/**
	 * @param pVoCampaign
	 * @throws ValueMissingException
	 * @throws RangeNotFoundException
	 * @throws CampaignException
	 */
	protected void removeCampaign(VoCampaign pVoCampaign)
			throws ValueMissingException, RangeNotFoundException,
			CampaignException, IkeaException {

		mCategory.info("Deleting campaign '" + pVoCampaign.getName() + "'.");

		init(pVoCampaign.getCampaignId());

		checkState(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
		checkCountry();

		mBefCampaign.delete(mCampaign);
	}

	/**
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser() throws ValueMissingException,
	IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException(
					"Tried to use BecCampaign without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

	/**
	 * @throws CampaignException
	 */
	protected void triggerProcessing(String pWishedState) throws ValueMissingException,
	CampaignException {

		requireCampaign();

		try {
			VoCampaignKey vVoCampaignKey = new VoCampaignKey();
			vVoCampaignKey.setCampaignId(mCampaign.getCampaignId());

			BsProcessCampaign vBsProcessCampaign = new BsProcessCampaign();
			vBsProcessCampaign.setVoCampaignKey(vVoCampaignKey);
			vBsProcessCampaign.setWishedState(pWishedState);
			BsExecuter bsExecuter = BeanFactory.getBsExecuter();
			bsExecuter.executeBsAsync(vBsProcessCampaign);
		} catch (IkeaException e) {
			mCategory.error(e.getMessage());
			throw new CampaignException("Could not start processing. "
					+ e.toString());
		}

	}

	protected int getMaxCardsInOneProcess() {
		return mEbcEnvironment.getMaxCardsInCampaignProcessing();
	}

	/**
	 * @param pCampaign
	 */
	protected void setCampaign(Campaign pCampaign) {
		mCampaign = pCampaign;
	}

	/**
	 * @throws ValueMissingException
	 */
	protected void requireCampaign() throws ValueMissingException {
		if (mCampaign == null)
			throw new ValueMissingException(
					"Tried to use BecCampaign without required Campaign.");
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void prepareForProcessing(String pWishedState, long pCampaignId)
			throws ValueMissingException, CampaignException {

		init(pCampaignId);
		requireCampaign();

		if (Constants.CAMPAIGN_STATE_CONSTANT_LOCKED.equals(pWishedState)) {
			checkState(Constants.CAMPAIGN_STATE_CONSTANT_INITIATED);
		} else if (Constants.CAMPAIGN_STATE_CONSTANT_INITIATED.equals(pWishedState)) {
			checkState(Constants.CAMPAIGN_STATE_CONSTANT_LOCKED, Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING);
		}
		else if (Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN.equals(pWishedState)) {
			checkState(Constants.MASS_LOAD_STATE_CONSTANT_AUTHORIZED);
		}
		else {
			throw new IllegalArgumentException("Trying to process to an unknown state: " + pWishedState);
		}

		IkeaUserProfile vIkeaUserProfile = mBsContext
				.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new ValueMissingException("User Profile could not be found");
		}

		mCampaign.setLockCount(0);
		mCampaign.setLockMessages(null);
		mCampaign.setWishedCampaignState(pWishedState);
		mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING);
		mBefCampaign.save(mCampaign);
	}


	public void afterPropertiesSet() throws Exception {
		validate();

	}

	public List<Campaign> getExpiredCampaigns(Date pExpireDateFrom,Date pExpireDateUpto) throws ValueMissingException
	{
		int processedcampaigns=0;
		mCategory.debug(pExpireDateFrom+";"+pExpireDateUpto);
		List<Campaign> vList =mBefCampaign.findExpiredCampaigns(pExpireDateFrom,pExpireDateUpto);
		mCategory.debug("found "+vList.size()+" Campaigns to expire it.");
		return vList;
	}


	public void processExpiredCampaignslist(List<Campaign> vCampign) throws ValueMissingException
	{
		int processedcampaign=0;
		int chunk=0;
		mCategory.debug(" fetched Campaigns to expire it.");

		for (Iterator<Campaign> i = vCampign.iterator(); i.hasNext();) 
		{
			Campaign vCampaign = (Campaign) i.next();

			processedcampaign= processExpiredcampaign(vCampaign);
			mCategory.debug("Completed Expired Campaign process: "+ ++chunk);
		}
	}



	public int processExpiredcampaign(Campaign pCampaign) throws ValueMissingException
	{
		init(pCampaign);
		requireCampaign();
		int vCount = 0;
		int vErrorCount = 0;
		mCategory.debug(String.valueOf(mCampaign.getCampaignId()));

		// Loop over the range
		Collection<Range> vRanges = mCampaign.getRanges();
		// Retrieve card number ids
		List<BigDecimal> vList = mBefCardNumber.findByRange(vRanges, mCampaign
				.getCurrentCardNumberId(), -1);

		for (Iterator<BigDecimal> j = vList.iterator(); j.hasNext();) {
			BigDecimal vId = (BigDecimal) j.next();
			long vCardNumberId = vId.longValue();

			CardNumber vCardNumber = mBefCardNumber
					.findByPrimaryKey(vCardNumberId);

			if (vCount >= getMaxCardsInOneProcess()) {

				return vCount;
			}
			//
			try {
				//				// FIND CARD AND THE MASSLOAD AMOUNT FROM THE CARD NUMBER
				Card vCard = vCardNumber.getCard();
				if(vCard!=null)
				{
					Amount vAmount = findAmount(mCampaign, vCard);
					if(vAmount==null)
					{
						mCategory.debug("No amount found");
					}
					else{
						mCategory.debug(vAmount.getAmountId()+":"+vAmount.getCurrentAmount());
						if(!Amounts.isZero(vAmount.getCurrentAmount()))
						{
							//							Set<CampaignLimitation> campaignlimitation=mCampaign.getCampaignLimitations();
							//							for(CampaignLimitation campaignlimitationrecord:campaignlimitation)
							//							{
							BusinessUnitEnvironment vBusinessUnitEnvironment = mUtilsFactory
									.createBusinessUnitEnvironment(vAmount.getBuType(),
											vAmount.getBuCode()
											);

							//								
							mBecCard.init(vCardNumber,vBusinessUnitEnvironment);
							//mBecFactory.createBecTransaction().createExpiredTransaction(mCampaign);
							mBecCard.expireCampaign(mCampaign);

							vCount++;
							//							}
						}
					}
				}
			}
			catch (CardPayException e) {
				mCategory
				.warn("Error when processing withdrawn of Campaign '"
						+ mCampaign.getCampaignId()+" "+e.getMessage());
				vErrorCount++;
				if (vErrorCount > 100) {
					throw new IkeaException(
							"Found more than 100 errors when processing withdrawn of mass load id '"
									+ mCampaign.getCampaignId()
									+ "'. Aborting.");
				}
			}
		}
		//		
		mCampaign.setCampaignState(Constants.CAMPAIGN_STATE_CONSTANT_EXPIRED);
		return vCount;

	}

	protected Amount findAmount(Campaign pCampaign, Card pCard) {

		if (pCampaign != null) {
			for (Iterator<Amount> i = pCard.getAmounts().iterator(); i
					.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (vAmount != null && pCampaign.equals(vAmount.getCampaign())) {

					return vAmount;
				}
			}
		}

		return null;
	}

	//@Override
	public void updateCampaignLoadTransactions_Aouthorization(Campaign pCampaign) throws Exception {

		List<Transaction> transactionList = mBefCampaign.getCampaignLoadTransactions(pCampaign);
		if(transactionList !=null){
			for(Transaction pTransaction : transactionList){

				mBecCard.init(pTransaction.getCard());
				mBecCard.updateCampaignLoadTransactions_Aouthorization(pTransaction,pCampaign);
			}
		}

	}

	public void campaignTransaction_Withdrawal(List<Transaction> pTransactions,ArrayList<Card> pCards,String state) throws Exception {

		ArrayList<Long> cCardId=new ArrayList();//
		for(Card cCard:pCards)
		{
			cCardId.add(cCard.getCardId());
		}

		for(Transaction pTransaction:pTransactions)
		{
			Card mCard=pTransaction.getCard();
			long mCardId=mCard.getCardId();
			if(cCardId.contains(mCardId))
			{
				Amount vAmount = findAmount(mCampaign, mCard);
				if(vAmount==null)
				{
					mCategory.debug("No amount found");
				}
				else{
					mCategory.debug(vAmount.getAmountId()+":"+vAmount.getCurrentAmount());

					if(state.equalsIgnoreCase("CANCEL"))
					{
						if(Amounts.isEqual(vAmount.getCurrentAmount(), mCampaign.getAmount()))
						{
							mBecCard.init(pTransaction.getCard());
							if(mCampaign.getIntervalStartDate().after(mCampaign.getUpdatedDateTime()))
							{
								pTransaction.setSalesDay("1900-01-01");
								mBefTransaction.update(pTransaction);
								mBecCard.CampaignDebiTransaction(mCampaign, "1900-01-01");
							}
							else{
								mBecCard.CampaignDebiTransaction(mCampaign, Dates.formatDate(new DateTime()));
							}
						}
						else
						{
							throw new CampaignException(
									"Card Number "+mCard.getCardNumber().getIssuer()
									+mCard.getCardNumber().getCardTypeDigit()
									+mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc())
									+mCard.getCardNumber().getCheckDigit()
									+" can not be cancelled as the card has been already cancelled or amount has been in use"
									);
						}
					}
					if(state.equalsIgnoreCase("WITHDRAW"))
					{
						if(!Amounts.isZero(vAmount.getCurrentAmount()))
						{
							mBecCard.init(pTransaction.getCard());
							if(mCampaign.getIntervalStartDate().after(mCampaign.getUpdatedDateTime()))
							{
								pTransaction.setSalesDay("1900-01-01");
								mBefTransaction.update(pTransaction);
								mBecCard.CampaignDebiTransaction(mCampaign, "1900-01-01");
							}
							else{
								mBecCard.CampaignDebiTransaction(mCampaign, Dates.formatDate(new DateTime()));
							}
						}

					}
				}
			}
		}
	}

	private int cancelCampaign(VoCampaign pCampaign) throws CampaignException
	{
		int vCount = 0;
		int vErrorCount = 0;

		String fromCard=pCampaign.getFromCardNumberString();
		String toCard=pCampaign.getUntilCardNumberString();
		String[] vCardNumbers = CheckDigits.generateCardNumbers(
				fromCard, toCard);
		//pCampaign.getvo;
		HashMap<String,CardNumber> defaultCards=new HashMap<String,CardNumber>();

		String headerString="CampaignRange;"
				+fromCard+";"+toCard;
		IkeaUserProfile vIkeaUserProfile = mBsContext
				.getUserProfile();
		Range vRange = mBefRange.create();
		vRange.setCount(vCardNumbers.length);
		vRange.setCountryCode(vIkeaUserProfile.getCountryCode());
		vRange.setHeader(headerString);
		vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE);
		vRange.setName(mCampaign.getName());

		for(Range voCardRange:mCampaign.getRanges())
		{
			List<CardNumber> rangeCards=mBefCardNumber.findByRangeId(voCardRange.getRangeId());

			for(CardNumber vCardNumber:rangeCards)
			{
				String connectedCards=vCardNumber.getIssuer()+vCardNumber.getCardTypeDigit()+vCardNumber.getAccountNumberEnc()+vCardNumber.getCheckDigit();
				defaultCards.put(connectedCards,vCardNumber);
				vRange.connectCardNumber(vCardNumber);
			}
		}
		HashSet<CardNumber> definedcards= new HashSet<CardNumber>();
		VoCardNumber pVoCardNumber;
		for(String vCardNumber:vCardNumbers)
		{

			if(!defaultCards.containsKey(vCardNumber))
			{
				try {
					pVoCardNumber = mBecCardNumber.splitCardNumber(vCardNumber);
					if(pVoCardNumber.getCardTypeDigit()==2 ||
							pVoCardNumber.getCardTypeDigit()==4){
						throw new CampaignException(
								"Card Number "+vCardNumber + " is not associated with campaign "+mCampaign.getName()
								);
					}
					else throw new CampaignException(
							"Card Number "+vCardNumber + " is not associated with campaign "+mCampaign.getName()
							);

				} catch (InvalidCardNumberException e) {
					// TODO Auto-generated catch block
					throw new CampaignException(
							"Card Number "+vCardNumber + "is invalid"
							);
				}


			}
			else{

				definedcards.add(defaultCards.get(vCardNumber));

			}

		}
		vRange.setCardNumbers(definedcards);
		mBefRange.save(vRange);

		List<Transaction> transactionList;
		try {
			transactionList = mBefCampaign.getCampaignLoadTransactions(mCampaign);
			ArrayList<Card> cardSet=new ArrayList();
			for(CardNumber dCard:definedcards)
			{
				cardSet.add(dCard.getCard());
			}
			campaignTransaction_Withdrawal(transactionList,cardSet,"CANCEL");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new CampaignException(
					e.getMessage()
					);//
		}


		//		
		// Reset processing values
		mCampaign.setCurrentCardNumberId(0);
		return vCount;


	} 

	private VoCampaign createOrUpdateRange(VoCampaign pVoCampaign,String rangestate) throws CampaignException, IkeaException, ValueMissingException
	{
		String fromCard=pVoCampaign.getFromCardNumberString();
		String toCard=pVoCampaign.getUntilCardNumberString();
		String[] vCardNumbers = CheckDigits.generateCardNumbers(
				fromCard, toCard);
		String headerString="CampaignRange;"
				+fromCard+";"+toCard;
		IkeaUserProfile vIkeaUserProfile = mBsContext
				.getUserProfile();


		Set<Range> rangelist= new HashSet<Range>();
		Range vRange=null;
		if(rangestate.equalsIgnoreCase("UPDATE"))
		{
			for(Range cRange:mCampaign.getRanges())
			{
				vRange=mBefRange.findByPrimaryKey(cRange.getRangeId());
				Set<CardNumber> campaigncards= vRange.getCardNumbers();
				for(CardNumber pCardNumber:campaigncards)
				{
					vRange.disconnectCardNumber(pCardNumber);
				}
			}
		}
		else{
			vRange = mBefRange.create();
		}
		vRange.setCount(vCardNumbers.length);
		vRange.setCountryCode(vIkeaUserProfile.getCountryCode());
		vRange.setHeader(headerString);
		vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_CAMPAIGN_RANGE);
		vRange.setName(pVoCampaign.getName());
	
		for(String vCardNumber:vCardNumbers)
		{

			VoCardNumber pVoCardNumber;
			try {
				pVoCardNumber = mBecCardNumber.splitCardNumber(vCardNumber);
			} catch (InvalidCardNumberException e1) {
				// TODO Auto-generated catch block
				throw new CampaignException(
						"Invalid Card Number "+vCardNumber + "Kindly remove the card and try again."
						);
			}
			//Modified in 3.9 release , Defect-IKEA01072482 anagc
			if(pVoCardNumber.getCardTypeDigit()==9 ||
					pVoCardNumber.getCardTypeDigit()==1 ||
					pVoCardNumber.getCardTypeDigit()==3){

				BecCard vBecCard = mBecFactory.createBecCard();
				try {

					// Create card
					vBecCard.createCard(vCardNumber);

					// Connect to range
					vRange.connectCardNumber(vBecCard.getCard().getCardNumber());

				} catch (DuplicateCardException e) {
					// Card already exist with this cardnumber
					BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();
					try {
						vBecCardNumber.findCardNumber(vCardNumber);
						vRange.connectCardNumber(vBecCardNumber.getCardNumber());
					} catch (InvalidCardNumberException e1) {
						// TODO Auto-generated catch block
						mCategory.info(e1.getMessage());
					} catch (CardNumberNotFoundException e1) {
						// TODO Auto-generated catch block
						mCategory.info(e1.getMessage());
					}


				} catch (InvalidCardNumberException e) {
					// TODO Auto-generated catch block
					throw new CampaignException(
							"Invalid Card Number "+vCardNumber + "Kindly remove the card and try again."
							);
				}
			}
			//Modified in 3.9 release , Defect-IKEA01072482 anagc
			else if(pVoCardNumber.getCardTypeDigit()==2 ||
					pVoCardNumber.getCardTypeDigit()==4){
				throw new CampaignException(
						"Gift and Refund cards are not allowed to create a Campaign."
						);
			}
			//Modified in 3.9 release , Defect-IKEA01072482 anagc
			else if(pVoCardNumber.getCardTypeDigit()==0)
			{
				throw new CampaignException(
						"Only Promotional cards are allowed to create Campaign through Card Range."
						);
			}
			//Modified in 3.9 release , Defect-IKEA01072482 anagc
			else{
				throw new CampaignException(
						"Invalid iPay Card, kindly remove the card and try again."
						);
			}
		}


		mBefRange.saveOrUpdate(vRange);
		rangelist.add(vRange);
		mCampaign.setRanges(rangelist);

		List<VoCardRangeRef> mVoCardRangeRef= new ArrayList<VoCardRangeRef>();
		VoCardRangeRef cardRef= new VoCardRangeRef();
		cardRef.setCount(vRange.getCount());
		cardRef.setCountryCode(vRange.getCountryCode());
		cardRef.setHeader(vRange.getHeader());
		cardRef.setImportState(vRange.getImportState());
		cardRef.setName(vRange.getName());		
		cardRef.setRangeId(vRange.getRangeId());
		cardRef.setObjectState(pVoCampaign.getObjectState());
		mVoCardRangeRef.add(cardRef);
		pVoCampaign.setVoCardRangeRefList(mVoCardRangeRef);
		return pVoCampaign;

	}

	private void updateExpireDate()
	{
		for(Range pCRange:mCampaign.getRanges())
		{
			List<CardNumber> vList=mBefCardNumber.findByRangeId(pCRange.getRangeId());
			for (CardNumber vCardNumber:vList) {

				Card vCard= mBefCard.findByPrimaryKey(vCardNumber.getCard().getCardId());
				if(!vCard.getCardType().equalsIgnoreCase(Constants.CARD_TYPE_CONSTANT_FAMILY))
				{
					vCard.setExpireDate(mCampaign.getIntervalEndDate());
					mBefCard.update(vCard);
				}
			}
		}
	}
}

