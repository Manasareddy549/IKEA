/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.MassLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecMassLoad {

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecMassLoad init(UserEnvironment pUserEnvironment);

	/**
	 * 
	 * @param pMassLoadId
	 * @return
	 */
	public BecMassLoad init(long pMassLoadId);

	/**
	 * 
	 * @param pMassLoad
	 * @return
	 */
	public BecMassLoad init(MassLoad pMassLoad);

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public MassLoad getMassLoad() throws ValueMissingException;

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoMassLoad getVoMassLoad() throws ValueMissingException;

	/**
	 * @param vVoMassLoad
	 * @throws IkeaException
	 */
	public void manage(VoMassLoad vVoMassLoad)
		throws
			IkeaException,
			InvalidCardNumberException,
			ValueMissingException,
			RangeNotFoundException,
			MassLoadException;

	/**
	 * @throws ValueMissingException
	 */
	public void lock() throws ValueMissingException, MassLoadException;

	/**
	 * @throws ValueMissingException
	 */
	public void unlock() throws ValueMissingException, MassLoadException;

	/**
	 * @throws ValueMissingException
	 */
	public void authorize()
		throws
			ValueMissingException,
			MassLoadException,
			FourEyesException,
			IkeaException;

	/**
	 * @throws ValueMissingException
	 */
	public void release()
		throws
			ValueMissingException,
			MassLoadException,
			FourEyesException,
			IkeaException;

	
	/**
	 * @throws ValueMissingException
	 */
	public void posRelease(long massloadId,String BuCode, String BuType, String CountryCode, String EmployeeId)
		throws
			ValueMissingException,
			MassLoadException,
			FourEyesException,
			IkeaException;
	
	/**
	 * @throws ValueMissingException
	 */
	public void posWithdraw(long massloadId,String BuCode, String BuType, String CountryCode, String EmployeeId)
		throws
			ValueMissingException,
			MassLoadException,
			IkeaException;


	/**
	 * @throws ValueMissingException
	 */
	public void withdraw()
		throws ValueMissingException, MassLoadException, IkeaException;

	/**
	 * @throws ValueMissingException
	 */
	public int process(long pMassLoadId)
		throws FourEyesException, ValueMissingException, MassLoadException, IkeaException;

	/**
	 * @return
	 */
	public VoBonusComplete getVoMassLoadBonus() throws ValueMissingException;
	
	/**
	 * 
	 * @param pWishedState
	 * @throws ValueMissingException
	 * @throws MassLoadException
	 */
	public void prepareForProcessing(String pWishedStatepMassLoadId, long pMassLoadId)
			throws ValueMissingException, MassLoadException;
}
