package com.ikea.cds.time;

import java.io.InputStream;

/**
 * A custom classloader intended to be used together with the @link{ZoneInfoProvider} since
 * that class does not handle packaging of the compiled tz-files into a jar-file.
 * @author thox
 *
 */
public class StartSlashRemovingClassLoader extends ClassLoader {

	/**
	 * Overrides the normal classloaders getResourceAsStream.
	 * Removes any start slash from the name before delegating to the classloader that loaded this class.
	 * 
	 */
	public InputStream getResourceAsStream(String name) {
		/*
        ClassLoader parent = getParent();
        if( parent==null){
            throw new IllegalArgumentException("Can not operate without a parent classloader");
        }
		 */
//		String adjustedName = name;
//		if( name.startsWith("/")){
//			adjustedName = adjustedName.substring(1,adjustedName.length());
//		}
		return this.getClass().getClassLoader().getResourceAsStream("org/joda/time/tz/data"+name);
		//return this.getSystemClassLoader().getResourceAsStream(adjustedName);
		//return parent.getResourceAsStream(adjustedName);
	}


}
