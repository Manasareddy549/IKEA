/*
 * Created on 2008-apr-21
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 */
public class InvalidVerificationCode extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8760696599169888183L;

	/**
	 * 
	 */
	public InvalidVerificationCode() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public InvalidVerificationCode(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidVerificationCode();
	}

}
