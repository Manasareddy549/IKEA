/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefExternalCardImpl extends BefAbstract<ExternalCard> implements BefExternalCard {

	private final static Logger mCategory_findByExternal =
		LoggerFactory.getLogger(
			BefExternalCardImpl.class.getName() + ".findByExternal");
	private final static Logger mCategory_deleteNotCompleted =
		LoggerFactory.getLogger(
			BefExternalCardImpl.class.getName() + ".deleteNotCompleted");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefExternalCardImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);

	}

	public List<ExternalCard> findByExternal(
		String pExternalCardNumberString,
		ExternalCardSystem pExternalCardSystem) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<ExternalCard> vCriteria = new GenericCriteria<ExternalCard>(vSession.createCriteria(ExternalCard.class));
		vCriteria.add(
			Restrictions.eq("cardNumberString", pExternalCardNumberString));
		if (pExternalCardSystem != null) {
			vCriteria.add(
					Restrictions.eq("externalCardSystem", pExternalCardSystem));
		}

		// To get just one per card
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByExternal.isDebugEnabled()) {
			mCategory_findByExternal.debug("Criteria: " + vCriteria.toString());
		}

		List<ExternalCard> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByExternal.info("No external card numbers found.");
		} else {
			mCategory_findByExternal.info(
				"Found " + vList.size() + " external cards.");
		}
		return vList;
	}

	public int deleteNotCompleted(ExternalCardSystem pExternalCardSystem) {
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"delete from ExternalCard where externalCardSystem=:externalCardSystem and card.cardId is null";

		if (mCategory_deleteNotCompleted.isDebugEnabled()) {
			mCategory_deleteNotCompleted.debug("HQL: " + vHql);
		}

		return vSession
			.createQuery(vHql)
			.setEntity("externalCardSystem", pExternalCardSystem)
			.executeUpdate();

	}

	@Override
	protected Class<ExternalCard> getBusinessEntityClass() {
		return ExternalCard.class;
	}

}
