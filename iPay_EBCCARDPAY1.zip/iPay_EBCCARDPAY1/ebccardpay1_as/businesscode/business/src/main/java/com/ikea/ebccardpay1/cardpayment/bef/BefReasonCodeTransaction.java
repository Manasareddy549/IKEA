package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefReasonCodeTransaction extends Bef<ReasonCodeTransaction> {
	
	public void saveReasonCodeTransaction(long transactioId, int reasoncodeid);

}
