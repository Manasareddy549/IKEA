package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRange;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRangeRef;
import com.ikea.ebcframework.exception.IkeaException;
import java.util.List;

public interface BecRange {

	/**
	 * 
	 * @param pRangeId
	 * @return
	 */
	public BecRange init(long pRangeId) throws RangeNotFoundException;

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecRange init(UserEnvironment pUserEnvironment);

	/**
	 * 
	 * @return
	 */
	public Range getRange() throws ValueMissingException;
	
	//Added by Bisweswar
	public Range getCampaignRange();
	
	public void saveRange(Range pRange);
	
	public void addCardNumbers(Range vRange, List<CardNumber> vList);

	/**
	 * @param pVoCardRange
	 * @param pVoCardNumberList
	 * @return
	 * @throws InvalidCardNumberException
	 * @throws IkeaException
	 */
	public VoCardRange importCardRange(
		VoCardRange pVoCardRange,
		List<VoCardNumber> pVoCardNumberList)
		throws InvalidCardNumberException, IkeaException;

	/**
	 * Retrieves the current card range for the user as a <code>List<VoCardRange></code>
	 * @throws IkeaException If an unexpected error ocurred
	 */
	public List<VoCardRangeRef> findCurrentCardRanges()
		throws ValueMissingException, IkeaException;

}
