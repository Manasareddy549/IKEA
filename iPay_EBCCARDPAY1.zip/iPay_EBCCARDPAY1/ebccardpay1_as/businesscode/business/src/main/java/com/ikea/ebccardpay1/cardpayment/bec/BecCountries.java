/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.CountryException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import java.util.List;
/**
 * @author dalq
 *
 *
 */
public interface BecCountries {

	/**
	 * @return List of VoCountry objects
	 */
	public List<VoCountry> findAllExchangeRateCountries()
		throws ValueMissingException;

	/**
	 * @param list
	 */
	public void manage(List<VoCountry> list)
		throws CountryException, ValueMissingException;

	/**
	 * @param pVoCountryList
	 */
	public void init(List<VoCountry> pVoCountryList);

	/**
	 * @return
	 */
	public List<VoCountry> getInputVoCountryList();

}
