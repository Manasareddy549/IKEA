/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefExternalCardSystem extends Bef<ExternalCardSystem>{

	public ExternalCardSystem findByName(String pExternalCardSystemName, String pImportState);
	
	public ExternalCardSystem findByNameOnly(String pExternalCardSystemName);

}