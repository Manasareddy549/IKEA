/*
 * Created on 2007-aug-15
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author anms
 *
 */
public class ExternalCardNotFoundException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4068002610476357687L;

	/**
	 * 
	 */
	public ExternalCardNotFoundException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public ExternalCardNotFoundException(String pMessage) {
		super(pMessage);
	}
}
