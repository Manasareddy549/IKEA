/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountry;
import com.ikea.ebccardpay1.cardpayment.exception.CountryException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;

/**
 * @author dalq
 * 
 * 
 */
public class BecCountriesImpl implements BecCountries {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecCountriesImpl.class);

	List<VoCountry> mVoCountryList = null;

	// Dependencies injected at creation of this BEC
	private BefCountry mBefCountry;
	private BecCountry mBecCountry;

	/**
	 * @param pBefCountry
	 * @param pBecCountry
	 */
	public BecCountriesImpl(BefCountry pBefCountry, BecCountry pBecCountry) {

		mBefCountry = pBefCountry;
		mBecCountry = pBecCountry;
	}

	void validate() {
		notNull(mBefCountry);
		notNull(mBecCountry);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountries#init(com.ikea.ebccardpay1
	 * .client.vo.VoCountry)
	 */
	public void init(List<VoCountry> pVoCountryList) {
		mVoCountryList = pVoCountryList;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCountry#findAll()
	 */
	public List<VoCountry> findAllExchangeRateCountries()
			throws ValueMissingException {
		List<VoCountry> vVoCountryList = new ArrayList<VoCountry>();

		mCategory.info("Start findExchangeRateCountries...");

		List<Country> vList = mBefCountry.findAll();

		for (Iterator<Country> i = vList.iterator(); i.hasNext();) {
			Country vCountry = (Country) i.next();

			mBecCountry.init(vCountry);
			vVoCountryList.add(mBecCountry.getVoCountry());

		}

		mCategory.info("Finished findAll, found: " + vVoCountryList.size());
		return vVoCountryList;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountries#manage(com.ikea.ebccardpay1
	 * .client.vo.VoCountry)
	 */
	public void manage(List<VoCountry> pVoCountryList) throws CountryException,
			ValueMissingException {

		init(new ArrayList<VoCountry>());
		requireVoCountryList();

		mCategory.info("Start manage Country list....");

		// Loop List of Countries, create or update
		for (VoCountry vVoCountry : pVoCountryList) {
			mBecCountry.manage(vVoCountry);
			mVoCountryList.add(mBecCountry.getVoCountry());

		}

		mCategory.info("Finished manage Country list....");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCountries#getInputVoCountryList()
	 */
	public List<VoCountry> getInputVoCountryList() {

		return mVoCountryList;
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireVoCountryList() throws ValueMissingException {
		if (mVoCountryList == null)
			throw new ValueMissingException(
					"Tried to use BecCountrySetups without required List<VoCountrySetup>.");
	}

}