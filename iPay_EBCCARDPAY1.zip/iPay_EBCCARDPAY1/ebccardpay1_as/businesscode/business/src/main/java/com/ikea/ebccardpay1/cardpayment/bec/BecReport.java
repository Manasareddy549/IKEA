package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.ReportException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoParameter;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportKPI;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportResults;
import com.ikea.ebccardpay1.cardpayment.vo.VoReport;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportTransaction;
import java.util.List;

/**
 *
 */
public interface BecReport {

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecReport init(UserEnvironment pUserEnvironment);

	/**
	 * Find all reports
	 * 
	 * @return A list of VoReport
	 */
	public List<VoReport> findAll();

	/**
	 * 
	 * @param pReportId
	 */
	public void setReport(long pReportId);

	/**
	 * 
	 * @param pVoParameterList
	 */
	public void setParameters(List<VoParameter> pVoParameterList);

	/**
	 * 
	 * @return
	 * @throws ReportException
	 */
	public boolean isKPIReport() throws ValueMissingException, ReportException;

	/**
	 * 
	 * @return
	 * @throws ReportException
	 */
	public List<VoReportTransaction> retrieveTransactionReport()
		throws ValueMissingException, ReportException;
	
	/**
	 * 
	 * @return
	 * @throws ReportException
	 */
	public List<VoReportTransaction> retrieveAdocReport(String query)
		throws ValueMissingException, ReportException;
	
	/**
	 * 
	 * @return
	 * @throws ReportException
	 */
	public List<VoReportResults> retrieveCardDetails(String query)
			throws ValueMissingException, ReportException;

	/**
	 * 
	 * @return
	 * @throws ReportException
	 */
	public List<VoReportKPI> retrieveKPIReport()
		throws ValueMissingException, ReportException;
}
