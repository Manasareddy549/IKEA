/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Activation;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.bef.BefActivation;
import com.ikea.ebccardpay1.cardpayment.bef.BefRange;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardBusinessKey;
import com.ikea.ebcframework.exception.IkeaException;
import org.springframework.beans.factory.annotation.Autowired;
import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 *
 */
public class BecCardsImpl implements BecCards {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecCardsImpl.class.getName());

	// Dependencies injected at creation of this BEC
	private BefRange mBefRange = null;
	private BefActivation mBefActivation = null;

	// Entities that this BEC operates on

	// Related Bec's that this Bec delegates work to
	BecCard mBecCard = null;

	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;

    private BecFactory mBecFactory;

	/**
	 * @param pBefRange
	 * @param pBefActivation
	 * @param pBecFactory 
	 */
	protected BecCardsImpl(
		BefRange pBefRange,
		BefActivation pBefActivation, BecFactory pBecFactory) {

		mBefRange = pBefRange;
		mBefActivation = pBefActivation;
		mBecFactory = pBecFactory;
	}
	
	void validate() {
		notNull(mBefActivation);
		notNull(mBefRange);
		notNull(mBecFactory);
		
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCards#init(com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem, com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit)
	 */
	public BecCards init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment) {

		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCards#activate(com.ikea.ebccardpay1.cardpayment.vo.VoCardBusinessKey)
	 */
	public List<VoCardBusinessKey> activate(List<VoCardBusinessKey> pVoCardBusinessKeyList)
		throws
			InvalidCardNumberException,
			DuplicateCardException,
			ValueMissingException,
			IkeaException {

		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();

		List<VoCardBusinessKey> vAlreadyExists = new ArrayList<VoCardBusinessKey>();

		// Create a range to use for the activation
		Range vRange = mBefRange.create();
		vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_ACTIVATION);

		// Scan through the card key list
		for (VoCardBusinessKey vVoCardBusinessKey : pVoCardBusinessKeyList) {
		
			mCategory.info(
				"Activating card with card number '"
					+ CardPaymentLogger.cardNumberToString(
						vVoCardBusinessKey.getCardNumberString())
					+ "'.");

			// Create a Bec Card
			BecCard vBecCard = mBecFactory.createBecCard();
			
			vBecCard.init(mBusinessUnitEnvironment, mTransactionEnvironment);

			try {

				// Create card
				vBecCard.createCard(vVoCardBusinessKey.getCardNumberString());

				// Connect to range
				vRange.connectCardNumber(vBecCard.getCard().getCardNumber());

			} catch (DuplicateCardException e) {
				// Card already exist with this cardnumber
				vAlreadyExists.add(vVoCardBusinessKey);
			}

		}

		// Create activation
		Activation vActivation = mBefActivation.create();
		vActivation.connectRange(vRange);
		mBefRange.save(vRange);
		mBefActivation.save(vActivation);

		return vAlreadyExists;
	}

	// ---------- Internal methods, must be protected so unit tests can access them ----------

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment()
		throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecCards without required BusinessUnitEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment()
		throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException("Tried to use BecCards without required TransactionEnvironment.");
	}

	

}
