/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public abstract class CardException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1730977826170174835L;

	public CardException() {
		super();
	}
	public CardException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidCard();
	}
}
