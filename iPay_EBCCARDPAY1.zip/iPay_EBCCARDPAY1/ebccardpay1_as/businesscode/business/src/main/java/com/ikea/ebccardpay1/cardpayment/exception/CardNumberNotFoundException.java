/*
 * Created on 2006-maj-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author anms
 *
 * CardNumberNotFoundException is thrown if a card number can not be found.
 */
public class CardNumberNotFoundException extends CardException {

	private static final long serialVersionUID = -2186258632964314805L;
	
	public CardNumberNotFoundException() {
		super();
	}
	public CardNumberNotFoundException(String pMessage) {
		super(pMessage);
	}

}
