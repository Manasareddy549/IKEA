/*
 * Created on 2007-apr-16
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.bef.BefBonus;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import static org.apache.commons.lang.Validate.notNull;
/**
 * @author anms
 *
 */
public class BecBonusesImpl implements BecBonuses {

	// Dependencies injected at creation of this BEC
	private BecBonus mBecBonus;
	private BefBonus mBefBonus;
	private BecCardNumber mBecCardNumber;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	/**
	 * 
	 */
	public BecBonusesImpl(
		BecBonus pBecBonus,
		BefBonus pBefBonus,
		BecCardNumber pBecCardNumber) {
		super();

		mBecBonus = pBecBonus;
		mBefBonus = pBefBonus;
		mBecCardNumber = pBecCardNumber;
	}

	void validate() {
		notNull(mBecBonus);
		notNull(mBefBonus);
		notNull(mBecCardNumber);
	}
	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#init(com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment)
	 */
	public BecBonuses init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	public List<VoBonusOnCard> findUnauthorized()
		throws IkeaException, ValueMissingException {

		List<VoBonusOnCard> vVoList = new ArrayList<VoBonusOnCard>();

		// Get bonuses for the logged in users country
		List<Bonus> vList = mBefBonus.findByUnauthorized(countryCodeForUser());

		for (Iterator<Bonus> i = vList.iterator(); i.hasNext();) {
			Bonus vBonus = (Bonus) i.next();
			// Let singel EBC do the extraction to VO
			mBecBonus.init(vBonus);
			VoBonusOnCard vVoBonusOnCard = mBecBonus.getVoBonusOnCard();
			vVoList.add(vVoBonusOnCard);
		}
		return vVoList;
	}

	// -----------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser()
		throws ValueMissingException, IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException("Tried to use BecBonuses without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

	public List<VoBonusComplete> findBonusLoads(VoBonusSearch pVoBonusSearch)
		throws ValueMissingException {

		List<Bonus> vList =
			mBefBonus.findBySearch(
				pVoBonusSearch.getBuType(),
				pVoBonusSearch.getBuCode(),
				pVoBonusSearch.getBonusCodeId(),
				pVoBonusSearch.getCountryCode(),
				pVoBonusSearch.getAuthorizedDateTime());

		List<VoBonusComplete> vBonusList = new LinkedList<VoBonusComplete>();

		for (Iterator<Bonus> i = vList.iterator(); i.hasNext();) {
			Bonus vBonus = (Bonus) i.next();

			// Let singel BEC do the extraction to VO
			mBecBonus.init(vBonus);
			VoBonusComplete vVoBonusComplete = new VoBonusComplete();
			vVoBonusComplete = mBecBonus.getVoBonus(pVoBonusSearch);

			// Map values that are not mapped automatic	
			vVoBonusComplete.setAmount(vBonus.getBonusAmount());
			vVoBonusComplete.setReleasedBy(vBonus.getAuthorizedBy());
			vVoBonusComplete.setReleasedDateTime(
				vBonus.getAuthorizedDateTime());
			vVoBonusComplete.setStatus(
				Constants.BONUS_SEARCH_CONSTANT_RELEASED);
			vVoBonusComplete.setName(
				Constants.BONUS_SEARCH_CONSTANT_SINGLE_BONUS);
			vVoBonusComplete.setLockCount(1);

			if (vBonus.getAmount() != null) {

				vVoBonusComplete.setBuCode(vBonus.getAmount().getBuCode());
				vVoBonusComplete.setBuType(vBonus.getAmount().getBuType());
			}

			if (vBonus.getAmount().getCard() != null) {

				vVoBonusComplete.setCardNumberString(
					mBecCardNumber.composeCardNumberString(
						vBonus.getAmount().getCard().getCardNumber()));
			}

			// Set the values for VoBonusCodeBrief			
			if (vBonus.getBonusCode() != null) {
				VoBonusCodeBrief vVoBonusCodeBrief = new VoBonusCodeBrief();
				ValueObjects.assignToValueObject(
					vVoBonusCodeBrief,
					vBonus.getBonusCode());

				vVoBonusComplete.setVoBonusCodeBrief(vVoBonusCodeBrief);
			}

			// Add VO to TreeSet
			vBonusList.add(vVoBonusComplete);
		}

		return vBonusList;

	}

}
