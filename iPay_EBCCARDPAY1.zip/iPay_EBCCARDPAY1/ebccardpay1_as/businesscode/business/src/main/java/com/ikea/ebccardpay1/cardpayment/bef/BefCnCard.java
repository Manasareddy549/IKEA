package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.CnCard;

public interface BefCnCard extends Bef<CnCard>{
	
	public void registerTheCards(long cnJobId);

}
