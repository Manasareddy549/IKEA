package com.ikea.ebccardpay1.cardpayment.utils;

import java.math.BigDecimal;
import java.util.Set;

import com.ikea.ebccardpay1.cardpayment.be.Amount;

public interface PriorityEvaluator {

	BigDecimal evaluatePriority(Set<Amount> pAmounts, int pBasePriority);
}
