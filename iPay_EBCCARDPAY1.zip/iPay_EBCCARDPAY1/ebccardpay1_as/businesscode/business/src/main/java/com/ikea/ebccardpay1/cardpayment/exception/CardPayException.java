/*
 * Created on 2006-aug-28
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.services.BusinessTask;
import com.ikea.ebcframework.error.ApplicationError;


/**
 * @author anms Do not declare CardPayException in your method signature.
 *         Declare the specific subclasses that can be thrown and detail when!
 */
public abstract class CardPayException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2747427220807059964L;

	private final static Logger mLog = LoggerFactory.getLogger(CardPayException.class);

	protected CardPayException() {
	}

	protected CardPayException(String pMessage) {
		super(pMessage);
	}

	public abstract ApplicationError createApplicationError();

	public void createApplicationErrors(BusinessTask pBt) {

		if (mLog.isInfoEnabled()) {
			mLog.info("Application exception stack trace:", this);
		}

		pBt.addApplicationError(createApplicationError());

		// Create a application error out of the detailed information if any
		String vMessage = getMessage();
		if (vMessage != null && vMessage.length() > 0) {
			pBt.addApplicationError(new EbcCardPay1ApplError.DetailedApplError(
					vMessage));
		}
	}
}
