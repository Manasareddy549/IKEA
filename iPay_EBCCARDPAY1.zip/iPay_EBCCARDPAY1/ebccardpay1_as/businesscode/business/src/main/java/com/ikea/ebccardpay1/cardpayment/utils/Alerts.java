/*
 * Created on 2007-apr-17
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface Alerts {

	/**
	 * 
	 * @param pMessage
	 * @throws IkeaException
	 */
	public void sendBuConfigurationAlert(String pMessage) throws IkeaException;
}
