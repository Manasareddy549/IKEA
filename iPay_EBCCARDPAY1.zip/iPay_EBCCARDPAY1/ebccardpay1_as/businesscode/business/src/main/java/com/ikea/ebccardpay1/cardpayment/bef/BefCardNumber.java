/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.math.BigDecimal;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;

public interface BefCardNumber extends Bef<CardNumber>{

	//iPay4.8.1- Sprint2
	public CardNumber findByCardNumber(String pIssuer, int pCardTypeDigit,  int pCheckDigit,String pEncAccountNumber);
	
	public boolean findCardEncrypted(String pIssuer,int pCardTypeDigit,String pAccountNumber,int pCheckDigit); 

	public java.util.List<CardNumber> findByRangeId(long pRangeId);
	//Added by Bisweswar
	public java.util.List<BigDecimal> findByCardNumberId(long pCradNumberId);

	public java.util.List<BigDecimal> findByRange(java.util.Collection<Range> pRanges, long pCurrentCardNumberId, int pMaxResultCount);

}