/*
 * Created on 2007-apr-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefCampaignLimitationImpl extends BefAbstract<CampaignLimitation> implements BefCampaignLimitation {

	/**
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCampaignLimitationImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<CampaignLimitation> getBusinessEntityClass() {
		return CampaignLimitation.class;
	}
}
