/*
 * Created on 2007-apr-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com
	.ikea
	.ebccardpay1
	.cardpayment
	.exception
	.CampaignLimitationNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;

/**
 * @author anms
 *
 */
public interface BecCampaignLimitation {

	/**
	 * 
	 * @param pCampaignLimitationId
	 * @return
	 * @throws CampaignLimitationNotFoundException
	 */
	public BecCampaignLimitation init(long pCampaignLimitationId)
		throws CampaignLimitationNotFoundException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public CampaignLimitation getCampaignLimitation()
		throws ValueMissingException;

	/**
	 * 
	 * @param pBuType
	 * @param pBuCode
	 */
	public void create(String pBuType, String pBuCode);

	/**
	 * 
	 * @throws ValueMissingException
	 */
	public void delete() throws ValueMissingException;


	/**
	 * 
	 * @throws ValueMissingException
	 */
	public void save() throws ValueMissingException;

}
