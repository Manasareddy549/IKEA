package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Collection;

/**
 */
public class ReportParameter {
	public static final String OPERATOR_EQUAL = "=";
	public static final String OPERATOR_LESS = "<";
	public static final String OPERATOR_LESS_OR_EQUAL = "<=";
	public static final String OPERATOR_GREATER = ">";
	public static final String OPERATOR_GREATER_OR_EQUAL = ">=";

	public static final String OPERATOR_SUBSTRING = "SUBSTR";
	public static final String OPERATOR_IN = "IN";

	private String mColumnName = null;
	private String mVariableName = null;
	private String mValue = null;
	private String mOperator = OPERATOR_EQUAL;
	private Collection<String> mValues = null;
	private Object mObjectValue = null;
	private String mParameterType = null;
	private boolean mUseObject = false;

	/**
	 * 
	 * @param pName
	 */
	public void setNames(String pName) {
		mColumnName = pName;
		mVariableName = pName;
	}

	/**
	 * 
	 * @param pName
	 */
	public void setNames(String pColumnName, String pVariableName) {
		mColumnName = pColumnName;
		mVariableName = pVariableName;
	}

	/**
	 * @return
	 */
	public String getColumnName() {
		return mColumnName;
	}

	/**
	 * @param string
	 */
	public void setColumnName(String string) {
		mColumnName = string;
	}

	/**
	 * @return
	 */
	public String getVariableName() {
		return mVariableName;
	}

	/**
	 * @param string
	 */
	public void setVariableName(String string) {
		mVariableName = string;
	}

	/**
	 * @return
	 */
	public String getOperator() {
		return mOperator;
	}

	/**
	 * @param i
	 */
	public void setOperator(String pOperator) {
		mOperator = pOperator;
	}

	/**
	 * @return
	 */
	public String getValue() {
		return mValue;
	}

	/**
	 * @param pValue
	 */
	public void setValue(String pValue) {
		mValue = pValue;
	}

	/**
	 * @return
	 */
	public Collection<String> getValues() {
		return mValues;
	}

	/**
	 * @param pValues
	 */
	public void setValues(Collection<String> pValues) {
		mValues = pValues;
	}

	/**
	 * @return
	 */
	public Object getObjectValue() {
		return mObjectValue;
	}

	/**
	 * @param pObjectValue
	 */
	public void setObjectValue(Object pObjectValue) {
		mObjectValue = pObjectValue;
	}

	/**
	 * @return
	 */
	public String getParameterType() {
		return mParameterType;
	}

	/**
	 * @param pParameterType
	 */
	public void setParameterType(String pParameterType) {
		mParameterType = pParameterType;
	}
	/**
	 * @return
	 */
	public boolean isUseObject() {
		return mUseObject;
	}

	/**
	 * @param pUseObject
	 */
	public void setUseObject(boolean pUseObject) {
		mUseObject = pUseObject;
	}

}
