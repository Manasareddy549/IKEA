package com.ikea.ebccardpay1.cardpayment.utils.entities;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Data")
public class Data implements Serializable{
	
	private String accountNumber;
	private String accountNumberEnc;
	private String transactionType;
	private long transactionId;
	private String transactionDateTime;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	@XmlElement(name = "AccountNumber")
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getAccountNumberEnc() {
		return accountNumberEnc;
	}
	
	@XmlElement(name = "AccountNumberEnc")
	public void setAccountNumberEnc(String accountNumberEnc) {
		this.accountNumberEnc = accountNumberEnc;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	
	@XmlElement(name = "TransactionType")
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public long getTransactionId() {
		return transactionId;
	}
	
	@XmlElement(name = "TransactionId")
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getTransactionDateTime() {
		return transactionDateTime;
	}
	
	@XmlElement(name = "TransactionDateTime")
	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	
	

}
