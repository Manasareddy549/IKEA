/*
 * Created on 2007-jan-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class ReferenceNotFound extends ReferenceCheckException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1612089643096095242L;

	/**
	 * @param pMessage
	 * @param pReference
	 */
	public ReferenceNotFound(
		String pSourceSystem,
		String pReference
		//String pSalesDay
		)
		{
		super(pSourceSystem, pReference);
				//pSalesDay
			
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.CardPayException#createApplicationError()
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ReferenceNotFound(
			mSourceSystem,
			mReference,
			mSalesDay);
	}

}
