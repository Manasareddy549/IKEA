/*
 * Created on 2007-sep-03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;
import java.util.List;
/**
 * @author dalq
 *
 *
 */
public interface BecMainCurrencies {

	public BecMainCurrencies init(List<VoMainCurrency> pVoMainCurrencyList);

	/**
	 * @param pVoCountry
	 */
	public void init(VoCountry pVoCountry);

	/**
	 * 
	 * @throws ValueMissingException
	 */
	public void manage() throws InvalidFromDateException,ValueMissingException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public List<VoMainCurrency> getMainCurrencyList()
		throws ValueMissingException;

}
