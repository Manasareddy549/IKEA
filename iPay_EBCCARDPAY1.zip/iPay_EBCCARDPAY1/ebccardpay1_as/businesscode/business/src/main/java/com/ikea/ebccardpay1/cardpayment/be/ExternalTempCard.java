/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class ExternalTempCard extends BusinessEntity {
	/**										
	 * Storage: EXTERNAL_TEMP_CARD_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mExternalTempCardId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;

	/**										
	 * Data								
	 */										
	private java.math.BigDecimal mBalance;
	private String mCurrencyCode;
	private String mBuType;
	private String mBuCode;
	private String mImportedRow;
	private String mImportedFile;
	private String mStatus;
	private String mExternalCardSystem;
	private String mIkeaCardType;
	private String mErrorMessage;	
	private String mCardNumberString;
	
	
	public long getExternalTempCardId() {
		return mExternalTempCardId;
	}
	/**
	 * @param pExternalTempCardId The externalTempCardId to set.
	 */
	public void setExternalTempCardId(long pExternalTempCardId) {
		mExternalTempCardId = pExternalTempCardId;
	}

	/**											
	 * @return Returns the cardNumberString.													
	 */											
	public String getCardNumberString() {
		return mCardNumberString;
	}
	/**
	 * @param pCardNumberString The cardNumberString to set.
	 */
	public void setCardNumberString(String pCardNumberString) {
		mCardNumberString = pCardNumberString;
	}

	/**											
	 * @return Returns the originalBalance.													
	 */											
	public java.math.BigDecimal getBalance() {
		return mBalance;
	}
	/**
	 * @param pOriginalBalance The originalBalance to set.
	 */
	public void setBalance(java.math.BigDecimal pBalance) {
		mBalance = pBalance;
	}

	/**											
	 * @return Returns the currencyCode.													
	 */											
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	/**
	 * @param pCurrencyCode The currencyCode to set.
	 */
	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the importedRow.													
	 */											
	public String getImportedRow() {
		return mImportedRow;
	}
	/**
	 * @param pImportedRow The importedRow to set.
	 */
	public void setImportedRow(String pImportedRow) {
		mImportedRow = pImportedRow;
	}

	public String getImportedFile() {
		return mImportedFile;
	}
	public void setImportedFile(String pImportedFile) {
		this.mImportedFile = pImportedFile;
	}
	public String getStatus() {
		return mStatus;
	}
	public void setStatus(String mStatus) {
		this.mStatus = mStatus;
	}
	/**											
	 * @return Returns the externalCardSystem.													
	 */											
	public String getExternalCardSystem() {
		return mExternalCardSystem;
	}
	/**
	 * @param pExternalCardSystem The externalCardSystem to set.
	 */
	public void setExternalCardSystem(String pExternalCardSystem) {
		mExternalCardSystem = pExternalCardSystem;
	}

	public String getIkeaCardType() {
		return mIkeaCardType;
	}
	public void setIkeaCardType(String pIkeaCardType) {
		this.mIkeaCardType = pIkeaCardType;
	}
	public String getErrorMessage() {
		return mErrorMessage;
	}
	public void setErrorMessage(String pErrorMessage) {
		this.mErrorMessage = pErrorMessage;
	}
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mExternalTempCardId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("externalTempCardId", CodeGeneration.toObject(mExternalTempCardId));
		vMap.put("cardNumberString", CodeGeneration.toObject(mCardNumberString));
		vMap.put("balance", CodeGeneration.toObject(mBalance));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("importedRow", CodeGeneration.toObject(mImportedRow));		
		vMap.put("importedFile", CodeGeneration.toObject(mImportedFile));
		vMap.put("status", CodeGeneration.toObject(mStatus));
		vMap.put("externalCardSystem", CodeGeneration.toObject(mExternalCardSystem));	
		vMap.put("ikeaCardType", CodeGeneration.toObject(mIkeaCardType));
		vMap.put("errorMessage", CodeGeneration.toObject(mErrorMessage));	
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("externalTempCardId")) mExternalTempCardId = CodeGeneration.objectTolong(pMap.get("externalTempCardId"));
		if(pMap.containsKey("cardNumberString")) mCardNumberString = CodeGeneration.objectToString(pMap.get("cardNumberString"));
		if(pMap.containsKey("balance")) mBalance = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("balance"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("importedRow")) mImportedRow = CodeGeneration.objectToString(pMap.get("importedRow"));	
		if(pMap.containsKey("importedFile")) mImportedFile = CodeGeneration.objectToString(pMap.get("importedFile"));
		if(pMap.containsKey("status")) mStatus = CodeGeneration.objectToString(pMap.get("status"));
		if(pMap.containsKey("externalCardSystem")) mExternalCardSystem = CodeGeneration.objectToString(pMap.get("externalCardSystem"));
		if(pMap.containsKey("ikeaCardType")) mIkeaCardType = CodeGeneration.objectToString(pMap.get("ikeaCardType"));
		if(pMap.containsKey("errorMessage")) mErrorMessage = CodeGeneration.objectToString(pMap.get("errorMessage"));
		
	}
}
