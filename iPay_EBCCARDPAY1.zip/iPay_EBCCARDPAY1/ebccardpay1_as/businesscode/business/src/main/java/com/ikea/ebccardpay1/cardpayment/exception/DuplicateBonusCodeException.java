/*
 * Created on 2007-apr-17
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class DuplicateBonusCodeException extends BonusCodeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -296278235865131232L;

	public DuplicateBonusCodeException() {
		super();
	}
	public DuplicateBonusCodeException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.DuplicateBonusCode();
	}
}
