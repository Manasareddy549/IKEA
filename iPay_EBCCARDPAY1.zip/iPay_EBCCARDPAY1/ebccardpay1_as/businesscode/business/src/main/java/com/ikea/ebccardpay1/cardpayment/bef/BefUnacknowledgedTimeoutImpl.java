/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.bef;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.UnacknowledgedTimeout;
import com.ikea.common.TimeSource;



public class BefUnacknowledgedTimeoutImpl extends BefAbstract<UnacknowledgedTimeout> implements BefUnacknowledgedTimeout {
	private final static Logger mLogger_findByUnacknowledgedTimeout =
		LoggerFactory.getLogger(
			BefUnacknowledgedTimeoutImpl.class.getName() + ".findByUnacknowledgedTimeout");

/**
* @param pSessionFactory
* @param pTimeSource
*/
public BefUnacknowledgedTimeoutImpl(SessionFactory pSessionFactory,
	TimeSource pTimeSource) {
super(pSessionFactory, pTimeSource);
}

@Override
protected Class<UnacknowledgedTimeout> getBusinessEntityClass() {
return UnacknowledgedTimeout.class;
}

public UnacknowledgedTimeout getUnacknowledgedTimeout(
		String pBuCode,String pBuType,String pSourceSystem) {
	Session vSession = mSessionFactory.getCurrentSession();

	String vHql =
		"from UnacknowledgedTimeout where buCode=:buCode and buType=:buType and sourceSystem=:sourceSystem";

	if (mLogger_findByUnacknowledgedTimeout.isDebugEnabled()) {
		mLogger_findByUnacknowledgedTimeout.debug("HQL: " + vHql);
	}

	UnacknowledgedTimeout vUnacknowledgedTimeout =
		(UnacknowledgedTimeout) vSession
			.createQuery(vHql)
			.setParameter("buCode", pBuCode)
			.setParameter("buType", pBuType)
			.setParameter("sourceSystem", pSourceSystem).uniqueResult();
	
	if (vUnacknowledgedTimeout == null) {
		mLogger_findByUnacknowledgedTimeout.debug("No unacknowledgedTimeoutId found.");
	}
	return vUnacknowledgedTimeout;
}
}