/*
 * Created on 2007-jan-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.cache.PrefetchCache;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebcframework.exception.IkeaException;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;


/**
 * @author anms
 *
 */
public class UnitsCacheImpl extends PrefetchCache implements UnitsCache {

	private final static Logger mCategory =
			LoggerFactory.getLogger(UnitsCacheImpl.class);

	// Should be dependency injected but since we do not create the cach our self this is good enough.
	private Alerts mAlerts = new AlertsImpl();

	/**
	 * Interator over units
	 * @see Unit
	 */
	private Iterator<Unit> mUnitIterator;

	/**
	 * Map with 'BU type'|'BU code' as key and Unit as value.
	 * @see Unit
	 */
	private HashMap<String, Unit> mUnitMap;


	private BefIpayBusinessUnits  mBefIpayBusinessUnits;


	/**
	 * Creates this cache. Must be public. Do not create your own instances,
	 * use getInstance!
	 * @see #getInstance
	 */
	public UnitsCacheImpl() {
		super();
	}


	/**
	 * Gets the instance of this cache (only one subset).
	 * @return a cache for BU information
	 */
	public static UnitsCacheImpl getInstance() {
		return (UnitsCacheImpl) getCache(UnitsCacheImpl.class.getName(), null);

	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#fetchSingle(java.lang.String)
	 */
	protected Object fetchSingle(String pObjectKey) throws Exception {
		throw new IllegalStateException("Internal error! Can not access fetchSingle, must wait until the cache is built.");
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UnitsCache#fetch()
	 */
	public Unit fetch(String pBuType, String pBuCode)
			throws BusinessUnitException {
		Unit vUnit = null;
		if (mCategory.isDebugEnabled()) {
			mCategory.debug(
					"Fetching info for " + pBuType + " " + pBuCode + ".");
		}
		try {
			vUnit = (Unit) fetchObject(key(pBuType, pBuCode));
		} catch (Exception e) {
			throw new BusinessUnitException(
					"Could not get BU info for "
							+ pBuType
							+ " "
							+ pBuCode
							+ ". Cause: "
							+ e.toString());
		}
		if (vUnit == null) {
			throw new BusinessUnitException(
					"No BU info for " + pBuType + " " + pBuCode + ".");
		}
		return vUnit;
	}
	/**
	 * Fetches the next object in the build process.
	 * @param pObjectKey a placeholder for the key. Append the key here as a string
	 * @return the object to cache with the key string value
	 * @throws Exception if some errors occurs
	 */
	protected Object fetchNext(StringBuffer pObjectKey) throws Exception {
		Object vObject = null;

		if (mUnitIterator != null) {
			if (mUnitIterator.hasNext()) {

				Unit vUnit = (Unit) mUnitIterator.next();
				// Create the key
				pObjectKey.append(key(vUnit.getBuType(), vUnit.getBuCode()));
				vObject = vUnit;
			}
		}
		return vObject;
	}
	/**
	 * Creates the key
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 */
	protected String key(String pBuType, String pBuCode) {
		return pBuType + "|" + pBuCode;
	}

	/**
	 * Returns the class name of the optimizer to use. If not implemented 
	 * serialize in Java will be used.
	 * You can use "com.ikea.cache.ZLIBObjectOptimizer" or "com.ikea.cache.ObjectOptimizer"
	 * or your own.
	 * @return the name of the class
	 * @see com.ikea.cache.ZLIBObjectOptimizer
	 * @see com.ikea.cache.ObjectOptimizer
	 */
	protected String getOptimizerProp() {
		return super.getOptimizerProp();
	}
	/**
	 * Gets the time out property. If zero it is never invalidated.
	 * @return the number of minutes the cache is valid, before it is reloaded
	 */
	protected int getTimeoutProp() {
		// 60 * 12 = Reload twice in one day.
		// 60 * 4 = Reload after 4 hours.
		return 60 * 4;
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#newObject(java.lang.String, java.io.ByteArrayInputStream)
	 */
	protected Object newObject(String pKey, ByteArrayInputStream pBytes)
			throws IOException {
		// Using default
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#objectToBytes(java.lang.Object, java.io.ByteArrayOutputStream)
	 */
	protected void objectToBytes(
			Object pObject,
			ByteArrayOutputStream pOStream)
					throws IOException {
		// Using default
	}

	/* (non-Javadoc)
	 * @see com.ikea.cache.ObjectCache#load()
	 */
	protected void load() throws Exception {
		mCategory.info("Loading...");
		super.load();
		mCategory.info("Loading done.");
	}

	/**
	 * Prepares for the building of the cache.
	 *
	 * @param pSubset the subset to build the cache for
	 * @return	Estimated number of objects this cache will contain. Return 0 if the number is unknown. Negative values are ignored.
	 * @throws Exception if some errors occurs
	 * @see #fetchNext
	 * @see #finalizeBuild
	 */
	protected int prepareBuild(String pSubset) throws Exception {

		mCategory.info("Building BU cache...");
		fetchAll();

		return mUnitMap.size();
	}
	/**
	 * Cleans up after the build process. This method will allways bee
	 * called, even if some exception occurs.
	 * Close connections and release other resourses.
	 * @throws Exception if some errors occurs
	 */
	protected void finalizeBuild() throws Exception {

		// Nothing to do.
		mCategory.info("Building BU cache done.");
	}

	/**
	 * Will get alla sites from CDS and put them in mUnitMap
	 */
	//@Transactional(readOnly=true)
	protected synchronized void fetchAll() throws Exception {
		try {
			mUnitMap = new HashMap<String, Unit>();
			List<IpayBusinessUnits> vDbList = mBefIpayBusinessUnits.findAll();

			if (vDbList!=null) {
				for (IpayBusinessUnits vBu:vDbList){
					mUnitMap.put(key(vBu.getId().getBuType(), vBu.getId().getBuCode()), new Unit(vBu));
				}
			}
			mUnitIterator = mUnitMap.values().iterator();


		} catch (Exception e) {
			sendAlert("Could not get sites from database");
			mCategory.error("Could not get sites from database", e);
			throw e;
		}
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer vBuff = new StringBuffer(this.getClass().getName());

		if (getInstance() != null
				|| getUnderlayingInstances() != null
				|| getUnderlayingInstances().values() != null) {

			for (Iterator<Unit> i = all().iterator(); i.hasNext();) {
				Unit vUnit = (Unit) i.next();
				vBuff.append("\r");
				vBuff.append(vUnit.getBuType());
				vBuff.append("\t");
				vBuff.append(vUnit.getBuCode());
				vBuff.append("\t");
				vBuff.append(vUnit.getCountryCode());
				vBuff.append("\t");
				vBuff.append(vUnit.getSiteName());
				vBuff.append("\t");
				vBuff.append(vUnit.getTimeZone());
				vBuff.append("\t");
				vBuff.append(vUnit.getCompanyCode());
				vBuff.append("\t");
				vBuff.append(vUnit.getCompanyName());

			}
		}

		return vBuff.toString();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UnitsCache#all()
	 */
	public Collection<Unit> all() throws BusinessUnitException {

		if (mCategory.isDebugEnabled()) {
			mCategory.debug("Fetching all BU info sorted");
		}
		if (getInstance() == null
				|| getUnderlayingInstances() == null
				|| getUnderlayingInstances().values() == null) {
			throw new BusinessUnitException("Internal error! You can not access this operation until the cache is built!");
		}

		// Return the Units sorted by BU
		Map<String,Unit> vSortedMap = new TreeMap<String,Unit>();
		vSortedMap.putAll(getUnderlayingInstances());

		return vSortedMap.values();
	}


	@SuppressWarnings("unchecked")
	private Map<String,Unit> getUnderlayingInstances() {
		return getInstance().ivInstances;
	}

	/**
	 * 
	 * @param pErrorString
	 * @throws IkeaException
	 */
	protected void sendAlert(String pErrorString) throws IkeaException {
		mCategory.error(pErrorString);
		mAlerts.sendBuConfigurationAlert(pErrorString);
	}


	void setBefIpayBusinessUnits(
			BefIpayBusinessUnits pBefIpayBusinessUnits) {
		Validate.notNull(pBefIpayBusinessUnits);
		mBefIpayBusinessUnits = pBefIpayBusinessUnits;

	}


}
