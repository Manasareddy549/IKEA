package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.bef.BefRange;
import com.ikea.ebccardpay1.cardpayment.exception.CardNumberNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRange;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRangeRef;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;

public class BecRangeImpl implements BecRange {

	private final static Logger mCategory =
			LoggerFactory.getLogger(BecRangeImpl.class);

	/**
	 * Dependencies
	 */
	private BecCardNumber mBecCardNumber = null;
	private BefRange mBefRange = null;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	private Range mRange = null;

	/**
	 * Dependecy injection
	 */
	protected BecRangeImpl(
			BecCardNumber pBecCardNumber,
			BefRange pBefRange) {

		mBecCardNumber = pBecCardNumber;
		mBefRange = pBefRange;
	}

	void validate() {
		notNull(mBecCardNumber);
		notNull(mBefRange);
	}
	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecRange#init(long)
	 */
	public BecRange init(long pRangeId) throws RangeNotFoundException {
		mRange = mBefRange.findByPrimaryKey(pRangeId);
		if (mRange == null) {
			throw new RangeNotFoundException("ID " + pRangeId);
		}
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecRange#init(com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment)
	 */
	public BecRange init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecRange#getRange()
	 */
	public Range getRange() throws ValueMissingException {
		requireRange();
		return mRange;
	}

	/* 
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecRange#importCardRange(com.ikea.ebccardpay1.cardpayment.vo.VoCardRange, com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber)
	 */
	public VoCardRange importCardRange(
			VoCardRange pVoCardRange,
			List<VoCardNumber> pVoCardNumberList)
					throws InvalidCardNumberException, IkeaException {

		// Log
		if (mCategory.isInfoEnabled()) {
			mCategory.info(CardPaymentLogger.cardRangeToString(pVoCardRange));
			mCategory.info(
					"Card number list size:" + pVoCardNumberList.size());
		}

		// Create or find existing entity
		Range vRange = null;
		if (pVoCardRange.getRangeId() == 0) {
			vRange = mBefRange.create();
		} else {
			vRange = mBefRange.findByPrimaryKey(pVoCardRange.getRangeId());
		}

		// Copy values from VO
		ValueObjects.assignToBusinessEntity(vRange, pVoCardRange);

		// Double check import state
		if ("START".equals(pVoCardRange.getImportState())) {
			vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_STARTED);
		} else if ("DONE".equals(pVoCardRange.getImportState())) {
			vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_COMPLETED);
		} else if ("FAILED".equals(pVoCardRange.getImportState())) {
			vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_FAILED);
		} else {
			vRange.setImportState(Constants.IMPORT_STATE_CONSTANT_UNKNOWN);
		}

		// Save entity
		mBefRange.save(vRange);

		// Copy back values to VO
		ValueObjects.assignToValueObject(pVoCardRange, vRange);

		// Save card numbers
		List<CardNumber> vList = new LinkedList<CardNumber>();
		for(VoCardNumber vVoCardNumber: pVoCardNumberList){
			// Find or create card number
			// Maybe we could optimize the search in the database tables, but we will do it wen we need it.
			try {
				mBecCardNumber.findCardNumber(
						vVoCardNumber.getCardNumberString());
			} catch (CardNumberNotFoundException e) {
				mBecCardNumber.createCardNumber(
						vVoCardNumber.getCardNumberString(),
						vVoCardNumber.getVerificationCode());
			}

			vList.add(mBecCardNumber.getCardNumber());
		}

		mBefRange.addCardNumbers(vRange, vList);

		return pVoCardRange;
	}

	//	@SuppressWarnings("unchecked")
	//	private Enumeration<VoCardNumber> getVoCardNumberEnumeration(
	//			List<VoCardNumber> pVoCardNumberList) {
	//		return pVoCardNumberList.getVoCardNumbers();
	//	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecRange#findCurrentCardRanges()
	 */
	public List<VoCardRangeRef> findCurrentCardRanges()
			throws ValueMissingException, IkeaException {

		List<Range> vList = mBefRange.findByCurrent(countryCodeForUser());

		List<VoCardRangeRef> vVoCardRangeRefList = new ArrayList<VoCardRangeRef>();
		for (Iterator<Range> i = vList.iterator(); i.hasNext();) {
			Range vRange = (Range) i.next();
			if(validRange(vRange))
			{
				VoCardRangeRef vVoCardRangeRef = new VoCardRangeRef();
				ValueObjects.assignToValueObject(vVoCardRangeRef, vRange);
				vVoCardRangeRefList.add(vVoCardRangeRef);
			}

		}

		return vVoCardRangeRefList;
	}

	// -----------------------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser()
			throws ValueMissingException, IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException("Tried to use BecRange without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireRange() throws ValueMissingException {
		if (mRange == null)
			throw new ValueMissingException("Tried to use BecRange without required Range.");
	}
	//Added by Bisweswar 
	public Range getCampaignRange(){
		return mBefRange.create();
	}

	public void saveRange(Range pRange){
		mBefRange.save(pRange);
	}

	public void addCardNumbers(Range vRange, List<CardNumber> vList){
		mBefRange.addCardNumbers(vRange, vList);
	}
	
	private boolean validRange(Range pRange)
	{
		Set<CardNumber> pCardNumberList=pRange.getCardNumbers();
		for(CardNumber pCardNumber:pCardNumberList)
		{
			if(pCardNumber.getCardTypeDigit()==0)
				return true;
			else
				return false;
		}
		
		return false;
		
	}

}
