/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;

public interface BefCampaignLimitation extends Bef<CampaignLimitation> {

}