/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class BonusCode extends BusinessEntity {
	/**										
	 * Storage: BONUS_CODE_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mBonusCodeId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<Amount> mAmount = new java.util.LinkedHashSet<Amount>(0);
	private java.util.Set<MassLoad> mMassLoad = new java.util.LinkedHashSet<MassLoad>(0);
	private java.util.Set<Bonus>  mBonus = new java.util.LinkedHashSet<Bonus>(0);

	/**										
	 * Data								
	 */										
	private long mCode;
	private String mName;
	private String mCountryCode;
	private java.util.Date mDisabledDateTime;
	private String mDisabledBy;

	/**											
	 * @return Returns the bonusCodeId.													
	 */											
	public long getBonusCodeId() {
		return mBonusCodeId;
	}
	/**
	 * @param pBonusCodeId The bonusCodeId to set.
	 */
	public void setBonusCodeId(long pBonusCodeId) {
		mBonusCodeId = pBonusCodeId;
	}

	/**											
	 * @return Returns the code.													
	 */											
	public long getCode() {
		return mCode;
	}
	/**
	 * @param pCode The code to set.
	 */
	public void setCode(long pCode) {
		mCode = pCode;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the disabledDateTime.													
	 */											
	public java.util.Date getDisabledDateTime() {
		return mDisabledDateTime;
	}
	/**
	 * @param pDisabledDateTime The disabledDateTime to set.
	 */
	public void setDisabledDateTime(java.util.Date pDisabledDateTime) {
		mDisabledDateTime = pDisabledDateTime;
	}

	/**											
	 * @return Returns the disabledBy.													
	 */											
	public String getDisabledBy() {
		return mDisabledBy;
	}
	/**
	 * @param pDisabledBy The disabledBy to set.
	 */
	public void setDisabledBy(String pDisabledBy) {
		mDisabledBy = pDisabledBy;
	}

	/**											
	 * @return Returns the amount.													
	 */											
	public java.util.Set<Amount> getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The amount to set.
	 */
	public void setAmount(java.util.Set<Amount> pAmount) {
		mAmount = pAmount;
	}

	/**											
	 * @return Returns the massLoad.													
	 */											
	public java.util.Set<MassLoad> getMassLoad() {
		return mMassLoad;
	}
	/**
	 * @param pMassLoad The massLoad to set.
	 */
	public void setMassLoad(java.util.Set<MassLoad> pMassLoad) {
		mMassLoad = pMassLoad;
	}

	/**											
	 * @return Returns the bonus.													
	 */											
	public java.util.Set<Bonus> getBonus() {
		return mBonus;
	}
	/**
	 * @param pBonus The bonus to set.
	 */
	public void setBonus(java.util.Set<Bonus>  pBonus) {
		mBonus = pBonus;
	}

	/**
	 * Connect a Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		getAmount().add(pAmount);
		if(pAmount != null) {
			pAmount.setBonusCode(this);
		}
	}

	/**
	 * Disconnect a Amount.
	 * @param pAmount
	 */
	public void disconnectAmount(Amount pAmount) {
		if(pAmount != null) {
			pAmount.setBonusCode(null);
		}
		getAmount().remove(pAmount);
	}

	/**
	 * Connect a MassLoad.
	 * @param pMassLoad
	 */
	public void connectMassLoad(MassLoad pMassLoad) {
		getMassLoad().add(pMassLoad);
		if(pMassLoad != null) {
			pMassLoad.setBonusCode(this);
		}
	}

	/**
	 * Disconnect a MassLoad.
	 * @param pMassLoad
	 */
	public void disconnectMassLoad(MassLoad pMassLoad) {
		if(pMassLoad != null) {
			pMassLoad.setBonusCode(null);
		}
		getMassLoad().remove(pMassLoad);
	}

	/**
	 * Connect a Bonus.
	 * @param pBonus
	 */
	public void connectBonus(Bonus pBonus) {
		getBonus().add(pBonus);
		if(pBonus != null) {
			pBonus.setBonusCode(this);
		}
	}

	/**
	 * Disconnect a Bonus.
	 * @param pBonus
	 */
	public void disconnectBonus(Bonus pBonus) {
		if(pBonus != null) {
			pBonus.setBonusCode(null);
		}
		getBonus().remove(pBonus);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mBonusCodeId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("bonusCodeId", CodeGeneration.toObject(mBonusCodeId));
		vMap.put("code", CodeGeneration.toObject(mCode));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("disabledDateTime", CodeGeneration.toObject(mDisabledDateTime));
		vMap.put("disabledBy", CodeGeneration.toObject(mDisabledBy));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("bonusCodeId")) mBonusCodeId = CodeGeneration.objectTolong(pMap.get("bonusCodeId"));
		if(pMap.containsKey("code")) mCode = CodeGeneration.objectTolong(pMap.get("code"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("disabledDateTime")) mDisabledDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("disabledDateTime"));
		if(pMap.containsKey("disabledBy")) mDisabledBy = CodeGeneration.objectToString(pMap.get("disabledBy"));
	}
}
