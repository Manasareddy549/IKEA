/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.common.TimeSource;
import com.ikea.mdsd.BusinessEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * @author tpon
 *
 * @param <T> The BusinessEnity the Bef is used for.
 */
public abstract class BefAbstract<T extends BusinessEntity> implements Bef<T>, InitializingBean {

	private static final Logger mLog = LoggerFactory.getLogger(BefAbstract.class);

	protected SessionFactory mSessionFactory = null;
	protected TimeSource mTimeSource = null;

	protected HibernateTemplate mHibernateTemplate = null;

    @Autowired
    private BsContext bsContext;
	//@Override
	public void afterPropertiesSet() throws Exception {
		Validate.notNull(bsContext, "Validation of BefAbstract member variable bsContext failed: the value is null");
		
	}

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	protected BefAbstract(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		mSessionFactory = pSessionFactory;
		mTimeSource = pTimeSource;
		mHibernateTemplate = new HibernateTemplate(mSessionFactory);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#create()
	 */
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.Bef#create()
	 */
	@SuppressWarnings("unchecked")
	public T create() {
		Class<T> businessEntityClass = getBusinessEntityClass();
		T vEntity = (T) BeanUtils.instantiateClass(businessEntityClass);
		vEntity.setCreatedDateTime(mTimeSource.currentDate());
		vEntity.setCreatedBy(bsContext.getUserProfile().getUID());
		return vEntity;
	}

	protected abstract Class<T> getBusinessEntityClass();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#save(Amount)
	 */
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.Bef#save(T)
	 */
	public void save(T pEntity) {
		if (pEntity != null) {
			if(mLog.isDebugEnabled()){
				mLog.debug("Saving a " + getBusinessEntityClass());
			}
			Session vSession = mSessionFactory.getCurrentSession();
			vSession.save(pEntity);
			vSession.flush();
		}
	}

	public void update(T pEntity){
		if(pEntity !=null){
		
			if(mLog.isDebugEnabled()){
				mLog.debug("Updating a " + getBusinessEntityClass());
			}
			
			Session vSession = mSessionFactory.getCurrentSession();
			vSession.update(pEntity);
			vSession.flush();
		}
	}
	
	public void saveOrUpdate(T pEntity){
		
		if(pEntity !=null){
			
			if(mLog.isDebugEnabled()){
				mLog.debug("Updating a " + getBusinessEntityClass());
			}
			
			Session vSession = mSessionFactory.getCurrentSession();
			vSession.saveOrUpdate(pEntity);
			vSession.flush();
		
	}
	}
	
	public void merge(T pEntity){
		if(pEntity !=null){
		
			if(mLog.isDebugEnabled()){
				mLog.debug("Updating a " + getBusinessEntityClass());
			}
			
			Session vSession = mSessionFactory.getCurrentSession();
			vSession.merge(pEntity);
			vSession.flush();
		}
	}
	
	public Session getOpenSession(){
	return mSessionFactory.openSession();
}

    public Session getCurrentSession(){
		return mSessionFactory.getCurrentSession();
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#findByPrimaryKey(long)
	 */
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.Bef#findByPrimaryKey(long)
	 */
	@SuppressWarnings("unchecked")
	public T findByPrimaryKey(long pId) {
		Session vSession = mSessionFactory.getCurrentSession();
		T vEntity = (T) vSession.load(getBusinessEntityClass(), new Long(pId));
		return vEntity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#findAll()
	 */
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.Bef#findAll()
	 */
	@Transactional(propagation=Propagation.SUPPORTS)
	public java.util.List<T> findAll() {
		Session vSession = mSessionFactory.getCurrentSession();
		GenericCriteria<T> vCriteria = new GenericCriteria<T>(vSession.createCriteria(getBusinessEntityClass()));
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return vCriteria.list();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#delete(Amount) {
	 */
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.Bef#delete(T)
	 */
	public void delete(T pEntity) {
		Session vSession = mSessionFactory.getCurrentSession();
		vSession.delete(pEntity);
		vSession.flush();
		pEntity.setBusinessEntityDeleted();
	}
}