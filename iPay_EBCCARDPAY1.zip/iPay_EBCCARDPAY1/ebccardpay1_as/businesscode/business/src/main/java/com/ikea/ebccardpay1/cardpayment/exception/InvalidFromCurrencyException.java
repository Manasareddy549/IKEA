/*
 * Created on 2007-sep-10
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *
 */
public class InvalidFromCurrencyException extends CurrencyException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7012729549476448340L;


	/**
	 * 
	 */
	public InvalidFromCurrencyException() {
		super();

	}

	/**
	 * @param message
	 */
	public InvalidFromCurrencyException(String message) {
		super(message);

	}


	public ApplicationError createApplicationError() {
		
		return new EbcCardPay1ApplError.InvalidFromCurrency();
	}

}
