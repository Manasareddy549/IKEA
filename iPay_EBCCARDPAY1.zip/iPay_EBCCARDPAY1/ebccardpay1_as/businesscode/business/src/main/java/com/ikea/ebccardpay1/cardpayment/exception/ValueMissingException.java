/*
 * Created on 2006-aug-04
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoReference;
import com.ikea.ebcframework.exception.IkeaException;
import java.util.List;

/**
 * @author anms
 * ValueMissingException is thrown if a required value is missing to perform the business logic.
 * All inpit values to a BT should be checked in the method validate().
 */
public class ValueMissingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2166458329535991297L;

	public ValueMissingException() {
		super();
	}
	public ValueMissingException(String pMessage) {
		super(pMessage);
	}

	public IkeaException createIkeaException() {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic.",this);
	}

	public IkeaException createIkeaException(String pCardNumberString) {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic. Card number '"
				+ CardPaymentLogger.cardNumberToString(pCardNumberString)
				+ "'.",this);
	}

	public IkeaException createIkeaException(VoReference pVoReference) {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic. Reference '"
				+ pVoReference.getReference()
				+ "'.",this);
	}

	public IkeaException createIkeaException(VoCampaign pVoCampaign) {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic. Campaign name '"
				+ pVoCampaign.getName()
				+ "'.",this);
	}

	public IkeaException createIkeaException(VoMassLoad pMassLoad) {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic. Mass Load name '"
				+ pMassLoad.getName()
				+ "'.",this);
	}

	public IkeaException createIkeaException(List<VoCountry> pVoCountryList) {
		return new IkeaException(
			"Internal error. Missing required value to perform the buisness logic for Country'.",this);
	}

}
