/*
 * Created on 2007-aug-09
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidAmountTypeException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystemBrief;
import com.ikea.mdsd.ValueObjects;

/**
 * @author anms
 *
 */
public class BecExternalCardSystemImpl implements BecExternalCardSystem {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecExternalCardSystemImpl.class);

	// Dependencies injected at creation of this BEC
	private BefExternalCardSystem mBefExternalCardSystem;
	private BecFactory mBecFactory;
	private Constants mConstants;
	private Units mUnits;

	// Entities that this BEC operates on
	private ExternalCardSystem mExternalCardSystem;

	// Related Bec's that this Bec delegates work to

	/**
	 * 
	 */
	public BecExternalCardSystemImpl(
		BefExternalCardSystem pBefExternalCardSystem,
		BecFactory pBecFactory,
		Constants pConstants,
		Units pUnits) {

		super();
		mBefExternalCardSystem = pBefExternalCardSystem;
		mBecFactory = pBecFactory;
		mConstants = pConstants;
		mUnits = pUnits;
	}

	void validate() {
		notNull(mBefExternalCardSystem);
		notNull(mBecFactory);
		notNull(mConstants);
		notNull(mUnits);
	}
	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#init(com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem)
	 */
	public BecExternalCardSystem init(ExternalCardSystem pExternalCardSystem) {
		mExternalCardSystem = pExternalCardSystem;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#init(String)
	 */
	public BecExternalCardSystem init(String pExternalCardSystemName) {
		mExternalCardSystem =
			mBefExternalCardSystem.findByName(pExternalCardSystemName, null);
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#getExternalCardSystem()
	 */
	public ExternalCardSystem getExternalCardSystem() {
		return mExternalCardSystem;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#findAllCompleted()
	 */
	public List<VoExternalCardSystemBrief> findAllCompleted() {
		List<ExternalCardSystem> vAll = mBefExternalCardSystem.findAll();

		List<VoExternalCardSystemBrief> vCompleted =
			new ArrayList<VoExternalCardSystemBrief>();

		for (Iterator<ExternalCardSystem> i = vAll.iterator(); i.hasNext();) {
			ExternalCardSystem vExternalCardSystem =
				(ExternalCardSystem) i.next();

			// Only add external card systems with completeted imports
			if (Constants
				.IMPORT_STATE_CONSTANT_COMPLETED
				.equals(vExternalCardSystem.getImportState())) {

				VoExternalCardSystemBrief vVoExternalCardSystemBrief =
					new VoExternalCardSystemBrief();
				ValueObjects.assignToValueObject(
					vVoExternalCardSystemBrief,
					vExternalCardSystem);
				vCompleted.add(
					vVoExternalCardSystemBrief);
			}
		}

		return vCompleted;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#nextAvailableInternalNumber()
	 */
	public CardNumber nextAvailableInternalNumber()
		throws ValueMissingException, InvalidCardNumberException {
		requireExternalCardSystem();

		long vCurrent = mExternalCardSystem.getCurrentAccountNumber();
		long vInitial = mExternalCardSystem.getInitialAccountNumber();
		long vMax = mExternalCardSystem.getMaxAccountNumber();

		if (vCurrent <= 0) {
			vCurrent = vInitial;
		} else {
			vCurrent++;
		}

		if (vCurrent > vMax) {
			throw new InvalidCardNumberException(
				"We have reached the maximun ("
					+ vMax
					+ ") in the internal card range for external card system '"
					+ mExternalCardSystem.getName()
					+ "'.");
		}
		mExternalCardSystem.setCurrentAccountNumber(vCurrent);
		// Save it now so we get constraint error id if some one else have updated this row
		mBefExternalCardSystem.save(mExternalCardSystem);

		// Create utils BEC to help create a new internal card number
		BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();
		vBecCardNumber.createCardNumber(
			mExternalCardSystem.getIssuer(),
			mExternalCardSystem.getCardTypeDigit(),
			vCurrent);

		return vBecCardNumber.getCardNumber();
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExternalCardSystem#importExternalCards(com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystem, com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard)
	 */
	public VoExternalCardSystem importExternalCards(
		VoExternalCardSystem pVoExternalCardSystem,
		List<VoExternalCard> pVoExternalCardList)
		throws
			InvalidCardNumberException,
			DuplicateExternalCardSystem,
			ValueMissingException,
			InvalidAmountTypeException {

		mCategory.info(
			"External card system name: "
				+ pVoExternalCardSystem.getName()
				+ " External card number list size:"
				+ pVoExternalCardList.size());

		// Check if this is the first post in the import	
		if (pVoExternalCardSystem.getImportState() == null
			|| pVoExternalCardSystem.getImportState().equals("")) {

			//Check if the ExternalCardSystem already exist with IMPORT_STATE != COMPLETED
			mExternalCardSystem =
				mBefExternalCardSystem.findByName(
					pVoExternalCardSystem.getName(),
					Constants.IMPORT_STATE_CONSTANT_COMPLETED);

			if (mExternalCardSystem == null) {

				// Try to create new ExternalCardSystem. SQL Error if it exist with import_state COMPLETED
				mExternalCardSystem = mBefExternalCardSystem.create();
				assignValues(pVoExternalCardSystem);
			}

			// This is the beginning of the import set status flag
			mExternalCardSystem.setImportState(
				Constants.IMPORT_STATE_CONSTANT_STARTED);

			// Mandatory value in DB
			mExternalCardSystem.setCurrentAccountNumber(0);

			//Save ExternalCardSystem before creating the ExternalCards to get PK
			mBefExternalCardSystem.save(mExternalCardSystem);

			//If external cards exists but import state not COMPLETED. Try to delete
			BecExternalCard vBecExternalCard =
				mBecFactory.createBecExternalCard();
			int vDeleted =
				vBecExternalCard.deleteNotCompleted(mExternalCardSystem);
			mCategory.info(
				"Found and deleted" + vDeleted + " uncompleted external cards");

		} else {
			// External card system exists, find by name  in BEF
			mCategory.info(
				"ExternalCardSystem_ID exist lookup post in DB -  Name="
					+ pVoExternalCardSystem.getName());
			mExternalCardSystem =
				mBefExternalCardSystem.findByName(
					pVoExternalCardSystem.getName(),
					null);
			assignValues(pVoExternalCardSystem);

			// This External Card System is already imported OK
			if (mExternalCardSystem
				.getImportState()
				.equals(Constants.IMPORT_STATE_CONSTANT_COMPLETED)) {
				throw new DuplicateExternalCardSystem(
					"The External Card System with this name already exists in database, name: "
						+ mExternalCardSystem.getName());

			}

		}

		for(VoExternalCard vVoExternalCard : pVoExternalCardList){

			// Create BEC for ExternalCard
			BecExternalCard vBecExternalCard =
				mBecFactory.createBecExternalCard();

			// Call create method ExternalCard BEC
			vBecExternalCard.createExternalCard(
				vVoExternalCard,
				mExternalCardSystem);

		}

		// If last card line set IMPORT_STATUS = COMPLETED
		if (pVoExternalCardSystem.getIsLastCards()) {
			//This is the last card to import, set importstate to COMPLETED
			mExternalCardSystem.setImportState(
				Constants.IMPORT_STATE_CONSTANT_COMPLETED);
			mBefExternalCardSystem.save(mExternalCardSystem);
		}

		// Assign external system BE values to new VO and return new VO
		VoExternalCardSystem vVoExternalCardSystem = new VoExternalCardSystem();
		ValueObjects.assignToValueObject(
			vVoExternalCardSystem,
			mExternalCardSystem);

		return vVoExternalCardSystem;
	}


	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void assignValues(VoExternalCardSystem pVoExternalCardSystem)
		throws
			ValueMissingException,
			InvalidCardNumberException,
			InvalidAmountTypeException {
		requireExternalCardSystem();

		// Copy to entity
		ValueObjects.assignToBusinessEntity(
			mExternalCardSystem,
			pVoExternalCardSystem);

		BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();

		// Check issuer
		vBecCardNumber.checkValidIssuer(mExternalCardSystem.getIssuer());

		// Check card type
		vBecCardNumber.checkCardTypeDigit(
			mExternalCardSystem.getCardTypeDigit());

		// Check amount type
		try {
			mConstants.checkValidAmountType(
				mExternalCardSystem.getAmountType());
		} catch (AmountTypeNotSupportedException e) {
			throw new InvalidAmountTypeException(e.toString());
		}

		// Check country code
		mUnits.checkValidCountryCode(mExternalCardSystem.getCountryCode());

		// Check regexp pattern
		Pattern.compile(mExternalCardSystem.getCardNumberPattern());

		// Check max > initial
		if (mExternalCardSystem.getInitialAccountNumber()
			> mExternalCardSystem.getMaxAccountNumber()) {
			throw new InvalidCardNumberException("Initial account number must be less than max account number");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireExternalCardSystem() throws ValueMissingException {
		if (mBefExternalCardSystem == null)
			throw new ValueMissingException("Tried to use BecExternalCardSystem without required ExternalCardSystem.");
	}
}
