/*
 * Created on 2007-dec-17
 *
 * 
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *
 */
public class AuthorizationAmountException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8780327241027722930L;

	/**
	 * 
	 */
	public AuthorizationAmountException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public AuthorizationAmountException(String pMessage) {
		super(pMessage);
	}

	/**
	 * 
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidAuthorizationAmount();
	}

}
