package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 */
public class ReportException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2180081305791869941L;

	public ReportException() {
		super();
	}

	public ReportException(String pMessage) {
		super(pMessage);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.exception.CardPayException#createApplicationError()
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidReport();
	}
}
