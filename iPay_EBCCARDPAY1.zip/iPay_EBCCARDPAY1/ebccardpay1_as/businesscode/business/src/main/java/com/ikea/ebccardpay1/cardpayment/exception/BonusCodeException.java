/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class BonusCodeException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4306534042246059540L;

	public BonusCodeException() {
		super();
	}
	public BonusCodeException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidBonusCode();
	}
}
