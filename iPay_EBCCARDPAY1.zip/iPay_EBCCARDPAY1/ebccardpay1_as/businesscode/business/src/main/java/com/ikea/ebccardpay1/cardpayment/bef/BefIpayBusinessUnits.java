package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefIpayBusinessUnits extends Bef<IpayBusinessUnits> {
	
	public IpayBusinessUnits findByPrimaryKey(String pBuType, String pBuCode);

}
