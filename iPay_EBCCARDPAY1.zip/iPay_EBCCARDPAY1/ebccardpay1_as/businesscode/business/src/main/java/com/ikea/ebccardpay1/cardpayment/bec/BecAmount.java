package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;

public interface BecAmount {

	/**
	 * @param pCard
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecAmount init(
			Card pCard,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pCard
	 * @param pAmount
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecAmount init(
			Card pCard,
			Amount pAmount,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param mRate
	 * @return 
	 */
	public BecAmount init(BigDecimal pRate);

	/**
	 * Creates a new amount of type CASH with required values set
	 *  
	 * @param pPriority The priority of the amount
	 * @return Itself as a convenience
	 * @throws ValueMissingException If card has not been set
	 */
	public BecAmount createCash(BigDecimal pPriority)
			throws ValueMissingException;

	/**
	 * Creates a new amount of type DISCOUNT with required values set
	 *
	 * @param pPriority The priority of the amount
	 * @return Itself as a convenience
	 * @throws ValueMissingException If card has not been set
	 */
	public BecAmount createDiscount(BigDecimal pPriority)
			throws ValueMissingException;

	/**
	 * Creates a new  Campaign amount of type DISCOUNT with required values set
	 *
	 * @param pPriority The priority of the amount
	 * @param pCampaign The Campaign
	 * @return Itself as a convenience
	 * @throws ValueMissingException If card has not been set
	 */

	public BecAmount createDiscountForCampaign(BigDecimal pPriority, Campaign pCampaign)
			throws ValueMissingException;


	//public void CampaignLoadtransaction(Campaign pCampaign) throws Exception;

	/**
	 * Loads the amount with given load amount. The currency is checked against the card
	 * and the amount is checked for negative values. The load operation also stores
	 * log entries in the transaction table. The load operation is defined for all amount
	 * types. The amount and card needs to be set before invoking load.
	 * 
	 * @param pVoLoadAmount The load amount to load
	 * @throws AmountException If load amount is not set or negative
	 * @throws CurrencyException If currency is not set or not same as card
	 * @throws ValueMissingException If required card, amount or TransactionEnvironment is not set
	 */
	public void load(VoLoadAmount pVoLoadAmount,String pSourceSystem,String pCardNumberString)
			throws AmountException, CurrencyException, ValueMissingException;

	/**
	 * Subtract an earlier loaded amount.
	 * 
	 * @param pVoLoadAmount The load amount to subtract
	 * @throws AmountException If load amount is not set or negative
	 * @throws ValueMissingException If required card, amount or TransactionEnvironment is not set
	 */
	public void undoLoad(VoLoadAmount pVoLoadAmount)
			throws ValueMissingException, AmountException;

	
	/**
	 * Rdeems the requested amount from the current amount. If the requested amount is less or equal
	 * than amount balance the balance is adjusted. If the balance is larger than the current balance
	 * the balance is reset. If isLastAmount is set this will lead to an insufficient amount response.
	 * The method returns the amount actually withdrawn from the balance.
	 * Note, no transaction entity is created for redeem!
	 * 
	 * @param pVoRequestAmount 
	 * @param pOriginalVoRequestAmount
	 * @param isLastAmount
	 * @return
	 * @throws AmountException
	 * @throws CurrencyException
	 * @throws ValueMissingException If required card, amount or TransactionEnvironment is not set
	 */
	
	public BigDecimal redeem(
			VoRequestAmount pVoRequestAmount,
			BigDecimal pRequestAmountInCardCurrency)
					throws AmountException, CurrencyException, ValueMissingException;

	/**
	 * Adds an earlier redeem amount.
	 * 
	 * @param pVoRedeemAmount
	 * @param isLastAmount
	 * @throws ValueMissingException If required card, amount or TransactionEnvironment is not set
	 */
	public void undoRedeem(VoRedeemAmount pVoRedeemAmount)
			throws ValueMissingException;

	/**
	 * @param pCampaign
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 */
	public void campaign(Campaign pCampaign)
			throws CurrencyException, AmountException, ValueMissingException;

	/**
	 * @param pMassLoad
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 */
	public void massLoad(MassLoad pMassLoad)
			throws CurrencyException, AmountException, ValueMissingException;

	/**
	 * 
	 * @param pBonus
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 */
	public void bonus(Bonus pBonus)
			throws CurrencyException, AmountException, ValueMissingException;

	/**
	 * 
	 * @param pMultipleSingleLoad
	 * @throws ValueMissingException 
	 * @throws CardPayException 
	 */
	void multipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pAmountValue) throws CardPayException, ValueMissingException;

	public BigDecimal redeemExpiredAmount(BigDecimal requestedAmount, BigDecimal inCardCurrency) throws AmountException, CurrencyException, ValueMissingException;

	public BigDecimal expirecampaign(Campaign pCampaign,Amount pAmount)
			throws CurrencyException, AmountException, ValueMissingException;

	public BigDecimal withdrawncampaign(Campaign pCampaign,Amount pAmount)
			throws CurrencyException, AmountException, ValueMissingException;

	public BigDecimal withdrawnMultipleSingleLoad() throws CurrencyException, AmountException, ValueMissingException;
}

