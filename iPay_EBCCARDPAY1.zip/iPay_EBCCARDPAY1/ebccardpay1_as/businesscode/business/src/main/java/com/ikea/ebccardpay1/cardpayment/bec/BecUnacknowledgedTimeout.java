/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.bec;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.UnacknowledgedTimeout;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;


public interface BecUnacknowledgedTimeout {
	
	/**
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecUnacknowledgedTimeout init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pCard
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecUnacknowledgedTimeout init(
		Card pCard,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);
	/**
	 * 
	 * @throws ReferenceCheckException
	 * @throws ValueMissingException
	 */
	public UnacknowledgedTimeout getUnacknowledgedTimeout(String pBuCode,String pBuType,String pSourceSystem)
		throws UnacknowledgedTimeoutException, ValueMissingException;

}
