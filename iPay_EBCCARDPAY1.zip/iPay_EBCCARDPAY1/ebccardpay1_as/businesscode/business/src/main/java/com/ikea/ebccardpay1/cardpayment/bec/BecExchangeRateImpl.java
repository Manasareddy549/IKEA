/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;
import static org.apache.commons.lang.Validate.notNull;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.vo.VoCountryKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.be.MainCurrency;
import com.ikea.ebccardpay1.cardpayment.bef.BefExchangeRate;
import com.ikea.ebccardpay1.cardpayment.bef.BefMainCurrency;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.common.TimeSource;
import com.ikea.mdsd.ValueObjects;

/**
 * @author dalq
 *
 *
 */
public class BecExchangeRateImpl implements BecExchangeRate {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecExchangeRateImpl.class);

	// Entities that this BEC operates on
	private ExchangeRate mExchangeRate;

	//	Dependencies injected at creation of this BEC
	private BefExchangeRate mBefExchangeRate = null;
	private BecFactory mBecFactory = null;
	private BefMainCurrency mBefMainCurrency = null;
	private TimeSource mTimeSource = null;

	//	Dependencies that need to be set
	private VoCountry mVoCountry = null;
	private List<MainCurrency> mMainCurrencies = null;

	/**
	 * 
	 * @param pBefExchangeRate
     * @param pBecFactory
     * @param pBefMainCurrency
     * @param pTimeSource
	 */
	public BecExchangeRateImpl(
		BefExchangeRate pBefExchangeRate,
		BecFactory pBecFactory,
		BefMainCurrency pBefMainCurrency,
		TimeSource pTimeSource) {
		mBefExchangeRate = pBefExchangeRate;
		mBecFactory = pBecFactory;
		mTimeSource = pTimeSource;
		mBefMainCurrency = pBefMainCurrency;
		//mBecCountry = pBecCountry;
	}

	void validate() {
		notNull(mBefExchangeRate);
		notNull(mBecFactory);
		notNull(mTimeSource);
		notNull(mBefMainCurrency);
	}
	/**
	 * 
	 */
	public BecExchangeRateImpl() {
		super();
	}

	/**
	 * @param pExchangeRateId
	 */
	public BecExchangeRate init(long pExchangeRateId) {
		mExchangeRate = mBefExchangeRate.findByPrimaryKey(pExchangeRateId);
		return this;

	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRate#init(com.ikea.ebccardpay1.cardpayment.vo.VoCountry)
	 */
	public void init(VoCountry pVoCountry) {
		mVoCountry = pVoCountry;
		mMainCurrencies = mBefMainCurrency.findAll();

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRate#getVoExchangeRate()
	 */
	public VoExchangeRate getVoExchangeRate() throws ValueMissingException {
		requireExchangeRate();

		VoExchangeRate vVoExchangeRate = new VoExchangeRate();

		ValueObjects.assignToValueObject(vVoExchangeRate, mExchangeRate);
		
		mCategory.debug(
			"Return VoExchangeRates From currency. "
				+ vVoExchangeRate.getFromCurrencyCode()
				+ "  To currency"
				+ vVoExchangeRate.getToCurrencyCode()
				+ " From date"
				+ vVoExchangeRate.getFromDate());

		return vVoExchangeRate;

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecExchangeRate#manage(com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRates)
	 */
	public void manage(VoExchangeRate pVoExchangeRate)
		throws
			InvalidFromDateException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException,
			ValueMissingException {

		if (Constants
			.OBJECT_STATE_NEW
			.equals(pVoExchangeRate.getObjectState())) {
			createExchangeRate(pVoExchangeRate);
		} else if (
			Constants.OBJECT_STATE_MODIFIED.equals(
			pVoExchangeRate.getObjectState())) {
			updateExchangeRate(pVoExchangeRate);
		} else if (
			Constants.OBJECT_STATE_READ.equals(
			pVoExchangeRate.getObjectState())) {
			// Sub entities are changed
			updateExchangeRate(pVoExchangeRate);
		} else {
			throw new ValueMissingException(
				"Illegal Object State set! Can not handle '"
					+ pVoExchangeRate.getObjectState()
					+ "'.");
		}

	}

	/**
	 * @param pVoExchangeRate
	 */
	protected void removeExchangeRate(VoExchangeRate pVoExchangeRate)
		throws ValueMissingException {

		init(pVoExchangeRate.getExchangeRateId());
		requireExchangeRate();

		mCategory.info(
			"Delete ExchangeRate - Id:" + pVoExchangeRate.getExchangeRateId());

		mBefExchangeRate.delete(mExchangeRate);

	}

	/**
	 * @param pVoExchangeRate
	 */
	protected void updateExchangeRate(VoExchangeRate pVoExchangeRate)
		throws
			InvalidFromDateException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException,
			ValueMissingException {

		//Check input values
		checkValues(pVoExchangeRate);

		mCategory.info(
			"Update ExchangeRate before INIT - FromCurrency:"
				+ pVoExchangeRate.getFromCurrencyCode()
				+ " ToCurrency:"
				+ pVoExchangeRate.getToCurrencyCode()
				+ " exchangeRate:"
				+ pVoExchangeRate.getExchangeRate()
				+ " exchangeRateID:"
				+ pVoExchangeRate.getExchangeRateId());

		init(pVoExchangeRate.getExchangeRateId());
		requireExchangeRate();

		mCategory.info(
			"Update ExchangeRate - FromCurrency:"
				+ pVoExchangeRate.getFromCurrencyCode()
				+ " ToCurrency:"
				+ pVoExchangeRate.getToCurrencyCode()
				+ " exchangeRate:"
				+ pVoExchangeRate.getExchangeRate());

		// Assign new values from VO to entity
		ValueObjects.assignToBusinessEntity(mExchangeRate, pVoExchangeRate);

		// Save updated entity
		mBefExchangeRate.save(mExchangeRate);

	}

	/**
	 * @param pVoExchangeRate
	 */
	protected void createExchangeRate(VoExchangeRate pVoExchangeRate)
		throws
			InvalidFromDateException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException,
			ValueMissingException {

		// Create new ExchangeRate
		requireVoCountry();

		//Check input values
		checkValues(pVoExchangeRate);

		mExchangeRate = mBefExchangeRate.create();
		mCategory.info(
			"Create new ExchangeRate - FromCurrency:"
				+ pVoExchangeRate.getFromCurrencyCode()
				+ " ToCurrency:"
				+ pVoExchangeRate.getToCurrencyCode()
				+ " exchangeRate:"
				+ pVoExchangeRate.getExchangeRate());

		// Assign to VO to Entity
		ValueObjects.assignToBusinessEntity(mExchangeRate, pVoExchangeRate);

		// Get the Country to connect the ExchangeRates with
		BecCountry vBecCountry = mBecFactory.createBecCountry();
        VoCountryKey voCountryKey = new VoCountryKey();
        voCountryKey.setCountryId(mVoCountry.getCountryId());
		vBecCountry.findCountry(voCountryKey);
		mExchangeRate.setCountry(vBecCountry.getCountry());

		// Save ExchangeRate
		mBefExchangeRate.save(mExchangeRate);
	}

	/**
	 * @param pVoExchangeRate
	 */
	protected void checkValues(VoExchangeRate pVoExchangeRate)
		throws
			ValueMissingException,
			InvalidFromDateException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException {

		mCategory.info(
			"CheckValues: From Currency '"
				+ pVoExchangeRate.getFromCurrencyCode()
				+ "' To currency '"
				+ pVoExchangeRate.getToCurrencyCode()
				+ "'.");

		if ("".equals(pVoExchangeRate.getExchangeRate())) {
			throw new ValueMissingException("Exchange rate  must not be empty");
		}

		if (pVoExchangeRate
			.getFromCurrencyCode()
			.equals(pVoExchangeRate.getToCurrencyCode())) {
			throw new InvalidToCurrencyException("From currency and to currency are the same");
		} // Input dates "FromDate" must not be before todays date (without time)
		DateTime vNow = new DateTime(mTimeSource.currentDate());
		if (pVoExchangeRate.getFromDate().before(Dates.withoutTime(vNow))) {
			throw new InvalidFromDateException(
				"From date '"
					+ pVoExchangeRate.getFromDate()
					+ "' is earlier than todays date '"
					+ Dates.withoutTime(vNow)
					+ "'.");
		}

	}

	protected void requireMainCurrencies() throws ValueMissingException {
		if (mMainCurrencies == null) {
			throw new ValueMissingException("Tried to use BecExchangeRate without required MainCurrencies.");
		}
	}

	protected void requireVoCountry() throws ValueMissingException {
		if (mVoCountry == null) {
			throw new ValueMissingException("Tried to use BecExchangeRate without required VoCountry.");
		}
	}

	protected void requireExchangeRate() throws ValueMissingException {
		if (mExchangeRate == null) {
			throw new ValueMissingException("Tried to use BecExchangeRate without required ExchangeRate.");
		}
	}

}
