package com.ikea.ebccardpay1.cardpayment.bef;


import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.*;
import com.ikea.common.TimeSource;

public class BefIpayBusinessUnitsImpl extends BefAbstract<IpayBusinessUnits> 
implements BefIpayBusinessUnits {
	
	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefIpayBusinessUnitsImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}
	
	@Override
	protected Class<IpayBusinessUnits> getBusinessEntityClass() {
		return IpayBusinessUnits.class;
	}

	public IpayBusinessUnits findByPrimaryKey(String pBuType, String pBuCode) {		
		IpayBusinessUnitsId key = new IpayBusinessUnitsId(pBuType,pBuCode);
		Session vSession = mSessionFactory.getCurrentSession();
		IpayBusinessUnits vEntity = (IpayBusinessUnits) vSession.load(getBusinessEntityClass(), key);
		return vEntity;
	}
}
