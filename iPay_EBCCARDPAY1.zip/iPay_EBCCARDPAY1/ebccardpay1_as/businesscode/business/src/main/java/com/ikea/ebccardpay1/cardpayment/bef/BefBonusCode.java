/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefBonusCode extends Bef<BonusCode>{

	public java.util.List<BonusCode> findByCurrent(String pCountryCode);

	public java.util.List<BonusCode> findBySearch(long pCode, String pName, String pCountryCode);

}