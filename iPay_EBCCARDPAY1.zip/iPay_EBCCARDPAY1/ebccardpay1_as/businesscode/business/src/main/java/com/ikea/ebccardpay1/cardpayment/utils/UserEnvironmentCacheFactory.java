package com.ikea.ebccardpay1.cardpayment.utils;
import static org.apache.commons.lang.Validate.notNull;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.cache.IkeaCacheFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

/**
 */

public class UserEnvironmentCacheFactory implements InitializingBean {

	@Autowired
	private BefIpayBusinessUnits  mBefIpayBusinessUnits;
	

    private final IkeaCacheFactory ikeaCacheFactory;

    @Autowired
    public UserEnvironmentCacheFactory(IkeaCacheFactory ikeaCacheFactory){
        notNull(ikeaCacheFactory);
        this.ikeaCacheFactory = ikeaCacheFactory;
    }

    public UserEnvironmentCache build() {
        // Normal usage of the IkeaCacheFactory
    	UserEnvironmentCacheImpl cache = (UserEnvironmentCacheImpl)ikeaCacheFactory.getCache(UserEnvironmentCacheImpl.class.getName(), null);
        // Followed by custom wiring, impossible to achieve with Spring
        cache.setBefIpayBusinessUnits(mBefIpayBusinessUnits);
        return cache;
    }

	//@Override
	public void afterPropertiesSet() throws Exception {
		notNull(mBefIpayBusinessUnits);		
	}


}