package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;

public class UserEnvironmentCacheMock implements UserEnvironmentCache{

	private HashMap<String, UserEnvironment> users = new LinkedHashMap<String, UserEnvironment>();
	
	public UserEnvironment fetch(String pUserId) {
		if (users.get(pUserId) == null){
			VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
			vVoBusinessUnit.setBuCode("107");
			vVoBusinessUnit.setBuType("STO");
			vVoBusinessUnit.setCountryCode("SE");
			Set<String> vPrivileges = new HashSet<String>();
			users.put(pUserId,new UserEnvironment(pUserId,vVoBusinessUnit,vPrivileges));
		}
		return users.get(pUserId);
	}

	
}
