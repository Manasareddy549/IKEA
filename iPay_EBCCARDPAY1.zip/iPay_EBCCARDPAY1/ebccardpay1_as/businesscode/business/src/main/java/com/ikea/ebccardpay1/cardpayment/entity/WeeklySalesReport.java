package com.ikea.ebccardpay1.cardpayment.entity;

import java.util.ArrayList;
import java.util.List;

public class WeeklySalesReport {
	
	private String mYear;

	private String mWeek;
	
	private List<WeeklySalesReportRow> mRows;

	public void addRow(WeeklySalesReportRow pReportRow){
		if (mRows == null){
			mRows = new ArrayList<WeeklySalesReportRow>();
		}
		mRows.add(pReportRow);
	}
	
	public String getYear() {
		return mYear;
	}

	public void setYear(String pYear) {
		mYear = pYear;
	}

	public String getWeek() {
		return mWeek;
	}

	public void setWeek(String pWeek) {
		mWeek = pWeek;
	}

	public List<WeeklySalesReportRow> getRows() {
		return mRows;
	}

	public void addAll(List<WeeklySalesReportRow> pReportRows) {
		if (mRows == null){
			mRows = new ArrayList<WeeklySalesReportRow>();
		}
		mRows.addAll(pReportRows);
	}
	
}
