/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.exception.CountryException;
import com.ikea.ebccardpay1.cardpayment.exception.CountryNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountryKey;

/**
 * @author dalq
 *
 *
 */
public interface BecCountry {

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCountry getVoCountry() throws ValueMissingException;

	public VoCountry getVoCountrySubs() throws ValueMissingException;

	/**
	 * 
	 * @param pCountry
	 * @return
	 */
	public BecCountry init(Country pCountry);

	/**
	 * 
	 * @return
	 */
	public Country getCountry();

	/**
	 * @param pCountryKey
	 * @return
	 */
	public void findCountry(VoCountryKey pCountryKey);

	/**
	 * 
	 * Collects both ExternalRateList and MainCurrencyList in VO
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCountry getVoCountryComplete() throws ValueMissingException;

	/**
	 * @param vVoCountry
	 */
	public void manage(VoCountry pVoCountry)
		throws CountryException, ValueMissingException;

	/**
	 * @param country
	 */
	public BecCountry init(VoCountry country) throws ValueMissingException;

	/**
	 * 
	 */
	public void manageAll()
		throws
			InvalidFromDateException,
			ValueMissingException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException;

	/**
	 * @param vCountryCode
	 * @return
	 */
	public void findCountry(String pCountryCode)
		throws CountryNotFoundException;

}
