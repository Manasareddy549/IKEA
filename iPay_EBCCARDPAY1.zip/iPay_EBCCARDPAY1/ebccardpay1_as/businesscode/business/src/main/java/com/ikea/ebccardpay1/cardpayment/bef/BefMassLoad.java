/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

public interface BefMassLoad extends Bef<MassLoad>{

	public java.util.List<MassLoad> findByCurrentFilter(String pCountryCode, String pMassLoadState);

	public java.util.List<MassLoad> findByCurrent(String pCountryCode);

	public java.util.List<MassLoad> findByUnprocessed();

	public java.util.List<MassLoad> findBySearch(String pNameLike, String pBuType, String pBuCode, String pCountryCode, long pBonusCodId, java.util.Date pReleaseDateTime, java.util.Date pCreatedDateTime);
	
	public java.util.List<Transaction> getMassLoadedTranscation(MassLoad pMassLoad) throws Exception;

}