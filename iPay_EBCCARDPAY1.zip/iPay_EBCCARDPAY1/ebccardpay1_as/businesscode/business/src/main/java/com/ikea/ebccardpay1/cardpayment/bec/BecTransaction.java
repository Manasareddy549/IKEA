package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;

public interface BecTransaction {

	/**
	 * @param pCard
	 * @param pAmount
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecTransaction init(
			Card pCard,
			Amount pAmount,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pTransaction
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecTransaction init(
			Transaction pTransaction,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);

	/**
	 * 
	 * @param pAmount
	 */
	public void setAmount(Amount pAmount);

	/**
	 * 
	 * @param pMassLoad
	 */
	public void setMassLoad(MassLoad pMassLoad);

	/**
	 * Allows access to the transaction business entity managed by the
	 * controller
	 * 
	 *  @return The current transaction
	 */
	public Transaction getTransaction();

	/**
	 * Create a transaction that records a load of an amount
	 * 
	 * @param pLoadAmount The load amount to register
	 * @param pCurrencyCode The currency code to register
	 * @param pVoReference The transactional reference
	 */
	public void createLoadTransaction(
			BigDecimal pLoadAmount,
			String pCurrencyCode,
			BigDecimal pBalanceChangeInCardCurrency,
			String pSourceSystem,
			VoLoadAmount pVoLoadAmount,
			String pCardNumberString)
					throws ValueMissingException;

	/**
	 * Create a transaction that records a redeem of an amount
	 * 
	 * @param pVoRequestAmount The request amount to register
	 * @param pBalanceChange The balance change
	 * @param pInsufficientAmount True if it was insufficient amount
	 * @param pCardNumberString 
	 */
	public void createRedeemTransaction(
			VoRequestAmount pVoRequestAmount,
			BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange,
			boolean pInsufficientAmount, String pCardNumberString)
					throws ValueMissingException;
	
	/**
	 * Create a transaction that records a redeem of an amount
	 * 
	 * @param pVoRequestAmount The request amount to register
	 * @param pBalanceChange The balance change
	 * @param pInsufficientAmount True if it was insufficient amount
	 */
	public void createRedeemTransactionManual(
			VoRequestAmount pVoRequestAmount,
			BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange,
			boolean pInsufficientAmount, String pCardNumberString)
					throws ValueMissingException;
	
	public void createRedeemTransactionManual(
			VoRequestAmount pVoRequestAmount,
			BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange,
			boolean pInsufficientAmount,
			VoManualTransaction pVoManualTransaction, String pCardNumberString)
					throws ValueMissingException;

	/**
	 * Create a transaction that records a void of an original transaction
	 * 
	 * @param pOriginal The original transaction to void
	 */
	public void createVoidTransaction(Transaction pOriginal)
			throws TransactionException, ValueMissingException;
	
	/**
	 * Create a transaction that records a void of an original transaction
	 * 
	 * @param pOriginal The original transaction to void
	 */
	public void createVoidManualTransaction(Transaction pOriginal)
			throws TransactionException, ValueMissingException;

	/**
	 * 
	 * @param pBonus
	 * @throws TransactionException
	 * @throws ValueMissingException
	 */
	public void createBonusLoadTransaction(Bonus pBonus)
			throws TransactionException, ValueMissingException;

	/**
	 * Create a transaction that records a mass load
	 * 
	 * @param pMassLoad The mass load
	 */
	public void createMassLoadTransaction(MassLoad pMassLoad)
			throws TransactionException, ValueMissingException;

	/**
	 * 
	 * @param pMassLoad
	 * @throws TransactionException
	 * @throws ValueMissingException
	 */
	public void createWithdrawMassLoadTransaction(MassLoad pMassLoad)
			throws TransactionException, ValueMissingException;

	public void CampaignLoadtransaction(Campaign pCampaign , Amount pAmount) throws Exception;

	/**
	 * 
	 *
	 */
	public void cancelTransaction() throws ValueMissingException;

	/**
	 * 
	 * @param pAmount
	 */
	void createMultipleSingleLoadTransaction(Amount pAmount, MultipleSingleLoad pMultipleSingleLoad) throws ValueMissingException, IkeaException;

	public void createExpiredTransaction(Campaign pCampaign,BigDecimal pBigDecimal)
			throws TransactionException, ValueMissingException;

	public void createRedeemTransaction(
			BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange,
			boolean pInsufficientAmount,Amount pAmount,Card pCard,BigDecimal vCurrentAmount)
					throws ValueMissingException;

	public void createWithdrawnTransaction(Campaign pCampaign,BigDecimal pBigDecimal)
			throws TransactionException, ValueMissingException;
	public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction,Campaign pCampaign)
			throws TransactionException, ValueMissingException;
	public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction,Campaign pCampaign) 
			throws TransactionException, ValueMissingException;

	public void CampaignDebiTransaction(Campaign pCampaign , Amount pAmount,String sales_Day) throws Exception;

	public void updateMassLoadedTransactions(Transaction pTransaction) 
			throws TransactionException, ValueMissingException;

	public void createWithdrawnMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad,BigDecimal pOriginalAmount,BigDecimal pCardBalanceChange)
			throws TransactionException, ValueMissingException;

	void publishTransactions();

}
