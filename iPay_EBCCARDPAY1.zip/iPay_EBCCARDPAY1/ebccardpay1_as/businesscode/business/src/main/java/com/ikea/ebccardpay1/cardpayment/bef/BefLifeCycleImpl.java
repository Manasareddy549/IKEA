/*
 * Created on 2006-june-16
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.LifeCycle;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 *
 */
public class BefLifeCycleImpl extends BefAbstract<LifeCycle> implements BefLifeCycle {

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefLifeCycleImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<LifeCycle> getBusinessEntityClass() {
		return LifeCycle.class;
	}
}
