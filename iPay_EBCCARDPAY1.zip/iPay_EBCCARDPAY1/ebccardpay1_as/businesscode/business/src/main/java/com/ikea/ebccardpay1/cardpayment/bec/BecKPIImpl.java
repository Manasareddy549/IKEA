package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.bef.BefKPI;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
/**
 *
 */
public class BecKPIImpl implements BecKPI {

	private final static Logger mCategory = LoggerFactory.getLogger(BecKPIImpl.class);

	// Dependencies injected at creation of this BEC
	private BefKPI mBefKPI = null;
	private TimeSource mTimeSource = null;
	private Units mUnits = null;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;
	/**
	 * Dependency injection
	 */
	protected BecKPIImpl(BefKPI pBefKPI, TimeSource pTimeSource, Units pUnits,BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefKPI = pBefKPI;
		mTimeSource = pTimeSource;
		mUnits = pUnits;
		mBefIpayBusinessUnits=pBefIpayBusinessUnits;
	}
	
	void validate() {
		notNull(mBefKPI);
		notNull(mTimeSource);
		notNull(mUnits);
	}
	

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBatchLog#findUncalculatedKPIDates(java.lang.String, java.lang.String)
	 */
	public List<String> findUncalculatedKPIDates(
		String pKPIType,
		String pBuType,
		String pBuCode,
		BefIpayBusinessUnits pBefIpayBusinessUnits) {
		List<String> vList = new LinkedList<String>();

		String vTimeZoneId = mUnits.getTimeZone(pBuType, pBuCode);

		DateTime vCalculationDateTime =
			Dates.localDateTime(mTimeSource.currentDate(), vTimeZoneId);

		mCategory.info(
			"Calculation date for "
				+ pBuType
				+ pBuCode
				+ " in local time: "
				+ CardPaymentLogger.jodaToString(vCalculationDateTime));

		// Find the last batch date for this BU
		String vLastKpiInterval =
			mBefKPI.findLastKPI(pKPIType, pBuType, pBuCode);

		if (vLastKpiInterval == null) {
			// If this is a new BU that we have not calculated KPI for, assume only previous day
			// Updated by srder to compare the Break hour with iPayBusinessunits value
			// If The value return from ipay business units is Null then break Hour is set to 3
			// or else the break hour will be compared with ipay business units value for the store.
			int vBreakhour = 0;

			IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(pBuType, pBuCode);

			if(vIpayBusinessUnits!=null){	
				if(	vIpayBusinessUnits.getBreakHour()!=null){

					vBreakhour= Integer.parseInt(vIpayBusinessUnits.getBreakHour());

				}else{
					vBreakhour=3;
				}
			}
			mCategory.info(
					"Break hour for"
						+ pBuType
						+ pBuCode
						+ ": "
						+ vBreakhour);
			
			if (!Dates.passedBreakingPoint(vCalculationDateTime,vBreakhour)) {
				// We are still in the last minutes(hours) of the previous sales day
				// -> We can not calculate for this date, go back one.
				vCalculationDateTime = Dates.withPrevDay(vCalculationDateTime);
			}
			vCalculationDateTime = Dates.withPrevDay(vCalculationDateTime);
			vList.add(Dates.formatDate(vCalculationDateTime));
		} else {

			mCategory.info(
				"Last KPI date found for "
					+ pBuType
					+ pBuCode
					+ " and '"
					+ pKPIType
					+ "' :"
					+ vLastKpiInterval);

			DateTime vNextKpiDate =
				Dates.parseDate(vLastKpiInterval, vTimeZoneId);
			
			// First set the breaking hour then go one day forward to next KPI date
			int vBreakhour = 0;

			IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(pBuType, pBuCode);

			if(vIpayBusinessUnits!=null){	
				if(	vIpayBusinessUnits.getBreakHour()!=null){

					vBreakhour= Integer.parseInt(vIpayBusinessUnits.getBreakHour());

				}else{
					vBreakhour=3;
				}
			}
			mCategory.info(
					"Break hour for"
						+ pBuType
						+ pBuCode
						+ ": "
						+ vBreakhour);
			vNextKpiDate = Dates.withBreakPoint(vNextKpiDate,vBreakhour);
			vNextKpiDate = Dates.withNextDay(vNextKpiDate);

			mCategory.debug(
				"Next KPI date beginning : "
					+ CardPaymentLogger.jodaToString(vNextKpiDate));

			// Back one day (can not calculate this day untill we have passed breaking hour of the next)
			vCalculationDateTime = Dates.withPrevDay(vCalculationDateTime);

			// Add days to batch date until we reach one day before calculation date
			while (vNextKpiDate.isBefore(vCalculationDateTime)) {
				mCategory.debug(
					"Adding because "
						+ CardPaymentLogger.jodaToString(vNextKpiDate)
						+ " is before "
						+ CardPaymentLogger.jodaToString(vCalculationDateTime));
				vList.add(Dates.formatDate(vNextKpiDate));
				vNextKpiDate = Dates.withNextDay(vNextKpiDate);
				mCategory.debug(
					"Next KPI date beginning: "
						+ CardPaymentLogger.jodaToString(vNextKpiDate));
			}
		}

		return vList;
	}

}
