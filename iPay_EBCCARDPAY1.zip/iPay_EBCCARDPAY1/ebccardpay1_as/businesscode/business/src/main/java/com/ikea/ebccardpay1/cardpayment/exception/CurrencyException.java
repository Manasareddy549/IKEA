/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;


/**
 * @author anms
 */
public class CurrencyException extends AmountException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1827922491297148585L;
	
	public CurrencyException() {
		super();
	}
	public CurrencyException(String pMessage) {
		super(pMessage);
	}
}
