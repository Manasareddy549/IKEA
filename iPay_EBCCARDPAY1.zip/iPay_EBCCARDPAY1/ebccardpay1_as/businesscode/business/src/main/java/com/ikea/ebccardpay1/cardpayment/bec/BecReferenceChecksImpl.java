package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebcframework.exception.IkeaException;

public class BecReferenceChecksImpl implements BecReferenceChecks {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecReferenceChecksImpl.class);

	/**
	 * Dependencies
	 */
	private BefReferenceCheck mBefReferenceCheck;
	private BecFactory mBecFactory;
    
    private UtilsFactory mUtilsFactory;
	/**
	 * Dependecy injection
	 * 
	 */
	protected BecReferenceChecksImpl(
		BefReferenceCheck pBefReferenceCheck,
		BecFactory pBecFactory, UtilsFactory pUtilsFactory) {

		mBefReferenceCheck = pBefReferenceCheck;
		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
	}

	
	public void validate() {
		notNull(mBefReferenceCheck);
		notNull(mBecFactory);
		notNull(mUtilsFactory);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#deleteOld()
	 */
	public int deleteOld() throws IkeaException {
		int vRowsDeleted = 0;
		mCategory.info(
			"Deleting acknowleded reference check entries for all stores.");

		// Get all BU
		List<VoBusinessUnit> vVoBusinessUnitList =
			mUtilsFactory.getUnits().allStores();

		// Group them by BU type
		Map<String, List<String>> vBuTypes = new HashMap<String, List<String>>();
		for(VoBusinessUnit vVoBusinessUnit : vVoBusinessUnitList){

			List<String> vBuCodes = vBuTypes.get(vVoBusinessUnit.getBuType());

			if (vBuCodes == null) {
				vBuTypes.put(vVoBusinessUnit.getBuType(), new ArrayList<String>());
				vBuCodes = vBuTypes.get(vVoBusinessUnit.getBuType());
			}

			vBuCodes.add(vVoBusinessUnit.getBuCode());
		}

		// Delete one BU type at a time
		for (Iterator<String> i = vBuTypes.keySet().iterator(); i.hasNext();) {
			String vBuType = (String) i.next();
			List<String> vBuCodes = vBuTypes.get(vBuType);

			int vRowsDeletedOneBuType =
				mBefReferenceCheck.deleteAcknowledged(vBuType, vBuCodes);
			if (mCategory.isInfoEnabled()) {
				mCategory.info(
					"Deleted "
						+ vRowsDeletedOneBuType
						+ " reference checks for BU type: "
						+ vBuType
						+ " BU codes: "
						+ vBuCodes);
			}
			vRowsDeleted += vRowsDeletedOneBuType;
		}

		return vRowsDeleted;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#undoUnAcknowledged()
	 */
	public int cancelOldUnacknowledged()
		throws ValueMissingException, AmountException {

		int vCancelledTransactions = 0;
		int vMinutes = 60;

		mCategory.info(
			"Cancelling unacknowledged transactions older than "
				+ vMinutes
				+ " minutes.");

		List<ReferenceCheck> vList = mBefReferenceCheck.findByWaitingAckOlderThan(vMinutes);

		if (vList == null || vList.size() == 0) {
			mCategory.info(
				"No old transactions waiting for acknowledgement found.");
			return vCancelledTransactions;
		}
		mCategory.info(
			"Found "
				+ vList.size()
				+ " unacknowledged transactions older than "
				+ vMinutes
				+ " minutes.");

		for (Iterator<ReferenceCheck> i = vList.iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();

			BecReferenceCheck vBecReferenceCheck =
				mBecFactory.createBecReferenceCheck();
			vBecReferenceCheck.cancelTransaction(vReferenceCheck);
			vCancelledTransactions++;
		}

		return vCancelledTransactions;
	}

	

	// ---------- Internal methods, must be protected so unit tests can access them ----------

}
