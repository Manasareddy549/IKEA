package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

/**
 * @author sakha60
 *
 */
public class Message extends BusinessEntity {
	/**										
	 * Storage: MESSAGE_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mMessageId;
	
	
	/**										
	 * Common attributes	
	 */		
	private java.util.Date mCreatedDateTime;
	private java.util.Date mUpdatedDateTime;
	private String mCreatedBy;
	private String mUpdatedBy;
	
	/**
	 * BLOB File
	 */
	private java.sql.Blob mMessage;

	

	
	public long getMessageId() {
		return mMessageId;
	}

	public void setMessageId(long mMessageId) {
		this.mMessageId = mMessageId;
	}

	/**
	 * @return Returns the createdDateTime
	 */
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	/**
	 * @param createdDateTime The createdDateTime to set
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**
	 * @return Returns the updatedDateTime
	 */
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	/**
	 * @param updatedDateTime The updatedDateTime to set
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/**
	 * @return Returns the createdBy
	 */
	public String getCreatedBy() {
		return mCreatedBy;
	}

	/**
	 * @param createdBy The createdBy to set
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**
	 * @return Returns the updatedBy
	 */
	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	/**
	 * @param updatedBy The updatedBy to set
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**
	 * @return Returns the sarecFile
	 */
	public java.sql.Blob getMessage() {
		return mMessage;
	}

	/**
	 * @param saarecFile The sarecFile to set
	 */
	public void setMessage(java.sql.Blob pMessage) {
		mMessage = pMessage;
	}
}
