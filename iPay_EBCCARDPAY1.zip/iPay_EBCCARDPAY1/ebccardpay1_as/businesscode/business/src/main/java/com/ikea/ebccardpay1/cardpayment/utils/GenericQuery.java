package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Parameter;
import javax.persistence.TemporalType;

import org.hibernate.CacheMode;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.LockOptions;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.type.Type;

@SuppressWarnings("unchecked")
public class GenericQuery<T> implements Query{

	Query mQuery;
	
	public int executeUpdate() throws HibernateException {
		return mQuery.executeUpdate();
	}

	public String[] getNamedParameters() throws HibernateException {
		return mQuery.getNamedParameters();
	}

	public String getQueryString() {
		return mQuery.getQueryString();
	}

	public String[] getReturnAliases() throws HibernateException {
		return mQuery.getReturnAliases();
	}

	public Type[] getReturnTypes() throws HibernateException {
		return mQuery.getReturnTypes();
	}

	public Iterator<T> iterate() throws HibernateException {
		return mQuery.iterate();
	}

	public List<T> list() throws HibernateException {
		return mQuery.list();
	}

	public ScrollableResults scroll() throws HibernateException {
		return mQuery.scroll();
	}

	public ScrollableResults scroll(ScrollMode scrollMode)
			throws HibernateException {
		return mQuery.scroll(scrollMode);
	}

	public GenericQuery<T> setBigDecimal(int position, BigDecimal number) {
		return new GenericQuery<T>(mQuery.setBigDecimal(position, number));
	}

	public GenericQuery<T> setBigDecimal(String name, BigDecimal number) {
		return new GenericQuery<T>(mQuery.setBigDecimal(name, number));
	}

	public GenericQuery<T> setBigInteger(int position, BigInteger number) {
		return new GenericQuery<T>(mQuery.setBigInteger(position, number));
	}

	public GenericQuery<T> setBigInteger(String name, BigInteger number) {
		return new GenericQuery<T>(mQuery.setBigInteger(name, number));
	}

	public GenericQuery<T> setBinary(int position, byte[] val) {
		return new GenericQuery<T>(mQuery.setBinary(position, val));
	}

	public GenericQuery<T> setBinary(String name, byte[] val) {
		return new GenericQuery<T>(mQuery.setBinary(name, val));
	}

	public GenericQuery<T> setBoolean(int position, boolean val) {
		return new GenericQuery<T>(mQuery.setBoolean(position, val));
	}

	public GenericQuery<T> setBoolean(String name, boolean val) {
		return new GenericQuery<T>(mQuery.setBoolean(name, val));
	}

	public GenericQuery<T> setByte(int position, byte val) {
		return new GenericQuery<T>(mQuery.setByte(position, val));
	}

	public GenericQuery<T> setByte(String name, byte val) {
		return new GenericQuery<T>(mQuery.setByte(name, val));
	}

	public GenericQuery<T> setCacheable(boolean cacheable) {
		return new GenericQuery<T>(mQuery.setCacheable(cacheable));
	}

	public GenericQuery<T> setCacheMode(CacheMode cacheMode) {
		return new GenericQuery<T>(mQuery.setCacheMode(cacheMode));
	}

	public GenericQuery<T> setCacheRegion(String cacheRegion) {
		return new GenericQuery<T>(mQuery.setCacheRegion(cacheRegion));
	}

	public GenericQuery<T> setCalendar(int position, Calendar calendar) {
		return new GenericQuery<T>(mQuery.setCalendar(position, calendar));
	}

	public GenericQuery<T> setCalendar(String name, Calendar calendar) {
		return new GenericQuery<T>(mQuery.setCalendar(name, calendar));
	}

	public GenericQuery<T> setCalendarDate(int position, Calendar calendar) {
		return new GenericQuery<T>(mQuery.setCalendarDate(position, calendar));
	}

	public GenericQuery<T> setCalendarDate(String name, Calendar calendar) {
		return new GenericQuery<T>(mQuery.setCalendarDate(name, calendar));
	}

	public GenericQuery<T> setCharacter(int position, char val) {
		return new GenericQuery<T>(mQuery.setCharacter(position, val));
	}

	public GenericQuery<T> setCharacter(String name, char val) {
		return new GenericQuery<T>(mQuery.setCharacter(name, val));
	}

	public GenericQuery<T> setComment(String comment) {
		return new GenericQuery<T>(mQuery.setComment(comment));
	}

	public GenericQuery<T> setDate(int position, Date date) {
		return new GenericQuery<T>(mQuery.setDate(position, date));
	}

	public GenericQuery<T> setDate(String name, Date date) {
		return new GenericQuery<T>(mQuery.setDate(name, date));
	}

	public GenericQuery<T> setDouble(int position, double val) {
		return new GenericQuery<T>(mQuery.setDouble(position, val));
	}

	public GenericQuery<T> setDouble(String name, double val) {
		return new GenericQuery<T>(mQuery.setDouble(name, val));
	}

	public GenericQuery<T> setEntity(int position, Object val) {
		return new GenericQuery<T>(mQuery.setEntity(position, val));
	}

	public GenericQuery<T> setEntity(String name, Object val) {
		return new GenericQuery<T>(mQuery.setEntity(name, val));
	}

	public GenericQuery<T> setFetchSize(int fetchSize) {
		return new GenericQuery<T>(mQuery.setFetchSize(fetchSize));
	}

	public GenericQuery<T> setFirstResult(int firstResult) {
		return new GenericQuery<T>(mQuery.setFirstResult(firstResult));
	}

	public GenericQuery<T> setFloat(int position, float val) {
		return new GenericQuery<T>(mQuery.setFloat(position, val));
	}

	public GenericQuery<T> setFloat(String name, float val) {
		return new GenericQuery<T>(mQuery.setFloat(name, val));
	}

	public GenericQuery<T> setFlushMode(FlushMode flushMode) {
		return new GenericQuery<T>(mQuery.setFlushMode(flushMode));
	}

	public GenericQuery<T> setInteger(int position, int val) {
		return new GenericQuery<T>(mQuery.setInteger(position, val));
	}

	public GenericQuery<T> setInteger(String name, int val) {
		return new GenericQuery<T>(mQuery.setInteger(name, val));
	}

	public GenericQuery<T> setLocale(int position, Locale locale) {
		return new GenericQuery<T>(mQuery.setLocale(position, locale));
	}

	public GenericQuery<T> setLocale(String name, Locale locale) {
		return new GenericQuery<T>(mQuery.setLocale(name, locale));
	}

	public GenericQuery<T> setLockMode(String alias, LockMode lockMode) {
		return new GenericQuery<T>(mQuery.setLockMode(alias, lockMode));
	}

	public GenericQuery<T> setLong(int position, long val) {
		return new GenericQuery<T>(mQuery.setLong(position, val));
	}

	public GenericQuery<T> setLong(String name, long val) {
		return new GenericQuery<T>(mQuery.setLong(name, val));
	}

	public GenericQuery<T> setMaxResults(int maxResults) {
		return new GenericQuery<T>(mQuery.setMaxResults(maxResults));
	}

	public GenericQuery<T> setParameter(int position, Object val, Type type) {
		return new GenericQuery<T>(mQuery.setParameter(position, val, type));
	}

	public GenericQuery<T> setParameter(int position, Object val)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameter(position, val));
	}

	public GenericQuery<T> setParameter(String name, Object val, Type type) {
		return new GenericQuery<T>(mQuery.setParameter(name, val, type));
	}

	public GenericQuery<T> setParameter(String name, Object val)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameter(name, val));
	}

	public GenericQuery<T> setParameterList(String name, Collection vals, Type type)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameterList(name, vals, type));
	}

	public GenericQuery<T> setParameterList(String name, Collection vals)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameterList(name, vals));
	}

	public GenericQuery<T> setParameterList(String name, Object[] vals, Type type)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameterList(name, vals, type));
	}

	public GenericQuery<T> setParameterList(String name, Object[] vals)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameterList(name, vals));
	}

	public GenericQuery<T> setParameters(Object[] values, Type[] types)
			throws HibernateException {
		return new GenericQuery<T>(mQuery.setParameters(values, types));
	}

	public GenericQuery<T> setProperties(Map bean) throws HibernateException {
		return new GenericQuery<T>(mQuery.setProperties(bean));
	}

	public GenericQuery<T> setProperties(Object bean) throws HibernateException {
		return new GenericQuery<T>(mQuery.setProperties(bean));
	}

	public GenericQuery<T> setReadOnly(boolean readOnly) {
		return new GenericQuery<T>(mQuery.setReadOnly(readOnly));
	}

	public GenericQuery<T> setResultTransformer(ResultTransformer transformer) {
		return new GenericQuery<T>(mQuery.setResultTransformer(transformer));
	}

	public GenericQuery<T> setSerializable(int position, Serializable val) {
		return new GenericQuery<T>(mQuery.setSerializable(position, val));
	}

	public GenericQuery<T> setSerializable(String name, Serializable val) {
		return new GenericQuery<T>(mQuery.setSerializable(name, val));
	}

	public GenericQuery<T> setShort(int position, short val) {
		return new GenericQuery<T>(mQuery.setShort(position, val));
	}

	public GenericQuery<T> setShort(String name, short val) {
		return new GenericQuery<T>(mQuery.setShort(name, val));
	}

	public GenericQuery<T> setString(int position, String val) {
		return new GenericQuery<T>(mQuery.setString(position, val));
	}

	public GenericQuery<T> setString(String name, String val) {
		return new GenericQuery<T>(mQuery.setString(name, val));
	}

	public GenericQuery<T> setText(int position, String val) {
		return new GenericQuery<T>(mQuery.setText(position, val));
	}

	public GenericQuery<T> setText(String name, String val) {
		return new GenericQuery<T>(mQuery.setText(name, val));
	}

	public GenericQuery<T> setTime(int position, Date date) {
		return new GenericQuery<T>(mQuery.setTime(position, date));
	}

	public GenericQuery<T> setTime(String name, Date date) {
		return new GenericQuery<T>(mQuery.setTime(name, date));
	}

	public GenericQuery<T> setTimeout(int timeout) {
		return new GenericQuery<T>(mQuery.setTimeout(timeout));
	}

	public GenericQuery<T> setTimestamp(int position, Date date) {
		return new GenericQuery<T>(mQuery.setTimestamp(position, date));
	}

	public GenericQuery<T> setTimestamp(String name, Date date) {
		return new GenericQuery<T>(mQuery.setTimestamp(name, date));
	}

	public T uniqueResult() throws HibernateException {
		return (T) mQuery.uniqueResult();
	}

	public GenericQuery(Query pQuery){
		mQuery = pQuery;
	}
	///////////////////

	//@Override
	public CacheMode getCacheMode() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public String getCacheRegion() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Integer getFetchSize() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public FlushMode getFlushMode() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Integer getTimeout() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public boolean isCacheable() {
		// TODO Auto-generated method stub
		return false;
	}

	//@Override
	public boolean isReadOnly() {
		// TODO Auto-generated method stub
		return false;
	}

	

	//@Override
	public String getComment() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Integer getFirstResult() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public LockOptions getLockOptions() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Query addQueryHint(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Integer getMaxResults() {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public Query setLockOptions(LockOptions arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
}
