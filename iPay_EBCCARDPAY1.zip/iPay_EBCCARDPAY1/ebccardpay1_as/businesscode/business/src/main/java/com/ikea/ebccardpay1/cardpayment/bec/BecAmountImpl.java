package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.IllegalAmountStateException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.services.EbcProperties;

import static org.apache.commons.lang.Validate.notNull;
import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.utils.UnitsCacheImpl;
import com.ikea.ebccardpay1.cardpayment.utils.Unit;

public class BecAmountImpl implements BecAmount {

	private final static Logger mLog = LoggerFactory.getLogger(BecAmountImpl.class);

	/**
	 * Dependencies
	 */
	private BefAmount mBefAmount;
	private BecTransaction mBecTransaction;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	/**
	 * Internal state
	 */
	private Card mCard;
	private Amount mAmount;
	private BusinessUnitEnvironment mBusinessUnitEnvironment;
	private BigDecimal mRate = null;

	/**
	 * Dependecy injection
	 */


	protected BecAmountImpl(
			BefAmount pBefAmount,
			BecTransaction pBecTransaction,
			BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefAmount = pBefAmount;
		mBecTransaction = pBecTransaction;
		mBefIpayBusinessUnits=pBefIpayBusinessUnits;
	}

	void validate() {
		notNull(mBefAmount);
		notNull(mBecTransaction);
		notNull(mBefIpayBusinessUnits);
	}


	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#init(com.ikea.ebccardpay1.cardpayment.be.Card, com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecAmount init(
			Card pCard,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		return init(
				pCard,
				null,
				pBusinessUnitEnvironment,
				pTransactionEnvironment);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#init(com.ikea.ebccardpay1.cardpayment.be.Card, com.ikea.ebccardpay1.cardpayment.be.Amount, com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecAmount init(
			Card pCard,
			Amount pAmount,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mAmount = pAmount;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;

		mBecTransaction.init(
				mCard,
				mAmount,
				mBusinessUnitEnvironment,
				pTransactionEnvironment);

		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#init(java.math.BigDecimal)
	 */
	public BecAmount init(BigDecimal pRate) {
		// Initiate exchange rate if it exist
		mRate = pRate;
		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#createCash(java.math.BigDecimal)
	 */
	public BecAmount createCash(BigDecimal pPriority)
	throws ValueMissingException {

		// Card and Business Unit must be set before calling createCash
		requireCard();
		requireBusinessUnitEnvironment();

		// Create a new amount and populate it with default values
		createDefault();
		mAmount.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_CASH);
		mAmount.setPriority(pPriority);

		mAmount.setBuType(mBusinessUnitEnvironment.getBuType());
		mAmount.setBuCode(mBusinessUnitEnvironment.getBuCode());

		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#createDiscount(java.math.BigDecimal)
	 */
	public BecAmount createDiscount(BigDecimal pPriority)
	throws ValueMissingException {

		// Card and Transaction Environment must be set before calling createCash
		requireCard();

		// Create a new amount and populate it with default values
		createDefault();
		mAmount.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		mAmount.setPriority(pPriority);

		// BU is not mandatory for discounts
		if (mBusinessUnitEnvironment != null) {
			mAmount.setBuType(mBusinessUnitEnvironment.getBuType());
			mAmount.setBuCode(mBusinessUnitEnvironment.getBuCode());
		}
		return this;
	}
	public BecAmount createDiscountForCampaign(BigDecimal pPriority , Campaign pCampaign)throws ValueMissingException{
		// Card and Transaction Environment must be set before calling createCash
		requireCard();

		// Create a new amount and populate it with default values
		createDefault();
		mAmount.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		mAmount.setPriority(pPriority);

		
		if(pCampaign.getCampaignLimitations().size()>1){
			calculateAndSaveSo(pCampaign , mAmount);
		}
		else{
			
			mAmount.setBuType(new ArrayList<CampaignLimitation>(pCampaign.getCampaignLimitations()).get(0).getBuType());
			mAmount.setBuCode(new ArrayList<CampaignLimitation>(pCampaign.getCampaignLimitations()).get(0).getBuCode());
			
	        //mAmount.connectCampaign(pCampaign);
		}
		return this;
	}
    public void calculateAndSaveSo(Campaign pCampaign, Amount mAmount){
		String countryCode = pCampaign.getCountryCode();
		UnitsCacheImpl unitsCache = UnitsCacheImpl.getInstance();
		Collection<Unit> allUnits  = unitsCache.all();
		
		for(Unit unit : allUnits){
			
			if(unit.getCountryCode().equalsIgnoreCase(countryCode)){
				if(unit.getBuType().equalsIgnoreCase("SO")){
				
					mAmount.setBuType(unit.getBuType());
					mAmount.setBuCode(unit.getBuCode());
				}
				
				
				
			}
		}
		
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#load(com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount)
	 */
	public void load(VoLoadAmount pVoLoadAmount,String pSourceSystem, String pCardNumberString)
	throws AmountException, CurrencyException, ValueMissingException {

		// Card and amount must be set before calling load
		requireCard();
		requireAmount();

		// Check only amount NOT currency to enable cross currency load
		checkAmount(pVoLoadAmount.getLoadAmount());

		// Add up the balance
		mAmount.setCurrentAmount(
				Amounts.add(
						mAmount.getCurrentAmount(),
						inCardCurrency(pVoLoadAmount.getLoadAmount())));
		mAmount.setOriginalAmount(
				Amounts.add(
						mAmount.getOriginalAmount(),
						inCardCurrency(pVoLoadAmount.getLoadAmount())));

		//Set balance change in card currency
		BigDecimal vBalanceChangeInCardCurrency =
			inCardCurrency(pVoLoadAmount.getLoadAmount());

		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(mAmount.getBuType(),mAmount.getBuCode());
		if (vIpayBusinessUnits != null)
			mAmount.setIpayBusinessUnits(vIpayBusinessUnits);

		//Save the amount before creating the transaction to get correct TRANSACTION_T.AMOUNT_ID 
		mBefAmount.save(mAmount);

		// Register the transaction
		mBecTransaction.createLoadTransaction(
				pVoLoadAmount.getLoadAmount(),
				pVoLoadAmount.getCurrencyCode(),
				vBalanceChangeInCardCurrency,
				pSourceSystem, pVoLoadAmount, pCardNumberString);

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Loaded "
					+ inCardCurrency(pVoLoadAmount.getLoadAmount())
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));

		}
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected BigDecimal inCardCurrency(BigDecimal pAmount) {
		if (mRate != null) {
			mLog.debug("Arithmetic multiply " + pAmount + " * " + mRate);
			BigDecimal vResult = Amounts.multiply(pAmount, mRate);
			mLog.debug("Arithmetic multiply result: " + vResult);
			return vResult;
		}
		return pAmount;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#undoLoad(com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount)
	 */
	public void undoLoad(VoLoadAmount pVoLoadAmount)
	throws ValueMissingException, IllegalAmountStateException {
		requireAmount();

		if (Amounts
				.isLess(
						mAmount.getCurrentAmount(),
						pVoLoadAmount.getLoadAmount())) {
			throw new IllegalAmountStateException(
					"Current amount is not enough. Current is '"
					+ mAmount.getCurrentAmount()
					+ "' requested undo a load of '"
					+ pVoLoadAmount.getLoadAmount()
					+ "'.");
		}

		// Subtract the loaded amount to the balance
		mAmount.setCurrentAmount(
				Amounts.subtract(
						mAmount.getCurrentAmount(),
						pVoLoadAmount.getLoadAmount()));
		mAmount.setOriginalAmount(
				Amounts.subtract(
						mAmount.getOriginalAmount(),
						pVoLoadAmount.getLoadAmount()));

		// Check if we get less than zero as result. Then we have internal problems...
		if (Amounts.isNegative(mAmount.getCurrentAmount())) {
			throw new IllegalAmountStateException("Tried to undo a load then current amount resulted in a negative amount.");
		}
		if (Amounts.isNegative(mAmount.getOriginalAmount())) {
			throw new IllegalAmountStateException("Tried to undo a load then original amount resulted in a negative amount.");
		}

		// Save the amount
		mBefAmount.save(mAmount);

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Unloaded "
					+ pVoLoadAmount.getLoadAmount()
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#redeem(com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount, boolean)
	 */
	public BigDecimal redeem(
			VoRequestAmount pVoRequestAmount,
			BigDecimal pRequestAmountInCardCurrency)
	throws AmountException, CurrencyException, ValueMissingException {

		// Card and amount must be set before calling redeem
		requireCard();
		requireAmount();

		// Check currency and amount
		checkAmount(pVoRequestAmount.getRequestAmount());
		checkAmount(pRequestAmountInCardCurrency);
		// Requested (Transaction) currency might be different from the card currency

		BigDecimal vCardBalanceChange = null;

		if (Amounts
				.isLessOrEqual(
						pRequestAmountInCardCurrency,
						mAmount.getCurrentAmount())) {

			// Set result to the current amount
			vCardBalanceChange = pRequestAmountInCardCurrency;

			// Reset the current amount
			mAmount.setCurrentAmount(
					Amounts.subtract(
							mAmount.getCurrentAmount(),
							vCardBalanceChange));
		} else {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.zero());
		}

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Requested "
					+ pVoRequestAmount.getRequestAmount()
					+ ". Redeemed in card currency: '"
					+ vCardBalanceChange
					+ "'. "
					+ CardPaymentLogger.amountToString(mAmount));
		}
		return vCardBalanceChange;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#undoRedeem(com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount, boolean)
	 */
	public void undoRedeem(VoRedeemAmount pVoRedeemAmount)
	throws ValueMissingException {

		requireAmount();

		// Add the redeemed amount to the balance
		mAmount.setCurrentAmount(
				Amounts.add(
						mAmount.getCurrentAmount(),
						pVoRedeemAmount.getRedeemAmount()));

		// Save the amount
		mBefAmount.save(mAmount);

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Unredeemed "
					+ pVoRedeemAmount.getRedeemAmount()
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#campaign(com.ikea.ebccardpay1.cardpayment.be.Campaign)
	 */
	public void campaign(Campaign pCampaign)
	throws CurrencyException, AmountException, ValueMissingException {

		// Card and amount must be set before calling camapign
		requireCard();
		requireAmount();

		// Check currency and amount
		checkCurrency(pCampaign.getCurrencyCode());
		checkAmount(pCampaign.getAmount());

		// Set the balance (Amount is never shared for Campaigns)
		//if(pCampaign.getCampaignState().equalsIgnoreCase(Constants.CAMPAIGN_STATE_CONSTANT_WITHDRAWN) ){
			//mAmount.setCurrentAmount(new BigDecimal(0));
		//}else{
			mAmount.setCurrentAmount(pCampaign.getAmount());
		//}
		mAmount.setOriginalAmount(pCampaign.getAmount());
		mAmount.setUpdatedBy(pCampaign.getUpdatedBy());
		mAmount.setUpdatedDateTime(pCampaign.getUpdatedDateTime());
		
		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(mAmount.getBuType(),mAmount.getBuCode());
        if (vIpayBusinessUnits != null)
                      mAmount.setIpayBusinessUnits(vIpayBusinessUnits);
		mAmount.setCampaign(pCampaign);
        mAmount.connectCampaign(pCampaign);
		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Loaded "
					+ pCampaign.getAmount()
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));
		}
	}
     
	// public void CampaignLoadtransaction(Campaign pCampaign) throws Exception{
		//mBecTransaction.CampaignLoadtransaction(pCampaign);
	//}
	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#massLoad(com.ikea.ebccardpay1.cardpayment.be.MassLoad)
	 * - modified by anagc on 16 feb 2016
	 */
	public void massLoad(MassLoad pMassLoad)
	throws CurrencyException, AmountException, ValueMissingException {

		// Card and amount must be set before calling camapign
		requireCard();
		requireAmount();

		// Check currency and amount
		checkCurrency(pMassLoad.getCurrencyCode());
		checkAmount(pMassLoad.getAmount());

		// Set the balance (Amount is never shared for Campaigns)
		mAmount.setCurrentAmount(pMassLoad.getAmount());
		mAmount.setOriginalAmount(pMassLoad.getAmount());
		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(mAmount.getBuType(),mAmount.getBuCode());
		if (vIpayBusinessUnits != null)
			mAmount.setIpayBusinessUnits(vIpayBusinessUnits);
		mAmount.setMassLoad(pMassLoad);
		mAmount.setBonusCode(pMassLoad.getBonusCode());
		String massloadState=pMassLoad.getWishedMassLoadState();
		if(massloadState.equalsIgnoreCase(Constants.MASS_LOAD_STATE_CONSTANT_LOCKED))
		{
			mAmount.setCurrentAmount(pMassLoad.getAmount());

			if (mLog.isInfoEnabled()) {
				mLog.info(
						"Loaded "
						+ pMassLoad.getAmount()
						+ ". "
						+ CardPaymentLogger.amountToString(mAmount));
			}
		}
		if(massloadState.equalsIgnoreCase(Constants.MASS_LOAD_STATE_CONSTANT_WITHDRAWN))
		{
			if (Amounts
					.isLessOrEqual(
							mAmount.getCurrentAmount(),
							pMassLoad.getAmount())) {
				mAmount.setCurrentAmount(
						Amounts.subtract(
								mAmount.getCurrentAmount(),
								pMassLoad.getAmount()));
			}


			if (mLog.isInfoEnabled()) {
				mLog.info(
						"Withdrawn "
						+ pMassLoad.getAmount()
						+ ". "
						+ CardPaymentLogger.amountToString(mAmount));
			}
		}
		//mBefAmount.save(mAmount);
	}

	public void multipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal vAmountValue) throws CardPayException, ValueMissingException {
		// Card and amount must be set before calling camapign
		requireCard();
		requireAmount();

		// Check currency and amount
		checkCurrency(pMultipleSingleLoad.getCurrencyCode());
		checkAmount(vAmountValue);

		// Set the balance (Amount is never shared for Campaigns)
		mAmount.setCurrentAmount(vAmountValue);
		mAmount.setOriginalAmount(vAmountValue);
		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(mAmount.getBuType(),mAmount.getBuCode());
		if (vIpayBusinessUnits != null)
			mAmount.setIpayBusinessUnits(vIpayBusinessUnits);
		pMultipleSingleLoad.connectAmount(mAmount);

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Loaded "
					+ vAmountValue
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecAmount#bonus(com.ikea.ebccardpay1.cardpayment.be.Bonus)
	 */
	public void bonus(Bonus pBonus)
	throws CurrencyException, AmountException, ValueMissingException {

		// Card and amount must be set before calling bonus
		requireCard();
		requireAmount();

		// Check currency and amount
		checkCurrency(pBonus.getCurrencyCode());
		checkAmount(pBonus.getBonusAmount());

		// Set the balance (Amount is never shared for Bonus)
		mAmount.setCurrentAmount(pBonus.getBonusAmount());
		mAmount.setOriginalAmount(pBonus.getBonusAmount());
		mAmount.setBonusCode(pBonus.getBonusCode());

		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(mAmount.getBuType(),mAmount.getBuCode());
		if (vIpayBusinessUnits != null)
			mAmount.setIpayBusinessUnits(vIpayBusinessUnits);
		mAmount.connectBonus(pBonus);

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Loaded "
					+ pBonus.getBonusAmount()
					+ ". "
					+ CardPaymentLogger.amountToString(mAmount));
		}
	}

	// ---------- Internal methods, must be protected so unit tests can access them ----------

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	protected BecAmount createDefault() throws ValueMissingException {

		// Card and Business Unit must be set before calling create
		requireCard();

		// Create a new amount and populate it with default values
		mAmount = mBefAmount.create();
		mAmount.setCurrentAmount(Amounts.zero());
		mAmount.setOriginalAmount(Amounts.zero());

		// Connect the new amount to the card (must do connect, must tell card that this amounts is connected)
		mAmount.connectCard(mCard);

		// We do not have to save the amount here, it will be saved when the card is saved.

		// Assign the new amount
		mBecTransaction.setAmount(mAmount);

		return this;
	}

	/**
	 * 
	 */
	protected void checkAmount(BigDecimal pAmount)
	throws ValueMissingException, AmountException {

		requireCard();

		// The amount must not be null, negative or zero
		if (pAmount == null) {
			throw new AmountException("Amount was null.");

		} else if (Amounts.isNegative(pAmount)) {
			throw new AmountException("Amount was negative.");

		} else if (Amounts.isZero(pAmount)) {
			throw new AmountException("Amount was zero.");
		}
	}

	/**
	 * 
	 */
	protected void checkCurrency(String pCurrencyCode)
	throws ValueMissingException, CurrencyException {

		requireCard();

		if (pCurrencyCode == null) {
			throw new CurrencyException("Currency was null.");

		} else if (
				mCard.getCurrencyCode() != null
				&& !pCurrencyCode.equals(mCard.getCurrencyCode())) {
			throw new CurrencyException(
					"Currency '"
					+ pCurrencyCode
					+ "' did not match card currency '"
					+ mCard.getCurrencyCode()
					+ "'.");
		}

	}

	/**
	 * Throws exception if mCard is not set
	 * 
	 * @throws ValueMissingException
	 */
	private void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException("Tried to use BecAmount without required Card.");
	}

	/**
	 * Throws exception if mAmount is not set
	 * 
	 * @throws ValueMissingException
	 */
	private void requireAmount() throws ValueMissingException {
		if (mAmount == null)
			throw new ValueMissingException("Tried to use BecAmount without required Amount.");
	}

	/**
	 * Throws exception if Business Unit Environment is not set
	 * 
	 * @throws ValueMissingException
	 */
	private void requireBusinessUnitEnvironment()
	throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecAmount without required Business Unit Environment.");
	}

	public void setBefIpayBusinessUnits(BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefIpayBusinessUnits= pBefIpayBusinessUnits;
	}
	
	//@Override
	public BigDecimal redeemExpiredAmount(BigDecimal requestedAmount,
			BigDecimal inCardCurrency) throws AmountException,
			CurrencyException, ValueMissingException {

		// Card and amount must be set before calling redeem
		requireCard();
		requireAmount();

		// Check currency and amount
		checkAmount(requestedAmount);
		checkAmount(inCardCurrency);
		// Requested (Transaction) currency might be different from the card
		// currency

		BigDecimal vCardBalanceChange = null;

		if (Amounts.isLessOrEqual(inCardCurrency, mAmount.getCurrentAmount())) {

			// Set result to the current amount
			vCardBalanceChange = inCardCurrency;

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.subtract(mAmount
					.getCurrentAmount(), vCardBalanceChange));
		} else {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.zero());
		}

		if (mLog.isInfoEnabled()) {
			mLog.info("Requested " + requestedAmount
					+ ". Redeemed in card currency: '" + vCardBalanceChange
					+ "'. " + CardPaymentLogger.amountToString(mAmount));
		}
		return vCardBalanceChange;
	}
	public BigDecimal expirecampaign(Campaign pCampaign,Amount pAmount)
			throws CurrencyException, AmountException, ValueMissingException
			{
		
		requireCard();
		requireAmount();



		BigDecimal vCardBalanceChange = null;

		if (Amounts
				.isLessOrEqual(mAmount.getCurrentAmount(),
						mAmount.getOriginalAmount()
						)) {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(
					Amounts.subtract(
							mAmount.getCurrentAmount(),
							vCardBalanceChange));
		} else {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.zero());
		}

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Requested "
					+ mAmount.getOriginalAmount()
					+ ". Redeemed in card currency: '"
					+ vCardBalanceChange
					+ "'. "
					+ CardPaymentLogger.amountToString(mAmount));
		}
		return vCardBalanceChange;
	}
	public BigDecimal withdrawncampaign(Campaign pCampaign,Amount pAmount)
			throws CurrencyException, AmountException, ValueMissingException
			{
		
		requireCard();
		requireAmount();



		BigDecimal vCardBalanceChange = null;

		if (Amounts
				.isLessOrEqual(mAmount.getCurrentAmount(),
						mAmount.getOriginalAmount()
						)) {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(
					Amounts.subtract(
							mAmount.getCurrentAmount(),
							vCardBalanceChange));
		} else {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.zero());
		}

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Requested "
					+ mAmount.getOriginalAmount()
					+ ". Redeemed in card currency: '"
					+ vCardBalanceChange
					+ "'. "
					+ CardPaymentLogger.amountToString(mAmount));
		}
		return vCardBalanceChange;
	}

	public BigDecimal withdrawnMultipleSingleLoad()
			throws CurrencyException, AmountException, ValueMissingException
			{
		
		requireCard();
		requireAmount();



		BigDecimal vCardBalanceChange = null;

		if (Amounts
				.isLessOrEqual(mAmount.getCurrentAmount(),
						mAmount.getOriginalAmount()
						)) {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(
					Amounts.subtract(
							mAmount.getCurrentAmount(),
							vCardBalanceChange));
		} else {

			// Set result to the current amount
			vCardBalanceChange = mAmount.getCurrentAmount();

			// Reset the current amount
			mAmount.setCurrentAmount(Amounts.zero());
		}

		if (mLog.isInfoEnabled()) {
			mLog.info(
					"Requested "
					+ mAmount.getOriginalAmount()
					+ ". Redeemed in card currency: '"
					+ vCardBalanceChange
					+ "'. "
					+ CardPaymentLogger.amountToString(mAmount));
		}
		return vCardBalanceChange;
	}


}
