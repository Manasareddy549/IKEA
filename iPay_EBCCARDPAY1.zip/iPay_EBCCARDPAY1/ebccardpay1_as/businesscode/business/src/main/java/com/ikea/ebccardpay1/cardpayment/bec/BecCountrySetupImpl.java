/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CountrySetup;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountrySetup;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountrySetup;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import static org.apache.commons.lang.Validate.notNull;
/**
 * @author anms
 *
 */
public class BecCountrySetupImpl implements BecCountrySetup {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecCountrySetupImpl.class);

	// Dependencies injected at creation of this BEC
	private BefCountrySetup mBefCountrySetup;

	// Entities that this BEC operates on
	private CountrySetup mCountrySetup;

	// Related Bec's that this Bec delegates work to

	/**
	 * 
	 */
	public BecCountrySetupImpl(BefCountrySetup pBefCountrySetup) {

		super();

		mBefCountrySetup = pBefCountrySetup;
	}

	void validate() {
		notNull(mBefCountrySetup);
		
	}
	public BecCountrySetup init(long pCountrySetupId) {
		mCountrySetup = mBefCountrySetup.findByPrimaryKey(pCountrySetupId);
		return this;
	}

	public BecCountrySetup init(CountrySetup pCountrySetup) {
		mCountrySetup = pCountrySetup;
		return this;
	}

	public CountrySetup getCountrySetup() {
		return mCountrySetup;
	}

	public VoCountrySetup getVoCountrySetup() throws ValueMissingException {

		requireCountrySetup();

		if (mCountrySetup.isBusinessEntityDeleted()) {
			return null;
		}

		VoCountrySetup vVoCountrySetup = new VoCountrySetup();
		ValueObjects.assignToValueObject(vVoCountrySetup, mCountrySetup);

		mCategory.debug(
			"Added Country Setup "
				+ vVoCountrySetup.getCountrySetupId()
				+ " "
				+ vVoCountrySetup.getCountryCode());

		return vVoCountrySetup;
	}

	public void manage(VoCountrySetup pVoCountrySetup)
		throws IkeaException, ValueMissingException, CountrySetupException {

		if (Constants
			.OBJECT_STATE_NEW
			.equals(pVoCountrySetup.getObjectState())) {
			createCountrySetup(pVoCountrySetup);
		} else if (
			Constants.OBJECT_STATE_MODIFIED.equals(
				pVoCountrySetup.getObjectState())) {
			updateCountrySetup(pVoCountrySetup);
		} else if (
			Constants.OBJECT_STATE_READ.equals(
				pVoCountrySetup.getObjectState())) {
			updateCountrySetup(pVoCountrySetup);
		} else if (
			Constants.OBJECT_STATE_REMOVED.equals(
				pVoCountrySetup.getObjectState())) {
			removeCountrySetup(pVoCountrySetup);
		} else {
			throw new ValueMissingException(
				"Illegal Object State set! Can not handle '"
					+ pVoCountrySetup.getObjectState()
					+ "'.");
		}

	}

	// -----------------------------------------------------

	/**
	 * @param vVoCountrySetup
	 * @throws IkeaException
	 */
	protected void createCountrySetup(VoCountrySetup pVoCountrySetup)
		throws IkeaException, ValueMissingException, CountrySetupException {

		mCountrySetup = mBefCountrySetup.create();

		mCategory.info(
			"Creating new Country Setup '"
				+ pVoCountrySetup.getCountryCode()
				+ "'.");

		ValueObjects.assignToBusinessEntity(mCountrySetup, pVoCountrySetup);
		mBefCountrySetup.save(mCountrySetup);
	}

	/**
	 * @param vVoCountrySetup
	 */
	protected void updateCountrySetup(VoCountrySetup pVoCountrySetup)
		throws ValueMissingException, CountrySetupException {

		init(pVoCountrySetup.getCountrySetupId());
		requireCountrySetup();

		mCategory.info(
			"Updating bonus code '" + pVoCountrySetup.getCountryCode() + "'.");

		ValueObjects.assignToBusinessEntity(mCountrySetup, pVoCountrySetup);
		mBefCountrySetup.save(mCountrySetup);
	}

	/**
	 * @param pVoCountrySetup
	 * @throws ValueMissingException
	 * @throws RangeNotFoundException
	 * @throws CountrySetupException
	 */
	protected void removeCountrySetup(VoCountrySetup pVoCountrySetup)
		throws ValueMissingException, CountrySetupException {

		init(pVoCountrySetup.getCountrySetupId());
		requireCountrySetup();

		mCategory.info(
			"Deleting Country Setup '"
				+ pVoCountrySetup.getCountryCode()
				+ "'.");

		mBefCountrySetup.delete(mCountrySetup);
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCountrySetup() throws ValueMissingException {
		if (mCountrySetup == null)
			throw new ValueMissingException("Tried to use BecCountrySetup without required CountrySetup.");
	}
}
