package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalTempCard;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;

public class BefExternalTempCardImpl extends BefAbstract<ExternalTempCard> implements BefExternalTempCard{

	private final static Logger mCategory_findByExternal =
			LoggerFactory.getLogger(
					BefExternalTempCardImpl.class.getName() + ".findByCardNumberString");

	public BefExternalTempCardImpl(
			SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);

	}
	protected Class<ExternalTempCard> getBusinessEntityClass() {
		return ExternalTempCard.class;
	}
	//@Override
	public List<ExternalTempCard> findByCardNumberString(String pCardNumberString) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<ExternalTempCard> vCriteria = new GenericCriteria<ExternalTempCard>(vSession.createCriteria(ExternalTempCard.class));
		vCriteria.add(
				Restrictions.eq("cardNumberString", pCardNumberString));

		// To get just one per card
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByExternal.isDebugEnabled()) {
			mCategory_findByExternal.debug("Criteria: " + vCriteria.toString());
		}

		List<ExternalTempCard> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByExternal.debug("No external card numbers found.");
		} else {
			mCategory_findByExternal.debug(
					"Found " + vList.size() + " external cards.");
		}
		return vList;
	}
	//@Override
	public List<ExternalTempCard> findByFileName(String pName) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<ExternalTempCard> vCriteria = new GenericCriteria<ExternalTempCard>(vSession.createCriteria(ExternalTempCard.class));
		vCriteria.add(
				Restrictions.eq("importedFile", pName));

		// To get just one per card
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByExternal.isDebugEnabled()) {
			mCategory_findByExternal.debug("Criteria: " + vCriteria.toString());
		}

		List<ExternalTempCard> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByExternal.info("No external card numbers found.");
		} else {
			mCategory_findByExternal.info(
					"Found " + vList.size() + " external cards.");
		}
		return vList;

	}
	//@Override
	public List<ExternalTempCard> findActiveCardsToTransfer(String pName,int count) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<ExternalTempCard> vCriteria = new GenericCriteria<ExternalTempCard>(vSession.createCriteria(ExternalTempCard.class));
		//TRANSFER
		ArrayList<String> vStates = new ArrayList<String>();


		vStates.add(Constants.CARD_STATUS_IMPORT);
		vStates.add(Constants.CARD_STATUS_CORRECTED);

		vCriteria.add(
				Restrictions.eq("importedFile", pName));

		vCriteria.add(Restrictions.in("status", vStates));

		vCriteria.setMaxResults(count);


		// To get just one per card
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByExternal.isDebugEnabled()) {
			mCategory_findByExternal.debug("Criteria: " + vCriteria.toString());
		}

		List<ExternalTempCard> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByExternal.info("No external card numbers found.");
		} else {
			mCategory_findByExternal.info(
					"Found " + vList.size() + " external cards.");
		}
		return vList;

	}
}
