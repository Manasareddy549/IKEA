/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.RangeNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaign;
import com.ikea.ebcframework.exception.IkeaException;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author anms
 *
 */
public interface BecCampaign {

	/**
	 * 
	 * @param pCampaignId
	 * @return
	 */
	public BecCampaign init(long pCampaignId);

	/**
	 * 
	 * @param pCampaign
	 * @return
	 */
	public BecCampaign init(Campaign pCampaign);

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecCampaign init(UserEnvironment pUserEnvironment);

	/**
	 * 
	 * @return
	 */
	public Campaign getCampaign() throws ValueMissingException;

	/**
	 * @return
	 * @throws ValueMissingException
	 */
	public VoCampaign getVoCampaign() throws ValueMissingException;

	/**
	 * @param vVoCampaign
	 * @throws IkeaException
	 */
	public void manage(VoCampaign vVoCampaign)
			throws
			IkeaException,
			ValueMissingException,
			RangeNotFoundException,
			CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void lock() throws ValueMissingException, CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void unlock() throws ValueMissingException, CampaignException;

	/**
	 * @throws ValueMissingException
	 */
	public void authorize()
			throws
			ValueMissingException,
			CampaignException,
			FourEyesException,
			IkeaException;

	/**
	 * @throws ValueMissingException
	 */
//	public void withdraw()
//			throws ValueMissingException, CampaignException, IkeaException;
			
	public void withdraw(VoCampaign pVoCampaign) throws ValueMissingException, CampaignException,IkeaException;

	/**
	 * @param pCampaignId
	 * @throws ValueMissingException
	 */
	 public int process(long pCampaignId)
		throws ValueMissingException, CampaignException, IkeaException;
		
//	public int process(long pCampaignId , VoCampaign pVoCampaign)
//			throws ValueMissingException, CampaignException, IkeaException;

	/**
	 * 
	 * @param pWishedState
	 * @param pCampaignId
	 * @throws ValueMissingException
	 * @throws CampaignException
	 */
	public void prepareForProcessing(String pWishedState, long pCampaignId)
			throws ValueMissingException, CampaignException;

	public List<Campaign> getExpiredCampaigns(Date pExpireDateFrom,Date pExpireDateUpto)throws ValueMissingException;

	public void processExpiredCampaignslist(List<Campaign> pCampign) throws ValueMissingException;
	
	 public void updateCampaignLoadTransactions_Aouthorization(Campaign pCampaign)throws Exception;

	public void afterPropertiesSet() throws Exception;
	
	//public void campaignTransaction_Withdrawal(Campaign pCampaign);
	//
}
