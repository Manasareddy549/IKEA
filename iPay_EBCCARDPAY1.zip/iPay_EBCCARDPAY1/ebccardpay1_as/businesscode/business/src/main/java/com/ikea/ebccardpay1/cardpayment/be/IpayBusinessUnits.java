
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class IpayBusinessUnits extends BusinessEntity {
	/**										
	 * Storage: REFERENCE_CHECK_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private IpayBusinessUnitsId mId;

	/**										
	 * Common attributes	
	 */		
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */			
	private java.util.Set<KPI>  mKPI = new java.util.LinkedHashSet<KPI>(0);
	private java.util.Set<KPI>  mKPI2 = new java.util.LinkedHashSet<KPI>(0);
	private java.util.Set<Amount>  mAmount = new java.util.LinkedHashSet<Amount>(0);

	/**										
	 * Data								
	 */										

	private String mBuName;
	private String mCountryCode;
	private String mCompanyCode;
	private String mCompanyName;
	private String mTimeZone;
	private String mBreakHour;



	/**											
	 * @return Returns the Id object.													
	 */											
	public IpayBusinessUnitsId getId() {
		if (mId==null){
			mId = new IpayBusinessUnitsId();
		}
		return mId;
	}
	
	/**											
	 * Sets the Id object.													
	 */											
	public void setId(IpayBusinessUnitsId pId) {
		mId = pId;
	}

	/**
	 * @param pBuName the buName to set
	 */
	public void setBuName(String pBuName) {
		mBuName = pBuName;
	}
	/**
	 * @return the buName
	 */
	public String getBuName() {
		return mBuName;
	}
	/**
	 * @param pCountryCode the countryCode to set
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCompanyCode the companyCode to set
	 */
	public void setCompanyCode(String pCompanyCode) {
		mCompanyCode = pCompanyCode;
	}
	/**
	 * @return the companyCode
	 */
	public String getCompanyCode() {
		return mCompanyCode;
	}
	/**
	 * @param pCompanyName the companyName to set
	 */
	public void setCompanyName(String pCompanyName) {
		mCompanyName = pCompanyName;
	}
	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return mCompanyName;
	}
	/**
	 * @param pTimeZone the timeZone to set
	 */
	public void setTimeZone(String pTimeZone) {
		mTimeZone = pTimeZone;
	}
	
	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return mTimeZone;
	}

	/**											
	 * @return Returns the KPI:s.												
	 */											
	public java.util.Set<KPI> getKpi() {
		return mKPI;
	}
	/**
	 * @param pKPI The KPI to set.
	 */
	public void setKpi(java.util.Set<KPI>  pKPI) {
		mKPI = pKPI;
	}

	/**											
	 * @return Returns the KPI2:s.												
	 */											
	public java.util.Set<KPI> getKpi2() {
		return mKPI2;
	}
	/**
	 * @param pKPI2 The KPI2 to set.
	 */
	public void setKpi2(java.util.Set<KPI>  pKPI2) {
		mKPI2 = pKPI2;
	}

	/**											
	 * @return Returns the Amount:s.												
	 */											
	public java.util.Set<Amount> getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The Amount to set.
	 */
	public void setAmount(java.util.Set<Amount>  pAmount) {
		mAmount = pAmount;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}
	/**											
	 * @param pBreakHour The BreakHour to set													
	 */	
	public void setBreakHour(String pBreakHour) {
		mBreakHour = pBreakHour;
	}
	/**											
	 * @return Returns the BreakHour.													
	 */	
	public String getBreakHour() {
		return mBreakHour;
	}
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();

		vMap.put("buType", CodeGeneration.toObject(mId.getBuType()));
		vMap.put("buCode", CodeGeneration.toObject(mId.getBuCode()));
		vMap.put("buName", CodeGeneration.toObject(mBuName));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("companyCode", CodeGeneration.toObject(mCompanyCode));
		vMap.put("companyName", CodeGeneration.toObject(mCompanyName));	
		vMap.put("timeZone", CodeGeneration.toObject(mTimeZone));	
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("breakHour", CodeGeneration.toObject(mBreakHour));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("buCode")) mId.setBuCode(CodeGeneration.objectToString(pMap.get("buCode")));
		if(pMap.containsKey("buType")) mId.setBuType(CodeGeneration.objectToString(pMap.get("buType")));
		if(pMap.containsKey("buName")) mBuName = CodeGeneration.objectToString(pMap.get("buName"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("companyCode")) mCompanyCode = CodeGeneration.objectToString(pMap.get("companyCode"));
		if(pMap.containsKey("companyName")) mCompanyName = CodeGeneration.objectToString(pMap.get("companyName"));
		if(pMap.containsKey("breakHour")) mBreakHour = CodeGeneration.objectToString(pMap.get("breakHour"));
		if(pMap.containsKey("timeZone")) mTimeZone = CodeGeneration.objectToString(pMap.get("timeZone"));

	}
}
