/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.KPI;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author tpon
 */
public class BefKPIImpl extends BefAbstract<KPI> implements BefKPI {

	private final static Logger mCategory_findLastKPI =
		LoggerFactory.getLogger(BefKPIImpl.class.getName() + ".findLastKPI");

	private final static Logger mCategory_calculate =
		LoggerFactory.getLogger(BefKPIImpl.class.getName() + ".calculate");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefKPIImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefKPI#findLastKPI(java.lang.String, java.lang.String, java.lang.String)
	 */
	public String findLastKPI(
		String pKPIType,
		String pBuType,
		String pBuCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"select max(kpiInterval) from KPI where kpiType = :kpiType and buType = :buType and buCode = :buCode ";

		if (mCategory_findLastKPI.isDebugEnabled()) {
			mCategory_findLastKPI.debug("HQL: " + vHql);
			mCategory_findLastKPI.debug(
				"Params: " + pKPIType + " " + pBuType + " " + pBuCode);
		}

		String vKpiInterval =
			(String) vSession
				.createQuery(vHql)
				.setParameter("kpiType", pKPIType)
				.setParameter("buType", pBuType)
				.setParameter("buCode", pBuCode)
				.uniqueResult();

		if (mCategory_findLastKPI.isDebugEnabled()) {
			mCategory_findLastKPI.debug(
				"Found last KPI interval " + vKpiInterval);
		}
		return vKpiInterval;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefKPI#calculate(java.lang.String, java.lang.String, java.lang.String, String, String)
	 */
	public List<Map<String, Object>> calculate(
		String pKPI,
		String pBuType,
		String pBuCode,
		String pSalesDayStart,
		String pSalesDayEnd) {

		List<Map<String, Object>> vResult = new LinkedList<Map<String, Object>>();

		// Look up HQL value
		String vHql = findHQLforKPI(pKPI);

		if (mCategory_calculate.isDebugEnabled()) {
			mCategory_calculate.debug("HQL for " + pKPI + ": " + vHql);
			mCategory_calculate.debug(
				"Params: "
					+ pBuType
					+ " "
					+ pBuCode
					+ " "
					+ pSalesDayStart
					+ " "
					+ pSalesDayEnd);
		}

		if (vHql != null) {

			GenericQuery<Map<String, Object>> vQuery =
				new GenericQuery<Map<String,Object>>(mSessionFactory.getCurrentSession().createQuery(vHql));

			if (vHql.indexOf(":buType") != -1) {
				vQuery.setParameter("buType", pBuType);
			}
			if (vHql.indexOf(":buCode") != -1) {
				vQuery.setParameter("buCode", pBuCode);
			}
			if (vHql.indexOf(":salesDayStart") != -1) {
				vQuery.setParameter("salesDayStart", pSalesDayStart);
			}
			if (vHql.indexOf(":salesDayEnd") != -1) {
				vQuery.setParameter("salesDayEnd", pSalesDayEnd);
			}
			
			if (vHql.indexOf(":sourceSystemExternal") != -1) {
				vQuery.setParameter("sourceSystemExternal", Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL);
			}
			
			if (vHql.indexOf(":financialTypeNone") != -1) {
				vQuery.setParameter(
					"financialTypeNone",
					Constants.FINANCIAL_TYPE_CONSTANT_NONE);
			}
			if (vHql.indexOf(":amountTypeList") != -1) {
				Collection<String> vAmountTypeList = new ArrayList<String>();
				vAmountTypeList.add(Constants.AMOUNT_TYPE_CONSTANT_CASH);
				vAmountTypeList.add(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);

				vQuery.setParameterList("amountTypeList", vAmountTypeList);

			}

			if (vHql.indexOf(":lifeCycleTypeMigrated") != -1) {
				vQuery.setParameter(
					"lifeCycleTypeMigrated",
					Constants.LIFE_CYCLE_TYPE_CONSTANT_MIGRATED);
			}
			if (vHql.indexOf(":voided") != -1) {
				vQuery.setParameter("voided", Boolean.TRUE);
			}
			// Execute HQL select statement
			vResult = vQuery.list();
		}
		if (mCategory_calculate.isInfoEnabled()) {
			mCategory_calculate.info("Found " + vResult.size() + " rows.");
		}
		return vResult;
	}


	/**
	 * 
	 * @param pKPI
	 * @return
	 */
	private String findHQLforKPI(String pKPI) {
		if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_DEBT)) {
			return "select new map(c.countryCode as fromCountryCode, c.currencyCode as fromCurrencyCode, c.cardType as cardType, '"
				+ Constants.FINANCIAL_TYPE_CONSTANT_DEBIT
				+ "' as financialType, "
				+ "sum(a.currentAmount) as amountSum, count(a.currentAmount) as transactionCount) "
				+ "from Amount a inner join a.card as c left outer join a.massLoad as m left outer join a.bonus as b "
				+ "where a.buType = :buType and a.buCode = :buCode "
				+ "and a.amountType in (:amountTypeList) "
				+ "and (a.massLoad is null or (m.releasedDateTime is not null and m.withdrawnDateTime is null)) "
				+ "and (a.bonus is null or (b.authorizedDateTime is not null)) "
				+ "and a.campaign is null "
				+ "and (c.expireDate is null or (c.expireDate > sysdate))"
				+ "group by c.countryCode, c.currencyCode, c.cardType";

		} else if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_COUNTRY)) {

			return "select new map("
					+ " c.cardType as cardType,"
					+ " t.sourceSystem as sourceSystem,"
					+ " c.countryCode as fromCountryCode,"
					+ " t.countryCode as toCountryCode,"
					+ " c.currencyCode as fromCurrencyCode,"
					+ " t.requestedCurrencyCode as toCurrencyCode,"
					+ " t.financialType as financialType,"
					+ " sum(t.balanceChange) as amountSum,"
					+ " count(t.transactionNo) as transactionCount,"
					+ " sum(t.cardBalanceChange) as cardAmountSum,"
					+ " a.buType as fromBuType,"
					+ " a.buCode as fromBuCode,"
					+ " t.buType as buType, "
					+ " t.buCode as buCode) "
					+ " from Transaction t"
					+ " inner join t.card as c"
					+ " left outer join t.amount as a"
					+ " where t.buType = :buType"
					+ " and t.buCode = :buCode"
					+ " and t.salesDay >= :salesDayStart"
					+ " and t.salesDay <= :salesDayEnd"
					+ " and t.financialType != :financialTypeNone"
					+ " and t.sourceSystem!=:sourceSystemExternal "
					//+ " and c.countryCode != t.countryCode"
					+ " and t.voidedTransactionNo = 0"
					+ " and not exists"
					+ " (select 1 from TransactionFilter f"
					+ "  where voided = :voided"
					+ "  and t.transactionNo = f.transactionNo)"
					+ " group by c.cardType, t.sourceSystem, c.countryCode, t.countryCode, c.currencyCode, t.requestedCurrencyCode,"
					+ " t.financialType, a.buType, a.buCode, t.buType, t.buCode";

		} else if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_EMPLOYEE)) {

			return "select new map(c.cardType as cardType, t.sourceSystem as sourceSystem, t.employee as employee, "
				+ "c.countryCode as fromCountryCode, t.countryCode as toCountryCode, "
				+ "c.currencyCode as fromCurrencyCode, t.requestedCurrencyCode as toCurrencyCode, t.financialType as financialType, "
				+ "sum(t.balanceChange) as amountSum, count(t.transactionNo) as transactionCount) "				
				+ "from Transaction t inner join t.card as c "
				+ "where t.buType = :buType and t.buCode = :buCode and t.salesDay >= :salesDayStart and t.salesDay <= :salesDayEnd "
				+ "and t.financialType != :financialTypeNone "
				+ " and t.sourceSystem!=:sourceSystemExternal "
				+ " and t.voidedTransactionNo = 0 and not exists (select 1 from TransactionFilter f where voided = :voided and t.transactionNo = f.transactionNo) "
				+ "group by c.cardType, t.sourceSystem, t.employee, c.countryCode, t.countryCode, c.currencyCode, t.requestedCurrencyCode,"
				+ " t.financialType ";

		} else if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_MIGRATION)) {

			return "select new map('"
				+ Constants.FINANCIAL_TYPE_CONSTANT_CREDIT
				+ "' as financialType, count(*) as transactionCount) "
				+ "from LifeCycle "
				+ "where buType = :buType and buCode = :buCode "
				+ "and lifeCycleType = :lifeCycleTypeMigrated";

		} else if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_STORE)) {

			return "select new map("
					+ " c.cardType as cardType,"
					+ " t.sourceSystem as sourceSystem,"
					+ " c.countryCode as fromCountryCode,"
					+ " t.countryCode as toCountryCode,"
					+ " c.currencyCode as fromCurrencyCode,"
					+ " t.requestedCurrencyCode as toCurrencyCode,"
					+ " t.financialType as financialType,"
					+ " sum(t.balanceChange) as amountSum,"
					+ " count(t.transactionNo) as transactionCount,"
					+ " a.buType as fromBuType,"
					+ " a.buCode as fromBuCode,"
					+ " t.buType as buType, "
					+ " t.buCode as buCode) "
					+ " from Transaction t"
					+ " inner join t.card as c"
					+ " left outer join t.amount as a"
					+ " where t.buType = :buType"
					+ " and t.buCode = :buCode"
					+ " and t.salesDay >= :salesDayStart"
					+ " and t.salesDay <= :salesDayEnd"
					+ " and t.financialType != :financialTypeNone"
					+ " and t.voidedTransactionNo = 0"
					+ " and t.sourceSystem!=:sourceSystemExternal"
					+ " and not exists"
					+ " (select 1 from TransactionFilter f"
					+ "  where voided = :voided"
					+ "  and t.transactionNo = f.transactionNo)"
					+ " group by c.cardType, t.sourceSystem, c.countryCode, t.countryCode, c.currencyCode, t.requestedCurrencyCode,"
					+ " t.financialType, a.buType, a.buCode, t.buType, t.buCode";

		} else if (pKPI.equals(Constants.KPI_TYPE_CONSTANT_EXPIRED)) {
			
			return "select new map(c.countryCode as fromCountryCode, c.currencyCode as fromCurrencyCode, c.cardType as cardType, '"
				+ Constants.FINANCIAL_TYPE_CONSTANT_DEBIT
				+ "' as financialType, "
				+ "sum(a.currentAmount) as amountSum, count(distinct c.cardId) as transactionCount) "
				+ "from Amount a inner join a.card as c left outer join a.massLoad as m left outer join a.bonus as b "
				+ "where a.buType = :buType and a.buCode = :buCode "
				+ "and (a.massLoad is null or (m.releasedDateTime is not null and m.withdrawnDateTime is null)) "
				+ "and (a.bonus is null or (b.authorizedDateTime is not null)) "
				+ "and a.campaign is null "
				+ "and to_char(c.expireDate,'yyyy-mm-dd') >= :salesDayStart and to_char(c.expireDate,'yyyy-mm-dd') <= :salesDayEnd "
				+ "group by c.countryCode, c.currencyCode, c.cardType";
				
		}

		return null;
	}

	@Override
	protected Class<KPI> getBusinessEntityClass() {
		return KPI.class;
	}

}
