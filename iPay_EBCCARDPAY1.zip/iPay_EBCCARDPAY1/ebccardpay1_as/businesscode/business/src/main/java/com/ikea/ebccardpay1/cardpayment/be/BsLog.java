package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

public class BsLog extends BusinessEntity{
	/**										
	 * Storage: BS_LOG_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mBsLogId;

	/**										
	 * Common attributes	
	 */										
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;

	/**										
	 * Data								
	 */										
	private String mBsName;
	private String mBsInputs;
	
	public long getBsLogId() {
		return mBsLogId;
	}
	public void setBsLogId(long pBsLogId) {
		mBsLogId = pBsLogId;
	}
	public String getCreatedBy() {
		return mCreatedBy;
	}
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	public String getBsName() {
		return mBsName;
	}
	public void setBsName(String pBsName) {
		mBsName = pBsName;
	}
	public String getBsInputs() {
		return mBsInputs;
	}
	public void setBsInputs(String pBsInputs) {
		mBsInputs = pBsInputs;
	}
	
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mBsLogId);
		return isSet;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("bsLogId", CodeGeneration.toObject(mBsLogId));
		vMap.put("bsName", CodeGeneration.toObject(mBsName));
		vMap.put("bsInputs", CodeGeneration.toObject(mBsInputs));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	 /*(non-Javadoc)
	  @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)*/
	 
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("bsLogId")) mBsLogId = CodeGeneration.objectTolong(pMap.get("bsLogId"));
		if(pMap.containsKey("bsName")) mBsName = CodeGeneration.objectToString(pMap.get("bsName"));
		if(pMap.containsKey("bsInputs")) mBsInputs = CodeGeneration.objectToString(pMap.get("bsInputs"));
	}
	

}
