/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.Iterator;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.BonusCode;
import com.ikea.ebccardpay1.cardpayment.bef.BefBonusCode;
import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCode;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCode;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeSearch;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import java.util.ArrayList;
import java.util.List;
import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 * 
 */
public class BecBonusCodesImpl implements BecBonusCodes {

	// Dependencies injected at creation of this BEC
	private BecBonusCode mBecBonusCode;
	private BefBonusCode mBefBonusCode;

	// Entities that this BEC operates on
	List<VoBonusCode> mVoBonusCodeList = null;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	/**
	 * 
	 */
	public BecBonusCodesImpl(BecBonusCode pBecBonus, BefBonusCode pBefBonusCode) {
		super();

		mBecBonusCode = pBecBonus;
		mBefBonusCode = pBefBonusCode;
	}

	void validate() {
		notNull(mBecBonusCode);
		notNull(mBefBonusCode);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#init(com.ikea.ebccardpay1
	 * .client.vo.VoBonusCode)
	 */
	public BecBonusCodes init(List<VoBonusCode> pVoBonusCodeList) {

		mVoBonusCodeList = pVoBonusCodeList;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonusCodes#init(com.ikea.ebccardpay1
	 * .cardpayment.utils.UserEnvironment)
	 */
	public BecBonusCodes init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#manage()
	 */
	public void manage() throws IkeaException, ValueMissingException,
			BonusCodeException {

		requireVoBonusCodeList();

		// Mange on each of the VoBonusCode

		for (VoBonusCode vVoBonusCode : mVoBonusCodeList) {
			// Let singel BEC do the management
			mBecBonusCode.manage(vVoBonusCode);

			// Copy new VO
			ValueObjects.assignFromMap(vVoBonusCode,
					ValueObjects.assignToMap(mBecBonusCode.getVoBonusCode()));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#getVoBonusCodeList()
	 */
	public List<VoBonusCode> getVoBonusCodeList() throws ValueMissingException {

		requireVoBonusCodeList();

		return mVoBonusCodeList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#findCurrentBonusCodes()
	 */
	public List<VoBonusCodeBriefRef> findCurrentBonusCodes()
			throws IkeaException, ValueMissingException {

		List<VoBonusCodeBriefRef> vVoList = new ArrayList<VoBonusCodeBriefRef>();

		// Get Bonuses for the logged in users country
		List<BonusCode> vList = mBefBonusCode
				.findByCurrent(countryCodeForUser());

		for (Iterator<BonusCode> i = vList.iterator(); i.hasNext();) {
			BonusCode vBonusCode = (BonusCode) i.next();

			// Let singel BEC do the extraction to VO
			mBecBonusCode.init(vBonusCode);
			vVoList.add(mBecBonusCode.getVoBonusCodeBriefRef());
		}
		return vVoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonuses#findBonuses(com.ikea.
	 * ebccardpay1.client.vo.VoBonusCodeSearch)
	 */
	public List<VoBonusCode> findBonuses(VoBonusCodeSearch pVoBonusCodeSearch)
			throws IkeaException, ValueMissingException {

		List<VoBonusCode> vVoList = new ArrayList<VoBonusCode>();

		// Get Bonuses for the logged in users country
		List<BonusCode> vList = mBefBonusCode.findBySearch(
				pVoBonusCodeSearch.getCode(), pVoBonusCodeSearch.getName(),
				pVoBonusCodeSearch.getCountryCode());

		for (Iterator<BonusCode> i = vList.iterator(); i.hasNext();) {
			BonusCode vBonusCode = (BonusCode) i.next();

			// Let singel BEC do the extraction to VO
			mBecBonusCode.init(vBonusCode);
			vVoList.add(mBecBonusCode.getVoBonusCode());
		}
		return vVoList;
	}

	// -----------------------------------------------------

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser() throws ValueMissingException,
			IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException(
					"Tried to use BecBonusCodes without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireVoBonusCodeList() throws ValueMissingException {
		if (mVoBonusCodeList == null)
			throw new ValueMissingException(
					"Tried to use BecBonusCodes without required List<VoBonusCode>.");
	}

}
