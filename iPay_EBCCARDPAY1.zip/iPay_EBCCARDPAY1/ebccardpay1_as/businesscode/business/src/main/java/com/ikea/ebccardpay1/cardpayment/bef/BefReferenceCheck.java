/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefReferenceCheck extends Bef<ReferenceCheck>{

	public int deleteAcknowledged(String pBuType, java.util.List<String> pStores);

	public ReferenceCheck findByReference(String pReference, String pSourceSystem);
	
	//public ReferenceCheck findByReference(String pReference, String pSourceSystem, String pSalesDay);
	public java.util.List<ReferenceCheck> findByWaitingAckOlderThan(int pMinutes);

}