package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.ExternalTempCard;


public interface BefExternalTempCard extends Bef<ExternalTempCard>{
	
	public List<ExternalTempCard> findByCardNumberString(String pCardNumberString);
	public List<ExternalTempCard> findByFileName(String pName);
	
	//List all Active Cards to Transfer
	public List<ExternalTempCard> findActiveCardsToTransfer(String pName, int count);
	

	
}