/*
 * Created on 2006-jun-07
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebcframework.services.EbcProperties;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author anms
 *
 */
public class EbcEnvironmentImpl implements EbcEnvironment {

    @Autowired
    EbcProperties ebcProperties;

	public int getMaxCardsInCampaignProcessing() {
		return ebcProperties.getInt(
			MAX_CARDS_IN_CAMPAIGN_PROCESSING_PROP,
			MAX_CARDS_IN_CAMPAIGN_PROCESSING_DEFAULT);

	}

	public int getMaxCardsInMassLoadProcessing() {
		return ebcProperties.getInt(
			MAX_CARDS_IN_MASS_LOAD_PROCESSING_PROP,
			MAX_CARDS_IN_MASS_LOAD_PROCESSING_DEFAULT);

	}

}
