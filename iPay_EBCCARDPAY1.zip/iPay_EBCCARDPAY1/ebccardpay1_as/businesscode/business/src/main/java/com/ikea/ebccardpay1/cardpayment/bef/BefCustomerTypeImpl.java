package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.CustomerType;
import com.ikea.common.TimeSource;

public class BefCustomerTypeImpl extends
BefAbstract<CustomerType> implements BefCustomerType{
	
	/**
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCustomerTypeImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<CustomerType> getBusinessEntityClass() {
		return CustomerType.class;
	}


}
