/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class MassLoadException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5027213427246308376L;

	public MassLoadException() {
		super();
	}
	public MassLoadException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidMassLoad();
	}
}
