package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Set;

import com.ikea.ebcframework.exception.IkeaException;

public interface CbdService {

	public CbdExchangeRatesForCurrencies getExchangeRatesForCurrencies(Set<String> pCurrencyCodes) throws IkeaException;

	public Company getCompanyForBusinessUnit(String pBuType, String pBuCode) throws IkeaException;

}