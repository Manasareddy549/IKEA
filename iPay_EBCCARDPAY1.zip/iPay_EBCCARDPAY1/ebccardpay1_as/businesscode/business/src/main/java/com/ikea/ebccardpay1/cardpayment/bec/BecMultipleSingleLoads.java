package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.MultipleSingleLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoadSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author Henrik Reinhold
 *
 */
public interface BecMultipleSingleLoads {

	/**
	 * @return
	 */
	List<MultipleSingleLoad> findUnauthorized() throws IkeaException;

	List<MultipleSingleLoad> findMultipleSingleLoads(
			VoMultipleSingleLoadSearch pVoMultipleSingleLoadSearch);
	
	List<VoMultipleSingleLoad> convertToVoList(List<MultipleSingleLoad> pMultipleSingleLoads);
	
	VoMultipleSingleLoad withdraw(VoMultipleSingleLoad pVoMultipleSingleLoad) throws ValueMissingException,MultipleSingleLoadException, MultipleSingleLoadException;

}
