package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationAmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.ReverseAmountCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoAuthorization;
import com.ikea.ebccardpay1.cardpayment.vo.VoCapture;
import com.ikea.ebccardpay1.cardpayment.vo.VoEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoReferenceAckTimeOut;
import com.ikea.ebccardpay1.cardpayment.vo.VoReferenceSpecifier;
import com.ikea.ebccardpay1.cardpayment.vo.VoReverse;
import com.ikea.ebcframework.exception.IkeaException;

public interface BecReferenceCheck {

	/**
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecReferenceCheck init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pCard
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecReferenceCheck init(
		Card pCard,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment);

	/**
	 * @param pManual Set if this is a manual transaction
	 * 
	 * @throws ReferenceCheckException
	 * @throws ValueMissingException
	 * @throws UnacknowledgedTimeoutException 
	 */
	public void checkAndCreate(boolean pManual)
		throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException;
	
	public void checkAndCreateVoid(boolean pManual)
			throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException;

	/**
	 * 
	 * @throws ReferenceCheckException
	 * @throws ValueMissingException
	 */
	public void acknowledge(VoReferenceSpecifier pVoReferenceSpecifier, VoCapture pVoCapture)
		throws ReferenceCheckException, ValueMissingException, AmountException;
	
	/**
	 * Reverse amount - reverse unauthorized transaction from ReserverdCardHistory_T
	 * 
	 * @param pVoReferenceSpecifier The source system that want's to reverse
	 * @param pManual True if this is a manual void
	 * @throws ValueMissingException
	 * @throws UnacknowledgedTimeoutException 
	 */
	public void reverseAmount(VoReferenceSpecifier pVoReferenceSpecifier, VoReverse pVoReverse)
		throws ReferenceCheckException, ValueMissingException, AmountException,
			ReverseAmountCheckException;
	
	/**
	 * Will cancel all unacknowledged transactions connected to the card.
	 * A load transaction will result in descreasing the amount,
	 * a redeem transaction will result in increasing the amount.
	 * @throws ValueMissingException
	 * @throws ReferenceCheckException 
	 */
	public void cancelUnacknowledged()
		throws ValueMissingException, AmountException, ReferenceCheckException;

	/**
	 * Will cancel the trancation connected to the refrence check.
	 * @throws ValueMissingException
	 */
	public void cancelTransaction(ReferenceCheck pReferenceCheck)
		throws ValueMissingException, AmountException;
	/**
	 * Caliculate the TransactionAckDateTime.
	 * @throws ValueMissingException
	 */
	public VoEnvironment calculateTransactionAckDateTime()
	throws ReferenceCheckException, ValueMissingException, UnacknowledgedTimeoutException;

	/**
	 * 
	 * @throws ReferenceCheckException
	 * @throws ValueMissingException
	 */

	public void resetAckTimeOut(VoReferenceAckTimeOut voReferenceSpecifier)
	throws ReferenceCheckException, ValueMissingException;
	/**
	 * 
	 * @throws ReferenceCheckException
	 * @throws ValueMissingException
	 */

	public boolean isReferenceWaitingForAcknowledgement(
			VoReferenceSpecifier voReferenceSpecifier)throws ReferenceCheckException, ValueMissingException;
			
	public void checkUnacknowledgeRedeemReferences()
			throws ValueMissingException, AmountException ;

	
}
