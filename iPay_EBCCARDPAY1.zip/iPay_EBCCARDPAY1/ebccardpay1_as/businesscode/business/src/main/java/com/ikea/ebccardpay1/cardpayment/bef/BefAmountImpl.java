/*
 * Created on 2006-june-16
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefAmountImpl extends BefAbstract<Amount> implements BefAmount{

	private final static Logger mCategory_findByAmountType =
		LoggerFactory.getLogger(
			BefAmountImpl.class.getName() + ".findByAmountType");

	private final static Logger mCategory_deleteByCampaign =
		LoggerFactory.getLogger(
			BefAmountImpl.class.getName() + ".deleteByCampaign");

	private final static Logger mCategory_usageByCampaign =
		LoggerFactory.getLogger(
			BefAmountImpl.class.getName() + ".usageByCampaign");

	private final static Logger mCategory_deleteByMassLoad =
		LoggerFactory.getLogger(
			BefAmountImpl.class.getName() + ".deleteByMassLoad");

	private final static Logger mCategory_usageByMassLoad =
		LoggerFactory.getLogger(
			BefAmountImpl.class.getName() + ".usageByMassLoad");

	private final static Logger mCategory_usageByBonus =
		LoggerFactory.getLogger(BefAmountImpl.class.getName() + ".usageByBonus");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefAmountImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#findByAmountType(java.lang.String)
	 */

	public List<Amount> findByAmountType(String pAmountType) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from Amount where amountType=:amountType order by createdDateTime";

		if (mCategory_findByAmountType.isDebugEnabled()) {
			mCategory_findByAmountType.debug("HQL: " + vHql);
		}

		List<Amount> vList =
			new GenericQuery<Amount>(vSession
				.createQuery(vHql)
				.setParameter("amountType", pAmountType))
				.list();

		if (mCategory_findByAmountType.isDebugEnabled()) {
			if (vList == null) {
				mCategory_findByAmountType.info("No list returned.");
			} else {
				mCategory_findByAmountType.info(
					"Number of amounts in list '" + vList.size() + "'.");
			}
		}
		return vList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#deleteByCampaign(com.ikea.ebccardpay1.cardpayment.be.Campaign)
	 */
	public int deleteByCampaign(Campaign pCampaign) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "delete from Amount where campaign=:campaign";

		if (mCategory_deleteByCampaign.isDebugEnabled()) {
			mCategory_deleteByCampaign.debug("HQL: " + vHql);
		}
		
		int count=vSession
				.createQuery(vHql)
				.setEntity("campaign", pCampaign)
				.executeUpdate();
		vSession.flush();

		return count;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#usageByCampaign(com.ikea.ebccardpay1.cardpayment.be.Campaign)
	 */
	public Map<BigDecimal,BigDecimal> usageByCampaign(Campaign pCampaign) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"select new map(sum(originalAmount) as totalAmount, sum(originalAmount) - sum(currentAmount) as usageAmount) "
				+ "from Amount where campaign=:campaign";

		if (mCategory_usageByCampaign.isDebugEnabled()) {
			mCategory_usageByCampaign.debug("HQL: " + vHql);
		}

		return new GenericQuery<Map<BigDecimal,BigDecimal>>(vSession
			.createQuery(vHql)
			.setEntity("campaign", pCampaign))
			.uniqueResult();
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#deleteByMassLoad(com.ikea.ebccardpay1.cardpayment.be.MassLoad)
	 */
	public int deleteByMassLoad(MassLoad pMassLoad) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "delete from Amount where massLoad=:massLoad";

		if (mCategory_deleteByMassLoad.isDebugEnabled()) {
			mCategory_deleteByMassLoad.debug("HQL: " + vHql);
		}
		
		int count=vSession
				.createQuery(vHql)
				.setEntity("massLoad", pMassLoad)
				.executeUpdate();
		
		vSession.flush();
		
		return count;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#usageByMassLoad(com.ikea.ebccardpay1.cardpayment.be.MassLoad)
	 */
	public Map<BigDecimal,BigDecimal> usageByMassLoad(MassLoad pMassLoad) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"select new map(sum(originalAmount) as totalAmount, sum(originalAmount) - sum(currentAmount) as usageAmount) "
				+ "from Amount where massLoad=:massLoad";

		if (mCategory_usageByMassLoad.isDebugEnabled()) {
			mCategory_usageByMassLoad.debug("HQL: " + vHql);
		}

		return new GenericQuery<Map<BigDecimal,BigDecimal>>(vSession
			.createQuery(vHql)
			.setEntity("massLoad", pMassLoad))
			.uniqueResult();
	}

	public Map<BigDecimal,BigDecimal> usageByBonus(Bonus pBonus) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"select new map(sum(originalAmount) as totalAmount, sum(originalAmount) - sum(currentAmount) as usageAmount) "
				+ "from Amount "
				+ "where bonusCode=:bonusCode "
				+ "and buCode=:buCode "
				+ "and bonus=:bonus "
				+ "and massLoad is null ";

		if (mCategory_usageByBonus.isDebugEnabled()) {
			mCategory_usageByBonus.debug("HQL: " + vHql);
		}

		return new GenericQuery<Map<BigDecimal,BigDecimal>>(vSession
			.createQuery(vHql)
			.setParameter("bonusCode", pBonus.getBonusCode())
			.setParameter("buCode", pBonus.getAmount().getBuCode())
			.setLong("bonus", pBonus.getBonusId()))
			.uniqueResult();

	}
	public Amount findByAmountId(long pAmountId) {
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from Amount where amountId=:amountId";

		Amount vAmount =
			(Amount) vSession
			.createQuery(vHql)
			.setParameter("amountId", pAmountId)
			.uniqueResult();

		if (vAmount == null) {
			mCategory_deleteByMassLoad.debug("No references found.");
		}
		return vAmount;
	}
	@Override
	protected Class<Amount> getBusinessEntityClass() {
		return Amount.class;
	}

}
