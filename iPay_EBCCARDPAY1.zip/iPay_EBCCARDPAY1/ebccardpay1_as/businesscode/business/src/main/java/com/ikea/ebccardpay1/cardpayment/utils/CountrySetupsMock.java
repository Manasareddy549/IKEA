package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.utils.CountrySetups;

public class CountrySetupsMock implements CountrySetups {

	public int getExpireDays(String pCountryCode, String pCardType)
			throws CountrySetupException {
		return 0;
	}

	public void reloadCache() {

	}

}
