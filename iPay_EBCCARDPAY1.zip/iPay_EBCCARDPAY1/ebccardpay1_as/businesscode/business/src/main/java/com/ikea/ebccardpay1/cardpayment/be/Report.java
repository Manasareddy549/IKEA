/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Report extends BusinessEntity {
	/**										
	 * Storage: REPORT_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mReportId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<Parameter> mParameters = new java.util.LinkedHashSet<Parameter>(0);

	/**										
	 * Data								
	 */										
	private String mGroupName;
	private String mName;
	private boolean mKpiReport;
	private int mSortOrder;
	private String mColumns;
	private String mQuery1;
	private String mQuery2;
	private String mPrivilege;

	/**											
	 * @return Returns the reportId.													
	 */											
	public long getReportId() {
		return mReportId;
	}
	/**
	 * @param pReportId The reportId to set.
	 */
	public void setReportId(long pReportId) {
		mReportId = pReportId;
	}

	/**											
	 * @return Returns the groupName.													
	 */											
	public String getGroupName() {
		return mGroupName;
	}
	/**
	 * @param pGroupName The groupName to set.
	 */
	public void setGroupName(String pGroupName) {
		mGroupName = pGroupName;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the kpiReport.													
	 */											
	public boolean getKpiReport() {
		return mKpiReport;
	}
	/**
	 * @param pKpiReport The kpiReport to set.
	 */
	public void setKpiReport(boolean pKpiReport) {
		mKpiReport = pKpiReport;
	}

	/**											
	 * @return Returns the sortOrder.													
	 */											
	public int getSortOrder() {
		return mSortOrder;
	}
	/**
	 * @param pSortOrder The sortOrder to set.
	 */
	public void setSortOrder(int pSortOrder) {
		mSortOrder = pSortOrder;
	}

	/**											
	 * @return Returns the columns.													
	 */											
	public String getColumns() {
		return mColumns;
	}
	/**
	 * @param pColumns The columns to set.
	 */
	public void setColumns(String pColumns) {
		mColumns = pColumns;
	}

	/**											
	 * @return Returns the query1.													
	 */											
	public String getQuery1() {
		return mQuery1;
	}
	/**
	 * @param pQuery1 The query1 to set.
	 */
	public void setQuery1(String pQuery1) {
		mQuery1 = pQuery1;
	}

	/**											
	 * @return Returns the query2.													
	 */											
	public String getQuery2() {
		return mQuery2;
	}
	/**
	 * @param pQuery2 The query2 to set.
	 */
	public void setQuery2(String pQuery2) {
		mQuery2 = pQuery2;
	}

	/**											
	 * @return Returns the privilege.													
	 */											
	public String getPrivilege() {
		return mPrivilege;
	}
	/**
	 * @param pPrivilege The privilege to set.
	 */
	public void setPrivilege(String pPrivilege) {
		mPrivilege = pPrivilege;
	}

	/**											
	 * @return Returns the parameters.													
	 */											
	public java.util.Set<Parameter> getParameters() {
		return mParameters;
	}
	/**
	 * @param pParameters The parameters to set.
	 */
	public void setParameters(java.util.Set<Parameter> pParameters) {
		mParameters = pParameters;
	}

	/**
	 * Connect a Parameter.
	 * @param pParameter
	 */
	public void connectParameter(Parameter pParameter) {
		getParameters().add(pParameter);
		if(pParameter != null) {
			pParameter.setReport(this);
		}
	}

	/**
	 * Disconnect a Parameter.
	 * @param pParameter
	 */
	public void disconnectParameter(Parameter pParameter) {
		if(pParameter != null) {
			pParameter.setReport(null);
		}
		getParameters().remove(pParameter);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mReportId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("reportId", CodeGeneration.toObject(mReportId));
		vMap.put("groupName", CodeGeneration.toObject(mGroupName));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("kpiReport", CodeGeneration.toObject(mKpiReport));
		vMap.put("sortOrder", CodeGeneration.toObject(mSortOrder));
		vMap.put("columns", CodeGeneration.toObject(mColumns));
		vMap.put("query1", CodeGeneration.toObject(mQuery1));
		vMap.put("query2", CodeGeneration.toObject(mQuery2));
		vMap.put("privilege", CodeGeneration.toObject(mPrivilege));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("reportId")) mReportId = CodeGeneration.objectTolong(pMap.get("reportId"));
		if(pMap.containsKey("groupName")) mGroupName = CodeGeneration.objectToString(pMap.get("groupName"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("kpiReport")) mKpiReport = CodeGeneration.objectToboolean(pMap.get("kpiReport"));
		if(pMap.containsKey("sortOrder")) mSortOrder = CodeGeneration.objectToint(pMap.get("sortOrder"));
		if(pMap.containsKey("columns")) mColumns = CodeGeneration.objectToString(pMap.get("columns"));
		if(pMap.containsKey("query1")) mQuery1 = CodeGeneration.objectToString(pMap.get("query1"));
		if(pMap.containsKey("query2")) mQuery2 = CodeGeneration.objectToString(pMap.get("query2"));
		if(pMap.containsKey("privilege")) mPrivilege = CodeGeneration.objectToString(pMap.get("privilege"));
	}
}
