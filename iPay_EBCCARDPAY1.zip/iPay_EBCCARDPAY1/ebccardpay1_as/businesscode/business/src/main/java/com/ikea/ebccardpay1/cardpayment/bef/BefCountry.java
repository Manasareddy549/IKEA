/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefCountry extends Bef<Country>{

	public Country findByCountryCode(String pCountryCode);

}