/*
 * Created on 2007-jan-26
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;

/**
 * @author anms
 * @author tpon
 * 
 */
public class UnitsCacheStaticImpl implements UnitsCache {


	private final static Logger mCategory = LoggerFactory.getLogger(UnitsCacheStaticImpl.class);

	protected static Map<String, Unit> sUnitMap = new TreeMap<String, Unit>();

	public static class UnitStatic extends Unit {

		private static final long serialVersionUID = 7031293348764206020L;

		/**
		 * Creates a STO unit
		 */
		public UnitStatic(String pBuCode, String pSiteName,
				String pCountryCode, String pTimeZone) {

			super();
			this.setBuType("STO");
			this.setBuCode(pBuCode);
			this.setSiteName(pSiteName);
			this.setCountryCode(pCountryCode);
			this.setTimeZone(pTimeZone);

		}
	}

	/**
	 * 
	 */
	public UnitsCacheStaticImpl() {
		super();
		init();
	}

	protected void init() {

		addToMap(new UnitStatic("381", "Springwood (Brisbane)", "AU",
				"Australia/Brisbane"));
		addToMap(new UnitStatic("383", "Moorabbin (Melbourne)", "AU",
				"Australia/Melbourne"));
		addToMap(new UnitStatic("384", "Richmond (Melbourne)", "AU",
				"Australia/Melbourne"));
		addToMap(new UnitStatic("382", "Homebush Bay Drive (Sydney)", "AU",
				"Australia/Sydney"));
		addToMap(new UnitStatic("380", "Moore Park (Sydney)", "AU",
				"Australia/Sydney"));

		addToMap(new UnitStatic("387", "Graz", "AT", "Europe/Vienna"));
		addToMap(new UnitStatic("388", "Linz (Haid)", "AT", "Europe/Vienna"));
		addToMap(new UnitStatic("273", "Innsbruck", "AT", "Europe/Vienna"));
		addToMap(new UnitStatic("386", "Salzburg", "AT", "Europe/Vienna"));
		addToMap(new UnitStatic("090", "North (Wien)", "AT", "Europe/Vienna"));
		addToMap(new UnitStatic("085", "V�sendorf City S�d (Wien)", "AT",
				"Europe/Vienna"));

		addToMap(new UnitStatic("114", "Wilrijk (Antwerp)", "BE",
				"Europe/Brussels"));
		addToMap(new UnitStatic("482", "Anderlecht (Brussels)", "BE",
				"Europe/Brussels"));
		addToMap(new UnitStatic("112", "Ternat (Brussels)", "BE",
				"Europe/Brussels"));
		addToMap(new UnitStatic("376", "Zaventem (Brussels)", "BE",
				"Europe/Brussels"));
		addToMap(new UnitStatic("375", "Hognoul (Li�ge)", "BE",
				"Europe/Brussels"));

		addToMap(new UnitStatic("803", "Beijing", "CN", "Asia/Shanghai"));
		addToMap(new UnitStatic("801", "Shanghai", "CN", "Asia/Shanghai"));

		addToMap(new UnitStatic("278", "Brno", "CZ", "Europe/Prague"));
		addToMap(new UnitStatic("309", "Ostrava", "CZ", "Europe/Prague"));
		addToMap(new UnitStatic("178", "Prague", "CZ", "Europe/Prague"));
		addToMap(new UnitStatic("408", "Prague", "CZ", "Europe/Prague"));

		addToMap(new UnitStatic("121", "Gentofte", "DK", "Europe/Copenhagen"));
		addToMap(new UnitStatic("120", "Odense", "DK", "Europe/Copenhagen"));
		addToMap(new UnitStatic("094", "T�strup", "DK", "Europe/Copenhagen"));
		addToMap(new UnitStatic("093", "�rhus", "DK", "Europe/Copenhagen"));

		addToMap(new UnitStatic("202", "Esbo", "FI", "Europe/Helsinki"));
		addToMap(new UnitStatic("422", "Vantaa", "FI", "Europe/Helsinki"));

		addToMap(new UnitStatic("134", "Bordeaux", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("133", "Lomme (Lille)", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("132", "Lyon", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("130", "Vitrolles (Marseille)", "FR",
				"Europe/Paris"));
		addToMap(new UnitStatic("260", "Metz", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("316", "Nantes", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("082", "Evry (Paris)", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("389", "Franconville (Paris)", "FR",
				"Europe/Paris"));
		addToMap(new UnitStatic("131", "Paris Nord (Paris)", "FR",
				"Europe/Paris"));
		addToMap(new UnitStatic("083", "Plaisir (Paris)", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("436", "Velizy Villacoublay (Paris)", "FR",
				"Europe/Paris"));
		addToMap(new UnitStatic("240", "Villiers (Paris)", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("239", "Strasbourg", "FR", "Europe/Paris"));
		addToMap(new UnitStatic("315", "La Valette (Toulon)", "FR",
				"Europe/Paris"));
		addToMap(new UnitStatic("242", "Toulouse", "FR", "Europe/Paris"));

		addToMap(new UnitStatic("394", "Spandau (Berlin)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("421", "Tempelhof (Berlin)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("129", "Waltersdorf (Berlin)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("119", "Bielefeld", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("117", "Braunschweig", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("228", "Brinkum (Bremen)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("118", "Chemnitz", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("072", "Kamen (Dortmund)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("223", "West (Dortmund)", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("221", "Dresden", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("425", "Duisburg", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("073", "Kaarst (D�sseldorf)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("321", "Reisholz (D�sseldorf)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("148", "Essen", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("222", "Hanau (Frankfurt)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("322", "Wallau (Frankfurt)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("320", "Freiburg", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("325", "Morfleet (Hamburg)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("146", "Schnelsen (Hamburg)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("226", "Burgwedel (Hannover)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("075", "Walldorf (Heidelberg)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("174", "Kassel", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("333", "Kiel", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("147", "K�ln", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("139", "G�ntersdorf (Leipzig)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("397", "Mannheim", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("063", "Eching (M�nchen)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("343", "Taufkirchen (M�nchen)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("074", "F�rth (N�rnberg)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("229", "Regensburg", "DE", "Europe/Berlin"));
		addToMap(new UnitStatic("227", "Lisdorf (Saarlouis)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("225", "Ludwigsburg (Stuttgart)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("224", "Sindelfingen (Stuttgart)", "DE",
				"Europe/Berlin"));
		addToMap(new UnitStatic("328", "Ulm", "DE", "Europe/Berlin"));

		addToMap(new UnitStatic("180", "Budapest", "HU", "Europe/Budapest"));
		addToMap(new UnitStatic("182", "Buda�rs", "HU", "Europe/Budapest"));

		addToMap(new UnitStatic("231", "Casalecchio (Bologna)", "IT",
				"Europe/Rome"));
		addToMap(new UnitStatic("354", "Brescia", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("352", "Florence", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("232", "Genova", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("233", "Carugate (Milano)", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("137", "Corsico (Milano)", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("353", "Naples", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("234", "Rome", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("135", "Torino", "IT", "Europe/Rome"));
		addToMap(new UnitStatic("427", "Rome II", "IT", "Europe/Rome"));

		addToMap(new UnitStatic("088", "Amsterdam", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("403", "Breda", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("272", "Arnhem (Duiven)", "NL",
				"Europe/Amsterdam"));
		addToMap(new UnitStatic("087", "Eindhoven", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("271", "Groningen", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("378", "Haarlem", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("089", "Heerlen", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("312", "Hengelo", "NL", "Europe/Amsterdam"));
		addToMap(new UnitStatic("274", "Barendrecht (Rotterdam)", "NL",
				"Europe/Amsterdam"));
		addToMap(new UnitStatic("080", "Sliedrecht (Rotterdam)", "NL",
				"Europe/Amsterdam"));
		addToMap(new UnitStatic("270", "Utrecht", "NL", "Europe/Amsterdam"));

		addToMap(new UnitStatic("097", "�sane (Bergen)", "NO", "Europe/Oslo"));
		addToMap(new UnitStatic("095", "Furuset (Oslo)", "NO", "Europe/Oslo"));
		addToMap(new UnitStatic("091", "Slependen (Oslo)", "NO", "Europe/Oslo"));
		addToMap(new UnitStatic("126", "Sandnes (Stavanger)", "NO",
				"Europe/Oslo"));
		addToMap(new UnitStatic("371", "Trondheim", "NO", "Europe/Oslo"));

		addToMap(new UnitStatic("203", "Gdansk", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("306", "Katowice", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("204", "Krakow", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("205", "Poznan", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("188", "Janki (Warsaw)", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("307", "North (Warsaw)", "PL", "Europe/Warsaw"));
		addToMap(new UnitStatic("201", "Wroclaw", "PL", "Europe/Warsaw"));

		addToMap(new UnitStatic("367", "Lisbon", "PT", "Europe/Lisbon"));

		addToMap(new UnitStatic("341", "Kazan", "RU", "Europe/Moscow"));
		addToMap(new UnitStatic("335", "Khimki (Moscow)", "RU", "Europe/Moscow"));
		addToMap(new UnitStatic("336", "Teply Stan (Moscow)", "RU",
				"Europe/Moscow"));
		addToMap(new UnitStatic("426", "St. Petersburg", "RU", "Europe/Moscow"));

		addToMap(new UnitStatic("489", "Bratislava", "SK", "Europe/Bratislava"));

		addToMap(new UnitStatic("280", "Badalona (Barcelona)", "ES",
				"Europe/Madrid"));
		addToMap(new UnitStatic("406", "Hospitalet de Llobregat (Barcelona)",
				"ES", "Europe/Madrid"));
		addToMap(new UnitStatic("276", "Barakaldo (Bilbao)", "ES",
				"Europe/Madrid"));
		addToMap(new UnitStatic("281", "Alcorcon (Madrid)", "ES",
				"Europe/Madrid"));
		addToMap(new UnitStatic("282", "San Sebastian (Madrid)", "ES",
				"Europe/Madrid"));
		addToMap(new UnitStatic("283", "Seville", "ES", "Europe/Madrid"));

		addToMap(new UnitStatic("122", "G�vle", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("398", "B�ckebol (G�teborg)", "SE",
				"Europe/Stockholm"));
		addToMap(new UnitStatic("014", "G�teborg", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("107", "V�la (Helsingborg)", "SE",
				"Europe/Stockholm"));
		addToMap(new UnitStatic("109", "J�nk�ping", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("017", "Link�ping", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("015", "Malm�", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("019", "Barkaby (Stockholm)", "SE",
				"Europe/Stockholm"));
		addToMap(new UnitStatic("012", "Kungens Kurva (Stockholm)", "SE",
				"Europe/Stockholm"));
		addToMap(new UnitStatic("013", "Sundsvall", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("108", "Uppsala", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("016", "V�ster�s", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("011", "�lmhult", "SE", "Europe/Stockholm"));
		addToMap(new UnitStatic("106", "�rebro", "SE", "Europe/Stockholm"));

		addToMap(new UnitStatic("078", "Aubonne", "CH", "Europe/Zurich"));
		addToMap(new UnitStatic("290", "Bern", "CH", "Europe/Zurich"));
		addToMap(new UnitStatic("101", "Lugano", "CH", "Europe/Zurich"));
		addToMap(new UnitStatic("292", "Pratteln", "CH", "Europe/Zurich"));
		addToMap(new UnitStatic("291", "Dietlikon (Z�rich)", "CH",
				"Europe/Zurich"));
		addToMap(new UnitStatic("077", "Spreitenbach (Z�rich)", "CH",
				"Europe/Zurich"));

		addToMap(new UnitStatic("142", "Birmingham", "GB", "Europe/London"));
		addToMap(new UnitStatic("264", "Bristol", "GB", "Europe/London"));
		addToMap(new UnitStatic("267", "Cardiff", "GB", "Europe/London"));
		addToMap(new UnitStatic("265", "Edinburgh", "GB", "Europe/London"));
		addToMap(new UnitStatic("266", "Braehead (Glasgow)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("261", "Leeds", "GB", "Europe/London"));
		addToMap(new UnitStatic("141", "Brent Park (London)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("144", "Croydon (London)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("255", "Edmonton (London)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("262", "Thurrock (London)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("143", "Gateshead (Newcastle)", "GB",
				"Europe/London"));
		addToMap(new UnitStatic("263", "Nottingham", "GB", "Europe/London"));
		addToMap(new UnitStatic("140", "Warrington", "GB", "Europe/London"));
	}

	protected void addToMap(UnitStatic unitStatic) {
		sUnitMap.put(key(unitStatic.getBuType(), unitStatic.getBuCode()),
				unitStatic);
	}

	/**
	 * Creates the key
	 * 
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 */
	protected static String key(String pBuType, String pBuCode) {
		return pBuType + "|" + pBuCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.utils.UnitsCache#fetch(java.lang.String,
	 * java.lang.String)
	 */
	public Unit fetch(String pBuType, String pBuCode)
			throws BusinessUnitException {
		return (Unit) sUnitMap.get(key(pBuType, pBuCode));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.UnitsCache#all()
	 */
	public Collection<Unit> all() throws BusinessUnitException {

		if (mCategory.isDebugEnabled()) {
			mCategory.debug("Fetching all BU info");
		}
		return sUnitMap.values();
	}

}
