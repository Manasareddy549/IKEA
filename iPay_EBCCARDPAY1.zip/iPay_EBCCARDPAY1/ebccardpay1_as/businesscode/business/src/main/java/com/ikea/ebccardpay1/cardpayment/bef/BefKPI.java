/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Map;

import com.ikea.ebccardpay1.cardpayment.be.KPI;

public interface BefKPI extends Bef<KPI>{

	public java.util.List<Map<String, Object>> calculate(String pKPI, String pBuType, String pBuCode, String pStart, String pEnd);

	public String findLastKPI(String pKPIType, String pBuType, String pBuCode);

}