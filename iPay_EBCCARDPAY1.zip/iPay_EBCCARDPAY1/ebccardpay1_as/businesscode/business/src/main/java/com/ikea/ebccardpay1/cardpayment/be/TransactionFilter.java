/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class TransactionFilter extends BusinessEntity {
	/**										
	 * Storage: TRANSACTION_FILTER_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mTransactionFilterId;


	/**										
	 * Foreign keys				
	 */										

	/**										
	 * Data								
	 */										
	private boolean mVoided;
	private long mTransactionNo;

	/**											
	 * @return Returns the transactionFilterId.													
	 */											
	public long getTransactionFilterId() {
		return mTransactionFilterId;
	}
	/**
	 * @param pTransactionFilterId The transactionFilterId to set.
	 */
	public void setTransactionFilterId(long pTransactionFilterId) {
		mTransactionFilterId = pTransactionFilterId;
	}

	/**											
	 * @return Returns the voided.													
	 */											
	public boolean getVoided() {
		return mVoided;
	}
	/**
	 * @param pVoided The voided to set.
	 */
	public void setVoided(boolean pVoided) {
		mVoided = pVoided;
	}

	/**											
	 * @return Returns the transactionNo.													
	 */											
	public long getTransactionNo() {
		return mTransactionNo;
	}
	/**
	 * @param pTransactionNo The transactionNo to set.
	 */
	public void setTransactionNo(long pTransactionNo) {
		mTransactionNo = pTransactionNo;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mTransactionFilterId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("transactionFilterId", CodeGeneration.toObject(mTransactionFilterId));
		vMap.put("voided", CodeGeneration.toObject(mVoided));
		vMap.put("transactionNo", CodeGeneration.toObject(mTransactionNo));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("transactionFilterId")) mTransactionFilterId = CodeGeneration.objectTolong(pMap.get("transactionFilterId"));
		if(pMap.containsKey("voided")) mVoided = CodeGeneration.objectToboolean(pMap.get("voided"));
		if(pMap.containsKey("transactionNo")) mTransactionNo = CodeGeneration.objectTolong(pMap.get("transactionNo"));
	}
}
