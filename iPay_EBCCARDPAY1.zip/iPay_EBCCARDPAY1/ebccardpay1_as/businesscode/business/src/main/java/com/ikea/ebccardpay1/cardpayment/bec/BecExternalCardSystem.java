/*
 * Created on 2007-aug-09
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidAmountTypeException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystemBrief;
import java.util.List;
/**
 * @author anms
 *
 */
public interface BecExternalCardSystem {

	/**
	 * 
	 * @param pExternalCardSystem
	 * @return
	 */
	public BecExternalCardSystem init(ExternalCardSystem pExternalCardSystem);

	/**
	 * 
	 * @param pExternalCardSystemName
	 * @return
	 */
	public BecExternalCardSystem init(String pExternalCardSystemName);

	/**
	 * 
	 * @return
	 */
	public ExternalCardSystem getExternalCardSystem();
	/**
	 * 
	 * @return
	 */
	public List<VoExternalCardSystemBrief> findAllCompleted();

	/**
	 * 
	 * @return
	 */
	public CardNumber nextAvailableInternalNumber()
		throws ValueMissingException, InvalidCardNumberException;

	/**
	 * 
	 * @param pVoExternalCardSystem
	 * @param pVoExternalCardList
	 * @return
	 */
	public VoExternalCardSystem importExternalCards(
		VoExternalCardSystem pVoExternalCardSystem,
		List<VoExternalCard> pVoExternalCardList)
		throws
			InvalidCardNumberException,
			DuplicateExternalCardSystem,
			ValueMissingException,
			InvalidAmountTypeException;
}
