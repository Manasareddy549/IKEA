package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;

public interface BefMultipleSingleLoad extends Bef<MultipleSingleLoad>{

	List<MultipleSingleLoad> findBySearch(String pNameLike, String pBuType, String pBuCode, String pCountryCode, java.util.Date pCreatedDateTime);

	List<MultipleSingleLoad> findByUnauthorized(String pCountryCode);

}