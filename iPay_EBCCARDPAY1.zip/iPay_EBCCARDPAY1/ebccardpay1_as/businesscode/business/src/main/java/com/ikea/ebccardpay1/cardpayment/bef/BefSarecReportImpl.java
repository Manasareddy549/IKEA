package com.ikea.ebccardpay1.cardpayment.bef;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.IpaySarecFTP;
import com.ikea.ebccardpay1.cardpayment.be.IpaySarecReport;
import com.ikea.ebccardpay1.cardpayment.be.ReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bec.BecFactory;
import com.ikea.ebccardpay1.cardpayment.bec.BecReport;
import com.ikea.ebccardpay1.cardpayment.exception.ReportException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoParameter;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportTransaction;
import com.ikea.ebcframework.exception.IkeaException;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;


/**
 * @author moans1
 * 
 */
public class BefSarecReportImpl extends BefAbstract<IpaySarecReport> implements
		BefSarecReport {

	private final static Logger mCategory_findLastSarecReport = LoggerFactory
			.getLogger(BefSarecReportImpl.class.getName()
					+ ".findLastSarecReport");

	private final static Logger mCategory_generate = LoggerFactory
			.getLogger(BefSarecReportImpl.class.getName() + ".generate");
	private final static Logger mCategory_deleteFromSaarec_report_t=LoggerFactory.getLogger(BefSarecReportImpl.class.getName()+".deleteSaarecReport");

	private final static Logger mLog = LoggerFactory.getLogger(BefSarecReportImpl.class);
	
	private final static Logger mCategory_transferSarecReport = LoggerFactory
	.getLogger(BefSarecReportImpl.class.getName()
			+ ".transferSarecReport");
		
	private BecFactory mBecFactory;
	
	private UtilsFactory mUtilsFactory;
	
	private EncryptionDecryption mEncryptionDecryption=null;
	
	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	protected BefSarecReportImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource, BecFactory pBecFactory, UtilsFactory pUtilsFactory, EncryptionDecryption pEncryptionDecryption) {
		super(pSessionFactory, pTimeSource);
		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
		mEncryptionDecryption = pEncryptionDecryption;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport#findLastSarecReport
	 * (java.lang.String, java.lang.String)
	 */
	public String findLastSarecReport(String pBuType, String pBuCode) {
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "select max(salesDate) from IpaySarecReport where buType = :buType and buCode = :buCode ";

		if (mCategory_findLastSarecReport.isDebugEnabled()) {
			mCategory_findLastSarecReport.debug("HQL: " + vHql);
			mCategory_findLastSarecReport.debug("Params: " + pBuType + " "
					+ pBuCode);
		}

		String vSalesDate = (String) vSession.createQuery(vHql).setParameter(
				"buType", pBuType).setParameter("buCode", pBuCode)
				.uniqueResult();

		if (mCategory_findLastSarecReport.isDebugEnabled()) {
			mCategory_findLastSarecReport.debug("Found last Sarec Report date "
					+ vSalesDate);
		}
		return vSalesDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport#generate(java.lang
	 * .String, java.lang.String, java.lang.String)
	 */
	public Blob generate(String pBuType, String pBuCode, String pSalesDay)
			throws IkeaException, ReportException, ValueMissingException {
		
		IpaySarecFTP pIpaySarecFTP = getIpaySarecFTP();
		String Decommission = pIpaySarecFTP.getSarecDecommission();
		
		if((Decommission == null) || (Decommission.length() == 0)) {

		BecReport vBec = mBecFactory.createBecReport()
				.init(
						mUtilsFactory.createUserEnvironment());

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Params: " + pBuType + " " + pBuCode + " "
					+ pSalesDay);
		}

		//Creating XML structure and storing it as StringBuilder
		StringBuilder xmlAsString = new StringBuilder();
		xmlAsString.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xmlAsString
				.append("<tendermanagement xmlns=\"http://www.ikea.com/sarec/declaredfunds\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
		xmlAsString
				.append(" xsi:schemaLocation=\"http://www.ikea.com/sarec/declaredfunds DeclaredFunds-1-03.xsd\"");
		xmlAsString.append(" buType=\"" + pBuType + "\" buCode=\"" + pBuCode
				+ "\" sourceSystem=\"iPAY\">\n");
		
		//Setting up parameter for calling BecReport method retrieveTransactionReport()
		List<VoParameter> vVoParameterList = new ArrayList<VoParameter>();

		VoParameter vBuTypeParameter = new VoParameter();
		vBuTypeParameter.setParameterType("BU_TYPE");
		vBuTypeParameter.setParameterValue(pBuType);

		VoParameter vBuCodeParameter = new VoParameter();
		vBuCodeParameter.setParameterType("BU_CODE");
		vBuCodeParameter.setParameterValue(pBuCode);

		VoParameter vSalesDayParameter = new VoParameter();
		vSalesDayParameter.setParameterType("SALES_DAY");
		vSalesDayParameter.setParameterValue(pSalesDay);

		vVoParameterList.add(vBuTypeParameter);
		vVoParameterList.add(vBuCodeParameter);
		vVoParameterList.add(vSalesDayParameter);

		//Setting Report id as 6 as it is the value for Daily Detailed Report
		vBec.setReport(6);
		vBec.setParameters(vVoParameterList);

		List<VoReportTransaction> voSalesdayTransactionList = vBec
				.retrieveTransactionReport();

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Got Daily detailed report for " + pBuType
					+ pBuCode + " for salesdate: " + pSalesDay);
		}

		if (voSalesdayTransactionList != null) {
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Got records for " + pBuType + pBuCode
						+ " for salesdate: " + pSalesDay);
			}
			if(voSalesdayTransactionList.size()>0)
				// converting the transaction list to xml format string.
				xmlAsString.append(getTransactionsAsXML(voSalesdayTransactionList));
			else
				return null;

		} 
		
		xmlAsString.append("</tendermanagement>");

		Blob vSarecReportBlob = null;

		try {
			// Converting the string object to Blob object
			byte[] vSarecReportByte = xmlAsString.toString().getBytes("UTF-8");
			Hibernate.getLobCreator(mSessionFactory.getCurrentSession()).createBlob(vSarecReportByte);
			vSarecReportBlob = Hibernate.getLobCreator(getCurrentSession()).createBlob(vSarecReportByte);
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Converted file to BLOB");
			}
		} catch (IOException e) {
			mCategory_generate.error("Unable to create file. " + e);
			mCategory_transferSarecReport.info(e.getMessage());
		}
		return vSarecReportBlob;
		}
		
		else
		{
			return null;
		}
		
	}
	
	public Blob generateS4hana(String pBuType, String pBuCode, String pSalesDay)
			throws IkeaException, ReportException, ValueMissingException {

		BecReport vBecS4 = mBecFactory.createBecReport()
				.init(
						mUtilsFactory.createUserEnvironment());

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Params: " + pBuType + " " + pBuCode + " "
					+ pSalesDay);
		}

		//Creating XML structure and storing it as StringBuilder
		StringBuilder xmlAsStringS4 = new StringBuilder();
		xmlAsStringS4.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xmlAsStringS4
				.append("<tendermanagement xmlns=\"http://www.ikea.com/sarec/declaredfunds\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
		xmlAsStringS4
				.append(" xsi:schemaLocation=\"http://www.ikea.com/sarec/declaredfunds DeclaredFunds-1-03.xsd\"");
		xmlAsStringS4.append(" buType=\"" + pBuType + "\" buCode=\"" + pBuCode
				+ "\" sourceSystem=\"iPAY\">\n");
		
		//Setting up parameter for calling BecReport method retrieveTransactionReport()
		List<VoParameter> vVoParameterListS4 = new ArrayList<VoParameter>();

		VoParameter vBuTypeParameterS4 = new VoParameter();
		vBuTypeParameterS4.setParameterType("BU_TYPE");
		vBuTypeParameterS4.setParameterValue(pBuType);

		VoParameter vBuCodeParameterS4 = new VoParameter();
		vBuCodeParameterS4.setParameterType("BU_CODE");
		vBuCodeParameterS4.setParameterValue(pBuCode);

		VoParameter vSalesDayParameterS4 = new VoParameter();
		vSalesDayParameterS4.setParameterType("SALES_DAY");
		vSalesDayParameterS4.setParameterValue(pSalesDay);

		vVoParameterListS4.add(vBuTypeParameterS4);
		vVoParameterListS4.add(vBuCodeParameterS4);
		vVoParameterListS4.add(vSalesDayParameterS4);

		//Setting Report id as 6 as it is the value for Daily Detailed Report
		vBecS4.setReport(6);
		vBecS4.setParameters(vVoParameterListS4);

		List<VoReportTransaction> voSalesdayTransactionListS4 = vBecS4
				.retrieveTransactionReport();

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Got Daily detailed report for " + pBuType
					+ pBuCode + " for salesdate: " + pSalesDay);
		}

		if (voSalesdayTransactionListS4 != null) {
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Got records for " + pBuType + pBuCode
						+ " for salesdate: " + pSalesDay);
			}
			if(voSalesdayTransactionListS4.size()>0)
				// converting the transaction list to xml format string.
				xmlAsStringS4.append(getTransactionsAsXMLS4(voSalesdayTransactionListS4));
			else
				return null;

		} 
		
		xmlAsStringS4.append("</tendermanagement>");

		Blob vSarecReportBlobS4 = null;

		try {
			// Converting the string object to Blob object
			byte[] vSarecReportByteS4 = xmlAsStringS4.toString().getBytes("UTF-8");
			Hibernate.getLobCreator(mSessionFactory.getCurrentSession()).createBlob(vSarecReportByteS4);
			vSarecReportBlobS4 = Hibernate.getLobCreator(getCurrentSession()).createBlob(vSarecReportByteS4);
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Converted file to BLOB");
			}
		} catch (IOException e) {
			mCategory_generate.error("Unable to create file. " + e);
			mCategory_transferSarecReport.info(e.getMessage());
		}
		return vSarecReportBlobS4;
	}

	/**
	 * This method takes input VoReportTransactionList and then returns the
	 * transactions in the form of xml
	 * 
	 * @param pVoSalesdayTransactionList
	 * @return StringBuilder
	 */

	private StringBuilder getTransactionsAsXML(
			List<VoReportTransaction> pVoSalesdayTransactionList) {

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate
					.debug("Started Converting the Transactions to XML");
		}
		StringBuilder transactionsAsXML = new StringBuilder();

		for(Iterator<VoReportTransaction> vReportIterator = pVoSalesdayTransactionList.iterator();vReportIterator.hasNext();){
						
			VoReportTransaction vVoReportTransaction = vReportIterator.next();
				
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Financial Type = "
						+ vVoReportTransaction.getFinancialType());
				mCategory_generate.debug("Credit Amount = "
						+ vVoReportTransaction.getCreditAmount());
				mCategory_generate.debug("Debit Amount = "
						+ vVoReportTransaction.getDebitAmount());
				mCategory_generate.debug("Void = "
						+ vVoReportTransaction.getVoid());
			}
			
			//Filtering out all void transactions
			if ("X".equals(vVoReportTransaction.getVoid())){
				mCategory_generate.debug("Voided");
				continue;
			}
			
			transactionsAsXML.append("<tendermovement ");

			String salesDate = vVoReportTransaction.getSalesDay();
			transactionsAsXML.append("date=\"" + salesDate + "T12:00:00Z\" ");
			
			String bookingType = "Declared Funds";
			transactionsAsXML.append("bookingType=\"" + bookingType + "\" ");
			
			transactionsAsXML.append("tenderId=\""
					+ vVoReportTransaction.getCardType() + "\" ");
			
			String salesAreaGroup; 
			if ("STOREPOINT".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()))
				salesAreaGroup = "IF";
			else if ("irw".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()) 
					||"ICP".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()) ||
					"ISELL".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()) ||
					"iPay".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()) || 
					"IME".equalsIgnoreCase(vVoReportTransaction.getSourceSystem())||
					"IPPCAPI".equalsIgnoreCase(vVoReportTransaction.getSourceSystem()))
				salesAreaGroup = "NONPOS";
			else 
				salesAreaGroup = "STORE";
			transactionsAsXML.append("salesAreaGroup=\"" + salesAreaGroup
					+ "\" ");
			
			if (vVoReportTransaction.getCreditAmount().compareTo(
					BigDecimal.ZERO) == 0)
				transactionsAsXML.append("valueTendered=\""
						+ vVoReportTransaction.getDebitAmount() + "\" ");
			else
				transactionsAsXML.append("valueTendered=\""
						+ vVoReportTransaction.getCreditAmount().negate() + "\" ");
			
			if(salesAreaGroup.equals("NONPOS")){
				transactionsAsXML.append("tillNo=\"\" ");
				transactionsAsXML.append("transactionNo=\"\" ");
			} else {
				String tillNo=vVoReportTransaction.getPointOfSale();
				String transactionNo=vVoReportTransaction.getReceipt();
				if(tillNo.equalsIgnoreCase("null"))
					tillNo="";
				if(transactionNo.equalsIgnoreCase("null"))
					transactionNo="";
				transactionsAsXML.append("tillNo=\""
						+ tillNo + "\" ");
				transactionsAsXML.append("transactionNo=\""
						+ transactionNo + "\" ");
			}
			
			transactionsAsXML.append("cashierId=\""
					+ vVoReportTransaction.getEmployee() + "\" />\n");
		}
		
		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Converted transactions to XML");
			mCategory_generate.debug(transactionsAsXML.toString());
		}
		
		return transactionsAsXML;
	}
	private StringBuilder getTransactionsAsXMLS4(
			List<VoReportTransaction> pVoSalesdayTransactionListS4) {

		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate
					.debug("Started Converting the Transactions to XML");
		}
		StringBuilder transactionsAsXMLS4 = new StringBuilder();

		for(Iterator<VoReportTransaction> vReportIteratorS4 = pVoSalesdayTransactionListS4.iterator();vReportIteratorS4.hasNext();){
						
			VoReportTransaction vVoReportTransactionS4 = vReportIteratorS4.next();
				
			if (mCategory_generate.isDebugEnabled()) {
				mCategory_generate.debug("Financial Type = "
						+ vVoReportTransactionS4.getFinancialType());
				mCategory_generate.debug("Credit Amount = "
						+ vVoReportTransactionS4.getCreditAmount());
				mCategory_generate.debug("Debit Amount = "
						+ vVoReportTransactionS4.getDebitAmount());
				mCategory_generate.debug("Void = "
						+ vVoReportTransactionS4.getVoid());
			}
			
			//Filtering out all void transactions
			if ("X".equals(vVoReportTransactionS4.getVoid())){
				mCategory_generate.debug("Voided");
				continue;
			}
			
			transactionsAsXMLS4.append("<tendermovement ");

			String salesDate = vVoReportTransactionS4.getSalesDay();
			transactionsAsXMLS4.append("date=\"" + salesDate + "T12:00:00Z\" ");
			
			String bookingType = "Declared Funds";
			transactionsAsXMLS4.append("bookingType=\"" + bookingType + "\" ");
			
			transactionsAsXMLS4.append("tenderId=\""
					+ vVoReportTransactionS4.getCardType() + "\" ");
					
			/*transactionsAsXMLS4.append("loadName=\""
			           + vVoReportTransactionS4.getLoadName() + "\" ");*/
			
			String salesAreaGroup;
			long TransactionNo= vVoReportTransactionS4.getTransactionNo();
		        
		  int reasonCode= fetchReasonCode(TransactionNo);
		  if (reasonCode==99 || reasonCode==90) {
		    	salesAreaGroup = vVoReportTransactionS4.getEmployee();
		  }
			 
		  else if ("STOREPOINT".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()))
				salesAreaGroup = "IF";
			else if ("irw".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()) 
					||"ICP".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()) ||
					"ISELL".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()) ||
					"iPay".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()) ||
                                         "IME".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem())||
                                         "IPPCAPI".equalsIgnoreCase(vVoReportTransactionS4.getSourceSystem()))
				salesAreaGroup = "NONPOS";
			else 
				salesAreaGroup = "STORE";
			transactionsAsXMLS4.append("salesAreaGroup=\"" + salesAreaGroup
					+ "\" ");
			
			if (vVoReportTransactionS4.getCreditAmount().compareTo(
					BigDecimal.ZERO) == 0)
				transactionsAsXMLS4.append("valueTendered=\""
						+ vVoReportTransactionS4.getDebitAmount() + "\" ");
			else
				transactionsAsXMLS4.append("valueTendered=\""
						+ vVoReportTransactionS4.getCreditAmount().negate() + "\" ");
			
			if(salesAreaGroup.equals("NONPOS")){
				transactionsAsXMLS4.append("tillNo=\"\" ");
				String transactionNo=vVoReportTransactionS4.getReceipt();
				if(transactionNo == null || "null".equalsIgnoreCase(transactionNo))
					transactionNo="";
				transactionsAsXMLS4.append("transactionNo=\""
						+ transactionNo + "\" ");
			} else {
				String tillNo=vVoReportTransactionS4.getPointOfSale();
				String transactionNo=vVoReportTransactionS4.getReceipt();
				if(tillNo.equalsIgnoreCase("null"))
					tillNo="";
				if(transactionNo.equalsIgnoreCase("null"))
					transactionNo="";
				transactionsAsXMLS4.append("tillNo=\""
						+ tillNo + "\" ");
				transactionsAsXMLS4.append("transactionNo=\""
						+ transactionNo + "\" ");
			}
			
			
			String cardNumber= vVoReportTransactionS4.getCardNumberString();
			String maskedNumber = maskCardNumber(cardNumber);
	        transactionsAsXMLS4.append("cardNumber=\""+ maskedNumber + "\" ");
	        
	        /*long TransactionNo= vVoReportTransactionS4.getTransactionNo();
	        
	      int reasonCode= fetchReasonCode(TransactionNo);*/
	      
	      
	      if(reasonCode == 0) {
				transactionsAsXMLS4.append("reasonCode=\"\" ");
	      }
	      
	      else {
	      transactionsAsXMLS4.append("reasonCode=\""+ reasonCode + "\" ");
	      }
	      
			
			transactionsAsXMLS4.append("cashierId=\""
					+ vVoReportTransactionS4.getEmployee() + "\" />\n");
		}
		
		if (mCategory_generate.isDebugEnabled()) {
			mCategory_generate.debug("Converted transactions to XML");
			mCategory_generate.debug(transactionsAsXMLS4.toString());
		}
		
		return transactionsAsXMLS4;
	}
	
	public int fetchReasonCode(long TransactionNumber)
	
	{
		 Session vSession = mSessionFactory.getCurrentSession();

			String vHql = "from Transaction where transactionNo = :transactionNo order by transactionId ASC";

			if (mCategory_transferSarecReport.isDebugEnabled()) {
				mCategory_transferSarecReport.debug("HQL: " + vHql);			
			}              		

			
			List<Transaction> vTransactionList = (List<Transaction>)(vSession.createQuery(vHql).setParameter("transactionNo", TransactionNumber).list());
			
			if (vTransactionList == null) {
				mCategory_transferSarecReport.debug("No Transactions found");
			}
			
			long TransactionID1;
			if (vTransactionList.size() == 1) {
				 TransactionID1 = vTransactionList.get(0).getTransactionId();
			}else {
				 TransactionID1 = vTransactionList.get(vTransactionList.size() - 1).getTransactionId();
			}
			
			
	     Session pSession = mSessionFactory.getCurrentSession();
	      
	      String pHql = "from ReasonCodeTransaction where transactionId = :transactionId ";
	      if (mCategory_transferSarecReport.isDebugEnabled()) {
				mCategory_transferSarecReport.debug("HQL: " + pHql);			
			} 
	      ReasonCodeTransaction vReasonCodeTransaction = (ReasonCodeTransaction)(pSession.createQuery(pHql).setParameter("transactionId", TransactionID1).uniqueResult());
	      if (vReasonCodeTransaction==null) {
	    	  return 0;
	      }
	      else {
	    	  
	     int reasonCodeId= vReasonCodeTransaction.getReasonCodeId();
	      return reasonCodeId;
	      }
	}
	
	public String maskCardNumber(String cardNo)
	{
		StringBuilder maskedNo = new StringBuilder(cardNo);
	    maskedNo.replace(7,13,"XXXXXX");
	    String maskedNumber = maskedNo.toString();
	    return maskedNumber;
	}
	
	
	@Override
	protected Class<IpaySarecReport> getBusinessEntityClass() {
		return IpaySarecReport.class;
	}

	/**
	 * This method is used to delete Sarec report from  IpaySarecReport
	 * @param pBuType
	 * @return List pStores
	 */
	public int deleteSaarecReport(String pBuType, java.util.List<String> pStores) {

		Session vSession = mSessionFactory.getCurrentSession();
		int saarecSuccessValue=getSaarecSuccessValue();
		int saarecFailedValue=getSaarecFailedValue();
		String vHql = "delete from IpaySarecReport where (buType=:buType and status=:status_f and createdDateTime<sysdate-:failedVal and buCode in (:buCodes)) or(buType=:buType and status=:status_t and createdDateTime<sysdate-:successVal and buCode in (:buCodes)) ";
		
		
		if (mCategory_deleteFromSaarec_report_t.isDebugEnabled()){
			mCategory_deleteFromSaarec_report_t.debug("HQL: " + vHql);}
		
		
			int vDeletedEntries = vSession.createQuery(vHql).setString("status_f", "Failed").setString("status_t", "Success").setString("buType", pBuType).setParameterList("buCodes", pStores).setInteger("successVal", saarecSuccessValue).setInteger("failedVal",saarecFailedValue).executeUpdate();
			vSession.flush();
		return vDeletedEntries;
	}
	protected int getSaarecSuccessValue()  {
		
		String vSuccess = "7";
		mLog.info("saarec_success_value: "+vSuccess);
		
		return Integer.parseInt(vSuccess) ;
		
	}
	protected int getSaarecFailedValue(){
		
		String vFailed = "14";
		mLog.info("saarec_failed_value: "+vFailed);
		
		return Integer.parseInt(vFailed) ;
	}

	public void transferSarecReport(){
		
		//Getting list of stores for which Sarec FTP Transfer is to be done
		List<IpaySarecReport> vIpaySarecReportList = getIpaySarecReport();	
		
		if (vIpaySarecReportList == null || vIpaySarecReportList.size() == 0) {
			mCategory_transferSarecReport.debug("No sarec report found.");
			return;
		}
		
		Iterator<IpaySarecReport> vIpaySarecReportIterator = vIpaySarecReportList.iterator();
		
		String vTransferStatus;
		String vTransferStatusS4hana;
		
		while(vIpaySarecReportIterator.hasNext()){
			
			IpaySarecReport vIpaySarecReport = vIpaySarecReportIterator.next();
			
			//FTP the Sarec Report to RIX Server
			vTransferStatus = ftpSarecReport(vIpaySarecReport);
			vTransferStatusS4hana = ftpS4hanaReport(vIpaySarecReport);
			
			//Updating the result of FTP
			//vIpaySarecReport.setStatus(vTransferStatus);
			vIpaySarecReport.setStatus(vTransferStatusS4hana);
			
			mCategory_transferSarecReport.debug("Transfer of Sarec Report for "+vIpaySarecReport.getBuType()+" "+vIpaySarecReport.getBuCode()
					+" for sales day "+vIpaySarecReport.getSalesDate()+" is "+vTransferStatusS4hana);
			
			this.save(vIpaySarecReport);
			
		}
		
		
	}
	
	private String ftpSarecReport(IpaySarecReport pIpaySarecReport) {
		
		String transferSarecReportStatus = "Failed";
		
		//Reading the details FTP server
		IpaySarecFTP vIpaySarecFTP = getIpaySarecFTP();
		String vUser = vIpaySarecFTP.getSarecUser();
		String vServer = vIpaySarecFTP.getSarecServer();
		String vPwd = vIpaySarecFTP.getSarecPassword();
		int vPort = vIpaySarecFTP.getSarecPort();
		String vPrivateKeyFile= vIpaySarecFTP.getSarecPrivateKeyFile();
		String vSubPath = vIpaySarecFTP.getSarecFTPLocation();
		
		Blob vSarecReport = pIpaySarecReport.getSarecFile();
		if(vSarecReport == null)
		{
			return "failed";
		}
		else {
			
		com.jcraft.jsch.Session vSession = null;
		ChannelSftp vSftp = null;
		try {
			//Convert the Sarec File Blob oject to String
			byte[] fileToTransferAsByte = vSarecReport.getBytes(1l, (int)vSarecReport.length());
			String fileToTransferAsString = new String (fileToTransferAsByte);
			
			String vSarecReportDate = pIpaySarecReport.getCreatedDateTime().toString();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			String vFileName = "iPay_"+pIpaySarecReport.getBuType()+pIpaySarecReport.getBuCode()+"_";
			
			Date d = sdf.parse(vSarecReportDate);
			sdf.applyPattern("yyyyMMddHHmmss");
			vFileName += (sdf.format(d));
			
			JSch vJsch = new JSch();
			
			vSession = vJsch.getSession(vUser, vServer, vPort);
			vSession.setUserInfo(new UserInfo() {
		        public String getPassphrase() {
		            return null;
		        }
		        public String getPassword() {
		            return null;
		        }
		        public boolean promptPassphrase(String string) {
		            return false;
		        }
		        public boolean promptPassword(String string) {
		            return false;
		        }
		        public boolean promptYesNo(String string) {
		            return true;
		        }
		        public void showMessage(String string) {
		        }
		    });
			
			if (vPrivateKeyFile == null || vPrivateKeyFile.length() == 0)
				vSession.setPassword(vPwd);
			else {
				vJsch.addIdentity(vPrivateKeyFile);
			}
			
			vSession.connect();
			
			vSftp = (ChannelSftp)vSession.openChannel("sftp");
			vSftp.connect();
			
			//Changing Remote FTP folder to the required location
			vSftp.cd(vSubPath);
			mCategory_transferSarecReport.debug("Local directory: "+vSftp.lpwd()+" Remote FTP location: "+vSftp.pwd());
			
			//Creating temp file on EBCCARDPAY1 server
			FileWriter vFileWriter = new FileWriter(vFileName+".xml");
			vFileWriter.append(fileToTransferAsString);
			vFileWriter.close();
			
			//FTP the file from EBCCARDPAY1 server to RIX FTP Sever
			vSftp.put(vSftp.lpwd()+"/"+vFileName+".xml",vFileName+".temp");
			
			//Rename the file after successful transfer
			vSftp.rename(vFileName+".temp", vFileName+".xml");
			
			//Deleting the temp file from EBCCARDPAY1 server
			File vFile = new File (vFileName+".xml");
			
			if(vFile.delete())
				mCategory_transferSarecReport.debug("Temporary File "+vFileName+".xml deleted successfully!!");
			else
				mCategory_transferSarecReport.debug("Failed to delete Temporary File "+vFileName+".temp!!!");
			
			transferSarecReportStatus="Success";
			
		} catch (SQLException e) {
			mCategory_transferSarecReport.info(e.getMessage());
			
		} catch (ParseException e) {
			mCategory_transferSarecReport.error("Parse Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (JSchException e) {
			mCategory_transferSarecReport.error("JSch Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (SftpException e) {
			mCategory_transferSarecReport.error("Sftp Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (IOException e) {
			mCategory_transferSarecReport.error("IO Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		}  finally {
			if (vSftp != null)
				vSftp.disconnect();
			if (vSession != null)
				vSession.disconnect();
			
		}
		
		return transferSarecReportStatus;
		}
		
		
	}
private String ftpS4hanaReport(IpaySarecReport pIpaySarecReport) {
		
		String transferS4hanaReportStatus = "Failed";
		
		//Reading the details FTP server
		IpaySarecFTP vIpaySarecFTP = getIpayS4hanaFTP();
		String vUser = vIpaySarecFTP.getSarecUser();
		String vServer = vIpaySarecFTP.getSarecServer();
		String vPwd = vIpaySarecFTP.getSarecPassword();
		int vPort = vIpaySarecFTP.getSarecPort();
		String vPrivateKeyFile= vIpaySarecFTP.getSarecPrivateKeyFile();
		String vSubPath = vIpaySarecFTP.getSarecFTPLocation();
		
		Blob vS4hanaReport = pIpaySarecReport.getS4hanaFile();
		
		com.jcraft.jsch.Session vSession = null;
		ChannelSftp vSftp = null;
		try {
			//Convert the Sarec File Blob oject to String
			byte[] fileToTransferAsByte = vS4hanaReport.getBytes(1l, (int)vS4hanaReport.length());
			String fileToTransferAsString = new String (fileToTransferAsByte);
			
			String vS4hanaReportDate = pIpaySarecReport.getCreatedDateTime().toString();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			String vFileName = "iPay_"+pIpaySarecReport.getBuType()+pIpaySarecReport.getBuCode()+"_";
			
			Date d = sdf.parse(vS4hanaReportDate);
			sdf.applyPattern("yyyyMMddHHmmss");
			vFileName += (sdf.format(d));
			
			JSch vJsch = new JSch();
			
			vSession = vJsch.getSession(vUser, vServer, vPort);
			vSession.setUserInfo(new UserInfo() {
		        public String getPassphrase() {
		            return null;
		        }
		        public String getPassword() {
		            return null;
		        }
		        public boolean promptPassphrase(String string) {
		            return false;
		        }
		        public boolean promptPassword(String string) {
		            return false;
		        }
		        public boolean promptYesNo(String string) {
		            return true;
		        }
		        public void showMessage(String string) {
		        }
		    });
			
			if (vPrivateKeyFile == null || vPrivateKeyFile.length() == 0)
				vSession.setPassword(vPwd);
			else {
				vJsch.addIdentity(vPrivateKeyFile);
			}
			
			vSession.connect();
			
			vSftp = (ChannelSftp)vSession.openChannel("sftp");
			vSftp.connect();
			
			//Changing Remote FTP folder to the required location
			vSftp.cd(vSubPath);
			mCategory_transferSarecReport.debug("Local directory: "+vSftp.lpwd()+" Remote FTP location: "+vSftp.pwd());
			
			//Creating temp file on EBCCARDPAY1 server
			FileWriter vFileWriter = new FileWriter(vFileName+".xml");
			vFileWriter.append(fileToTransferAsString);
			vFileWriter.close();
			
			//FTP the file from EBCCARDPAY1 server to RIX FTP Sever
			vSftp.put(vSftp.lpwd()+"/"+vFileName+".xml",vFileName+".temp");
			
			//Rename the file after successful transfer
			vSftp.rename(vFileName+".temp", vFileName+".xml");
			
			//Deleting the temp file from EBCCARDPAY1 server
			File vFile = new File (vFileName+".xml");
			
			if(vFile.delete())
				mCategory_transferSarecReport.debug("Temporary File "+vFileName+".xml deleted successfully!!");
			else
				mCategory_transferSarecReport.debug("Failed to delete Temporary File "+vFileName+".temp!!!");
			
			transferS4hanaReportStatus="Success";
			
		} catch (SQLException e) {
			mCategory_transferSarecReport.info(e.getMessage());
			
		} catch (ParseException e) {
			mCategory_transferSarecReport.error("Parse Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (JSchException e) {
			mCategory_transferSarecReport.error("JSch Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (SftpException e) {
			mCategory_transferSarecReport.error("Sftp Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		} catch (IOException e) {
			mCategory_transferSarecReport.error("IO Exception: "+e);
			mCategory_transferSarecReport.info(e.getMessage());
		}  finally {
			if (vSftp != null)
				vSftp.disconnect();
			if (vSession != null)
				vSession.disconnect();
			
		}
		return transferS4hanaReportStatus;
		
		
	}


	private List<IpaySarecReport> getIpaySarecReport(){
		
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from IpaySarecReport where status <> :status ";

		if (mCategory_transferSarecReport.isDebugEnabled()) {
			mCategory_transferSarecReport.debug("HQL: " + vHql);			
		}

		//Getting list of all SAREC+ store fils which have not been transferred to RIX Server
		List<IpaySarecReport> vIpaySarecReport = (List<IpaySarecReport>)(vSession.createQuery(vHql).setParameter("status", "Success").list());
		
		if (vIpaySarecReport == null || vIpaySarecReport.size() == 0) {
			mCategory_transferSarecReport.debug("No sarec report found.");
		}
		
		return vIpaySarecReport;
		
	}
	
	private IpaySarecFTP getIpaySarecFTP(){
		
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from IpaySarecFTP where sarecId = :sarecId ";

		if (mCategory_transferSarecReport.isDebugEnabled()) {
			mCategory_transferSarecReport.debug("HQL: " + vHql);			
		}              		

		IpaySarecFTP vIpaySarecFTP = (IpaySarecFTP)(vSession.createQuery(vHql).setParameter("sarecId", 1l).uniqueResult());
		
		if (vIpaySarecFTP == null) {
			mCategory_transferSarecReport.debug("No sarec rix server details found.");
		}
		
		return vIpaySarecFTP;
		
	}
	
private IpaySarecFTP getIpayS4hanaFTP(){
		
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from IpaySarecFTP where sarecId = :sarecId ";

		if (mCategory_transferSarecReport.isDebugEnabled()) {
			mCategory_transferSarecReport.debug("HQL: " + vHql);			
		}              		

		IpaySarecFTP vIpayS4hanaFTP = (IpaySarecFTP)(vSession.createQuery(vHql).setParameter("sarecId", 2l).uniqueResult());
		
		if (vIpayS4hanaFTP == null) {
			mCategory_transferSarecReport.debug("No s4hana rix server details found.");
		}
		
		return vIpayS4hanaFTP;
		
	}

}
