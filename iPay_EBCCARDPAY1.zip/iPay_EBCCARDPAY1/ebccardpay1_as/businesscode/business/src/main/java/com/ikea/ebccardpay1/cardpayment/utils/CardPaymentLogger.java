/*
 * Created on 2006-aug-02
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Iterator;
import java.util.List;

import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.vo.VoBalanceAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpay1.cardpayment.vo.VoCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardRange;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;

/**
 * @author snug
 * 
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CardPaymentLogger {

	/**
	 * 
	 * @param pVoCard
	 * @return
	 */
	public static String cardToString(VoCard pVoCard) {

		String vOut = "Card number: ";
		if (pVoCard != null) {
			vOut += cardNumberToString(pVoCard.getCardNumberString());
			vOut += " state: " + pVoCard.getCardState();
			vOut += " balance: " + pVoCard.getBalanceAmount();
			vOut += " amounts in " + pVoCard.getCurrencyCode() + ": {";
			if (pVoCard.getVoBalanceAmountList() != null
					&& pVoCard.getVoBalanceAmountList().size() > 0) {
				for (VoBalanceAmount vVoBalanceAmount : pVoCard.getVoBalanceAmountList()) {
					vOut += "[" + vVoBalanceAmount.getAmountType();
					vOut += " " + vVoBalanceAmount.getCurrentAmount() + "]";
				}
			}
			vOut += "}";
			vOut += " type: " + pVoCard.getCardType();
			vOut += "}";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pVoCard
	 * @return
	 */
	public static String cardToString(VoCardComplete pVoCard) {

		String vOut = "Card number: ";
		if (pVoCard != null) {
			vOut += cardNumberToString(pVoCard.getCardNumberString());
			vOut += " state: " + pVoCard.getCardState();
			vOut += " balance: " + pVoCard.getBalanceAmount();
			vOut += " amounts in " + pVoCard.getCurrencyCode() + ": {";
			if (pVoCard.getVoBalanceAmountList() != null
					&& pVoCard.getVoBalanceAmountList().size() > 0) {
				for (VoBalanceAmount vVoBalanceAmount : pVoCard.getVoBalanceAmountList()) {
					vOut += "[" + vVoBalanceAmount.getAmountType();
					vOut += " " + vVoBalanceAmount.getCurrentAmount() + "]";
				}
			}
			vOut += "}";
			vOut += " type: " + pVoCard.getCardType();
			vOut += "}";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pCard
	 * @return
	 */
	public static String cardToString(Card pCard) {

		String vOut = "Card number: ";
		if (pCard != null) {
			vOut += cardNumberToString(pCard.getCardNumber());
			vOut += " state: " + pCard.getCardState();
			vOut += " amounts in " + pCard.getCurrencyCode() + ": {";
			if (pCard.getAmounts() != null && pCard.getAmounts().size() > 0) {
				for (Iterator<Amount> i = pCard.getAmounts().iterator(); i.hasNext();) {
					Amount vAmount = i.next();
					vOut += "[" + vAmount.getAmountType();
					vOut += " " + vAmount.getCurrentAmount() + "]";
				}
			}
			vOut += "}";
			vOut += " type: " + pCard.getCardType();
			vOut += "}";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pCardNumberString
	 * @return
	 */
	public static String cardNumberToString(String pCardNumberString) {

		if (pCardNumberString == null || pCardNumberString.length() == 0) {
			return "";
		}
		StringBuffer vLogString = new StringBuffer(pCardNumberString);
		int vLen = vLogString.length();
		if (vLen >= 8) {
			vLogString.replace(vLen - 8, vLen - 4, "****");
		} else if (vLen == 7) {
			vLogString.replace(vLen - 7, vLen - 4, "***");
		} else if (vLen == 6) {
			vLogString.replace(vLen - 6, vLen - 4, "**");
		} else if (vLen == 5) {
			vLogString.replace(vLen - 5, vLen - 4, "*");
		}
		return vLogString.toString();
	}

	/**
	 * 
	 * @param pCardNumber
	 * @return
	 */
	public static String cardNumberToString(CardNumber pCardNumber) {

		if (pCardNumber == null) {
			return "";
		}
		String vLogString = pCardNumber.getIssuer()
				+ pCardNumber.getCardTypeDigit()
				+ pCardNumber.getAccountNumberEnc() + pCardNumber.getCheckDigit();
		return cardNumberToString(vLogString);
	}

	/**
	 * 
	 * @param pVoLoadAmount
	 * @return
	 */
	public static String loadAmountToString(VoLoadAmount pVoLoadAmount) {

		String vOut = "Load amount: ";
		if (pVoLoadAmount != null) {
			vOut += " amount: " + pVoLoadAmount.getLoadAmount();
			vOut += " currency: " + pVoLoadAmount.getCurrencyCode();
			vOut += " amountType: " + pVoLoadAmount.getAmountType();
		}
		return vOut;
	}

	/**
	 * 
	 * @param pVoRequestAmount
	 * @return
	 */
	public static String requestAmountToString(VoRequestAmount pVoRequestAmount) {

		String vOut = "Request amount: ";
		if (pVoRequestAmount != null) {
			vOut += " amount: " + pVoRequestAmount.getRequestAmount();
			vOut += " currency: " + pVoRequestAmount.getCurrencyCode();
		}
		return vOut;
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	public static String amountToString(Amount pAmount) {

		String vOut = "Amount: ";
		if (pAmount != null) {
			vOut += " id: " + pAmount.getAmountId();
			vOut += " type: " + pAmount.getAmountType();
			vOut += " current amount: " + pAmount.getCurrentAmount();
			vOut += " original amount: " + pAmount.getOriginalAmount();
			vOut += " prio: " + pAmount.getPriority();
		}
		return vOut;
	}

	/**
	 * 
	 * @param pReferenceCheck
	 * @return
	 */
	public static String referenceCheckToString(ReferenceCheck pReferenceCheck) {

		String vOut = "ReferenceCheck: ";
		if (pReferenceCheck != null) {
			vOut += " id: " + pReferenceCheck.getReferenceCheckId();
			vOut += " transaction no: " + pReferenceCheck.getTransactionNo();
			vOut += " [ref: " + pReferenceCheck.getSourceSystem();
			vOut += " " + pReferenceCheck.getReference() + "]";
			vOut += " [receipt: " + pReferenceCheck.getBuType();
			vOut += " " + pReferenceCheck.getBuCode();
			vOut += " " + pReferenceCheck.getPointOfSale();
			vOut += " " + pReferenceCheck.getReceipt() + "]";
			vOut += " [waiting ack: " + pReferenceCheck.getWaitingAck() + "]";
			vOut += " [cancelled: " + pReferenceCheck.getCancelled() + "]";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pCampaign
	 * @return
	 */
	public static String campaignToString(Campaign pCampaign) {

		String vOut = "Campaign: ";
		if (pCampaign != null) {
			vOut += " id: " + pCampaign.getCampaignId();
			vOut += " name: " + pCampaign.getName();
		}
		return vOut;
	}

	/**
	 * 
	 * @param pMassLoad
	 * @return
	 */
	public static String massLoadToString(MassLoad pMassLoad) {

		String vOut = "Mass Load: ";
		if (pMassLoad != null) {
			vOut += " id: " + pMassLoad.getMassLoadId();
			vOut += " name: " + pMassLoad.getName();
		}
		return vOut;
	}

	/**
	 * 
	 * @param pVoCardRange
	 * @return
	 */
	public static String cardRangeToString(VoCardRange pVoCardRange) {

		String vOut = "CardRange: ";
		if (pVoCardRange != null) {
			vOut += " [rangeId: " + pVoCardRange.getRangeId() + "]";
			vOut += " [state: " + pVoCardRange.getImportState() + "]";
			vOut += " [checksum: " + pVoCardRange.getChecksum() + "]";
			vOut += " [count: " + pVoCardRange.getCount() + "]";
			vOut += " [countryCode: " + pVoCardRange.getCountryCode() + "]";
			vOut += " [fileName: " + pVoCardRange.getFileName() + "]";
			vOut += " [header: " + pVoCardRange.getHeader() + "]";
			vOut += " [name: " + pVoCardRange.getName() + "]";
			vOut += " [createdDate: " + pVoCardRange.getCreatedDateTime() + "]";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static String jodaToString(DateTime pDateTime) {

		String vOut = "Joda date time: ";
		if (pDateTime != null) {
			vOut += "" + pDateTime.year().get();
			vOut += "-" + pDateTime.monthOfYear().get();
			vOut += "-" + pDateTime.dayOfMonth().get();
			vOut += " " + pDateTime.hourOfDay().get();
			vOut += ":" + pDateTime.minuteOfHour().get();
			vOut += ":" + pDateTime.secondOfMinute().get();
			vOut += "." + pDateTime.millisOfSecond().get();
			vOut += " " + pDateTime.getZone().getID();
			vOut += " [" + pDateTime.toString() + "]";
		}
		return vOut;
	}

	/**
	 * 
	 * @param pVoBusinessUnitList
	 * @return
	 */
	public static String buListToString(List<VoBusinessUnit> pVoBusinessUnitList) {

		String vOut = "[";
		for(VoBusinessUnit vVoBusinessUnit: pVoBusinessUnitList){
			vOut += vVoBusinessUnit.getBuCode() + ", ";
		}
		vOut += "]";
		return vOut;
	}
}
