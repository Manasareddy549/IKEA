/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.be.LifeCycle;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefLifeCycle;
import com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.BlockedCardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNumberNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateCardException;
import com.ikea.ebccardpay1.cardpayment.exception.ExpiredCardException;
import com.ikea.ebccardpay1.cardpayment.exception.ExternalCardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.IllegalCardStateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardTypeDigitException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidForeignCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode;
import com.ikea.ebccardpay1.cardpayment.exception.MassLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.MissingCardCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.PosDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.CountrySetups;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoBalanceAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonus;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardEntry;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardHistory;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystemKey;
import com.ikea.ebccardpay1.cardpayment.vo.VoLifeCycle;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoadBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoReservedCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransaction;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;

/**
 * @author anms
 * 
 */
public class BecCardImpl implements BecCard, InitializingBean {

	private final static Logger mCategory = LoggerFactory.getLogger(BecCardImpl.class.getName());

	// Dependencies injected at creation of this BEC

	private BecFactory mBecFactory = null;
	BecTransactions mBecTransactions = null;

	private BefTransaction mBefTransaction = null;

	private BefCard mBefCard = null;
	private BefLifeCycle mBefLifeCycle = null;
	private BefAuthorization mBefAuthorization = null;
	private CountrySetups mCountrySetups = null;
	private TimeSource mTimeSource = null;
	private Constants mConstants = null;
	private EncryptionDecryption mEncryptionDecryption = null;

	// Entities that this BEC operates on
	private Card mCard = null;
	private CardNumber mCardNumber = null;

	// Related Bec's that this Bec delegates work to
	BecAmounts mBecAmounts = null;
	BecCardNumber mBecCardNumber = null;
	BecReferenceCheck mBecReferenceCheck = null;
	BecReservedCardHistory mBecReservedCardHistory = null;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;
	private String mCardNumberString = "";
	private VoExternalCardSystemKey mVoExternalCardSystemKey = null;
	private UtilsFactory mUtilsFactory = null;

	private BefAmount mBefAmount = null;

	public static CopyOnWriteArrayList<Card> crdlist = null;
	public static BigDecimal VALID_GIFT_CARD_AMOUNT_CN = BigDecimal.valueOf(1000);
	
	private BefReservedCardHistory mBefReservedCardHistory=null;

	/**
	 * @param pBecFactory
	 * @param pBecTransactions
	 * @param pBefCard
	 * @param pBefLifeCycle
	 * @param pBefAuthorization
	 * @param pTimeSource
	 * @param pConstants
	 */
	protected BecCardImpl(BecFactory pBecFactory, BecTransactions pBecTransactions, BefCard pBefCard,
			BefLifeCycle pBefLifeCycle, BefAuthorization pBefAuthorization, CountrySetups pCountrySetups,
			TimeSource pTimeSource, Constants pConstants, BefTransaction pBefTransaction, UtilsFactory pUtilsFactory,
			BefAmount pBefAmount, EncryptionDecryption pEncryptionDecryption, BefReservedCardHistory pBefReservedCardHistory) {

		mBecFactory = pBecFactory;
		mBecTransactions = pBecTransactions;
		mBefCard = pBefCard;
		mBefLifeCycle = pBefLifeCycle;
		mBefAuthorization = pBefAuthorization;
		mCountrySetups = pCountrySetups;
		mTimeSource = pTimeSource;
		mConstants = pConstants;
		mBefTransaction = pBefTransaction;
		mUtilsFactory = pUtilsFactory;
		mBefAmount = pBefAmount;
		mEncryptionDecryption = pEncryptionDecryption;
		mBefReservedCardHistory = pBefReservedCardHistory;
	}

	void validate() {
		notNull(mBecFactory);
		notNull(mBecTransactions);
		notNull(mBefCard);
		notNull(mBefLifeCycle);
		notNull(mBefAuthorization);
		notNull(mCountrySetups);
		notNull(mTimeSource);
		notNull(mConstants);
		notNull(mBefTransaction);
		notNull(mUtilsFactory);
		notNull(mBefAmount);
		notNull(mEncryptionDecryption);
		notNull(mBefReservedCardHistory);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#init(com.ikea.ebccardpay1
	 * .cardpayment.utils.BusinessUnitEnvironment,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecCard init(BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Card)
	 */
	public BecCard init(Card pCard) {

		assignCard(pCard);
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#init(com.ikea.ebccardpay1
	 * .cardpayment.be.CardNumber)
	 */
	public BecCard init(CardNumber pCardNumber) {

		mCardNumber = pCardNumber;
		assignCard(mCardNumber.getCard());

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#init(com.ikea.ebccardpay1
	 * .cardpayment.be.CardNumber)
	 */
	public BecCard init(CardNumber pCardNumber, BusinessUnitEnvironment pBusinessUnitEnvironment) {
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mCardNumber = pCardNumber;
		assignCard(mCardNumber.getCard());

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#init(java.lang.String,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit)
	 */
	public BecCard init(String pCardNumberString, BusinessUnitEnvironment pBusinessUnitEnvironment)
			throws InvalidCardNumberException {

		// Set business unit
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;

		BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();

		// Find or create card number
		try {
			vBecCardNumber.findCardNumber(pCardNumberString);

		} catch (CardNumberNotFoundException e) {
			vBecCardNumber.createCardNumber(pCardNumberString);
		}

		return init(vBecCardNumber.getCardNumber());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#getCard()
	 */
	public Card getCard() {
		return mCard;
	}

	public CardNumber getCardNumber() {
		return mCardNumber;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#createCard(String)
	 */
	public void createCard(String pCardNumberString)
			throws InvalidCardNumberException, DuplicateCardException, ValueMissingException, IkeaException {

		mCategory.info("Creating new card.");

		assignCard(mBefCard.create());
		initCardState(null, null);
		findOrCreateCardNumber(pCardNumberString);
		setCardTypeFromCardNumber();

		mBefCard.save(mCard);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#createFromExternal(com.ikea
	 * .ebccardpay1.cardpayment.be.CardNumber,
	 * com.ikea.ebccardpay1.cardpayment.be.ExternalCard,
	 * com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem)
	 */
	public void createFromExternal(CardNumber pCardNumber, ExternalCard pExternalCard,
			ExternalCardSystem pExternalCardSystem) throws InvalidCardNumberException, ValueMissingException {

		mCategory.info("Creating new internal card.");

		assignCard(mBefCard.create());
		initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_ACTIVATED,
				"Card " + pExternalCard.getCardNumberString() + " from " + pExternalCardSystem.getName());

		mCard.connectCardNumber(pCardNumber);
		setCardTypeFromCardNumber();

		mBefCard.save(mCard);
	}

	// Check Balance for Void find CardID
	public void findCard(long pCardId) {
		assignCard(mBefCard.findByPrimaryKey(pCardId));

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#findCard(String)
	 */
	public void findCard(String pCardNumberString) throws InvalidCardNumberException, CardNotFoundException,
			ValueMissingException, IkeaException, ReferenceCheckException {

		mCategory.info("Finding card in db.");
		Card vCard = null;

		try {
			// Utility bec card number for finding card
			BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();
			vBecCardNumber.findCardNumber(pCardNumberString);

			if (vBecCardNumber.getCardNumber() == null) {
				throw new CardNotFoundException("Card number not found.");
			} else if (vBecCardNumber.getCardNumber().getCard() == null) {
				throw new CardNotFoundException("Card number found but no card connected to this card number.");
			}

			vCard = vBecCardNumber.getCardNumber().getCard();

			// Init CardNumber here to get hold of possible verificationCode
			init(vBecCardNumber.getCardNumber());

		} catch (CardNumberNotFoundException e) {
			// See if it is an external card number
			try {
				vCard = tryExternalCardNumber(pCardNumberString);
			} catch (ExternalCardNotFoundException e2) {
				throw new CardNotFoundException(e.getMessage() + " " + e2.getMessage());
			}
		} catch (InvalidCardNumberException e) {
			// External card number might have a different regexp pattern
			try {
				vCard = tryExternalCardNumber(pCardNumberString);
			} catch (ExternalCardNotFoundException e2) {
				throw e;
			}
		}

		assignCard(vCard);

		// Cancel all unacknowlegded transactions on this card before proceeding
		cancelUnacknowledged();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#findCard(String)
	 */
	@Transactional(readOnly = true)
	public void findCardForBalanceCheck(String pCardNumberString)
			throws InvalidCardNumberException, CardNotFoundException, ValueMissingException, IkeaException {

		mCategory.info("Finding card in db.");
		Card vCard = null;

		try {
			// Utility bec card number for finding card
			BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();
			vBecCardNumber.findCardNumber(pCardNumberString);

			if (vBecCardNumber.getCardNumber() == null) {
				throw new CardNotFoundException("Card number not found.");
			} else if (vBecCardNumber.getCardNumber().getCard() == null) {
				throw new CardNotFoundException("Card number found but no card connected to this card number.");
			}

			vCard = vBecCardNumber.getCardNumber().getCard();

			// Init CardNumber here to get hold of possible verificationCode
			init(vBecCardNumber.getCardNumber());

		} catch (CardNumberNotFoundException e) {
			// See if it is an external card number
			try {
				vCard = tryExternalCardNumber(pCardNumberString);
			} catch (ExternalCardNotFoundException e2) {
				throw new CardNotFoundException(e.getMessage() + " " + e2.getMessage());
			}
		} catch (InvalidCardNumberException e) {
			// External card number might have a different regexp pattern
			try {
				vCard = tryExternalCardNumber(pCardNumberString);
			} catch (ExternalCardNotFoundException e2) {
				throw e;
			}
		}

		assignCard(vCard);

		// Cancel all unacknowlegded transactions on this card before proceeding
		/**
		 * 27 - SEPTEMBER -2012 RELEASE 3.0 The canceUncacknowledged is commented as
		 * part of release 3.0 . During the Balance check we do not need to cancel the
		 * unacknowledged transactions. This is already not done from iPayAdminClient.
		 * Now onwards no transactions will waiting for acknowledgment be canceled from
		 * POS Systems.
		 */
		/* cancelUnacknowledged(); */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCard#findCard(com.ikea.ebccardpay1
	 * .cardpayment.vo.VoCardEntry)
	 */
	public void findCard(VoCardEntry pVoCardEntry) throws InvalidCardNumberException, CardNotFoundException,
			ValueMissingException, IkeaException, ReferenceCheckException {

		mVoExternalCardSystemKey = pVoCardEntry.getVoExternalCardSystemKey();
		findCard(pVoCardEntry.getCardNumberString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCard#loadAmount(com.ikea.ebccardpay1
	 * .cardpayment.vo.VoLoadAmount)
	 */
	public void loadAmount(VoLoadAmount pVoLoadAmount, long pPosExpiryDate) throws CardException, BlockedCardException,
			CurrencyException, AmountException, CountrySetupException, ValueMissingException, ReferenceCheckException,
			IkeaException, InvalidForeignCardException, PosDateException {

		mCategory.info("Loading card with amount " + pVoLoadAmount.getLoadAmount() + ".");

		requireCard();
		requireBusinessUnitEnvironment();

		// Can not load a blocked or expired card
		checkCard();

		// Check if this refrence exists, if it does then throw an exception, if
		// not then create it.
		mBecReferenceCheck.checkAndCreate(false);

		// Bind to currency if needed
		bindCard(pVoLoadAmount.getCurrencyCode(), mBusinessUnitEnvironment.getCountryCode());
		requireExpireDate();

		String cardType = mCard.getCardType();

		// Check to restrict loading of China GIFT card for more than 1000 CNY
		if (!verifyCardAmountForCN(cardType, pVoLoadAmount.getCurrencyCode(), mBusinessUnitEnvironment.getCountryCode(),
				pVoLoadAmount.getLoadAmount())) {
			throw new AmountException("Gift card cannot be loaded for more than 1000 CNY for China");
		}
		if (pPosExpiryDate > 0) {
			String StringDate = Long.toString(pPosExpiryDate);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			sdf.setLenient(false);

			try {

				Date posDate = sdf.parse(StringDate);
				Calendar c1 = Calendar.getInstance();
				c1.setTime(mTransactionEnvironment.getTransmissionDateTime());
				c1.set(Calendar.HOUR_OF_DAY, 0);
				c1.set(Calendar.MINUTE, 0);
				c1.set(Calendar.SECOND, 0);
				c1.set(Calendar.MILLISECOND, 0);
				Date transmissionDate = c1.getTime();

				if (posDate.compareTo(transmissionDate) < 0) {
					throw new PosDateException("Expire Date is before the Current date/ Invalid Date Format");

				} else {
					mCard.setExpireDate(posDate);
				}

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				throw new PosDateException("Expire Date is before the Current date/ Invalid Date Format");
			}

		} else {

		}

		if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
			throw new AmountException("Card balance is not zero. You can't reload the card");

		}
		
		//PAYM-3851 - Check for unacknowledged transactions before load.
		mBecReferenceCheck.checkUnacknowledgeRedeemReferences();
		
		// }
		// Load amount on card
		if (mTransactionEnvironment.getSourceSystem().equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL)) {
			mBecAmounts.loadAmount(pVoLoadAmount, Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL, mCardNumberString);
		} else {
			mBecAmounts.loadAmount(pVoLoadAmount, null, mCardNumberString);
		}

		// We do not have to call save, the card object is already connected to
		// the db
		// and will automaticly we updated if it is changed.
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#loadExternalAmount(com.ikea
	 * .ebccardpay1.cardpayment.vo.VoLoadAmount)
	 */
	public void loadExternalAmount(VoLoadAmount pVoLoadAmount, String pSourceSystem)
			throws CardException, CurrencyException, AmountException, CountrySetupException, ValueMissingException,
			IkeaException, InvalidForeignCardException {

		mCategory.info("Loading card with external amount " + pVoLoadAmount.getLoadAmount() + ".");

		requireCard();
		requireBusinessUnitEnvironment();

		// Bind to currency if needed
		bindCard(pVoLoadAmount.getCurrencyCode(), mBusinessUnitEnvironment.getCountryCode());
		requireExpireDate();

		String cardType = mCard.getCardType();
		if (cardType.equalsIgnoreCase("GIFT") || cardType.equalsIgnoreCase("REFUND")) {
			if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
				throw new AmountException("Card balance is not zero. You can't reload the card");

			}
		}
		// Load amount on card

		mBecAmounts.loadAmount(pVoLoadAmount, pSourceSystem, mCardNumberString);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecCard#redeemAmount(com.ikea.
	 * ebccardpay1.cardpayment.vo.VoRequestAmount,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount)
	 */
	public void redeemAmount(VoRequestAmount pVoRequestAmount, VoRedeemAmount pVoRedeemedAmountOut, boolean pManual)
			throws CardException, BlockedCardException, CurrencyException, AmountException, ValueMissingException,
			ReferenceCheckException, IkeaException, InvalidForeignCardException {

		mCategory.info("Redeeming card with requested amount " + pVoRequestAmount.getRequestAmount() + " "
				+ pVoRequestAmount.getCurrencyCode() + ".");

		requireCard();
		requireTransactionEnvironment();

		// Can not redeem a blocked or expired card
		checkCard();
		// Can not redeem a card without a currency. Only apply on REDEEM!
		checkCardCurrency();

		

		if(mTransactionEnvironment.getAutoAcknowledge()==true ) {
			// mTransactionEnvironment.getAckTimeout()==0
			// Check if this refrence exsits, if it does the throw an exception, if
			// not then create it.
			mBecReferenceCheck.checkAndCreate(pManual);
			// Load amount on card
		mBecAmounts.redeemAmount(pVoRequestAmount, pVoRedeemedAmountOut, mCardNumberString);
		
		}else if(mTransactionEnvironment.getAutoAcknowledge()==false) {
			// mTransactionEnvironment.getAckTimeout() > 0
			// Check if this refrence exsits, if it does the throw an exception, if
			// not then create it.
			mBecReferenceCheck.checkAndCreate(pManual);
			
			mBecAmounts.redeemAmountReserved(pVoRequestAmount, pVoRedeemedAmountOut, mCardNumberString);
		}
		
	}

	public void redeemAmountManual(VoRequestAmount pVoRequestAmount, VoRedeemAmount pVoRedeemedAmountOut,
			boolean pManual, VoManualTransaction pVoManualTransaction, String pCardNumberString)
			throws CardException, BlockedCardException, CurrencyException, AmountException, ValueMissingException,
			ReferenceCheckException, IkeaException, InvalidForeignCardException {

		mCategory.info("Redeeming card with requested amount " + pVoRequestAmount.getRequestAmount() + " "
				+ pVoRequestAmount.getCurrencyCode() + ".");

		requireCard();
		requireTransactionEnvironment();

		// Can not redeem a blocked or expired card
		checkCard();
		// Can not redeem a card without a currency. Only apply on REDEEM!
		checkCardCurrency();

		// Check if this refrence exsits, if it does the throw an exception, if
		// not then create it.
		mBecReferenceCheck.checkAndCreate(pManual);

		// Load amount on card
		// mBecAmounts.redeemAmount(pVoRequestAmount, pVoRedeemedAmountOut);

		mBecAmounts.redeemAmountManual(pVoRequestAmount, pVoRedeemedAmountOut, pVoManualTransaction, pCardNumberString);
		// We do not have to call save, the card object is already connected to
		// the db
		// and will automaticly we updated if it is changed.
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecCard#loadCampaign(com.ikea.
	 * ebccardpay1.cardpayment.be.Campaign)
	 */
	public void loadCampaign(Campaign pCampaign) throws ValueMissingException, BlockedCardException,
			ExpiredCardException, IllegalCardStateException, InvalidCardNumberException, CurrencyException,
			AmountException, CountrySetupException, IkeaException, InvalidCardException {

		// Create card if needed. It will be activated
		if (mCard == null) {

			// It is important that the following three rows are executed before
			// mCard is connected to mCardNumber. getCardTypeFromCardNumber
			// flushes the session which would trigger an attempt to save the
			// incomplete mCard otherwise.
			assignCard(mBefCard.create());
			String cardTypeFromCardNumber = getCardTypeFromCardNumber();
			mCard.setCardType(cardTypeFromCardNumber);

			mCard.connectCardNumber(mCardNumber);
			initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_CAMPAIGN, "Campaign " + pCampaign.getName());
			mBefCard.save(mCard);
		}

		requireCard();
		mCategory.info("Loading campaign amount to card id '" + mCard.getCardId() + "'.");

		// Can not load a blocked or expired card
		checkCard();

		// Bind to currency if needed
		bindCard(pCampaign.getCurrencyCode(), pCampaign.getCountryCode());
		String cardType = mCard.getCardType();
		if (cardType.equalsIgnoreCase("GIFT") || cardType.equalsIgnoreCase("REFUND")) {
			// Restricting Gift and Refund cards in Campaign defect -anagc
			throw new AmountException("Gift and Refund cards cannot be loaded through Campaign");

		}
		// Create amounts for campaign
		mBecAmounts.loadCampaign(pCampaign);
	}

	public void CampaignLoadtransaction(Campaign pCampaign) throws Exception {

		mBecAmounts.CampaignLoadtransaction(pCampaign);
	}

	private String getCardTypeFromCardNumber() throws InvalidCardTypeDigitException {
		try {
			return mConstants.getCardType(mCardNumber.getCardTypeDigit());
		} catch (CardTypeDigitNotFoundException e) {
			throw new InvalidCardTypeDigitException(
					"Card type digit '" + mCardNumber.getCardTypeDigit() + "' is not valid.");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecCard#loadMassLoad(com.ikea.
	 * ebccardpay1.cardpayment.be.MassLoad)
	 */
	public void loadMassLoad(MassLoad pMassLoad) throws ValueMissingException, BlockedCardException,
			ExpiredCardException, IllegalCardStateException, InvalidCardNumberException, CurrencyException,
			AmountException, CountrySetupException, IkeaException, InvalidCardException {

		// Create card if needed. It will be activated
		if (mCard == null) {
			assignCard(mBefCard.create());
			mCard.connectCardNumber(mCardNumber);
			initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_MASS_LOAD, "Mass Load " + pMassLoad.getName());
			setCardTypeFromCardNumber();
			mBefCard.save(mCard);
		}

		// Can not load a blocked or expired card
		checkCard();

		// Bind to currency if needed
		bindCard(pMassLoad.getCurrencyCode(), pMassLoad.getCountryCode());
		// Load amount on card
		requireExpireDate();
		String cardType = mCard.getCardType();

		// Check to restrict loading of China GIFT card for more than 1000 CNY
		if (!verifyCardAmountForCN(cardType, pMassLoad.getCurrencyCode(), pMassLoad.getCountryCode(),
				pMassLoad.getAmount())) {
			throw new AmountException("Gift card cannot be loaded for more than 1000 CNY for China");
		}

		if (cardType.equalsIgnoreCase("GIFT") || cardType.equalsIgnoreCase("REFUND")) {
			if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
				throw new AmountException("Card balance is not zero. You can't reload the card");

			}

		}
		// if(cardType.equalsIgnoreCase(Constants.CARD_TYPE_CONSTANT_FAMILY) ||
		// cardType.equalsIgnoreCase(Constants.CARD_TYPE_CONSTANT_VOUCHER) ||
		// cardType.equalsIgnoreCase(Constants.CARD_TYPE_CONSTANT_QPC) ||
		// cardType.equalsIgnoreCase(Constants.CARD_TYPE_CONSTANT_CAMPAIGN)
		// ){
		// throw new AmountException("Campaign, QPC, Voucher and Family cards cannot be
		// loaded through Massload");
		// }
		// Create amounts for Mass Load
		mBecAmounts.loadMassLoad(pMassLoad);
	}

	public void loadMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pAmountValue)
			throws InvalidCardNumberException, IllegalArgumentException, ValueMissingException, CardException,
			CardPayException, IkeaException {
		// Create card if needed. It will be activated
		if (mCard == null) {
			assignCard(mBefCard.create());
			mCard.connectCardNumber(mCardNumber);
			initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_MULTIPLE_SINGLE_LOAD,
					"Multiple Single Load " + pMultipleSingleLoad.getName());
			setCardTypeFromCardNumber();
			mBefCard.save(mCard);
		}

		// Can not load a blocked or expired card
		checkCard();

		// Bind to currency if needed
		bindCard(pMultipleSingleLoad.getCurrencyCode(), pMultipleSingleLoad.getCountryCode());
		// Load amount on card
		String cardType = mCard.getCardType();

		if (!verifyCardAmountForCN(cardType, pMultipleSingleLoad.getCurrencyCode(),
				pMultipleSingleLoad.getCountryCode(), pAmountValue)) {
			throw new AmountException("Gift card cannot be loaded for more than 1000 CNY for China");
		}

		if (cardType.equalsIgnoreCase("GIFT") || cardType.equalsIgnoreCase("REFUND")) {
			if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
				throw new AmountException("Card balance is not zero. You can't reload the card");

			}
		}
		// Create amount for Multiple Single Load
		mBecAmounts.loadMultipleSingleLoad(pMultipleSingleLoad, pAmountValue);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecCard#loadBonus(com.ikea.ebccardpay1
	 * .cardpayment.be.Bonus)
	 */
	public void loadBonus(Bonus pBonus) throws ValueMissingException, BlockedCardException, ExpiredCardException,
			IllegalCardStateException, InvalidCardNumberException, CurrencyException, AmountException,
			CountrySetupException, IkeaException, InvalidCardException {

		requireCard();

		// Can not load a blocked or expired card
		checkCard();

		// Bind to currency if needed
		bindCard(pBonus.getCurrencyCode(), pBonus.getCountryCode());
		// Load amount on card
		String cardType = mCard.getCardType();

		if (!verifyCardAmountForCN(cardType, pBonus.getCurrencyCode(), pBonus.getCountryCode(),
				pBonus.getBonusAmount())) {
			throw new AmountException("Gift card cannot be loaded for more than 1000 CNY for China");
		}

		if (cardType.equalsIgnoreCase("GIFT") || cardType.equalsIgnoreCase("REFUND")) {
			if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
				throw new AmountException("Card balance is not zero. You can't reload the card");

			}
		}
		// Create amount/s for bonus
		mBecAmounts.loadBonus(pBonus);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#block()
	 */
	public void block(String pDescription) throws IllegalArgumentException, BlockedCardException, ExpiredCardException,
			AmountException, ValueMissingException {

		// Can not block a card that is already blocked or an expired card
		checkCard();

		// If card balance is not zero, throw error
		if (!Amounts.isZero(calculateBalance(mTimeSource.currentDate(), new ArrayList<VoBalanceAmount>(), null))) {
			throw new AmountException("Card balance is not zero. Please empty card before blocking.");

		}

		changeCardState(Constants.CARD_STATE_CONSTANT_BLOCKED, pDescription);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#manual(com.ikea.ebccardpay1
	 * .cardpayment.vo.VoManualTransaction)
	 */
	public void manual(VoManualTransaction pVoManualTransaction)
			throws CardException, CurrencyException, AmountException, ValueMissingException, ReferenceCheckException,
			TransactionException, IkeaException, InvalidForeignCardException {

		// Check if redeem
		boolean vIsRedeem = Constants.TRANSACTION_TYPE_CONSTANT_REDEEM
				.equals(pVoManualTransaction.getTransactionType());

		if (!vIsRedeem) {
			throw new TransactionException("Invalid transation type for manual transaction, only redeem is supported");
		}

		if (vIsRedeem) {
			VoRequestAmount vVoRequestAmount = new VoRequestAmount();

			vVoRequestAmount.setCurrencyCode(pVoManualTransaction.getCurrencyCode());
			vVoRequestAmount.setRequestAmount(pVoManualTransaction.getAmount());

			// Set totalAmount same as amount. Only applicable for flow of BS
			// ManualTransaction
			// Must have this set to handle ManualRedemption in forreign
			// currency
			vVoRequestAmount.setTotalAmount(pVoManualTransaction.getAmount());

			// redeemAmount(vVoRequestAmount, null, true);
			redeemAmountManual(vVoRequestAmount, null, true, pVoManualTransaction, mCardNumberString);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#calculateBalance()
	 */
	public VoCard calculateBalance() throws ValueMissingException {

		mCategory.info("Calculate balance.");
		requireCard();

		// We require a business unit here so that we will be sure that
		// business units are passed to findActiveAmounts of BecAmounts
		// inside the calculateBalance called below.
		requireBusinessUnitEnvironment();

		VoCard vVoCard = createVoCard();
		vVoCard.setVoBalanceAmountList(new ArrayList<VoBalanceAmount>());

		vVoCard.setBalanceDateTime(mTimeSource.currentDate());
		vVoCard.setVoBalanceAmountList(new ArrayList<VoBalanceAmount>());
		// Fill the empty list with valid amounts
		vVoCard.setBalanceAmount(
				calculateBalance(vVoCard.getBalanceDateTime(), vVoCard.getVoBalanceAmountList(), null));
		
		//PAYM-7178
		BigDecimal reservedBalance = new BigDecimal(0.0);
		
		List<ReservedCardHistory> reservedList = mBefReservedCardHistory.getCurrentAuthorizeAmountList(mCard);
		for (Iterator<ReservedCardHistory> i = reservedList.iterator(); i.hasNext();) {
			ReservedCardHistory reservedCardHistory = (ReservedCardHistory) i.next();
			if("AUTHORIZE_REDEEM".equals(reservedCardHistory.getReservedTransactionType())) {
				
			reservedBalance = reservedBalance.add(reservedCardHistory.getCardBalanceChange());
			
			}
		}
		vVoCard.setReservedAmount(reservedBalance);
		vVoCard.setReservedCurrencyCode(mCard.getCurrencyCode());
		
		return vVoCard;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#calculateBalance()
	 */
	public VoCardComplete calculateCompleteBalance() throws ValueMissingException {

		mCategory.info("Calculate balance.");
		requireCard();

		VoCardComplete vVoCardComplete = createVoCardComplete();

		vVoCardComplete.setBalanceDateTime(mTimeSource.currentDate());
		vVoCardComplete.setVoBalanceAmountList(new ArrayList<VoBalanceAmount>());
		vVoCardComplete.setVoAmountList(new ArrayList<VoAmount>());
		vVoCardComplete.setBalanceAmount(calculateBalance(vVoCardComplete.getBalanceDateTime(),
				vVoCardComplete.getVoBalanceAmountList(), vVoCardComplete.getVoAmountList()));

		//PAYM-7178
				BigDecimal reservedBalance = new BigDecimal(0.0);
				
				List<ReservedCardHistory> reservedList = mBefReservedCardHistory.getCurrentAuthorizeAmountList(mCard);
				for (Iterator<ReservedCardHistory> i = reservedList.iterator(); i.hasNext();) {
					ReservedCardHistory reservedCardHistory = (ReservedCardHistory) i.next();
					
					if("AUTHORIZE_REDEEM".equals(reservedCardHistory.getReservedTransactionType())) {
						
						reservedBalance = reservedBalance.add(reservedCardHistory.getCardBalanceChange());
						
					}
					
					
				}
				vVoCardComplete.setReservedAmount(reservedBalance);
				vVoCardComplete.setReservedCurrencyCode(mCard.getCurrencyCode());
		
		return vVoCardComplete;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#retrieveCardHistory()
	 */
	public VoCardHistory retrieveCardHistory() throws ValueMissingException {

		mCategory.info("Retrieving card history.");
		requireCard();

		VoCardHistory vVoCard = createVoCardHistory();

		vVoCard.setBalanceDateTime(mTimeSource.currentDate());
		vVoCard.setVoBalanceAmountList(new ArrayList<VoBalanceAmount>());
		vVoCard.setBalanceAmount(
				calculateBalance(vVoCard.getBalanceDateTime(), vVoCard.getVoBalanceAmountList(), null));

		return vVoCard;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#assignToCountryCode(java
	 * .lang.String)
	 */
	public void assignToCountryCode(String pCountryCode) throws ValueMissingException, CountrySetupException {

		requireCard();

		if (pCountryCode != null && pCountryCode.length() > 0) {
			mCard.setCountryCode(pCountryCode);

			mCategory.info("Assigning card to " + pCountryCode + ".");

			if (mCard.getExpireDate() == null) {
				int vExpireDays = mCountrySetups.getExpireDays(mCard.getCountryCode(), mCard.getCardType());

				// Check to see if there is an expire date for this country
				if (vExpireDays > 0) {
					mCategory.info("Setting expire date to " + vExpireDays + " days from now.");

					// Create a DateTime from now and add the expire days
					DateTime vNow = new DateTime(mTimeSource.currentDate());
					DateTime vExpireDate = vNow.plusDays(vExpireDays);

					// Set expire date on card
					setExpireDate(Dates.withoutTime(vExpireDate));
				}
			}

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#setExpireDate(java.util.
	 * Date)
	 */
	public void resetExpireDate() throws CountrySetupException, ValueMissingException {

		requireCard();
		if (mCard.getCountryCode() != null && mCard.getCountryCode().length() > 0) {

			mCategory.info("Get expireDate for country  " + mCard.getCountryCode() + ".");

			if (mCard.getExpireDate() != null) {
				return;
			}

			int vExpireDays = mCountrySetups.getExpireDays(mCard.getCountryCode(), mCard.getCardType());

			// Check to see if there is an expire date for this country
			if (vExpireDays > 0) {
				mCategory.info("Resetting expire date to " + vExpireDays + " days from now.");

				// Create a DateTime from now and add the expire days
				DateTime vNow = new DateTime(mTimeSource.currentDate());
				DateTime vExpireDate = vNow.plusDays(vExpireDays);

				// Set expire date on card
				setExpireDate(Dates.withoutTime(vExpireDate));
			} else if (vExpireDays == 0) {
				mCard.setExpireDate(null);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#setExpireDate(java.util.
	 * Date)
	 */
	public void setExpireDate(Date pDate) throws ValueMissingException {

		requireCard();

		if (pDate != null) {
			mCard.setExpireDate(pDate);
		}
	}

	// ---------- Internal methods, must be protected so unit tests can access
	// them ----------

	protected void cancelUnacknowledged() throws ValueMissingException, ReferenceCheckException {

		// Only operations that comes from a Paymnet Systsem (not iPay Admin)
		// will result in a cancel of unacknowledged
		if (pointOfSaleContext()) {

			mCategory.info("Search and cancel unacknowledged transactions.");
			// Undo all unacknowledged transactions
			try {
				mBecReferenceCheck.cancelUnacknowledged();
			} catch (AmountException e) {
				throw new IllegalStateException("Could not cancel unacknowledged transactions. " + e.toString());
			}
		} else {
			mCategory.info("We are not in a POS context and will NOT try cancel unacknowledged transactions.");
		}
	}

	/**
	 * Are we processing a request from a POS System? Some operations like cancel
	 * unacknowledged and migarte cards are only valid if we come from a POS.
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	protected boolean pointOfSaleContext() {
		return mTransactionEnvironment != null && mConstants.isPointOfSale(mTransactionEnvironment.getSourceSystem());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#calculateBalance()
	 */
	protected BigDecimal calculateBalance(Date pCalculationTime, List<VoBalanceAmount> pBalanceAmountListToFill,
			List<VoAmount> pAmountListToFill) throws ValueMissingException {

		mCategory.info("Calculating balance for " + pCalculationTime);
		requireCard();

		// If the business unit is set, it will be included in the active
		// amounts
		// calculation
		String vBuType = null;
		String vBuCode = null;
		if (mBusinessUnitEnvironment != null) {
			vBuType = mBusinessUnitEnvironment.getBuType();
			vBuCode = mBusinessUnitEnvironment.getBuCode();
		}

		// Ignore total amounts in calculate balance. This means that Discounts
		// that
		// has a minimum purchase amount will be included in the balance
		List<Amount> vBalanceAmounts = mBecAmounts.findActiveAmounts(pCalculationTime, null, vBuType, vBuCode);

		BigDecimal vBalance = new BigDecimal(0.0);

		for (Iterator<Amount> i = vBalanceAmounts.iterator(); i.hasNext();) {
			Amount vAmount = (Amount) i.next();
			vBalance = vBalance.add(vAmount.getCurrentAmount());

			VoBalanceAmount vVoBalanceAmount = new VoBalanceAmount();
			ValueObjects.assignToValueObject(vVoBalanceAmount, vAmount);
			pBalanceAmountListToFill.add(vVoBalanceAmount);
		}

		// Fill the complete amount list too.
		if (pAmountListToFill != null) {

			BigDecimal vOne = new BigDecimal(1.0);
			BigDecimal vNicePriority = vOne;

			List<Amount> vAmounts = new ArrayList<Amount>(mCard.getAmounts());
			Collections.sort(vAmounts, new Comparator<Amount>() {
				public int compare(Amount o1, Amount o2) {
					Amount a1 = (Amount) o1, a2 = (Amount) o2;
					return a1.getPriority().compareTo(a2.getPriority());
				}
			});

			for (Iterator<Amount> j = vAmounts.iterator(); j.hasNext();) {
				Amount vAmount = (Amount) j.next();

				VoAmount vVoAmount = new VoAmount();
				ValueObjects.assignToValueObject(vVoAmount, vAmount);
				vVoAmount.setPriority(vNicePriority);
				vNicePriority = vNicePriority.add(vOne);

				// All could have a bonus code connected to the amount
				if (vAmount.getBonusCode() != null) {
					VoBonusCodeBrief vVoBonusCodeBrief = new VoBonusCodeBrief();
					ValueObjects.assignToValueObject(vVoBonusCodeBrief, vAmount.getBonusCode());
					vVoAmount.setVoBonusCodeBrief(vVoBonusCodeBrief);
				}

				// Campaign...
				if (vAmount.getCampaign() != null) {
					vVoAmount.setVoCampaignValidity(vAmount.getCampaign().getVoCampaignValidity());
				}

				// .. or Mass Load ....
				if (vAmount.getMassLoad() != null) {
					VoMassLoadBrief vVoMassLoadBrief = new VoMassLoadBrief();
					ValueObjects.assignToValueObject(vVoMassLoadBrief, vAmount.getMassLoad());
					vVoAmount.setVoMassLoadBrief(vVoMassLoadBrief);
				}

				// ... or Bonus.
				if (vAmount.getBonus() != null) {
					VoBonus vVoBonus = new VoBonus();
					ValueObjects.assignToValueObject(vVoBonus, vAmount.getBonus());
					vVoAmount.setVoBonus(vVoBonus);
				}
				pAmountListToFill.add(vVoAmount);
			}
		}

		return vBalance;
	}

	/**
	 * Binds the card to a currency and country if needed, i.e. it has not been
	 * bound before.
	 * 
	 * @param pCurrencyCode
	 * @param pCountryCode
	 * @throws IllegalCardStateException
	 * @throws ValueMissingException
	 */
	protected void bindCard(String pCurrencyCode, String pCountryCode)
			throws IllegalCardStateException, ValueMissingException, CountrySetupException {

		if (pCurrencyCode == null) {
			throw new ValueMissingException("Missing Currency Code in bindCard");
		} else if (pCountryCode == null) {
			throw new ValueMissingException("Missing Country Code in bindCard");
		}

		mCategory.info("Binding card to " + pCurrencyCode + ".");

		requireCard();

		if (mCard.getCurrencyCode() == null || mCard.getCurrencyCode().length() == 0) {

			if (!Constants.CARD_STATE_CONSTANT_ACTIVE.equals(mCard.getCardState())) {
				throw new IllegalCardStateException("Card had wrong state. Must be "
						+ Constants.CARD_STATE_CONSTANT_ACTIVE + ". Currenct state is " + mCard.getCardState() + ".");
			}

			mCard.setCurrencyCode(pCurrencyCode);

			// Assign to country code and set expire date if needed
			assignToCountryCode(pCountryCode);

			changeCardState(Constants.CARD_STATE_CONSTANT_BOUND, "");

		} else if (!mCard.getCurrencyCode().equalsIgnoreCase(pCurrencyCode)) {
			mCategory.warn("Card currency is already set to " + mCard.getCurrencyCode() + ". Not changing.");
			// BecAmount will deal with this.

			// Reset expire date even if this is a cross-currency load if expire
			// date is set for the country connected to the card
			resetExpireDate();

		} else {
			mCategory.info("Card currency is already set to " + mCard.getCurrencyCode() + ".");
			// Reset expire date when a new LOAD is made if expire date is set
			// for the country connected to the card
			resetExpireDate();
		}

	}

	/**
	 * Tries to find the card number, if it exists AND is not connected to a card
	 * then use this card number. If the card number does not exist the create a new
	 * card number. Finally connect the (old or new) card number to the card.
	 * 
	 * @param pCardNumberString
	 * @throws InvalidCardNumberException if the card number string does not match
	 *                                    the regexp, the check didgit is not
	 *                                    correct, or the card type didgit is not
	 *                                    supported.
	 * @throws DuplicateCardException     if a card with this card number already
	 *                                    exists in the database.
	 */
	protected void findOrCreateCardNumber(String pCardNumberString)
			throws InvalidCardNumberException, DuplicateCardException, ValueMissingException {

		requireCard();

		mCategory.info(
				"Checking if the card number (not the card object just the card number object) already exists in db.");

		try {
			mBecCardNumber.findCardNumber(pCardNumberString);

			mCategory.info("Found card number in db, checking if it is connected to a card.");

			if (mBecCardNumber.getCardNumber().getCard() != null) {
				throw new DuplicateCardException();
			}

			mCategory.info(
					"The card number is not connected to a card, but it exists in the db. We do not have to create the number, using the old one.");

		} catch (CardNumberNotFoundException e) {
			mCategory.info("No card number entry found in db. Creating a new.");
			mBecCardNumber.createCardNumber(pCardNumberString);
		}

		mCard.connectCardNumber(mBecCardNumber.getCardNumber());
	}

	/**
	 * 
	 * @param pCardNumberString
	 * @return
	 * @throws IkeaException
	 */
	public Card tryExternalCardNumber(String pCardNumberString)
			throws ValueMissingException, InvalidCardNumberException, ExternalCardNotFoundException, IkeaException {

		mCategory.info("Internal card number not found, trying searching as external card number");

		// Search among the external card numbers
		BecExternalCard vBecExternalCard = mBecFactory.createBecExternalCard();
		if (mVoExternalCardSystemKey != null) {
			vBecExternalCard.init(mVoExternalCardSystemKey.getName());
		}

		vBecExternalCard.findExternal(pCardNumberString);
		Card vCard = vBecExternalCard.getExternalCard().getCard();

		if (vCard == null) {
			mCategory.info(
					"No internal card exists for this external card. Creating an internal card out of the info of the external card.");

			return vBecExternalCard.createInternalFromExternal();
		}
		return vCard;
	}

	/**
	 * Sets the card types based on the card type digit in the card number string.
	 * 
	 * @throws InvalidCardNumberException if the card type digit is not valid
	 */
	protected void setCardTypeFromCardNumber() throws InvalidCardNumberException {
		try {
			mCard.setCardType(mConstants.getCardType(mCard.getCardNumber().getCardTypeDigit()));
		} catch (CardTypeDigitNotFoundException e) {
			throw new InvalidCardTypeDigitException(
					"Card type digit '" + mCard.getCardNumber().getCardTypeDigit() + "' is not valid.");
		}
	}

	/**
	 * @param pCardStateConstant
	 * @return the life cycle type constant
	 * @throws IllegalArgumentException if the card state argument is not a valid
	 *                                  card state constant
	 */
	protected String mapLifeCycleType(String pCardStateConstant) throws IllegalArgumentException {

		String vType = null;
		if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_ACTIVE)) {
			vType = Constants.LIFE_CYCLE_TYPE_CONSTANT_ACTIVATED;
		} else if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_BOUND)) {
			vType = Constants.LIFE_CYCLE_TYPE_CONSTANT_TRANSACTION;
		} else if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_EXPIRED)) {
			vType = Constants.LIFE_CYCLE_TYPE_CONSTANT_EXPIRED;
		} else if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_BLOCKED)) {
			vType = Constants.LIFE_CYCLE_TYPE_CONSTANT_BLOCKED;
		} else if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_ARCHIVED)) {
			vType = Constants.LIFE_CYCLE_TYPE_CONSTANT_ARCHIVED;
		} else if (pCardStateConstant.equals(Constants.CARD_STATE_CONSTANT_INACTIVE)) {
			vType = null;
		} else {
			throw new IllegalArgumentException(
					"Internal error. Undefined card state change! Can not change to '" + pCardStateConstant + "'.");
		}
		return vType;
	}

	/**
	 * Set the inital card state and create a life cycle object
	 * 
	 * @param pLifeCycleType
	 * @param pDescription
	 * @return the new life cycle object connected to the card
	 * @throws IllegalArgumentException if the card state argument is not a valid
	 *                                  card state constant
	 * @throws ValueMissingException    if TransactionEnvironment is not set
	 */
	protected void initCardState(String pLifeCycleType, String pDescription)
			throws IllegalArgumentException, ValueMissingException {

		requireCard();

		String vCardStateConstant = Constants.CARD_STATE_CONSTANT_ACTIVE;

		// Translate card state change into life cycle type
		String vLifeCycleType = pLifeCycleType;
		if (vLifeCycleType == null) {
			vLifeCycleType = mapLifeCycleType(vCardStateConstant);
		}

		// Create lifecycle object
		mCategory.info("Creating life cycle object for initial state.");
		LifeCycle vLifeCycle = mBefLifeCycle.create();
		vLifeCycle.setPrevState(null);
		vLifeCycle.setNextState(vCardStateConstant);
		vLifeCycle.setLifeCycleType(vLifeCycleType);
		vLifeCycle.setDescription(pDescription);

		if (mTransactionEnvironment != null) {
			vLifeCycle.setSourceSystem(mTransactionEnvironment.getSourceSystem());
		}

		if (mBusinessUnitEnvironment != null) {
			vLifeCycle.setBuType(mBusinessUnitEnvironment.getBuType());
			vLifeCycle.setBuCode(mBusinessUnitEnvironment.getBuCode());
		}

		// Use connect - the card is not created in the database jet.
		mCard.connectLifeCycle(vLifeCycle);
		mCard.setLastLifeCycleDateTime(vLifeCycle.getCreatedDateTime());
		mCard.setCardState(vCardStateConstant);

		// Do not call save here on the life cycle object, it will be saved when
		// card is saved
		// since the relation is cascading="all" and the card object is not
		// created in the db yet.
	}

	/**
	 * @param pCardStateConstant
	 * @param pDescription
	 * @throws IllegalArgumentException if the card state argument is not a valid
	 *                                  card state constant
	 * @throws ValueMissingException    if the card or TransactionEnvironment is not
	 *                                  set.
	 */
	protected void changeCardState(String pCardStateConstant, String pDescription)
			throws IllegalArgumentException, ValueMissingException {

		mCategory.info("Changing card state to " + pCardStateConstant);

		requireCard();

		// Translate card state change into life cycle type
		String vLifeCycleType = mapLifeCycleType(pCardStateConstant);

		// Change the state
		String vPrevState = mCard.getCardState();
		mCard.setCardState(pCardStateConstant);

		// Create lifecycle object
		mCategory.info("Creating life cycle object for state change " + vPrevState + " -> " + pCardStateConstant);
		LifeCycle vLifeCycle = mBefLifeCycle.create();
		mCard.setLastLifeCycleDateTime(mTimeSource.currentDate());
		if (pointOfSaleContext()) {
			// Use setCard and not connectCard - we do not want to read all life
			// cycles into a set before inserting the new one.
			vLifeCycle.setCard(mCard);
		} else {
			vLifeCycle.connectCard(mCard);
		}
		vLifeCycle.setPrevState(vPrevState);
		vLifeCycle.setNextState(pCardStateConstant);
		vLifeCycle.setLifeCycleType(vLifeCycleType);
		vLifeCycle.setDescription(pDescription);

		// Set Source system if we have it.
		if (mTransactionEnvironment != null) {
			vLifeCycle.setSourceSystem(mTransactionEnvironment.getSourceSystem());
		}

		// Set BU if we have it.
		if (mBusinessUnitEnvironment != null) {
			vLifeCycle.setBuType(mBusinessUnitEnvironment.getBuType());
			vLifeCycle.setBuCode(mBusinessUnitEnvironment.getBuCode());
		}

		// Save the life cycle object, the card object is already created in the
		// db.
		mBefLifeCycle.save(vLifeCycle);
	}

	/**
	 * Creates a VO out of the internal card.
	 * 
	 * @return
	 */
	protected VoCard createVoCard() throws ValueMissingException {

		requireCard();

		VoCard vVoCard = new VoCard();
		ValueObjects.assignToValueObject(vVoCard, mCard);

		vVoCard.setIssuer(mCard.getCardNumber().getIssuer());
		vVoCard.setCardTypeDigit(mCard.getCardNumber().getCardTypeDigit());
		vVoCard.setAccountNumber(mEncryptionDecryption.decrypt(mCard.getCardNumber().getAccountNumberEnc()));
		vVoCard.setCheckDigit(mCard.getCardNumber().getCheckDigit());
		vVoCard.setCardNumberString(mBecCardNumber.composeCardNumberString(mCard.getCardNumber()));

		return vVoCard;
	}

	/**
	 * Creates a VO including all amounts out of the internal card.
	 * 
	 * @return
	 */
	protected VoCardComplete createVoCardComplete() {

		VoCardComplete vVoCardComplete = new VoCardComplete();
		ValueObjects.assignToValueObject(vVoCardComplete, mCard);

		vVoCardComplete.setIssuer(mCard.getCardNumber().getIssuer());
		vVoCardComplete.setCardTypeDigit(mCard.getCardNumber().getCardTypeDigit());
		vVoCardComplete.setAccountNumber(mCard.getCardNumber().getAccountNumberEnc());
		vVoCardComplete.setCheckDigit(mCard.getCardNumber().getCheckDigit());
		vVoCardComplete.setCardNumberString(mBecCardNumber.composeCardNumberString(mCard.getCardNumber()));

		return vVoCardComplete;
	}

	/**
	 * Creates a VO out of the internal card with transactions, life cycle events.
	 * 
	 * @return
	 */
	protected VoCardHistory createVoCardHistory() throws ValueMissingException {
		requireCard();

		VoCardHistory vVoCard = new VoCardHistory();
		ValueObjects.assignToValueObject(vVoCard, mCard);

		vVoCard.setIssuer(mCard.getCardNumber().getIssuer());
		vVoCard.setCardTypeDigit(mCard.getCardNumber().getCardTypeDigit());
		vVoCard.setAccountNumber(mCard.getCardNumber().getAccountNumberEnc());
		vVoCard.setCheckDigit(mCard.getCardNumber().getCheckDigit());
		vVoCard.setCardNumberString(mBecCardNumber.composeCardNumberString(mCard.getCardNumber()));

		// Life cycle handling
		List<VoLifeCycle> vVoLifeCycleList = new ArrayList<VoLifeCycle>();
		for (Iterator<LifeCycle> i = mCard.getLifeCycles().iterator(); i.hasNext();) {
			LifeCycle vLifeCycle = (LifeCycle) i.next();
			VoLifeCycle vVoLifeCycle = new VoLifeCycle();
			ValueObjects.assignToValueObject(vVoLifeCycle, vLifeCycle);
			vVoLifeCycleList.add(vVoLifeCycle);
		}
		vVoCard.setVoLifeCycleList(vVoLifeCycleList);
		
		// Reserved card handling
		//PAYM-7178
		List<VoReservedCard> vVoReservedCardList = new ArrayList<VoReservedCard>();
		List<ReservedCardHistory> reservedList = mBefReservedCardHistory.getCurrentAuthorizeAmountList(mCard);
		for (Iterator<ReservedCardHistory> i = reservedList.iterator(); i.hasNext();) {
			ReservedCardHistory reservedCardHistory = (ReservedCardHistory) i.next();
			VoReservedCard vVoReservedCard =  new VoReservedCard();
			ValueObjects.assignToValueObject(vVoReservedCard, reservedCardHistory);
			Long vTransactionNO = new Long(vVoReservedCard.getTransactionNo());

			vVoReservedCard.setWaitingAcknowledgment(isWaitingAcknowledgment(vTransactionNO.longValue()));
			vVoReservedCardList.add(vVoReservedCard);
		}
		vVoCard.setVoReservedCardList(vVoReservedCardList);
		
		
		// Authorizations
		List<Authorization> vList = mBefAuthorization.findByCard(mCard);
		Map<Long, String> vAuthorizations = new HashMap<Long, String>();
		for (Iterator<Authorization> i = vList.iterator(); i.hasNext();) {
			Authorization vAuthorization = (Authorization) i.next();
			vAuthorizations.put(new Long(vAuthorization.getTransactionNo()), vAuthorization.getAuthorizationNumber());
		}

		// Transactions
		mBecTransactions.initTransactions(mCard.getTransactions());
		vVoCard.setVoTransactionList(mBecTransactions.compressDetailed());

		// Set if waiting for acknowledgment on each transaction no.
		for (VoTransaction vVoTransaction : vVoCard.getVoTransactionList()) {

			Long vTransactionNo = new Long(vVoTransaction.getTransactionNo());

			vVoTransaction.setWaitingAcknowledgment(isWaitingAcknowledgment(vTransactionNo.longValue()));

			if (vAuthorizations.containsKey(vTransactionNo)) {
				vVoTransaction.setAuthorizationNumber((String) vAuthorizations.get(vTransactionNo));
			}
		}

		return vVoCard;
	}

	/**
	 * Does this card have an unacknowledged transaction?
	 * 
	 * @param pTransactionNo
	 * @return
	 * @throws ValueMissingException
	 */
	protected boolean isWaitingAcknowledgment(long pTransactionNo) throws ValueMissingException {
		requireCard();

		if (mCard.getReferenceCheck() == null) {
			return false;
		}
		// The references for this card is already in memory sonce we have read
		// them with join when we read the card from the database.
		for (Iterator<ReferenceCheck> i = mCard.getReferenceCheck().iterator(); i.hasNext();) {
			ReferenceCheck vReferenceCheck = (ReferenceCheck) i.next();
			if (vReferenceCheck.getTransactionNo() == pTransactionNo && vReferenceCheck.getWaitingAck()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws BlockedCardException  if the card is blocked
	 */
	protected void checkCard() throws ValueMissingException, BlockedCardException, ExpiredCardException {
		requireCard();

		if (Constants.CARD_STATE_CONSTANT_BLOCKED.equals(mCard.getCardState())) {
			throw new BlockedCardException();
		}

		// CR-IKEA01097948-iPay card validity on expire date, convert time_source date
		// to DateTime object
		DateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date sDateq = mTransactionEnvironment.getTransmissionDateTime();
		String vValue = sDateFormat.format(sDateq);
		Date sDate;
		try {
			sDate = sDateFormat.parse(vValue);
			if (mCard.getExpireDate() != null && // mCard.getExpireDate().before(mTimeSource.currentDate()
					mCard.getExpireDate().before(sDate)) {
				throw new ExpiredCardException("Card expired '" + mCard.getExpireDate() + "'.");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			throw new ExpiredCardException("Source system Time source issue");
		}

	}

	protected void checkCardCurrency() throws MissingCardCurrencyException {

		if (mCard.getCurrencyCode() == null || "".equals(mCard.getCurrencyCode())) {
			throw new MissingCardCurrencyException("Card has never been loaded, no currency code set yet.");
		}
		mCategory.info("Check card currency:" + mCard.getCurrencyCode());
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException("Tried to use BecCard without required Card.");
	}

	/**
	 * 
	 * @param pCard
	 */
	protected void assignCard(Card pCard) {

		if (mCategory.isDebugEnabled()) {
			mCategory.debug("Assigning card " + CardPaymentLogger.cardToString(pCard));
		}

		setCard(pCard);

		if (pCard != null) {
			mBecAmounts = mBecFactory.createBecAmounts().init(mCard, mBusinessUnitEnvironment, mTransactionEnvironment);

			mBecCardNumber = mBecFactory.createBecCardNumber();

			mBecReferenceCheck = mBecFactory.createBecReferenceCheck().init(mCard, mBusinessUnitEnvironment,
					mTransactionEnvironment);
		} else {
			mBecAmounts = null;
			mBecCardNumber = null;
			mBecReferenceCheck = null;
		}
	}

	/**
	 * Only used in unit tests to set up the BEC!
	 * 
	 * @return
	 */
	protected void setCard(Card pCard) {
		mCard = pCard;
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment() throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required TransactionEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment() throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecCard without required BusinessUnitEnvironment.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCard#checkVerificationCode(java
	 * .lang.String)
	 */
	// iPay4.8.1- Sprint2
	public void checkVerificationCode(String pVerificationCode, String pSourceSystem) throws InvalidVerificationCode {

		if (pSourceSystem != null) {
			// If verification code exist in database for this cardnumber, check if
			// it is a match.
			if (mCardNumber != null && mCardNumber.getVerificationCodeEnc() != null
					&& !mCardNumber.getVerificationCodeEnc().equals("")) {
				if (pVerificationCode == null || !pVerificationCode
						.equals(mEncryptionDecryption.decrypt(mCardNumber.getVerificationCodeEnc()))) {
					throw new InvalidVerificationCode("Invalid verification code. '" + pVerificationCode
							+ "' does not match the actual verification code.");
				}
			}

			if (pSourceSystem.equals("IRW") || pSourceSystem.equals("ICP") || pSourceSystem.equals("ISELL")
					|| pSourceSystem.equals("IME") || pSourceSystem.equals("IPPCAPI")) {

				if (pVerificationCode == null || !pVerificationCode
						.equals(mEncryptionDecryption.decrypt(mCardNumber.getVerificationCodeEnc()))) {

					throw new InvalidVerificationCode("Invalid verification code. '" + pVerificationCode

							+ "' does not match the actual verification code.");

				}
			}

		} else
			throw new InvalidVerificationCode("Invalid input.Source System code is missing '");
	}

	/**
	 * 
	 * @throws AmountException
	 * @throws IkeaException
	 */
	protected void requireExpireDate() throws AmountException, IkeaException {

		String cardType = mCard.getCardType();
		if (cardType != null) {
			if (cardType.equalsIgnoreCase("CAMPAIGN")) {
				return;
			} else if (cardType.equalsIgnoreCase("QPC") && mCard.getExpireDate() == null) {
				throw new AmountException(
						"QPC Card must have an expire date,Please Set the Expire date before loading.");
			}
		}
		/*
		 * else { throw new
		 * AmountException("Invalid CardType or no cardType specified"); }
		 */

	}

	// @Override
	public boolean getExpiredCards(String pFromDate, String pToDate) throws Exception {

		mCategory.info("getExpiredCards()");
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		CopyOnWriteArrayList<Card> cards = new CopyOnWriteArrayList<Card>();

		cards = (CopyOnWriteArrayList<Card>) mBefCard.getExpiredCards(pFromDate, pToDate);

		CopyOnWriteArrayList<Card> expiredCards = null;

		if (cards.size() > 6000) {
			Collection<Card> cd = new ArrayList<Card>(cards.subList(1, 5000));
			expiredCards = new CopyOnWriteArrayList<Card>(cd);
		} else {
			expiredCards = cards;
		}

		if (expiredCards != null && !expiredCards.isEmpty()) {
			mCategory.info("Total ExpiredCards : " + expiredCards.size());
			List<Transaction> expiredTransactions = new ArrayList<Transaction>();

			Iterator<Card> cardlist = expiredCards.listIterator();
			while (cardlist.hasNext()) {

				Card icard = cardlist.next();

				if (!icard.getCardState().equalsIgnoreCase(Constants.CARD_STATE_CONSTANT_EXPIRED)) {
					if (icard != null && icard.getAmounts() != null) {

						icard.setCardState(Constants.CARD_STATE_CONSTANT_EXPIRED);
						icard.setLastTransactionDateTime(new Date());
						icard.setLastLifeCycleDateTime(new Date());

						for (Amount amount : icard.getAmounts()) {

							if (amount.getCurrentAmount().doubleValue() > 0) {
								Transaction vTransaction = mBefTransaction.create();

								vTransaction.setBuCode(amount.getBuCode());
								vTransaction.setBuType(amount.getBuType());
								vTransaction.setCountryCode(icard.getCountryCode());
								vTransaction.setSwiped("N");
								vTransaction.setTransactionNo(0);
								vTransaction.setCard(icard);
								vTransaction.setTransmissionDateTime(new Date());
								vTransaction.setInsufficientAmount(false);
								vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
								vTransaction
										.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
								vTransaction.setSourceSystem("IPAY");
								vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
								vTransaction.setCrossBorder(false);
								vTransaction.setCrossCurrency(false);
								vTransaction.setVoidedTransactionNo(0);
								vTransaction.setCancelled(false);
								if (icard.getCurrencyCode() != null && !icard.getCurrencyCode().isEmpty())
									vTransaction.setRequestedCurrencyCode(icard.getCurrencyCode());
								else
									vTransaction.setRequestedCurrencyCode("");

								BigDecimal prioCurrentAmount = amount.getCurrentAmount();
								vTransaction.setBalanceChange(amount.getCurrentAmount());
								vTransaction.setCardBalanceChange(amount.getCurrentAmount());
								amount.setCurrentAmount(new BigDecimal(0));
								vTransaction.setAmount(amount);
								vTransaction.setRequestedAmount(prioCurrentAmount);
								vTransaction.setEmployee(Constants.EXPIRE_CARD_JOB);
								vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
								vTransaction.setReference(vTransactionEnvironment.getReference());

								saveTransaction(vTransaction);

							}

						}

					}
				}

			}
			mCategory.info("Create redeem transaction ");

		}

		mCategory.info("Transaction created successfully");

		return true;

	}

	protected void saveTransaction(Transaction pTransaction) {

		if (mCategory.isInfoEnabled()) {
			mCategory.info("Creating transaction no " + pTransaction.getTransactionNo() + " "
					+ pTransaction.getTransactionType() + " " + pTransaction.getBalanceChange());
		}
		// We will explicitly call save here since we are not using connect due to
		// performance reasons.
		mBefTransaction.save(pTransaction);
	}

	// @Override
	public void afterPropertiesSet() throws Exception {
		validate();

	}

	// @Override
	public int getCardSize(String pFromDate, String pToDate) {
		int size = 0;
		try {
			mCategory.info("Inside the list couunt.");
			size = mBefCard.getExpiredCards(pFromDate, pToDate).size();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			mCategory.info(e.getMessage());
		}
		return size;
	}

	/**
	 * @param pMassLoad
	 * @throws ValueMissingException
	 * @throws BlockedCardException
	 * @throws ExpiredCardException
	 * @throws IllegalCardStateException
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws IkeaException
	 * @throws InvalidCardException      - by anagc on 02-16-2016
	 */
	public void withdrawMassLoad(MassLoad pMassLoad) throws ValueMissingException, BlockedCardException,
			ExpiredCardException, IllegalCardStateException, InvalidCardNumberException, CurrencyException,
			AmountException, CountrySetupException, IkeaException, InvalidCardException {

		// withdraw amounts on the card
		mBecAmounts.withdrawMassLoad(pMassLoad);

	}

	// @Override
	public void processExpiredCards(CopyOnWriteArrayList<Card> crdlist, int start, int range) {
		mCategory.info("getExpiredCards()");
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		CopyOnWriteArrayList<Card> expiredCards = crdlist;

		if (expiredCards != null && !expiredCards.isEmpty()) {

			mCategory.info("Total ExpiredCards : " + expiredCards.size());
			// Set<Transaction> expiredTransactions = new HashSet<Transaction>();

			for (int i = start; i < range; i++) {
				if (i < expiredCards.size()) {

					Card icard = expiredCards.get(i);

					if (icard != null && icard.getAmounts() != null) {

						icard.setCardState(Constants.CARD_STATE_CONSTANT_EXPIRED);
						icard.setLastTransactionDateTime(new Date());
						icard.setLastLifeCycleDateTime(new Date());

						for (Amount amount : icard.getAmounts()) {

							Transaction vTransaction = mBefTransaction.create();
							if (Math.max(0, amount.getCurrentAmount().stripTrailingZeros().scale()) > 0) {
								vTransaction.setBuCode(amount.getBuCode());
								vTransaction.setBuType(amount.getBuType());
								vTransaction.setCountryCode(icard.getCountryCode());
								vTransaction.setSwiped("N");
								// vTransaction.setTransactionNo(0);
								vTransaction.setCard(icard);
								vTransaction.setTransmissionDateTime(new Date());
								vTransaction.setInsufficientAmount(false);
								vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
								vTransaction
										.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
								vTransaction.setSourceSystem("IPAY");
								vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
								vTransaction.setCrossBorder(false);
								vTransaction.setCrossCurrency(false);
								vTransaction.setVoidedTransactionNo(0);
								vTransaction.setCancelled(false);
								if (icard.getCurrencyCode() != null && !icard.getCurrencyCode().isEmpty())
									vTransaction.setRequestedCurrencyCode(icard.getCurrencyCode());
								else
									vTransaction.setRequestedCurrencyCode("");

								BigDecimal prioCurrentAmount = amount.getCurrentAmount();
								vTransaction.setBalanceChange(amount.getCurrentAmount());
								vTransaction.setCardBalanceChange(amount.getCurrentAmount());
								amount.setCurrentAmount(new BigDecimal(0));

								vTransaction.setRequestedAmount(prioCurrentAmount);
								vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
								vTransaction.setEmployee(Constants.EXPIRE_CARD_JOB);
								vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
								vTransaction.setReference(vTransactionEnvironment.getReference());
								vTransaction.setAmount(amount);
								// amount.getTransactions().add(vTransaction);

							} else {
								vTransaction.setBuCode(amount.getBuCode());
								vTransaction.setBuType(amount.getBuType());
								vTransaction.setCountryCode(icard.getCountryCode());
								vTransaction.setSwiped("N");
								// vTransaction.setTransactionNo(0);
								vTransaction.setCard(icard);
								vTransaction.setTransmissionDateTime(new Date());
								vTransaction.setInsufficientAmount(false);
								vTransaction.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
								vTransaction
										.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
								vTransaction.setSourceSystem("IPAY");
								vTransaction.setSalesDay(Dates.formatDate(new DateTime()));
								vTransaction.setCrossBorder(false);
								vTransaction.setCrossCurrency(false);
								vTransaction.setVoidedTransactionNo(0);
								vTransaction.setCancelled(false);
								if (icard.getCurrencyCode() != null && !icard.getCurrencyCode().isEmpty())
									vTransaction.setRequestedCurrencyCode(icard.getCurrencyCode());
								else
									vTransaction.setRequestedCurrencyCode("");

								BigDecimal prioCurrentAmount = amount.getCurrentAmount();
								vTransaction.setBalanceChange(amount.getCurrentAmount());
								vTransaction.setCardBalanceChange(amount.getCurrentAmount());
								amount.setCurrentAmount(new BigDecimal(0));

								vTransaction.setRequestedAmount(prioCurrentAmount);
								vTransaction.setEmployee(vTransactionEnvironment.getEmployee().trim());
								vTransaction.setEmployee(Constants.EXPIRE_CARD_JOB);
								vTransaction.setTransactionNo(vTransactionEnvironment.getTransactionNo());
								vTransaction.setReference(vTransactionEnvironment.getReference());
								vTransaction.setAmount(amount);
								// amount.getTransactions().add(vTransaction);

							}

							saveTransaction(vTransaction);
							mBefAmount.merge(amount);
							mBefCard.merge(icard);
						} // End inner for

					}

				}

			} // End of Outer for loop

		} // End of if.

	}

	// @Override
	public void setCardList(CopyOnWriteArrayList<Card> crdlist) {
		BecCardImpl.crdlist = crdlist;

	}

	// @Override
	public CopyOnWriteArrayList<Card> getCardList() {
		// TODO Auto-generated method stub
		return BecCardImpl.crdlist;
	}

	// @Override
	public Collection<Card> getExpCards() throws Exception {
		// TODO Auto-generated method stub
		return mBefCard.getExpiredCards();
	}

	public void expireCampaign(Campaign pCampaign) throws ValueMissingException, BlockedCardException,
			ExpiredCardException, IllegalCardStateException, InvalidCardNumberException, CurrencyException,
			AmountException, CountrySetupException, IkeaException, InvalidCardException, TransactionException {

		mBecAmounts.expireCampign(pCampaign);

	}

	@SuppressWarnings("unchecked")
	// @Override
	public void expiredCardProcessing() throws Exception {
		String date = Dates.formatDate(Dates.getDateTime(new Date()));
		Set<Card> cardSet = new LinkedHashSet<Card>(mBefCard.getExpiredCards());
		for (Card card : cardSet) {

			if (!card.getCardState().equalsIgnoreCase(Constants.CARD_STATE_CONSTANT_EXPIRED)) {
				card.setCardState(Constants.CARD_STATE_CONSTANT_EXPIRED);
				card.setLastTransactionDateTime(new Date());
				card.setLastLifeCycleDateTime(new Date());

				if (card.getAmounts() != null && !card.getAmounts().isEmpty()) {

					for (Amount amt : card.getAmounts()) {

						init(card);
						if (amt.getCurrentAmount().doubleValue() > 0) {

							mBecAmounts.redeemAmount(new ArrayList(card.getAmounts()));
						}

					}
				}

			}

		}
	}

	public void withdrawnCampaign(Campaign pCampaign) throws ValueMissingException, BlockedCardException,
			ExpiredCardException, IllegalCardStateException, InvalidCardNumberException, CurrencyException,
			AmountException, CountrySetupException, IkeaException, InvalidCardException, TransactionException {

		mBecAmounts.withdrawnCampign(pCampaign);

	}

	// @Override
	public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction, Campaign pCampaign)
			throws Exception {

		mBecAmounts.updateCampaignLoadTransactions_Aouthorization(pTransaction, pCampaign);
	}

	// @Override
	public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction, Campaign pCampaign)
			throws Exception {
		mBecAmounts.updateCampaignLoadTransactions_Withdrawal(pTransaction, pCampaign);

	}

	public void CampaignDebiTransaction(Campaign pCampaign, String sales_Day) throws Exception {

		mBecAmounts.CampaignDebiTransaction(pCampaign, sales_Day);
	}

	public void addMassLoadExpiry(Date pExpiryDate) throws ExpiredCardException {

		if (pExpiryDate != null) {
			if (pExpiryDate.after(mTimeSource.currentDate())) {
				mCard.setExpireDate(Dates.withoutTime(new DateTime(pExpiryDate)));
			} else {
				throw new ExpiredCardException("Invalid Mass Load Expiry Date.");
			}

		}

	}

	public void saveMassLoadCard(MassLoad pMassLoad)
			throws IllegalArgumentException, ValueMissingException, InvalidCardNumberException {

		// Create card if needed. It will be activated
		if (mCard == null) {
			assignCard(mBefCard.create());
			mCard.connectCardNumber(mCardNumber);
			initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_MASS_LOAD, "Mass Load " + pMassLoad.getName());
			setCardTypeFromCardNumber();
			mBefCard.save(mCard);
		}

	}

	public void setMassLoadExpiryFromMap(java.util.Map<String, Object> map,
			java.util.List<CardNumber> pCardNumberList) {
		if (map.get("expiryDate") instanceof java.util.Date) {

			if (pCardNumberList != null) {
				for (CardNumber crdNumber : pCardNumberList) {
					mCard = crdNumber.getCard();

					mCard.setExpireDate((java.util.Date) map.get("expiryDate"));
				}
			}

		}

	}

	public void saveCampaignCard(Campaign pCampaign)
			throws IllegalArgumentException, ValueMissingException, InvalidCardNumberException {
		// Create card if needed. It will be activated
		if (mCard == null) {
			assignCard(mBefCard.create());
			mCard.connectCardNumber(mCardNumber);
			initCardState(Constants.LIFE_CYCLE_TYPE_CONSTANT_CAMPAIGN, "Mass Load " + pCampaign.getName());
			setCardTypeFromCardNumber();
			mBefCard.save(mCard);
		}

	}

	public void withdrawnSingleLoad(MultipleSingleLoad pMultipleSingleLoad)
			throws CurrencyException, AmountException, TransactionException, ValueMissingException {

		mBecAmounts.withdrawnSingleLoad(pMultipleSingleLoad);

	}

	protected Boolean verifyCardAmountForCN(String cardType, String currencyCode, String countryCode,
			BigDecimal amount) {

		if (cardType.equalsIgnoreCase("GIFT") && currencyCode.equalsIgnoreCase("CNY")
				&& countryCode.equalsIgnoreCase("CN") && amount.compareTo(VALID_GIFT_CARD_AMOUNT_CN) > 0) {
			return false;
		}

		return true;
	}

	@Override
	public BecCard init(BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment, String pCardNumberString) {
		
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
        mTransactionEnvironment = pTransactionEnvironment;
        mCardNumberString = pCardNumberString;
       
        return this;
	}

}
