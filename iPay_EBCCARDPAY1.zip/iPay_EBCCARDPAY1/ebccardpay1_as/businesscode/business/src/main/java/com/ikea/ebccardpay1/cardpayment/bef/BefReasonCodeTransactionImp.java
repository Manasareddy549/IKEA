package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.ReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

public class BefReasonCodeTransactionImp extends BefAbstract<ReasonCodeTransaction> implements BefReasonCodeTransaction{

	private final static Logger mLogger_findByReference =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByReference");

	private final static Logger mLogger_findByOriginator =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByOriginator");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefReasonCodeTransactionImp(
			SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<ReasonCodeTransaction> getBusinessEntityClass() {
		return ReasonCodeTransaction.class;
	}
	
	@Override
	public void saveReasonCodeTransaction(long transactionId, int reasonCodeId) {
		
		Session vSession = mSessionFactory.getCurrentSession();
		ReasonCodeTransaction txn = new ReasonCodeTransaction();
		
		txn.setTransactionId(transactionId);
		txn.setReasonCodeId(reasonCodeId);

		vSession.save(txn);
		vSession.getTransaction().commit();
	}
	
}
