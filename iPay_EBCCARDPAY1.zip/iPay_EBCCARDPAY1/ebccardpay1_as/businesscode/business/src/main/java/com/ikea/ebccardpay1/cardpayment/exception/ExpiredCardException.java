/*
 * Created on 2007-mar-13
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class ExpiredCardException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4407368775492948023L;

	/**
	 * 
	 */
	public ExpiredCardException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public ExpiredCardException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ExpiredCard();
	}

}
