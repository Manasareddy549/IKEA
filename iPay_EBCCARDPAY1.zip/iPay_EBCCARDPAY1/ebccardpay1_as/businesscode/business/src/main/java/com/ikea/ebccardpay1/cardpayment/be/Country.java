/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Country extends BusinessEntity {
	/**										
	 * Storage: COUNTRY_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mCountryId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<ExchangeRate> mExchangeRates = new java.util.LinkedHashSet<ExchangeRate>(0);
	private java.util.Set<MainCurrency> mMainCurrencies = new java.util.LinkedHashSet<MainCurrency>(0);

	/**										
	 * Data								
	 */										
	private String mCountryCode;
	private String mExchangeMode;
	private boolean mCrossCurrencyAllowed;
	private boolean mCrossCurrencyLoadAllowed;
	private boolean mCrossCurrencyRedeemAllowed;
	private boolean mCardAllowedInForeignCounty;

	/**											
	 * @return Returns the countryId.													
	 */											
	public long getCountryId() {
		return mCountryId;
	}
	/**
	 * @param pCountryId The countryId to set.
	 */
	public void setCountryId(long pCountryId) {
		mCountryId = pCountryId;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the exchangeMode.													
	 */											
	public String getExchangeMode() {
		return mExchangeMode;
	}
	/**
	 * @param pExchangeMode The exchangeMode to set.
	 */
	public void setExchangeMode(String pExchangeMode) {
		mExchangeMode = pExchangeMode;
	}

	/**											
	 * @return Returns the crossCurrencyAllowed.													
	 */											
	public boolean getCrossCurrencyAllowed() {
		return mCrossCurrencyAllowed;
	}
	/**
	 * @param pCrossCurrencyAllowed The crossCurrencyAllowed to set.
	 */
	public void setCrossCurrencyAllowed(boolean pCrossCurrencyAllowed) {
		mCrossCurrencyAllowed = pCrossCurrencyAllowed;
	}

	/**											
	 * @return Returns the crossCurrencyLoadAllowed.													
	 */											
	public boolean getCrossCurrencyLoadAllowed() {
		return mCrossCurrencyLoadAllowed;
	}
	/**
	 * @param pCrossCurrencyLoadAllowed The crossCurrencyLoadAllowed to set.
	 */
	public void setCrossCurrencyLoadAllowed(boolean pCrossCurrencyLoadAllowed) {
		mCrossCurrencyLoadAllowed = pCrossCurrencyLoadAllowed;
	}

	/**											
	 * @return Returns the crossCurrencyRedeemAllowed.													
	 */											
	public boolean getCrossCurrencyRedeemAllowed() {
		return mCrossCurrencyRedeemAllowed;
	}
	/**
	 * @param pCrossCurrencyRedeemAllowed The crossCurrencyRedeemAllowed to set.
	 */
	public void setCrossCurrencyRedeemAllowed(boolean pCrossCurrencyRedeemAllowed) {
		mCrossCurrencyRedeemAllowed = pCrossCurrencyRedeemAllowed;
	}

	/**											
	 * @return Returns the exchangeRates.													
	 */											
	public java.util.Set<ExchangeRate> getExchangeRates() {
		return mExchangeRates;
	}
	/**
	 * @param pExchangeRates The exchangeRates to set.
	 */
	public void setExchangeRates(java.util.Set<ExchangeRate> pExchangeRates) {
		mExchangeRates = pExchangeRates;
	}

	/**											
	 * @return Returns the mainCurrencies.													
	 */											
	public java.util.Set<MainCurrency> getMainCurrencies() {
		return mMainCurrencies;
	}
	/**
	 * @param pMainCurrencies The mainCurrencies to set.
	 */
	public void setMainCurrencies(java.util.Set<MainCurrency> pMainCurrencies) {
		mMainCurrencies = pMainCurrencies;
	}
	
	/**											
	 * @return Returns the cardAllowedInForeignCounty.													
	 */	
	public boolean getCardAllowedInForeignCounty() {
		return mCardAllowedInForeignCounty;
	}
	
	/**
	 * @param pCardAllowedInForeignCounty The cardAllowedInForeignCounty to set.
	 */
	public void setCardAllowedInForeignCounty(boolean pCardAllowedInForeignCounty) {
		mCardAllowedInForeignCounty = pCardAllowedInForeignCounty;
	}

	/**
	 * Connect a ExchangeRate.
	 * @param pExchangeRate
	 */
	public void connectExchangeRate(ExchangeRate pExchangeRate) {
		getExchangeRates().add(pExchangeRate);
		if(pExchangeRate != null) {
			pExchangeRate.setCountry(this);
		}
	}

	/**
	 * Disconnect a ExchangeRate.
	 * @param pExchangeRate
	 */
	public void disconnectExchangeRate(ExchangeRate pExchangeRate) {
		if(pExchangeRate != null) {
			pExchangeRate.setCountry(null);
		}
		getExchangeRates().remove(pExchangeRate);
	}

	/**
	 * Connect a MainCurrency.
	 * @param pMainCurrency
	 */
	public void connectMainCurrency(MainCurrency pMainCurrency) {
		getMainCurrencies().add(pMainCurrency);
		if(pMainCurrency != null) {
			pMainCurrency.setCountry(this);
		}
	}

	/**
	 * Disconnect a MainCurrency.
	 * @param pMainCurrency
	 */
	public void disconnectMainCurrency(MainCurrency pMainCurrency) {
		if(pMainCurrency != null) {
			pMainCurrency.setCountry(null);
		}
		getMainCurrencies().remove(pMainCurrency);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mCountryId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("countryId", CodeGeneration.toObject(mCountryId));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("exchangeMode", CodeGeneration.toObject(mExchangeMode));
		vMap.put("crossCurrencyAllowed", CodeGeneration.toObject(mCrossCurrencyAllowed));
		vMap.put("crossCurrencyLoadAllowed", CodeGeneration.toObject(mCrossCurrencyLoadAllowed));
		vMap.put("crossCurrencyRedeemAllowed", CodeGeneration.toObject(mCrossCurrencyRedeemAllowed));
		vMap.put("cardAllowedInForeignCounty", CodeGeneration.toObject(mCardAllowedInForeignCounty));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("countryId")) mCountryId = CodeGeneration.objectTolong(pMap.get("countryId"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("exchangeMode")) mExchangeMode = CodeGeneration.objectToString(pMap.get("exchangeMode"));
		if(pMap.containsKey("crossCurrencyAllowed")) mCrossCurrencyAllowed = CodeGeneration.objectToboolean(pMap.get("crossCurrencyAllowed"));
		if(pMap.containsKey("crossCurrencyLoadAllowed")) mCrossCurrencyLoadAllowed = CodeGeneration.objectToboolean(pMap.get("crossCurrencyLoadAllowed"));
		if(pMap.containsKey("crossCurrencyRedeemAllowed")) mCrossCurrencyRedeemAllowed = CodeGeneration.objectToboolean(pMap.get("crossCurrencyRedeemAllowed"));
		if(pMap.containsKey("cardAllowedInForeignCounty")) mCardAllowedInForeignCounty = CodeGeneration.objectToboolean(pMap.get("cardAllowedInForeignCounty"));
	}
}
