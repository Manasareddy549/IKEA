/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.common.TimeSource;
import java.util.StringTokenizer;

import java.text.ParseException;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import org.springframework.transaction.annotation.Transactional;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import org.joda.time.DateTime;
import org.hibernate.criterion.Restrictions;
import org.hibernate.Criteria;
import com.ikea.ebccardpay1.common.*;

/**
 * @author anms
 * @author tpon
 */
public class BefCardImpl extends BefAbstract<Card> implements BefCard{
	
	
	private final static Logger mLogger_findByOriginator =
		LoggerFactory.getLogger(
			BefTransactionImpl.class.getName() + ".findByOriginator");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCardImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<Card> getBusinessEntityClass() {
		return Card.class;
	}

	
	@SuppressWarnings("unchecked")
	//@Override
	public CopyOnWriteArrayList<Card> getExpiredCards(String fromdate,
			String tDate) throws Exception {
		Session vSession = mSessionFactory.getCurrentSession();

		try {
			mLogger_findByOriginator.info(" Fetch data from DB");
			String pattern = "yyyy-MM-dd";
			SimpleDateFormat dateFormater = new SimpleDateFormat(pattern);
			Date vFromDate= dateFormater.parse(fromdate);
			Date vToDate= dateFormater.parse(tDate);
			
			GenericCriteria<Card> vCriteria = new GenericCriteria<Card>(
					vSession.createCriteria(Card.class));
			vCriteria.add(Restrictions.ge("expireDate",
					vFromDate));

			vCriteria.add(Restrictions.lt("expireDate",
					vToDate));
			vCriteria.add(Restrictions.ne("cardState",Constants.CARD_STATE_CONSTANT_EXPIRED));
			vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			Collection<Card> cardList = new ArrayList<Card>(vCriteria.list());
			CopyOnWriteArrayList<Card> expiredCards = new CopyOnWriteArrayList<Card>(
					cardList);
			
			return expiredCards;
		} catch (Exception e) {
			mLogger_findByOriginator
					.error("Error while fetching the data from DB : " + e);
			throw e;
		}

	}	
	 public Date calculateFromDate(String pFromDate){
		 SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		 String tempDate = null;
		 StringTokenizer token = new StringTokenizer(pFromDate,"-");
		
		 StringBuffer buffer = new StringBuffer();
		 
		 while(token.hasMoreTokens()){
			 buffer.append(token.nextToken()) ;
		 }
		
		 tempDate = buffer.toString();
		 Date tempdt = null;
		try {
			tempdt = format.parse(tempDate);
		} catch (ParseException e) {
			
			mLogger_findByOriginator.info(e.getMessage());
		}
		 Date finalFromDt =  new java.sql.Date(tempdt.getTime());
		 
		 return finalFromDt;
		
	}
	 
	 public Date calculateToDate(String pToDate){
		 SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		 String tempDate = null;
		 StringTokenizer token = new StringTokenizer(pToDate,"-");
		
		 StringBuffer buffer = new StringBuffer();
		 
		 while(token.hasMoreTokens()){
			 buffer.append(token.nextToken()) ;
		 }
		
		 tempDate = buffer.toString();
		 Date tempdt = null;
		try {
			tempdt = format.parse(tempDate);
		} catch (ParseException e) {
			
			mLogger_findByOriginator.info(e.getMessage());
		}
		 Date finalToDt =  new java.sql.Date(tempdt.getTime());
		 
		 return finalToDt;
		
	}
	
	@SuppressWarnings("unchecked")
	//@Override
	public Collection<Card> getExpiredCards() throws Exception {

		Session vSession = getCurrentSession();

		mLogger_findByOriginator.info(" Fetch data from DB");

		Collection<Card> crdCollection = new ArrayList<Card>();

		try {

			GenericCriteria<Card> vCriteria = new GenericCriteria<Card>(
					vSession.createCriteria(Card.class));
			
			    String pattern = "yyyy-MM-dd";
						
			    SimpleDateFormat dateFormater = new SimpleDateFormat(pattern);
			    /* CR- IKEA01097948, Selecting cards which has expired previous day, not on current day
				String fromDateString = dateFormater.format(new DateTime().toDate());
			    String toDateString = dateFormater.format(new DateTime().plusDays(1).toDate());
			    	*/
			    
			    String fromDateString = dateFormater.format(new DateTime().minusDays(1).toDate());//expired previous day
			    String toDateString = dateFormater.format(new DateTime().toDate());// till todays date.
			    
			    Date startOfDay = dateFormater.parse(fromDateString);
			    Date endOfDay   = dateFormater.parse(toDateString);
				
			    
			    vCriteria.add(Restrictions.ge("expireDate",
			    		startOfDay));

				vCriteria.add(Restrictions.lt("expireDate",
						endOfDay));

			vCriteria.add(Restrictions.ne("cardState",
					Constants.CARD_STATE_CONSTANT_EXPIRED));
			vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			crdCollection = vCriteria.list();

		} catch (Exception ex) {
			mLogger_findByOriginator
					.info(" Error while retriving data  from DB");
		}

		return crdCollection;

	}

	public Card findByCardId(long pCardId) {
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from Card where cardId=:cardId";

		Card vCard =
			(Card) vSession
			.createQuery(vHql)
			.setParameter("cardId", pCardId)
			.uniqueResult();

		if (vCard == null) {
			mLogger_findByOriginator.debug("No references found.");
		}
		return vCard;
	}

}
