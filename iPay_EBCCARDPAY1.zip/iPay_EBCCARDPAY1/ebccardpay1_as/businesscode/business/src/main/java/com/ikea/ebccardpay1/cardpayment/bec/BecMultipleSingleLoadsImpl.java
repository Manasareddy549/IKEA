package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefMultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.MultipleSingleLoadException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.vo.VoMultipleSingleLoadSearch;
import com.ikea.ebccardpay1.common.Amounts;
import com.ikea.ebccardpay1.common.Constants;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.mdsd.ValueObjects;


public class BecMultipleSingleLoadsImpl implements BecMultipleSingleLoads {
	private static final Logger mLog = LoggerFactory
			.getLogger(BecMultipleSingleLoadsImpl.class);

	@Autowired
	private BefMultipleSingleLoad mBefMultipleSingleLoad;

    @Autowired
    private UtilsFactory utilsFactory;
    
    
	@Autowired
	private BefCardNumber mBefCardNumber;


	@Autowired
	private TimeSource mTimeSource;

	@Autowired
	private BsContext bsContext;

	@Autowired
	private UtilsFactory mUtilsFactory;

	@Autowired
	private BecCard mBecCard;

	@Autowired
	private BecTransaction mBecTransaction;


	public List<MultipleSingleLoad> findUnauthorized() throws IkeaException {
		UserEnvironment vUserEnvironment = utilsFactory
				.createUserEnvironment();
		return mBefMultipleSingleLoad.findByUnauthorized(vUserEnvironment
				.getCountryCode());
	}

	public List<MultipleSingleLoad> findMultipleSingleLoads(
			VoMultipleSingleLoadSearch pVoMultipleSingleLoadSearch) {

		return mBefMultipleSingleLoad.findBySearch(pVoMultipleSingleLoadSearch
				.getNameLike(), pVoMultipleSingleLoadSearch.getBuType(),
				pVoMultipleSingleLoadSearch.getBuCode(),
				pVoMultipleSingleLoadSearch.getCountryCode(),
				pVoMultipleSingleLoadSearch.getCreatedDateTime());

	}

	public List<VoMultipleSingleLoad> convertToVoList(
			List<MultipleSingleLoad> pMultipleSingleLoads) {
		List<VoMultipleSingleLoad> vVoMultipleSingleLoadList = new ArrayList<VoMultipleSingleLoad>();
		if (pMultipleSingleLoads != null && pMultipleSingleLoads.size() > 0) {
			for (MultipleSingleLoad vMultipleSingleLoad : pMultipleSingleLoads) {
				VoMultipleSingleLoad vVoMultipleSingleLoad = new VoMultipleSingleLoad();
				ValueObjects.assignToValueObject(vVoMultipleSingleLoad,
						vMultipleSingleLoad);
				vVoMultipleSingleLoadList
						.add(vVoMultipleSingleLoad);
			}
		}
		return vVoMultipleSingleLoadList;
	}
	
	@Override
	public VoMultipleSingleLoad withdraw(VoMultipleSingleLoad pVoMultipleSingleLoad) throws ValueMissingException, MultipleSingleLoadException  {
		VoMultipleSingleLoad vVoMultipleSingleLoad = new VoMultipleSingleLoad();
		if(pVoMultipleSingleLoad.getMultipleSingleLoadId() <0)
		{
			throw new ValueMissingException("Invalid Massload");
		}

		else
		{
			MultipleSingleLoad vMultipleSingleLoad=mBefMultipleSingleLoad.findByPrimaryKey(pVoMultipleSingleLoad.getMultipleSingleLoadId());
			if(vMultipleSingleLoad== null)
			{
				throw new MultipleSingleLoadException("Multiple Single Load "+pVoMultipleSingleLoad.getName()+" not found. Kindly refresh the page.");
			}
			else{
				IkeaUserProfile vIkeaUserProfile = bsContext
						.getUserProfile();
				if (vIkeaUserProfile == null) {
					throw new ValueMissingException("User Profile could not be found");
				}
				else{
					String vUserId = vIkeaUserProfile.getUID().toLowerCase();
					vMultipleSingleLoad.setWithdrawBy(vUserId);
					vMultipleSingleLoad.setWithdrawDateTime(mTimeSource.currentDate());
//					vMultipleSingleLoad.setSingleLoadState(Constants.MULTIPLE_STATE_CONSTANT_AUTHORIZED);
					for (Amount vAmount : vMultipleSingleLoad.getAmounts()) {

						if(!Amounts.isZero(vAmount.getCurrentAmount()))
						{
							// Init bec
							if(vAmount.getCurrentAmount().doubleValue()>0){
								BusinessUnitEnvironment vBusinessUnitEnvironment = mUtilsFactory
										.createBusinessUnitEnvironment(vMultipleSingleLoad.getBuType(),
												vMultipleSingleLoad.getBuCode());

								mBecCard.init(vAmount.getCard().getCardNumber(),vBusinessUnitEnvironment);
								try {
									mBecCard.withdrawnSingleLoad(vMultipleSingleLoad);
								} catch (AmountException | TransactionException e) {
									// TODO Auto-generated catch block
									mLog.info("Could not withdraw card  "
											+ vAmount.getCard() + " with amount: " + vAmount.getCurrentAmount());
								}
							}
						}
					}
					mBefMultipleSingleLoad.update(vMultipleSingleLoad);
					
					ValueObjects.assignToValueObject(vVoMultipleSingleLoad,
							vMultipleSingleLoad);
					
				}
			}
		}

		return vVoMultipleSingleLoad;

	}

	protected Amount findAmount(MultipleSingleLoad pMultipleSingleLoad, Card pCard) {

		if (pMultipleSingleLoad != null) {
			for (Iterator<Amount> i = pCard.getAmounts().iterator(); i
					.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (vAmount != null && pMultipleSingleLoad.equals(vAmount.getMultipleSingleLoad())) {

					return vAmount;
				}
			}
		}

		return null;
	}


}
