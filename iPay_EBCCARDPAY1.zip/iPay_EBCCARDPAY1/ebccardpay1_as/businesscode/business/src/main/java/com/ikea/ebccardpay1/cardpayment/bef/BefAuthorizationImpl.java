/*
 * Created on 2007-feb-05
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 * 
 */
public class BefAuthorizationImpl extends BefAbstract<Authorization> implements
		BefAuthorization {

	private final static Logger mCategory_findByAuthorizationNumber = LoggerFactory
			.getLogger(BefAuthorizationImpl.class.getName()
					+ ".findByAuthorizationNumber");

	private final static Logger mCategory_findByTransactionNo = LoggerFactory
			.getLogger(BefAuthorizationImpl.class.getName()
					+ ".findByTransactionNo");

	private final static Logger mCategory_findByCard = LoggerFactory
			.getLogger(BefAuthorizationImpl.class.getName() + ".findByCard");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefAuthorizationImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bef.BefAuthorization#
	 * findByAuthorizationNumber(java.lang.String)
	 */
	public Authorization findByAuthorizationNumber(String pAuthorizationNumber) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from Authorization where authorizationNumber=:authorizationNumber";

		if (mCategory_findByAuthorizationNumber.isDebugEnabled()) {
			mCategory_findByAuthorizationNumber.debug("HQL: " + vHql);
		}

		return (Authorization) vSession.createQuery(vHql).setParameter(
				"authorizationNumber", pAuthorizationNumber).uniqueResult();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization#findByTransactionNo
	 * (long)
	 */
	public Authorization findByTransactionNo(long pTransactionNo) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from Authorization where transactionNo=:transactionNo";

		if (mCategory_findByTransactionNo.isDebugEnabled()) {
			mCategory_findByTransactionNo.debug("HQL: " + vHql);
		}

		return (Authorization) vSession.createQuery(vHql).setLong(
				"transactionNo", pTransactionNo).uniqueResult();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization#findByCard(com.
	 * ikea.ebccardpay1.cardpayment.be.Card)
	 */
	public List<Authorization> findByCard(Card pCard) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from Authorization where transactionNo in (select transactionNo from Transaction where card=:card)";

		if (mCategory_findByCard.isDebugEnabled()) {
			mCategory_findByCard.debug("HQL: " + vHql);
		}

		return new GenericQuery<Authorization>(vSession.createQuery(vHql)
				.setEntity("card", pCard)).list();
	}

	@Override
	protected Class<Authorization> getBusinessEntityClass() {
		return Authorization.class;
	}

}
