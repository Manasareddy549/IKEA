/*
 * Created on 2007-jan-25
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.ikea.ebccardpay1.cardpayment.vo.VoCurrency;
import com.ikea.ebccardpay1.cardpayment.vo.VoCurrency;

/**
 * @author anms
 * @author tpon
 * 
 */
public class CurrenciesImpl implements Currencies {

	private Map<String, Iso4217> mCurrencyMap = new TreeMap<String, Iso4217>();
	private Map<String, VoCurrency> mVoCurrencyMap = new TreeMap<String, VoCurrency>();
	private Map<String, List<VoCurrency>> mVoCurrencyMapPerCountryCode = new TreeMap<String, List<VoCurrency>>();


	/**
	 * 
	 */
	public CurrenciesImpl() {
		super();
		init();
	}
	
	protected void init(){
		
		addToMaps(new Iso4217("AF" ,"AFGHANISTAN", "Afghani", "AFN"));
		addToMaps(new Iso4217("AL", "ALBANIA", "Lek", "ALL"));
		addToMaps(new Iso4217("DZ", "ALGERIA", "Algerian Dinar",
				"DZD"));
		addToMaps(new Iso4217("AS", "AMERICAN SAMOA", "US Dollar",
				"USD"));
		addToMaps(new Iso4217("AD", "ANDORRA", "Euro", "EUR"));
		addToMaps(new Iso4217("AO", "ANGOLA", "Kwanza", "AOA"));
		addToMaps(new Iso4217("AI", "ANGUILLA",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("AG", "ANTIGUA AND BARBUDA",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("AR", "ARGENTINA", "Argentine Peso",
				"ARS"));
		addToMaps(new Iso4217("AM", "ARMENIA", "Armenian Dram",
				"AMD"));
		addToMaps(new Iso4217("AW", "ARUBA", "Aruban Guilder",
				"AWG"));
		addToMaps(new Iso4217("AU", "AUSTRALIA",
				"Australian Dollar", "AUD"));
		addToMaps(new Iso4217("AT", "AUSTRIA", "Euro", "EUR"));
		addToMaps(new Iso4217("AZ", "AZERBAIJAN",
				"Azerbaijanian Manat", "AZN"));
		addToMaps(new Iso4217("BS", "BAHAMAS", "Bahamian Dollar",
				"BSD"));
		addToMaps(new Iso4217("BH", "BAHRAIN", "Bahraini Dinar",
				"BHD"));
		addToMaps(new Iso4217("BD", "BANGLADESH", "Taka", "BDT"));
		addToMaps(new Iso4217("BB", "BARBADOS", "Barbados Dollar",
				"BBD"));
		addToMaps(new Iso4217("BY", "BELARUS", "Belarussian Ruble",
				"BYR"));
		addToMaps(new Iso4217("BE", "BELGIUM", "Euro", "EUR"));
		addToMaps(new Iso4217("BZ", "BELIZE", "Belize Dollar",
				"BZD"));
		addToMaps(new Iso4217("BJ", "BENIN", "CFA Franc BCEAO",
				"XOF"));
		addToMaps(new Iso4217("BM", "BERMUDA", "Bermudian Dollar",
				"BMD"));
		addToMaps(new Iso4217("BT", "BHUTAN", "Indian Rupee", "INR"));
		addToMaps(new Iso4217("BT", "BHUTAN", "Ngultrum", "BTN"));
		addToMaps(new Iso4217("BO", "BOLIVIA", "Boliviano", "BOB"));
		addToMaps(new Iso4217("BO", "BOLIVIA", "Mvdol", "BOV"));
		addToMaps(new Iso4217("BA", "BOSNIA & HERZEGOVINA",
				"Convertible Marks", "BAM"));
		addToMaps(new Iso4217("BW", "BOTSWANA", "Pula", "BWP"));
		addToMaps(new Iso4217("BV", "BOUVET ISLAND",
				"Norwegian Krone", "NOK"));
		addToMaps(new Iso4217("BR", "BRAZIL", "Brazilian Real",
				"BRL"));
		addToMaps(new Iso4217("", 
				"BRITISH INDIAN OCEAN TERRITORY", "US Dollar", "USD"));
		addToMaps(new Iso4217("BN", "BRUNEI DARUSSALAM",
				"Brunei Dollar", "BND"));
		addToMaps(new Iso4217("BG", "BULGARIA", "Bulgarian Lev",
				"BGN"));
		addToMaps(new Iso4217("BF", "BURKINA FASO",
				"CFA Franc BCEAO", "XOF"));
		addToMaps(new Iso4217("BI", "BURUNDI", "Burundi Franc",
				"BIF"));
		addToMaps(new Iso4217("KH", "CAMBODIA", "Riel", "KHR"));
		addToMaps(new Iso4217("CM", "CAMEROON", "CFA Franc BEAC",
				"XAF"));
		addToMaps(new Iso4217("CA", "CANADA", "Canadian Dollar",
				"CAD"));
		addToMaps(new Iso4217("CV", "CAPE VERDE",
				"Cape Verde Escudo", "CVE"));
		addToMaps(new Iso4217("CY", "CAYMAN ISLANDS",
				"Cayman Islands Dollar", "KYD"));
		addToMaps(new Iso4217("CF", "CENTRAL AFRICAN REPUBLIC",
				"CFA Franc BEAC", "XAF"));
		addToMaps(new Iso4217("TD", "CHAD", "CFA Franc BEAC", "XAF"));
		addToMaps(new Iso4217("CL", "CHILE", "Chilean Peso", "CLP"));
		addToMaps(new Iso4217("CL", "CHILE",
				"Unidades de formento", "CLF"));
		addToMaps(new Iso4217("CN", "CHINA", "Yuan Renminbi", "CNY"));
		addToMaps(new Iso4217("CX", "CHRISTMAS ISLAND",
				"Australian Dollar", "AUD"));
		addToMaps(new Iso4217("CC", "COCOS (KEELING) ISLANDS",
				"Australian Dollar", "AUD"));
		addToMaps(new Iso4217("CO", "COLOMBIA", "Colombian Peso",
				"COP"));
		addToMaps(new Iso4217("CO", "COLOMBIA",
				"Unidad de Valor Real", "COU"));
		addToMaps(new Iso4217("KM", "COMOROS", "Comoro Franc",
				"KMF"));
		addToMaps(new Iso4217("CG", "CONGO", "CFA Franc BEAC",
				"XAF"));
		addToMaps(new Iso4217("CD", 
				"CONGO, THE DEMOCRATIC REPUBLIC OF", "Franc Congolais", "CDF"));
		addToMaps(new Iso4217("CK", "COOK ISLANDS",
				"New Zealand Dollar", "NZD"));
		addToMaps(new Iso4217("CR", "COSTA RICA",
				"Costa Rican Colon", "CRC"));
		addToMaps(new Iso4217("CI", "C�TE D'IVOIRE",
				"CFA Franc BCEAO", "XOF"));
		addToMaps(new Iso4217("HR", "CROATIA", "Croatian Kuna",
				"HRK"));
		addToMaps(new Iso4217("CU", "CUBA", "Cuban Peso", "CUP"));
		addToMaps(new Iso4217("CY", "CYPRUS", "Cyprus Pound", "CYP"));
		addToMaps(new Iso4217("CZ", "CZECH REPUBLIC",
				"Czech Koruna", "CZK"));
		addToMaps(new Iso4217("DK", "DENMARK", "Danish Krone",
				"DKK"));
		addToMaps(new Iso4217("DJ", "DJIBOUTI", "Djibouti Franc",
				"DJF"));
		addToMaps(new Iso4217("DM", "DOMINICA",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("DO", "DOMINICAN REPUBLIC",
				"Dominican Peso", "DOP"));
		addToMaps(new Iso4217("EC", "ECUADOR", "US Dollar", "USD"));
		addToMaps(new Iso4217("EG", "EGYPT", "Egyptian Pound",
				"EGP"));
		addToMaps(new Iso4217("SV", "EL SALVADOR",
				"El Salvador Colon", "SVC"));
		addToMaps(new Iso4217("SV", "EL SALVADOR", "US Dollar",
				"USD"));
		addToMaps(new Iso4217("GQ", "EQUATORIAL GUINEA",
				"CFA Franc BEAC", "XAF"));
		addToMaps(new Iso4217("ER", "ERITREA", "Nakfa", "ERN"));
		addToMaps(new Iso4217("EE", "ESTONIA", "Kroon", "EEK"));
		addToMaps(new Iso4217("ET", "ETHIOPIA", "Ethiopian Birr",
				"ETB"));
		addToMaps(new Iso4217("FK", "FALKLAND ISLANDS (MALVINAS)",
				"Falkland Islands Pound", "FKP"));
		addToMaps(new Iso4217("FO", "FAROE ISLANDS",
				"Danish Krone", "DKK"));
		addToMaps(new Iso4217("FJ", "FIJI", "Fiji Dollar", "FJD"));
		addToMaps(new Iso4217("FI", "FINLAND", "Euro", "EUR"));
		addToMaps(new Iso4217("FR", "FRANCE", "Euro", "EUR"));
		addToMaps(new Iso4217("GF", "FRENCH GUIANA", "Euro", "EUR"));
		addToMaps(new Iso4217("PF", "FRENCH POLYNESIA",
				"CFP Franc", "XPF"));
		addToMaps(new Iso4217("TF", "FRENCH SOUTHERN TERRITORIES",
				"Euro", "EUR"));
		addToMaps(new Iso4217("GA", "GABON", "CFA Franc BEAC",
				"XAF"));
		addToMaps(new Iso4217("GM", "GAMBIA", "Dalasi", "GMD"));
		addToMaps(new Iso4217("GE", "GEORGIA", "Lari", "GEL"));
		addToMaps(new Iso4217("DE", "GERMANY", "Euro", "EUR"));
		addToMaps(new Iso4217("GH", "GHANA", "Cedi", "GHC"));
		addToMaps(new Iso4217("GI", "GIBRALTAR", "Gibraltar Pound",
				"GIP"));
		addToMaps(new Iso4217("GR", "GREECE", "Euro", "EUR"));
		addToMaps(new Iso4217("GL", "GREENLAND", "Danish Krone",
				"DKK"));
		addToMaps(new Iso4217("GD", "GRENADA",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("GP", "GUADELOUPE", "Euro", "EUR"));
		addToMaps(new Iso4217("GU", "GUAM", "US Dollar", "USD"));
		addToMaps(new Iso4217("GT", "GUATEMALA", "Quetzal", "GTQ"));
		addToMaps(new Iso4217("GN", "GUINEA", "Guinea Franc", "GNF"));
		addToMaps(new Iso4217("GW", "GUINEA-BISSAU",
				"Guinea-Bissau Peso", "GWP"));
		addToMaps(new Iso4217("GW", "GUINEA-BISSAU",
				"CFA Franc BCEAO", "XOF"));
		addToMaps(new Iso4217("GY", "GUYANA", "Guyana Dollar",
				"GYD"));
		addToMaps(new Iso4217("HT", "HAITI", "Gourde", "HTG"));
		addToMaps(new Iso4217("HT", "HAITI", "US Dollar", "USD"));
		addToMaps(new Iso4217("HM", 
				"HEARD ISLAND AND McDONALD ISLANDS", "Australian Dollar", "AUD"));
		addToMaps(new Iso4217("VA", 
				"HOLY SEE (VATICAN CITY STATE)", "Euro", "EUR"));
		addToMaps(new Iso4217("HN", "HONDURAS", "Lempira", "HNL"));
		addToMaps(new Iso4217("HK", "HONG KONG",
				"Hong Kong Dollar", "HKD"));
		addToMaps(new Iso4217("HU", "HUNGARY", "Forint", "HUF", 0));
		addToMaps(new Iso4217("IS", "ICELAND", "Iceland Krona",
				"ISK"));
		//Country code IM is modified to IN for country India - Modified by anagc, 25-sep-2017*/
		addToMaps(new Iso4217("IN", "INDIA", "Indian Rupee", "INR"));
		addToMaps(new Iso4217("ID", "INDONESIA", "Rupiah", "IDR"));
		addToMaps(new Iso4217("", 
				"INTERNATIONAL MONETARY FUND (I.M.F)", "SDR", "XDR"));
		addToMaps(new Iso4217("IR", "IRAN (ISLAMIC REPUBLIC OF)",
				"Iranian Rial", "IRR"));
		addToMaps(new Iso4217("IQ", "IRAQ", "Iraqi Dinar", "IQD"));
		addToMaps(new Iso4217("IE", "IRELAND", "Euro", "EUR"));
		addToMaps(new Iso4217("IL", "ISRAEL", "New Israeli Sheqel",
				"ILS"));
		addToMaps(new Iso4217("IT", "ITALY", "Euro", "EUR"));
		addToMaps(new Iso4217("JM", "JAMAICA", "Jamaican Dollar",
				"JMD"));
		addToMaps(new Iso4217("JP", "JAPAN", "Yen", "JPY", 0));
		addToMaps(new Iso4217("JO", "JORDAN", "Jordanian Dinar",
				"JOD"));
		addToMaps(new Iso4217("KZ", "KAZAKHSTAN", "Tenge", "KZT"));
		addToMaps(new Iso4217("KE", "KENYA", "Kenyan Shilling",
				"KES"));
		addToMaps(new Iso4217("KI", "KIRIBATI",
				"Australian Dollar", "AUD"));
		addToMaps(new Iso4217("KP", 
				"KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF", "North Korean Won", "KPW"));
		addToMaps(new Iso4217("KR", "KOREA,REPUBLICOF", "Won",
				"KRW"));
		addToMaps(new Iso4217("KW", "KUWAIT", "Kuwaiti Dinar",
				"KWD"));
		addToMaps(new Iso4217("KG", "KYRGYZSTAN", "Som", "KGS"));
		addToMaps(new Iso4217("LA", 
				"LAO PEOPLE'S DEMOCRATIC REPUBLIC", "Kip", "LAK"));
		addToMaps(new Iso4217("LV", "LATVIA", "Latvian Lats", "LVL"));
		addToMaps(new Iso4217("LB", "LEBANON", "Lebanese Pound",
				"LBP"));
		addToMaps(new Iso4217("LS", "LESOTHO", "Rand", "ZAR"));
		addToMaps(new Iso4217("LS", "LESOTHO", "Loti", "LSL"));
		addToMaps(new Iso4217("LR", "LIBERIA", "Liberian Dollar",
				"LRD"));
		addToMaps(new Iso4217("LY", "LIBYAN ARAB JAMAHIRIYA",
				"Libyan Dinar", "LYD"));
		addToMaps(new Iso4217("LI", "LIECHTENSTEIN", "Swiss Franc",
				"CHF"));
		addToMaps(new Iso4217("LT", "LITHUANIA",
				"Lithuanian Litas", "LTL"));
		addToMaps(new Iso4217("LU", "LUXEMBOURG", "Euro", "EUR"));
		addToMaps(new Iso4217("MO", "MACAO", "Pataca", "MOP"));
		addToMaps(new Iso4217("MK", 
				"MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF", "Denar", "MKD"));
		addToMaps(new Iso4217("MG", "MADAGASCAR",
				"Malagascy Ariary", "MGA"));
		addToMaps(new Iso4217("MW", "MALAWI", "Kwacha", "MWK"));
		addToMaps(new Iso4217("MY", "MALAYSIA",
				"Malaysian Ringgit", "MYR"));
		addToMaps(new Iso4217("MV", "MALDIVES", "Rufiyaa", "MVR"));
		addToMaps(new Iso4217("ML", "MALI", "CFA Franc BCEAO",
				"XOF"));
		addToMaps(new Iso4217("MT", "MALTA", "Maltese Lira", "MTL"));
		addToMaps(new Iso4217("MH", "MARSHALL ISLANDS",
				"US Dollar", "USD"));
		addToMaps(new Iso4217("MQ", "MARTINIQUE", "Euro", "EUR"));
		addToMaps(new Iso4217("MR", "MAURITANIA", "Ouguiya", "MRO"));
		addToMaps(new Iso4217("MU", "MAURITIUS", "Mauritius Rupee",
				"MUR"));
		addToMaps(new Iso4217("YT", "MAYOTTE", "Euro", "EUR"));
		addToMaps(new Iso4217("MX", "MEXICO", "Mexican Peso", "MXN"));
		addToMaps(new Iso4217("MX", "MEXICO",
				"Mexican Unidad de Inversion (UID)", "MXV"));
		addToMaps(new Iso4217("FM", 
				"MICRONESIA (FEDERATED STATES OF)", "US Dollar", "USD"));
		addToMaps(new Iso4217("MD", 
				"MOLDOVA, REPUBLIC OF Moldovan", "Leu", "MDL"));
		addToMaps(new Iso4217("MC", "MONACO", "Euro", "EUR"));
		addToMaps(new Iso4217("MN", "MONGOLIA", "Tugrik", "MNT"));
		addToMaps(new Iso4217("ME", "MONTENEGRO", "Euro", "EUR"));
		addToMaps(new Iso4217("MS", "MONTSERRAT",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("MA", "MOROCCO", "Moroccan Dirham",
				"MAD"));
		addToMaps(new Iso4217("MZ", "MOZAMBIQUE", "Metical", "MZN"));
		addToMaps(new Iso4217("MM", "MYANMAR", "Kyat", "MMK"));
		addToMaps(new Iso4217("NA", "NAMIBIA", "Rand", "ZAR"));
		addToMaps(new Iso4217("NA", "NAMIBIA", "Namibian Dollar",
				"NAD"));
		addToMaps(new Iso4217("NR", "NAURU", "Australian Dollar",
				"AUD"));
		addToMaps(new Iso4217("NP", "NEPAL", "Nepalese Rupee",
				"NPR"));
		addToMaps(new Iso4217("NL", "NETHERLANDS", "Euro", "EUR"));
		addToMaps(new Iso4217("AN", "NETHERLANDS ANTILLES",
				"Netherlands Antillian Guilder", "ANG"));
		addToMaps(new Iso4217("NC", "NEW CALEDONIA", "CFP Franc",
				"XPF"));
		addToMaps(new Iso4217("NZ", "NEW ZEALAND",
				"New Zealand Dollar", "NZD"));
		addToMaps(new Iso4217("NI", "NICARAGUA", "Cordoba Oro",
				"NIO"));
		addToMaps(new Iso4217("NE", "NIGER", "CFA Franc BCEAO",
				"XOF"));
		addToMaps(new Iso4217("NG", "NIGERIA", "Naira", "NGN"));
		addToMaps(new Iso4217("NU", "NIUE", "New Zealand Dollar",
				"NZD"));
		addToMaps(new Iso4217("NF", "NORFOLK ISLAND",
				"Australian Dollar", "AUD"));
		addToMaps(new Iso4217("MP", "NORTHERN MARIANA ISLANDS",
				"US Dollar", "USD"));
		addToMaps(new Iso4217("NO", "NORWAY", "Norwegian Krone",
				"NOK"));
		addToMaps(new Iso4217("OM", "OMAN", "Rial Omani", "OMR"));
		addToMaps(new Iso4217("PK", "PAKISTAN", "Pakistan Rupee",
				"PKR"));
		addToMaps(new Iso4217("PW", "PALAU", "US Dollar", "USD"));
		addToMaps(new Iso4217("PA", "PANAMA", "Balboa", "PAB"));
		addToMaps(new Iso4217("PA", "PANAMA", "US Dollar", "USD"));
		addToMaps(new Iso4217("PG", "PAPUA NEW GUINEA", "Kina",
				"PGK"));
		addToMaps(new Iso4217("PY", "PARAGUAY", "Guarani", "PYG"));
		addToMaps(new Iso4217("PE", "PERU", "Nuevo Sol", "PEN"));
		addToMaps(new Iso4217("PH", "PHILIPPINES",
				"Philippine Peso", "PHP"));
		addToMaps(new Iso4217("PN", "PITCAIRN",
				"New Zealand Dollar", "NZD"));
		addToMaps(new Iso4217("PL", "POLAND", "Zloty", "PLN"));
		addToMaps(new Iso4217("PT", "PORTUGAL", "Euro", "EUR"));
		addToMaps(new Iso4217("PR", "PUERTO RICO", "US Dollar",
				"USD"));
		addToMaps(new Iso4217("QA", "QATAR", "Qatari Rial", "QAR"));
		addToMaps(new Iso4217("RE", "R�UNION", "Euro", "EUR"));
		
		/*CR: IKEA01068146- ROL currency is Restricted on iPay.
		addToMaps(new Iso4217("RO", "ROMANIA", "Old Leu", "ROL"));
		- Modified by anagc, 25-sep-2017*/
		
		addToMaps(new Iso4217("RO", "ROMANIA", "New Leu", "RON"));
		addToMaps(new Iso4217("RU", "RUSSIAN FEDERATION",
				"Russian Ruble", "RUB"));
		addToMaps(new Iso4217("RW", "RWANDA", "Rwanda Franc", "RWF"));
		addToMaps(new Iso4217("SH", "SAINT HELENA",
				"Saint Helena Pound", "SHP"));
		addToMaps(new Iso4217("KN", "SAINT KITTS AND NEVIS",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("LC", "SAINT LUCIA",
				"East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("PM", "SAINT PIERRE AND MIQUELON",
				"Euro", "EUR"));
		addToMaps(new Iso4217("VC", 
				"SAINT VINCENT AND THE GRENADINES", "East Caribbean Dollar", "XCD"));
		addToMaps(new Iso4217("WS", "SAMOA", "Tala", "WST"));
		addToMaps(new Iso4217("SM", "SAN MARINO", "Euro", "EUR"));
		addToMaps(new Iso4217("ST", "S�O TOME AND PRINCIPE",
				"Dobra", "STD"));
		addToMaps(new Iso4217("SA", "SAUDI ARABIA", "Saudi Riyal",
				"SAR"));
		addToMaps(new Iso4217("SN", "SENEGAL", "CFA Franc BCEAO",
				"XOF"));
		addToMaps(new Iso4217("RS", "SERBIA", "Serbian Dinar",
				"RSD"));
		addToMaps(new Iso4217("SC", "SEYCHELLES",
				"Seychelles Rupee", "SCR"));
		addToMaps(new Iso4217("SL", "SIERRA LEONE", "Leone", "SLL"));
		addToMaps(new Iso4217("SG", "SINGAPORE",
				"Singapore Dollar", "SGD"));
		addToMaps(new Iso4217("SK", "SLOVAKIA", "Euro", "EUR"));
		addToMaps(new Iso4217("SI", "SLOVENIA", "Euro", "EUR"));
		addToMaps(new Iso4217("SB", "SOLOMON ISLANDS",
				"Solomon Islands Dollar", "SBD"));
		addToMaps(new Iso4217("SO", "SOMALIA", "Somali Shilling",
				"SOS"));
		addToMaps(new Iso4217("ZA", "SOUTH AFRICA", "Rand", "ZAR"));
		addToMaps(new Iso4217("ES", "SPAIN", "Euro", "EUR"));
		addToMaps(new Iso4217("LK", "SRI LANKA", "Sri Lanka Rupee",
				"LKR"));
		addToMaps(new Iso4217("SD", "SUDAN", "Sudanese Dinar",
				"SDD"));
		addToMaps(new Iso4217("SR", "SURINAME", "Surinam Dollar",
				"SRD"));
		addToMaps(new Iso4217("SJ", "SVALBARD AND JAN MAYEN",
				"Norwegian Krone", "NOK"));
		addToMaps(new Iso4217("SZ", "SWAZILAND", "Lilangeni", "SZL"));
		addToMaps(new Iso4217("SE", "SWEDEN", "Swedish Krona",
				"SEK"));
		addToMaps(new Iso4217("CH", "SWITZERLAND", "Swiss Franc",
				"CHF"));
		
		/*CR: IKEA01068146- CHW and CHE currency is Restricted on iPay.
		addToMaps(new Iso4217("CH", "SWITZERLAND", "WIR Franc",
				"CHW")); 
		addToMaps(new Iso4217("CH", "SWITZERLAND", "WIR Euro",
				"CHE"));
		- Modified by anagc, 25-sep-2017*/
		
		addToMaps(new Iso4217("SY", "SYRIAN ARAB REPUBLIC",
				"Syrian Pound", "SYP"));
		addToMaps(new Iso4217("TW", "TAIWAN, PROVINCE OF CHINA",
				"New Taiwan Dollar", "TWD"));
		addToMaps(new Iso4217("TJ", "TAJIKISTAN", "Somoni", "TJS"));
		addToMaps(new Iso4217("TZ", "TANZANIA, UNITED REPUBLIC OF",
				"Tanzanian Shilling", "TZS"));
		addToMaps(new Iso4217("TH", "THAILAND", "Baht", "THB"));
		addToMaps(new Iso4217("TL", "TIMOR-LESTE", "US Dollar",
				"USD"));
		addToMaps(new Iso4217("TG", "TOGO", "CFA Franc BCEAO",
				"XOF"));
		addToMaps(new Iso4217("TK", "TOKELAU",
				"New Zealand Dollar", "NZD"));
		addToMaps(new Iso4217("TO", "TONGA", "Pa'anga", "TOP"));
		addToMaps(new Iso4217("TT", "TRINIDAD AND TOBAGO",
				"Trinidad and Tobago Dollar", "TTD"));
		addToMaps(new Iso4217("TN", "TUNISIA", "Tunisian Dinar",
				"TND"));
		addToMaps(new Iso4217("TR", "TURKEY", "New Turkish Lira",
				"TRY"));
		addToMaps(new Iso4217("TM", "TURKMENISTAN", "Manat", "TMM"));
		addToMaps(new Iso4217("TC", "TURKS AND CAICOS ISLANDS",
				"US Dollar", "USD"));
		addToMaps(new Iso4217("TV", "TUVALU", "Australian Dollar",
				"AUD"));
		addToMaps(new Iso4217("UG", "UGANDA", "Uganda Shilling",
				"UGX"));
		addToMaps(new Iso4217("UA", "UKRAINE", "Hryvnia", "UAH"));
		addToMaps(new Iso4217("AE", "UNITED ARAB EMIRATES UAE",
				"Dirham", "AED"));
		addToMaps(new Iso4217("GB", "UNITED KINGDOM",
				"Pound Sterling", "GBP"));
		addToMaps(new Iso4217("US", "UNITED STATES", "US Dollar",
				"USD"));
		/*CR: IKEA01068146- USS and USN currency is Restricted on iPay.
		addToMaps(new Iso4217("US", "UNITED STATES", "(Same day)",
				"USS"));
		addToMaps(new Iso4217("US", "UNITED STATES", "(Next day)",
				"USN"));
		- Modified by anagc, 25-sep-2017*/
		addToMaps(new Iso4217("UM", 
				"UNITED STATES MINOR OUTLYING ISLANDS", "US Dollar", "USD"));
		addToMaps(new Iso4217("UY", "URUGUAY", "Peso Uruguayo",
				"UYU"));
		addToMaps(new Iso4217("UY", "URUGUAY",
				"Uruguay Peso en Unidades Indexadas", "UYI"));
		addToMaps(new Iso4217("UZ", "UZBEKISTAN", "Uzbekistan Sum",
				"UZS"));
		addToMaps(new Iso4217("VU", "VANUATU", "Vatu", "VUV"));
		addToMaps(new Iso4217("VE", "VENEZUELA", "Bolivar", "VEB"));
		addToMaps(new Iso4217("VN", "VIET NAM", "Dong", "VND"));
		addToMaps(new Iso4217("VG", "VIRGIN ISLANDS (BRITISH)",
				"US Dollar", "USD"));
		addToMaps(new Iso4217("VI", "VIRGIN ISLANDS (US)",
				"US Dollar", "USD"));
		addToMaps(new Iso4217("WF", "WALLIS AND FUTUNA",
				"CFP Franc", "XPF"));
		addToMaps(new Iso4217("EH", "WESTERN SAHARA",
				"Moroccan Dirham", "MAD"));
		addToMaps(new Iso4217("YE", "YEMEN", "Yemeni Rial", "YER"));
		addToMaps(new Iso4217("ZM", "ZAMBIA", "Kwacha", "ZMK"));
		addToMaps(new Iso4217("ZW", "ZIMBABWE", "Zimbabwe Dollar",
				"ZWD"));
		
		
	}
	
	protected void addToMaps(Iso4217 pIso4217){

		mCurrencyMap.put(pIso4217.mCountryName, pIso4217);

		VoCurrency vVoCurrency = new VoCurrency();
		vVoCurrency.setCurrencyCode(pIso4217.mCurrencyCode);
		vVoCurrency.setCurrencyName(pIso4217.mCurrencyName);
		vVoCurrency.setDecimals(pIso4217.mDecimals);

		mVoCurrencyMap.put(pIso4217.mCurrencyCode, vVoCurrency);
		List<VoCurrency> vVocurrencyList = (List<VoCurrency>) mVoCurrencyMapPerCountryCode.get(pIso4217.mCountryCode);
		if(vVocurrencyList == null){
			vVocurrencyList = new ArrayList<VoCurrency>();
		}
		vVocurrencyList.add(vVoCurrency);
		mVoCurrencyMapPerCountryCode.put(pIso4217.mCountryCode, vVocurrencyList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#allVoCurrency()
	 */
	public List<VoCurrency> allVoCurrency() {

		List<VoCurrency> vList = new ArrayList<VoCurrency>();

		if (mVoCurrencyMap != null) {
			for (VoCurrency vVoCurrency : mVoCurrencyMap.values()) {				
				vList.add(vVoCurrency);
			}
		}

		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#allCurrencyCodes()
	 */
	public List<String> allCurrencyCodes() {
		List<String> vList = new ArrayList<String>();

		// Loop over currencies
		for (Iso4217 vCurrency : mCurrencyMap.values()) {
			if (!vList.contains(vCurrency.mCurrencyCode)) {
				vList.add(vCurrency.mCurrencyCode);
			}
		}

		Collections.sort(vList);

		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Units#allCurrencyNames()
	 */
	public List<String> allCurrencyNames() {
		List<String> vList = new ArrayList<String>();

		// Loop over currencies
		for (Iso4217 vCurrency : mCurrencyMap.values()) {			
			String vName = vCurrency.mCurrencyCode + ", "
					+ vCurrency.mCurrencyName;
			if (!vList.contains(vName)) {
				vList.add(vName);
			}
		}

		Collections.sort(vList);

		return vList;
	}

	public List<VoCurrency> getCurrencyForCountry(String countryCode) {
		return (List<VoCurrency>) mVoCurrencyMapPerCountryCode.get(countryCode);
	}
}
