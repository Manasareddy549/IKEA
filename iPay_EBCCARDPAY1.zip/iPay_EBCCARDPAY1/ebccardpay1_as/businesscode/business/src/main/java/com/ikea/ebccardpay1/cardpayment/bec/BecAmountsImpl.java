package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.YearMonthDay;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.MultipleSingleLoad;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.CountryNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidForeignCardException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.DefaultPriorityEvaluator;
import com.ikea.ebccardpay1.cardpayment.utils.PriorityEvaluator;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoManualTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.EbcProperties;

public class BecAmountsImpl implements BecAmounts {

	private final static Logger mLog = LoggerFactory.getLogger(BecAmountsImpl.class);
	/**
	 * Dependencies
	 */
	private EbcProperties mEbcProperties;
	private BecFactory mBecFactory;
	private PriorityEvaluator mPriorityEvaluator;
	private Units mUnits;
	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	/** 
	 * Internal state
	 */
	private Card mCard = null;
	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;
	private BigDecimal mRate = null;
	private UtilsFactory mUtilsFactory=null;

	/**
	 * Dependecy injection
	 * @param pEbcProperties 
	 */
	protected BecAmountsImpl(BecFactory pBecFactory, Units pUnits, PriorityEvaluator pPriorityEvaluator, EbcProperties pEbcProperties,BefIpayBusinessUnits pBefIpayBusinessUnits,UtilsFactory pUtilsFactory) {

		mBecFactory = pBecFactory;
		mUnits = pUnits;
		mPriorityEvaluator = pPriorityEvaluator;
		mEbcProperties = pEbcProperties;
		mBefIpayBusinessUnits=pBefIpayBusinessUnits;
		mUtilsFactory=pUtilsFactory;
	}


	void validate() {
		notNull(mBecFactory);
		notNull(mUnits);
		notNull(mPriorityEvaluator);
		notNull(mEbcProperties);


	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Card,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecAmounts init(Card pCard,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#loadAmountOnCard(com.
	 * ikea.ebccardpay1.cardpayment.vo.VoLoadAmount,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoReference)
	 */
	public void loadAmount(VoLoadAmount pVoLoadAmount,String pSourceSystem, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException, IkeaException, InvalidCardException, InvalidForeignCardException {

		requireBusinessUnitEnvironment();
		requireTransactionEnvironment();
		String Vcountry= mBusinessUnitEnvironment.getCountryCode();
		//exception for  countries HU, US, CA, PL to reload
		if(filterCountryToAllowReload())
		{
			String cardType = mCard.getCardType();		
			if (cardType!=null)
			{
				requireNewCard();	
				requireAckload();
				checkReloadCriteria();
				BecAmount vBecAmount = null;

				if (pVoLoadAmount.getLoadAmount() != null
						&& Amounts.isZero(pVoLoadAmount.getLoadAmount())) {
					// It is valid to load with zero amount. Create a zero transaction.
					mLog
					.info("Creating a zero transaction since the load amount was zero.");
					mBecFactory.createBecTransaction().init(mCard, null,
							mBusinessUnitEnvironment, mTransactionEnvironment)
					.createLoadTransaction(Amounts.zero(),
							pVoLoadAmount.getCurrencyCode(), Amounts.zero(),pSourceSystem, pVoLoadAmount, pCardNumberString);
					return;
				}

				if (Constants.AMOUNT_TYPE_CONSTANT_CASH.equals(pVoLoadAmount
						.getAmountType())) {

					// Create a new CASH (it is no use in using the same, we have too
					// much that differs: mass load, bonus code, BU)
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment)
							.createCash(
									mPriorityEvaluator.evaluatePriority(mCard
											.getAmounts(),
											Constants.AMOUNT_PRIORITY_GIFT));

				} else if (Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT.equals(pVoLoadAmount
						.getAmountType())) {

					// Amount type DISCOUNT uses a new entries each time. We need to
					// calculate a new priority for it.
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment)
							.createDiscount(
									mPriorityEvaluator.evaluatePriority(mCard
											.getAmounts(),
											Constants.AMOUNT_PRIORITY_REFUND));

				} else {
					throw new ValueMissingException("Unhandled amount type:"
							+ CardPaymentLogger.loadAmountToString(pVoLoadAmount));
				}

				// Check if we shall load in foreign currency
				if (!mCard.getCurrencyCode().equals(pVoLoadAmount.getCurrencyCode())) {
					mLog.info("Will do Load in foreign currency. Card currency '"
							+ mCard.getCurrencyCode() + "' reqested '"
							+ pVoLoadAmount.getCurrencyCode() + "'.");

					// Check that cross currency transactions are allowed for the
					// current country
					if (crossCurrencyIsAllowed() && crossCurrencyLoadIsAllowed()) {

						// Find valid exchange rate.
						findRate(pVoLoadAmount.getCurrencyCode(), mCard
								.getCurrencyCode());
						mLog.info(" Current rate is: " + mRate + " for currency From: "
								+ pVoLoadAmount.getCurrencyCode() + " To: "
								+ mCard.getCurrencyCode());

						vBecAmount = vBecAmount.init(mRate);
					} else {
						mLog
						.info("Cross currency transaction is not allowed from country "
								+ mBusinessUnitEnvironment.getCountryCode());
						/*PR-IKEA01082411 use one Error Code for all Foreign cards exception
						throw new CurrencyException(
								"Cross currency transaction not allowed from country "
										+ mBusinessUnitEnvironment.getCountryCode());
						 */
						throw new InvalidForeignCardException(
								"Cross currency transaction not allowed from country "+mBusinessUnitEnvironment.getCountryCode());

					}
				}
				// Load the amount
				vBecAmount.load(pVoLoadAmount,pSourceSystem, pCardNumberString);
			}else{
				throw new AmountException("CAMPAIGN Card can be loaded only threw Massload");	
			}
		}
		//		else{
		//			//Changes done in 3.10, CR- IKEA01097947
		//			throw new AmountException("You can't reload the cards in country "+mBusinessUnitEnvironment.getCountryCode());
		//
		//		}

		else{
			String cardType = mCard.getCardType();
			requireNewCard();
			if (cardType!=null)
			{
				if(!cardType.equalsIgnoreCase("CAMPAIGN")){
					requireReload();	
				}	
				requireAckload();
				//checkReloadCriteria();
				BecAmount vBecAmount = null;

				if (pVoLoadAmount.getLoadAmount() != null
						&& Amounts.isZero(pVoLoadAmount.getLoadAmount())) {
					// It is valid to load with zero amount. Create a zero transaction.
					mLog
					.info("Creating a zero transaction since the load amount was zero.");
					mBecFactory.createBecTransaction().init(mCard, null,
							mBusinessUnitEnvironment, mTransactionEnvironment)
					.createLoadTransaction(Amounts.zero(),
							pVoLoadAmount.getCurrencyCode(), Amounts.zero(),pSourceSystem,pVoLoadAmount, pCardNumberString);
					return;
				}

				if (Constants.AMOUNT_TYPE_CONSTANT_CASH.equals(pVoLoadAmount
						.getAmountType())) {

					// Create a new CASH (it is no use in using the same, we have too
					// much that differs: mass load, bonus code, BU)
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment)
							.createCash(
									mPriorityEvaluator.evaluatePriority(mCard
											.getAmounts(),
											Constants.AMOUNT_PRIORITY_GIFT));

				} else if (Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT.equals(pVoLoadAmount
						.getAmountType())) {

					// Amount type DISCOUNT uses a new entries each time. We need to
					// calculate a new priority for it.
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment)
							.createDiscount(
									mPriorityEvaluator.evaluatePriority(mCard
											.getAmounts(),
											Constants.AMOUNT_PRIORITY_REFUND));

				} else {
					throw new ValueMissingException("Unhandled amount type:"
							+ CardPaymentLogger.loadAmountToString(pVoLoadAmount));
				}

				// Check if we shall load in foreign currency
				if (!mCard.getCurrencyCode().equals(pVoLoadAmount.getCurrencyCode())) {
					mLog.info("Will do Load in foreign currency. Card currency '"
							+ mCard.getCurrencyCode() + "' reqested '"
							+ pVoLoadAmount.getCurrencyCode() + "'.");

					// Check that cross currency transactions are allowed for the
					// current country
					if (crossCurrencyIsAllowed() && crossCurrencyLoadIsAllowed()) {

						// Find valid exchange rate.
						findRate(pVoLoadAmount.getCurrencyCode(), mCard
								.getCurrencyCode());
						mLog.info(" Current rate is: " + mRate + " for currency From: "
								+ pVoLoadAmount.getCurrencyCode() + " To: "
								+ mCard.getCurrencyCode());

						vBecAmount = vBecAmount.init(mRate);
					} else {
						mLog
						.info("Cross currency transaction is not allowed from country "
								+ mBusinessUnitEnvironment.getCountryCode());
						throw new InvalidForeignCardException(
								"Cross currency transaction not allowed from country "+mBusinessUnitEnvironment.getCountryCode());
					}
				}

				// Load the amount
				vBecAmount.load(pVoLoadAmount,pSourceSystem,pCardNumberString);
			}else{
				throw new AmountException("CAMPAIGN Card can be loaded only threw Massload");
			}
		}
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#redeemAmount(com.ikea
	 * .ebccardpay1.cardpayment.vo.VoRequestAmount,
	 * com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount)
	 */
	@Override
	public void redeemAmount(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException {

		if(!cardIsAllowedInForeignCounty()){
			throw new InvalidForeignCardException("This Card is not valid for this Country. Please try other Cards.");
		}

		requireCard();
		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		VoRequestAmount vVoRequestAmountCardCurrency = pVoRequestAmount;
		checkRedeemCriteria();
		// Check if we shall redeem in foreign currency
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mLog.info("Will do redeem in foreign currency. Card currency '"
					+ mCard.getCurrencyCode() + "' reqested '"
					+ pVoRequestAmount.getCurrencyCode() + "'.");

			// Check that cross currency transactions are allowed for the
			// current country
			if (crossCurrencyIsAllowed() && crossCurrencyRedeemIsAllowed()) {

				findRate(pVoRequestAmount.getCurrencyCode(), mCard
						.getCurrencyCode());
			} else {
				mLog
				.info("Cross currency transaction is not allowed from country "
						+ mBusinessUnitEnvironment.getCountryCode());
				/*PR-IKEA01082411 use one Error Code for all Foreign cards exception
				throw new CurrencyException(
						"Cross currency transaction not allowed from country "
								+ mBusinessUnitEnvironment.getCountryCode());
				 */
				throw new InvalidForeignCardException(
						"Cross currency transaction not allowed from country "+mBusinessUnitEnvironment.getCountryCode());

			}
		}
		redeemAmountInCardCurrency(vVoRequestAmountCardCurrency,
				pVoRedeemedAmountOut, pCardNumberString);
	}
	@Override
	public void redeemAmountReserved(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException {

		if(!cardIsAllowedInForeignCounty()){
			throw new InvalidForeignCardException("This Card is not valid for this Country. Please try other Cards.");
		}

		requireCard();
		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		VoRequestAmount vVoRequestAmountCardCurrency = pVoRequestAmount;
		checkRedeemCriteria();
		// Check if we shall redeem in foreign currency
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mLog.info("Will do redeem in foreign currency. Card currency '"
					+ mCard.getCurrencyCode() + "' reqested '"
					+ pVoRequestAmount.getCurrencyCode() + "'.");

			// Check that cross currency transactions are allowed for the
			// current country
			if (crossCurrencyIsAllowed() && crossCurrencyRedeemIsAllowed()) {

				findRate(pVoRequestAmount.getCurrencyCode(), mCard
						.getCurrencyCode());
			} else {
				mLog
				.info("Cross currency transaction is not allowed from country "
						+ mBusinessUnitEnvironment.getCountryCode());
				/*PR-IKEA01082411 use one Error Code for all Foreign cards exception
				throw new CurrencyException(
						"Cross currency transaction not allowed from country "
								+ mBusinessUnitEnvironment.getCountryCode());
				 */
				throw new InvalidForeignCardException(
						"Cross currency transaction not allowed from country "+mBusinessUnitEnvironment.getCountryCode());

			}
		}
		redeemAmountInCardCurrencyReserved(vVoRequestAmountCardCurrency,
				pVoRedeemedAmountOut, pCardNumberString);
	}
	
	public void redeemAmountManual(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, VoManualTransaction pVoManualTransaction, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException, InvalidCardException, IkeaException, InvalidForeignCardException {

		if(!cardIsAllowedInForeignCounty()){
			throw new InvalidForeignCardException("This Card is not valid for this Country. Please try other Cards.");
		}

		requireCard();
		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		VoRequestAmount vVoRequestAmountCardCurrency = pVoRequestAmount;
		checkRedeemCriteria();
		// Check if we shall redeem in foreign currency
		if (!mCard.getCurrencyCode().equals(pVoRequestAmount.getCurrencyCode())) {
			mLog.info("Will do redeem in foreign currency. Card currency '"
					+ mCard.getCurrencyCode() + "' reqested '"
					+ pVoRequestAmount.getCurrencyCode() + "'.");

			// Check that cross currency transactions are allowed for the
			// current country
			if (crossCurrencyIsAllowed() && crossCurrencyRedeemIsAllowed()) {

				findRate(pVoRequestAmount.getCurrencyCode(), mCard
						.getCurrencyCode());
			} else {
				mLog
				.info("Cross currency transaction is not allowed from country "
						+ mBusinessUnitEnvironment.getCountryCode());
				/*PR-IKEA01082411 use one Error Code for all Foreign cards exception
				throw new CurrencyException(
						"Cross currency transaction not allowed from country "
								+ mBusinessUnitEnvironment.getCountryCode());
				 */
				throw new InvalidForeignCardException(
						"Cross currency transaction not allowed from country "+mBusinessUnitEnvironment.getCountryCode());

			}
		}
		//redeemAmountInCardCurrency(vVoRequestAmountCardCurrency,
				//pVoRedeemedAmountOut);
		redeemAmountInCardCurrencyManual(vVoRequestAmountCardCurrency,
				pVoRedeemedAmountOut, pVoManualTransaction, pCardNumberString);
	}

	private boolean crossCurrencyIsAllowed() throws CountryNotFoundException {
		BecCountry vBecCountry = mBecFactory.createBecCountry();
		vBecCountry.findCountry(mBusinessUnitEnvironment.getCountryCode());
		return vBecCountry.getCountry().getCrossCurrencyAllowed();
	}

	private boolean crossCurrencyLoadIsAllowed() throws CountryNotFoundException {
		BecCountry vBecCountry = mBecFactory.createBecCountry();
		vBecCountry.findCountry(mBusinessUnitEnvironment.getCountryCode());
		return vBecCountry.getCountry().getCrossCurrencyLoadAllowed();
	}

	private boolean crossCurrencyRedeemIsAllowed() throws CountryNotFoundException {
		BecCountry vBecCountry = mBecFactory.createBecCountry();
		vBecCountry.findCountry(mBusinessUnitEnvironment.getCountryCode());
		return vBecCountry.getCountry().getCrossCurrencyRedeemAllowed();
	}

	private boolean cardIsAllowedInForeignCounty() throws CountryNotFoundException{


		BecCountry vBecCountry = mBecFactory.createBecCountry();
		String stroreCoutryCode = mBusinessUnitEnvironment.getCountryCode();

		String cardCountryCode = mCard.getCountryCode();

		vBecCountry.findCountry(cardCountryCode);

		if(!stroreCoutryCode.equalsIgnoreCase(cardCountryCode)){
			if(!vBecCountry.getCountry().getCardAllowedInForeignCounty()){
				return false;
			}
		}

		return true;

	}

	/**
	 * 
	 * @param pFromCurrencyCode
	 * @param pToCurrencyCode
	 */
	protected void findRate(String pFromCurrencyCode, String pToCurrencyCode)
			throws ValueMissingException, CurrencyException {

		requireBusinessUnitEnvironment();

		BecExchangeRates vBecExchangeRates = mBecFactory
				.createBecExchangeRates().init(mBusinessUnitEnvironment);

		mRate = vBecExchangeRates.getExchangeRate(pFromCurrencyCode,
				pToCurrencyCode);

		if (mLog.isInfoEnabled()) {
			mLog.info("Using Exchange Rate '" + mRate + "' for "
					+ pFromCurrencyCode + " to " + pToCurrencyCode + ".");
		}
	}



	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected BigDecimal inCardCurrency(BigDecimal pAmount) {
		if (mRate != null) {
			mLog.debug("Arithmetic multiply " + pAmount + " * " + mRate);
			BigDecimal vResult = Amounts.multiply(pAmount, mRate);
			mLog.debug("Arithmetic multiply result: " + vResult);
			return vResult;
		}
		return pAmount;
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected BigDecimal inRequestCurrency(BigDecimal pAmount) {
		if (mRate != null) {
			mLog.debug("Arithmetic dividing " + pAmount + " / " + mRate);
			BigDecimal vResult = Amounts.divide(pAmount, mRate);
			mLog.debug("Arithmetic dividing result: " + vResult);
			return vResult;
		}
		return pAmount;
	}

	/**
	 * 
	 * @param pVoRequestAmount
	 * @param pCardNumberString 
	 * @throws ValueMissingException
	 */
	protected void registerZeroRedeemTransaction(
			VoRequestAmount pVoRequestAmount,String pCardNumberString) throws ValueMissingException {
		mLog
		.info("Creating a zero transaction since no active amounts were found.");
		mBecFactory.createBecTransaction().init(mCard, null,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createRedeemTransaction(pVoRequestAmount, Amounts.zero(),
				Amounts.zero(), true, pCardNumberString);
	}
	
	protected void registerZeroRedeemTransactionReserved(
			VoRequestAmount pVoRequestAmount,String pCardNumberString) throws ValueMissingException {
		mLog
		.info("Creating a zero transaction since no active amounts were found.");
		mBecFactory.createBecReservedCardHistory().init(mCard, null,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createReservedTransaction(pVoRequestAmount, Amounts.zero(),
				Amounts.zero(), true, pCardNumberString, mRate);
	}
	
	/**
	 * 
	 * @param pVoRequestAmount
	 * @throws ValueMissingException
	 */
	protected void registerZeroRedeemTransactionManual(
			VoRequestAmount pVoRequestAmount, String pCardNumberString) throws ValueMissingException {
		mLog
		.info("Creating a zero transaction since no active amounts were found.");
		mBecFactory.createBecTransaction().init(mCard, null,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createRedeemTransactionManual(pVoRequestAmount, Amounts.zero(),
				Amounts.zero(), true, pCardNumberString);
	}

	/**
	 * 
	 * @param pVoRequestAmount
	 * @param pBalanceBalanceInRequestCurrency
	 * @param pBalanceChangeInCardCurrency
	 * @param pInsufficientAmount
	 * @param pCardNumberString 
	 * @throws ValueMissingException
	 */
	protected void registerRedeemTransaction(Amount pAmount,
			VoRequestAmount pVoRequestAmount,
			BigDecimal pBalanceBalanceInRequestCurrency,
			BigDecimal pBalanceChangeInCardCurrency, boolean pInsufficientAmount, String pCardNumberString)
					throws ValueMissingException {
		mBecFactory.createBecTransaction().init(mCard, pAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createRedeemTransaction(pVoRequestAmount,
				pBalanceBalanceInRequestCurrency,
				pBalanceChangeInCardCurrency, pInsufficientAmount, pCardNumberString);
	}
	
	protected void registerRedeemTransactionReserved(Amount pAmount,
			VoRequestAmount pVoRequestAmount,
			BigDecimal pBalanceBalanceInRequestCurrency,
			BigDecimal pBalanceChangeInCardCurrency, boolean pInsufficientAmount, String pCardNumberString)
					throws ValueMissingException {
		mBecFactory.createBecReservedCardHistory().init(mCard, pAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createReservedTransaction(pVoRequestAmount,
				pBalanceBalanceInRequestCurrency,
				pBalanceChangeInCardCurrency, pInsufficientAmount, pCardNumberString, mRate);
	}
	
	protected void registerRedeemTransactionManual(Amount pAmount,
			VoRequestAmount pVoRequestAmount,
			BigDecimal pBalanceBalanceInRequestCurrency,
			BigDecimal pBalanceChangeInCardCurrency, boolean pInsufficientAmount, VoManualTransaction vVoManualTransaction, String pCardNumberString)
					throws ValueMissingException {
		mBecFactory.createBecTransaction().init(mCard, pAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment)
		.createRedeemTransactionManual(pVoRequestAmount,
				pBalanceBalanceInRequestCurrency,
				pBalanceChangeInCardCurrency, pInsufficientAmount, vVoManualTransaction, pCardNumberString);
	}

	/**
	 * 
	 * @param pVoRequestAmount
	 * @param pVoRedeemedAmountOut
	 * @param pCardNumberString 
	 * @throws AmountException
	 * @throws CurrencyException
	 * @throws ValueMissingException
	 */
	protected void redeemAmountInCardCurrency(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException {

		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		// Create new temporay request amount
		VoRequestAmount vVoRequestAmount = (VoRequestAmount) pVoRequestAmount
				.clone();

		final BigDecimal vOriginalRequestedAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		// Remaining amount is how much we still have to redeem from the card
		BigDecimal vRemainingAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
			throw new CurrencyException(
					"Too small value of request amount. Amount in card currency restulted in zero!");
		}

		// Find active amounts
		List<Amount> vList = findActiveAmounts(mBusinessUnitEnvironment
				.getSalesDateTime(), inCardCurrency(vVoRequestAmount
						.getTotalAmount()), mBusinessUnitEnvironment.getBuType(),
				mBusinessUnitEnvironment.getBuCode());

		mLog.info("Found " + vList.size() + " active amounts.");
		if (vList.size() == 0 || Amounts.isZero(vRemainingAmountInCardCurrency)) {
			// No amounts found that matches. Create a zero transaction.
			registerZeroRedeemTransaction(vVoRequestAmount, pCardNumberString);
			// Set redeemed amount in requested currency
			if (pVoRedeemedAmountOut != null) {
				pVoRedeemedAmountOut.setRedeemAmount(Amounts.zero());
			}
			return;
		}
		BigDecimal vBalanceChangeInRequestCurrencySum = Amounts.zero();

		// Loop over amounts redeeming as we go
		for (int i = 0; i < vList.size(); i++) {
			Amount vAmount = (Amount) vList.get(i);

			// Create bec from amount
			BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
					vAmount, mBusinessUnitEnvironment, mTransactionEnvironment);

			// Try to redeem as much as possible
			BigDecimal vBalanceChangeInCardCurrency = vBecAmount.redeem(
					vVoRequestAmount, vRemainingAmountInCardCurrency);

			// Subtract the balance change from the remaining amount
			vRemainingAmountInCardCurrency = Amounts.subtract(
					vRemainingAmountInCardCurrency,
					vBalanceChangeInCardCurrency);

			boolean vIsZeroLeft = Amounts
					.isZero(vRemainingAmountInCardCurrency);
			boolean vIsLastAmount = (i + 1) == vList.size();

			BigDecimal vBalanceChangeInRequestCurrency = inRequestCurrency(vBalanceChangeInCardCurrency);

			// If it is the last transaction for this redeem then set the
			// remaining amount
			// so the sums will add up to the exact requested amount
			if (vIsZeroLeft) {
				vBalanceChangeInRequestCurrency = Amounts.subtract(
						pVoRequestAmount.getRequestAmount(),
						vBalanceChangeInRequestCurrencySum);
			}

			// Sum up all the balance changes so we get a sum that is exactly
			// the same as the requested even if we round of some digits.
			vBalanceChangeInRequestCurrencySum = Amounts.add(
					vBalanceChangeInRequestCurrencySum,
					vBalanceChangeInRequestCurrency);

			// Register redeem transaction out side the amount, only for redeem
			registerRedeemTransaction(vAmount, vVoRequestAmount,
					vBalanceChangeInRequestCurrency,
					vBalanceChangeInCardCurrency, vIsLastAmount && !vIsZeroLeft , pCardNumberString);

			if (vIsZeroLeft)
				break;

			// Prepare for redeem of next amount object
			vVoRequestAmount
			.setRequestAmount(inRequestCurrency(vRemainingAmountInCardCurrency));
		}

		// Set redeemed amount in requested currency
		if (pVoRedeemedAmountOut != null) {
			if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
				// We have redeemed all that was requested
				pVoRedeemedAmountOut.setRedeemAmount(pVoRequestAmount
						.getRequestAmount());
			} else {
				// Insufficient amount on card
				pVoRedeemedAmountOut.setRedeemAmount(inRequestCurrency(Amounts
						.subtract(vOriginalRequestedAmountInCardCurrency,
								vRemainingAmountInCardCurrency)));
			}
		}
	}
	protected void redeemAmountInCardCurrencyReserved(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException {

		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		// Create new temporay request amount
		VoRequestAmount vVoRequestAmount = (VoRequestAmount) pVoRequestAmount
				.clone();

		final BigDecimal vOriginalRequestedAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		// Remaining amount is how much we still have to redeem from the card
		BigDecimal vRemainingAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
			throw new CurrencyException(
					"Too small value of request amount. Amount in card currency restulted in zero!");
		}

		// Find active amounts
		List<Amount> vList = findActiveAmounts(mBusinessUnitEnvironment
				.getSalesDateTime(), inCardCurrency(vVoRequestAmount
						.getTotalAmount()), mBusinessUnitEnvironment.getBuType(),
				mBusinessUnitEnvironment.getBuCode());

		mLog.info("Found " + vList.size() + " active amounts.");
		if (vList.size() == 0 || Amounts.isZero(vRemainingAmountInCardCurrency)) {
			// No amounts found that matches. Create a zero transaction.
			registerZeroRedeemTransactionReserved(vVoRequestAmount, pCardNumberString);
			// Set redeemed amount in requested currency
			if (pVoRedeemedAmountOut != null) {
				pVoRedeemedAmountOut.setRedeemAmount(Amounts.zero());
			}
			return;
		}
		BigDecimal vBalanceChangeInRequestCurrencySum = Amounts.zero();

		// Loop over amounts redeeming as we go
		for (int i = 0; i < vList.size(); i++) {
			Amount vAmount = (Amount) vList.get(i);

			// Create bec from amount
			BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
					vAmount, mBusinessUnitEnvironment, mTransactionEnvironment);

			// Try to redeem as much as possible
			BigDecimal vBalanceChangeInCardCurrency = vBecAmount.redeem(
					vVoRequestAmount, vRemainingAmountInCardCurrency);

			// Subtract the balance change from the remaining amount
			vRemainingAmountInCardCurrency = Amounts.subtract(
					vRemainingAmountInCardCurrency,
					vBalanceChangeInCardCurrency);

			boolean vIsZeroLeft = Amounts
					.isZero(vRemainingAmountInCardCurrency);
			boolean vIsLastAmount = (i + 1) == vList.size();

			BigDecimal vBalanceChangeInRequestCurrency = inRequestCurrency(vBalanceChangeInCardCurrency);

			// If it is the last transaction for this redeem then set the
			// remaining amount
			// so the sums will add up to the exact requested amount
			if (vIsZeroLeft) {
				vBalanceChangeInRequestCurrency = Amounts.subtract(
						pVoRequestAmount.getRequestAmount(),
						vBalanceChangeInRequestCurrencySum);
			}

			// Sum up all the balance changes so we get a sum that is exactly
			// the same as the requested even if we round of some digits.
			vBalanceChangeInRequestCurrencySum = Amounts.add(
					vBalanceChangeInRequestCurrencySum,
					vBalanceChangeInRequestCurrency);

			// Register redeem transaction out side the amount, only for redeem
			registerRedeemTransactionReserved(vAmount, vVoRequestAmount,
					vBalanceChangeInRequestCurrency,
					vBalanceChangeInCardCurrency, vIsLastAmount && !vIsZeroLeft , pCardNumberString);

			if (vIsZeroLeft)
				break;

			// Prepare for redeem of next amount object
			vVoRequestAmount
			.setRequestAmount(inRequestCurrency(vRemainingAmountInCardCurrency));
		}

		// Set redeemed amount in requested currency
		if (pVoRedeemedAmountOut != null) {
			if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
				// We have redeemed all that was requested
				pVoRedeemedAmountOut.setRedeemAmount(pVoRequestAmount
						.getRequestAmount());
			} else {
				// Insufficient amount on card
				pVoRedeemedAmountOut.setRedeemAmount(inRequestCurrency(Amounts
						.subtract(vOriginalRequestedAmountInCardCurrency,
								vRemainingAmountInCardCurrency)));
			}
		}
	}
	
	protected void redeemAmountInCardCurrencyManual(VoRequestAmount pVoRequestAmount,
			VoRedeemAmount pVoRedeemedAmountOut, VoManualTransaction pVoManualTransaction, String pCardNumberString) throws AmountException,
	CurrencyException, ValueMissingException {

		requireBusinessUnitEnvironment();
		checkAmount(pVoRequestAmount);

		// Create new temporay request amount
		VoRequestAmount vVoRequestAmount = (VoRequestAmount) pVoRequestAmount
				.clone();

		final BigDecimal vOriginalRequestedAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		// Remaining amount is how much we still have to redeem from the card
		BigDecimal vRemainingAmountInCardCurrency = inCardCurrency(vVoRequestAmount
				.getRequestAmount());

		if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
			throw new CurrencyException(
					"Too small value of request amount. Amount in card currency restulted in zero!");
		}

		// Find active amounts
		List<Amount> vList = findActiveAmounts(mBusinessUnitEnvironment
				.getSalesDateTime(), inCardCurrency(vVoRequestAmount
						.getTotalAmount()), mBusinessUnitEnvironment.getBuType(),
				mBusinessUnitEnvironment.getBuCode());

		mLog.info("Found " + vList.size() + " active amounts.");
		if (vList.size() == 0 || Amounts.isZero(vRemainingAmountInCardCurrency)) {
			// No amounts found that matches. Create a zero transaction.
			registerZeroRedeemTransactionManual(vVoRequestAmount, pCardNumberString);
			// Set redeemed amount in requested currency
			if (pVoRedeemedAmountOut != null) {
				pVoRedeemedAmountOut.setRedeemAmount(Amounts.zero());
			}
			return;
		}
		BigDecimal vBalanceChangeInRequestCurrencySum = Amounts.zero();

		// Loop over amounts redeeming as we go
		for (int i = 0; i < vList.size(); i++) {
			Amount vAmount = (Amount) vList.get(i);

			// Create bec from amount
			BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
					vAmount, mBusinessUnitEnvironment, mTransactionEnvironment);

			// Try to redeem as much as possible
			BigDecimal vBalanceChangeInCardCurrency = vBecAmount.redeem(
					vVoRequestAmount, vRemainingAmountInCardCurrency);

			// Subtract the balance change from the remaining amount
			vRemainingAmountInCardCurrency = Amounts.subtract(
					vRemainingAmountInCardCurrency,
					vBalanceChangeInCardCurrency);

			boolean vIsZeroLeft = Amounts
					.isZero(vRemainingAmountInCardCurrency);
			boolean vIsLastAmount = (i + 1) == vList.size();

			BigDecimal vBalanceChangeInRequestCurrency = inRequestCurrency(vBalanceChangeInCardCurrency);

			// If it is the last transaction for this redeem then set the
			// remaining amount
			// so the sums will add up to the exact requested amount
			if (vIsZeroLeft) {
				vBalanceChangeInRequestCurrency = Amounts.subtract(
						pVoRequestAmount.getRequestAmount(),
						vBalanceChangeInRequestCurrencySum);
			}

			// Sum up all the balance changes so we get a sum that is exactly
			// the same as the requested even if we round of some digits.
			vBalanceChangeInRequestCurrencySum = Amounts.add(
					vBalanceChangeInRequestCurrencySum,
					vBalanceChangeInRequestCurrency);

			// Register redeem transaction out side the amount, only for redeem
			//registerRedeemTransaction(vAmount, vVoRequestAmount,
					//vBalanceChangeInRequestCurrency,
					//vBalanceChangeInCardCurrency, vIsLastAmount && !vIsZeroLeft);
			
			registerRedeemTransactionManual(vAmount, vVoRequestAmount,
					vBalanceChangeInRequestCurrency,
					vBalanceChangeInCardCurrency, vIsLastAmount && !vIsZeroLeft, pVoManualTransaction, pCardNumberString);

			if (vIsZeroLeft)
				break;

			// Prepare for redeem of next amount object
			vVoRequestAmount
			.setRequestAmount(inRequestCurrency(vRemainingAmountInCardCurrency));
		}

		// Set redeemed amount in requested currency
		if (pVoRedeemedAmountOut != null) {
			if (Amounts.isZero(vRemainingAmountInCardCurrency)) {
				// We have redeemed all that was requested
				pVoRedeemedAmountOut.setRedeemAmount(pVoRequestAmount
						.getRequestAmount());
			} else {
				// Insufficient amount on card
				pVoRedeemedAmountOut.setRedeemAmount(inRequestCurrency(Amounts
						.subtract(vOriginalRequestedAmountInCardCurrency,
								vRemainingAmountInCardCurrency)));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#loadCampaign(com.ikea
	 * .ebccardpay1.cardpayment.be.Campaign)
	 */
	public void loadCampaign(Campaign pCampaign) throws CurrencyException,
	AmountException, ValueMissingException, IkeaException, InvalidCardException {

		String cardType = mCard.getCardType();
		BecAmount vBecAmount = null;
		if(filterCountryToAllowReload())
		{
			// Try to find the campaign amount
			for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (pCampaign.equals(vAmount.getCampaign())) {
					vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
							mBusinessUnitEnvironment, mTransactionEnvironment);
				}
			}

			// Create a new amount
			if (vBecAmount == null) {

				vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment)
						.createDiscountForCampaign(
								mPriorityEvaluator.evaluatePriority(mCard
										.getAmounts(),
										Constants.AMOUNT_PRIORITY_CAMPAIGN),pCampaign);

			}

			vBecAmount.campaign(pCampaign);
		}
		else{
			requireNewCard();
			requireReload();
			for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (pCampaign.equals(vAmount.getCampaign())) {
					vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
							mBusinessUnitEnvironment, mTransactionEnvironment);
				}
			}

			// Create a new amount
			if (vBecAmount == null) {

				vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment)
						.createDiscountForCampaign(
								mPriorityEvaluator.evaluatePriority(mCard
										.getAmounts(),
										Constants.AMOUNT_PRIORITY_CAMPAIGN),pCampaign);

			}

			vBecAmount.campaign(pCampaign);
		}

	}

	public void CampaignLoadtransaction(Campaign pCampaign) throws Exception{

		Set<Amount> campaignAmounts = new LinkedHashSet<Amount>(pCampaign.getAmounts());
		for(Amount amount:campaignAmounts){
			mBecFactory.createBecTransaction().init(mCard,
					amount, mBusinessUnitEnvironment,
					mTransactionEnvironment).CampaignLoadtransaction(pCampaign,amount);
		}


	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#loadMassLoad(com.ikea
	 * .ebccardpay1.cardpayment.be.MassLoad)
	 */
	public void loadMassLoad(MassLoad pMassLoad) throws CurrencyException,
	AmountException, ValueMissingException, IkeaException, InvalidCardException {

		// Modified Promotional card Functionality, Defect-IKEA01072486 -anagc
		requireBusinessUnitEnvironment();
		//exception for  countries HU, US, CA, PL to reload
		if(filterCountryToAllowReload())
		{
			String cardType = mCard.getCardType();
			if (cardType!=null && (cardType.equalsIgnoreCase("REFUND")||cardType.equalsIgnoreCase("GIFT")||cardType.equalsIgnoreCase("VOUCHER")||cardType.equalsIgnoreCase("FAMILY")||cardType.equalsIgnoreCase("CAMPAIGN")))
			{
				requireNewCard();	
				checkReloadCriteria();
				BecAmount vBecAmount = null;
				// Try to find the Mass Load amount
				for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
					Amount vAmount = (Amount) i.next();

					if (pMassLoad.equals(vAmount.getMassLoad())) {
						vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
								mBusinessUnitEnvironment, mTransactionEnvironment);
					}
				}
				// Create a new amount
				if (vBecAmount == null) {
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment);

					boolean isCash = Constants.AMOUNT_TYPE_CONSTANT_CASH
							.equals(pMassLoad.getAmountType());

					if (isCash) {
						vBecAmount.createCash(mPriorityEvaluator.evaluatePriority(mCard
								.getAmounts(), Constants.AMOUNT_PRIORITY_MASSLOAD));
					} else {
						vBecAmount
						.createDiscount(mPriorityEvaluator.evaluatePriority(
								mCard.getAmounts(),
								Constants.AMOUNT_PRIORITY_MASSLOAD));
					}
					vBecAmount.massLoad(pMassLoad);
				}
				else if (cardType.equalsIgnoreCase("QPC")){
					throw new AmountException("QPC Cards Cannot be Loaded through MassLoad");
				}
			}

		}
		//		else{
		//			//Changes done in 3.10, CR- IKEA01097947
		//			throw new AmountException("You can't reload the cards in country "+mBusinessUnitEnvironment.getCountryCode());
		//
		//		}


		else{
			String cardtype = mCard.getCardType();
			if (cardtype!=null && (cardtype.equalsIgnoreCase("refund")||cardtype.equalsIgnoreCase("gift")||cardtype.equalsIgnoreCase("voucher")||cardtype.equalsIgnoreCase("family")||cardtype.equalsIgnoreCase("campaign")))
			{
				requireNewCard();
				requireReload();	
				//checkreloadcriteria();
				BecAmount vbecamount = null;
				// try to find the mass load amount
				for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
					Amount vamount = (Amount) i.next();

					if (pMassLoad.equals(vamount.getMassLoad())) {
						vbecamount = mBecFactory.createBecAmount().init(mCard, vamount,
								mBusinessUnitEnvironment, mTransactionEnvironment);
					}
				}
				// create a new amount
				if (vbecamount == null) {
					vbecamount = mBecFactory.createBecAmount().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment);

					boolean iscash = Constants.AMOUNT_TYPE_CONSTANT_CASH
							.equals(pMassLoad.getAmountType());

					if (iscash) {
						vbecamount.createCash(mPriorityEvaluator.evaluatePriority(mCard
								.getAmounts(), Constants.AMOUNT_PRIORITY_MASSLOAD));
					} else {
						vbecamount
						.createDiscount(mPriorityEvaluator.evaluatePriority(
								mCard.getAmounts(),
								Constants.AMOUNT_PRIORITY_MASSLOAD));
					}
				}
				vbecamount.massLoad(pMassLoad);
			}
			else if (cardtype.equalsIgnoreCase("qpc")){
				throw new AmountException("qpc cards cannot be loaded through massload");
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#loadMultipleSingleLoad(com.ikea
	 * .ebccardpay1.cardpayment.be.MultipleSingleLoad)
	 */
	public void loadMultipleSingleLoad(MultipleSingleLoad pMultipleSingleLoad, BigDecimal pAmountValue)
			throws CurrencyException, CardPayException, ValueMissingException, IkeaException {

		requireBusinessUnitEnvironment();
		//exception for  countries HU, US, CA, PL to Reload
		if(filterCountryToAllowReload())
		{
			String cardType = mCard.getCardType();		
			if (cardType!=null && (cardType.equalsIgnoreCase("REFUND")||cardType.equalsIgnoreCase("GIFT")||cardType.equalsIgnoreCase("VOUCHER")||cardType.equalsIgnoreCase("FAMILY"))){

				requireNewCard();	
				//requireAckload();
				checkReloadCriteria();
				BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment);

				vBecAmount.createCash(mPriorityEvaluator.evaluatePriority(mCard
						.getAmounts(), Constants.AMOUNT_PRIORITY_GIFT));

				vBecAmount.multipleSingleLoad(pMultipleSingleLoad, pAmountValue);
			}
			if (cardType.equalsIgnoreCase("QPC")){
				throw new AmountException("QPC Card can be loaded only through POS");
			}
			else if (cardType.equalsIgnoreCase("CAMPAIGN")){
				throw new AmountException("CAMPAIGN Card can be loaded threw Massload");
			}

		}
		//		else{
		//			//Changes done in 3.10, CR- IKEA01097947
		//			throw new AmountException("You can't reload the cards in country "+mBusinessUnitEnvironment.getCountryCode());
		//
		//		}
		else{
			String cardType = mCard.getCardType();		
			if (cardType!=null && (cardType.equalsIgnoreCase("REFUND")||cardType.equalsIgnoreCase("GIFT")||cardType.equalsIgnoreCase("VOUCHER")||cardType.equalsIgnoreCase("FAMILY")))
			{
				requireNewCard();
				requireReload();	
				//requireAckload();
				//checkReloadCriteria();
				// Create a new amount
				BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment);

				vBecAmount.createCash(mPriorityEvaluator.evaluatePriority(mCard
						.getAmounts(), Constants.AMOUNT_PRIORITY_GIFT));

				vBecAmount.multipleSingleLoad(pMultipleSingleLoad, pAmountValue);
			}
			else if (cardType.equalsIgnoreCase("QPC")){
				throw new AmountException("QPC Card can be loaded only through POS");
			}
			else if (cardType.equalsIgnoreCase("CAMPAIGN")){
				throw new AmountException("CAMPAIGN Card can be loaded threw Massload");
			}
		}
	}

	public void loadBonus(Bonus pBonus) throws CurrencyException,
	AmountException, ValueMissingException, IkeaException, InvalidCardException {

		requireBusinessUnitEnvironment();
		//exception for  countries HU, US, CA, PL to Reload
		if(filterCountryToAllowReload())
		{
			String cardType = mCard.getCardType();		
			if (cardType!=null && (!cardType.equalsIgnoreCase("QPC"))||(!cardType.equalsIgnoreCase("CAMPAIGN")))
			{
				requireCard();
				requireNewCard();	
				//requireAckload();
				checkReloadCriteria();
				// Create a new amount
				BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment);

				boolean isCash = Constants.AMOUNT_TYPE_CONSTANT_CASH.equals(pBonus
						.getAmountType());

				if (isCash) {
					vBecAmount.createCash(mPriorityEvaluator.evaluatePriority(mCard
							.getAmounts(), Constants.AMOUNT_PRIORITY_GIFT));
				} else {
					vBecAmount.createDiscount(mPriorityEvaluator.evaluatePriority(mCard
							.getAmounts(), Constants.AMOUNT_PRIORITY_REFUND));
				}
				vBecAmount.bonus(pBonus);	
			}
			if (cardType.equalsIgnoreCase("QPC")){
				throw new AmountException("QPC Card can be loaded only through Bonus");
			}
			else if (cardType.equalsIgnoreCase("CAMPAIGN")){
				throw new AmountException("CAMPAIGN Card can be loaded threw Bonus");
			}
		}
		//		else{
		//			//Changes done in 3.10, CR- IKEA01097947
		//			throw new AmountException("You can't reload the cards in country "+mBusinessUnitEnvironment.getCountryCode());
		//
		//		}
		else{
			String cardType = mCard.getCardType();		
			if (cardType!=null && (!cardType.equalsIgnoreCase("QPC"))||(!cardType.equalsIgnoreCase("CAMPAIGN"))){
				requireNewCard();
				requireCard();
				requireReload();
				//requireAckload();
				//checkReloadCriteria();
				// Create a new amount
				BecAmount vBecAmount = mBecFactory.createBecAmount().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment);

				boolean isCash = Constants.AMOUNT_TYPE_CONSTANT_CASH.equals(pBonus
						.getAmountType());

				if (isCash) {
					vBecAmount.createCash(mPriorityEvaluator.evaluatePriority(mCard
							.getAmounts(), Constants.AMOUNT_PRIORITY_GIFT));
				} else {
					vBecAmount.createDiscount(mPriorityEvaluator.evaluatePriority(mCard
							.getAmounts(), Constants.AMOUNT_PRIORITY_REFUND));
				}

				vBecAmount.bonus(pBonus);
			}

			if (cardType.equalsIgnoreCase("QPC")){
				throw new AmountException("QPC Card can be loaded only through Bonus");
			}
			else if (cardType.equalsIgnoreCase("CAMPAIGN")){
				throw new AmountException("CAMPAIGN Card can be loaded threw Bonus");
			}
		}

	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecAmounts#findActiveAmounts(java
	 * .util.Date)
	 */
	public List<Amount> findActiveAmounts(Date pCalculationTime,
			BigDecimal pTotalAmount, String pBuType, String pBuCode)
					throws ValueMissingException {

		requireCard();

		List<Amount> vList = new ArrayList<Amount>();
		for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
			Amount vAmount = (Amount) i.next();
			if (isActive(vAmount, pCalculationTime, pTotalAmount, pBuType,
					pBuCode)) {
				vList.add(vAmount);
			}
		}

		Collections.sort(vList, DefaultPriorityEvaluator.sPriorityComparator);

		return vList;
	}

	/**
	 * -------------
	 * Internal methods, must be protected so unit tests can access them
	 * -------------
	 */

	protected BecAmount activeCashBecAmount() throws ValueMissingException {

		requireCard();
		requireBusinessUnitEnvironment();

		Date vCalculationTime = mBusinessUnitEnvironment.getSalesDateTime();

		for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
			Amount vAmount = (Amount) i.next();

			if (Constants.AMOUNT_TYPE_CONSTANT_CASH.equals(vAmount
					.getAmountType())
					&& isActive(vAmount, vCalculationTime, null, null, null)
					&& vAmount.getBuType().equals(
							mBusinessUnitEnvironment.getBuType())
					&& vAmount.getBuCode().equals(
							mBusinessUnitEnvironment.getBuCode())) {

				return mBecFactory.createBecAmount().init(mCard, vAmount,
						mBusinessUnitEnvironment, mTransactionEnvironment);
			}
		}

		return mBecFactory.createBecAmount().init(mCard,
				mBusinessUnitEnvironment, mTransactionEnvironment).createCash(
						mPriorityEvaluator.evaluatePriority(mCard.getAmounts(),
								Constants.AMOUNT_PRIORITY_GIFT));
	}

	/**
	 * Is this amount valid on the given date and time? Can it be used for
	 * redemption and balance?
	 * 
	 * @param pAmount
	 * @param pActiveOn
	 * @return
	 */
	protected boolean isActive(Amount pAmount, Date pActiveOn,
			BigDecimal pTotalAmount, String pBuType, String pBuCode) {

		if (pAmount.getCurrentAmount() == null
				|| Amounts.isZero(pAmount.getCurrentAmount())) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_ZEROED);
			return false;
		}

		if (pAmount.getCampaign() != null) {
			return isActiveCampaign(pAmount, pActiveOn, pTotalAmount, pBuType,
					pBuCode,mBefIpayBusinessUnits);
		} else if (pAmount.getMassLoad() != null) {
			return isActiveMassLoad(pAmount);
		} else if (pAmount.getBonus() != null) {
			return isActiveBonus(pAmount);
		} else if (pAmount.getMultipleSingleLoad() != null) {
			return isActiveMultipleSingleLoad(pAmount);
		}

		// If no obstacles found then it is included
		pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);
		return true;
	}

	/**
	 * 
	 * @param pAmount
	 * @param pCalulationUtcTime
	 * @param pTotalAmount
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 */
	protected boolean isActiveCampaign(Amount pAmount, Date pCalulationUtcTime,
			BigDecimal pTotalAmount, String pBuType, String pBuCode,BefIpayBusinessUnits pBefIpayBusinessUnits) {

		Campaign vCampaign = pAmount.getCampaign();

		// A campaign is active only if it is authorized and not withdrawn.
		if (vCampaign.getAuthorizedDateTime() == null) {

			// The campaign is not released yet -> not active
			pAmount.setBalanceState(Constants.BALANCE_STATE_PROCESSING);
			return false;
		}
		if (vCampaign.getWithdrawnDateTime() != null) {

			// The campaign is withdrawn -> not active
			pAmount.setBalanceState(Constants.BALANCE_STATE_WITHDRAWN);
			return false;
		}

		// Assume included state
		pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);

		if (pBuType != null && pBuCode != null) {

			String vSalesDay = Dates.calculateSalesDay(mUnits,
					pCalulationUtcTime, pBuType, pBuCode, mBefIpayBusinessUnits);

			// Sales day < start date
			if (before(vSalesDay, vCampaign.getIntervalStartDate())) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}

			// Sales day > stop date
			if (after(vSalesDay, vCampaign.getIntervalEndDate())) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}

			// Test week day
			if (!activeForWeekdays(vSalesDay, vCampaign)) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}

			// Test time of day
			if (!activeForTime(pCalulationUtcTime, pBuType, pBuCode, vCampaign)) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}

			if (!activeForLimitations(pBuType, pBuCode, vCampaign)) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}
		} else {
			// No BU set
			// The true sales day can not be more than 2 days away so start with
			// a rough guess to exclude very old and the once far in the future.
			DateTime vMinCalc = new DateTime(pCalulationUtcTime).minusDays(2);
			DateTime vMaxCalc = new DateTime(pCalulationUtcTime).plusDays(2);

			// vMaxCalc < start date
			if (before(Dates.formatDate(vMaxCalc), vCampaign
					.getIntervalStartDate())) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_FUTURE);
				return false;
			}

			// vMinCalc > stop date
			if (after(Dates.formatDate(vMinCalc), vCampaign
					.getIntervalEndDate())) {
				pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
				return false;
			}
		}

		// Test minimum purchase amount
		if (vCampaign.getMinPurchaseAmount() != null
				&& pTotalAmount != null
				&& Amounts.isLess(pTotalAmount, vCampaign
						.getMinPurchaseAmount())) {

			pAmount.setBalanceState(Constants.BALANCE_STATE_EXCLUDED);
			return false;
		}

		if (pBuType == null || pBuCode == null) {
			// We are in an uncertain context where active depends on BU
			pAmount.setBalanceState(Constants.BALANCE_STATE_TENTATIVE);
		} else if ((pTotalAmount == null || Amounts.isZero(pTotalAmount))
				&& vCampaign.getMinPurchaseAmount() != null
				&& !Amounts.isZero(vCampaign.getMinPurchaseAmount())) {
			// We are in an uncertain context where active depends on total
			// sales amount
			pAmount.setBalanceState(Constants.BALANCE_STATE_TENTATIVE);
		} else {
			pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);
		}

		return true;
	}

	/**
	 * 
	 * @param pBuType
	 * @param pBuCode
	 * @param pCampaign
	 * @return
	 */
	protected boolean activeForLimitations(String pBuType, String pBuCode,
			Campaign pCampaign) {

		if (pBuType != null && pBuCode != null) {

			// Test valid for BU list
			Collection<CampaignLimitation> vLimitations = pCampaign
					.getCampaignLimitations();
			if (vLimitations != null && vLimitations.size() > 0) {
				boolean vHit = false, vType = false, vCode = false;

				// Look for a hit in the limitation list
				for (Iterator<CampaignLimitation> i = vLimitations.iterator(); i
						.hasNext()
						&& !vHit;) {
					CampaignLimitation vCampaignLimitation = (CampaignLimitation) i
							.next();

					vType = vCampaignLimitation.getBuType().equals(pBuType);
					vCode = vCampaignLimitation.getBuCode().equals(pBuCode);
					vHit = vType && vCode;
				}

				// If we don't get a hit campaign is not applicable
				if (!vHit) {
					return false;
				}
			}
		}
		return true;
	}

	protected boolean activeForWeekdays(String pSalesDay, Campaign pCampaign) {

		DateTime vDateTime = Dates.parseDate(pSalesDay);
		int vWeekday = vDateTime.dayOfWeek().get();
		if (!pCampaign.getMonday() && vWeekday == DateTimeConstants.MONDAY) {
			return false;
		}
		if (!pCampaign.getTuesday() && vWeekday == DateTimeConstants.TUESDAY) {
			return false;
		}
		if (!pCampaign.getWednesday()
				&& vWeekday == DateTimeConstants.WEDNESDAY) {
			return false;
		}
		if (!pCampaign.getThursday() && vWeekday == DateTimeConstants.THURSDAY) {
			return false;
		}
		if (!pCampaign.getFriday() && vWeekday == DateTimeConstants.FRIDAY) {
			return false;
		}
		if (!pCampaign.getSaturday() && vWeekday == DateTimeConstants.SATURDAY) {
			return false;
		}
		if (!pCampaign.getSunday() && vWeekday == DateTimeConstants.SUNDAY) {
			return false;
		}
		return true;
	}

	protected boolean activeForTime(Date pCalulationUtcTime, String pBuType,
			String pBuCode, Campaign pCampaign) {

		if (pCampaign.getFromTime() == null && pCampaign.getUntilTime() == null) {
			return true;
		}

		String vTimeZoneId = mUnits.getTimeZone(pBuType, pBuCode);

		DateTime vSalesTime = Dates.localDateTime(pCalulationUtcTime,
				vTimeZoneId);
		String vSales = Dates.formatTime(vSalesTime, true);

		if (beforeTime(vSales, pCampaign.getFromTime())) {
			return false;
		}
		if (afterTime(vSales, pCampaign.getUntilTime())) {
			return false;
		}
		return true;
	}

	/**
	 * @param pLeft
	 * @param pRight
	 * @return
	 */
	protected boolean before(String pLeft, Date pRight) {
		if (pRight == null) {
			return false;
		}
		YearMonthDay vRightYearMonthDay = new YearMonthDay(pRight.getTime());
		YearMonthDay vLeftDateTime = new YearMonthDay(Dates.parseDate(pLeft));
		return vLeftDateTime.isBefore(vRightYearMonthDay);
	}

	/**
	 * @param pLeft
	 * @param pRight
	 * @return
	 */
	protected boolean after(String pLeft, Date pRight) {
		if (pRight == null) {
			return false;
		}
		YearMonthDay vRightYearMonthDay = new YearMonthDay(pRight.getTime());
		YearMonthDay vLeftDateTime = new YearMonthDay(Dates.parseDate(pLeft));
		return vLeftDateTime.isAfter(vRightYearMonthDay);
	}

	/**
	 * @param pLeft_HHMMSS
	 * @param pRight_HHMM
	 * @return
	 */
	protected boolean beforeTime(String pLeft_HHMMSS, String pRight_HHMM) {
		if (pRight_HHMM == null || pRight_HHMM.length() == 0) {
			return false;
		}
		String vRight_HHMMSS = pRight_HHMM + ":00";
		return pLeft_HHMMSS.compareTo(vRight_HHMMSS) < 0;
	}

	/**
	 * @param pLeft_HHMMSS
	 * @param pRight_HHMM
	 * @return
	 */
	protected boolean afterTime(String pLeft_HHMMSS, String pRight_HHMM) {
		if (pRight_HHMM == null || pRight_HHMM.length() == 0) {
			return false;
		}
		String vRight_HHMMSS = pRight_HHMM + ":00";
		return pLeft_HHMMSS.compareTo(vRight_HHMMSS) > 0;
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected boolean isActiveMassLoad(Amount pAmount) {

		MassLoad vMassLoad = pAmount.getMassLoad();
		if (vMassLoad == null) {
			return false;
		}

		// A mass load is active if it is released and not withdrawn.
		if (vMassLoad.getReleasedDateTime() != null
				&& vMassLoad.getWithdrawnDateTime() == null) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);
			return true;
		}

		if (vMassLoad.getWithdrawnDateTime() != null) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_WITHDRAWN);

		} else if (vMassLoad.getReleasedDateTime() == null) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_PROCESSING);

		}
		return false;
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected boolean isActiveBonus(Amount pAmount) {

		Bonus vBonus = pAmount.getBonus();
		if (vBonus == null) {
			return false;
		}

		// A bonus is active after it is authorized
		if (vBonus.getAuthorizedDateTime() != null) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);
			return true;

		} else {
			pAmount.setBalanceState(Constants.BALANCE_STATE_PROCESSING);
			return false;
		}
	}

	/**
	 * 
	 * @param pAmount
	 * @return
	 */
	protected boolean isActiveMultipleSingleLoad(Amount pAmount) {

		MultipleSingleLoad vMultipleSingleLoad = pAmount.getMultipleSingleLoad();
		if (vMultipleSingleLoad == null) {
			return false;
		}

		// A multiple single load is active after it is authorized
		if (vMultipleSingleLoad.getAuthorizedDateTime() != null) {
			pAmount.setBalanceState(Constants.BALANCE_STATE_INCLUDED);
			return true;

		} else {
			pAmount.setBalanceState(Constants.BALANCE_STATE_PROCESSING);
			return false;
		}
	}
	/**
	 * 
	 * @param pVoRequestAmount
	 * @throws CurrencyException
	 */
	protected void checkAmount(VoRequestAmount pVoRequestAmount)
			throws AmountException, ValueMissingException {

		if (pVoRequestAmount == null) {
			throw new ValueMissingException("VoRequestAmount was null.");
		}

		// The amount must not be null, negative or zero
		if (pVoRequestAmount.getRequestAmount() == null) {
			throw new AmountException("Requested redeem amount was null.");

		} else if (Amounts.isNegative(pVoRequestAmount.getRequestAmount())) {
			throw new AmountException("Requested redeem amount was negative.");

		} else if (Amounts.isZero(pVoRequestAmount.getRequestAmount())) {
			throw new AmountException("Requested redeem amount was zero.");
		}

	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException(
					"Tried to use BecAmounts without required Card.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment()
			throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException(
					"Tried to use BecAmounts without required BusinessUnitEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment() throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException(
					"Tried to use BecAmounts without required TransactionEnvironment.");
	}
	/**
	 * 
	 * @throws AmountException
	 * @throws IkeaException 
	 */
	protected void requireNewCard() throws AmountException, IkeaException {


		mLog.info("Entering requireNewCard ");
		if(isProductionEnviornment()){
			String cardType = mCard.getCardType();
			//if (cardType!=null && (cardType.equalsIgnoreCase("QPC")||cardType.equalsIgnoreCase("CAMPAIGN")||cardType.equalsIgnoreCase("VOUCHER") )){
			if (cardType!=null && (cardType.equalsIgnoreCase("QPC")||cardType.equalsIgnoreCase("VOUCHER") )){
				if (mCard.getAmounts()== null || mCard.getAmounts().size()>=1)
					throw new AmountException("QPC,CAMPAIGN,VOUCHER Cards cannot be loaded more than once.");
			}
			/*else {
				throw new AmountException("Invalid CardType or no cardType specified");
			}*/

		}

	}
	/**
	 * 
	 * @throws AmountException
	 * @throws IkeaException 
	 */
	protected void requireReload() throws AmountException, IkeaException {
		mLog.info("Entering requireReload ");
		if(isProductionEnviornment()){
			String cardType = mCard.getCardType();
			if (mCard.getAmounts()== null || mCard.getAmounts().size()>=1)
				throw new AmountException("You can't reload the cards in country "+mBusinessUnitEnvironment.getCountryCode());

			/*else {
				throw new AmountException("Invalid CardType or no cardType specified");
			}*/

		}
	}
	protected void requireAckload() throws AmountException, IkeaException {
		mLog.info("Entering requireAckload ");
		if ((mTransactionEnvironment.getSourceSystem().equalsIgnoreCase("ISELL") ||
				mTransactionEnvironment.getSourceSystem().equalsIgnoreCase("IRW")||
				mTransactionEnvironment.getSourceSystem().equalsIgnoreCase("ICP")||mTransactionEnvironment.getSourceSystem().equalsIgnoreCase("IME"))
				&&!mTransactionEnvironment.getAutoAcknowledge()){
			throw new AmountException("cannot be loaded with AutoAcknowledge false");
		}
	}
	protected boolean isProductionEnviornment() throws IkeaException ,AmountException {
		String vHost = mEbcProperties.getString("server_environment", "production");
		mLog.info("server_environment: "+vHost);
		if(vHost.equalsIgnoreCase("production")|| vHost.startsWith("prod")){
			return true;
		}
		return false;
	}

	protected boolean filterCountryToAllowReload() throws IkeaException ,AmountException, ValueMissingException{

		requireBusinessUnitEnvironment();		
		String vCountry= mBusinessUnitEnvironment.getCountryCode();
		mLog.info("filter_source : "+vCountry);
		String vHost = mEbcProperties.getString("FilterCountryToAllowReload","NOSOURCE");
		ArrayList<String> vHostList = new  ArrayList<String>(Arrays.asList(vHost.split(",")));
		mLog.info("Filter Country To Allow Reload: "+vHostList);
		return vHostList.contains(vCountry);
	}
	protected void checkReloadCriteria() throws IkeaException, ValueMissingException, InvalidCardException {
		requireBusinessUnitEnvironment();	
		mLog.info("Entering requireAckload ");
		String vCompany= mBusinessUnitEnvironment.getCompanyCode();
		String ExistingCompany = null;
		if (mCard.getAmounts()!= null || mCard.getAmounts().size()>=1){
			for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
				Amount vAmount = (Amount) i.next();
				String pBuType=vAmount.getBuType();
				String pBuCode=vAmount.getBuCode();
				ExistingCompany=mUnits.getCompanyCode(pBuType, pBuCode);
				break;
			}
		}

		if(ExistingCompany!= null&&!vCompany.equals(ExistingCompany)){
			throw new InvalidCardException("Wrong Business Unit,Company Code'" + vCompany
					+ "'not maching to the bounded Company Code");
		}

	}
	//Modified by anagc
	protected void checkRedeemCriteria() throws IkeaException, ValueMissingException, InvalidCardException, InvalidForeignCardException {
		requireBusinessUnitEnvironment();	
		mLog.info("Entering requireAckload ");
		String vCountry= mBusinessUnitEnvironment.getCountryCode();
		String ExistingCountry = null;
		String cardType = mCard.getCardType();
		if (cardType!=null && (cardType.equalsIgnoreCase("QPC")||cardType.equalsIgnoreCase("CAMPAIGN")||cardType.equalsIgnoreCase("VOUCHER")||cardType.equalsIgnoreCase("FAMILY") ))
		{
			if (mCard.getAmounts()!= null){
				for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
					Amount vAmount = (Amount) i.next();
					String pBuType=vAmount.getBuType();
					String pBuCode=vAmount.getBuCode();
					ExistingCountry=mUnits.getCountryCode(pBuType, pBuCode);
					break;
				}
			}

			if(ExistingCountry!= null&&!vCountry.equals(ExistingCountry)){

				/*PR-IKEA01082411 use one Error Code for all Foreign cards exception
				throw new PromotionalCardException("You can't redeem the "+cardType+" card in different country other than where it was loaded. The card was loaded in "+ExistingCountry );
				 */
				throw new InvalidForeignCardException("You can't redeem the "+cardType+" card in different country other than where it was loaded. The card was loaded in "+ExistingCountry );
			}

		}
	}
	/**
	 * @param pMassLoad
	 * @throws CurrencyException
	 * @throws AmountException
	 * @throws ValueMissingException
	 * @throws IkeaException 
	 * @throws InvalidCardException
	 * - by anagc on 02-16-2016 
	 */
	public void withdrawMassLoad(MassLoad pMassLoad)
			throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException
	{
		requireBusinessUnitEnvironment();
		BecAmount vBecAmount = null;
		String cardType = mCard.getCardType();
		// Try to find the Mass Load amount
		for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
			Amount vAmount = (Amount) i.next();

			if (pMassLoad.equals(vAmount.getMassLoad())) {
				vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
						mBusinessUnitEnvironment, mTransactionEnvironment);
			}
		}

		vBecAmount.massLoad(pMassLoad);
	}

	public void expireCampign(Campaign pCampaign)
			throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException, TransactionException
	{
		requireBusinessUnitEnvironment();
		BecAmount vBecAmount = null;
		String cardType = mCard.getCardType();
		// Try to find the Mass Load amount
		Amount vAmount = findAmount(pCampaign,mCard);
		vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment);
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
		BigDecimal vCardBalanceChange= vBecAmount.expirecampaign(pCampaign,vAmount);
		mBecFactory.createBecTransaction().init(mCard, vAmount,
				mBusinessUnitEnvironment, vTransactionEnvironment)
		.createExpiredTransaction(pCampaign,vCardBalanceChange);
	}
	protected Amount findAmount(Campaign pCampaign, Card pCard) {

		if (pCampaign != null) {
			for (Iterator<Amount> i = pCard.getAmounts().iterator(); i
					.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (vAmount != null && pCampaign.equals(vAmount.getCampaign())) {

					return vAmount;
				}
			}
		}

		return null;
	}
	//@Override
	public void redeemAmount(List<Amount> amouts) throws AmountException,
	CurrencyException, ValueMissingException, InvalidCardException,
	IkeaException {

		requireCard();

		BecAmount vBecAmount = null;
		BigDecimal vBalanceChangeInCardCurrency = null;
		BigDecimal vRemainingAmountInCardCurrency = null;
		BigDecimal vBalanceChangeInRequestCurrencySum = Amounts.zero();
		BigDecimal vCurrentAmount = null;

		if (amouts != null && !amouts.isEmpty()) {

			for (int i = 0; i < amouts.size(); i++) {
				if (amouts.get(i).getCurrentAmount().doubleValue() > 0 && amouts.get(i).getBuCode()!=null) {

					vCurrentAmount = amouts.get(i).getCurrentAmount();
					vBecAmount = mBecFactory.createBecAmount().init(mCard,
							amouts.get(i), mBusinessUnitEnvironment,
							mTransactionEnvironment);
					vBalanceChangeInCardCurrency = vBecAmount
							.redeemExpiredAmount(amouts.get(i)
									.getCurrentAmount(), amouts.get(i)
									.getCurrentAmount());
					// Subtract the balance change from the remaining amount
					vRemainingAmountInCardCurrency = amouts.get(i)
							.getCurrentAmount();
					vRemainingAmountInCardCurrency = Amounts.subtract(
							vRemainingAmountInCardCurrency,
							vBalanceChangeInCardCurrency);

					boolean vIsZeroLeft = Amounts
							.isZero(vRemainingAmountInCardCurrency);
					boolean vIsLastAmount = (i + 1) == amouts.size();

					BigDecimal vBalanceChangeInRequestCurrency = inRequestCurrency(vBalanceChangeInCardCurrency);

					// If it is the last transaction for this redeem then set
					// the
					// remaining amount
					// so the sums will add up to the exact requested amount
					if (vIsZeroLeft) {
						vBalanceChangeInRequestCurrency = Amounts.subtract(
								amouts.get(i).getCurrentAmount(),
								vBalanceChangeInRequestCurrencySum);
					}

					// Sum up all the balance changes so we get a sum that is
					// exactly
					// the same as the requested even if we round of some
					// digits.
					vBalanceChangeInRequestCurrencySum = Amounts.add(
							vBalanceChangeInRequestCurrencySum,
							vBalanceChangeInRequestCurrency);

					mBecFactory.createBecTransaction().init(mCard,
							amouts.get(i), mBusinessUnitEnvironment,
							mTransactionEnvironment).createRedeemTransaction(
									vBalanceChangeInRequestCurrency,
									vBalanceChangeInCardCurrency, vIsLastAmount,
									amouts.get(i), mCard, vCurrentAmount);

					if (vIsZeroLeft)
						break;

				}

			}
		}

	}
	public void withdrawnCampign(Campaign pCampaign)
			throws CurrencyException, AmountException, ValueMissingException, IkeaException, InvalidCardException, TransactionException
	{
		requireBusinessUnitEnvironment();
		BecAmount vBecAmount = null;
		String cardType = mCard.getCardType();
		// Try to find the Mass Load amount
		Amount vAmount = findAmount(pCampaign,mCard);
		vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment);
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
		BigDecimal vCardBalanceChange= vBecAmount.withdrawncampaign(pCampaign,vAmount);
		mBecFactory.createBecTransaction().init(mCard, vAmount,
				mBusinessUnitEnvironment, vTransactionEnvironment)
		.createWithdrawnTransaction(pCampaign,vCardBalanceChange);
	}	

	public void updateCampaignLoadTransactions_Aouthorization(Transaction pTransaction , Campaign pCampaign) throws Exception {
		mBecFactory.createBecTransaction().init(pTransaction, mBusinessUnitEnvironment, mTransactionEnvironment).updateCampaignLoadTransactions_Aouthorization(pTransaction,pCampaign);
	}
	//@Override
	public void updateCampaignLoadTransactions_Withdrawal(Transaction pTransaction,
			Campaign pCampaign) throws Exception {
		mBecFactory.createBecTransaction().init(pTransaction, mBusinessUnitEnvironment, mTransactionEnvironment).updateCampaignLoadTransactions_Withdrawal(pTransaction,pCampaign);

	}

	//@Override
	public void CampaignDebiTransaction(Campaign pCampaign,String sales_Day) throws Exception {
		for (Iterator<Amount> i = mCard.getAmounts().iterator(); i.hasNext();) {
			Amount vAmount = (Amount) i.next();

			if (pCampaign.equals(vAmount.getCampaign())) {
				mBecFactory.createBecTransaction().init(mCard,
						vAmount, mBusinessUnitEnvironment,
						mTransactionEnvironment).CampaignDebiTransaction(pCampaign,vAmount,sales_Day);
			}

		}
	}

	public void withdrawnSingleLoad(MultipleSingleLoad pMultipleSingleLoad) throws ValueMissingException, CurrencyException, AmountException, TransactionException

	{
		requireBusinessUnitEnvironment();
		BecAmount vBecAmount = null;
		String cardType = mCard.getCardType();
		// Try to find the Mass Load amount
		Amount vAmount = findAmount(pMultipleSingleLoad,mCard);
		vBecAmount = mBecFactory.createBecAmount().init(mCard, vAmount,
				mBusinessUnitEnvironment, mTransactionEnvironment);
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
		BigDecimal vCardBalanceChange= vBecAmount.withdrawnMultipleSingleLoad();
		mBecFactory.createBecTransaction().init(mCard, vAmount,
				mBusinessUnitEnvironment, vTransactionEnvironment)
		.createWithdrawnMultipleSingleLoad(pMultipleSingleLoad,vAmount.getOriginalAmount(),vCardBalanceChange);
	}

	protected Amount findAmount(MultipleSingleLoad pMultipleSingleLoad, Card pCard) {

		if (pMultipleSingleLoad != null) {
			for (Iterator<Amount> i = pCard.getAmounts().iterator(); i
					.hasNext();) {
				Amount vAmount = (Amount) i.next();

				if (vAmount != null && pMultipleSingleLoad.equals(vAmount.getMultipleSingleLoad())) {

					return vAmount;
				}
			}
		}

		return null;
	}
}
