package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;

public class EbcEnvironmentMock implements EbcEnvironment {

	public int getMaxCardsInCampaignProcessing() {
		return 1;
	}

	public int getMaxCardsInMassLoadProcessing() {
		return 1;
	}

}
