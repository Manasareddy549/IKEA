/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Collection;
import java.util.List;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefCard extends Bef<Card>{
	
	public List<Card> getExpiredCards(String fromDate , String todate) throws Exception;
    public Collection<Card>  getExpiredCards() throws Exception;
    public Card findByCardId(long cardId);
	
}