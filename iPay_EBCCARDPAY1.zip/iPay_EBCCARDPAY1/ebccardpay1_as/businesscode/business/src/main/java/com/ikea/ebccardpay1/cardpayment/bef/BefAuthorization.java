/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;

public interface BefAuthorization extends Bef<Authorization>{

	public Authorization findByAuthorizationNumber(String pAuthorizationNumber);

	public Authorization findByTransactionNo(long pTransactionNo);

	public java.util.List<Authorization> findByCard(Card pCard);

}