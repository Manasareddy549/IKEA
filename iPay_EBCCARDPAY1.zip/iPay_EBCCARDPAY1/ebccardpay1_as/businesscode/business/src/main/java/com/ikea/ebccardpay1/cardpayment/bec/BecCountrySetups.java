/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountrySetup;
import com.ikea.ebcframework.exception.IkeaException;
import java.util.List;

/**
 * @author anms
 *
 */
public interface BecCountrySetups {

	/**
	 * @param pVoCountrySetupList
	 * @return
	 */
	public BecCountrySetups init(List<VoCountrySetup> pVoCountrySetupList);

	/**
	 * @throws IkeaException
	 * @throws ValueMissingException
	 * @throws CountrySetupException
	 */
	public void manage()
		throws IkeaException, ValueMissingException, CountrySetupException;

	/**
	 * @return
	 */
	public List<VoCountrySetup> getVoCountrySetupList()
		throws ValueMissingException;

	/**
	 * @return
	 * @throws IkeaException
	 */
	public List<VoCountrySetup> findAllCountrySetups()
		throws IkeaException, ValueMissingException;
}
