package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

/**
 * @author anagc
 *
 */
public class CnCard extends BusinessEntity {
	
	private long cardId;
	private String cardNumber;
	private String registered;
	private long cnBatchJobId;

	
	/**										
	 * Common attributes	
	 */		
	private int versionNo;
	private java.util.Date createdDateTime;
	private java.util.Date updatedDateTime;
	private String createdBy;
	private String updatedBy;
	
	
	public long getCardId() {
		return cardId;
	}
	public void setCardId(long cardId) {
		this.cardId = cardId;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getRegistered() {
		return registered;
	}
	public void setRegistered(String registered) {
		this.registered = registered;
	}
	public long getCnBatchJobId() {
		return cnBatchJobId;
	}
	public void setCnBatchJobId(long cnBatchJobId) {
		this.cnBatchJobId = cnBatchJobId;
	}
	public int getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(int versionNo) {
		this.versionNo = versionNo;
	}
	public java.util.Date getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(java.util.Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public java.util.Date getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(java.util.Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
	
}
