package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.mdsd.BusinessEntity;
import org.hibernate.Session;

public interface Bef<T extends BusinessEntity> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#create()
	 */
	public abstract T create();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#save(Amount)
	 */
	public abstract void save(T pEntity);
	
	public abstract void update(T pEntity);
	
	public abstract void saveOrUpdate(T pEntity);
	
	public abstract void merge(T pEntity) ;
	
	public abstract Session getOpenSession();
	
	public abstract Session getCurrentSession();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#findByPrimaryKey(long)
	 */
	public abstract T findByPrimaryKey(long pId);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#findAll()
	 */
	public abstract java.util.List<T> findAll();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefAmount#delete(Amount) {
	 */
	public abstract void delete(T pEntity);

}