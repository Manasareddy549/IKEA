/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Parameter;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefParameterImpl extends BefAbstract<Parameter> implements BefParameter {

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefParameterImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<Parameter> getBusinessEntityClass() {
		return Parameter.class;
	}

}
