package com.ikea.ebccardpay1.cardpayment.utils;
import static org.apache.commons.lang.Validate.notNull;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.cache.IkeaCacheFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;

/**
 */

public class CountrySetupCacheFactory implements InitializingBean {

    @Autowired
    private BefFactory befFactory;

    private final IkeaCacheFactory ikeaCacheFactory;

    @Autowired
    public CountrySetupCacheFactory(IkeaCacheFactory ikeaCacheFactory){
        notNull(ikeaCacheFactory);
        this.ikeaCacheFactory = ikeaCacheFactory;
    }

    @SuppressWarnings("unchecked")
    public CountrySetupCacheImpl build() {
        // Normal usage of the IkeaCacheFactory
        CountrySetupCacheImpl cache = (CountrySetupCacheImpl)ikeaCacheFactory.getCache(CountrySetupCacheImpl.class.getName(), null);
        // Followed by custom wiring, impossible to achieve with Spring
        cache.setBefFactory(befFactory);
        return cache;
    }

	//@Override
	public void afterPropertiesSet() throws Exception {
		notNull(befFactory);		
	}


}