package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;


@Component
public interface BecReservedCardHistory {

	public BecReservedCardHistory init(long pTransactionNo);
	/**
	 * @param pTransactionEnvironment
	 * @return
	 */
	public BecReservedCardHistory init(ReservedCardHistory pReservedCardHistory, BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);
	
	public BecReservedCardHistory init(Card pCard, Amount pAmount, BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment);

	public void createReservedTransaction(VoRequestAmount pVoRequestAmount,
			BigDecimal pTransactionBalanceChange,
			BigDecimal pCardBalanceChange,
			boolean pInsufficientAmount, String pCardNumberString, BigDecimal pRate) throws ValueMissingException;
	
	/**
	 * Cancels the current transactions
	 * 
	 * @throws ValueMissingException
	 */
	public void cancelReservedCardHistorys()
		throws ValueMissingException, AmountException;
	
	public void cancelTransaction() throws ValueMissingException;
	
	public Card createVoidAuthorizeRedeemTransaction(String pReference, String pSourceSystem,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment, boolean pWaitingAck, boolean pManual)throws ValueMissingException, TransactionException;
}
