//package com.ikea.ebccardpay1.cardpayment.utils;
//
//import com.ikea.ebcframework.exception.IkeaException;
//
//public class UtilsFactorySingleton {
//	protected static UtilsFactory sInstance;
//
//	/**
//	 * Don't construct - it is a singleton.
//	 */
//	private UtilsFactorySingleton() {
//	}
//
//	/**
//	 *
//	 * @return
//	 */
//	synchronized public static UtilsFactory getInstance()
//		throws IkeaException {
//		if (sInstance == null) {
//			throw new IllegalStateException("Should have been initiated by Spring Framework");
//		}
//
//		return sInstance;
//	}
//
//	/**
//	 * Use this setter before the first invocation of the getter
//	 * to prevent the creation of a default instance.
//	 *
//	 * @param pFactory Null to reset the singleton
//	 */
//	public static void setInstance(UtilsFactory pFactory) {
//		sInstance = pFactory;
//	}
//}
