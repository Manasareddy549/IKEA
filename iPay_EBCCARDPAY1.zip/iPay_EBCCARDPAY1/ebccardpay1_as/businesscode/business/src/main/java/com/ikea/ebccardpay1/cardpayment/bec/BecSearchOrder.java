package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;

import com.ikea.ebccardpay1.cardpayment.exception.NoCardsAttachedException;
import com.ikea.ebccardpay1.cardpayment.exception.WrongOrderException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardEntry;
import com.ikea.ebccardpay1.cardpayment.vo.VoSearchOrder;

public interface BecSearchOrder {
	
	List<VoCardEntry> searchOrder(VoSearchOrder pVoSearchOrder) throws WrongOrderException, NoCardsAttachedException;
}
