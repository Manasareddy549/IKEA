/*
 * Created on 2007-apr-13
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefBonus;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationException;
import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.common.TimeSource;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import org.springframework.beans.factory.annotation.Autowired;
import static org.apache.commons.lang.Validate.notNull;
/**
 * @author anms
 *
 */
public class BecBonusImpl implements BecBonus {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecBonusImpl.class);

	// Dependencies injected at creation of this BEC
	private BefBonus mBefBonus;
	private BecFactory mBecFactory;
	private UtilsFactory mUtilsFactory;
	private TimeSource mTimeSource;
	private BefAmount mBefAmount;

	BusinessUnitEnvironment mBusinessUnitEnvironment = null;

	private Bonus mBonus = null;
	private BecCard mBecCard = null;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

    @Autowired
    private BsContext mBsContext;

	/**
	 *  
	 * 
	 */
	public BecBonusImpl(
		BecFactory pBecFactory,
		UtilsFactory pUtilsFactory,
		BefBonus pBefBonus,
		TimeSource pTimeSource,
		BefAmount pBefAmount, BsContext pBsContext) {
		super();

		mBefBonus = pBefBonus;
		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
		mTimeSource = pTimeSource;
		mBefAmount = pBefAmount;
		mBsContext = pBsContext;
	}
	
	void validate() {
		notNull(mBefBonus);
		notNull(mBecFactory);
		notNull(mUtilsFactory);
		notNull(mTimeSource);
		notNull(mBefAmount);
		notNull(mBsContext);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init()
	 */
	public BecBonus init(
		String pCardNumberString,
		BusinessUnitEnvironment pBusinessUnitEnvironment)
		throws ValueMissingException, IkeaException, CardPayException {
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);
		mBecCard =
			mBecFactory.createBecCard().init(mBusinessUnitEnvironment, vTransactionEnvironment);
		mBecCard.findCard(pCardNumberString);

		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init(com.ikea.ebccardpay1.cardpayment.be.Bonus)
	 */
	public BecBonus init(Bonus pBonus) {
		mBonus = pBonus;
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init(long)
	 */
	public BecBonus init(long pBonusId) {
		mBonus = mBefBonus.findByPrimaryKey(pBonusId);

		mBusinessUnitEnvironment =
			mUtilsFactory.createBusinessUnitEnvironment(
				mBonus.getAmount().getBuType(),
				mBonus.getAmount().getBuCode());

		mBecCard =
			mBecFactory.createBecCard().init(mBonus.getAmount().getCard());

		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init(com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment)
	 */
	public BecBonus init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/*
	 * 
	 */
	public void createBonus(VoBonusOnCard pVoBonusOnCard)
		throws BonusCodeException, ValueMissingException, IkeaException {

		mBonus = mBefBonus.create();
		mBonus.setCountryCode(countryCodeForUser());

		mBonus.setBonusAmount(pVoBonusOnCard.getAmount());
		mBonus.setCurrencyCode(pVoBonusOnCard.getCurrencyCode());
		mBonus.setAmountType(pVoBonusOnCard.getAmountType());

		if (pVoBonusOnCard.getVoBonusCodeBriefRef() == null) {
			throw new BonusCodeException("Missing bonus code for bonus on card");
		}

		// Get the bonus code and connect it (use set to avoid updating BonusCode table).
		BecBonusCode vBecBonusCode =
			mBecFactory.createBecBonusCode().init(
				pVoBonusOnCard.getVoBonusCodeBriefRef().getBonusCodeId());
		mBonus.setBonusCode(vBecBonusCode.getBonusCode());
		mBonus.setReasonCodeId(pVoBonusOnCard.getReasonCode());

		mBefBonus.save(mBonus);
	}

	/*
	 * 
	 */
	public Bonus getBonus() {
		return mBonus;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#loadBonus(com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard)
	 */
	public void loadBonus()
		throws ValueMissingException, IkeaException, CardPayException {

		requireBonus();
		requireBecCard();

		mCategory.info(
			"Loading bonus of "
				+ mBonus.getAmount()
				+ " "
				+ mBonus.getCurrencyCode());
		

		mBecCard.loadBonus(mBonus);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#authorize()
	 */
	public void authorize()
		throws
			ValueMissingException,
			AuthorizationException,
			FourEyesException,
			TransactionException {

		requireBonus();
		requireBusinessUnitEnvironment();
		requireBecCard();

		mCategory.info(
			"Authorizing bonus of "
				+ mBonus.getBonusAmount()
				+ " "
				+ mBonus.getCurrencyCode()
				+ " on bonus id "
				+ mBonus.getBonusId());

		IkeaUserProfile vIkeaUserProfile =
			mBsContext.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new AuthorizationException("User Profile could not be found.");
		}
		String VUserId = vIkeaUserProfile.getUID().toLowerCase();


		// The same person can not load AND authorize a bonus
		if (mBonus.getCreatedBy() != null && VUserId.equals(mBonus.getCreatedBy().toLowerCase())) {
			throw new FourEyesException("The same user can not both load (initiate) and authorize the bonus.");
		}
		if (mBonus.getUpdatedBy() != null && VUserId.equals(mBonus.getUpdatedBy().toLowerCase())) {
			throw new FourEyesException("The same user can not both load (edit) and authorize the bonus.");
		}

		if (mBonus.getAuthorizedDateTime() != null) {
			throw new AuthorizationException(
				"The bonus is already authorized by '"
					+ mBonus.getAuthorizedBy()
					+ "'.");
		}

		mBonus.setAuthorizedDateTime(mTimeSource.currentDate());
		mBonus.setAuthorizedBy(VUserId);

		// Create transaction enviroment
		TransactionEnvironment vTransactionEnvironment =
			mUtilsFactory.createTransactionEnvironment(
				Constants.SOURCE_SYSTEM_CONSTANT_IPAY,
				null);

		// Create and initialize transaction
		BecTransaction vBecTransaction = mBecFactory.createBecTransaction();
		vBecTransaction.init(
			mBecCard.getCard(),
			mBonus.getAmount(),
			mBusinessUnitEnvironment,
			vTransactionEnvironment);

		vBecTransaction.createBonusLoadTransaction(mBonus);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#getVoBonusOnCard()
	 */
	public VoBonusOnCard getVoBonusOnCard() throws ValueMissingException {

		requireBonus();

		if (mBonus.isBusinessEntityDeleted()) {
			return null;
		}

		VoBonusOnCard vVoBonusOnCard = new VoBonusOnCard();

		ValueObjects.assignToValueObject(vVoBonusOnCard, mBonus);
		vVoBonusOnCard.setAmount(mBonus.getBonusAmount());
		if (mBonus.getAmount() != null) {
			vVoBonusOnCard.setBuType(mBonus.getAmount().getBuType());
			vVoBonusOnCard.setBuCode(mBonus.getAmount().getBuCode());

			if (mBonus.getAmount().getCard() != null) {

				BecCardNumber vBecCardNumber =
					mBecFactory.createBecCardNumber();

				vVoBonusOnCard.setCardNumberString(
					vBecCardNumber.composeCardNumberString(
						mBonus.getAmount().getCard().getCardNumber()));
			}
		}
		if (mBonus.getBonusCode() != null) {
			VoBonusCodeBriefRef vVoBonusCodeBriefRef =
				new VoBonusCodeBriefRef();
			ValueObjects.assignToValueObject(
				vVoBonusCodeBriefRef,
				mBonus.getBonusCode());
			vVoBonusOnCard.setVoBonusCodeBriefRef(vVoBonusCodeBriefRef);
		}

		return vVoBonusOnCard;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#getVoBonus(com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch)
	 */
	public VoBonusComplete getVoBonus(VoBonusSearch pVoBonusSearch)
		throws ValueMissingException {
		requireBonus();

		if (mBonus.isBusinessEntityDeleted()) {
			return null;
		}

		VoBonusComplete vVoBonusComplete = new VoBonusComplete();
		ValueObjects.assignToValueObject(vVoBonusComplete, mBonus);
		mCategory.debug(
			"Added bonus complete "
				+ vVoBonusComplete.getBonusId()
				+ " "
				+ vVoBonusComplete.getBuCode());

		Map<BigDecimal,BigDecimal> vMap = mBefAmount.usageByBonus(mBonus);

		vVoBonusComplete.setUsageAmount(vMap.get("usageAmount"));
		vVoBonusComplete.setTotalAmount(vMap.get("totalAmount"));

		mCategory.debug("UsageAmount:" + vMap.get("usageAmount"));
		mCategory.debug("TotalAmount:" + vMap.get("totalAmount"));

		return vVoBonusComplete;
	}

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 */
	protected String countryCodeForUser()
		throws ValueMissingException, IkeaException {

		if (mUserEnvironment == null) {
			throw new ValueMissingException("Tried to use BecBonus without required UserEnvironment.");
		}

		return mUserEnvironment.getCountryCode();
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBonus() throws ValueMissingException {
		if (mBonus == null)
			throw new ValueMissingException("Tried to use BecBonus without required Bonus.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBusinessUnitEnvironment()
		throws ValueMissingException {
		if (mBusinessUnitEnvironment == null)
			throw new ValueMissingException("Tried to use BecBonus without required BusinessUnitEnvironment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBecCard() throws ValueMissingException {
		if (mBecCard == null)
			throw new ValueMissingException("Tried to use BecBonus without required BecCard.");
	}

}
