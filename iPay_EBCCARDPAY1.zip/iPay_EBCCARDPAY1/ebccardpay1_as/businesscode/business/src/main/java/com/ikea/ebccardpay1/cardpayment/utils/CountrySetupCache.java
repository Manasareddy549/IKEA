/*
 * Created on 2007-apr-26
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;

/**
 * @author anms
 *
 */
public interface CountrySetupCache {

	/**
	 * 
	 * @param pCountryCode
	 * @param pCardType
	 * @return null if not found
	 * @throws CountrySetupException
	 */
	public Integer fetch(String pCountryCode, String pCardType)
		throws CountrySetupException;

	/**
	 * 
	 *
	 */
	public void reload();
}
