/*
 * Created on 2007-apr-17
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.monitor.EbcMonitor;
import com.ikea.ebcframework.spring.BeanFactory;

/**
 * @author anms
 *
 */
public class AlertsImpl implements Alerts {

	private final static Logger mCategory =
		LoggerFactory.getLogger(AlertsImpl.class);

    private EbcMonitor ebcMonitor = BeanFactory.getEbcMonitor();
	/**
	 * 
	 */
	public AlertsImpl() {
		super();
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.Alerts#sendBuConfigurationAlert(java.lang.String)
	 */
	public void sendBuConfigurationAlert(String pMessage)
		throws IkeaException {

		mCategory.info(
			"Sending BU config alert with message '" + pMessage + "'.");

		ebcMonitor.alert(
                "EBCCARDPAY1_BU_CONFIG",
                "<Message>" + pMessage + "</Message>");
	}
}
