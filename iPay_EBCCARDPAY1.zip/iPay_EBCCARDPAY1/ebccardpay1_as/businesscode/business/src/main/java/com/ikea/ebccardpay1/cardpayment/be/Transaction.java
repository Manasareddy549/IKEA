/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Transaction extends BusinessEntity {
	/**										
	 * Storage: TRANSACTION_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mTransactionId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private Card mCard;
	private Amount mAmount;
	private Campaign mCampaign;
	private MassLoad mMassLoad;
	private ReasonCode mReasonCodes;

	/**										
	 * Data								
	 */										
	private String mReference;
	private java.math.BigDecimal mBalanceChange;
	private java.math.BigDecimal mRequestedAmount;
	private String mRequestedCurrencyCode;
	private String mFinancialType;
	private String mTransactionType;
	private String mSourceSystem;
	private java.util.Date mTransmissionDateTime;
	private boolean mCancelled;
	private String mBuType;
	private String mBuCode;
	private String mCountryCode;
	private String mSwiped;
	private String mEmployee;
	private long mTransactionNo;
	private boolean mInsufficientAmount;
	private boolean mCrossBorder;
	private boolean mCrossCurrency;
	private String mSalesDay;
	private java.math.BigDecimal mCardBalanceChange;
	private java.math.BigDecimal mTotalAmount;
	private String mPointOfSale;
	private String mReceipt;
	private long mVoidedTransactionNo;

	/**											
	 * @return Returns the transactionId.													
	 */											
	public long getTransactionId() {
		return mTransactionId;
	}
	/**
	 * @param pTransactionId The transactionId to set.
	 */
	public void setTransactionId(long pTransactionId) {
		mTransactionId = pTransactionId;
	}

	/**											
	 * @return Returns the reference.													
	 */											
	public String getReference() {
		return mReference;
	}
	/**
	 * @param pReference The reference to set.
	 */
	public void setReference(String pReference) {
		mReference = pReference;
	}

	/**											
	 * @return Returns the balanceChange.													
	 */											
	public java.math.BigDecimal getBalanceChange() {
		return mBalanceChange;
	}
	/**
	 * @param pBalanceChange The balanceChange to set.
	 */
	public void setBalanceChange(java.math.BigDecimal pBalanceChange) {
		mBalanceChange = pBalanceChange;
	}

	/**											
	 * @return Returns the requestedAmount.													
	 */											
	public java.math.BigDecimal getRequestedAmount() {
		return mRequestedAmount;
	}
	/**
	 * @param pRequestedAmount The requestedAmount to set.
	 */
	public void setRequestedAmount(java.math.BigDecimal pRequestedAmount) {
		mRequestedAmount = pRequestedAmount;
	}

	/**											
	 * @return Returns the requestedCurrencyCode.													
	 */											
	public String getRequestedCurrencyCode() {
		return mRequestedCurrencyCode;
	}
	/**
	 * @param pRequestedCurrencyCode The requestedCurrencyCode to set.
	 */
	public void setRequestedCurrencyCode(String pRequestedCurrencyCode) {
		mRequestedCurrencyCode = pRequestedCurrencyCode;
	}

	/**											
	 * @return Returns the financialType.													
	 */											
	public String getFinancialType() {
		return mFinancialType;
	}
	/**
	 * @param pFinancialType The financialType to set.
	 */
	public void setFinancialType(String pFinancialType) {
		mFinancialType = pFinancialType;
	}

	/**											
	 * @return Returns the transactionType.													
	 */											
	public String getTransactionType() {
		return mTransactionType;
	}
	/**
	 * @param pTransactionType The transactionType to set.
	 */
	public void setTransactionType(String pTransactionType) {
		mTransactionType = pTransactionType;
	}

	/**											
	 * @return Returns the sourceSystem.													
	 */											
	public String getSourceSystem() {
		return mSourceSystem;
	}
	/**
	 * @param pSourceSystem The sourceSystem to set.
	 */
	public void setSourceSystem(String pSourceSystem) {
		mSourceSystem = pSourceSystem;
	}

	/**											
	 * @return Returns the transmissionDateTime.													
	 */											
	public java.util.Date getTransmissionDateTime() {
		return mTransmissionDateTime;
	}
	/**
	 * @param pTransmissionDateTime The transmissionDateTime to set.
	 */
	public void setTransmissionDateTime(java.util.Date pTransmissionDateTime) {
		mTransmissionDateTime = pTransmissionDateTime;
	}

	/**											
	 * @return Returns the cancelled.													
	 */											
	public boolean getCancelled() {
		return mCancelled;
	}
	/**
	 * @param pCancelled The cancelled to set.
	 */
	public void setCancelled(boolean pCancelled) {
		mCancelled = pCancelled;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the swiped.													
	 */											
	public String getSwiped() {
		return mSwiped;
	}
	/**
	 * @param pSwiped The swiped to set.
	 */
	public void setSwiped(String pSwiped) {
		mSwiped = pSwiped;
	}

	/**											
	 * @return Returns the employee.													
	 */											
	public String getEmployee() {
		return mEmployee;
	}
	/**
	 * @param pEmployee The employee to set.
	 */
	public void setEmployee(String pEmployee) {
		mEmployee = pEmployee;
	}

	/**											
	 * @return Returns the transactionNo.													
	 */											
	public long getTransactionNo() {
		return mTransactionNo;
	}
	/**
	 * @param pTransactionNo The transactionNo to set.
	 */
	public void setTransactionNo(long pTransactionNo) {
		mTransactionNo = pTransactionNo;
	}

	/**											
	 * @return Returns the insufficientAmount.													
	 */											
	public boolean getInsufficientAmount() {
		return mInsufficientAmount;
	}
	/**
	 * @param pInsufficientAmount The insufficientAmount to set.
	 */
	public void setInsufficientAmount(boolean pInsufficientAmount) {
		mInsufficientAmount = pInsufficientAmount;
	}

	/**											
	 * @return Returns the crossBorder.													
	 */											
	public boolean getCrossBorder() {
		return mCrossBorder;
	}
	/**
	 * @param pCrossBorder The crossBorder to set.
	 */
	public void setCrossBorder(boolean pCrossBorder) {
		mCrossBorder = pCrossBorder;
	}

	/**											
	 * @return Returns the crossCurrency.													
	 */											
	public boolean getCrossCurrency() {
		return mCrossCurrency;
	}
	/**
	 * @param pCrossCurrency The crossCurrency to set.
	 */
	public void setCrossCurrency(boolean pCrossCurrency) {
		mCrossCurrency = pCrossCurrency;
	}

	/**											
	 * @return Returns the salesDay.													
	 */											
	public String getSalesDay() {
		return mSalesDay;
	}
	/**
	 * @param pSalesDay The salesDay to set.
	 */
	public void setSalesDay(String pSalesDay) {
		mSalesDay = pSalesDay;
	}

	/**											
	 * @return Returns the cardBalanceChange.													
	 */											
	public java.math.BigDecimal getCardBalanceChange() {
		return mCardBalanceChange;
	}
	/**
	 * @param pCardBalanceChange The cardBalanceChange to set.
	 */
	public void setCardBalanceChange(java.math.BigDecimal pCardBalanceChange) {
		mCardBalanceChange = pCardBalanceChange;
	}

	/**											
	 * @return Returns the totalAmount.													
	 */											
	public java.math.BigDecimal getTotalAmount() {
		return mTotalAmount;
	}
	/**
	 * @param pTotalAmount The totalAmount to set.
	 */
	public void setTotalAmount(java.math.BigDecimal pTotalAmount) {
		mTotalAmount = pTotalAmount;
	}

	/**											
	 * @return Returns the pointOfSale.													
	 */											
	public String getPointOfSale() {
		return mPointOfSale;
	}
	/**
	 * @param pPointOfSale The pointOfSale to set.
	 */
	public void setPointOfSale(String pPointOfSale) {
		mPointOfSale = pPointOfSale;
	}

	/**											
	 * @return Returns the receipt.													
	 */											
	public String getReceipt() {
		return mReceipt;
	}
	/**
	 * @param pReceipt The receipt to set.
	 */
	public void setReceipt(String pReceipt) {
		mReceipt = pReceipt;
	}

	/**											
	 * @return Returns the voidedTransactionNo.													
	 */											
	public long getVoidedTransactionNo() {
		return mVoidedTransactionNo;
	}
	/**
	 * @param pVoidedTransactionNo The voidedTransactionNo to set.
	 */
	public void setVoidedTransactionNo(long pVoidedTransactionNo) {
		mVoidedTransactionNo = pVoidedTransactionNo;
	}

	/**											
	 * @return Returns the card.													
	 */											
	public Card getCard() {
		return mCard;
	}
	/**
	 * @param pCard The card to set.
	 */
	public void setCard(Card pCard) {
		mCard = pCard;
	}

	/**											
	 * @return Returns the amount.													
	 */											
	public Amount getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The amount to set.
	 */
	public void setAmount(Amount pAmount) {
		mAmount = pAmount;
	}

	/**											
	 * @return Returns the campaign.													
	 */											
	public Campaign getCampaign() {
		return mCampaign;
	}
	/**
	 * @param pCampaign The campaign to set.
	 */
	public void setCampaign(Campaign pCampaign) {
		mCampaign = pCampaign;
	}

	/**											
	 * @return Returns the massLoad.													
	 */											
	public MassLoad getMassLoad() {
		return mMassLoad;
	}
	/**
	 * @param pMassLoad The massLoad to set.
	 */
	public void setMassLoad(MassLoad pMassLoad) {
		mMassLoad = pMassLoad;
	}

	/**
	 * Connect Card.
	 * @param pCard
	 */
	public void connectCard(Card pCard) {
		setCard(pCard);
		if(pCard != null) {
			pCard.getTransactions().add(this);
		}
	}

	/**
	 * Disconnect Card.
	 */
	public void disconnectCard() {
		if(getCard() != null) {
			getCard().getTransactions().remove(this);
		}
		setCard(null);
	}

	/**
	 * Connect Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		setAmount(pAmount);
		if(pAmount != null) {
			pAmount.getTransactions().add(this);
		}
	}

	/**
	 * Disconnect Amount.
	 */
	public void disconnectAmount() {
		if(getAmount() != null) {
			getAmount().getTransactions().remove(this);
		}
		setAmount(null);
	}

	/**
	 * Connect Campaign.
	 * @param pCampaign
	 */
	public void connectCampaign(Campaign pCampaign) {
		setCampaign(pCampaign);
		if(pCampaign != null) {
			pCampaign.getTransactions().add(this);
		}
	}

	/**
	 * Disconnect Campaign.
	 */
	public void disconnectCampaign() {
		if(getCampaign() != null) {
			getCampaign().getTransactions().remove(this);
		}
		setCampaign(null);
	}

	/**
	 * Connect MassLoad.
	 * @param pMassLoad
	 */
	public void connectMassLoad(MassLoad pMassLoad) {
		setMassLoad(pMassLoad);
		if(pMassLoad != null) {
			pMassLoad.getTransactions().add(this);
		}
	}

	/**
	 * Disconnect MassLoad.
	 */
	public void disconnectMassLoad() {
		if(getMassLoad() != null) {
			getMassLoad().getTransactions().remove(this);
		}
		setMassLoad(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}
	public ReasonCode getReasonCodes() {
		return mReasonCodes;
	}
	public void setReasonCodes(ReasonCode mReasonCodes) {
		this.mReasonCodes = mReasonCodes;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mTransactionId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("transactionId", CodeGeneration.toObject(mTransactionId));
		vMap.put("reference", CodeGeneration.toObject(mReference));
		vMap.put("balanceChange", CodeGeneration.toObject(mBalanceChange));
		vMap.put("requestedAmount", CodeGeneration.toObject(mRequestedAmount));
		vMap.put("requestedCurrencyCode", CodeGeneration.toObject(mRequestedCurrencyCode));
		vMap.put("financialType", CodeGeneration.toObject(mFinancialType));
		vMap.put("transactionType", CodeGeneration.toObject(mTransactionType));
		vMap.put("sourceSystem", CodeGeneration.toObject(mSourceSystem));
		vMap.put("transmissionDateTime", CodeGeneration.toObject(mTransmissionDateTime));
		vMap.put("cancelled", CodeGeneration.toObject(mCancelled));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("swiped", CodeGeneration.toObject(mSwiped));
		vMap.put("employee", CodeGeneration.toObject(mEmployee));
		vMap.put("transactionNo", CodeGeneration.toObject(mTransactionNo));
		vMap.put("insufficientAmount", CodeGeneration.toObject(mInsufficientAmount));
		vMap.put("crossBorder", CodeGeneration.toObject(mCrossBorder));
		vMap.put("crossCurrency", CodeGeneration.toObject(mCrossCurrency));
		vMap.put("salesDay", CodeGeneration.toObject(mSalesDay));
		vMap.put("cardBalanceChange", CodeGeneration.toObject(mCardBalanceChange));
		vMap.put("totalAmount", CodeGeneration.toObject(mTotalAmount));
		vMap.put("pointOfSale", CodeGeneration.toObject(mPointOfSale));
		vMap.put("receipt", CodeGeneration.toObject(mReceipt));
		vMap.put("voidedTransactionNo", CodeGeneration.toObject(mVoidedTransactionNo));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("transactionId")) mTransactionId = CodeGeneration.objectTolong(pMap.get("transactionId"));
		if(pMap.containsKey("reference")) mReference = CodeGeneration.objectToString(pMap.get("reference"));
		if(pMap.containsKey("balanceChange")) mBalanceChange = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("balanceChange"));
		if(pMap.containsKey("requestedAmount")) mRequestedAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("requestedAmount"));
		if(pMap.containsKey("requestedCurrencyCode")) mRequestedCurrencyCode = CodeGeneration.objectToString(pMap.get("requestedCurrencyCode"));
		if(pMap.containsKey("financialType")) mFinancialType = CodeGeneration.objectToString(pMap.get("financialType"));
		if(pMap.containsKey("transactionType")) mTransactionType = CodeGeneration.objectToString(pMap.get("transactionType"));
		if(pMap.containsKey("sourceSystem")) mSourceSystem = CodeGeneration.objectToString(pMap.get("sourceSystem"));
		if(pMap.containsKey("transmissionDateTime")) mTransmissionDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("transmissionDateTime"));
		if(pMap.containsKey("cancelled")) mCancelled = CodeGeneration.objectToboolean(pMap.get("cancelled"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("swiped")) mSwiped = CodeGeneration.objectToString(pMap.get("swiped"));
		if(pMap.containsKey("employee")) mEmployee = CodeGeneration.objectToString(pMap.get("employee"));
		if(pMap.containsKey("transactionNo")) mTransactionNo = CodeGeneration.objectTolong(pMap.get("transactionNo"));
		if(pMap.containsKey("insufficientAmount")) mInsufficientAmount = CodeGeneration.objectToboolean(pMap.get("insufficientAmount"));
		if(pMap.containsKey("crossBorder")) mCrossBorder = CodeGeneration.objectToboolean(pMap.get("crossBorder"));
		if(pMap.containsKey("crossCurrency")) mCrossCurrency = CodeGeneration.objectToboolean(pMap.get("crossCurrency"));
		if(pMap.containsKey("salesDay")) mSalesDay = CodeGeneration.objectToString(pMap.get("salesDay"));
		if(pMap.containsKey("cardBalanceChange")) mCardBalanceChange = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("cardBalanceChange"));
		if(pMap.containsKey("totalAmount")) mTotalAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("totalAmount"));
		if(pMap.containsKey("pointOfSale")) mPointOfSale = CodeGeneration.objectToString(pMap.get("pointOfSale"));
		if(pMap.containsKey("receipt")) mReceipt = CodeGeneration.objectToString(pMap.get("receipt"));
		if(pMap.containsKey("voidedTransactionNo")) mVoidedTransactionNo = CodeGeneration.objectTolong(pMap.get("voidedTransactionNo"));
	}
	
}
