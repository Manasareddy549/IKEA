package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.be.ExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.be.ExternalTempCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.bef.BefExternalTempCard;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.exception.BlockedCardException;
import com.ikea.ebccardpay1.cardpayment.exception.CardException;
import com.ikea.ebccardpay1.cardpayment.exception.CountrySetupException;
import com.ikea.ebccardpay1.cardpayment.exception.CurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidAmountTypeException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidExternalSourceSystemException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidForeignCardException;
import com.ikea.ebccardpay1.cardpayment.exception.PosDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardSystem;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTemp;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTempOutput;
import com.ikea.ebccardpay1.cardpayment.vo.VoExternalCardTempStatus;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;


public class BecExternalTempCardImpl implements BecExternalTempCard{
	private final static Logger mLog = LoggerFactory.getLogger(BecExternalTempCardImpl.class);

	private BefExternalTempCard mBefExternalTempCard;
	private BefExternalCardSystem mBefExternalCardSystem;
	private BefExternalCard mBefExternalCard;
	private BecFactory mBecFactory;
	private UtilsFactory mUtilsFactory;
	private Units mUnits;
	private Constants mConstants = null;

	// Entities that this BEC operates on
	private ExternalTempCard mExternalTempCard;

	public BecExternalTempCardImpl(
			BefExternalTempCard pBefExternalTempCard,
			BefExternalCardSystem pBefExternalCardSystem,
			BefExternalCard pBefExternalCard,
			BecFactory pBecFactory,
			UtilsFactory pUtilsFactory,
			Units pUnits,
			Constants pConstants) {

		super();

		mBefExternalTempCard = pBefExternalTempCard;
		mBefExternalCardSystem=pBefExternalCardSystem;
		mBefExternalCard=pBefExternalCard;
		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
		mUnits = pUnits;
		mConstants=pConstants;
	}

	void validate() {
		notNull(mBefExternalTempCard);
		notNull(mBefExternalCardSystem);
		notNull(mBefExternalCard);
		notNull(mBecFactory);
		notNull(mUtilsFactory);
		notNull(mUnits);
		notNull(mConstants);
	}


	public BecExternalTempCard init(ExternalTempCard pExternalTempCard) {

		mExternalTempCard = pExternalTempCard;
		return this;
	}

	//@Override
	public List<VoExternalCardTempOutput> importExternalCards(
			List<VoExternalCardTemp> pVoExternalCardTempList,VoExternalCardTempStatus pVoExternalCardTempStatus) {
		// TODO Auto-generated method stub
		mLog.info("Starting External card Service Upload");
		List<VoExternalCardTempOutput> mVoExternalCardTempOutput= new ArrayList<VoExternalCardTempOutput>();

		for(VoExternalCardTemp mpVoExternalCardTemp:pVoExternalCardTempList)
		{
			mVoExternalCardTempOutput.addAll(createOrUpdate(mpVoExternalCardTemp,pVoExternalCardTempStatus));
		}

		mLog.info("External card Service Upload ended Succesfully");

		return mVoExternalCardTempOutput;
	}

	private List<VoExternalCardTempOutput> createOrUpdate(VoExternalCardTemp mpVoExternalCardTemp,VoExternalCardTempStatus mVoExternalCardTempStatus)
	{
		mLog.debug("Create or Update external cards");

		List<ExternalTempCard> mExternalTempCardList= mBefExternalTempCard.findByCardNumberString(mpVoExternalCardTemp.getCardNumberString());

		List<VoExternalCardTempOutput> mVoExternalCardTempOutputList= new ArrayList<VoExternalCardTempOutput>();
		if(mExternalTempCardList.size()>0)
		{
			for(ExternalTempCard mExternalTempCard:mExternalTempCardList)
			{
				ValueObjects.assignToBusinessEntity(mExternalTempCard,mpVoExternalCardTemp);
				mExternalTempCard.setStatus(Constants.CARD_STATUS_CORRECTED);
				mExternalTempCard.setErrorMessage(null);
				mBefExternalTempCard.update(mExternalTempCard);		

				VoExternalCardTempOutput vVoExternalCardTempOutput = new VoExternalCardTempOutput();
				ValueObjects.assignToValueObject(vVoExternalCardTempOutput, mExternalTempCard);

				mVoExternalCardTempOutputList.add(vVoExternalCardTempOutput);
			}
		}
		else{
			ExternalTempCard mExternalTempCard=mBefExternalTempCard.create();
			ValueObjects.assignToBusinessEntity(mExternalTempCard, mpVoExternalCardTemp);
			ValueObjects.assignToBusinessEntity(mExternalTempCard, mVoExternalCardTempStatus);
			mBefExternalTempCard.save(mExternalTempCard);

			VoExternalCardTempOutput vVoExternalCardTempOutput = new VoExternalCardTempOutput();
			ValueObjects.assignToValueObject(vVoExternalCardTempOutput, mExternalTempCard);

			mVoExternalCardTempOutputList.add(vVoExternalCardTempOutput);
		}

		mLog.debug("Create or Update external cards ended ");
		return mVoExternalCardTempOutputList;
	}

	public List<VoExternalCardTempOutput> createCardsAndTransfer(VoExternalCardTempStatus mVoExternalCardTempStatus)
	{

		mLog.info("Start Transferring");
		List<ExternalTempCard> mExternalTempCardList= mBefExternalTempCard.findActiveCardsToTransfer(mVoExternalCardTempStatus.getImportedFileName(), Integer.parseInt(mVoExternalCardTempStatus.getErrorMessage()));

		List<VoExternalCardTempOutput> mVoExternalCardTempOutput= new ArrayList<VoExternalCardTempOutput>();

		if(mExternalTempCardList.size()>0)
		{
			for(ExternalTempCard mExternalTempCard:mExternalTempCardList)
			{
				ExternalCardSystem mExternalCardSystem = mBefExternalCardSystem.findByNameOnly(mExternalTempCard.getExternalCardSystem());

				if(mExternalCardSystem !=null)
				{
					try{
						createOrUpdateExternalCard(mExternalTempCard,mExternalCardSystem);
						mExternalTempCard.setErrorMessage(null);
						mExternalTempCard.setStatus(Constants.CARD_STATUS_TRANSFER);
						mBefExternalTempCard.update(mExternalTempCard);

						VoExternalCardTempOutput vVoExternalCardTempOutput = new VoExternalCardTempOutput();
						ValueObjects.assignToValueObject(vVoExternalCardTempOutput, mExternalTempCard);
						mVoExternalCardTempOutput.add(vVoExternalCardTempOutput);
					}
					catch(Exception e)
					{
						mExternalTempCard.setErrorMessage(e.getMessage());
						mExternalTempCard.setStatus(Constants.CARD_STATUS_FAILED);
						mBefExternalTempCard.update(mExternalTempCard);

						VoExternalCardTempOutput vVoExternalCardTempOutput = new VoExternalCardTempOutput();
						ValueObjects.assignToValueObject(vVoExternalCardTempOutput, mExternalTempCard);
						mVoExternalCardTempOutput.add(vVoExternalCardTempOutput);
					}
				}
				else{
					mLog.debug("No External source system found by the name: "+mExternalTempCard.getExternalCardSystem());
				}
			}			
		}
		else{
			mLog.info("No Active Cards found for the provided File Name");
		}
		mLog.info("Card Transferring Ended");
		return mVoExternalCardTempOutput;
	}

	//update card status to failed to stop transfer.
	public List<VoExternalCardTempOutput> updateCardStatus(VoExternalCardTempStatus mVoExternalCardTempStatus)
	{
		List<ExternalTempCard> mExternalTempCardList= mBefExternalTempCard.findByFileName(mVoExternalCardTempStatus.getImportedFileName());

		List<VoExternalCardTempOutput> mVoExternalCardTempOutputList= new ArrayList<VoExternalCardTempOutput>();
		for(ExternalTempCard mExternalTempCard:mExternalTempCardList)
		{
			mExternalTempCard.setStatus(Constants.CARD_STATUS_FAILED);
			mBefExternalTempCard.update(mExternalTempCard);
			VoExternalCardTempOutput vVoExternalCardTempOutput = new VoExternalCardTempOutput();
			ValueObjects.assignToValueObject(vVoExternalCardTempOutput, mExternalTempCard);
			mVoExternalCardTempOutputList.add(vVoExternalCardTempOutput);
		}

		return mVoExternalCardTempOutputList;
	}

	//@Override
	public boolean createOrUpdateSourceSystem(
			VoExternalCardSystem mVoExternalCardSystem) throws InvalidExternalSourceSystemException, InvalidCardNumberException, InvalidAmountTypeException {

		//ExternalCardSystem mExternalCardSystem=mBefExternalCardSystem.create();

		ExternalCardSystem mExternalCardSystem =
				mBefExternalCardSystem.findByNameOnly(
						mVoExternalCardSystem.getName());

		if(mExternalCardSystem!=null)
		{
			VoExternalCardSystem pVoExternalCardSystem=new VoExternalCardSystem();
			ValueObjects.assignToValueObject(pVoExternalCardSystem, mExternalCardSystem);

			if(mVoExternalCardSystem.getCountryCode().equalsIgnoreCase(pVoExternalCardSystem.getCountryCode()) &&
					mVoExternalCardSystem.getAmountType().equalsIgnoreCase(pVoExternalCardSystem.getAmountType()) &&
					mVoExternalCardSystem.getCardNumberPattern().equalsIgnoreCase(pVoExternalCardSystem.getCardNumberPattern()) &&
					mVoExternalCardSystem.getCardNumberPattern().equalsIgnoreCase(pVoExternalCardSystem.getCardNumberPattern()) &&
					mVoExternalCardSystem.getIssuer().equalsIgnoreCase(pVoExternalCardSystem.getIssuer()) &&
					mVoExternalCardSystem.getCardTypeDigit()==pVoExternalCardSystem.getCardTypeDigit())
			{
				if(pVoExternalCardSystem.getInitialAccountNumber()!=mVoExternalCardSystem.getInitialAccountNumber())
				{
					throw new InvalidExternalSourceSystemException("Initial Account Number is not same as provided before for source system "+mVoExternalCardSystem.getName());
				}
				if(mVoExternalCardSystem.getMaxAccountNumber()<pVoExternalCardSystem.getMaxAccountNumber())
				{
					throw new InvalidExternalSourceSystemException("Maximum Account Number is less than the value provided before for source system "+mVoExternalCardSystem.getName());

				}

				ValueObjects.assignToBusinessEntity(mExternalCardSystem, mVoExternalCardSystem);
				mBefExternalCardSystem.update(mExternalCardSystem);

			}
			else{
				throw new InvalidExternalSourceSystemException("External source system information does not match with configured for source system "+mVoExternalCardSystem.getName());
			}
			ValueObjects.assignToBusinessEntity(mExternalCardSystem, mVoExternalCardSystem);
			mBefExternalCardSystem.update(mExternalCardSystem);
			return true;
		}
		else{

			validateValues(mVoExternalCardSystem);

			mExternalCardSystem=mBefExternalCardSystem.create();
			ValueObjects.assignToBusinessEntity(mExternalCardSystem, mVoExternalCardSystem);
			mExternalCardSystem.setCurrentAccountNumber(0);
			mBefExternalCardSystem.save(mExternalCardSystem);
			return true;
		}
	}
	protected void validateValues(VoExternalCardSystem pVoExternalCardSystem) throws InvalidCardNumberException, InvalidAmountTypeException
	{
		BecCardNumber vBecCardNumber = mBecFactory.createBecCardNumber();

		// Check issuer
		vBecCardNumber.checkValidIssuer(pVoExternalCardSystem.getIssuer());

		// Check card type
		vBecCardNumber.checkCardTypeDigit(
				pVoExternalCardSystem.getCardTypeDigit());

		// Check amount type
		try {
			mConstants.checkValidAmountType(
					pVoExternalCardSystem.getAmountType());
		} catch (AmountTypeNotSupportedException e) {
			throw new InvalidAmountTypeException(e.toString());
		}

		// Check country code
		mUnits.checkValidCountryCode(pVoExternalCardSystem.getCountryCode());

		// Check regexp pattern
		Pattern.compile(pVoExternalCardSystem.getCardNumberPattern());

		// Check max > initial
		if (pVoExternalCardSystem.getInitialAccountNumber()
				> pVoExternalCardSystem.getMaxAccountNumber()) {
			throw new InvalidCardNumberException("Initial account number must be less than max account number");
		}
	}

	protected void createOrUpdateExternalCard(ExternalTempCard pExternalTempCard,ExternalCardSystem pExternalCardSystem) 
			throws ValueMissingException, IkeaException, BlockedCardException, CurrencyException, CardException, AmountException, ReferenceCheckException, InvalidForeignCardException, CountrySetupException, PosDateException
			{
		List<ExternalCard> mExternalCardList=mBefExternalCard.findByExternal(pExternalTempCard.getCardNumberString(),pExternalCardSystem);

		if(mExternalCardList.size()>0)
		{
			createOnlyTransaction(pExternalTempCard);
		}
		else{
			VoExternalCard vVoExternalCard= new VoExternalCard();
			ValueObjects.assignToValueObject(vVoExternalCard, pExternalTempCard);
			vVoExternalCard.setOriginalBalance(pExternalTempCard.getBalance());
			BecExternalCard vBecExternalCard =
					mBecFactory.createBecExternalCard();
			// Call create method ExternalCard BEC
			vBecExternalCard.createExternalCard(
					vVoExternalCard,
					pExternalCardSystem);
			BecCard vBecCard=mBecFactory.createBecCard();
			Card mExternalNewCard=vBecCard.tryExternalCardNumber(vVoExternalCard.getCardNumberString());
			if(mExternalNewCard==null)
			{
				throw new IkeaException("Card Number and Transaction creation failed for External Card");
			}
		}
			}

	private void createOnlyTransaction(ExternalTempCard pExternalTempCard) throws 
	IkeaException, ValueMissingException, BlockedCardException, CurrencyException, CardException, AmountException, ReferenceCheckException, InvalidForeignCardException, CountrySetupException, PosDateException
	{
		BecCard vBecCard=mBecFactory.createBecCard();
		Card mExternalNewCard=vBecCard.tryExternalCardNumber(pExternalTempCard.getCardNumberString());
		Set<Amount> mAmountSet=mExternalNewCard.getAmounts();
		String mAMountType=null;
		BigDecimal vBalance = new BigDecimal(0.0);
		for(Amount mAmount:mAmountSet)
		{
			vBalance = vBalance.add(mAmount.getCurrentAmount());
			mAMountType=mAmount.getAmountType();
		}

		if(Amounts.isZero(pExternalTempCard.getBalance()))//current amount=zero, redeem all the available amount
		{
			vBecCard=setupBecCard(pExternalTempCard,mExternalNewCard);
			VoRequestAmount mVoRequestAmount= new VoRequestAmount();
			mVoRequestAmount.setRequestAmount(vBalance);
			mVoRequestAmount.setTotalAmount(vBalance);
			mVoRequestAmount.setCurrencyCode(pExternalTempCard.getCurrencyCode());
			VoRedeemAmount vVoRedeemAmount = new VoRedeemAmount();
			vBecCard.redeemAmount(mVoRequestAmount, vVoRedeemAmount, false);
		}

		else if(Amounts.isEqual(pExternalTempCard.getBalance(), vBalance))//current amount= prev balance 
		{
			if(pExternalTempCard.getCurrencyCode().equalsIgnoreCase(mExternalNewCard.getCurrencyCode()))
			{

				//No Operation
			}
		}

		else if(Amounts.isLess(pExternalTempCard.getBalance(), vBalance))//current amount< prev balance 
		{
			vBecCard=setupBecCard(pExternalTempCard,mExternalNewCard);
			VoRequestAmount mVoRequestAmount= new VoRequestAmount();
			BigDecimal vSubBalance = new BigDecimal(0.0);
			if(pExternalTempCard.getCurrencyCode().equalsIgnoreCase(mExternalNewCard.getCurrencyCode()))
			{
				vSubBalance=vSubBalance.add(vBalance);
				vSubBalance=vSubBalance.subtract(pExternalTempCard.getBalance());
				mVoRequestAmount.setRequestAmount(vSubBalance);
				mVoRequestAmount.setTotalAmount(vSubBalance);
				mVoRequestAmount.setCurrencyCode(pExternalTempCard.getCurrencyCode());
				VoRedeemAmount vVoRedeemAmount = new VoRedeemAmount();
				vBecCard.redeemAmount(mVoRequestAmount, vVoRedeemAmount, false);
			}
		}
		else if(Amounts.isGreaterOrEqual(pExternalTempCard.getBalance(), vBalance) &&
				!Amounts.isEqual(pExternalTempCard.getBalance(), vBalance))//current amount> prev balance 
		{

			
			VoRequestAmount mVoRequestAmount= new VoRequestAmount();
			if(pExternalTempCard.getCurrencyCode().equalsIgnoreCase(mExternalNewCard.getCurrencyCode()))
			{
				if(!Amounts.isZero(vBalance))
				{
					vBecCard=setupBecCard(pExternalTempCard,mExternalNewCard);
					mVoRequestAmount.setRequestAmount(vBalance);
					mVoRequestAmount.setTotalAmount(vBalance);
					mVoRequestAmount.setCurrencyCode(mExternalNewCard.getCurrencyCode());
					VoRedeemAmount vVoRedeemAmount = new VoRedeemAmount();
					vBecCard.redeemAmount(mVoRequestAmount, vVoRedeemAmount, false);
				}
				
				//Transaction will be created on same transaction number if transaction environment is not created again.
				vBecCard=setupBecCard(pExternalTempCard,mExternalNewCard);			
				VoLoadAmount mVoLoadAmount= new VoLoadAmount();
				mVoLoadAmount.setLoadAmount(pExternalTempCard.getBalance());
				mVoLoadAmount.setAmountType(mAMountType);
				mVoLoadAmount.setCurrencyCode(pExternalTempCard.getCurrencyCode());
				vBecCard.loadAmount(mVoLoadAmount,0);
			}

		}


	}

	protected BecCard setupBecCard(ExternalTempCard pExternalTempCard,Card pCard) throws ValueMissingException {

		BusinessUnitEnvironment vBusinessUnitEnvironment =
				mUtilsFactory.createBusinessUnitEnvironment(
						pExternalTempCard.getBuType(),
						pExternalTempCard.getBuCode());
		TransactionEnvironment vTransactionEnvironment =
				mUtilsFactory.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_EXTERNAL,
						null);

		BecCard vBecCard=mBecFactory.createBecCard();
		vBecCard.init(
				vBusinessUnitEnvironment,
				vTransactionEnvironment);
		vBecCard.init(pCard);
		return vBecCard;
	}
}


