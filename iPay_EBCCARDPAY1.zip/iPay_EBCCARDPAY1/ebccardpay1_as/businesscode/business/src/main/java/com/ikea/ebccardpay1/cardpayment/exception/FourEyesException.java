/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class FourEyesException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9114782271306309753L;

	public FourEyesException() {
		super();
	}
	public FourEyesException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.FourEyes();
	}
}
