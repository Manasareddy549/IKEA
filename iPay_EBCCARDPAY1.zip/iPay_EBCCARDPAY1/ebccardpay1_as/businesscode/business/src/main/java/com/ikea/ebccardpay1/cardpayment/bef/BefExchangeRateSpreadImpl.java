/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeRateSpread;
import com.ikea.common.TimeSource;

/**
 * @author tpon
 * 
 */
public class BefExchangeRateSpreadImpl extends BefAbstract<ExchangeRateSpread>
		implements BefExchangeRateSpread {

	private final static Logger mLog = LoggerFactory
			.getLogger(BefExchangeRateSpreadImpl.class);

	private ExchangeRateSpread mCurrentSpread = null;
	private long mCurrentSpreadFetchTimestamp = 0;
	private long mCurrentSpreadLifetime = 5000;

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefExchangeRateSpreadImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);

	}

	public ExchangeRateSpread findCurrent() {

		if (mCurrentSpread == null
				|| (mCurrentSpreadFetchTimestamp + mCurrentSpreadLifetime) < System
						.currentTimeMillis()) {
			mLog.debug("Fetching the current spread for exchange rates.");
			List<ExchangeRateSpread> vAll = super.findAll();
			ExchangeRateSpread vCurrent = new ExchangeRateSpread();
			if (vAll.size() == 1) {
				vCurrent = vAll.get(0);
			} else if (vAll.size() > 1) {
				mLog
						.info("More then one EXCHANGE_RATE_SPREAD was found in the database. The most recent one will be picked.");
				Date vNewest = new Date(0);

				for (ExchangeRateSpread exchangeRateSpread : vAll) {
					if (exchangeRateSpread.getCreatedDateTime().after(vNewest)) {
						vNewest = exchangeRateSpread.getCreatedDateTime();
						vCurrent = exchangeRateSpread;
					}
				}
			} else {
				mLog
						.error("No EXCHANGE_RATE_SPREAD was found. Returning ZERO as EXCHANGE_RATE_SPREAD.");
				vCurrent.setExchangeRateSpread(BigDecimal.ZERO);
			}
			mLog.debug("The current spread was: "
					+ vCurrent.getExchangeRateSpread().toString());
			mCurrentSpread = vCurrent;
			mCurrentSpreadFetchTimestamp = System.currentTimeMillis();
		} else if (mLog.isDebugEnabled()) {
			mLog.debug("Using the previously fetched spread for exchange "
					+ "rates since it was feteched less then 10 seconds ago.");
		}
		return mCurrentSpread;

	}

	@Override
	protected Class<ExchangeRateSpread> getBusinessEntityClass() {
		return ExchangeRateSpread.class;
	}

}
