/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.vo.VoCampaignValidity;
import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.ValueObjects;

public class Campaign extends BusinessEntity {
	
	private final static Logger mLog = LoggerFactory.getLogger(Campaign.class);
	
	/**										
	 * Storage: CAMPAIGN_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mCampaignId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private java.util.Set<Range> mRanges = new java.util.LinkedHashSet<Range>(0);
	private java.util.Set<Amount> mAmounts = new java.util.LinkedHashSet<Amount>(0);
	private java.util.Set<Transaction> mTransactions = new java.util.LinkedHashSet<Transaction>(0);
	private java.util.Set<CampaignLimitation> mCampaignLimitations = new java.util.LinkedHashSet<CampaignLimitation>(0);
	private int mReasonCode;
	private String mCustomerType;

	/**										
	 * Data								
	 */										
	private String mName;
	private String mCampaignState;
	private String mWishedCampaignState;
	private String mCountryCode;
	private java.util.Date mIntervalStartDate;
	private java.util.Date mIntervalEndDate;
	private String mFromTime;
	private String mUntilTime;
	private boolean mMonday;
	private boolean mTuesday;
	private boolean mWednesday;
	private boolean mThursday;
	private boolean mFriday;
	private boolean mSaturday;
	private boolean mSunday;
	private java.math.BigDecimal mAmount;
	private String mCurrencyCode;
	private java.math.BigDecimal mMinPurchaseAmount;
	private java.util.Date mAuthorizedDateTime;
	private String mAuthorizedBy;
	private java.util.Date mWithdrawnDateTime;
	private String mWithdrawnBy;
	private long mLockCount;
	private String mLockMessages;
	private long mCurrentCardNumberId;
	private String mCompanyName;

	/**											
	 * @return Returns the campaignId.													
	 */											
	public long getCampaignId() {
		return mCampaignId;
	}
	/**
	 * @param pCampaignId The campaignId to set.
	 */
	public void setCampaignId(long pCampaignId) {
		mCampaignId = pCampaignId;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the campaignState.													
	 */											
	public String getCampaignState() {
		return mCampaignState;
	}
	/**
	 * @param pCampaignState The campaignState to set.
	 */
	public void setCampaignState(String pCampaignState) {
		mCampaignState = pCampaignState;
	}

	/**											
	 * @return Returns the wishedCampaignState.													
	 */											
	public String getWishedCampaignState() {
		return mWishedCampaignState;
	}
	/**
	 * @param pWishedCampaignState The wishedCampaignState to set.
	 */
	public void setWishedCampaignState(String pWishedCampaignState) {
		mWishedCampaignState = pWishedCampaignState;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the intervalStartDate.													
	 */											
	public java.util.Date getIntervalStartDate() {
		return mIntervalStartDate;
	}
	/**
	 * @param pIntervalStartDate The intervalStartDate to set.
	 */
	public void setIntervalStartDate(java.util.Date pIntervalStartDate) {
		mIntervalStartDate = pIntervalStartDate;
	}

	/**											
	 * @return Returns the intervalEndDate.													
	 */											
	public java.util.Date getIntervalEndDate() {
		return mIntervalEndDate;
	}
	/**
	 * @param pIntervalEndDate The intervalEndDate to set.
	 */
	public void setIntervalEndDate(java.util.Date pIntervalEndDate) {
		mIntervalEndDate = pIntervalEndDate;
	}

	/**											
	 * @return Returns the fromTime.													
	 */											
	public String getFromTime() {
		return mFromTime;
	}
	/**
	 * @param pFromTime The fromTime to set.
	 */
	public void setFromTime(String pFromTime) {
		mFromTime = pFromTime;
	}

	/**											
	 * @return Returns the untilTime.													
	 */											
	public String getUntilTime() {
		return mUntilTime;
	}
	/**
	 * @param pUntilTime The untilTime to set.
	 */
	public void setUntilTime(String pUntilTime) {
		mUntilTime = pUntilTime;
	}

	/**											
	 * @return Returns the monday.													
	 */											
	public boolean getMonday() {
		return mMonday;
	}
	/**
	 * @param pMonday The monday to set.
	 */
	public void setMonday(boolean pMonday) {
		mMonday = pMonday;
	}

	/**											
	 * @return Returns the tuesday.													
	 */											
	public boolean getTuesday() {
		return mTuesday;
	}
	/**
	 * @param pTuesday The tuesday to set.
	 */
	public void setTuesday(boolean pTuesday) {
		mTuesday = pTuesday;
	}

	/**											
	 * @return Returns the wednesday.													
	 */											
	public boolean getWednesday() {
		return mWednesday;
	}
	/**
	 * @param pWednesday The wednesday to set.
	 */
	public void setWednesday(boolean pWednesday) {
		mWednesday = pWednesday;
	}

	/**											
	 * @return Returns the thursday.													
	 */											
	public boolean getThursday() {
		return mThursday;
	}
	/**
	 * @param pThursday The thursday to set.
	 */
	public void setThursday(boolean pThursday) {
		mThursday = pThursday;
	}

	/**											
	 * @return Returns the friday.													
	 */											
	public boolean getFriday() {
		return mFriday;
	}
	/**
	 * @param pFriday The friday to set.
	 */
	public void setFriday(boolean pFriday) {
		mFriday = pFriday;
	}

	/**											
	 * @return Returns the saturday.													
	 */											
	public boolean getSaturday() {
		return mSaturday;
	}
	/**
	 * @param pSaturday The saturday to set.
	 */
	public void setSaturday(boolean pSaturday) {
		mSaturday = pSaturday;
	}

	/**											
	 * @return Returns the sunday.													
	 */											
	public boolean getSunday() {
		return mSunday;
	}
	/**
	 * @param pSunday The sunday to set.
	 */
	public void setSunday(boolean pSunday) {
		mSunday = pSunday;
	}

	/**											
	 * @return Returns the amount.													
	 */											
	public java.math.BigDecimal getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The amount to set.
	 */
	public void setAmount(java.math.BigDecimal pAmount) {
		mAmount = pAmount;
	}

	/**											
	 * @return Returns the currencyCode.													
	 */											
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	/**
	 * @param pCurrencyCode The currencyCode to set.
	 */
	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	/**											
	 * @return Returns the minPurchaseAmount.													
	 */											
	public java.math.BigDecimal getMinPurchaseAmount() {
		return mMinPurchaseAmount;
	}
	/**
	 * @param pMinPurchaseAmount The minPurchaseAmount to set.
	 */
	public void setMinPurchaseAmount(java.math.BigDecimal pMinPurchaseAmount) {
		mMinPurchaseAmount = pMinPurchaseAmount;
	}

	/**											
	 * @return Returns the authorizedDateTime.													
	 */											
	public java.util.Date getAuthorizedDateTime() {
		return mAuthorizedDateTime;
	}
	/**
	 * @param pAuthorizedDateTime The authorizedDateTime to set.
	 */
	public void setAuthorizedDateTime(java.util.Date pAuthorizedDateTime) {
		mAuthorizedDateTime = pAuthorizedDateTime;
	}

	/**											
	 * @return Returns the authorizedBy.													
	 */											
	public String getAuthorizedBy() {
		return mAuthorizedBy;
	}
	/**
	 * @param pAuthorizedBy The authorizedBy to set.
	 */
	public void setAuthorizedBy(String pAuthorizedBy) {
		mAuthorizedBy = pAuthorizedBy;
	}

	/**											
	 * @return Returns the withdrawnDateTime.													
	 */											
	public java.util.Date getWithdrawnDateTime() {
		return mWithdrawnDateTime;
	}
	/**
	 * @param pWithdrawnDateTime The withdrawnDateTime to set.
	 */
	public void setWithdrawnDateTime(java.util.Date pWithdrawnDateTime) {
		mWithdrawnDateTime = pWithdrawnDateTime;
	}

	/**											
	 * @return Returns the withdrawnBy.													
	 */											
	public String getWithdrawnBy() {
		return mWithdrawnBy;
	}
	/**
	 * @param pWithdrawnBy The withdrawnBy to set.
	 */
	public void setWithdrawnBy(String pWithdrawnBy) {
		mWithdrawnBy = pWithdrawnBy;
	}

	/**											
	 * @return Returns the lockCount.													
	 */											
	public long getLockCount() {
		return mLockCount;
	}
	/**
	 * @param pLockCount The lockCount to set.
	 */
	public void setLockCount(long pLockCount) {
		mLockCount = pLockCount;
	}

	/**											
	 * @return Returns the lockMessages.													
	 */											
	public String getLockMessages() {
		return mLockMessages;
	}
	/**
	 * @param pLockMessages The lockMessages to set.
	 */
	public void setLockMessages(String pLockMessages) {
		mLockMessages = pLockMessages;
	}

	/**											
	 * @return Returns the currentCardNumberId.													
	 */											
	public long getCurrentCardNumberId() {
		return mCurrentCardNumberId;
	}
	/**
	 * @param pCurrentCardNumberId The currentCardNumberId to set.
	 */
	public void setCurrentCardNumberId(long pCurrentCardNumberId) {
		mCurrentCardNumberId = pCurrentCardNumberId;
	}

	/**											
	 * @return Returns the ranges.													
	 */											
	public java.util.Set<Range> getRanges() {
		return mRanges;
	}
	/**
	 * @param pRanges The ranges to set.
	 */
	public void setRanges(java.util.Set<Range> pRanges) {
		mRanges = pRanges;
	}

	/**											
	 * @return Returns the amounts.													
	 */											
	public java.util.Set<Amount> getAmounts() {
		return mAmounts;
	}
	/**
	 * @param pAmounts The amounts to set.
	 */
	public void setAmounts(java.util.Set<Amount> pAmounts) {
		mAmounts = pAmounts;
	}

	/**											
	 * @return Returns the transactions.													
	 */											
	public java.util.Set<Transaction> getTransactions() {
		return mTransactions;
	}
	/**
	 * @param pTransactions The transactions to set.
	 */
	public void setTransactions(java.util.Set<Transaction> pTransactions) {
		mTransactions = pTransactions;
	}

	/**											
	 * @return Returns the campaignLimitations.													
	 */											
	public java.util.Set<CampaignLimitation> getCampaignLimitations() {
		return mCampaignLimitations;
	}
	/**
	 * @param pCampaignLimitations The campaignLimitations to set.
	 */
	public void setCampaignLimitations(java.util.Set<CampaignLimitation> pCampaignLimitations) {
		mCampaignLimitations = pCampaignLimitations;
	}
	public int getReasonCode() {
		return mReasonCode;
	}
	public void setReasonCode(int mReasonCode) {
		this.mReasonCode = mReasonCode;
	}

	public String getCustomerType() {
		return mCustomerType;
	}
	public void setCustomerType(String pCustomerType) {
		mCustomerType = pCustomerType;
	}
	public String getCompanyName() {
		return mCompanyName;
	}
	public void setCompanyName(String pCompanyName) {
		mCompanyName = pCompanyName;
	}
	/**
	 * Connect a Range.
	 * @param pRange
	 */
	public void connectRange(Range pRange) {
		getRanges().add(pRange);
		if(pRange != null) {
			pRange.getCampaigns().add(this);
		}
	}

	/**
	 * Disconnect a Range.
	 * @param pRange
	 */
	public void disconnectRange(Range pRange) {
		if(pRange != null) {
			pRange.getCampaigns().remove(this);
		}
		getRanges().remove(pRange);
	}

	/**
	 * Connect a Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		getAmounts().add(pAmount);
		if(pAmount != null) {
			pAmount.setCampaign(this);
		}
	}

	/**
	 * Disconnect a Amount.
	 * @param pAmount
	 */
	public void disconnectAmount(Amount pAmount) {
		if(pAmount != null) {
			pAmount.setCampaign(null);
		}
		getAmounts().remove(pAmount);
	}

	/**
	 * Connect a Transaction.
	 * @param pTransaction
	 */
	public void connectTransaction(Transaction pTransaction) {
		getTransactions().add(pTransaction);
		if(pTransaction != null) {
			pTransaction.setCampaign(this);
		}
	}

	/**
	 * Disconnect a Transaction.
	 * @param pTransaction
	 */
	public void disconnectTransaction(Transaction pTransaction) {
		if(pTransaction != null) {
			pTransaction.setCampaign(null);
		}
		getTransactions().remove(pTransaction);
	}

	/**
	 * Connect a CampaignLimitation.
	 * @param pCampaignLimitation
	 */
	public void connectCampaignLimitation(CampaignLimitation pCampaignLimitation) {
		getCampaignLimitations().add(pCampaignLimitation);
		if(pCampaignLimitation != null) {
			pCampaignLimitation.setCampaign(this);
		}
	}

	/**
	 * Disconnect a CampaignLimitation.
	 * @param pCampaignLimitation
	 */
	public void disconnectCampaignLimitation(CampaignLimitation pCampaignLimitation) {
		if(pCampaignLimitation != null) {
			pCampaignLimitation.setCampaign(null);
		}
		getCampaignLimitations().remove(pCampaignLimitation);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mCampaignId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("campaignId", CodeGeneration.toObject(mCampaignId));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("campaignState", CodeGeneration.toObject(mCampaignState));
		vMap.put("wishedCampaignState", CodeGeneration.toObject(mWishedCampaignState));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("intervalStartDate", CodeGeneration.toObject(mIntervalStartDate));
		vMap.put("intervalEndDate", CodeGeneration.toObject(mIntervalEndDate));
		vMap.put("fromTime", CodeGeneration.toObject(mFromTime));
		vMap.put("untilTime", CodeGeneration.toObject(mUntilTime));
		vMap.put("monday", CodeGeneration.toObject(mMonday));
		vMap.put("tuesday", CodeGeneration.toObject(mTuesday));
		vMap.put("wednesday", CodeGeneration.toObject(mWednesday));
		vMap.put("thursday", CodeGeneration.toObject(mThursday));
		vMap.put("friday", CodeGeneration.toObject(mFriday));
		vMap.put("saturday", CodeGeneration.toObject(mSaturday));
		vMap.put("sunday", CodeGeneration.toObject(mSunday));
		vMap.put("amount", CodeGeneration.toObject(mAmount));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("minPurchaseAmount", CodeGeneration.toObject(mMinPurchaseAmount));
		vMap.put("authorizedDateTime", CodeGeneration.toObject(mAuthorizedDateTime));
		vMap.put("authorizedBy", CodeGeneration.toObject(mAuthorizedBy));
		vMap.put("withdrawnDateTime", CodeGeneration.toObject(mWithdrawnDateTime));
		vMap.put("withdrawnBy", CodeGeneration.toObject(mWithdrawnBy));
		vMap.put("lockCount", CodeGeneration.toObject(mLockCount));
		vMap.put("lockMessages", CodeGeneration.toObject(mLockMessages));
		vMap.put("currentCardNumberId", CodeGeneration.toObject(mCurrentCardNumberId));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("reasonCode", CodeGeneration.toObject(mReasonCode));
		vMap.put("customerType", CodeGeneration.toObject(mCustomerType));
		vMap.put("companyName", CodeGeneration.toObject(mCompanyName));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("campaignId")) mCampaignId = CodeGeneration.objectTolong(pMap.get("campaignId"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("campaignState")) mCampaignState = CodeGeneration.objectToString(pMap.get("campaignState"));
		if(pMap.containsKey("wishedCampaignState")) mWishedCampaignState = CodeGeneration.objectToString(pMap.get("wishedCampaignState"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("intervalStartDate")) mIntervalStartDate = CodeGeneration.objectTojava_util_Date(pMap.get("intervalStartDate"));
		if(pMap.containsKey("intervalEndDate")) mIntervalEndDate = CodeGeneration.objectTojava_util_Date(pMap.get("intervalEndDate"));
		if(pMap.containsKey("fromTime")) mFromTime = CodeGeneration.objectToString(pMap.get("fromTime"));
		if(pMap.containsKey("untilTime")) mUntilTime = CodeGeneration.objectToString(pMap.get("untilTime"));
		if(pMap.containsKey("monday")) mMonday = CodeGeneration.objectToboolean(pMap.get("monday"));
		if(pMap.containsKey("tuesday")) mTuesday = CodeGeneration.objectToboolean(pMap.get("tuesday"));
		if(pMap.containsKey("wednesday")) mWednesday = CodeGeneration.objectToboolean(pMap.get("wednesday"));
		if(pMap.containsKey("thursday")) mThursday = CodeGeneration.objectToboolean(pMap.get("thursday"));
		if(pMap.containsKey("friday")) mFriday = CodeGeneration.objectToboolean(pMap.get("friday"));
		if(pMap.containsKey("saturday")) mSaturday = CodeGeneration.objectToboolean(pMap.get("saturday"));
		if(pMap.containsKey("sunday")) mSunday = CodeGeneration.objectToboolean(pMap.get("sunday"));
		if(pMap.containsKey("amount")) mAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("amount"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("minPurchaseAmount")) mMinPurchaseAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("minPurchaseAmount"));
		if(pMap.containsKey("authorizedDateTime")) mAuthorizedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("authorizedDateTime"));
		if(pMap.containsKey("authorizedBy")) mAuthorizedBy = CodeGeneration.objectToString(pMap.get("authorizedBy"));
		if(pMap.containsKey("withdrawnDateTime")) mWithdrawnDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("withdrawnDateTime"));
		if(pMap.containsKey("withdrawnBy")) mWithdrawnBy = CodeGeneration.objectToString(pMap.get("withdrawnBy"));
		if(pMap.containsKey("lockCount")) mLockCount = CodeGeneration.objectTolong(pMap.get("lockCount"));
		if(pMap.containsKey("lockMessages")) mLockMessages = CodeGeneration.objectToString(pMap.get("lockMessages"));
		if(pMap.containsKey("currentCardNumberId")) mCurrentCardNumberId = CodeGeneration.objectTolong(pMap.get("currentCardNumberId"));
		if(pMap.containsKey("reasonCode")) mReasonCode = CodeGeneration.objectToint(pMap.get("reasonCode"));
		if(pMap.containsKey("customerType")) mCustomerType = CodeGeneration.objectToString(pMap.get("customerType"));
		if(pMap.containsKey("companyName")) mCompanyName = CodeGeneration.objectToString(pMap.get("companyName"));
	}
	

	public VoCampaignValidity getVoCampaignValidity()
			throws ValueMissingException {

		VoCampaignValidity vVoCampaignValidity = new VoCampaignValidity();
		assignToVoCampaignValidity(vVoCampaignValidity);
		vVoCampaignValidity
				.setVoCampaignLimitationList(getVoCampaignLimitationList());

		// Limitations (BUs)
		vVoCampaignValidity
				.setVoCampaignLimitationList(getVoCampaignLimitationList());

		return vVoCampaignValidity;
	}

	public void assignToVoCampaignValidity(
			VoCampaignValidity pVoCampaignValidity)
			throws ValueMissingException {

		Map<String, Object> vMap = assignToMap();

		vMap.remove("fromTime");
		vMap.remove("untilTime");

		ValueObjects.assignFromMap(pVoCampaignValidity, vMap);

		// Special handling for fromTime and untilTime
		if (getFromTime() != null) {
			pVoCampaignValidity.setFromTime(Dates.parseTime(
					getFromTime() + ":00").toDate());
		}
		if (getUntilTime() != null) {
			pVoCampaignValidity.setUntilTime(Dates.parseTime(
					getUntilTime() + ":00").toDate());
		}
	}

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public List<VoCampaignLimitation> getVoCampaignLimitationList()
			throws ValueMissingException {

		List<VoCampaignLimitation> vVoCampaignLimitationList = new ArrayList<VoCampaignLimitation>();

		// Sort the BUs
		List<CampaignLimitation> vLimitations = new ArrayList<CampaignLimitation>(
				getCampaignLimitations());
		Collections.sort(vLimitations, new Comparator<CampaignLimitation>() {
			public int compare(CampaignLimitation o1, CampaignLimitation o2) {
				CampaignLimitation a1 = (CampaignLimitation) o1, a2 = (CampaignLimitation) o2;
				return a1.getBuCode().compareTo(a2.getBuCode());
			}
		});

		if (vLimitations != null) {
			for (Iterator<CampaignLimitation> i = vLimitations.iterator(); i
					.hasNext();) {
				CampaignLimitation vCampaignLimitation = (CampaignLimitation) i
						.next();
				VoCampaignLimitation vVoCampaignLimitation = new VoCampaignLimitation();
				ValueObjects.assignToValueObject(vVoCampaignLimitation,
						vCampaignLimitation);
				vVoCampaignLimitationList
						.add(vVoCampaignLimitation);
				mLog.debug("Added limitation "
						+ vVoCampaignLimitation.getBuCode());
			}
		}
		return vVoCampaignLimitationList;
	}
}
