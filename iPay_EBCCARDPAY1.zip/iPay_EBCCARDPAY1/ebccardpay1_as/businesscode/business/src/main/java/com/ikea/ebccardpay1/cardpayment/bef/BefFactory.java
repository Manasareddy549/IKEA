/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.bec.BecExternalTempCard;

public interface BefFactory {

	public BefCountry getBefCountry();

	public BefExchangeRate getBefExchangeRate();

	public BefExternalCard getBefExternalCard();

	public BefExternalCardSystem getBefExternalCardSystem();

	public BefMainCurrency getBefMainCurrency();

	public BefExchangeModeConstant getBefExchangeModeConstant();

	public BefBonusCode getBefBonusCode();

	public BefCampaignLimitation getBefCampaignLimitation();

	public BefKPI getBefKPI();

	public BefCountrySetup getBefCountrySetup();

	public BefReport getBefReport();

	public BefReferenceCheck getBefReferenceCheck();

	public BefActivation getBefActivation();

	public BefCampaign getBefCampaign();

	public BefMassLoad getBefMassLoad();

	public BefRange getBefRange();

	public BefCardTypeConstant getBefCardTypeConstant();

	public BefAmount getBefAmount();

	public BefCard getBefCard();

	public BefCardNumber getBefCardNumber();

	public BefLifeCycle getBefLifeCycle();

	public BefTransaction getBefTransaction();

	public BefParameter getBefParameter();

	public BefAuthorization getBefAuthorization();

	public BefSourceSystemConstant getBefSourceSystemConstant();

	public BefBonus getBefBonus();

	public BefTransactionFilter getBefTransactionFilter();

	public BefExchangeRateSpread getBefExchangeRateSpread();
	
	public BefConstants getBefConstants();
	
	public  BefIpayBusinessUnits getBefIpayBusinessUnits();
	
	public BefUnacknowledgedTimeout getBefUnacknowledgedTimeout();
	
	public BefSarecReport getBefSarecReport();
	
	public BefExternalTempCard getBefExternalTempCard();
	
	public BefCnCardBatchJob getBefCnCardBatchJob();
	
	public BefCnCard getBefCnCard();
	
	public BefReasonCodeTransaction getBefReasonCodeTransaction();
	
	public BefReasonCode getBefReasonCode();
	
	public BefBsLog getBefBsLog();
	
	public BefCustomerType getBefCustomerType();

	public BefMessage getBefMessage();
	
	public BefReservedCardHistory getBefReservedCardHistory();

}