/*
 * Created on 2007-sep-13
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author dalq
 *
 *
 */
public class ExchangeRateNotFoundException extends CurrencyException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3453929172147150206L;

	/**
	 * 
	 */
	public ExchangeRateNotFoundException() {
		super();

	}

	/**
	 * @param pMessage
	 */
	public ExchangeRateNotFoundException(String pMessage) {
		super(pMessage);

	}

}
