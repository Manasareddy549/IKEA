package com.ikea.ebccardpay1.cardpayment.bec;

import static org.apache.commons.lang.Validate.notNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebcframework.services.BsContext;

public class BecProcessExpiredCradsImpl implements BecProcessExpiredCrads {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecProcessExpiredCradsImpl.class.getName());
	private BefCard mBefCard = null;
	//private BefTransaction mBefTransaction = null;
    private UtilsFactory mUtilsFactory = null;
	//private BefAmount mBefAmount = null;
	public Set<Card> cardList = new HashSet<Card>();
	
	public static CopyOnWriteArrayList<Card> crdlist = null;
	
	 @Autowired
	 private BsContext bsContext;

	
	//BefTransaction pBefTransaction,BefAmount pBefAmount
	protected BecProcessExpiredCradsImpl(BefCard pBefCard, UtilsFactory pUtilsFactory) {

		mBefCard = pBefCard;
		//mBefTransaction = pBefTransaction;
		mUtilsFactory = pUtilsFactory;
		//mBefAmount = pBefAmount;
	}

	void validate() {

		notNull(mBefCard);

		//notNull(mBefTransaction);
		notNull(mUtilsFactory);
		//notNull(mBefAmount);

	}

	//@Override
	@Transactional
	public int getCardSize() throws Exception {

		cardList = new HashSet<Card>(mBefCard.getExpiredCards());
		return cardList.size();
	}

	//@Override
	@Transactional
	public void processExpiredCards() {
		
		

		mCategory.info("getExpiredCards()");
		TransactionEnvironment vTransactionEnvironment = mUtilsFactory
				.createTransactionEnvironment(
						Constants.SOURCE_SYSTEM_CONSTANT_IPAY, null);

		Set<Amount> amountSet ;
		Set<Transaction> transactionSet;
		if (cardList != null && !cardList.isEmpty()){
			mCategory.info("Total ExpiredCards : " + cardList.size());
			for (Card icard :cardList) {
				amountSet = new HashSet<Amount>();
				transactionSet= new HashSet<Transaction>();
				if (icard != null && icard.getAmounts() != null) {
						icard.setCardState(Constants.CARD_STATE_CONSTANT_EXPIRED);
						icard.setLastTransactionDateTime(new Date());
						icard.setLastLifeCycleDateTime(new Date());
					
						
						for (Amount amount : icard.getAmounts()) {
							
							Transaction vTransaction = new Transaction();//mBefTransaction.create();
							if (Math.max(0, amount.getCurrentAmount().stripTrailingZeros().scale()) > 0) {
								vTransaction.setBuCode(amount.getBuCode());
								vTransaction.setBuType(amount.getBuType());
								vTransaction.setCountryCode(icard
										.getCountryCode());
								vTransaction.setSwiped("N");
								// vTransaction.setTransactionNo(0);
								vTransaction.setCard(icard);
								vTransaction
										.setTransmissionDateTime(new Date());
								vTransaction.setInsufficientAmount(false);
								vTransaction
										.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
								vTransaction
										.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
								vTransaction.setSourceSystem("IPAY");
								vTransaction.setSalesDay(Dates
										.formatDate(new DateTime()));
								vTransaction.setCrossBorder(false);
								vTransaction.setCrossCurrency(false);
								vTransaction.setVoidedTransactionNo(0);
								vTransaction.setCancelled(false);
								if (icard.getCurrencyCode() != null
										&& !icard.getCurrencyCode().isEmpty())
									vTransaction.setRequestedCurrencyCode(icard
											.getCurrencyCode());
								else
									vTransaction.setRequestedCurrencyCode("");

								BigDecimal prioCurrentAmount = amount
										.getCurrentAmount();
								vTransaction.setBalanceChange(amount
										.getCurrentAmount());
								vTransaction.setCardBalanceChange(amount
										.getCurrentAmount());
								amount.setCurrentAmount(new BigDecimal(0));

								vTransaction
										.setRequestedAmount(prioCurrentAmount);
								vTransaction
										.setEmployee(vTransactionEnvironment
												.getEmployee().trim());
								vTransaction
										.setEmployee(Constants.EXPIRE_CARD_JOB);
								vTransaction
										.setTransactionNo(vTransactionEnvironment
												.getTransactionNo());
								vTransaction
										.setReference(vTransactionEnvironment
												.getReference());
								vTransaction.setCreatedBy(bsContext.getUserProfile().getUID());
								vTransaction.setCreatedDateTime(new Date());
								vTransaction.setAmount(amount);
								// amount.getTransactions().add(vTransaction);

							} else {
								vTransaction.setBuCode(amount.getBuCode());
								vTransaction.setBuType(amount.getBuType());
								vTransaction.setCountryCode(icard
										.getCountryCode());
								vTransaction.setSwiped("N");
								// vTransaction.setTransactionNo(0);
								vTransaction.setCard(icard);
								vTransaction
										.setTransmissionDateTime(new Date());
								vTransaction.setInsufficientAmount(false);
								vTransaction
										.setFinancialType(Constants.FINANCIAL_TYPE_CONSTANT_DEBIT);
								vTransaction
										.setTransactionType(Constants.TRANSACTION_TYPE_CONSTANT_EXPIRED_REDEEM_CARD);
								vTransaction.setSourceSystem("IPAY");
								vTransaction.setSalesDay(Dates
										.formatDate(new DateTime()));
								vTransaction.setCrossBorder(false);
								vTransaction.setCrossCurrency(false);
								vTransaction.setVoidedTransactionNo(0);
								vTransaction.setCancelled(false);
								if (icard.getCurrencyCode() != null
										&& !icard.getCurrencyCode().isEmpty())
									vTransaction.setRequestedCurrencyCode(icard
											.getCurrencyCode());
								else
									vTransaction.setRequestedCurrencyCode("");

								BigDecimal prioCurrentAmount = amount
										.getCurrentAmount();
								vTransaction.setBalanceChange(amount
										.getCurrentAmount());
								vTransaction.setCardBalanceChange(amount
										.getCurrentAmount());
								amount.setCurrentAmount(new BigDecimal(0));

								vTransaction
										.setRequestedAmount(prioCurrentAmount);
								vTransaction
										.setEmployee(vTransactionEnvironment
												.getEmployee().trim());
								vTransaction
										.setEmployee(Constants.EXPIRE_CARD_JOB);
								vTransaction
										.setTransactionNo(vTransactionEnvironment
												.getTransactionNo());
								vTransaction
										.setReference(vTransactionEnvironment
												.getReference());
								vTransaction.setCreatedBy(bsContext.getUserProfile().getUID());
								vTransaction.setCreatedDateTime(new Date());
								vTransaction.setAmount(amount);
								// amount.getTransactions().add(vTransaction);

							}
							transactionSet.add(vTransaction);
							amount.setTransactions(transactionSet);
							amountSet.add(amount) ;
							//amountSet.add(amount);
							/*amount.getTransactions().add(vTransaction);
							icard.getTransactions().add(vTransaction);
							mBefTransaction.save(vTransaction);*/
							//mBefAmount.merge(amount);
							//mBefCard.update(icard);

						} // End inner for
						
						
					}
				icard.setTransactions(transactionSet);
				icard.setAmounts(amountSet);
				mBefCard.saveOrUpdate(icard);
				}

			}// End of Outer for loop

		} // End of if.

	

	

	
	
	
	
	
	

	}


	


