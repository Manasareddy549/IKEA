/*
 * Created on 2006-dec-13
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class InvalidCardCheckDigitException
	extends InvalidCardNumberException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2973065124408249931L;

	/**
	 * 
	 *
	 */
	public InvalidCardCheckDigitException() {
		super();
	}

	/**
	 * 
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidCardCheckDigit();
	}

}
