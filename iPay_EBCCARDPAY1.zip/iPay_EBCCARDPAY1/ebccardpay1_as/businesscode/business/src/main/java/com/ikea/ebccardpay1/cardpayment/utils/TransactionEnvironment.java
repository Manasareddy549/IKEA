package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;

public interface TransactionEnvironment {

	/**
	 * 
	 * @return
	 */
	public abstract String getReference();

	/**
	 * 
	 * @return
	 */
	public abstract String getSourceSystem();

	/**
	 * 
	 * @return
	 */
	public abstract Date getTransmissionDateTime();

	/**
	 * 
	 * @return
	 */
	public abstract boolean getAutoAcknowledge();

	/**
	 * 
	 * @return
	 */
	public abstract String getEmployee();

	/**
	 * 
	 * @return
	 */
	public abstract String getPointOfSale();

	/**
	 * 
	 * @return
	 */
	public abstract String getReceipt();

	/**
	 * 
	 * @return
	 */
	public abstract String getSwiped();

	/**
	 * Gets the transaction no for this transaction to keep all transaction rows together.
	 * @return
	 * @throws IllegalStateException if errors from IKEA key generator
	 */
	public long getTransactionNo() throws IllegalStateException;
	
	public abstract long getAckTimeout();

}
