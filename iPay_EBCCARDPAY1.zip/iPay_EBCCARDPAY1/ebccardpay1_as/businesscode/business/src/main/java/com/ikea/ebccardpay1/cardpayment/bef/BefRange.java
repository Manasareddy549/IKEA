/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefRange extends Bef<Range>{

	public java.util.List<Range> findByCurrent(String pCountryCode);

	public void addCardNumbers(Range pRange, java.util.List<CardNumber> pCardNumbers);

}