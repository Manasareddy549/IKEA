/*
 * Created on 2007-aug-22
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author dalq
 *
 * DuplicateExternalCardSystem error is thrown if an External Card System already exists in the 
 * database with the same name
 *
 */
public class DuplicateExternalCardSystem extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1501689139658062033L;


	/**
	 * 
	 */
	public DuplicateExternalCardSystem() {
		super();

	}


	/**
	 * @param pMessage
	 */
	public DuplicateExternalCardSystem(String pMessage) {
		super(pMessage);
	}

}
