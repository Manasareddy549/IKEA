/*
 * Created on 2007-sep-10
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *
 */
public class InvalidToCurrencyException extends CurrencyException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3810809639738539766L;

	/**
	 * 
	 */
	public InvalidToCurrencyException() {
		super();
	}

	/**
	 * @param message
	 */
	public InvalidToCurrencyException(String message) {
		super(message);
	}

	public ApplicationError createApplicationError() {
		
		return new EbcCardPay1ApplError.InvalidToCurrency();
	}

}
