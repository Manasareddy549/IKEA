package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

/**
 *
 */
public interface BecKPI {

	/**
	 * Evaluates the dates that needs to be calculated
	 * 
	 * @param pKPIType
	 * @param pBuType
	 * @param pBuCode
	 * @param pBefIpayBusinessUnits
	 * @return
	 */
	List<String> findUncalculatedKPIDates(String pKPIType, String pBuType,
			String pBuCode,BefIpayBusinessUnits pBefIpayBusinessUnits);
}
