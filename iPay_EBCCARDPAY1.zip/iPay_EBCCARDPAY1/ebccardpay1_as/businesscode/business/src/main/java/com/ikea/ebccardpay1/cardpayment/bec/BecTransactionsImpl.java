package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.TransactionFilter;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransactionFilter;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationAmountException;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationException;
import com.ikea.ebccardpay1.cardpayment.exception.CardNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.ReferenceCheckException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.CheckDigits;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.vo.VoAuthorization;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionBrief;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionDetail;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionKey;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.ValueObjects;
import static org.apache.commons.lang.Validate.notNull;


public class BecTransactionsImpl implements BecTransactions, InitializingBean {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecTransactionsImpl.class);

	// Dependencies injected at creation of this BEC
	private BefIpayBusinessUnits mBefIpayBusinessUnits;
	private Units mUnits;
	private TimeSource mTimeSource;
	private BecFactory mBecFactory;
	private BefTransaction mBefTransaction;
	private BefAuthorization mBefAuthorization;
	private BefTransactionFilter mBefTransactionFilter;
	private UtilsFactory mUtilsFactory;
	private EbcProperties mEbcProperties;
	private EncryptionDecryption mEncryptionDecryption=null;

	// BE that this BEC operates on
	Collection<Transaction> mTransactions = null;
	Card mCard = null;
	String mAuthorizationNumber = null;
	VoTransactionKey mVoTransactionKey = null;
	String accountNumber = null;

	// Related Bec's that this Bec delegates work to

	private BusinessUnitEnvironment mBusinessUnitEnvironment;
	private TransactionEnvironment mTransactionEnvironment;
	private String mReference;
	private String mSourceSystem;
	
	
	private BecReservedCardHistory mBecReservedCardHistory;

	/**
	 * Dependecy injection
	 */
	protected BecTransactionsImpl(BecFactory pBecFactory,
			UtilsFactory pUtilsFactory, Units pUnits, TimeSource pTimeSource,
			BefTransactionFilter pBefTransactionFilter,
			BefTransaction pBefTransaction, BefAuthorization pBefAuthorization,
			BefIpayBusinessUnits pBefIpayBusinessUnits,EncryptionDecryption pEncryptionDecryption,
			EbcProperties pEbcProperties, BecReservedCardHistory pBecReservedCardHistory) {

		mBecFactory = pBecFactory;
		mUtilsFactory = pUtilsFactory;
		mUnits = pUnits;
		mTimeSource = pTimeSource;
		mBefTransactionFilter = pBefTransactionFilter;
		mBefTransaction = pBefTransaction;
		mBefAuthorization = pBefAuthorization;
		mBefIpayBusinessUnits = pBefIpayBusinessUnits;
		mEncryptionDecryption = pEncryptionDecryption;
		mEbcProperties = pEbcProperties;
		mBecReservedCardHistory = pBecReservedCardHistory;
	}


	void validate() {
		notNull(mBecFactory);
		notNull(mUtilsFactory);
		notNull(mUnits);
		notNull(mTimeSource);
		notNull(mBefTransaction);
		notNull(mBefTransactionFilter);
		notNull(mBefAuthorization);
		notNull(mBecReservedCardHistory);
	}

	//@Override
	public void afterPropertiesSet() throws Exception {
		validate();

	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#init(long)
	 */
	public BecTransactions init(long pTransactionNo) {

		initTransactions(mBefTransaction.findByTransactionNo(pTransactionNo));

		if (mTransactions.size() > 0) {
			Transaction vTransaction = (Transaction) mTransactions.iterator()
					.next();
			initBusinessUnitEnvironment(mUtilsFactory
					.createBusinessUnitEnvironment(vTransaction));
		}
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#init(java.lang.String
	 * , java.lang.String,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecTransactions init(String pReference, String pSourceSystem,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		mReference = pReference;
		mSourceSystem = pSourceSystem;
		initBusinessUnitEnvironment(pBusinessUnitEnvironment);
		initTransactionEnvironment(pTransactionEnvironment);

		return initTransactions(mBefTransaction.findByReference(pReference,
				pSourceSystem));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#init(java.lang.String
	 * , java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public BecTransactions init(String pBuType, String pBuCode,
			String pSourceSystem, String pPointOfSale,
			String pCardNumberString,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment)
					throws CardNotFoundException, InvalidCardNumberException,
					ValueMissingException, IkeaException, ReferenceCheckException {

		initBusinessUnitEnvironment(pBusinessUnitEnvironment);
		initTransactionEnvironment(pTransactionEnvironment);

		// Find card information
		initCard(pCardNumberString);

		return initTransactions(mBefTransaction.findByOriginator(pBuType,
				pBuCode, pSourceSystem, pPointOfSale, Dates.calculateSalesDay(
						mUnits, mTimeSource.currentDate(), pBuType, pBuCode, mBefIpayBusinessUnits),
						null, mCard));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecTransactions#init(java.math.
	 * BigDecimal, java.lang.String, java.lang.String)
	 */
	public BecTransactions init(BigDecimal pAmount, String pCurrencyCode,
			String pBuType, String pBuCode, String pSourceSystem,
			String pPointOfSale, String pReceipt, String pCardNumberString,
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment)
					throws CardNotFoundException, InvalidCardNumberException,
					ValueMissingException, IkeaException, ReferenceCheckException {

		initBusinessUnitEnvironment(pBusinessUnitEnvironment);
		initTransactionEnvironment(pTransactionEnvironment);

		// Find card information
		initCard(pCardNumberString);

		// Load transaction based on originator, including receipt
		initTransactions(mBefTransaction.findByOriginator(pBuType, pBuCode,
				pSourceSystem, pPointOfSale, Dates.calculateSalesDay(mUnits,
						mTimeSource.currentDate(), pBuType, pBuCode, mBefIpayBusinessUnits), pReceipt,
						mCard));

		// Compress resulting transactions
		for(VoTransactionBrief vVoTransactionBrief : compressBrief()){

			// Inspect values
			BigDecimal vAmount = null;
			// Check balance differently depending on if it is a cross currency.
			if (!mCard.getCurrencyCode().equals(pCurrencyCode)) {
				mCategory
				.info("This is a cross country use sumBalanceChange = "
						+ vVoTransactionBrief.getSumBalanceChange());
				vAmount = vVoTransactionBrief.getSumBalanceChange();
			} else {
				mCategory.info("No cross country sumCardBalanceChange = "
						+ vVoTransactionBrief.getSumCardBalanceChange());
				vAmount = vVoTransactionBrief.getSumCardBalanceChange();
			}
			long vTransactionNo = vVoTransactionBrief.getTransactionNo();

			// If the sum of balance change does not match the specified amount
			// remove all transactions based on that transaction no
			if (!Amounts.isEqual(vAmount, pAmount)) {
				for (Iterator<Transaction> j = mTransactions.iterator(); j
						.hasNext();) {
					Transaction vTransaction = (Transaction) j.next();
					if (vTransaction.getTransactionNo() == vTransactionNo) {
						j.remove();
					}
					mCategory.info("1 vTransaction.getTransactionNo()"
							+ vTransaction.getTransactionNo() + " VoidTrNo"
							+ vTransaction.getVoidedTransactionNo());

				}
			}
		}

		StringBuffer vVoidedTransactionNo = new StringBuffer();

		// Remove transactions that were not for the given card
		for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
			Transaction vTransaction = (Transaction) i.next();
			if (vTransaction.getCard().getCardId() != mCard.getCardId()) {
				i.remove();
			}

			// Collect already references from voided TransactionNo
			if (vTransaction.getVoidedTransactionNo() != 0) {
				vVoidedTransactionNo.append(vTransaction
						.getVoidedTransactionNo());
			}

		}

		// Remove transactions that have other transaction_no.
		// Can only void one transaction per request
		long vTransactionNo = -1;
		boolean vRemoved = false;
		for (Iterator<Transaction> k = mTransactions.iterator(); k.hasNext();) {
			vRemoved = false;
			Transaction vTransaction = (Transaction) k.next();

			if (vVoidedTransactionNo.indexOf(Long.toString(vTransaction
					.getTransactionNo())) != -1
					|| (vTransactionNo != -1 && vTransactionNo != vTransaction
					.getTransactionNo())) {
				k.remove();
				vRemoved = true;
			}
			if (!vRemoved)
				vTransactionNo = vTransaction.getTransactionNo();
		}
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bec.BecTransactions#init(com.ikea.
	 * ebccardpay1.cardpayment.utils.BusinessUnitEnvironment,
	 * com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecTransactions init(
			BusinessUnitEnvironment pBusinessUnitEnvironment,
			TransactionEnvironment pTransactionEnvironment) {

		initBusinessUnitEnvironment(pBusinessUnitEnvironment);
		initTransactionEnvironment(pTransactionEnvironment);

		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#initTransactions
	 * (java.util.Collection)
	 */
	public BecTransactions initTransactions(
			Collection<Transaction> pTransactions) {

		mTransactions = pTransactions;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#setCard(java.lang
	 * .String)
	 */
	public BecTransactions initCard(String pCardNumberString)
			throws CardNotFoundException, InvalidCardNumberException,
			ValueMissingException, IkeaException, ReferenceCheckException {

		// Find card information
		mCard = null;
		BecCard vBecCard = mBecFactory.createBecCard();
		vBecCard.findCard(pCardNumberString);
		mCard = vBecCard.getCard();
		return this;
	}

	/**
	 * 
	 * @param pVoAuthorization
	 * @param pVoTransactionBrief
	 */
	protected void checkBalanceChange(VoAuthorization pVoAuthorization,
			VoTransactionBrief pVoTransactionBrief)
					throws AuthorizationAmountException {
		BigDecimal vSum = pVoTransactionBrief.getRequestedAmount().subtract(
				pVoTransactionBrief.getSumBalanceChange());

		// The output should be 0 if the amounts are the same.
		if (!Amounts.isEqual(vSum, Amounts.zero())) {
			mCategory.info("Requested amount '"
					+ pVoTransactionBrief.getRequestedAmount()
					+ "' not same as balance change '"
					+ pVoTransactionBrief.getSumBalanceChange()
					+ "' , notify user!!");
			// Throw error to force user to a manual change of the requested
			// amount
			throw new AuthorizationAmountException("Requested amount '"
					+ pVoTransactionBrief.getRequestedAmount()
					+ "' is not available on card. Balance change was '"
					+ pVoTransactionBrief.getSumBalanceChange() + "'");
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#getCard()
	 */
	public Card getCard() throws ValueMissingException {
		requireCard();
		return mCard;
	}

	public VoTransactionKey getVoTransactionKey() throws ValueMissingException {
		requireVoTransactionKey();
		return mVoTransactionKey;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#cancelTransactions()
	 */
	public void cancelTransactions() throws ValueMissingException,
	AmountException {

		requireTransactions();

		for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
			Transaction vTransaction = (Transaction) i.next();

			mCategory.info("Cancelling transaction no "
					+ vTransaction.getTransactionNo() + " "
					+ vTransaction.getTransactionType());

			// Check if a zero transactions (redemption of a card with balance
			// zero)
			if (vTransaction.getAmount() != null) {
				// Undo the transaction
				undoAmount(vTransaction);
			}

			// Mark transaction
			BecTransaction vBecTransaction = mBecFactory.createBecTransaction()
					.init(vTransaction, mBusinessUnitEnvironment,
							mTransactionEnvironment);
			vBecTransaction.cancelTransaction();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#voidTransactions
	 * (java.lang.String, boolean)
	 */
	public Card voidTransactions(String pSourceSystem,
			boolean pManual, boolean pWaitingAck) throws TransactionException,
			AuthorizationException, AmountException, IkeaException,
			AuthorizationAmountException, ReferenceCheckException,
			ValueMissingException, UnacknowledgedTimeoutException {

		requireTransactions();

		// Authorize the old transactions first
		if (pManual) {
			try {
				authorizeTransactions();
			} catch (AuthorizationException e) {
				throw new TransactionException(
						"You can not void a transaction that is already authorized. "
								+ e.getMessage());
			}

		}

		if (mTransactions.size() == 0) {
			
			//throw new TransactionException("No transactions found to void");
			
			return mBecReservedCardHistory.createVoidAuthorizeRedeemTransaction(mReference, mSourceSystem, mBusinessUnitEnvironment, mTransactionEnvironment, pWaitingAck, pManual);
			
		}else {
			
			Transaction vFirst = (Transaction) mTransactions.iterator().next();
			if (pManual) {
				mTransactionEnvironment = mUtilsFactory
						.createTransactionEnvironment(pSourceSystem, vFirst);
			}

			// List of all new void transactions
			List<Transaction> vVoidTransactions = new LinkedList<Transaction>();

			Set<Long> vTransactionsNoToFilter = new java.util.LinkedHashSet<Long>(0);

			long vTransactionNoCheck = 0;

			for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
				Transaction vTransaction = (Transaction) i.next();

				// Check if this transaction has already been Voided.
				if (vTransactionNoCheck == 0
						|| (vTransactionNoCheck != vTransaction.getTransactionNo())) {
					TransactionFilter vTransactionFilter = mBefTransactionFilter
							.findByTransactionNo(vTransaction.getTransactionNo());
					
					// 3.8.1 patch to 
					if(vTransaction.getCancelled())
					{
						mCard = vTransaction.getCard();
						AuthorizationForCancelledTransaction(vTransaction.getRequestedAmount(),vTransaction.getRequestedCurrencyCode());
						return null;
					}
					if (vTransactionFilter != null
							&& vTransactionFilter.getVoided()) {
						throw new TransactionException(
								"You can not void a transaction that has already been voided.");
					}
					vTransactionNoCheck = vTransaction.getTransactionNo();
				}

				// Save unique TransactionNo for filter creation
				vTransactionsNoToFilter.add(new Long(vTransaction
						.getTransactionNo()));

				mCategory.info("Voiding transaction no "
						+ vTransaction.getTransactionNo() + " id "
						+ vTransaction.getTransactionId() + " "
						+ vTransaction.getTransactionType());

			
					// Undo the transaction
					undoAmount(vTransaction);
			
				// Mark transaction
				BecTransaction vBecTransaction = mBecFactory.createBecTransaction()
						.init(vTransaction.getCard(), vTransaction.getAmount(),
								mBusinessUnitEnvironment, mTransactionEnvironment);

				mCard = vTransaction.getCard();
				
					vBecTransaction.createVoidTransaction(vTransaction);
					vVoidTransactions.add(vBecTransaction.getTransaction());
				

			}

			// Create Reference for VOID
			BecReferenceCheck vBecReferenceCheck = mBecFactory
					.createBecReferenceCheck().init(mCard,
							mBusinessUnitEnvironment, mTransactionEnvironment);

			vBecReferenceCheck.checkAndCreateVoid(pManual);

			// Loop through the unique TransactionNo and create filter posts in
			// TRANSACTION_FILTER_T
			for (Iterator<Long> i = vTransactionsNoToFilter.iterator(); i.hasNext();) {
				Long vTransactionNo = (Long) i.next();

				// Create a transaction filter on the original transaction
				TransactionFilter vTransactionFilter = mBefTransactionFilter
						.create();
				vTransactionFilter.setVoided(true);
				vTransactionFilter.setTransactionNo(vTransactionNo.longValue());
				mBefTransactionFilter.save(vTransactionFilter);

			}

			// Set the void transactions as the current transactions
			initTransactions(vVoidTransactions);
		}

	

		if (pManual) {
			 authorizeTransactions();
			 return null;
		}
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#voidTransactions
	 * (java.lang.String, boolean)
	 */
	public VoAuthorization voidManualTransactions(String pSourceSystem,
			boolean pManual) throws TransactionException,
			AuthorizationException, AmountException, IkeaException,
			AuthorizationAmountException, ReferenceCheckException,
			ValueMissingException, UnacknowledgedTimeoutException {

		requireTransactions();

		// Authorize the old transactions first
		if (pManual) {
			try {
				authorizeTransactions();
			} catch (AuthorizationException e) {
				throw new TransactionException(
						"You can not void a transaction that is already authorized. "
								+ e.getMessage());
			}

		}

		if (mTransactions.size() == 0) {
			throw new TransactionException("No transactions found to void");
		}

		Transaction vFirst = (Transaction) mTransactions.iterator().next();
		if (pManual) {
			mTransactionEnvironment = mUtilsFactory
					.createTransactionEnvironment(pSourceSystem, vFirst);
		}

		// List of all new void transactions
		List<Transaction> vVoidTransactions = new LinkedList<Transaction>();

		Set<Long> vTransactionsNoToFilter = new java.util.LinkedHashSet<Long>(0);

		long vTransactionNoCheck = 0;

		for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
			Transaction vTransaction = (Transaction) i.next();

			// Check if this transaction has already been Voided.
			if (vTransactionNoCheck == 0
					|| (vTransactionNoCheck != vTransaction.getTransactionNo())) {
				TransactionFilter vTransactionFilter = mBefTransactionFilter
						.findByTransactionNo(vTransaction.getTransactionNo());
				
				// 3.8.1 patch to 
				if(vTransaction.getCancelled())
				{
					mCard = vTransaction.getCard();
					return  AuthorizationForCancelledTransaction(vTransaction.getRequestedAmount(),vTransaction.getRequestedCurrencyCode());
				}
				if (vTransactionFilter != null
						&& vTransactionFilter.getVoided()) {
					throw new TransactionException(
							"You can not void a transaction that has already been voided.");
				}
				vTransactionNoCheck = vTransaction.getTransactionNo();
			}

			// Save unique TransactionNo for filter creation
			vTransactionsNoToFilter.add(new Long(vTransaction
					.getTransactionNo()));

			mCategory.info("Voiding transaction no "
					+ vTransaction.getTransactionNo() + " id "
					+ vTransaction.getTransactionId() + " "
					+ vTransaction.getTransactionType());

		
				// Undo the transaction
				undoAmount(vTransaction);
		
			// Mark transaction
			BecTransaction vBecTransaction = mBecFactory.createBecTransaction()
					.init(vTransaction.getCard(), vTransaction.getAmount(),
							mBusinessUnitEnvironment, mTransactionEnvironment);

			mCard = vTransaction.getCard();
			
				vBecTransaction.createVoidManualTransaction(vTransaction);
				vVoidTransactions.add(vBecTransaction.getTransaction());
			

		}

		// Create Reference for VOID
		BecReferenceCheck vBecReferenceCheck = mBecFactory
				.createBecReferenceCheck().init(mCard,
						mBusinessUnitEnvironment, mTransactionEnvironment);

		vBecReferenceCheck.checkAndCreate(pManual);

		// Loop through the unique TransactionNo and create filter posts in
		// TRANSACTION_FILTER_T
		for (Iterator<Long> i = vTransactionsNoToFilter.iterator(); i.hasNext();) {
			Long vTransactionNo = (Long) i.next();

			// Create a transaction filter on the original transaction
			TransactionFilter vTransactionFilter = mBefTransactionFilter
					.create();
			vTransactionFilter.setVoided(true);
			vTransactionFilter.setTransactionNo(vTransactionNo.longValue());
			mBefTransactionFilter.save(vTransactionFilter);

		}

		// Set the void transactions as the current transactions
		initTransactions(vVoidTransactions);

		if (pManual) {
			return authorizeTransactions();
		}
		return null;
	}

	public VoAuthorization authorizeTransactions()
			throws AuthorizationException, AuthorizationAmountException,
			ValueMissingException {
		Iterator<Transaction> iterator = mTransactions.iterator();
		if (iterator.hasNext()) {
			Transaction trans = (Transaction) iterator.next();
			// BigDecimal balanceChange = trans.getBalanceChange();
			CardNumber cardNumber = trans.getCard().getCardNumber();
			
			//iPay4.8.1- Sprint2
//			if(cardNumber.getAccountNumberEnc()==null || cardNumber.getAccountNumberEnc().length()==0) {
//				accountNumber = cardNumber.getAccountNumber();
//			}
//			else {
				accountNumber = mEncryptionDecryption.decrypt(cardNumber.getAccountNumberEnc());
				 
			//}
			
			int checkDigit = cardNumber.getCheckDigit();

			// Compress the transactions
			List<VoTransactionBrief> vList = compressBrief();

			// We should now have one VoTransactionBrief for the complete
			// transaction
			if (vList.size() != 1) {
				throw new AuthorizationException(
						"Transaction can not be determined");
			}

			// Extract transaction information
			VoTransactionBrief vVoTransactionBrief = vList.get(0);
			long vTransactionNo = vVoTransactionBrief.getTransactionNo();

			BigDecimal balanceChange = vVoTransactionBrief
					.getSumBalanceChange();
			String vAuthorizationNumber = calculateAuthorizationNumberBasedOnCardAndBalanceChange(
					accountNumber, checkDigit, balanceChange);

			mCategory.info("Authorization for transaction no " + vTransactionNo
					+ " '" + vAuthorizationNumber + "'.");

			// Check to see if we already have an authorization for this
			// transaction
			Authorization vAuthorization = mBefAuthorization
					.findByTransactionNo(vTransactionNo);

			// Not OK
			if (vAuthorization != null) {
				throw new AuthorizationException(
						"Authorization already exists for transaction no "
								+ vTransactionNo + ".");
			} else if (Amounts
					.isZero(vVoTransactionBrief.getSumBalanceChange())) {
				throw new AuthorizationAmountException(
						"No amounts available on this card, balance is '0'.");
			}

			// Create new authorization
			vAuthorization = mBefAuthorization.create();
			vAuthorization.setAuthorizationNumber(vAuthorizationNumber);
			vAuthorization.setTransactionNo(vTransactionNo);
			mBefAuthorization.save(vAuthorization);

			// Construct VO for the authorization
			VoAuthorization vVoAuthorization = new VoAuthorization();
			vVoAuthorization.setAuthorizationNumber(vAuthorizationNumber);
			vVoAuthorization.setAmount(vVoTransactionBrief
					.getSumBalanceChange());

			vVoAuthorization.setCurrencyCode(vVoTransactionBrief
					.getRequestedCurrencyCode());

			// If transaction is from client then check if requested amount is
			// matching the balance change.
			if (vVoTransactionBrief.getSourceSystem() != null
					&& filterSourceSystemToAllowManualTransaction(vVoTransactionBrief.getSourceSystem())) {
				// If requested amount is different from balanceChange set flag
				// amountsMismatch=true
				checkBalanceChange(vVoAuthorization, vVoTransactionBrief);
			}

			return vVoAuthorization;
		} else {
			throw new AuthorizationException(
					"Transaction can not be determined");
		}

	}

	private boolean filterSourceSystemToAllowManualTransaction(String sourceSystem) {
		String vHost = mEbcProperties.getString("FilterSourceSystemToAllowManualTransaction","NOSOURCE");
		ArrayList<String> vHostList = new  ArrayList<String>(Arrays.asList(vHost.split(",")));
		return vHostList.contains(sourceSystem);
	}


	protected String calculateAuthorizationNumberBasedOnCardAndBalanceChange(
			String accountNumber, int checkDigit, BigDecimal balanceChange) {

		String accountNumberSubstring = accountNumber.substring(accountNumber
				.length() - 2);
		String checkDigitString = String.valueOf(checkDigit);
		char balanceChangeDigitString = balanceChange.toString().charAt(0);
		return CheckDigits.generateAuthorizationNumber(accountNumberSubstring + checkDigitString
				+ balanceChangeDigitString);
	}

	protected String calculateAuthorizationNumber()
			throws ValueMissingException {

		requireTransactions();

		// Use the same for all in this scope
		if (mAuthorizationNumber != null) {
			mCategory.info("Using same authorization number '"
					+ mAuthorizationNumber + "'.");
			return mAuthorizationNumber;
		}

		// Generate a new one base on these transactions
		BigDecimal vSum = Amounts.zero();
		for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
			Transaction vTransaction = (Transaction) i.next();
			vSum = Amounts.add(vSum, vTransaction.getBalanceChange());
		}

		// Generate an authorization number
		mAuthorizationNumber = CheckDigits.generateAuthorizationNumber();
		mCategory.info("Generated new authorization number '"
				+ mAuthorizationNumber + "'.");
		return mAuthorizationNumber;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#compressBrief()
	 */
	public List<VoTransactionBrief> compressBrief() throws ValueMissingException {

		List<VoTransactionBrief> vVoTransactionBriefList = new ArrayList<VoTransactionBrief>();

		requireTransactions();

		Collection<Map<String, Object>> vMapValuesList = getCompressedMapValues();
		for (Iterator<Map<String, Object>> i = vMapValuesList.iterator(); i
				.hasNext();) {
			Map<String, Object> vMapValus = i.next();
			VoTransactionBrief vVoTransactionBrief = new VoTransactionBrief();
			ValueObjects.assignFromMap(vVoTransactionBrief, vMapValus);

			vVoTransactionBriefList.add(vVoTransactionBrief);
		}
		return vVoTransactionBriefList;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#compressCard()
	 */
	public List<VoTransactionCard> compressCard() throws ValueMissingException {

		List<VoTransactionCard> vVoTransactionCardList = new ArrayList<VoTransactionCard>();

		requireTransactions();
		requireCard();

		Collection<Map<String, Object>> vMapValuesList = getCompressedMapValues();
		for (Iterator<Map<String, Object>> i = vMapValuesList.iterator(); i
				.hasNext();) {
			Map<String, Object> vMapValus = i.next();
			VoTransactionCard vVoTransactionCard = new VoTransactionCard();
			ValueObjects.assignFromMap(vVoTransactionCard, vMapValus);

			// Set specific Card values from entity
			vVoTransactionCard.setCardState(mCard.getCardState());
			vVoTransactionCard.setCardType(mCard.getCardType());
			vVoTransactionCard.setCardNumberString(mBecFactory
					.createBecCardNumber().composeCardNumberString(
							mCard.getCardNumber()));

			// Set Authorization
			Authorization vAuthorization = mBefAuthorization
					.findByTransactionNo(vVoTransactionCard.getTransactionNo());
			if (vAuthorization != null) {
				vVoTransactionCard.setAuthorizationNumber(vAuthorization
						.getAuthorizationNumber());
			}

			vVoTransactionCardList.add(vVoTransactionCard);

		}
		return vVoTransactionCardList;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#compressDetailed()
	 */
	public List<VoTransaction> compressDetailed() throws ValueMissingException {
		List<VoTransaction> vVoTransactionList = new ArrayList<VoTransaction>();

		requireTransactions();

		Collection<Map<String, Object>> vMapValuesList = getCompressedMapValues();
		for (Iterator<Map<String, Object>> i = vMapValuesList.iterator(); i
				.hasNext();) {
			Map<String, Object> vMapValus = i.next();
			VoTransaction vVoTransaction = new VoTransaction();
			ValueObjects.assignFromMap(vVoTransaction, vMapValus);

			vVoTransaction
			.setVoTransactionDetailList((List<VoTransactionDetail>) vMapValus
					.get("List<VoTransactionDetail>"));

			vVoTransactionList.add(vVoTransaction);
		}
		return vVoTransactionList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecTransactions#compressReport()
	 */
	public List<VoReportTransaction> compressReport()
			throws ValueMissingException {
		List<VoReportTransaction> vVoReportTransactionList = new ArrayList<VoReportTransaction>();

		requireTransactions();

		Collection<Map<String, Object>> vMapValuesList = getCompressedMapValues();
		for (Iterator<Map<String, Object>> i = vMapValuesList.iterator(); i
				.hasNext();) {
			Map<String, Object> vMapValus = i.next();
			VoReportTransaction vVoReportTransaction = new VoReportTransaction();
			ValueObjects.assignFromMap(vVoReportTransaction, vMapValus);

			vVoReportTransaction
			.setVoTransactionDetailList((List<VoTransactionDetail>) vMapValus
					.get("List<VoTransactionDetail>"));

			vVoReportTransactionList
			.add(vVoReportTransaction);
		}
		return vVoReportTransactionList;
	}

	// ---------- Internal methods, must be protected so unit tests can access
	// them ----------

	/**
	 * Fill the VO list with transaction values in a collection of value maps.
	 * Then can the value maps be used to create VoTransaction,
	 * VoTransactionBrief, VoReportTransaction or TransactionCard.
	 */
	protected Collection<Map<String, Object>> getCompressedMapValues()
			throws ValueMissingException {

		requireTransactions();

		// Group them into a map structure to compress the info
		Map<Long, Map<String, Object>> vMap = new TreeMap<Long, Map<String, Object>>();
		Map<String, Object> vVoTransactionValues;

		for (Iterator<Transaction> i = mTransactions.iterator(); i.hasNext();) {
			Transaction vTransaction = i.next();

			if (vMap.containsKey(new Long(vTransaction.getTransactionNo()))) {
				vVoTransactionValues = vMap.get(new Long(vTransaction
						.getTransactionNo()));
				// If one of them is insufficient amount then set to true
				if (vTransaction.getInsufficientAmount()) {
					vVoTransactionValues.put("insufficientAmount",
							CodeGeneration.toObject(true));
				}
				// Take the largest and set as requested redeem amount
				if (Amounts.isLessOrEqual((BigDecimal) vVoTransactionValues
						.get("requestedAmount"), vTransaction
						.getRequestedAmount())) {
					vVoTransactionValues.put("requestedAmount", vTransaction
							.getRequestedAmount());
				}
			} else {
				vVoTransactionValues = new HashMap<String, Object>();
				vVoTransactionValues = vTransaction.assignToMap();
				// Create initial values and details list
				vVoTransactionValues.put("sumBalanceChange", Amounts.zero());
				vVoTransactionValues
				.put("sumCardBalanceChange", Amounts.zero());
				vVoTransactionValues.put("List<VoTransactionDetail>",
						new ArrayList<VoTransactionDetail>());

				vMap.put(new Long(vTransaction.getTransactionNo()),
						vVoTransactionValues);
			}
			// Add the sums
			vVoTransactionValues.put("sumBalanceChange", Amounts.add(
					(BigDecimal) vVoTransactionValues.get("sumBalanceChange"),
					vTransaction.getBalanceChange()));
			vVoTransactionValues.put("sumCardBalanceChange", Amounts.add(
					(BigDecimal) vVoTransactionValues
					.get("sumCardBalanceChange"), vTransaction
					.getCardBalanceChange()));

			// Add detail row to details list
			addDetails((List<VoTransactionDetail>) vVoTransactionValues
					.get("List<VoTransactionDetail>"), vTransaction);
		}
		return vMap.values();
	}

	/**
	 * @param pList
	 * @param pTransaction
	 */
	private void addDetails(List<VoTransactionDetail> pList,
			Transaction pTransaction) {

		VoTransactionDetail vVoTransactionDetail = new VoTransactionDetail();
		ValueObjects.assignToValueObject(vVoTransactionDetail, pTransaction);
		pList.add(vVoTransactionDetail);
	}

	/**
	 * @param pBusinessUnitEnvironment
	 * @return
	 */
	protected BecTransactions initBusinessUnitEnvironment(
			BusinessUnitEnvironment pBusinessUnitEnvironment) {

		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		return this;
	}

	/**
	 * @param pTransactionEnvironment
	 * @return
	 */
	protected BecTransactions initTransactionEnvironment(
			TransactionEnvironment pTransactionEnvironment) {

		mTransactionEnvironment = pTransactionEnvironment;
		return this;
	}

	/**
	 * @param pTransaction
	 * @throws ValueMissingException
	 */
	protected void undoAmount(Transaction pTransaction)
			throws ValueMissingException, AmountException {

		if (pTransaction.getAmount() == null
				&& Amounts.isZero(pTransaction.getCardBalanceChange())) {
			// No amount connected to this transaction since it is a zero
			// tranaction. Just return.
			mCategory.info("No amount connected to transaction id "
					+ pTransaction.getTransactionId() + " skipping undo.");
			return;
		}

		BecAmount vBecAmount = mBecFactory.createBecAmount().init(null,
				pTransaction.getAmount(), mBusinessUnitEnvironment,
				mTransactionEnvironment);
		// Undo load or redeem transaction.
		if (Constants.TRANSACTION_TYPE_CONSTANT_LOAD.equals(pTransaction
				.getTransactionType())) {

			VoLoadAmount vVoLoadAmount = new VoLoadAmount();
			vVoLoadAmount.setLoadAmount(pTransaction.getCardBalanceChange());
			mCategory.info("Undoing load of " + vVoLoadAmount.getLoadAmount());
			vBecAmount.undoLoad(vVoLoadAmount);
		} else if (Constants.TRANSACTION_TYPE_CONSTANT_REDEEM
				.equals(pTransaction.getTransactionType())) {

			VoRedeemAmount vVoRedeemAmount = new VoRedeemAmount();
			vVoRedeemAmount
			.setRedeemAmount(pTransaction.getCardBalanceChange());
			mCategory.info("Undoing redeem of "
					+ vVoRedeemAmount.getRedeemAmount());
			vBecAmount.undoRedeem(vVoRedeemAmount);
		} else {
			throw new IllegalStateException("Internal error: Transaction type "
					+ pTransaction.getTransactionType()
					+ " can not be canceled.");
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactionEnvironment() throws ValueMissingException {
		if (mTransactionEnvironment == null)
			throw new ValueMissingException(
					"Tried to use BecTransactions without required Transaction Environment.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireTransactions() throws ValueMissingException {
		if (mTransactions == null)
			throw new ValueMissingException(
					"Tried to use BecTransactions without required Transactions.");
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCard() throws ValueMissingException {
		if (mCard == null)
			throw new ValueMissingException(
					"Tried to use BecTransactions without required Card.");
	}

	/**
	 * 
	 */
	protected void requireVoTransactionKey() throws ValueMissingException {
		if (mVoTransactionKey == null)
			throw new ValueMissingException(
					"Tried to use BecTransactions without required VoTransactionKey.");

	}

	protected VoAuthorization AuthorizationForCancelledTransaction(BigDecimal pAmount,String pCurrencyCode)
	{
		VoAuthorization authorization= new VoAuthorization();
		authorization.setAmount(pAmount);
		authorization.setAmountsMismatch(false);
		authorization.setAuthorizationNumber("00000");
		authorization.setCurrencyCode(pCurrencyCode);
		mCategory.info("Generating Authorization For Cancelled Transaction");
		return authorization;
		
	}


}
