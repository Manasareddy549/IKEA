/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.bec.BecFactory;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;

public class BefFactoryImpl implements BefFactory {

	private BefKPI mBefKPI = null;
	private BefCountrySetup mBefCountrySetup = null;
	private BefReport mBefReport = null;
	private BefReferenceCheck mBefReferenceCheck = null;
	private BefCampaign mBefCampaign = null;
	private BefMassLoad mBefMassLoad = null;
	private BefRange mBefRange = null;
	private BefCardTypeConstant mBefCardTypeConstant = null;
	private BefAmount mBefAmount = null;
	private BefCard mBefCard = null;
	private BefCardNumber mBefCardNumber = null;
	private BefLifeCycle mBefLifeCycle = null;
	private BefTransaction mBefTransaction = null;
	private BefParameter mBefParameter = null;
	private BefAuthorization mBefAuthorization = null;
	private BefSourceSystemConstant mBefSourceSystemConstant = null;
	private BefActivation mBefActivation = null;
	private BefCampaignLimitation mBefCampaignLimitation = null;
	private BefBonusCode mBefBonusCode = null;
	private BefBonus mBefBonus = null;
	private BefTransactionFilter mBefTransactionFilter = null;
	private BefCountry mBefCountry = null;
	private BefExchangeRate mBefExchangeRate = null;
	private BefExchangeModeConstant mBefExchangeModeConstant = null;
	private BefExternalCard mBefExternalCard = null;
	private BefExternalCardSystem mBefExternalCardSystem = null;
	private BefMainCurrency mBefMainCurrency = null;
	private BefExchangeRateSpread mBefExchangeRateSpread = null;
	private BefConstants mBefConstants = null;
	private BefIpayBusinessUnits mBefIpayBusinessUnits = null;
	private BefUnacknowledgedTimeout mBefUnacknowledgedTimeout = null;
	private BefSarecReport mBefSarecReport = null;
	private BefExternalTempCard mBefExternalTempCard = null;	
	private BefCnCardBatchJob mBefCnCardBatchJob = null;
	private BefCnCard mBefCnCard = null;
	private BefReasonCodeTransaction mBefReasonCodeTransaction = null;
	private BefReasonCode mBefReasonCode = null;
	private EncryptionDecryption mEncryptionDecryption=null;
	private BefBsLog mBefBsLog = null;
	private BefCustomerType mBefCustomerType = null;
	private BefMessage mBefMessage = null;
	private BefReservedCardHistory mBefReservedCardHistory = null;
	
	@Autowired
	BecFactory becFactory;
	
	@Autowired
	UtilsFactory utilsFactory;
	
		/**
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	protected BefFactoryImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {

		mBefKPI = new BefKPIImpl(pSessionFactory, pTimeSource);
		mBefCountrySetup = new BefCountrySetupImpl(pSessionFactory, pTimeSource);
		mBefReport = new BefReportImpl(pSessionFactory, pTimeSource);
		mBefReferenceCheck = new BefReferenceCheckImpl(pSessionFactory,
				pTimeSource);
		mBefCampaign = new BefCampaignImpl(pSessionFactory, pTimeSource);
		mBefMassLoad = new BefMassLoadImpl(pSessionFactory, pTimeSource);
		mBefRange = new BefRangeImpl(pSessionFactory, pTimeSource);
		mBefCardTypeConstant = new BefCardTypeConstantImpl(pSessionFactory,
				pTimeSource);
		mBefAmount = new BefAmountImpl(pSessionFactory, pTimeSource);
		mBefCard = new BefCardImpl(pSessionFactory, pTimeSource);
		mBefCardNumber = new BefCardNumberImpl(pSessionFactory, pTimeSource);
		mBefLifeCycle = new BefLifeCycleImpl(pSessionFactory, pTimeSource);
		mBefTransaction = new BefTransactionImpl(pSessionFactory, pTimeSource);
		mBefParameter = new BefParameterImpl(pSessionFactory, pTimeSource);
		mBefAuthorization = new BefAuthorizationImpl(pSessionFactory,
				pTimeSource);
		mBefSourceSystemConstant = new BefSourceSystemConstantImpl(
				pSessionFactory, pTimeSource);
		mBefActivation = new BefActivationImpl(pSessionFactory, pTimeSource);
		mBefCampaignLimitation = new BefCampaignLimitationImpl(pSessionFactory,
				pTimeSource);
		mBefBonusCode = new BefBonusCodeImpl(pSessionFactory, pTimeSource);
		mBefBonus = new BefBonusImpl(pSessionFactory, pTimeSource);
		mBefTransactionFilter = new BefTransactionFilterImpl(pSessionFactory,
				pTimeSource);
		mBefCountry = new BefCountryImpl(pSessionFactory, pTimeSource);
		mBefExchangeRate = new BefExchangeRateImpl(pSessionFactory, pTimeSource);
		mBefExchangeModeConstant = new BefExchangeModeConstantImpl(
				pSessionFactory, pTimeSource);
		mBefExternalCard = new BefExternalCardImpl(pSessionFactory, pTimeSource);
		mBefExternalCardSystem = new BefExternalCardSystemImpl(pSessionFactory,
				pTimeSource);
		mBefMainCurrency = new BefMainCurrencyImpl(pSessionFactory, pTimeSource);
		mBefExchangeRateSpread = null;
		mBefConstants = new BefConstantsImpl(pSessionFactory);
		mBefUnacknowledgedTimeout=new BefUnacknowledgedTimeoutImpl(pSessionFactory, pTimeSource);
		mBefSarecReport = new BefSarecReportImpl(pSessionFactory, pTimeSource, becFactory, utilsFactory,mEncryptionDecryption);
		mBefExternalTempCard = new BefExternalTempCardImpl(pSessionFactory,pTimeSource);
		mBefCnCardBatchJob=new BefCnCardBatchJobImpl(pSessionFactory,pTimeSource);
		mBefCnCard=new BefCnCardImpl(pSessionFactory,pTimeSource);
		mBefReasonCodeTransaction=new BefReasonCodeTransactionImp(pSessionFactory,pTimeSource);
		mBefReasonCode=new BefReasonCodeImpl(pSessionFactory,pTimeSource);
		mBefBsLog=new BefBsLogImpl(pSessionFactory,pTimeSource);
		mBefCustomerType=new BefCustomerTypeImpl(pSessionFactory,pTimeSource);
		mBefMessage = new BefMessageImpl(pSessionFactory,pTimeSource);
		mBefReservedCardHistory = new BefReservedCardHistoryImpl(pSessionFactory,pTimeSource); 
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefKPI()
	 */
	public BefKPI getBefKPI() {
		return mBefKPI;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCountrySetup()
	 */
	public BefCountrySetup getBefCountrySetup() {
		return mBefCountrySetup;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefReport()
	 */
	public BefReport getBefReport() {
		return mBefReport;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefReferenceCheck()
	 */
	public BefReferenceCheck getBefReferenceCheck() {
		return mBefReferenceCheck;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCampaign()
	 */
	public BefCampaign getBefCampaign() {
		return mBefCampaign;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefMassLoad()
	 */
	public BefMassLoad getBefMassLoad() {
		return mBefMassLoad;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefRange()
	 */
	public BefRange getBefRange() {
		return mBefRange;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCardTypeConstant()
	 */
	public BefCardTypeConstant getBefCardTypeConstant() {
		return mBefCardTypeConstant;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefAmount()
	 */
	public BefAmount getBefAmount() {
		return mBefAmount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCard()
	 */
	public BefCard getBefCard() {
		return mBefCard;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCardNumber()
	 */
	public BefCardNumber getBefCardNumber() {
		return mBefCardNumber;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefLifeCycle()
	 */
	public BefLifeCycle getBefLifeCycle() {
		return mBefLifeCycle;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefTransaction()
	 */
	public BefTransaction getBefTransaction() {
		return mBefTransaction;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefParameter()
	 */
	public BefParameter getBefParameter() {
		return mBefParameter;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefAuthorization()
	 */
	public BefAuthorization getBefAuthorization() {
		return mBefAuthorization;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefSourceSystemConstant
	 * ()
	 */
	public BefSourceSystemConstant getBefSourceSystemConstant() {
		return mBefSourceSystemConstant;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefActivation()
	 */
	public BefActivation getBefActivation() {
		return mBefActivation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCampaignLimitation
	 * ()
	 */
	public BefCampaignLimitation getBefCampaignLimitation() {
		return mBefCampaignLimitation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefBonus()
	 */
	public BefBonusCode getBefBonusCode() {
		return mBefBonusCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefBonus()
	 */
	public BefBonus getBefBonus() {
		return mBefBonus;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefTransactionFilter()
	 */
	public BefTransactionFilter getBefTransactionFilter() {
		return mBefTransactionFilter;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefCountry()
	 */
	public BefCountry getBefCountry() {
		return mBefCountry;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefExchangeRate()
	 */
	public BefExchangeRate getBefExchangeRate() {
		return mBefExchangeRate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ikea.ebccardpay1.cardpayment.bef.BefFactory#
	 * getBefExchangeRateModeConstant()
	 */
	public BefExchangeModeConstant getBefExchangeModeConstant() {
		return mBefExchangeModeConstant;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefExternalCard()
	 */
	public BefExternalCard getBefExternalCard() {
		return mBefExternalCard;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefExternalCardSystem
	 * ()
	 */
	public BefExternalCardSystem getBefExternalCardSystem() {
		return mBefExternalCardSystem;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefFactory#getBefMainCurrency()
	 */
	public BefMainCurrency getBefMainCurrency() {
		return mBefMainCurrency;
	}

	public BefExchangeRateSpread getBefExchangeRateSpread() {
		return mBefExchangeRateSpread;
	}

	public BefConstants getBefConstants() {
		return mBefConstants;
	}

	public BefIpayBusinessUnits getBefIpayBusinessUnits() {
		return mBefIpayBusinessUnits;
	}

	public BefUnacknowledgedTimeout getBefUnacknowledgedTimeout() {
		return mBefUnacknowledgedTimeout;
	}
	
	public BefSarecReport getBefSarecReport() {
		return mBefSarecReport;
	}
	
	public BefExternalTempCard getBefExternalTempCard() {
		return mBefExternalTempCard;
	}

	@Override
	public BefCnCardBatchJob getBefCnCardBatchJob() {
		// TODO Auto-generated method stub
		return mBefCnCardBatchJob;
	}

	@Override
	public BefCnCard getBefCnCard() {
		// TODO Auto-generated method stub
		return mBefCnCard;
	}
	
	@Override
	public BefReasonCodeTransaction getBefReasonCodeTransaction() {
		return mBefReasonCodeTransaction;
	}
	
	@Override
	public BefReasonCode getBefReasonCode() {
		return mBefReasonCode;
	}
	
	@Override
	public BefBsLog getBefBsLog() {
		return mBefBsLog;
	}
	
	@Override
	public BefCustomerType getBefCustomerType() {
		return mBefCustomerType;
	}

	@Override
	public BefMessage getBefMessage() {
		return mBefMessage;
	}
	@Override
	public BefReservedCardHistory getBefReservedCardHistory() {
		return mBefReservedCardHistory;
	}

}