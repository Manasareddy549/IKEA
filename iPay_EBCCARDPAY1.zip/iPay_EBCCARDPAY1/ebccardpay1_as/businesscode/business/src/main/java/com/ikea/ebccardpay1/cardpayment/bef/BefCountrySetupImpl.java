/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.ebccardpay1.cardpayment.be.CountrySetup;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 *
 */
public class BefCountrySetupImpl extends BefAbstract<CountrySetup> implements BefCountrySetup {

	private final static Logger mCategory_findByCountryCode =
		LoggerFactory.getLogger(
			BefCountrySetupImpl.class.getName() + ".findByCountryCode");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCountrySetupImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefCountrySetup#findByUnique(java.lang.String, java.lang.String)
	 */
	@Transactional(propagation = Propagation.SUPPORTS)
	public CountrySetup findByUnique(String pCountryCode, String pCardType) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		Criteria vCriteria = vSession.createCriteria(CountrySetup.class);
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria.add(Restrictions.eq("cardType", pCardType));

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByCountryCode.isDebugEnabled()) {
			mCategory_findByCountryCode.debug(
				"Criteria: " + vCriteria.toString());
		}

		return (CountrySetup) vCriteria.uniqueResult();
	}

	@Override
	protected Class<CountrySetup> getBusinessEntityClass() {
		return CountrySetup.class;
	}
}
