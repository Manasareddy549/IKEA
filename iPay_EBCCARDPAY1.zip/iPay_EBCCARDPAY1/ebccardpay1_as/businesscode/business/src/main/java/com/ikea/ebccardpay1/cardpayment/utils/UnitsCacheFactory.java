package com.ikea.ebccardpay1.cardpayment.utils;
import static org.apache.commons.lang.Validate.notNull;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.cache.IkeaCacheFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

/**
 */

public class UnitsCacheFactory implements InitializingBean {

	@Autowired
	private BefIpayBusinessUnits  mBefIpayBusinessUnits;
	

    private final IkeaCacheFactory ikeaCacheFactory;

    @Autowired
    public UnitsCacheFactory(IkeaCacheFactory ikeaCacheFactory){
        notNull(ikeaCacheFactory);
        this.ikeaCacheFactory = ikeaCacheFactory;
    }

    @SuppressWarnings("unchecked")
    public UnitsCache build() {
        // Normal usage of the IkeaCacheFactory
        UnitsCacheImpl cache = (UnitsCacheImpl)ikeaCacheFactory.getCache(UnitsCacheImpl.class.getName(), null);
        // Followed by custom wiring, impossible to achieve with Spring
        cache.setBefIpayBusinessUnits(mBefIpayBusinessUnits);
        return cache;
    }

	//@Override
	public void afterPropertiesSet() throws Exception {
		notNull(mBefIpayBusinessUnits);		
	}


}