/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class Card extends BusinessEntity {
	/**										
	 * Storage: CARD_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mCardId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private CardNumber mCardNumber;
	private java.util.Set<Transaction> mTransactions = new java.util.LinkedHashSet<Transaction>(0);
	private java.util.Set<LifeCycle> mLifeCycles = new java.util.LinkedHashSet<LifeCycle>(0);
	private java.util.Set<Amount> mAmounts = new java.util.LinkedHashSet<Amount>(0);
	private java.util.Set<ReferenceCheck> mReferenceCheck = new java.util.LinkedHashSet<ReferenceCheck>(0);
	private ExternalCard mExternalCard;

	/**										
	 * Data								
	 */										
	private String mCardState;
	private String mCurrencyCode;
	private java.util.Date mLastLifeCycleDateTime;
	private java.util.Date mLastTransactionDateTime;
	private String mCountryCode;
	private String mCardType;
	private java.util.Date mExpireDate;

	/**											
	 * @return Returns the cardId.													
	 */											
	public long getCardId() {
		return mCardId;
	}
	/**
	 * @param pCardId The cardId to set.
	 */
	public void setCardId(long pCardId) {
		mCardId = pCardId;
	}

	/**											
	 * @return Returns the cardState.													
	 */											
	public String getCardState() {
		return mCardState;
	}
	/**
	 * @param pCardState The cardState to set.
	 */
	public void setCardState(String pCardState) {
		mCardState = pCardState;
	}

	/**											
	 * @return Returns the currencyCode.													
	 */											
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	/**
	 * @param pCurrencyCode The currencyCode to set.
	 */
	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	/**											
	 * @return Returns the lastLifeCycleDateTime.													
	 */											
	public java.util.Date getLastLifeCycleDateTime() {
		return mLastLifeCycleDateTime;
	}
	/**
	 * @param pLastLifeCycleDateTime The lastLifeCycleDateTime to set.
	 */
	public void setLastLifeCycleDateTime(java.util.Date pLastLifeCycleDateTime) {
		mLastLifeCycleDateTime = pLastLifeCycleDateTime;
	}

	/**											
	 * @return Returns the lastTransactionDateTime.													
	 */											
	public java.util.Date getLastTransactionDateTime() {
		return mLastTransactionDateTime;
	}
	/**
	 * @param pLastTransactionDateTime The lastTransactionDateTime to set.
	 */
	public void setLastTransactionDateTime(java.util.Date pLastTransactionDateTime) {
		mLastTransactionDateTime = pLastTransactionDateTime;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the cardType.													
	 */											
	public String getCardType() {
		return mCardType;
	}
	/**
	 * @param pCardType The cardType to set.
	 */
	public void setCardType(String pCardType) {
		mCardType = pCardType;
	}

	/**											
	 * @return Returns the expireDate.													
	 */											
	public java.util.Date getExpireDate() {
		return mExpireDate;
	}
	/**
	 * @param pExpireDate The expireDate to set.
	 */
	public void setExpireDate(java.util.Date pExpireDate) {
		mExpireDate = pExpireDate;
	}

	/**											
	 * @return Returns the cardNumber.													
	 */											
	public CardNumber getCardNumber() {
		return mCardNumber;
	}
	/**
	 * @param pCardNumber The cardNumber to set.
	 */
	public void setCardNumber(CardNumber pCardNumber) {
		mCardNumber = pCardNumber;
	}

	/**											
	 * @return Returns the transactions.													
	 */											
	public java.util.Set<Transaction> getTransactions() {
		return mTransactions;
	}
	/**
	 * @param pTransactions The transactions to set.
	 */
	public void setTransactions(java.util.Set<Transaction> pTransactions) {
		mTransactions = pTransactions;
	}

	/**											
	 * @return Returns the lifeCycles.													
	 */											
	public java.util.Set<LifeCycle> getLifeCycles() {
		return mLifeCycles;
	}
	/**
	 * @param pLifeCycles The lifeCycles to set.
	 */
	public void setLifeCycles(java.util.Set<LifeCycle> pLifeCycles) {
		mLifeCycles = pLifeCycles;
	}

	/**											
	 * @return Returns the amounts.													
	 */											
	public java.util.Set<Amount> getAmounts() {
		return mAmounts;
	}
	/**
	 * @param pAmounts The amounts to set.
	 */
	public void setAmounts(java.util.Set<Amount> pAmounts) {
		mAmounts = pAmounts;
	}

	/**											
	 * @return Returns the referenceCheck.													
	 */											
	public java.util.Set<ReferenceCheck> getReferenceCheck() {
		return mReferenceCheck;
	}
	/**
	 * @param pReferenceCheck The referenceCheck to set.
	 */
	public void setReferenceCheck(java.util.Set<ReferenceCheck> pReferenceCheck) {
		mReferenceCheck = pReferenceCheck;
	}

	/**											
	 * @return Returns the externalCard.													
	 */											
	public ExternalCard getExternalCard() {
		return mExternalCard;
	}
	/**
	 * @param pExternalCard The externalCard to set.
	 */
	public void setExternalCard(ExternalCard pExternalCard) {
		mExternalCard = pExternalCard;
	}

	/**
	 * Connect CardNumber.
	 * @param pCardNumber
	 */
	public void connectCardNumber(CardNumber pCardNumber) {
		setCardNumber(pCardNumber);
		if(pCardNumber != null) {
			pCardNumber.setCard(this);
		}
	}

	/**
	 * Disconnect CardNumber.
	 */
	public void disconnectCardNumber() {
		if(getCardNumber() != null) {
			getCardNumber().setCard(null);
		}
		setCardNumber(null);
	}

	/**
	 * Connect a Transaction.
	 * @param pTransaction
	 */
	public void connectTransaction(Transaction pTransaction) {
		getTransactions().add(pTransaction);
		if(pTransaction != null) {
			pTransaction.setCard(this);
		}
	}

	/**
	 * Disconnect a Transaction.
	 * @param pTransaction
	 */
	public void disconnectTransaction(Transaction pTransaction) {
		if(pTransaction != null) {
			pTransaction.setCard(null);
		}
		getTransactions().remove(pTransaction);
	}

	/**
	 * Connect a LifeCycle.
	 * @param pLifeCycle
	 */
	public void connectLifeCycle(LifeCycle pLifeCycle) {
		getLifeCycles().add(pLifeCycle);
		if(pLifeCycle != null) {
			pLifeCycle.setCard(this);
		}
	}

	/**
	 * Disconnect a LifeCycle.
	 * @param pLifeCycle
	 */
	public void disconnectLifeCycle(LifeCycle pLifeCycle) {
		if(pLifeCycle != null) {
			pLifeCycle.setCard(null);
		}
		getLifeCycles().remove(pLifeCycle);
	}

	/**
	 * Connect a Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		getAmounts().add(pAmount);
		if(pAmount != null) {
			pAmount.setCard(this);
		}
	}

	/**
	 * Disconnect a Amount.
	 * @param pAmount
	 */
	public void disconnectAmount(Amount pAmount) {
		if(pAmount != null) {
			pAmount.setCard(null);
		}
		getAmounts().remove(pAmount);
	}

	/**
	 * Connect a ReferenceCheck.
	 * @param pReferenceCheck
	 */
	public void connectReferenceCheck(ReferenceCheck pReferenceCheck) {
		getReferenceCheck().add(pReferenceCheck);
		if(pReferenceCheck != null) {
			pReferenceCheck.setCard(this);
		}
	}

	/**
	 * Disconnect a ReferenceCheck.
	 * @param pReferenceCheck
	 */
	public void disconnectReferenceCheck(ReferenceCheck pReferenceCheck) {
		if(pReferenceCheck != null) {
			pReferenceCheck.setCard(null);
		}
		getReferenceCheck().remove(pReferenceCheck);
	}

	/**
	 * Connect ExternalCard.
	 * @param pExternalCard
	 */
	public void connectExternalCard(ExternalCard pExternalCard) {
		setExternalCard(pExternalCard);
		if(pExternalCard != null) {
			pExternalCard.setCard(this);
		}
	}

	/**
	 * Disconnect ExternalCard.
	 */
	public void disconnectExternalCard() {
		if(getExternalCard() != null) {
			getExternalCard().setCard(null);
		}
		setExternalCard(null);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mCardId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("cardId", CodeGeneration.toObject(mCardId));
		vMap.put("cardState", CodeGeneration.toObject(mCardState));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("lastLifeCycleDateTime", CodeGeneration.toObject(mLastLifeCycleDateTime));
		vMap.put("lastTransactionDateTime", CodeGeneration.toObject(mLastTransactionDateTime));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("cardType", CodeGeneration.toObject(mCardType));
		vMap.put("expireDate", CodeGeneration.toObject(mExpireDate));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("cardId")) mCardId = CodeGeneration.objectTolong(pMap.get("cardId"));
		if(pMap.containsKey("cardState")) mCardState = CodeGeneration.objectToString(pMap.get("cardState"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("lastLifeCycleDateTime")) mLastLifeCycleDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("lastLifeCycleDateTime"));
		if(pMap.containsKey("lastTransactionDateTime")) mLastTransactionDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("lastTransactionDateTime"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("cardType")) mCardType = CodeGeneration.objectToString(pMap.get("cardType"));
		if(pMap.containsKey("expireDate")) mExpireDate = CodeGeneration.objectTojava_util_Date(pMap.get("expireDate"));
	}
}
