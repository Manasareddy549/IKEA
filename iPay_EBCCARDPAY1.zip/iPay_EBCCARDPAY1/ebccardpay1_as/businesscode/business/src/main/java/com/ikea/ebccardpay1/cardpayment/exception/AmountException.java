/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 */
public class AmountException extends CardPayException {

	private static final long serialVersionUID = -8531407424370864248L;

	public AmountException() {
		super();
	}
	public AmountException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidAmount();
	}
}
