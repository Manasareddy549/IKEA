package com.ikea.ebccardpay1.cardpayment.bef;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.CnCardBatchJob;
import com.ikea.ebccardpay1.cardpayment.bec.BecFactory;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;



public class BefCnCardBatchJobImpl extends BefAbstract<CnCardBatchJob> implements BefCnCardBatchJob{

	private BecFactory mBecFactory;

	private UtilsFactory mUtilsFactory;

	protected BefCnCardBatchJobImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
		// TODO Auto-generated constructor stub

	}

	@Override
	protected Class<CnCardBatchJob> getBusinessEntityClass() {
		// TODO Auto-generated method stub
		return CnCardBatchJob.class;
	}


	private static final Logger mLog = LoggerFactory
			.getLogger(BefCnCardBatchJobImpl.class);
   // iPay4.8.1R- Sprint2
	public List<Object[]> registerCard(String pActiveDate,String pCountry,int pRecordCount) throws ParseException {
		Session vSession = mSessionFactory.getCurrentSession();

		mLog.info("Fetching cards to register in china Site");

		String vSql2 =
				"SELECT I.TRANSACTION_ID,"
						+"  I.TRANSMISSION_DATE_TIME,"
						+"  I.SALES_DAY,"
						+"  J.AMOUNT,"
						+"  J.CARD,"
						+"  J.CARD_ID,"
						+"  J.EXPIRE_DATE"
						+" FROM TRANSACTION_T I,"
						+"  (SELECT MAX(F.TRANSACTION_ID) AS TRANSACTION_ID,"
						+"  						   H.AMOUNT," //3
						+"  						   H.CARD," //4
						+"  						   H.CARD_ID," //5
						+"  						   H.EXPIRE_DATE" //6
						+"  						 FROM TRANSACTION_T F,"
						+"  						   (SELECT D.CARD_ID,"
						+"  						     (C.ISSUER"
						+"  						     ||C.CARD_TYPE_DIGIT"
						+"                               ||C.ACCOUNT_NUMBER_ENC"
						//+"  						     ||C.ACCOUNT_NUMBER"
						+"  						     ||C.CHECK_DIGIT) AS CARD,"
						+"  						     CASE"
						+"  						       WHEN D.EXPIRE_DATE IS NULL"
						+"  						       THEN TO_DATE('31-DEC-2099', 'DD-MON-YYYY')"
						+"  						       ELSE D.EXPIRE_DATE"
						+"  						     END AS EXPIRE_DATE,"
						+"  						     E.AMOUNT,"
						+"  						     (SELECT MAX(G.CREATED_DATE_TIME)"
						+"  						     FROM TRANSACTION_T G"
						+"  						     WHERE G.CARD_ID        =D.CARD_ID"
						+"  						     AND G.SALES_DAY       <>'1900-01-01'"
						+"  						     AND G.FINANCIAL_TYPE   ='CREDIT'"
						+"  						     AND G.TRANSACTION_TYPE<>'VOID_REDEEM'"
						+"  						     ) AS CREATED_DATE_TIME"
						+"  						   FROM CARD_NUMBER_T C,"
						+"  						     CARD_T D,"
						+"  						     (SELECT B.CARD_ID,"
						+"  						       SUM("
						+"  						       CASE"
						+"  						         WHEN B.FINANCIAL_TYPE='CREDIT'"
						+"  						         THEN B.CARD_BALANCE_CHANGE"
						+"  						         WHEN B.FINANCIAL_TYPE='DEBIT'"
						+"  						         THEN (-1*B.CARD_BALANCE_CHANGE)"
						+"  						         ELSE 0"
						+"  						       END) AS AMOUNT"
						+"  						     FROM CARD_T A ,"
						+"  						       TRANSACTION_T B"
						+"  						     WHERE A.COUNTRY_CODE    =:COUNTRY_CODE"
						+"  						     AND A.CARD_TYPE         ='GIFT'"
						+"  						     AND A.CARD_STATE        ='BOUND'"
						+"  						     AND A.CREATED_DATE_TIME <:ACTIVE_DATE"
						+"  						     AND A.CARD_ID NOT      IN"
						+"  						       (SELECT CARD_ID FROM CN_CARD_T"
						+"  						       )"
						+"  						     AND B.CARD_ID    =A.CARD_ID"
						+"  						     AND B.SALES_DAY <>'1900-01-01'"
						+"  						     AND TO_DATE(B.SALES_DAY,'YYYY-MM-DD')<TO_DATE(:SALES_DAY,'YYYY-MM-DD')"
						+"  						     GROUP BY B.CARD_ID"
						+"  						     HAVING SUM("
						+"  						       CASE"
						+"  						         WHEN B.FINANCIAL_TYPE='CREDIT'"
						+"  						         THEN B.CARD_BALANCE_CHANGE"
						+"  						         WHEN B.FINANCIAL_TYPE='DEBIT'"
						+"  						         THEN (-1*B.CARD_BALANCE_CHANGE)"
						+"  						         ELSE 0"
						+"  						       END)>0"
						+"  						     ) E"
						+"  						   WHERE D.CARD_ID     =E.CARD_ID"
						+"  						   AND C.CARD_NUMBER_ID=D.CARD_NUMBER_ID"
						+"  						   ) H"
						+"  						 WHERE F.CARD_ID             =H.CARD_ID"
						+"  						 AND F.CREATED_DATE_TIME=H.CREATED_DATE_TIME"
						+"  						 AND F.FINANCIAL_TYPE        ='CREDIT'"
						+"  						 AND F.TRANSACTION_TYPE     <>'VOID_REDEEM'"
						+" GROUP BY H.CARD,"
						+" H.CARD_ID, "
						+" H.EXPIRE_DATE, "
						+" H.AMOUNT "
						+" ) J "
						+" WHERE I.TRANSACTION_ID=J.TRANSACTION_ID";
		StringBuffer vBuffer=new StringBuffer(vSql2);

		if(pRecordCount!=0)
		{
			vBuffer.append(" AND ROWNUM<=:RECORD_COUNT");
		}

		String vSql=vBuffer.toString();

		SQLQuery vQuery = vSession.createSQLQuery(vSql);
		vQuery.setString("COUNTRY_CODE", pCountry);

		vQuery.setString("SALES_DAY", pActiveDate);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");	
		Date inputdate = sdf.parse(pActiveDate);
		Calendar c1= Calendar.getInstance();
		c1.setTime(inputdate);
		c1.set(Calendar.HOUR_OF_DAY, 0);
		c1.set(Calendar.MINUTE, 0);
		c1.set(Calendar.SECOND, 0);
		c1.set(Calendar.MILLISECOND, 0);
		Date mActivedate = c1.getTime();

		vQuery.setDate("ACTIVE_DATE", mActivedate);
		if(pRecordCount!=0)
		{
			vQuery.setInteger("RECORD_COUNT", pRecordCount);
		}

		mLog.info(vQuery.getNamedParameters().toString());

		mLog.debug(vQuery.getQueryString());

		List<Object[]> rows=vQuery.list();

		if(rows!=null)
		{
			if(rows.size()>0)
			{
				mLog.info("Found "+Integer.toString(rows.size())+" Transactions");
				return rows;
			}
			else{
				mLog.info("Found Zero Transactions");
				return null;
			}
		}
		else{
			mLog.info("Found Zero Transactions");
			return null;
		}

	}



	public List<Object[]> getTransactions(String pSalesDay,String pCountry) {
		Session vSession = mSessionFactory.getCurrentSession();

		mLog.info("Fetching Transactions on salesDay basis");

		String vSql =
				"SELECT A.TRANSACTION_ID," //0
						+"     A.TRANSACTION_TYPE," //1
						+"     A.FINANCIAL_TYPE," //2
						+"     C.CARD_ID," //3
						+"     (D.ISSUER"
						+"     ||D.CARD_TYPE_DIGIT"
						+"     ||D.ACCOUNT_NUMBER_ENC"
						//+"     ||D.ACCOUNT_NUMBER"
						+"     ||D.CHECK_DIGIT) AS CARD," //4
						+"     CASE"
						+"       WHEN C.EXPIRE_DATE IS NULL"
						+"       THEN TO_DATE('31-DEC-2099', 'DD-MON-YYYY')"
						+"       ELSE C.EXPIRE_DATE" 
						+"     END AS EXPIRE_DATE," //5
						+"     A.TRANSMISSION_DATE_TIME," //6
						+"     A.SALES_DAY," //7
						+"     A.CARD_BALANCE_CHANGE," //8
						+"     CASE"
						+"       WHEN EXISTS"
						+"         (SELECT E.CARD_ID FROM CN_CARD_T E WHERE E.CARD_ID=C.CARD_ID"
						+"         )"
						+"       THEN 'Y'"
						+"       ELSE 'N'"
						+"     END AS REGISTERED," //9
						+"     A.CREATED_DATE_TIME, " //10
						+"     (SELECT SUM("
						+"       CASE"
						+"         WHEN B.FINANCIAL_TYPE='CREDIT'"
						+"         THEN B.CARD_BALANCE_CHANGE"
						+"         WHEN B.FINANCIAL_TYPE='DEBIT'"
						+"         THEN (-1*B.CARD_BALANCE_CHANGE)"
						+"         ELSE 0"
						+"       END)"
						+"     FROM TRANSACTION_T B"
						+"     WHERE CARD_ID         =A.CARD_ID"
						+"     AND CREATED_DATE_TIME<=A.CREATED_DATE_TIME"
						+"     ) AS AMOUNT" //11
						+"   FROM TRANSACTION_T A,"
						+"     CARD_T C,"
						+"     CARD_NUMBER_T D"
						+"   WHERE A.SALES_DAY         =:SALES_DAY"
						+"   AND A.CARD_BALANCE_CHANGE<>'0'"
						+"   AND C.COUNTRY_CODE        =:COUNTRY"
						+"   AND C.CARD_TYPE           ='GIFT'"
						+"   AND A.CARD_ID             =C.CARD_ID"
						+"   AND D.CARD_NUMBER_ID      =C.CARD_NUMBER_ID"
						+"   ORDER BY A.CREATED_DATE_TIME";

		SQLQuery vQuery = vSession.createSQLQuery(vSql);
		vQuery.setString("SALES_DAY", pSalesDay);
		vQuery.setString("COUNTRY", pCountry);


		mLog.debug(vQuery.getQueryString());

		List<Object[]> rows=vQuery.list();

		if(rows!=null)
		{
			if(rows.size()>0)
			{
				mLog.info("Found "+Integer.toString(rows.size())+" Transactions");
				return rows;
			}
			else{
				mLog.info("Found Zero Transactions");
				return null;
			}
		}
		else{
			mLog.info("Found Zero Transactions");
			return null;
		}

	}
	
	public List<Object[]> getCreditTransaction(long card_id,Date dateToIgnore) {
		Session vSession = mSessionFactory.getCurrentSession();

		mLog.info("Fetching latest Credit Transactions for Card ");

		String vSql =
				"SELECT I.TRANSACTION_ID,"
						+"  I.TRANSMISSION_DATE_TIME,"
						+"  I.SALES_DAY,"
						+"  J.AMOUNT,"
						+"  J.CARD,"
						+"  J.CARD_ID,"
						+"  J.EXPIRE_DATE"
						+" FROM TRANSACTION_T I,"
						+"  (SELECT MAX(F.TRANSACTION_ID) AS TRANSACTION_ID,"
						+"						  						   H.AMOUNT, "
						+"						  						   H.CARD, "
						+"						  						   H.CARD_ID, "
						+"						  						   H.EXPIRE_DATE "
						+"						  						 FROM TRANSACTION_T F,"
						+"						  						   (SELECT D.CARD_ID,"
						+"						  						     (C.ISSUER"
						+"						  						     ||C.CARD_TYPE_DIGIT"
						+"                                                   ||C.ACCOUNT_NUMBER_ENC"
						//+"						  						     ||C.ACCOUNT_NUMBER"
						+"						  						     ||C.CHECK_DIGIT) AS CARD,"
						+"						  						     CASE"
						+"						  						       WHEN D.EXPIRE_DATE IS NULL"
						+"						  						       THEN TO_DATE('31-DEC-2099', 'DD-MON-YYYY')"
						+"						  						       ELSE D.EXPIRE_DATE"
						+"						  						     END AS EXPIRE_DATE,"
						+"						  						     E.AMOUNT,"
						+"						  						     (SELECT MAX(G.CREATED_DATE_TIME)"
						+"						  						     FROM TRANSACTION_T G"
						+"						  						     WHERE G.CARD_ID        =D.CARD_ID"
						+"						  						     AND G.SALES_DAY       <>'1900-01-01'"
						+"						  						     AND G.FINANCIAL_TYPE   ='CREDIT'"
						+"						  						     AND G.TRANSACTION_TYPE<>'VOID_REDEEM'"
						+"						  						     ) AS CREATED_DATE_TIME"
						+"						  						   FROM CARD_NUMBER_T C,"
						+"						  						     CARD_T D,"
						+"						  						     (SELECT B.CARD_ID,"
						+"						  						       SUM("
						+"						  						       CASE"
						+"						  						         WHEN B.FINANCIAL_TYPE='CREDIT'"
						+"						  						         THEN B.CARD_BALANCE_CHANGE"
						+"						  						         WHEN B.FINANCIAL_TYPE='DEBIT'"
						+"						  						         THEN (-1*B.CARD_BALANCE_CHANGE)"
						+"						  						         ELSE 0"
						+"						  						       END) AS AMOUNT"
						+"						  						     FROM CARD_T A ,"
						+"						  						       TRANSACTION_T B"
						+"						  						     WHERE A.CARD_ID=:CARD_ID"
						+"						  						     AND A.CARD_ID NOT      IN"
						+"						  						       (SELECT CARD_ID FROM CN_CARD_T"
						+"						  						       )"
						+"						  						     AND B.CARD_ID    =A.CARD_ID"
						+"						  						     AND B.SALES_DAY <>'1900-01-01'"
						+"                               					 AND B.CREATED_DATE_TIME<:CREATED_DATE_TIME"
						+"						  						     GROUP BY B.CARD_ID"
						+"						  						     HAVING SUM("
						+"						  						       CASE"
						+"						  						         WHEN B.FINANCIAL_TYPE='CREDIT'"
						+"						  						         THEN B.CARD_BALANCE_CHANGE"
						+"						  						         WHEN B.FINANCIAL_TYPE='DEBIT'"
						+"						  						         THEN (-1*B.CARD_BALANCE_CHANGE)"
						+"						  						         ELSE 0"
						+"						  						       END)>0"
						+"						  						     ) E"
						+"						  						   WHERE D.CARD_ID     =E.CARD_ID"
						+"						  						   AND C.CARD_NUMBER_ID=D.CARD_NUMBER_ID"
						+"						  						   ) H"
						+"						  						 WHERE F.CARD_ID             =H.CARD_ID"
						+"						  						 AND F.CREATED_DATE_TIME=H.CREATED_DATE_TIME"
						+"						  						 AND F.FINANCIAL_TYPE        ='CREDIT'"
						+"						  						 AND F.TRANSACTION_TYPE     <>'VOID_REDEEM'"
						+" GROUP BY H.CARD,"
						+" H.CARD_ID, "
						+" H.EXPIRE_DATE, "
						+" H.AMOUNT "
						+" ) J "
						+" WHERE I.TRANSACTION_ID=J.TRANSACTION_ID";

		SQLQuery vQuery = vSession.createSQLQuery(vSql);
		
		vQuery.setLong("CARD_ID", card_id);
		vQuery.setTimestamp("CREATED_DATE_TIME",dateToIgnore);


		mLog.debug(vQuery.getQueryString());

		List<Object[]> rows=vQuery.list();

		if(rows!=null)
		{
			if(rows.size()>0)
			{
				mLog.info("Found "+Integer.toString(rows.size())+" Transactions");
				return rows;
			}
			else{
				mLog.info("Found Zero Transactions");
				return null;
			}
		}
		else{
			mLog.info("Found Zero Transactions");
			return null;
		}

	}
	


	@Override
	public List<CnCardBatchJob> getBlobFilesToRegister(String pIds) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		GenericCriteria<CnCardBatchJob> vCriteria = new GenericCriteria<CnCardBatchJob>(vSession.createCriteria(CnCardBatchJob.class));

		if(pIds!=null)
		{
			String[] mIds=pIds.split(",");
			ArrayList<Long> vIds= new ArrayList<Long>();
			for(String mId:mIds)
			{
				vIds.add(Long.parseLong(mId));
			}
			vCriteria.add(Restrictions.in("cnBatchJobId", vIds));
		}


		ArrayList<String> vStates = new ArrayList<String>();
		vStates.add("PENDING");
		vStates.add("FAILED");

		vCriteria.add(Restrictions.in("status", vStates));

		vCriteria.addOrder(Order.asc("createdDateTime"));


		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		mLog.debug("Criteria: " + vCriteria.toString());


		List<CnCardBatchJob> vList = vCriteria.list();

		if(vList!=null)
		{
			if(vList.size()>0)
			{
				mLog.info("Found "+Integer.toString(vList.size())+" Transactions");
				return vList;
			}
			else{
				mLog.info("Found Zero Transactions");
				return null;
			}
		}
		else{
			mLog.info("Found Zero Transactions");
			return null;
		}

	}

	public Blob createChinaBlobFile(String pStringData)
	{
		Session vSession = mSessionFactory.getCurrentSession();
		Blob mBlob=null;
		try {
			// Converting the string object to Blob object
			byte[] vData = pStringData.getBytes("UTF-8");
			mBlob = Hibernate.getLobCreator(vSession).createBlob(vData);

			mLog.debug("Converted file to BLOB");
		} catch (IOException e) {
			mLog.error("Unable to create file. " + e);
			mLog.debug(e.getLocalizedMessage());
		}
		return mBlob;


	}

	@Override
	public List<CnCardBatchJob> findByFlowNumber(String flowNumber) {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();
		if(flowNumber!=null)
		{
			GenericCriteria<CnCardBatchJob> vCriteria = new GenericCriteria<CnCardBatchJob>(vSession.createCriteria(CnCardBatchJob.class));

			vCriteria.add(Restrictions.eq("flowNumber", flowNumber));
			ArrayList<String> vStates = new ArrayList<String>();
			vStates.add("TRANSFERRED");
			vStates.add("FAILED");

			vCriteria.add(Restrictions.in("status", vStates));

			vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			List<CnCardBatchJob> vList = vCriteria.list();

			if(vList!=null)
			{
				if(vList.size()>0)
				{
					mLog.info("Found "+Integer.toString(vList.size())+" Transactions");
					return vList;
				}
				else{
					mLog.info("Found Zero Transactions");
					return null;
				}
			}
			else{
				mLog.info("Found Zero Transactions");
				return null;
			}

		}
		else{
			return null;
		}
	}

	
	public void deleteBatchJob(long cnJobId)
	{
		Session vSession = mSessionFactory.getCurrentSession();
		int vUpdated = 0;
		String vSql =
				"DELETE CN_CARD_T WHERE CN_BATCH_JOB_ID=:cnJobId";
		SQLQuery vQuery = vSession.createSQLQuery(vSql);
		vQuery.setLong("cnJobId", cnJobId);
		vUpdated +=vQuery.executeUpdate();
		mLog.debug("Deleted "+vUpdated+" records from CN_CARD_T");
		
		int vUpdated2 = 0;
		String vSql2 =
				"DELETE CN_BATCH_JOB_T WHERE CN_BATCH_JOB_ID=:cnJobId";
		SQLQuery vQuery2 = vSession.createSQLQuery(vSql2);
		vQuery2.setLong("cnJobId", cnJobId);
		vUpdated2 +=vQuery2.executeUpdate();
		
		mLog.debug("Deleted "+vQuery2+" records from CN_BATCH_JOB_T");
		vSession.flush();
	}





}
