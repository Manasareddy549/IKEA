package com.ikea.ebccardpay1.cardpayment.be;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

public class MultipleSingleLoad extends BusinessEntity {
	/**										
	 * Storage: MULTIPLE_SINGLE_LOAD_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mMultipleSingleLoadId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private Date mCreatedDateTime;
	private String mUpdatedBy;
	private Date mUpdatedDateTime;
	private Date mExpiryDate;
	private String mWithdrawBy;
    private Date mWithdrawDateTime;
	

	/**										
	 * Foreign keys				
	 */										
	private Set<Amount> mAmounts = new LinkedHashSet<Amount>(0);
	private int mReasonCode;
	private String mCustomerType;
	

	/**										
	 * Data								
	 */										
	private String mName;
	private String mCurrencyCode;
	private Date mAuthorizedDateTime;
	private String mAuthorizedBy;
	private String mCountryCode;
	private String mAmountType;
	private String mBuType;
	private String mBuCode;
	private long mInitiatedCount;
	private BigDecimal mInitiatedAmount;
	private String mInitiateErrorMessages;
	private String mCompanyName;

	/**
	 * Connect a Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		getAmounts().add(pAmount);
		if(pAmount != null) {
			pAmount.setMultipleSingleLoad(this);
		}
	}

	/**
	 * Disconnect a Amount.
	 * @param pAmount
	 */
	public void disconnectAmount(Amount pAmount) {
		if(pAmount != null) {
			pAmount.setMultipleSingleLoad(null);
		}
		getAmounts().remove(pAmount);
	}


	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	public String getCustomerType() {
		return mCustomerType;
	}

	public void setCustomerType(String pCustomerType) {
		mCustomerType = pCustomerType;
	}

	public String getCompanyName() {
		return mCompanyName;
	}

	public void setCompanyName(String pCompanyName) {
		mCompanyName = pCompanyName;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mMultipleSingleLoadId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public Map<String, Object> assignToMap() {
		Map<String, Object> vMap = super.assignToMap();
		vMap.put("multipleSingleLoadId", CodeGeneration.toObject(mMultipleSingleLoadId));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("authorizedDateTime", CodeGeneration.toObject(mAuthorizedDateTime));
		vMap.put("authorizedBy", CodeGeneration.toObject(mAuthorizedBy));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("initiatedCount", CodeGeneration.toObject(mInitiatedCount));
		vMap.put("initiatedAmount", CodeGeneration.toObject(mInitiatedAmount));
		vMap.put("initiateErrorMessages", CodeGeneration.toObject(mInitiateErrorMessages));
		vMap.put("amountType", CodeGeneration.toObject(mAmountType));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("expiryDate", CodeGeneration.toObject(mExpiryDate));
		vMap.put("withdrawDateTime", CodeGeneration.toObject(mWithdrawDateTime));
		vMap.put("withdrawBy", CodeGeneration.toObject(mWithdrawBy));
		vMap.put("reasonCode", CodeGeneration.toObject(mReasonCode));
		vMap.put("customerType", CodeGeneration.toObject(mCustomerType));
		vMap.put("companyName", CodeGeneration.toObject(mCompanyName));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(Map)
	 */
	public void assignFromMap(Map<String, Object> pMap) {
		if(pMap.containsKey("multipleSingleLoad")) mMultipleSingleLoadId = CodeGeneration.objectTolong(pMap.get("multipleSingleLoad"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("authorizedDateTime")) mAuthorizedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("authorizedDateTime"));
		if(pMap.containsKey("authorizedBy")) mAuthorizedBy = CodeGeneration.objectToString(pMap.get("authorizedBy"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("initiatedCount")) mInitiatedCount = CodeGeneration.objectTolong(pMap.get("initiatedCount"));
		if(pMap.containsKey("initiatedAmount")) mInitiatedAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("initiatedAmount"));
		if(pMap.containsKey("initiateErrorMessages")) mInitiateErrorMessages = CodeGeneration.objectToString(pMap.get("initateErrorMessages"));
		if(pMap.containsKey("amountType")) mAmountType = CodeGeneration.objectToString(pMap.get("amountType"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("withdrawDateTime")) mWithdrawDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("withdrawDateTime"));
		if(pMap.containsKey("withdrawBy")) mWithdrawBy = CodeGeneration.objectToString(pMap.get("withdrawBy"));
		if(pMap.containsKey("expiryDate")) mExpiryDate = CodeGeneration.objectTojava_util_Date(pMap.get("expiryDate"));
		if(pMap.containsKey("reasonCode")) mReasonCode = CodeGeneration.objectToint(pMap.get("reasonCode"));
		if(pMap.containsKey("customerType")) mCustomerType = CodeGeneration.objectToString(pMap.get("customerType"));
		if(pMap.containsKey("companyName")) mCompanyName = CodeGeneration.objectToString(pMap.get("companyName"));
	}

	public long getMultipleSingleLoadId() {
		return mMultipleSingleLoadId;
	}

	public void setMultipleSingleLoadId(long pMultipleSingleLoadId) {
		mMultipleSingleLoadId = pMultipleSingleLoadId;
	}

	public Set<Amount> getAmounts() {
		return mAmounts;
	}

	public void setAmounts(Set<Amount> pAmounts) {
		mAmounts = pAmounts;
	}

	public String getName() {
		return mName;
	}

	public void setName(String pName) {
		mName = pName;
	}

	public String getCurrencyCode() {
		return mCurrencyCode;
	}

	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	public Date getAuthorizedDateTime() {
		return mAuthorizedDateTime;
	}

	public void setAuthorizedDateTime(Date pAuthorizedDateTime) {
		mAuthorizedDateTime = pAuthorizedDateTime;
	}

	public String getAuthorizedBy() {
		return mAuthorizedBy;
	}

	public void setAuthorizedBy(String pAuthorizedBy) {
		mAuthorizedBy = pAuthorizedBy;
	}

	public String getCountryCode() {
		return mCountryCode;
	}

	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	public String getAmountType() {
		return mAmountType;
	}

	public void setAmountType(String pAmountType) {
		mAmountType = pAmountType;
	}

	public String getBuType() {
		return mBuType;
	}

	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	public String getBuCode() {
		return mBuCode;
	}

	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	public void increaseInitiatedCount() {
		mInitiatedCount++;
	}

	public long getInitiatedCount() {
		return mInitiatedCount;
	}

	public void setInitiatedCount(long pInitiatedCount) {
		mInitiatedCount = pInitiatedCount;
	}

	public BigDecimal getInitiatedAmount() {
		return mInitiatedAmount;
	}

	public void setInitiatedAmount(BigDecimal pInitiatedAmount) {
		mInitiatedAmount = pInitiatedAmount;
	}

	public String getInitiateErrorMessages() {
		return mInitiateErrorMessages;
	}

	public void setInitiateErrorMessages(String pInitiateErrorMessages) {
		mInitiateErrorMessages = pInitiateErrorMessages;
	}

	public void addInitiatedAmount(BigDecimal pAmountValue) {
		mInitiatedAmount = mInitiatedAmount.add(pAmountValue);
	}

	public Date getExpiryDate() {
        return mExpiryDate;
                    
    }

    /**
     * Generated setter for property.
     * @param pExpiryDate New property value to set.
            
     */
    public void setExpiryDate(Date pExpiryDate) {
        mExpiryDate = pExpiryDate;
                    
    }

    public String getWithdrawBy() {
        return mWithdrawBy;
                    
    }

    /**
     * Generated setter for property.
     * @param pWithdrawBy New property value to set.
            
     */
    public void setWithdrawBy(String pWithdrawBy) {
        mWithdrawBy = pWithdrawBy;
                    
    }

    /**
     * Generated getter for property.
     * @return Current property value.
     */
    public Date getWithdrawDateTime() {
        return mWithdrawDateTime;
                    
    }

    /**
     * Generated setter for property.
     * @param pWithdrawDateTime New property value to set.
            
     */
    public void setWithdrawDateTime(Date pWithdrawDateTime) {
        mWithdrawDateTime = pWithdrawDateTime;
                    
    }
    public int getReasonCode() {
		return mReasonCode;
	}

	public void setReasonCode(int mReasonCode) {
		this.mReasonCode = mReasonCode;
	}



}
