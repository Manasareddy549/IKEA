package com.ikea.ebccardpay1.cardpayment.exception;

/**
 */
public abstract class ReferenceCheckException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7271851178153844845L;
	protected String mSourceSystem;
	protected String mReference;
	protected String mSalesDay;

	public ReferenceCheckException(
		String pSourceSystem,
		String pReference) {
		super("");
		mReference = pReference;
		mSourceSystem = pSourceSystem;
		//mSalesDay = pSalesDay;
	}
}
