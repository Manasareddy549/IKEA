/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

public class ReasonCode extends BusinessEntity {
	/**										
	 * Storage: REASON_CODE_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private int mReasonCodeId;

	/**										
	 * Common attributes	
	 */										
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private MassLoad mMassLoad;
	private MultipleSingleLoad mMultipleSingleLoad;
	private java.util.Set<Campaign> mCampaigns = new java.util.LinkedHashSet<Campaign>(0);
	private Transaction mTransactions;

	

	/**										
	 * Data								
	 */										
	private String mLoadReasonDescription;
	private String mRedeemReasonDescription;
	private String mDescription;
	
	
	
	public int getReasonCodeId() {
		return mReasonCodeId;
	}

	public void setReasonCodeId(int mReasonCodeId) {
		this.mReasonCodeId = mReasonCodeId;
	}

	public String getCreatedBy() {
		return mCreatedBy;
	}

	public void setCreatedBy(String mCreatedBy) {
		this.mCreatedBy = mCreatedBy;
	}

	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	public void setCreatedDateTime(java.util.Date mCreatedDateTime) {
		this.mCreatedDateTime = mCreatedDateTime;
	}

	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	public void setUpdatedBy(String mUpdatedBy) {
		this.mUpdatedBy = mUpdatedBy;
	}

	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	public void setUpdatedDateTime(java.util.Date mUpdatedDateTime) {
		this.mUpdatedDateTime = mUpdatedDateTime;
	}

	public MassLoad getMassLoad() {
		return mMassLoad;
	}

	public void setMassLoad(MassLoad mMassLoad) {
		this.mMassLoad = mMassLoad;
	}

	public MultipleSingleLoad getMultipleSingleLoad() {
		return mMultipleSingleLoad;
	}

	public void setMultipleSingleLoad(MultipleSingleLoad mMultipleSingleLoad) {
		this.mMultipleSingleLoad = mMultipleSingleLoad;
	}

	public java.util.Set<Campaign> getCampaigns() {
		return mCampaigns;
	}

	public void setCampaigns(java.util.Set<Campaign> mCampaigns) {
		this.mCampaigns = mCampaigns;
	}

	public String getLoadReasonDescription() {
		return mLoadReasonDescription;
	}

	public void setLoadReasonDescription(String mLoadReasonDescription) {
		this.mLoadReasonDescription = mLoadReasonDescription;
	}

	public String getRedeemReasonDescription() {
		return mRedeemReasonDescription;
	}

	public void setRedeemReasonDescription(String mRedeemReasonDescription) {
		this.mRedeemReasonDescription = mRedeemReasonDescription;
	}

	public String getDescription() {
		return mDescription;
	}

	public void setDescription(String mDescription) {
		this.mDescription = mDescription;
	}

	public Transaction getTransactions() {
		return mTransactions;
	}

	public void setTransactions(Transaction mTransactions) {
		this.mTransactions = mTransactions;
	}

	/**
	 * Connect MassLoad.
	 * @param pMassLoad
	 */
	/*public void connectMassLoad(MassLoad pMassLoad) {
		setMassLoad(pMassLoad);
		if(pMassLoad != null) {
			pMassLoad.setReasonCode(this);
		}
	}

	*//**
	 * Disconnect MassLoad.
	 *//*
	public void disconnectMassLoad() {
		if(getMassLoad() != null) {
			getMassLoad().setReasonCode(null);
		}
		setMassLoad(null);
	}*/

	/**
	 * Connect a Campaign.
	 * @param pCampaign
	 */
	/*public void connectCampaign(Campaign pCampaign) {
		getCampaigns().add(pCampaign);
		if(pCampaign != null) {
			pCampaign.getReasonCode().add(this);
		}
	}

	*//**
	 * Disconnect a Campaign.
	 * @param pCampaign
	 *//*
	public void disconnectCampaign(Campaign pCampaign) {
		if(pCampaign != null) {
			pCampaign.getRanges().remove(this);
		}
		getCampaigns().remove(pCampaign);
	}
	*/
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mReasonCodeId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("reasonCodeId", CodeGeneration.toObject(mReasonCodeId));
		vMap.put("loadReasonDescription", CodeGeneration.toObject(mLoadReasonDescription));
		vMap.put("redeemReasonDescription", CodeGeneration.toObject(mRedeemReasonDescription));
		vMap.put("description", CodeGeneration.toObject(mDescription));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		return vMap;
	}

	 /*(non-Javadoc)
	  @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)*/
	 
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("reasonCodeId")) mReasonCodeId = CodeGeneration.objectToInteger(pMap.get("reasonCodeId"));
		if(pMap.containsKey("loadReasonDescription")) mLoadReasonDescription = CodeGeneration.objectToString(pMap.get("loadReasonDescription"));
		if(pMap.containsKey("redeemReasonDescription")) mRedeemReasonDescription = CodeGeneration.objectToString(pMap.get("redeemReasonDescription"));
		if(pMap.containsKey("description")) mDescription = CodeGeneration.objectToString(pMap.get("description"));
	}


}
