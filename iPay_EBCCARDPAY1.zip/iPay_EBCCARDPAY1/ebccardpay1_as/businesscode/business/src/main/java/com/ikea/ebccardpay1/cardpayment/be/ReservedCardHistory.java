package com.ikea.ebccardpay1.cardpayment.be;

import java.math.BigDecimal;
import java.util.Date;

import com.ikea.mdsd.BusinessEntity;
import com.ikea.mdsd.CodeGeneration;

/**
 * @author vikum27
 *
 */

public class ReservedCardHistory extends BusinessEntity {
	/**										
	 * Storage: RESERVED_CARD_HISTORY_T												
	 */	
	/**										
	 * Primary key				
	 */
	private long mReservedHistoryId;
	
	private String mReservedTransactionType;
	private String mReference;
	private BigDecimal mOriginalUnAuthorizeAmount;
	private BigDecimal mCurrentAuthorizeAmount;
	private BigDecimal mRemainingUnAuthorizeAmount;
	private String mFinancialType;
	private String mCurrencyCode;
	private String mSourceSystem;
	private Date mTransmissionDateTime;
	private boolean mCancelled;
	private String mBuType;
	private String mBuCode;
	private String mCountryCode;
	private String mSwiped;
	/**										
	 * Foreign keys				
	 */				
	private Card mCard;
	private Amount mAmount;
	private MassLoad mMassLoad;
	private Campaign mCampaign;
	/**										
	 * Data								
	 */
	private String mEmployee;
	private long mTransactionNo;
	private java.math.BigDecimal mTotalAmount;
	private boolean mCrossBorder;
	private boolean mCrossCurrency;
	private boolean mInsufficientAmount;
	private String mSalesDay;
	private String mPointOfSale;
	private String mReceipt;
	private int mVersionNo;
	private String mCreatedBy;
	private Date mCreatedDateTime;
	private String mUpdatedBy;
	private Date mUpdatedDateTime;
	private String mVoidedTransactionNo;
	private BigDecimal mCardBalanceChange;
	private BigDecimal mExchangeRate;
	
	public long getReservedHistoryId() {
		return mReservedHistoryId;
	}
	public void setReservedHistoryId(long mReservedHistoryId) {
		this.mReservedHistoryId = mReservedHistoryId;
	}
	public String getReservedTransactionType() {
		return mReservedTransactionType;
	}
	public void setReservedTransactionType(String mReservedTransactionType) {
		this.mReservedTransactionType = mReservedTransactionType;
	}
	public String getReference() {
		return mReference;
	}
	public void setReference(String mReference) {
		this.mReference = mReference;
	}
	public BigDecimal getOriginalUnAuthorizeAmount() {
		return mOriginalUnAuthorizeAmount;
	}
	public void setOriginalUnAuthorizeAmount(BigDecimal mOriginalUnAuthorizeAmount) {
		this.mOriginalUnAuthorizeAmount = mOriginalUnAuthorizeAmount;
	}
	public BigDecimal getCurrentAuthorizeAmount() {
		return mCurrentAuthorizeAmount;
	}
	public void setCurrentAuthorizeAmount(BigDecimal mCurrentAuthorizeAmount) {
		this.mCurrentAuthorizeAmount = mCurrentAuthorizeAmount;
	}
	
	public BigDecimal getRemainingUnAuthorizeAmount() {
		return mRemainingUnAuthorizeAmount;
	}
	public void setRemainingUnAuthorizeAmount(BigDecimal mRemainingUnAuthorizeAmount) {
		this.mRemainingUnAuthorizeAmount = mRemainingUnAuthorizeAmount;
	}
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	public void setCurrencyCode(String mCurrencyCode) {
		this.mCurrencyCode = mCurrencyCode;
	}
	public String getSourceSystem() {
		return mSourceSystem;
	}
	public void setSourceSystem(String mSourceSystem) {
		this.mSourceSystem = mSourceSystem;
	}
	public Date getTransmissionDateTime() {
		return mTransmissionDateTime;
	}
	public void setTransmissionDateTime(Date mTransmissionDateTime) {
		this.mTransmissionDateTime = mTransmissionDateTime;
	}
	public boolean isCancelled() {
		return mCancelled;
	}
	public void setCancelled(boolean mCancelled) {
		this.mCancelled = mCancelled;
	}
	public String getBuType() {
		return mBuType;
	}
	public void setBuType(String mBuType) {
		this.mBuType = mBuType;
	}
	public String getBuCode() {
		return mBuCode;
	}
	public void setBuCode(String mBuCode) {
		this.mBuCode = mBuCode;
	}
	public String getCountryCode() {
		return mCountryCode;
	}
	public void setCountryCode(String mCountryCode) {
		this.mCountryCode = mCountryCode;
	}
	public Card getCard() {
		return mCard;
	}
	public void setCard(Card mCard) {
		this.mCard = mCard;
	}
	public Amount getAmount() {
		return mAmount;
	}
	public void setAmount(Amount mAmount) {
		this.mAmount = mAmount;
	}
	public MassLoad getMassLoad() {
		return mMassLoad;
	}
	public void setMassLoad(MassLoad mMassLoad) {
		this.mMassLoad = mMassLoad;
	}
	public Campaign getCampaign() {
		return mCampaign;
	}
	public void setCampaign(Campaign mCampaign) {
		this.mCampaign = mCampaign;
	}
	public String getEmployee() {
		return mEmployee;
	}
	public void setEmployee(String mEmployee) {
		this.mEmployee = mEmployee;
	}
	public long getTransactionNo() {
		return mTransactionNo;
	}
	public void setTransactionNo(long mTransactionNo) {
		this.mTransactionNo = mTransactionNo;
	}
	
	public BigDecimal getTotalAmount() {
		return mTotalAmount;
	}
	public void setTotalAmount(BigDecimal mTotalAmount) {
		this.mTotalAmount = mTotalAmount;
	}
	public boolean isCrossBorder() {
		return mCrossBorder;
	}
	public void setCrossBorder(boolean mCrossBorder) {
		this.mCrossBorder = mCrossBorder;
	}
	public boolean isCrossCurrency() {
		return mCrossCurrency;
	}
	public void setCrossCurrency(boolean mCrossCurrency) {
		this.mCrossCurrency = mCrossCurrency;
	}
	public String getSalesDay() {
		return mSalesDay;
	}
	public void setSalesDay(String mSalesDay) {
		this.mSalesDay = mSalesDay;
	}
	public String getPointOfSale() {
		return mPointOfSale;
	}
	public void setPointOfSale(String mPointOfSale) {
		this.mPointOfSale = mPointOfSale;
	}
	public String getReceipt() {
		return mReceipt;
	}
	public void setReceipt(String mReceipt) {
		this.mReceipt = mReceipt;
	}
	public String getCreatedBy() {
		return mCreatedBy;
	}
	public void setCreatedBy(String mCreatedBy) {
		this.mCreatedBy = mCreatedBy;
	}
	public Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	public void setCreatedDateTime(Date mCreatedDateTime) {
		this.mCreatedDateTime = mCreatedDateTime;
	}
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	public void setUpdatedBy(String mUpdatedBy) {
		this.mUpdatedBy = mUpdatedBy;
	}
	public Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	public void setUpdatedDateTime(Date mUpdatedDateTime) {
		this.mUpdatedDateTime = mUpdatedDateTime;
	}
	
	public String getFinancialType() {
		return mFinancialType;
	}
	public void setFinancialType(String mFinancialType) {
		this.mFinancialType = mFinancialType;
	}
	public String getSwiped() {
		return mSwiped;
	}
	public void setSwiped(String mSwiped) {
		this.mSwiped = mSwiped;
	}
	public boolean isInsufficientAmount() {
		return mInsufficientAmount;
	}
	public void setInsufficientAmount(boolean mInsufficientAmount) {
		this.mInsufficientAmount = mInsufficientAmount;
	}
	public int getVersionNo() {
		return mVersionNo;
	}
	public void setVersionNo(int mVersionNo) {
		this.mVersionNo = mVersionNo;
	}
	public String getVoidedTransactionNo() {
		return mVoidedTransactionNo;
	}
	public void setVoidedTransactionNo(String mVoidedTransactionNo) {
		this.mVoidedTransactionNo = mVoidedTransactionNo;
	}
	
	public BigDecimal getCardBalanceChange() {
		return mCardBalanceChange;
	}
	public void setCardBalanceChange(BigDecimal mCardBalanceChange) {
		this.mCardBalanceChange = mCardBalanceChange;
	}
	public BigDecimal getExchangeRate() {
		return mExchangeRate;
	}
	public void setExchangeRate(BigDecimal mExchangeRate) {
		this.mExchangeRate = mExchangeRate;
	}
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mReservedHistoryId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("reservedHistoryId", CodeGeneration.toObject(mReservedHistoryId));
		vMap.put("reservedTransactionType", CodeGeneration.toObject(mReservedTransactionType));
		vMap.put("reference", CodeGeneration.toObject(mReference));
		vMap.put("originalUnAuthorizeAmount", CodeGeneration.toObject(mOriginalUnAuthorizeAmount));
		vMap.put("currentAuthorizeAmount", CodeGeneration.toObject(mCurrentAuthorizeAmount));
		vMap.put("remainingUnAuthorizeAmount", CodeGeneration.toObject(mRemainingUnAuthorizeAmount));
		vMap.put("financialType", CodeGeneration.toObject(mFinancialType));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("sourceSystem", CodeGeneration.toObject(mSourceSystem));
		vMap.put("transmissionDateTime", CodeGeneration.toObject(mTransmissionDateTime));
		vMap.put("cancelled", CodeGeneration.toObject(mCancelled));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("swiped", CodeGeneration.toObject(mSwiped));
		vMap.put("employee", CodeGeneration.toObject(mEmployee));
		vMap.put("transactionNo", CodeGeneration.toObject(mTransactionNo));
		vMap.put("totalAmount", CodeGeneration.toObject(mTotalAmount));
		vMap.put("crossBorder", CodeGeneration.toObject(mCrossBorder));
		vMap.put("crossCurrency", CodeGeneration.toObject(mCrossCurrency));
		vMap.put("insufficientAmount", CodeGeneration.toObject(mInsufficientAmount));
		vMap.put("salesDay", CodeGeneration.toObject(mSalesDay));
		vMap.put("pointOfSale", CodeGeneration.toObject(mPointOfSale));
		vMap.put("receipt", CodeGeneration.toObject(mReceipt));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("voidedTransactionNo", CodeGeneration.toObject(mVoidedTransactionNo));
		vMap.put("cardBalanceChange", CodeGeneration.toObject(mCardBalanceChange));
		vMap.put("exchangeRate", CodeGeneration.toObject(mExchangeRate));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("reservedHistoryId")) mReservedHistoryId = CodeGeneration.objectTolong(pMap.get("reservedHistoryId"));
		if(pMap.containsKey("reservedTransactionType")) mReservedTransactionType = CodeGeneration.objectToString(pMap.get("reservedTransactionType"));
		if(pMap.containsKey("reference")) mReference = CodeGeneration.objectToString(pMap.get("reference"));
		if(pMap.containsKey("originalUnAuthorizeAmount")) mOriginalUnAuthorizeAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("originalUnAuthorizeAmount"));
		if(pMap.containsKey("currentAuthorizeAmount")) mCurrentAuthorizeAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("currentAuthorizeAmount"));
		if(pMap.containsKey("remainingUnAuthorizeAmount")) mRemainingUnAuthorizeAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("remainingUnAuthorizeAmount"));
		if(pMap.containsKey("financialType")) mFinancialType = CodeGeneration.objectToString(pMap.get("financialType"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("sourceSystem")) mSourceSystem = CodeGeneration.objectToString(pMap.get("sourceSystem"));
		if(pMap.containsKey("transmissionDateTime")) mTransmissionDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("transmissionDateTime"));
		if(pMap.containsKey("cancelled")) mCancelled = CodeGeneration.objectToboolean(pMap.get("cancelled"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("swiped")) mSwiped = CodeGeneration.objectToString(pMap.get("swiped"));
		if(pMap.containsKey("employee")) mEmployee = CodeGeneration.objectToString(pMap.get("employee"));
		if(pMap.containsKey("transactionNo")) mTransactionNo = CodeGeneration.objectToLong(pMap.get("transactionNo"));
		if(pMap.containsKey("totalAmount")) mTotalAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("totalAmount"));
		if(pMap.containsKey("crossBorder")) mCrossBorder = CodeGeneration.objectToboolean(pMap.get("crossBorder"));
		if(pMap.containsKey("crossCurrency")) mCrossCurrency = CodeGeneration.objectToboolean(pMap.get("crossCurrency"));
		if(pMap.containsKey("insufficientAmount")) mInsufficientAmount = CodeGeneration.objectToboolean(pMap.get("insufficientAmount"));
		if(pMap.containsKey("salesDay")) mSalesDay = CodeGeneration.objectToString(pMap.get("salesDay"));
		if(pMap.containsKey("pointOfSale")) mPointOfSale = CodeGeneration.objectToString(pMap.get("pointOfSale"));
		if(pMap.containsKey("receipt")) mReceipt = CodeGeneration.objectToString(pMap.get("receipt"));
		if(pMap.containsKey("versionNo")) mVersionNo = CodeGeneration.objectToint(pMap.get("versionNo"));
		if(pMap.containsKey("createdBy")) mCreatedBy = CodeGeneration.objectToString(pMap.get("createdBy"));
		if(pMap.containsKey("createdDateTime")) mCreatedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("createdDateTime"));
		if(pMap.containsKey("updatedBy")) mUpdatedBy = CodeGeneration.objectToString(pMap.get("updatedBy"));
		if(pMap.containsKey("updatedDateTime")) mUpdatedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("updatedDateTime"));
		if(pMap.containsKey("voidedTransactionNo")) mVoidedTransactionNo = CodeGeneration.objectToString(pMap.get("voidedTransactionNo"));
		if(pMap.containsKey("cardBalanceChange")) mCardBalanceChange = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("cardBalanceChange"));
		if(pMap.containsKey("exchangeRate")) mExchangeRate = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("exchangeRate"));
		
	}
	
}
