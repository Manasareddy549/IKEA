/*
 * Created on 2008-feb-01
 *
 * 
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author dalq
 *
 *	CountryException is thrown if the input country is not set
 *
 */
public class CountryException extends CardPayException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7498048147381301274L;

	/**
	 * 
	 */
	public CountryException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public CountryException(String pMessage) {
		super(pMessage);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.exception.CardPayException#createApplicationError()
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.MissingCountryCode();
	}

}
