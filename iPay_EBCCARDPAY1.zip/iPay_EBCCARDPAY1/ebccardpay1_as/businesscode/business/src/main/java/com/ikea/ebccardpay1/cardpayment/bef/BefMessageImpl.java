/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Message;

/**
 * @author sakha60
 */
public class BefMessageImpl extends BefAbstract<Message> implements BefMessage {
	
	protected BefMessageImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
		// TODO Auto-generated constructor stub
	}

	private final static Logger mLog = LoggerFactory.getLogger(BefMessageImpl.class);

	@Override
	protected Class<Message> getBusinessEntityClass() {
		return Message.class;
	}
}
