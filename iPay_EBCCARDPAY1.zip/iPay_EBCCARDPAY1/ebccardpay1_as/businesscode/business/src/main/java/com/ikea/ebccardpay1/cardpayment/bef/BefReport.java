package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;
import java.util.Map;

import com.ikea.ebccardpay1.cardpayment.be.Report;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpay1.cardpayment.utils.ReportParameter;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportResults;

public interface BefReport extends Bef<Report>{

	List<Map<String, Object>> retrieveReport(String pQuery1, String pQuery2, java.util.List<ReportParameter> pParameters);

	List<Map<String, Object>> retrieveAdocReport(String pQuery);
	
	VoReportResults retrieveCardDetails(VoCardNumber vVoCardNumber);
	
	WeeklySalesReport retrieveSalesReportByWeek(String pYear, String pWeek);
}