/*
 * Created on 2007-apr-13
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.exception.AuthorizationException;
import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.CardPayException;
import com.ikea.ebccardpay1.cardpayment.exception.FourEyesException;
import com.ikea.ebccardpay1.cardpayment.exception.TransactionException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusComplete;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusOnCard;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusSearch;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public interface BecBonus {

	/**
	 * 
	 * @return
	 */
	public BecBonus init(
		String pCardNumberString,
		BusinessUnitEnvironment pBusinessUnitEnvironment)
		throws ValueMissingException, IkeaException, CardPayException;

	/**
	 * 
	 * @param pBonus
	 * @return
	 */
	public BecBonus init(Bonus pBonus);

	/**
	 * 
	 * @param pBonusId
	 * @return
	 */
	public BecBonus init(long pBonusId);

	/**
	 * 
	 * @param pUserEnvironment
	 * @return
	 */
	public BecBonus init(UserEnvironment pUserEnvironment);

	/**
	 * 
	 *
	 */
	public void createBonus(VoBonusOnCard pVoBonusOnCard)
		throws BonusCodeException, ValueMissingException, IkeaException;

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws IkeaException
	 * @throws CardPayException
	 */
	public void loadBonus()
		throws ValueMissingException, IkeaException, CardPayException;

	/**
	 * 
	 * @throws ValueMissingException
	 * @throws AuthorizationException
	 * @throws FourEyesException
	 */
	public void authorize()
		throws
			ValueMissingException,
			AuthorizationException,
			FourEyesException,
			TransactionException;

	/**
	 * 
	 * @return
	 * @throws ValueMissingException
	 */
	public VoBonusOnCard getVoBonusOnCard() throws ValueMissingException;

	/**
	 * 
	 * @return
	 */
	public VoBonusComplete getVoBonus(VoBonusSearch pVoBonusSearch) throws ValueMissingException;

}
