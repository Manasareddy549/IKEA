/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;

public class CardNumber extends BusinessEntity {
	/**										
	 * Storage: CARD_NUMBER_T												
	 */										

	/**										
	 * Primary key				
	 */	
	private long mCardNumberId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private Card mCard;
	private java.util.Set<Range> mRanges = new java.util.LinkedHashSet<Range>(0);

	/**										
	 * Data								
	 */	
	//iPay4.8.1 Sprint2
	//private String mAccountNumber;
	private String mIssuer;
	private int mCardTypeDigit;
	private int mCheckDigit;
	//private String mVerificationCode;
	private String mAccountNumberEnc;
	private String mVerificationCodeEnc;
	//Sprint2- Field Encryption CR
	private String mIssuerCountryCode;
	
	/**											
	 * @return Returns the cardNumberId.													
	 */											
	public long getCardNumberId() {
		return mCardNumberId;
	}
	/**
	 * @param pCardNumberId The cardNumberId to set.
	 */
	public void setCardNumberId(long pCardNumberId) {
		mCardNumberId = pCardNumberId;
	}

	/**											
	 * @return Returns the accountNumber.													
	 */											
//	public String getAccountNumber() {
//		
//		//mAccountNumber = mEncryptionDecryption.decrypt(mAccountNumber) ;
//		return mAccountNumber;
//	}
	/**
	 * @param pAccountNumber The accountNumber to set.
	 */
//	public void setAccountNumber(String pAccountNumber) {
//		mAccountNumber = pAccountNumber;//mEncryptionDecryption.encrypt(pAccountNumber);
//	}

	/**											
	 * @return Returns the issuer.													
	 */											
	public String getIssuer() {
		return mIssuer;
	}
	/**
	 * @param pIssuer The issuer to set.
	 */
	public void setIssuer(String pIssuer) {
		mIssuer = pIssuer;
	}

	/**											
	 * @return Returns the cardTypeDigit.													
	 */											
	public int getCardTypeDigit() {
		return mCardTypeDigit;
	}
	/**
	 * @param pCardTypeDigit The cardTypeDigit to set.
	 */
	public void setCardTypeDigit(int pCardTypeDigit) {
		mCardTypeDigit = pCardTypeDigit;
	}

	/**											
	 * @return Returns the checkDigit.													
	 */											
	public int getCheckDigit() {
		return mCheckDigit;
	}
	/**
	 * @param pCheckDigit The checkDigit to set.
	 */
	public void setCheckDigit(int pCheckDigit) {
		mCheckDigit = pCheckDigit;
	}

	/**											
	 * @return Returns the verificationCode.													
	 */											
//	public String getVerificationCode() {
//		return mVerificationCode;
//	}
	/**
	 * @param pVerificationCode The verificationCode to set.
	 */
//	public void setVerificationCode(String pVerificationCode) {
//		mVerificationCode = pVerificationCode;
//	}
	
	public String getAccountNumberEnc() {
		return mAccountNumberEnc;
	}
	public void setAccountNumberEnc(String pAccountNumberEnc) {
		mAccountNumberEnc = pAccountNumberEnc;
	}
	public String getVerificationCodeEnc() {
		return mVerificationCodeEnc;
	}
	public void setVerificationCodeEnc(String pVerificationCodeEnc) {
		mVerificationCodeEnc = pVerificationCodeEnc;
	}


	/**											
	 * @return Returns the card.													
	 */											
	public Card getCard() {
		return mCard;
	}
	/**
	 * @param pCard The card to set.
	 */
	public void setCard(Card pCard) {
		mCard = pCard;
	}

	/**											
	 * @return Returns the ranges.													
	 */											
	public java.util.Set<Range> getRanges() {
		return mRanges;
	}
	/**
	 * @param pRanges The ranges to set.
	 */
	public void setRanges(java.util.Set<Range> pRanges) {
		mRanges = pRanges;
	}

	/**
	 * Connect Card.
	 * @param pCard
	 */
	public void connectCard(Card pCard) {
		setCard(pCard);
		if(pCard != null) {
			pCard.setCardNumber(this);
		}
	}

	/**
	 * Disconnect Card.
	 */
	public void disconnectCard() {
		if(getCard() != null) {
			getCard().setCardNumber(null);
		}
		setCard(null);
	}

	/**
	 * Connect a Range.
	 * @param pRange
	 */
	public void connectRange(Range pRange) {
		getRanges().add(pRange);
		if(pRange != null) {
			pRange.getCardNumbers().add(this);
		}
	}

	/**
	 * Disconnect a Range.
	 * @param pRange
	 */
	public void disconnectRange(Range pRange) {
		if(pRange != null) {
			pRange.getCardNumbers().remove(this);
		}
		getRanges().remove(pRange);
	}

	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	public String getIssuerCountryCode() {
		return mIssuerCountryCode;
	}
	public void setIssuerCountryCode(String pIssuerCountryCode) {
		this.mIssuerCountryCode = pIssuerCountryCode;
	}
	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mCardNumberId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("cardNumberId", CodeGeneration.toObject(mCardNumberId));
		//vMap.put("accountNumber", CodeGeneration.toObject(mAccountNumber));
		vMap.put("issuer", CodeGeneration.toObject(mIssuer));
		vMap.put("cardTypeDigit", CodeGeneration.toObject(mCardTypeDigit));
		vMap.put("checkDigit", CodeGeneration.toObject(mCheckDigit));
		//vMap.put("verificationCode", CodeGeneration.toObject(mVerificationCode));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("accountNumberEnc", CodeGeneration.toObject(mAccountNumberEnc));
		vMap.put("verificationCodeEnc", CodeGeneration.toObject(mVerificationCodeEnc));
		vMap.put("issuerCountryCode", CodeGeneration.toObject(mIssuerCountryCode));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("cardNumberId")) mCardNumberId = CodeGeneration.objectTolong(pMap.get("cardNumberId"));
		//if(pMap.containsKey("accountNumber")) mAccountNumber = CodeGeneration.objectToString(pMap.get("accountNumber"));
		if(pMap.containsKey("issuer")) mIssuer = CodeGeneration.objectToString(pMap.get("issuer"));
		if(pMap.containsKey("cardTypeDigit")) mCardTypeDigit = CodeGeneration.objectToint(pMap.get("cardTypeDigit"));
		if(pMap.containsKey("checkDigit")) mCheckDigit = CodeGeneration.objectToint(pMap.get("checkDigit"));
		//if(pMap.containsKey("verificationCode")) mVerificationCode = CodeGeneration.objectToString(pMap.get("verificationCode"));
		if(pMap.containsKey("accountNumberEnc")) mAccountNumberEnc = CodeGeneration.objectToString(pMap.get("accountNumberEnc"));
		if(pMap.containsKey("verificationCodeEnc")) mVerificationCodeEnc = CodeGeneration.objectToString(pMap.get("verificationCodeEnc"));
		if(pMap.containsKey("issuerCountryCode")) mIssuerCountryCode = CodeGeneration.objectToString(pMap.get("issuerCountryCode"));
	}
}
