/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.Bonus;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * 
 */
public class BefBonusImpl extends BefAbstract<Bonus> implements BefBonus {

	private final static Logger mCategory_findByUnauthorized = LoggerFactory
			.getLogger(BefBonusImpl.class.getName() + ".findByUnauthorized");

	private final static Logger mCategory_findBySearch = LoggerFactory
			.getLogger(BefBonusImpl.class.getName() + ".findBySearch");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefBonusImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#findByCurrent(java.lang
	 * .String)
	 */
	public List<Bonus> findByUnauthorized(String pCountryCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Bonus> vCriteria = new GenericCriteria<Bonus>(vSession
				.createCriteria(Bonus.class));
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria.add(Restrictions.isNull("authorizedDateTime"));

		// To get just one per bonus
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByUnauthorized.isDebugEnabled()) {
			mCategory_findByUnauthorized.debug("Criteria: "
					+ vCriteria.toString());
		}

		List<Bonus> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByUnauthorized.info("No bonuses found.");
		} else {
			mCategory_findByUnauthorized.info("Found " + vList.size()
					+ " bonuses.");
		}
		return vList;
	}

	public List<Bonus> findBySearch(String pBuType, String pBuCode,
			long pBonusCode, String pCountryCode, Date pAuthorizedDateTime) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Bonus> vCriteria = new GenericCriteria<Bonus>(vSession
				.createCriteria(Bonus.class));

		boolean vBuType = pBuType != null && pBuType.length() > 0;
		boolean vBuCode = pBuCode != null && pBuCode.length() > 0;

		if (vBuType && vBuCode) {
			vCriteria.createCriteria("amount").add(
					Restrictions.eq("buType", pBuType)).add(
					Restrictions.eq("buCode", pBuCode));
		}

		if (pBonusCode > 0) {
			vCriteria.createCriteria("bonusCode").add(
					Restrictions.eq("bonusCodeId", new Long(pBonusCode)));

		}

		if (pCountryCode != null && pCountryCode.length() > 0) {
			vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		}

		if (pAuthorizedDateTime != null) {
			vCriteria.add(Restrictions.ge("authorizedDateTime",
					pAuthorizedDateTime));
		}

		if (mCategory_findBySearch.isDebugEnabled()) {
			mCategory_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<Bonus> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findBySearch
					.info("No bonus loads found in bonus search.");
		} else {
			mCategory_findBySearch.info("Found " + vList.size()
					+ " bonus loads.");
		}

		return vList;

	}

	@Override
	protected Class<Bonus> getBusinessEntityClass() {
		return Bonus.class;
	}

}
