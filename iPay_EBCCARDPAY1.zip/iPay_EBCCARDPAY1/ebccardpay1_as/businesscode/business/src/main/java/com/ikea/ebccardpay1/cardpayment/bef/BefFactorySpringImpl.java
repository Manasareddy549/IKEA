package com.ikea.ebccardpay1.cardpayment.bef;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class BefFactorySpringImpl implements BefFactory, ApplicationContextAware{

	private ApplicationContext mContext;

	public void setApplicationContext(ApplicationContext pApplicationContext)
			throws BeansException {
				mContext = pApplicationContext;
	}
	
	public BefActivation getBefActivation() {
		return (BefActivation) mContext.getBean("befActivation");
	}

	public BefAmount getBefAmount() {
		return (BefAmount) mContext.getBean("befAmount");
	}

	public BefAuthorization getBefAuthorization() {
		return (BefAuthorization) mContext.getBean("befAuthorization");
	}

	public BefBonus getBefBonus() {
		return (BefBonus) mContext.getBean("befBonus");
	}

	public BefBonusCode getBefBonusCode() {
		return (BefBonusCode) mContext.getBean("befBonusCode");
	}

	public BefCampaign getBefCampaign() {
		return (BefCampaign) mContext.getBean("befCampaign");
	}

	public BefCampaignLimitation getBefCampaignLimitation() {
		return (BefCampaignLimitation) mContext.getBean("befCampaignLimitation");
	}

	public BefCard getBefCard() {
		return (BefCard) mContext.getBean("befCard");
	}

	public BefCardNumber getBefCardNumber() {
		return (BefCardNumber) mContext.getBean("befCardNumber");
	}

	public BefCardTypeConstant getBefCardTypeConstant() {
		return (BefCardTypeConstant) mContext.getBean("befCardTypeConstant");
	}

	public BefCountry getBefCountry() {
		return (BefCountry) mContext.getBean("befCountry");
	}

	public BefCountrySetup getBefCountrySetup() {
		return (BefCountrySetup) mContext.getBean("befCountrySetup");
	}

	public BefExchangeModeConstant getBefExchangeModeConstant() {
		return (BefExchangeModeConstant) mContext.getBean("befExchangeModeConstant");
	}

	public BefExchangeRate getBefExchangeRate() {
		return (BefExchangeRate) mContext.getBean("befExchangeRate");
	}

	public BefExternalCard getBefExternalCard() {
		return (BefExternalCard) mContext.getBean("befExternalCard");
	}

	public BefExternalCardSystem getBefExternalCardSystem() {
		return (BefExternalCardSystem) mContext.getBean("befExternalCardSystem");
	}

	public BefKPI getBefKPI() {
		return (BefKPI) mContext.getBean("befKpi");
	}

	public BefLifeCycle getBefLifeCycle() {
		return (BefLifeCycle) mContext.getBean("befLifeCycle");
	}

	public BefMainCurrency getBefMainCurrency() {
		return (BefMainCurrency) mContext.getBean("befMainCurrency");
	}

	public BefMassLoad getBefMassLoad() {
		return (BefMassLoad) mContext.getBean("befMassLoad");
	}

	public BefParameter getBefParameter() {
		return (BefParameter) mContext.getBean("befParameter");
	}

	public BefRange getBefRange() {
		return (BefRange) mContext.getBean("befRange");
	}

	public BefReferenceCheck getBefReferenceCheck() {
		return (BefReferenceCheck) mContext.getBean("befReferenceCheck");
	}

	public BefReport getBefReport() {
		return (BefReport) mContext.getBean("befReport");
	}

	public BefSourceSystemConstant getBefSourceSystemConstant() {
		return (BefSourceSystemConstant) mContext.getBean("befSourceSystemConstant");
	}

	public BefTransaction getBefTransaction() {
		return (BefTransaction) mContext.getBean("befTransaction");
	}

	public BefTransactionFilter getBefTransactionFilter() {
		return (BefTransactionFilter) mContext.getBean("befTransactionFilter");
	}

	public BefConstants getBefConstants() {
		return (BefConstants) mContext.getBean("befConstants");
	}

	public BefExchangeRateSpread getBefExchangeRateSpread() {
		return (BefExchangeRateSpread) mContext.getBean("befExchangeRateSpread");
	}

	public BefIpayBusinessUnits getBefIpayBusinessUnits() {		
		return (BefIpayBusinessUnits) mContext.getBean("befIpayBusinessUnits");
	}

	public BefUnacknowledgedTimeout getBefUnacknowledgedTimeout() {
		return (BefUnacknowledgedTimeout) mContext.getBean("befUnacknowledgedTimeout");
	}

	public BefSarecReport getBefSarecReport() {
		return (BefSarecReport) mContext.getBean("befSarecReport");
	}

	public BefExternalTempCard getBefExternalTempCard() {
		// TODO Auto-generated method stub
		return (BefExternalTempCard) mContext.getBean("befExternalTempCard");
	}

	@Override
	public BefCnCardBatchJob getBefCnCardBatchJob() {
		// TODO Auto-generated method stub
		return (BefCnCardBatchJob) mContext.getBean("befCnCardBatchJob");
	}

	@Override
	public BefCnCard getBefCnCard() {
		// TODO Auto-generated method stub
		return (BefCnCard) mContext.getBean("befCnCard");
	}
	
	@Override
	public BefReasonCodeTransaction getBefReasonCodeTransaction() {
		// TODO Auto-generated method stub
		return (BefReasonCodeTransaction) mContext.getBean("befReasonCodeTransaction");
	}
	
	@Override
	public BefReasonCode getBefReasonCode() {
		// TODO Auto-generated method stub
		return (BefReasonCode) mContext.getBean("befReasonCode");
	}
	
	@Override
	public BefBsLog getBefBsLog() {
		// TODO Auto-generated method stub
		return (BefBsLog) mContext.getBean("befBsLog");
	}
	
	@Override
	public BefCustomerType getBefCustomerType() {
		// TODO Auto-generated method stub
		return (BefCustomerType) mContext.getBean("befCustomerType");
	}

	@Override
	public BefMessage getBefMessage() {
		// TODO Auto-generated method stub
		return (BefMessage) mContext.getBean("befMessage");
	}
	
	@Override
	public BefReservedCardHistory getBefReservedCardHistory() {
		// TODO Auto-generated method stub
		return (BefReservedCardHistory) mContext.getBean("befReservedCardHistory");
	}
}
