/**
 *	Automatically generated file
 */
package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.BusinessEntity;

public class MassLoad extends BusinessEntity {
	/**										
	 * Storage: MASS_LOAD_T												
	 */										

	/**										
	 * Primary key				
	 */										
	private long mMassLoadId;

	/**										
	 * Common attributes	
	 */										
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;


	/**										
	 * Foreign keys				
	 */										
	private Range mRange;
	private java.util.Set<Amount> mAmounts = new java.util.LinkedHashSet<Amount>(0);
	private java.util.Set<Transaction> mTransactions = new java.util.LinkedHashSet<Transaction>(0);
	private BonusCode mBonusCode;
	private int mReasonCode;
	private String mCustomerType;


	/**										
	 * Data								
	 */										
	private String mName;
	private java.math.BigDecimal mAmount;
	private String mCurrencyCode;
	private java.util.Date mAuthorizedDateTime;
	private String mAuthorizedBy;
	private java.util.Date mReleasedDateTime;
	private String mReleasedBy;
	private java.util.Date mWithdrawnDateTime;
	private String mWithdrawnBy;
	private String mMassLoadState;
	private String mWishedMassLoadState;
	private String mWishedUserId;
	private String mCountryCode;
	private long mLockCount;
	private String mLockMessages;
	private String mAmountType;
	private String mBuType;
	private String mBuCode;
	private String mFromCardNumberString;
	private String mUntilCardNumberString;
	private long mCurrentCardNumberId;
	private String mCompanyName;

	/**											
	 * @return Returns the massLoadId.													
	 */											
	public long getMassLoadId() {
		return mMassLoadId;
	}
	/**
	 * @param pMassLoadId The massLoadId to set.
	 */
	public void setMassLoadId(long pMassLoadId) {
		mMassLoadId = pMassLoadId;
	}

	/**											
	 * @return Returns the name.													
	 */											
	public String getName() {
		return mName;
	}
	/**
	 * @param pName The name to set.
	 */
	public void setName(String pName) {
		mName = pName;
	}

	/**											
	 * @return Returns the amount.													
	 */											
	public java.math.BigDecimal getAmount() {
		return mAmount;
	}
	/**
	 * @param pAmount The amount to set.
	 */
	public void setAmount(java.math.BigDecimal pAmount) {
		mAmount = pAmount;
	}

	/**											
	 * @return Returns the currencyCode.													
	 */											
	public String getCurrencyCode() {
		return mCurrencyCode;
	}
	/**
	 * @param pCurrencyCode The currencyCode to set.
	 */
	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	/**											
	 * @return Returns the authorizedDateTime.													
	 */											
	public java.util.Date getAuthorizedDateTime() {
		return mAuthorizedDateTime;
	}
	/**
	 * @param pAuthorizedDateTime The authorizedDateTime to set.
	 */
	public void setAuthorizedDateTime(java.util.Date pAuthorizedDateTime) {
		mAuthorizedDateTime = pAuthorizedDateTime;
	}

	/**											
	 * @return Returns the authorizedBy.													
	 */											
	public String getAuthorizedBy() {
		return mAuthorizedBy;
	}
	/**
	 * @param pAuthorizedBy The authorizedBy to set.
	 */
	public void setAuthorizedBy(String pAuthorizedBy) {
		mAuthorizedBy = pAuthorizedBy;
	}

	/**											
	 * @return Returns the releasedDateTime.													
	 */											
	public java.util.Date getReleasedDateTime() {
		return mReleasedDateTime;
	}
	/**
	 * @param pReleasedDateTime The releasedDateTime to set.
	 */
	public void setReleasedDateTime(java.util.Date pReleasedDateTime) {
		mReleasedDateTime = pReleasedDateTime;
	}

	/**											
	 * @return Returns the releasedBy.													
	 */											
	public String getReleasedBy() {
		return mReleasedBy;
	}
	/**
	 * @param pReleasedBy The releasedBy to set.
	 */
	public void setReleasedBy(String pReleasedBy) {
		mReleasedBy = pReleasedBy;
	}

	/**											
	 * @return Returns the withdrawnDateTime.													
	 */											
	public java.util.Date getWithdrawnDateTime() {
		return mWithdrawnDateTime;
	}
	/**
	 * @param pWithdrawnDateTime The withdrawnDateTime to set.
	 */
	public void setWithdrawnDateTime(java.util.Date pWithdrawnDateTime) {
		mWithdrawnDateTime = pWithdrawnDateTime;
	}

	/**											
	 * @return Returns the withdrawnBy.													
	 */											
	public String getWithdrawnBy() {
		return mWithdrawnBy;
	}
	/**
	 * @param pWithdrawnBy The withdrawnBy to set.
	 */
	public void setWithdrawnBy(String pWithdrawnBy) {
		mWithdrawnBy = pWithdrawnBy;
	}

	/**											
	 * @return Returns the massLoadState.													
	 */											
	public String getMassLoadState() {
		return mMassLoadState;
	}
	/**
	 * @param pMassLoadState The massLoadState to set.
	 */
	public void setMassLoadState(String pMassLoadState) {
		mMassLoadState = pMassLoadState;
	}

	/**											
	 * @return Returns the wishedMassLoadState.													
	 */											
	public String getWishedMassLoadState() {
		return mWishedMassLoadState;
	}
	/**
	 * @param pWishedMassLoadState The wishedMassLoadState to set.
	 */
	public void setWishedMassLoadState(String pWishedMassLoadState) {
		mWishedMassLoadState = pWishedMassLoadState;
	}

	/**											
	 * @return Returns the wishedUserId.													
	 */											
	public String getWishedUserId() {
		return mWishedUserId;
	}
	/**
	 * @param pWishedUserId The wishedUserId to set.
	 */
	public void setWishedUserId(String pWishedUserId) {
		mWishedUserId = pWishedUserId;
	}

	/**											
	 * @return Returns the countryCode.													
	 */											
	public String getCountryCode() {
		return mCountryCode;
	}
	/**
	 * @param pCountryCode The countryCode to set.
	 */
	public void setCountryCode(String pCountryCode) {
		mCountryCode = pCountryCode;
	}

	/**											
	 * @return Returns the lockCount.													
	 */											
	public long getLockCount() {
		return mLockCount;
	}
	/**
	 * @param pLockCount The lockCount to set.
	 */
	public void setLockCount(long pLockCount) {
		mLockCount = pLockCount;
	}

	/**											
	 * @return Returns the lockMessages.													
	 */											
	public String getLockMessages() {
		return mLockMessages;
	}
	/**
	 * @param pLockMessages The lockMessages to set.
	 */
	public void setLockMessages(String pLockMessages) {
		mLockMessages = pLockMessages;
	}

	/**											
	 * @return Returns the amountType.													
	 */											
	public String getAmountType() {
		return mAmountType;
	}
	/**
	 * @param pAmountType The amountType to set.
	 */
	public void setAmountType(String pAmountType) {
		mAmountType = pAmountType;
	}

	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	/**											
	 * @return Returns the fromCardNumberString.													
	 */											
	public String getFromCardNumberString() {
		return mFromCardNumberString;
	}
	/**
	 * @param pFromCardNumberString The fromCardNumberString to set.
	 */
	public void setFromCardNumberString(String pFromCardNumberString) {
		mFromCardNumberString = pFromCardNumberString;
	}

	/**											
	 * @return Returns the untilCardNumberString.													
	 */											
	public String getUntilCardNumberString() {
		return mUntilCardNumberString;
	}
	/**
	 * @param pUntilCardNumberString The untilCardNumberString to set.
	 */
	public void setUntilCardNumberString(String pUntilCardNumberString) {
		mUntilCardNumberString = pUntilCardNumberString;
	}

	/**											
	 * @return Returns the currentCardNumberId.													
	 */											
	public long getCurrentCardNumberId() {
		return mCurrentCardNumberId;
	}
	/**
	 * @param pCurrentCardNumberId The currentCardNumberId to set.
	 */
	public void setCurrentCardNumberId(long pCurrentCardNumberId) {
		mCurrentCardNumberId = pCurrentCardNumberId;
	}

	/**											
	 * @return Returns the range.													
	 */											
	public Range getRange() {
		return mRange;
	}
	/**
	 * @param pRange The range to set.
	 */
	public void setRange(Range pRange) {
		mRange = pRange;
	}

	/**											
	 * @return Returns the amounts.													
	 */											
	public java.util.Set<Amount> getAmounts() {
		return mAmounts;
	}
	/**
	 * @param pAmounts The amounts to set.
	 */
	public void setAmounts(java.util.Set<Amount> pAmounts) {
		mAmounts = pAmounts;
	}

	/**											
	 * @return Returns the transactions.													
	 */											
	public java.util.Set<Transaction> getTransactions() {
		return mTransactions;
	}
	/**
	 * @param pTransactions The transactions to set.
	 */
	public void setTransactions(java.util.Set<Transaction> pTransactions) {
		mTransactions = pTransactions;
	}

	/**											
	 * @return Returns the bonusCode.													
	 */											
	public BonusCode getBonusCode() {
		return mBonusCode;
	}
	/**
	 * @param pBonusCode The bonusCode to set.
	 */
	public void setBonusCode(BonusCode pBonusCode) {
		mBonusCode = pBonusCode;
	}
	public int getReasonCode() {
		return mReasonCode;
	}
	public void setReasonCode(int mReasonCode) {
		this.mReasonCode = mReasonCode;
	}

	public String getCustomerType() {
		return mCustomerType;
	}
	public void setCustomerType(String pCustomerType) {
		mCustomerType = pCustomerType;
	}
	public String getCompanyName() {
		return mCompanyName;
	}
	public void setCompanyName(String pCompanyName) {
		mCompanyName = pCompanyName;
	}
	/**
	 * Connect Range.
	 * @param pRange
	 */
	public void connectRange(Range pRange) {
		setRange(pRange);
		if(pRange != null) {
			pRange.setMassLoad(this);
		}
	}

	/**
	 * Disconnect Range.
	 */
	public void disconnectRange() {
		if(getRange() != null) {
			getRange().setMassLoad(null);
		}
		setRange(null);
	}

	/**
	 * Connect a Amount.
	 * @param pAmount
	 */
	public void connectAmount(Amount pAmount) {
		getAmounts().add(pAmount);
		if(pAmount != null) {
			pAmount.setMassLoad(this);
		}
	}

	/**
	 * Disconnect a Amount.
	 * @param pAmount
	 */
	public void disconnectAmount(Amount pAmount) {
		if(pAmount != null) {
			pAmount.setMassLoad(null);
		}
		getAmounts().remove(pAmount);
	}

	/**
	 * Connect a Transaction.
	 * @param pTransaction
	 */
	public void connectTransaction(Transaction pTransaction) {
		getTransactions().add(pTransaction);
		if(pTransaction != null) {
			pTransaction.setMassLoad(this);
		}
	}

	/**
	 * Disconnect a Transaction.
	 * @param pTransaction
	 */
	public void disconnectTransaction(Transaction pTransaction) {
		if(pTransaction != null) {
			pTransaction.setMassLoad(null);
		}
		getTransactions().remove(pTransaction);
	}

	/**
	 * Connect BonusCode.
	 * @param pBonusCode
	 */
	public void connectBonusCode(BonusCode pBonusCode) {
		setBonusCode(pBonusCode);
		if(pBonusCode != null) {
			pBonusCode.getMassLoad().add(this);
		}
	}

	/**
	 * Disconnect BonusCode.
	 */
	public void disconnectBonusCode() {
		if(getBonusCode() != null) {
			getBonusCode().getMassLoad().remove(this);
		}
		setBonusCode(null);
	}
	/**
	 * Connect ReasonCode.
	 * @param pReasonCode
	 */
	/*public void connectReasonCode(ReasonCode pReasonCode) {
		setReasonCode(pReasonCode);
		if(pReasonCode != null) {
			pReasonCode.setMassLoad(this);
		}
	}

	*//**
	 * Disconnect Range.
	 *//*
	public void disconnectReasonCode() {
		if(getReasonCode() != null) {
			getReasonCode().setMassLoad(null);s
		}
		setReasonCode(null);
	}
*/
	/**											
	 * @return Returns the versionNo.													
	 */											
	public int getVersionNo() {
		return mVersionNo;
	}
	/**
	 * @param pVersionNo The versionNo to set.
	 */
	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	/**											
	 * @return Returns the createdBy.													
	 */											
	public String getCreatedBy() {
		return mCreatedBy;
	}
	/**
	 * @param pCreatedBy The createdBy to set.
	 */
	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	/**											
	 * @return Returns the createdDateTime.													
	 */											
	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}
	/**
	 * @param pCreatedDateTime The createdDateTime to set.
	 */
	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	/**											
	 * @return Returns the updatedBy.													
	 */											
	public String getUpdatedBy() {
		return mUpdatedBy;
	}
	/**
	 * @param pUpdatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	/**											
	 * @return Returns the updatedDateTime.													
	 */											
	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}
	/**
	 * @param pUpdatedDateTime The updatedDateTime to set.
	 */
	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#hasPrimaryKeySet()
	 */
	public boolean hasPrimaryKeySet() {
		boolean isSet = true;
		isSet = isSet && CodeGeneration.isSet(mMassLoadId);
		return isSet;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignToMap()
	 */
	public java.util.Map<String, Object> assignToMap() {
		java.util.Map<String, Object> vMap = super.assignToMap();
		vMap.put("massLoadId", CodeGeneration.toObject(mMassLoadId));
		vMap.put("name", CodeGeneration.toObject(mName));
		vMap.put("amount", CodeGeneration.toObject(mAmount));
		vMap.put("currencyCode", CodeGeneration.toObject(mCurrencyCode));
		vMap.put("authorizedDateTime", CodeGeneration.toObject(mAuthorizedDateTime));
		vMap.put("authorizedBy", CodeGeneration.toObject(mAuthorizedBy));
		vMap.put("releasedDateTime", CodeGeneration.toObject(mReleasedDateTime));
		vMap.put("releasedBy", CodeGeneration.toObject(mReleasedBy));
		vMap.put("withdrawnDateTime", CodeGeneration.toObject(mWithdrawnDateTime));
		vMap.put("withdrawnBy", CodeGeneration.toObject(mWithdrawnBy));
		vMap.put("massLoadState", CodeGeneration.toObject(mMassLoadState));
		vMap.put("wishedMassLoadState", CodeGeneration.toObject(mWishedMassLoadState));
		vMap.put("wishedUserId", CodeGeneration.toObject(mWishedUserId));
		vMap.put("countryCode", CodeGeneration.toObject(mCountryCode));
		vMap.put("lockCount", CodeGeneration.toObject(mLockCount));
		vMap.put("lockMessages", CodeGeneration.toObject(mLockMessages));
		vMap.put("amountType", CodeGeneration.toObject(mAmountType));
		vMap.put("buType", CodeGeneration.toObject(mBuType));
		vMap.put("buCode", CodeGeneration.toObject(mBuCode));
		vMap.put("fromCardNumberString", CodeGeneration.toObject(mFromCardNumberString));
		vMap.put("untilCardNumberString", CodeGeneration.toObject(mUntilCardNumberString));
		vMap.put("currentCardNumberId", CodeGeneration.toObject(mCurrentCardNumberId));
		vMap.put("versionNo", CodeGeneration.toObject(mVersionNo));
		vMap.put("createdBy", CodeGeneration.toObject(mCreatedBy));
		vMap.put("createdDateTime", CodeGeneration.toObject(mCreatedDateTime));
		vMap.put("updatedBy", CodeGeneration.toObject(mUpdatedBy));
		vMap.put("updatedDateTime", CodeGeneration.toObject(mUpdatedDateTime));
		vMap.put("reasonCode", CodeGeneration.toObject(mReasonCode));
		vMap.put("customerType", CodeGeneration.toObject(mCustomerType));
		vMap.put("companyName", CodeGeneration.toObject(mCompanyName));
		return vMap;
	}

	/* (non-Javadoc)
	 * @see com.ikea.mdsd.BusinessEntity#assignFromMap(java.util.Map)
	 */
	public void assignFromMap(java.util.Map<String, Object> pMap) {
		if(pMap.containsKey("massLoadId")) mMassLoadId = CodeGeneration.objectTolong(pMap.get("massLoadId"));
		if(pMap.containsKey("name")) mName = CodeGeneration.objectToString(pMap.get("name"));
		if(pMap.containsKey("amount")) mAmount = CodeGeneration.objectTojava_math_BigDecimal(pMap.get("amount"));
		if(pMap.containsKey("currencyCode")) mCurrencyCode = CodeGeneration.objectToString(pMap.get("currencyCode"));
		if(pMap.containsKey("authorizedDateTime")) mAuthorizedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("authorizedDateTime"));
		if(pMap.containsKey("authorizedBy")) mAuthorizedBy = CodeGeneration.objectToString(pMap.get("authorizedBy"));
		if(pMap.containsKey("releasedDateTime")) mReleasedDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("releasedDateTime"));
		if(pMap.containsKey("releasedBy")) mReleasedBy = CodeGeneration.objectToString(pMap.get("releasedBy"));
		if(pMap.containsKey("withdrawnDateTime")) mWithdrawnDateTime = CodeGeneration.objectTojava_util_Date(pMap.get("withdrawnDateTime"));
		if(pMap.containsKey("withdrawnBy")) mWithdrawnBy = CodeGeneration.objectToString(pMap.get("withdrawnBy"));
		if(pMap.containsKey("massLoadState")) mMassLoadState = CodeGeneration.objectToString(pMap.get("massLoadState"));
		if(pMap.containsKey("wishedMassLoadState")) mWishedMassLoadState = CodeGeneration.objectToString(pMap.get("wishedMassLoadState"));
		if(pMap.containsKey("wishedUserId")) mWishedUserId = CodeGeneration.objectToString(pMap.get("wishedUserId"));
		if(pMap.containsKey("countryCode")) mCountryCode = CodeGeneration.objectToString(pMap.get("countryCode"));
		if(pMap.containsKey("lockCount")) mLockCount = CodeGeneration.objectTolong(pMap.get("lockCount"));
		if(pMap.containsKey("lockMessages")) mLockMessages = CodeGeneration.objectToString(pMap.get("lockMessages"));
		if(pMap.containsKey("amountType")) mAmountType = CodeGeneration.objectToString(pMap.get("amountType"));
		if(pMap.containsKey("buType")) mBuType = CodeGeneration.objectToString(pMap.get("buType"));
		if(pMap.containsKey("buCode")) mBuCode = CodeGeneration.objectToString(pMap.get("buCode"));
		if(pMap.containsKey("fromCardNumberString")) mFromCardNumberString = CodeGeneration.objectToString(pMap.get("fromCardNumberString"));
		if(pMap.containsKey("untilCardNumberString")) mUntilCardNumberString = CodeGeneration.objectToString(pMap.get("untilCardNumberString"));
		if(pMap.containsKey("currentCardNumberId")) mCurrentCardNumberId = CodeGeneration.objectTolong(pMap.get("currentCardNumberId"));
		if(pMap.containsKey("reasonCode")) mReasonCode = CodeGeneration.objectToint(pMap.get("reasonCode"));
		if(pMap.containsKey("customerType")) mCustomerType = CodeGeneration.objectToString(pMap.get("customerType"));
		if(pMap.containsKey("companyName")) mCompanyName = CodeGeneration.objectToString(pMap.get("companyName"));
	}
}
