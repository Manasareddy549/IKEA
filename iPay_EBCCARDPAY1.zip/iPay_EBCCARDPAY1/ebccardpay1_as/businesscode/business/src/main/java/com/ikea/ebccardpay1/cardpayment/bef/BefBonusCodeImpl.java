/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.BonusCode;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 * 
 */
public class BefBonusCodeImpl extends BefAbstract<BonusCode> implements
		BefBonusCode {

	private final static Logger mCategory_findByCurrent = LoggerFactory
			.getLogger(BefBonusCodeImpl.class.getName() + ".findByCurrent");

	private final static Logger mCategory_findBySearch = LoggerFactory
			.getLogger(BefBonusCodeImpl.class.getName() + ".findBySearch");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefBonusCodeImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	public List<BonusCode> findByCurrent(String pCountryCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<BonusCode> vCriteria = new GenericCriteria<BonusCode>(
				vSession.createCriteria(BonusCode.class));
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria.add(Restrictions.isNull("disabledDateTime"));

		// To get just one per bonus
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByCurrent.isDebugEnabled()) {
			mCategory_findByCurrent.debug("Criteria: " + vCriteria.toString());
		}

		List<BonusCode> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByCurrent.info("No bonuses found.");
		} else {
			mCategory_findByCurrent.info("Found " + vList.size() + " bonuses.");
		}
		return vList;
	}

	public List<BonusCode> findBySearch(long pCode, String pNameLike,
			String pCountryCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<BonusCode> vCriteria = new GenericCriteria<BonusCode>(
				vSession.createCriteria(BonusCode.class));

		if (pCode != 0) {
			vCriteria.add(Expression.eq("code", new Long(pCode)));
		}
		if (pNameLike != null && pNameLike.length() > 0) {
			vCriteria.add(Expression.like("name", pNameLike, MatchMode.START));
		}
		if (pCountryCode != null && pCountryCode.length() > 0) {
			vCriteria.add(Expression.eq("countryCode", pCountryCode));
		}

		// To get just one per bonus
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findBySearch.isDebugEnabled()) {
			mCategory_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<BonusCode> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findBySearch.info("No bonus codes found.");
		} else {
			mCategory_findBySearch.info("Found " + vList.size()
					+ " bonus codes.");
		}
		return vList;
	}

	@Override
	protected Class<BonusCode> getBusinessEntityClass() {
		return BonusCode.class;
	}
}
