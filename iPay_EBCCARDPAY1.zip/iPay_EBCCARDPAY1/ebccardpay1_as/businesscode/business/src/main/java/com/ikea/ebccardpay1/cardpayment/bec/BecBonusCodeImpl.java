/*
 * Created on 2007-mar-23
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.services.IkeaUserProfile;
import com.ikea.ebccardpay1.cardpayment.be.BonusCode;
import com.ikea.ebccardpay1.cardpayment.bef.BefBonusCode;
import com.ikea.ebccardpay1.cardpayment.exception.BonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.DuplicateBonusCodeException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCode;
import com.ikea.ebccardpay1.cardpayment.vo.VoBonusCodeBriefRef;
import com.ikea.ebcframework.services.BsContext;
import com.ikea.common.TimeSource;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.mdsd.ValueObjects;
import org.springframework.beans.factory.annotation.Autowired;

import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 * 
 */
public class BecBonusCodeImpl implements BecBonusCode {

	private final static Logger mCategory = LoggerFactory
			.getLogger(BecBonusCodeImpl.class);

	// Dependencies injected at creation of this BEC
	private BefBonusCode mBefBonusCode = null;
	private TimeSource mTimeSource = null;

	// Entities that this BEC operates on
	private BonusCode mBonusCode = null;

	@Autowired
	private BsContext mBsContext;

	// Related Bec's that this Bec delegates work to

	/**
	 * 
	 */
	public BecBonusCodeImpl(BefBonusCode pBefBonusCode, TimeSource pTimeSource, BsContext pBsContext) {

		super();

		mBefBonusCode = pBefBonusCode;
		mTimeSource = pTimeSource;
		mBsContext = pBsContext;
	}

	void validate() {
		notNull(mBefBonusCode);
		notNull(mTimeSource);
		notNull(mBsContext);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init(long)
	 */
	public BecBonusCode init(long pBonusCodeId) {
		mBonusCode = mBefBonusCode.findByPrimaryKey(pBonusCodeId);
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonus#init(com.ikea.ebccardpay1
	 * .cardpayment.be.Bonus)
	 */
	public BecBonusCode init(BonusCode pBonusCode) {
		mBonusCode = pBonusCode;
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonusCode#getBonusCode()
	 */
	public BonusCode getBonusCode() {
		return mBonusCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecBonus#getVoBonusCode()
	 */
	public VoBonusCode getVoBonusCode() throws ValueMissingException {

		requireBonusCode();

		if (mBonusCode.isBusinessEntityDeleted()) {
			return null;
		}

		VoBonusCode vVoBonusCode = new VoBonusCode();
		ValueObjects.assignToValueObject(vVoBonusCode, mBonusCode);

		// Explicitly set disabled flag
		vVoBonusCode.setDisabled(mBonusCode.getDisabledDateTime() != null);

		mCategory.debug("Added bonus code " + vVoBonusCode.getBonusCodeId()
				+ " " + vVoBonusCode.getName());

		return vVoBonusCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonusCode#getVoBonusCodeBriefRef
	 * ()
	 */
	public VoBonusCodeBriefRef getVoBonusCodeBriefRef()
			throws ValueMissingException {

		requireBonusCode();

		VoBonusCodeBriefRef vVoBonusCodeBriefRef = new VoBonusCodeBriefRef();
		ValueObjects.assignToValueObject(vVoBonusCodeBriefRef, mBonusCode);

		mCategory.debug("Added bonus code "
				+ vVoBonusCodeBriefRef.getBonusCodeId() + " "
				+ vVoBonusCodeBriefRef.getName());

		return vVoBonusCodeBriefRef;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bec.BecBonusCode#manage(com.ikea.ebccardpay1
	 * .client.vo.VoBonusCode)
	 */
	public void manage(VoBonusCode pVoBonusCode) throws IkeaException,
			ValueMissingException, BonusCodeException {

		if (Constants.OBJECT_STATE_NEW.equals(pVoBonusCode.getObjectState())) {
			createBonusCode(pVoBonusCode);
		} else if (Constants.OBJECT_STATE_MODIFIED.equals(pVoBonusCode
				.getObjectState())) {
			updateBonusCode(pVoBonusCode);
		} else if (Constants.OBJECT_STATE_READ.equals(pVoBonusCode
				.getObjectState())) {
			// Sub entities are changed
			updateBonusCode(pVoBonusCode);
		} else if (Constants.OBJECT_STATE_REMOVED.equals(pVoBonusCode
				.getObjectState())) {
			removeBonusCode(pVoBonusCode);
		} else {
			throw new ValueMissingException(
					"Illegal Object State set! Can not handle '"
							+ pVoBonusCode.getObjectState() + "'.");
		}

	}

	// -----------------------------------------------------

	/**
	 * @param pVoBonusCode
	 * @throws IkeaException
	 */
	protected void createBonusCode(VoBonusCode pVoBonusCode)
			throws IkeaException, ValueMissingException, BonusCodeException {

		mBonusCode = mBefBonusCode.create();

		mCategory.info("Creating new bonus code '" + pVoBonusCode.getName()
				+ "'.");

		checkCode(pVoBonusCode);
		ValueObjects.assignToBusinessEntity(mBonusCode, pVoBonusCode);
		setDisabled(pVoBonusCode);
		mBefBonusCode.save(mBonusCode);
	}

	/**
	 * @param pVoBonusCode
	 */
	protected void updateBonusCode(VoBonusCode pVoBonusCode)
			throws ValueMissingException, BonusCodeException {

		init(pVoBonusCode.getBonusCodeId());
		requireBonusCode();

		mCategory.info("Updating bonus code '" + pVoBonusCode.getName() + "'.");

		checkCode(pVoBonusCode);
		ValueObjects.assignToBusinessEntity(mBonusCode, pVoBonusCode);
		setDisabled(pVoBonusCode);
		mBefBonusCode.save(mBonusCode);
	}

	/**
	 * @param pVoBonusCode
	 * @throws ValueMissingException
	 * @throws BonusCodeException
	 */
	protected void removeBonusCode(VoBonusCode pVoBonusCode)
			throws ValueMissingException, BonusCodeException {

		init(pVoBonusCode.getBonusCodeId());
		requireBonusCode();

		mCategory.info("Deleting bonus code '" + pVoBonusCode.getName() + "'.");

		mBefBonusCode.delete(mBonusCode);
	}

	/**
	 * @param pVoBonusCode
	 * @throws ValueMissingException
	 * @throws BonusCodeException
	 */
	protected void setDisabled(VoBonusCode pVoBonusCode)
			throws ValueMissingException, BonusCodeException {

		requireBonusCode();

		// Determine user profile
		IkeaUserProfile vIkeaUserProfile = mBsContext.getUserProfile();
		if (vIkeaUserProfile == null) {
			throw new ValueMissingException("User Profile could not be found");
		}
		String VUserId = vIkeaUserProfile.getUID();

		// Set Disabled handling
		if (!pVoBonusCode.getDisabled()) {
			mBonusCode.setDisabledBy(null);
			mBonusCode.setDisabledDateTime(null);
		} else if (pVoBonusCode.getDisabled()
				&& mBonusCode.getDisabledDateTime() == null) {
			mBonusCode.setDisabledBy(VUserId);
			mBonusCode.setDisabledDateTime(mTimeSource.currentDate());
		}
	}

	/**
	 * @throws ValueMissingException
	 * @throws BonusCodeException
	 */
	protected void checkCode(VoBonusCode pVoBonusCode)
			throws ValueMissingException, BonusCodeException {

		// Must check the values before assigning them to the BE (otherwise the
		// unique contraint will pop-up)

		if (pVoBonusCode == null) {
			return;
		}

		// Code can not be zero (zero is eqvivalent with not set)
		if (pVoBonusCode.getCode() == 0) {
			throw new BonusCodeException(
					"The code can not be zero. Was zero for '"
							+ pVoBonusCode.getName() + "'.");
		}

		if ((pVoBonusCode.getCountryCode() == null)
				|| (pVoBonusCode.getCountryCode().length() == 0)) {
			throw new BonusCodeException(
					"The country code must not be empty. Was empty for '"
							+ pVoBonusCode.getName() + "'.");
		}

		// Check if the code already exists for this country.
		List<BonusCode> vList = mBefBonusCode.findBySearch(
				pVoBonusCode.getCode(), null, pVoBonusCode.getCountryCode());
		if (vList != null && vList.size() > 0) {
			// We have found a bonus code with this code for the country
			BonusCode vBonusCode = (BonusCode) vList.get(0);
			if (vBonusCode.getBonusCodeId() != pVoBonusCode.getBonusCodeId()) {
				// It is not myself.
				throw new DuplicateBonusCodeException(
						"Another bonus code with code '"
								+ pVoBonusCode.getCode()
								+ "' already exists for country '"
								+ pVoBonusCode.getCountryCode() + "'.");
			}
		}
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireBonusCode() throws ValueMissingException {
		if (mBonusCode == null)
			throw new ValueMissingException(
					"Tried to use BecBonus without required BonusCode.");
	}

}
