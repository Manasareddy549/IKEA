/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.StringType;

import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

/**
 * @author anms
 * @author tpon
 *
 */
public class BefMassLoadImpl extends BefAbstract<MassLoad> implements BefMassLoad {

	private final static Logger mCategory_findByCurrent =
		LoggerFactory.getLogger(
			BefMassLoadImpl.class.getName() + ".findByCurrent");

	private final static Logger mCategory_findByCurrentFilter =
		LoggerFactory.getLogger(
			BefMassLoadImpl.class.getName() + ".findByCurrentFilter");

	private final static Logger mCategory_findByUnprocessed =
		LoggerFactory.getLogger(
			BefMassLoadImpl.class.getName() + ".findByUnprocessed");

	private final static Logger mCategory_findBySearch =
		LoggerFactory.getLogger(BefMassLoadImpl.class.getName() + ".findBySearch");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefMassLoadImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	* @see com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad#findByCurrent(java.lang.String, java.util.Date)
	*/
	public List<MassLoad> findByCurrent(String pCountryCode) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MassLoad> vCriteria = new GenericCriteria<MassLoad>(vSession.createCriteria(MassLoad.class));
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria.add(
			Restrictions.or(
				Restrictions.isNull("releasedDateTime"),
				Restrictions.sqlRestriction(
					"{alias}.released_date_time > (sysdate - 15)")));
		vCriteria.add(
			Restrictions.or(
				Restrictions.isNull("withdrawnDateTime"),
				Restrictions.sqlRestriction(
					"{alias}.withdrawn_date_time > (sysdate - 15)")));

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByCurrent.isDebugEnabled()) {
			mCategory_findByCurrent.debug("Criteria: " + vCriteria.toString());
		}

		List<MassLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByCurrent.info("No mass loads found.");
		} else {
			mCategory_findByCurrent.info(
				"Found " + vList.size() + " mass loads.");
		}
		return vList;
	}

	/* (non-Javadoc)
	* @see com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad#findByCurrent(java.lang.String, java.util.Date)
	*/
	public List<MassLoad> findByCurrentFilter(
		String pCountryCode,
		String pMassLoadState) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MassLoad> vCriteria = new GenericCriteria<MassLoad>(vSession.createCriteria(MassLoad.class));
		

		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));

		//Check filter, to get selected massLoad state
		if (pMassLoadState != null && !pMassLoadState.equals("")) {

			// MassLoadState RELEASED
			if (pMassLoadState
				.equals(Constants.MASS_LOAD_STATE_CONSTANT_RELEASED)) {
				vCriteria.add(
					Restrictions.or(
						Restrictions.sqlRestriction(
							"{alias}.mass_load_state = ? and {alias}.released_date_time > (sysdate - 15)",
							pMassLoadState,
							StringType.INSTANCE),
						Restrictions.eq(
							"wishedMassLoadState",
							pMassLoadState)));

				// MassLoadState WITHDRAWN
			} else if (
				pMassLoadState.equals(
					Constants.MASS_LOAD_STATE_CONSTANT_WITHDRAWN)) {

				vCriteria.add(
					Restrictions.or(
						Restrictions.sqlRestriction(
							"{alias}.mass_load_state = ? and {alias}.withdrawn_date_time > (sysdate - 15)",
							pMassLoadState,
							StringType.INSTANCE),
						Restrictions.eq(
							"wishedMassLoadState",
							pMassLoadState)));
				vCriteria.add(
					Restrictions.or(
						Restrictions.sqlRestriction(
							"{alias}.released_date_time > (sysdate - 15)"),
						Restrictions.sqlRestriction(
							"{alias}.authorized_date_time > (sysdate - 15)")));

			} else {
				// MassLoadState INITIATED, LOCKED, AUTHORIZED
				vCriteria.add(
					Restrictions.or(
						Restrictions.eq("massLoadState", pMassLoadState),
						Restrictions.eq(
							"wishedMassLoadState",
							pMassLoadState)));

			}

		}

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByCurrentFilter.isDebugEnabled()) {
			mCategory_findByCurrentFilter.debug(
				"Criteria: " + vCriteria.toString());
		}

		List<MassLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByCurrentFilter.info("No mass loads found.");
		} else {
			mCategory_findByCurrentFilter.info(
				"Found " + vList.size() + " mass loads.");
		}
		return vList;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad#findByUnprocessed()
	 */
	public List<MassLoad> findByUnprocessed() {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MassLoad> vCriteria = new GenericCriteria<MassLoad>(vSession.createCriteria(MassLoad.class));
		vCriteria.add(
			Restrictions.eq(
				"massLoadState",
				Constants.MASS_LOAD_STATE_CONSTANT_PROCESSING));

		// Just take the ones that have not been updated for 60 minutes
		vCriteria.add(
			Restrictions.sqlRestriction(
				"{alias}.UPDATED_DATE_TIME < sysdate-(60/(24*60))"));

		// To get just one per mass load
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByUnprocessed.isDebugEnabled()) {
			mCategory_findByUnprocessed.debug(
				"Criteria: " + vCriteria.toString());
		}

		List<MassLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByUnprocessed.info("No mass loads found.");
		} else {
			mCategory_findByUnprocessed.info(
				"Found " + vList.size() + " mass loads.");
		}
		return vList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefMassLoad#findBySearch(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<MassLoad> findBySearch(
		String pNameLike,
		String pBuType,
		String pBuCode,
		String pCountryCode,
		long pBonusCodeId,
		Date pReleasedDateTime,
		Date pCreatedDateTime) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<MassLoad> vCriteria = new GenericCriteria<MassLoad>(vSession.createCriteria(MassLoad.class));

		if (pNameLike != null && pNameLike.length() > 0) {
			vCriteria.add(Restrictions.like("name", "%" + pNameLike + "%"));
		}
		if (pBuType != null && pBuType.length() > 0) {
			vCriteria.add(Restrictions.eq("buType", pBuType));
		}
		if (pBuCode != null && pBuCode.length() > 0) {
			vCriteria.add(Restrictions.eq("buCode", pBuCode));
		}
		if (pCountryCode != null && pCountryCode.length() > 0) {
			vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		}

		if (pBonusCodeId > 0) {
			vCriteria.createCriteria("bonusCode").add(
				Restrictions.eq("bonusCodeId", new Long(pBonusCodeId)));
		}

		if (pReleasedDateTime != null) {
			vCriteria.add(
				Restrictions.ge("releasedDateTime", pReleasedDateTime));
		}
		if (pCreatedDateTime != null) {
			vCriteria.add(Restrictions.ge("createdDateTime", pCreatedDateTime));
		}

		if (mCategory_findBySearch.isDebugEnabled()) {
			mCategory_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<MassLoad> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findBySearch.info("No mass loads found.");
		} else {
			mCategory_findBySearch.info(
				"Found " + vList.size() + " mass loads.");
		}

		return vList;
	}

	@Override
	protected Class<MassLoad> getBusinessEntityClass() {
		return MassLoad.class;
	}
	
	//@Override
	public List<Transaction> getMassLoadedTranscation(MassLoad pMassLoad) throws Exception {
		
		Session vSession = mSessionFactory.getCurrentSession();
		GenericCriteria<Transaction> vCriteria = new GenericCriteria<Transaction>(vSession.createCriteria(Transaction.class));
		vCriteria.add(Restrictions.eq("massLoad", pMassLoad));
		return vCriteria.list();
	}

}
