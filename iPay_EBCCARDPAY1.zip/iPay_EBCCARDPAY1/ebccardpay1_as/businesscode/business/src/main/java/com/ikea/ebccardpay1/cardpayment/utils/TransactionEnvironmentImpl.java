package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Date;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.persistence.keygenerator.IkeaKeyGenerator;
import com.ikea.ebcframework.services.BsContext;

public class TransactionEnvironmentImpl implements TransactionEnvironment {

	/**
	 * Dependency
	 */
	String mReference;
	String mSourceSystem;
	Date mTransmissionDateTime;
	boolean mAutoAcknowledge;
	String mEmployee;
	String mPointOfSale;
	String mReceipt;
	String mSwiped;
	Long mAckTimeout;
    private BsContext mBsContext;
    private IkeaKeyGenerator mIkeaKeyGenerator;

	/*
	 * Internals
	 */
	long mTransactionNo = 0;

	/**
	 * Dependency injection
	 */
	protected TransactionEnvironmentImpl(
		String pReference,
		String pSourceSystem,
		Date pTransmissionDateTime,
		boolean pAutoAcknowledge,
		String pEmployee,
		String pPointOfSale,
		String pReceipt,
		String pSwiped,
		long pAckTimeout, 
		BsContext pBsContext, 
		IkeaKeyGenerator pKeyGenerator) {

		mReference = pReference;
		mSourceSystem = pSourceSystem;
		mTransmissionDateTime = pTransmissionDateTime;
		mAutoAcknowledge = pAutoAcknowledge;
		mEmployee = pEmployee;
		mPointOfSale = pPointOfSale;
		mReceipt = pReceipt;
		mSwiped = pSwiped;
		mAckTimeout = pAckTimeout;
		mBsContext = pBsContext;
		mIkeaKeyGenerator = pKeyGenerator;
	}
	
	

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getReference()
	 */
	public String getReference() {
		return mReference;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getSourceSystem()
	 */
	public String getSourceSystem() {
		return mSourceSystem;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getTransmissionDateTime()
	 */
	public Date getTransmissionDateTime() {
		return mTransmissionDateTime;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getAutoAcknowledge()
	 */
	public boolean getAutoAcknowledge() {
		return mAutoAcknowledge;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getEmployee()
	 */
	public String getEmployee() {
		return mEmployee;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getPointOfSale()
	 */
	public String getPointOfSale() {
		return mPointOfSale;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getReceipt()
	 */
	public String getReceipt() {
		return mReceipt;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getSwiped()
	 */
	public String getSwiped() {
		return mSwiped;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment#getTransactionNo()
	 */
	public long getTransactionNo() throws IllegalStateException {
		if (mTransactionNo == 0) {
			mTransactionNo = nextTransactionNo();
		}
		return mTransactionNo;
	}

	/**
	 * Gets the next transaction no
	 * @return
	 * @throws IllegalStateException
	 */
	protected long nextTransactionNo() throws IllegalStateException {

		try {
			return mIkeaKeyGenerator.getNextKey(
                    mBsContext.getEbcName(),
                    "TRANSACTION_NO");

		} catch (IkeaException e) {
			IllegalStateException e2 =
				new IllegalStateException(
					"Error when trying to get next transaction number (TRANSACTION_NO) using IKEA Key generator! "
						+ e);
			e2.initCause(e);
			throw e2;
		}

	}

	public long getAckTimeout() {
		return mAckTimeout;
	}

}
