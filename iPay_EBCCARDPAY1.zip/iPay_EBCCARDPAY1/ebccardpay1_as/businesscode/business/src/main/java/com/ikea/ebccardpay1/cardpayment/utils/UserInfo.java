/*
 * Created on 2008-mar-31
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.Serializable;

/**
 * @author dalq
 *
 */
public class UserInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7716868960808884432L;
	private String mCountryCode;
	private String mUid;

	/**
	 * 
	 */
	public UserInfo() {
		super();
	}

	/**
	 * @return
	 */
	public String getCountryCode() {
		return mCountryCode;
	}

	/**
	 * @param string
	 */
	public void setCountryCode(String string) {
		mCountryCode = string;
	}

	/**
	 * @return
	 */
	public String getUid() {
		return mUid;
	}

	/**
	 * @param string
	 */
	public void setUid(String string) {
		mUid = string;
	}

}
