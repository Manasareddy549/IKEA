/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.UnacknowledgedTimeout;
import com.ikea.ebccardpay1.cardpayment.bef.BefUnacknowledgedTimeout;
import com.ikea.ebccardpay1.cardpayment.exception.UnacknowledgedTimeoutException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;


public class BecUnacknowledgedTimeoutImpl implements BecUnacknowledgedTimeout {
	
	private final static Logger mCategory =
		LoggerFactory.getLogger(BecUnacknowledgedTimeoutImpl.class);

	/**
	 * Dependencies
	 */
	private BefUnacknowledgedTimeout mBefUnacknowledgedTimeout;

	// Entities that this BEC operates on
	private Card mCard;

	// Related Bec's that this Bec delegates work to
	BecTransactions mBecTransactions = null;

	private BusinessUnitEnvironment mBusinessUnitEnvironment = null;
	private TransactionEnvironment mTransactionEnvironment = null;

	/**
	 * Dependecy injection
	 */
	protected BecUnacknowledgedTimeoutImpl(
		
		BefUnacknowledgedTimeout pBefUnacknowledgedTimeout) {

		mBefUnacknowledgedTimeout = pBefUnacknowledgedTimeout;
	}
	
	void validate() {
		Validate.notNull(mBefUnacknowledgedTimeout);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#init(com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecUnacknowledgedTimeout init(
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment) {

		return init(null, pBusinessUnitEnvironment, pTransactionEnvironment);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck#init(com.ikea.ebccardpay1.cardpayment.be.Card, com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment)
	 */
	public BecUnacknowledgedTimeout init(
		Card pCard,
		BusinessUnitEnvironment pBusinessUnitEnvironment,
		TransactionEnvironment pTransactionEnvironment) {

		mCard = pCard;
		mBusinessUnitEnvironment = pBusinessUnitEnvironment;
		mTransactionEnvironment = pTransactionEnvironment;

		mBecTransactions.init(
			mBusinessUnitEnvironment,
			mTransactionEnvironment);

		return this;
	}

	public UnacknowledgedTimeout getUnacknowledgedTimeout(String pBuCode,String pBuType,String pSourceSystem)
			throws UnacknowledgedTimeoutException, ValueMissingException {
		UnacknowledgedTimeout vUnacknowledgedTimeout =mBefUnacknowledgedTimeout.getUnacknowledgedTimeout(pBuCode,pBuType,pSourceSystem);
		return vUnacknowledgedTimeout;
		
	}

		
}
