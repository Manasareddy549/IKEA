/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 * CardNotFoundException is thrown if a card with this card number can not be found.
 */
public class CardNotFoundException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8163552001769247074L;
	
	public CardNotFoundException() {
		super();
	}
	public CardNotFoundException(String pMessage) {
		super(pMessage);
	}
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.CardNotFound();
	}
}
