package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.JobCreatorSchedule;

public interface BefJobCreatorSchedule extends Bef<JobCreatorSchedule> {


}