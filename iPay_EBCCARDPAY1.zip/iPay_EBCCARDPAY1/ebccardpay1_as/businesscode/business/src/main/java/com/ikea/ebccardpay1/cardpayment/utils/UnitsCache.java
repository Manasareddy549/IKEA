/*
 * Created on 2007-jan-26
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Collection;

import com.ikea.ebccardpay1.cardpayment.exception.*;

/**
 * @author anms
 *
 */
public interface UnitsCache {

	/**
	 * Fetches the BU info
	 * @param pBuType Business Unit type
	 * @param pBuCode Business Unit code
	 * @return the BU info
	 * @throws BusinessUnitException if the BU does not exist or if internal errors
	 */
	public Unit fetch(String pBuType, String pBuCode)
		throws BusinessUnitException;

	/**
	 * Fetches BU info for all BU
	 * @return a Collection of Unit objects sorted by BU
	 * @throws IllegalStateException if the cache has not been built.
	 */
	public Collection<Unit> all() throws BusinessUnitException;

	/**
	 * A string represenation of the content of this cache.
	 */
	public String toString();

}
