package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.IOException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.tz.ZoneInfoProvider;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;

import com.ikea.cds.time.StartSlashRemovingClassLoader;

public class Dates {

	private final static Logger mCategory = LoggerFactory.getLogger(Dates.class);

	private static final int BREAK_HOUR = 3;

	/**
	 * 
	 */
	static ZoneInfoProvider sZoneInfoProvider = null;

	protected static DateTimeZone sIkeaZone = DateTimeZone.UTC;

	/**
	 * 
	 * @return
	 */
	protected static ZoneInfoProvider getZoneInfoProvider() {

		if (sZoneInfoProvider == null) {
			try {
				sZoneInfoProvider =
					new ZoneInfoProvider(
						"",
						new StartSlashRemovingClassLoader());
			} catch (IOException e) {
				mCategory.error(
					"Failed to initialise time zone provider for Joda Time.",
					e);
				IllegalStateException e2 =
					new IllegalStateException("Failed to initialise time zone provider for Joda Time.");
				e2.setStackTrace(e.getStackTrace());
				throw e2;
			}
		}
		return sZoneInfoProvider;
	}

	/**
	 * 
	 * @param pTimeZoneId
	 * @return
	 */
	public static DateTimeZone dateTimeZoneForId(String pTimeZoneId) {
		return getZoneInfoProvider().getZone(pTimeZoneId);
	}

	/**
	 * @return string at HH:MM:SS format
	 */
	public static String formatDateToTime(
		Date pDate,
		boolean pIncludeSeconds) {
		DateTime vDateTime = new DateTime(pDate, sIkeaZone);
		return Dates.formatTime(vDateTime, pIncludeSeconds);
	}

	/**
	 * @return a date object
	 */
	public static Date parse(String pUtc_YYYYMMDD_HHMMDD) {
		DateTime vDateTime = Dates.parseDateTime(pUtc_YYYYMMDD_HHMMDD);
		return vDateTime.toDate();
	}

	/**
	 * Change the time of the day to be set at breaking point, e.g. when the store has done end-of-day.
	 * For example the statistics will be calculated 2006-11-22 02:00:00 to 2006-11-23 02:00:00,
	 * because thire might be store that are open until 00:00:00 and theire might be tsranactions comming in
	 * after midnight that shall belong to the previous sales date.
	 * @param pCal the date to change the time for.
	 */
	public static DateTime withBreakPoint(DateTime pDateTime,int vBreakhour) {
		return pDateTime.withHourOfDay(vBreakhour);
	}

	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static boolean passedBreakingPoint(DateTime pDateTime, int breakhour) {
		return pDateTime.hourOfDay().get() >= breakhour;
	}

	/**
	 * 
	 * @param pDate
	 * @return
	 */
	public static Date withoutTime(DateTime pDateTime) {

		String vYYYYMMDD = Dates.formatDate(pDateTime);
		return Dates.parseDate(vYYYYMMDD).toDate();
	}

	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static DateTime getDateTime(Date pDate) {
		return new DateTime(pDate, sIkeaZone);
	}
	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static DateTime withNextDay(DateTime pDateTime) {
		return pDateTime.plusDays(1);
	}
	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static DateTime withAddedAckTime(DateTime pDateTime,long pAckTimeout) {
		return pDateTime.plusSeconds((int) pAckTimeout);
	}
	/**
	 * 
	 * @param pDateTime
	 * @return
	 */
	public static DateTime withPrevDay(DateTime pDateTime) {
		return pDateTime.minusDays(1);
	}

	/**
	 * 
	 * @param pUTC
	 * @param pTimeZoneId
	 * @return
	 */
	public static DateTime localDateTime(Date pUTC, String pTimeZoneId) {

		DateTimeZone vZone = getZoneInfoProvider().getZone(pTimeZoneId);

		return new DateTime(pUTC, vZone);
	}

	/**
	 * 
	 * @param pDateTime
	 * @return a string with format yyyy-MM-dd hh:mm:ss, 
	 * for example 2006-05-07 17:20:00 for may the 7th 2006 at twenty minutes past five o'clock in the afternoon.
	 */
	public static String formatDateTime(
		DateTime pDateTime,
		boolean pIncludeSeconds) {
		return formatDate(pDateTime)
			+ " "
			+ formatTime(pDateTime, pIncludeSeconds);
	}

	/**
	 * 
	 * @param pDateTime
	 * @param pIncludeSeconds Include seconds in time string
	 * 
	 * @return a string with format hh:mm:ss, 
	 * for example 17:20:00 for may the 7th 2006 at twenty minutes past five o'clock in the afternoon.
	 */
	public static String formatTime(
		DateTime pDateTime,
		boolean pIncludeSeconds) {

		String vTime =
			padZero(pDateTime.hourOfDay().get())
				+ ":"
				+ padZero(pDateTime.minuteOfHour().get());
		if (pIncludeSeconds) {
			vTime += ":" + padZero(pDateTime.secondOfMinute().get());
		}
		return vTime;
	}

	/**
	 * 
	 * @param pDateTime
	 * @return a string with format yyyy-MM-dd, for example 2006-05-07 for may the 7th 2006
	 */
	public static String formatDate(DateTime pDateTime) {
		return ""
			+ pDateTime.year().get()
			+ "-"
			+ padZero(pDateTime.monthOfYear().get())
			+ "-"
			+ padZero(pDateTime.dayOfMonth().get());
	}

	/**
	 * @param pIn
	 * @return
	 */
	private static String padZero(int pIn) {
		String vIn = "" + pIn;
		String vOut = vIn;
		if (vIn.length() == 1) {
			vOut = "0" + vIn;
		}
		return vOut;
	}

	/**
	 * 
	 * @param pYYYY_MM_DD on the format yyyy-MM-dd for example 2006-05-03
	 * @return a DateTime object with just year, month and day set based on UTC time zone
	 */
	public static DateTime parseDate(String pUtcString_YYYYMMDD) {

		return parseDate(pUtcString_YYYYMMDD, sIkeaZone);
	}

	/**
	 * 
	 * @param pYYYY_MM_DD on the format yyyy-MM-dd for example 2006-05-03
	 * @param pTimeZoneId time zone this calendar is based on
	 * @return a DateTime object with just year, month and day set based on the givven time zone.
	 */
	public static DateTime parseDate(
		String pLocalString_YYYYMMDD,
		String pTimeZoneId) {

		// Create time zone
		return parseDate(
			pLocalString_YYYYMMDD,
			getZoneInfoProvider().getZone(pTimeZoneId));
	}

	/**
	 * Internal
	 * @param pYYYY_MM_DD_String
	 * @param pTimeZone
	 * @return
	 */
	private static DateTime parseDate(
		String pYYYYMMDD,
		DateTimeZone pDateTimeZone) {

		DateTime vDateTime =
			new DateTime(
				Integer.parseInt(pYYYYMMDD.substring(0, 4)),
				Integer.parseInt(pYYYYMMDD.substring(5, 7)),
				Integer.parseInt(pYYYYMMDD.substring(8, 10)),
				0,
				0,
				0,
				0,
				pDateTimeZone);

		return vDateTime;
	}

	/**
	 * 
	 * @param pUtcString_HHMMSS on the format HH:MM:SS for example 10:00:00
	 * @return a DateTime object with just hour, minutes and seconds set based on UTC time zone
	 */
	public static DateTime parseTime(String pUtcString_HHMMSS) {

		return parseTime(pUtcString_HHMMSS, sIkeaZone);
	}

	/**
	 * 
	 * @param pLocalString_HHMMSS on the format HH:MM:SS for example 10:00:00
	 * @param pTimeZoneId time zone this calendar is based on
	 * @return a DateTime object with just hour, minutes and seconds set based on the given time zone.
	 */
	public static DateTime parseTime(
		String pLocalString_HHMMSS,
		String pTimeZoneId) {

		// Create time zone
		return parseTime(
			pLocalString_HHMMSS,
			getZoneInfoProvider().getZone(pTimeZoneId));
	}

	/**
	 * Internal
	 * @param pYYYY_MM_DD_String
	 * @param pTimeZone
	 * @return
	 */
	private static DateTime parseTime(
		String pHHMMSS,
		DateTimeZone pDateTimeZone) {

		DateTime vDateTime =
			new DateTime(
				1967,
				11,
				20,
				Integer.parseInt(pHHMMSS.substring(0, 2)),
				Integer.parseInt(pHHMMSS.substring(3, 5)),
				Integer.parseInt(pHHMMSS.substring(6, 8)),
				0,
				pDateTimeZone);

		return vDateTime;
	}

	/**
	 * 
	 * @param pString on the format yyyy-MM-dd hh:mm:ss for example 2006-12-13 20:58:34
	 * @param pTimeZoneId time zone this calendar is based on
	 * @return a DateTime object with year, month, day, hour, minute and seconds set based on givven time zone
	 */
	public static DateTime parseDateTime(
		String pLocalString,
		String pTimeZoneId) {

		// Create time zone
		return parseDateTime(
			pLocalString,
			getZoneInfoProvider().getZone(pTimeZoneId));
	}

	/**
	 * 
	 * @param pString on the format yyyy-MM-dd hh:mm:ss for example 2006-12-13 20:58:34
	 * @return a DateTime object with year, month, day, hour, minute and seconds set based on UTC tiem zone
	 */
	public static DateTime parseDateTime(String pUtcString) {
		return parseDateTime(pUtcString, sIkeaZone);
	}

	/**
	 * Internal
	 * @param pString
	 * @return
	 */
	protected static DateTime parseDateTime(
		String pYYYYMMDD_HHMMSS,
		DateTimeZone pDateTimeZone) {

		DateTime vDateTime =
			new DateTime(
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(0, 4)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(5, 7)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(8, 10)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(11, 13)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(14, 16)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(17, 19)),
				0,
				pDateTimeZone);

		return vDateTime;
	}

	/**
	 * 
	 * @param pDate
	 * @return
	 */
	public static String calculateSalesDay(
			Units pUnits,
			Date pUtc,
			String pBuType,
			String pBuCode,
			BefIpayBusinessUnits mBefIpayBusinessUnits
	) {

		String vTimeZoneId = pUnits.getTimeZone(pBuType, pBuCode);

		DateTimeZone vZone = getZoneInfoProvider().getZone(vTimeZoneId);

		DateTime vDateTime = new DateTime(pUtc, vZone);
		// Updated by srder to compare the Break hour with iPayBusinessunits value
		// If The value return from ipay business units is Null then break Hour is set to 3
		// or else the break hour will be compared with ipay business units value for the store.
		int vBreakhour = 0;

		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(pBuType, pBuCode);

		if(vIpayBusinessUnits!=null){
			if(	vIpayBusinessUnits.getBreakHour()!=null){

				vBreakhour= Integer.parseInt(vIpayBusinessUnits.getBreakHour());

			}else{
				vBreakhour=BREAK_HOUR;
			}
		}
		if (!Dates.passedBreakingPoint(vDateTime,vBreakhour)) {
			// If we have not passed breaking hour then 
			// this shall be registered on the preivous sales date
			// After midnight sales shall belong to the previos date.
			vDateTime = Dates.withPrevDay(vDateTime);
		}

		return Dates.formatDate(vDateTime);
	}

	public static Date convertToLocalDate(
		Units pUnits,
		Date pUtc,
		String pBuType,
		String pBuCode) {

		String vTimeZoneId = pUnits.getTimeZone(pBuType, pBuCode);

		DateTimeZone vZone = getZoneInfoProvider().getZone(vTimeZoneId);

		DateTime vDateTime = new DateTime(pUtc, vZone);

		return Dates.withoutTime(vDateTime);

	}

	public static DateTime localDateTime(DateTime pUTC, String pTimeZoneId) {
		DateTimeZone vZone = getZoneInfoProvider().getZone(pTimeZoneId);
		return new DateTime(pUTC, vZone);
	}

}
