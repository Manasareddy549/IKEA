/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.CardTypeConstant;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 *
 */
public class BefCardTypeConstantImpl extends BefAbstract<CardTypeConstant> implements BefCardTypeConstant {
	
	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCardTypeConstantImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	@Override
	protected Class<CardTypeConstant> getBusinessEntityClass() {
		return CardTypeConstant.class;
	}
}
