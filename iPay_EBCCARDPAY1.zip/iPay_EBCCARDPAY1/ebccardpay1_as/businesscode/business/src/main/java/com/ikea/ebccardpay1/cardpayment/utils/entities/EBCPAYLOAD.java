package com.ikea.ebccardpay1.cardpayment.utils.entities;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "EBCPAYLOAD")
public class EBCPAYLOAD implements Serializable{
	
	private Data data;

	public Data getData() {
		return data;
	}

	@XmlElement(name = "Data")
	public void setData(Data data) {
		this.data = data;
	}
	
}
