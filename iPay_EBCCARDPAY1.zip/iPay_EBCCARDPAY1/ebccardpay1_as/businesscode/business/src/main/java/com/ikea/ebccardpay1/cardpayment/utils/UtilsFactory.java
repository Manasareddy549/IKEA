package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpay1.cardpayment.vo.VoEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoOriginator;
import com.ikea.ebccardpay1.cardpayment.vo.VoReference;
import com.ikea.ebccardpay1.cardpayment.vo.VoSourceSystem;

public interface UtilsFactory {

	/**
	 * 
	 * @return
	 */
	public UserEnvironment createUserEnvironment();

	/**
	 * 
	 * @param pVoReference
	 * @param pVoSourceSystem
	 * @param pVoEnvironment
	 * @return A transaction enviroment based on provided parameters
	 */
	public abstract TransactionEnvironment createTransactionEnvironment(
		String pSwiped,
		VoOriginator pVoOriginator,
		VoReference pVoReference,
		VoSourceSystem pVoSourceSystem,
		VoEnvironment pVoEnvironment);

	/**
	 * 
	 * @param pTransaction
	 * @return A transaction enviroment based on provided parameters
	 */
	public abstract TransactionEnvironment createTransactionEnvironment(
		String pSourceSystem,
		Transaction pTransaction);

	/**
	 * @param pSwiped
	 * @param pVoOriginator
	 * @param pVoSourceSystem
	 * @return
	 */
	public abstract TransactionEnvironment createTransactionEnvironment(
		String pSwiped,
		VoOriginator pVoOriginator,
		VoSourceSystem pVoSourceSystem);

	/**
	 * @param pVoSourceSystem
	 * @return
	 */
	public abstract TransactionEnvironment createTransactionEnvironment(VoSourceSystem pVoSourceSystem);

	/**
	 * @param pVoOriginator
	 * @return
	 */
	public abstract BusinessUnitEnvironment createBusinessUnitEnvironment(VoOriginator pVoOriginator);

	/**
	 * @param pVoBusinessUnit
	 * @return
	 */
	public abstract BusinessUnitEnvironment createBusinessUnitEnvironment(VoBusinessUnit pVoBusinessUnit);

	/**
	 * @param pTransaction
	 * @return
	 */
	public abstract BusinessUnitEnvironment createBusinessUnitEnvironment(Transaction pTransaction);
	
	/**
	 * @param pReserverdCardHistory
	 * @return
	 */
	public abstract BusinessUnitEnvironment createBusinessUnitEnvironment(ReservedCardHistory pReservedCardHistory);

	/**
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 */
	public abstract BusinessUnitEnvironment createBusinessUnitEnvironment(
		String pBuType,
		String pBuCode);

	/**
	 * 
	 * @return
	 */
	public abstract EbcEnvironment getEbcEnvironment();

	/**
	 * Creates a new empty VO object
	 * @return
	 */
	public VoLoadAmount createVoLoadAmount();

	/**
	 * Get the Units object
	 * @return
	 */
	public Units getUnits();

	/**
	 * Get the Currencies object
	 * @return
	 */
	public Currencies getCurrencies();

	/**
	 * Get the CountrySetups object
	 * @return
	 */
	public CountrySetups getCountrySetups();

	/**
	 * Gets the PriorityEvaluator
	 * @return
	 */
	PriorityEvaluator createPriorityEvaluator();

}
