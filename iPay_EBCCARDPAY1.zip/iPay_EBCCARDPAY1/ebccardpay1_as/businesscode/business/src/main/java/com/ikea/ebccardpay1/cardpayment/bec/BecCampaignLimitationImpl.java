/*
 * Created on 2007-apr-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import org.apache.commons.lang.Validate;

import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.bef.BefCampaignLimitation;
import com
	.ikea
	.ebccardpay1
	.cardpayment
	.exception
	.CampaignLimitationNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;

/**
 * @author anms
 *
 */
public class BecCampaignLimitationImpl implements BecCampaignLimitation {

	// Dependencies injected at creation of this BEC
	private BefCampaignLimitation mBef;

	// Entity that this BEC operates on
	CampaignLimitation mCampaignLimitation;

	/**
	 * 
	 */
	public BecCampaignLimitationImpl(
		BefCampaignLimitation pBef) {
		super();

		mBef = pBef;
	}
	
	public void validate() {
		Validate.notNull(mBef);
		
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaignLimitation#init(long)
	 */
	public BecCampaignLimitation init(long pCampaignLimitationId)
		throws CampaignLimitationNotFoundException {

		mCampaignLimitation = mBef.findByPrimaryKey(pCampaignLimitationId);
		if (mCampaignLimitation == null) {
			throw new IllegalStateException("ID " + pCampaignLimitationId);
		}
		return this;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaignLimitation#getCampaignLimitation()
	 */
	public CampaignLimitation getCampaignLimitation()
		throws ValueMissingException {
		requireCampaignLimitation();
		return mCampaignLimitation;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaignLimitation#create(java.lang.String, java.lang.String)
	 */
	public void create(String pBuType, String pBuCode) {
		mCampaignLimitation = mBef.create();
		mCampaignLimitation.setBuType(pBuType);
		mCampaignLimitation.setBuCode(pBuCode);
	}


	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCampaignLimitation#save()
	 */
	public void save() throws ValueMissingException {
		requireCampaignLimitation();
		mBef.save(mCampaignLimitation);
		
	}

	public void delete() throws ValueMissingException {
		requireCampaignLimitation();

		mBef.delete(mCampaignLimitation);
	}

	/**
	 * 
	 * @throws ValueMissingException
	 */
	protected void requireCampaignLimitation() throws ValueMissingException {
		if (mCampaignLimitation == null)
			throw new ValueMissingException("Tried to use BecCampaignLimitation without required CampaignLimitation.");
	}

	



}
