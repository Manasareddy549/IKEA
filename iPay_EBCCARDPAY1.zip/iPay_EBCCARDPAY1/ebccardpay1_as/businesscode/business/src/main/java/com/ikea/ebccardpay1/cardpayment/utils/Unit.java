/*
 * Created on 2007-jan-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.Serializable;

import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;

/**
 * @author anms
 *
 */
public class Unit implements Serializable, Cloneable {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 7528193867130961390L;
	private static final long serialVersionUID = 7528193867130961391L;
	private String mBuType;
	private String mBuCode;
	private String mSiteName;
	private String mCountryCode;
	private String mTimeZone;
	private String mCompanyCode;
	private String mCompanyName;
	

	/**
	 * Creates an empty Unit
	 */
	public Unit() {
	}

	public Unit(IpayBusinessUnits ipayBusinessUnits){
		this.mBuType=ipayBusinessUnits.getId().getBuType();
		this.mBuCode=ipayBusinessUnits.getId().getBuCode();
		this.mSiteName=ipayBusinessUnits.getBuName();
		this.mCountryCode = ipayBusinessUnits.getCountryCode();
		this.mTimeZone=ipayBusinessUnits.getTimeZone();
		this.mCompanyCode=ipayBusinessUnits.getCompanyCode();
		this.mCompanyName=ipayBusinessUnits.getCompanyName();		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	public Object clone() {
		Unit vNew = new Unit();
		vNew.mBuCode = this.mBuCode;
		vNew.mBuType = this.mBuType;
		vNew.mCountryCode = this.mCountryCode;
		vNew.mSiteName = this.mSiteName;
		vNew.mTimeZone = this.mTimeZone;

		return vNew;
	}

	/**
	 * @return
	 */
	public String getBuCode() {
		return mBuCode;
	}

	/**
	 * @return
	 */
	public String getBuType() {
		return mBuType;
	}

	/**
	 * @return
	 */
	public String getCountryCode() {
		return mCountryCode;
	}

	/**
	 * @return
	 */
	public String getSiteName() {
		return mSiteName;
	}

	/**
	 * @return
	 */
	public String getTimeZone() {
		return mTimeZone;
	}

	/**
	 * @param string
	 */
	public void setBuCode(String string) {
		mBuCode = string;
	}

	/**
	 * @param string
	 */
	public void setBuType(String string) {
		mBuType = string;
	}

	/**
	 * @param string
	 */
	public void setCountryCode(String string) {
		mCountryCode = string;
	}

	/**
	 * @param string
	 */
	public void setSiteName(String string) {
		mSiteName = string;
	}

	/**
	 * @param string
	 */
	public void setTimeZone(String string) {
		mTimeZone = string;
	}


	public String getCompanyCode() {
		return mCompanyCode;
	}


	public void setCompanyCode(String companyCode) {
		mCompanyCode = companyCode;
	}


	public String getCompanyName() {
		return mCompanyName;
	}


	public void setCompanyName(String companyName) {
		mCompanyName = companyName;
	}

}
