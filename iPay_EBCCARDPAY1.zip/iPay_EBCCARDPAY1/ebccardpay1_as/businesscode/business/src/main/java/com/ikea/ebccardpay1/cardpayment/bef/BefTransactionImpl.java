/*
 * Created on 2006-june-16
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.be.ReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefTransactionImpl extends BefAbstract<Transaction> implements BefTransaction {

	private final static Logger mLogger_findByReference =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByReference");

	private final static Logger mLogger_findByOriginator =
			LoggerFactory.getLogger(
					BefTransactionImpl.class.getName() + ".findByOriginator");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefTransactionImpl(
			SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefTransaction#findByTransactionNo(long)
	 */
	public List<Transaction> findByTransactionNo(long pTransactionNo) {

		Session vSession = mSessionFactory.getCurrentSession();

		return new GenericQuery<Transaction>(vSession
				.createQuery(
						"from Transaction" + " where transactionNo=:transactionNo")
				.setLong("transactionNo", pTransactionNo))
				.list();
	}
	public Transaction findByTransactionNumber(long pTransactionNo) {

		Session vSession = mSessionFactory.getCurrentSession();

		
		Transaction vTransaction = (Transaction) vSession
				.createQuery("from Transaction where transactionNo=:transactionNo")
				.setParameter("transactionNo", pTransactionNo)
				.uniqueResult();
		
		if (vTransaction == null) {
			mLogger_findByOriginator.debug("No record found.");
		}
		
		return vTransaction;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefTransaction#findByReference(java.lang.String, java.lang.String)
	 */
	public List<Transaction> findByReference(String pReference, String pSourceSystem) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
				"from Transaction t where "
						+ "t.transactionNo in ( select r.transactionNo from ReferenceCheck r where "
						+ "r.reference = :reference and r.sourceSystem=:sourceSystem )";

		if (mLogger_findByReference.isDebugEnabled()) {
			mLogger_findByReference.debug("HQL: " + vHql);
		}

		return 
				new GenericQuery<Transaction>(vSession
						.createQuery(vHql)
						.setParameter("reference", pReference)
						.setParameter("sourceSystem", pSourceSystem))
				.list();

	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefTransaction#findByOriginator(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.ikea.ebccardpay1.cardpayment.be.Card)
	 */
	public List<Transaction> findByOriginator(
			String pBuType,
			String pBuCode,
			String pSourceSystem,
			String pPointOfSale,
			String pSalesDay,
			String pReceipt,
			Card pCard) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vReceiptHql = "";
		if (pReceipt != null) {
			vReceiptHql = " and r.receipt = :receipt";
		}

		String vHql =
				"from Transaction t where "
						+ "t.transactionNo in ( select r.transactionNo from ReferenceCheck r where "
						+ "r.buCode=:buCode and r.pointOfSale=:pointOfSale and waitingAck=:waitingAck and "
						+ "r.sourceSystem=:sourceSystem and r.buType=:buType and  t.card=:card"
						+ vReceiptHql
						+ " ) and t.salesDay = :salesDay";

		if (mLogger_findByOriginator.isDebugEnabled()) {
			mLogger_findByOriginator.debug("HQL: " + vHql);
		}

		GenericQuery<Transaction> vQuery =
				new GenericQuery<Transaction>(vSession
						.createQuery(vHql)
						.setParameter("buType", pBuType)
						.setParameter("buCode", pBuCode)
						.setParameter("sourceSystem", pSourceSystem)
						.setParameter("pointOfSale", pPointOfSale)
						.setParameter("salesDay", pSalesDay)
						.setBoolean("waitingAck", false)
						.setEntity("card", pCard));

		if (pReceipt != null) {
			vQuery.setParameter("receipt", pReceipt);
		}

		return vQuery.list();

	}

	@Override
	protected Class<Transaction> getBusinessEntityClass() {
		return Transaction.class;
	}

	//@Override
	public void deleteLoadCampaignTransaction(Campaign pCampaign) throws Exception {

		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "delete from Transaction where campaign=:campaign";
		vSession
		.createQuery(vHql)
		.setEntity("campaign", pCampaign)
		.executeUpdate();
		vSession.flush();
	}
	//@Override
	public void deleteByMassload(MassLoad pMassLoad) throws Exception {
		// TODO Auto-generated method stub
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "delete from Transaction where massLoad=:massload";
		vSession
		.createQuery(vHql)
		.setEntity("massload", pMassLoad)
		.executeUpdate();
		vSession.flush();
	}
	
	public List<Transaction> findByReciept(String pReciept,String pBuType, String pBuCode,String psalesDay) {

		Session vSession = mSessionFactory.getCurrentSession();

		StringBuffer vHqlTemp= new StringBuffer("from Transaction where receipt=:receipt and buType=:buType and buCode=:buCode");
		
		if(psalesDay!=null)
		{
			vHqlTemp.append(" and salesDay=:salesDay");

			String vHql=vHqlTemp.toString();

			if (mLogger_findByReference.isDebugEnabled()) {
				mLogger_findByReference.debug("HQL: " + vHql);
			}

			return 
					new GenericQuery<Transaction>(vSession
							.createQuery(vHql)
							.setParameter("receipt", pReciept)
							.setParameter("buType", pBuType)
							.setParameter("buCode", pBuCode)
							.setParameter("salesDay", psalesDay)
							)
					.list();

		}
		
		else{
			String vHql=vHqlTemp.toString();

			if (mLogger_findByReference.isDebugEnabled()) {
				mLogger_findByReference.debug("HQL: " + vHql);
			}

			return 
					new GenericQuery<Transaction>(vSession
							.createQuery(vHql)
							.setParameter("receipt", pReciept)
							.setParameter("buType", pBuType)
							.setParameter("buCode", pBuCode)
							)
					.list();
		}
	}

}
