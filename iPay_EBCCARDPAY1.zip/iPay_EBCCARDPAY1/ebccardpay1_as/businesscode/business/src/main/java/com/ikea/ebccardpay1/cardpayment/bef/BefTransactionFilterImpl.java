/*
 * Created on 2007-feb-05
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.TransactionFilter;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 */
public class BefTransactionFilterImpl extends BefAbstract<TransactionFilter> implements BefTransactionFilter {

	private final static Logger mCategory_findByTransactionNo =
		LoggerFactory.getLogger(
			BefTransactionFilterImpl.class.getName() + ".findByTransactionNo");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefTransactionFilterImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefTransactionFilter#findByTransactionNo(long)
	 */
	public TransactionFilter findByTransactionNo(long pTransactionNo) {
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql =
			"from TransactionFilter where transactionNo=:transactionNo";

		if (mCategory_findByTransactionNo.isDebugEnabled()) {
			mCategory_findByTransactionNo.debug("HQL: " + vHql);
		}

		return new GenericQuery<TransactionFilter>(vSession
			.createQuery(vHql)
			.setLong("transactionNo", pTransactionNo))
			.uniqueResult();
	}

	@Override
	protected Class<TransactionFilter> getBusinessEntityClass() {
		return TransactionFilter.class;
	}
}
