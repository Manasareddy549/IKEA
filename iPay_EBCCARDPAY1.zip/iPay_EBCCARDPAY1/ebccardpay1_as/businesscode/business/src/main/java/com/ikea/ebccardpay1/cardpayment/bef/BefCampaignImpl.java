/*
 * Created on 2006-maj-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;

/**
 * @author anms
 * @author tpon
 */
public class BefCampaignImpl extends BefAbstract<Campaign> implements
		BefCampaign {

	private final static Logger mCategory_findByCurrent = LoggerFactory
			.getLogger(BefCampaignImpl.class.getName() + ".findByCurrent");

	private final static Logger mCategory_findByUnprocessed = LoggerFactory
			.getLogger(BefCampaignImpl.class.getName() + ".findByUnprocessed");

	private final static Logger mCategory_findBySearch = LoggerFactory
			.getLogger(BefCampaignImpl.class.getName() + ".findBySearch");

	private final static Logger mCategory_connectRange = LoggerFactory
			.getLogger(BefCampaignImpl.class.getName() + ".connectRange");

	private final static Logger mCategory_disconnectRange = LoggerFactory
			.getLogger(BefCampaignImpl.class.getName() + ".disconnectRange");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCampaignImpl(SessionFactory pSessionFactory,
			TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#findByCurrent(java.lang
	 * .String, java.util.Date)
	 */
	public List<Campaign> findByCurrent(String pCountryCode,
			Date pTodaysSalesDay) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Campaign> vCriteria = new GenericCriteria<Campaign>(
				vSession.createCriteria(Campaign.class));
		vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		vCriteria
				.add(Restrictions
						.or(
								Restrictions.isNull("withdrawnDateTime"),
								Restrictions
										.sqlRestriction("{alias}.withdrawn_date_time > (sysdate - 15)")));

		vCriteria.add(Restrictions.or(Restrictions.ge("intervalEndDate",
				pTodaysSalesDay), Restrictions.isNull("authorizedDateTime")));

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByCurrent.isDebugEnabled()) {
			mCategory_findByCurrent.debug("Criteria: " + vCriteria.toString());
		}

		List<Campaign> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByCurrent.info("No campaigns found.");
		} else {
			mCategory_findByCurrent.info("Found " + vList.size()
					+ " campaigns.");
		}
		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#findByUnprocessed()
	 */
	public List<Campaign> findByUnprocessed() {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Campaign> vCriteria = new GenericCriteria<Campaign>(
				vSession.createCriteria(Campaign.class, "alias"));
		vCriteria.add(Restrictions.eq("campaignState",
				Constants.CAMPAIGN_STATE_CONSTANT_PROCESSING));

		// Just take the ones that have not been updated for 60 minutes
		vCriteria
				.add(Restrictions
						.sqlRestriction("{alias}.UPDATED_DATE_TIME < sysdate-(60/(24*60))"));

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findByUnprocessed.isDebugEnabled()) {
			mCategory_findByUnprocessed.debug("Criteria: "
					+ vCriteria.toString());
		}

		List<Campaign> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findByUnprocessed.info("No campaigns found.");
		} else {
			mCategory_findByUnprocessed.info("Found " + vList.size()
					+ " campaigns.");
		}
		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#findBySearch(java.lang
	 * .String, java.lang.String, java.lang.String, java.lang.String,
	 * java.util.Date, java.util.Date)
	 */
	public List<Campaign> findBySearch(String pBuType, String pBuCode,
			String pCountryCode, String pNameLike, Date pIntervalOnFromDate,
			Date pIntervalOnUntilDate) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Campaign> vCriteria = new GenericCriteria<Campaign>(
				vSession.createCriteria(Campaign.class));

		boolean vBuType = pBuType != null && pBuType.length() > 0;
		boolean vBuCode = pBuCode != null && pBuCode.length() > 0;

		if (vBuType && vBuCode) {
			vCriteria.createCriteria("campaignLimitations").add(
					Restrictions.eq("buType", pBuType)).add(
					Restrictions.eq("buCode", pBuCode));
		} else if (vBuType) {
			vCriteria.createCriteria("campaignLimitations").add(
					Restrictions.eq("buType", pBuType));
		} else if (vBuCode) {
			vCriteria.createCriteria("campaignLimitations").add(
					Restrictions.eq("buCode", pBuCode));
		}

		if (pCountryCode != null && pCountryCode.length() > 0) {
			vCriteria.add(Restrictions.eq("countryCode", pCountryCode));
		}
		if (pNameLike != null && pNameLike.length() > 0) {
			vCriteria.add(Restrictions.like("name", "%" + pNameLike + "%"));
		}

		if (pIntervalOnFromDate != null && pIntervalOnUntilDate != null) {
			vCriteria.add(Restrictions.ge("intervalEndDate",
					pIntervalOnFromDate));
			vCriteria.add(Restrictions.le("intervalStartDate",
					pIntervalOnUntilDate));
		}

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		if (mCategory_findBySearch.isDebugEnabled()) {
			mCategory_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<Campaign> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findBySearch.info("No campaigns found.");
		} else {
			mCategory_findBySearch
					.info("Found " + vList.size() + " campaigns.");
		}
		return vList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#connectRange(long,
	 * long)
	 */
	public int connectRange(long pCampaignId, long pRangeId) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vSql = "insert into CAMPAIGN_RANGE_T (CAMPAIGN_ID, RANGE_ID) values (:campaignId, :rangeId)  ";

		if (mCategory_connectRange.isDebugEnabled()) {
			mCategory_connectRange.debug("SQL: " + vSql);
			mCategory_connectRange.debug("Params CAMPAIGN_ID: " + pCampaignId
					+ " RANGE_ID:" + pRangeId);
		}

		int vEntries = vSession.createSQLQuery(vSql).setLong("campaignId",
				pCampaignId).setLong("rangeId", pRangeId).executeUpdate();
		vSession.flush();

		if (mCategory_connectRange.isInfoEnabled()) {
			mCategory_connectRange.info("Inserted " + vEntries
					+ " entries into CAMPAIGN_RANGE_T.");
		}
		return vEntries;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ikea.ebccardpay1.cardpayment.bef.BefCampaign#disconnectRange(long,
	 * long)
	 */
	public int disconnectRange(long pCampaignId, long pRangeId) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vSql = "delete from CAMPAIGN_RANGE_T where CAMPAIGN_ID = :campaignId and RANGE_ID = :rangeId  ";

		if (mCategory_disconnectRange.isDebugEnabled()) {
			mCategory_disconnectRange.debug("SQL: " + vSql);
			mCategory_disconnectRange.debug("Params CAMPAIGN_ID: "
					+ pCampaignId + " RANGE_ID:" + pRangeId);
		}

		int vDeletedEntries = vSession.createSQLQuery(vSql).setLong(
				"campaignId", pCampaignId).setLong("rangeId", pRangeId)
				.executeUpdate();
		vSession.flush();

		if (mCategory_disconnectRange.isInfoEnabled()) {
			mCategory_disconnectRange.info("Deleted " + vDeletedEntries
					+ " entries from CAMPAIGN_RANGE_T.");
		}
		return vDeletedEntries;
	}

	@Override
	protected Class<Campaign> getBusinessEntityClass() {
		return Campaign.class;
	}

	public List<Campaign> findExpiredCampaigns(Date pExpireDateFrom,Date pExpireDateUpto) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<Campaign> vCriteria = new GenericCriteria<Campaign>(
				vSession.createCriteria(Campaign.class));

		vCriteria.add(Restrictions.ge("intervalEndDate",
				pExpireDateFrom));

		vCriteria.add(Restrictions.lt("intervalEndDate",
				pExpireDateUpto));
		vCriteria.add(Restrictions.ne("campaignState",Constants.CAMPAIGN_STATE_CONSTANT_EXPIRED));

		// To get just one per campaign
		vCriteria.setMaxResults(100);
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		

		if (mCategory_findBySearch.isDebugEnabled()) {
			mCategory_findBySearch.debug("Criteria: " + vCriteria.toString());
		}

		List<Campaign> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mCategory_findBySearch.info("No campaigns found.");
		} else {
			mCategory_findBySearch
			.info("Found " + vList.size() + " campaigns.");
		}
		return vList;
	}
	
	//@Override
		 public List<Transaction> getCampaignLoadTransactions(Campaign pCampaign) throws Exception {
			Session vSession = mSessionFactory.getCurrentSession();
			GenericCriteria<Transaction> vCriteria = new GenericCriteria<Transaction>(vSession.createCriteria(Transaction.class));
			vCriteria.add(Restrictions.eq("campaign", pCampaign));
			return vCriteria.list();
		}


}
