package com.ikea.ebccardpay1.cardpayment.bef;

import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefBsLog extends Bef<BsLog> {
	
	//void writelog(String bsName, String bsInputs, String user);

}
