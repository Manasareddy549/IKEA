/*
 * Created on 2007-aug-08
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author dalq
 * @author tpon
 *
 */
public class BefExchangeRateImpl extends BefAbstract<ExchangeRate> implements BefExchangeRate {

	private final static Logger mCategory_findBySearch =
		LoggerFactory.getLogger(
			BefExchangeRateImpl.class.getName() + ".findBySearch");

	private final static Logger mCategory_findCurrentExchangeRates =
		LoggerFactory.getLogger(
			BefExchangeRateImpl.class.getName() + ".findCurrentExchangeRates");

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefExchangeRateImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);

	}

	public ExchangeRate findBySearch(
		String pFromCurrency,
		String pToCurrency,
		Date pLocalDate,
		long pCountryId) {

		Session vSession = mSessionFactory.getCurrentSession();

		mCategory_findBySearch.info(
			"findBySearch input fromCurrency: "
				+ pFromCurrency
				+ " toCurrency: "
				+ pToCurrency
				+ " localDate:"
				+ pLocalDate
				+ "countryId:"
				+ pCountryId);

		String vHql =
			"from ExchangeRate where fromDate = "
				+ "(select max(fromDate) "
				+ "from ExchangeRate where fromDate <= :fromDate "
				+ "and country.countryId = :countryId "
				+ "and fromCurrencyCode = :fromCurrencyCode "
				+ "and toCurrencyCode = :toCurrencyCode) "
				+ "and country.countryId = :countryId "
				+ "and fromCurrencyCode = :fromCurrencyCode "
				+ "and toCurrencyCode = :toCurrencyCode ";

		ExchangeRate vExchangeRate =
			new GenericQuery<ExchangeRate>(vSession
				.createQuery(vHql)
				.setDate("fromDate", pLocalDate)
				.setLong("countryId", pCountryId)
				.setString("fromCurrencyCode", pFromCurrency)
				.setString("toCurrencyCode", pToCurrency)
				.setLong("countryId", pCountryId)
				.setString("fromCurrencyCode", pFromCurrency)
				.setString("toCurrencyCode", pToCurrency))
				.uniqueResult();

		if (vExchangeRate == null) {
			mCategory_findBySearch.info(
				"No Exchange rate found for this countryId " + pCountryId);

		} else {
			mCategory_findBySearch.info(
				"Exchange rate found for this countryId "
					+ pCountryId
					+ " Exchange rate:"
					+ vExchangeRate.getExchangeRate());
		}

		return vExchangeRate;
	}

	public List<ExchangeRate> findCurrent(long pCountryId) {

		Session vSession = mSessionFactory.getCurrentSession();

		String vSql =
			"select ert.* from EXCHANGE_RATE_T ert, (select max(from_date) as from_date, "
				+ "t1.from_currency_code, t1.to_currency_code from EXCHANGE_RATE_T t1 "
				+ "where t1.from_date <= sysdate and t1.country_id = :countryId "
				+ "group by t1.from_currency_code, t1.to_currency_code "
				+ "union select t2.from_date, t2.from_currency_code, t2.to_currency_code from EXCHANGE_RATE_T t2 "
				+ "where t2.from_date > sysdate - 30 and t2.country_id = :countryId ) t "
				+ "where ert.from_date = t.from_date and ert.from_currency_code = t.from_currency_code "
				+ "and ert.to_currency_code = t.to_currency_code "
				+ "and ert.country_id = :countryId ";

		List<ExchangeRate> vList =
			new GenericQuery<ExchangeRate>(vSession
				.createSQLQuery(vSql)
				.addEntity(ExchangeRate.class)
				.setLong("countryId", pCountryId)
				.setLong("countryId", pCountryId)
				.setLong("countryId", pCountryId))
				.list();

		if (vList == null) {
			mCategory_findCurrentExchangeRates.info(
				"No Exchange rate found for this countryId " + pCountryId);

		} else {
			mCategory_findCurrentExchangeRates.info(
				"Current ExchangeRates found for this countryId " + pCountryId);
		}

		return vList;

	}

	@Override
	protected Class<ExchangeRate> getBusinessEntityClass() {
		return ExchangeRate.class;
	}

}
