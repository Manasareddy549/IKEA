package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.AmountException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebcframework.exception.IkeaException;

public interface BecReferenceChecks {

	/**
	 * @return Number of deleted entries.
	 */
	public int deleteOld() throws IkeaException;

	/**
	 * Will cancel all unacknowledged transactions (on all cards) that are older than one hour.
	 */
	public int cancelOldUnacknowledged()
		throws ValueMissingException, AmountException;

}
