package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anagc
 */
public class PosDateException extends CardPayException {

	private static final long serialVersionUID = -8531407424370864248L;

	public PosDateException() {
		super();
	}
	public PosDateException(String pMessage) {
		super(pMessage);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidPosDate();
	}
}
