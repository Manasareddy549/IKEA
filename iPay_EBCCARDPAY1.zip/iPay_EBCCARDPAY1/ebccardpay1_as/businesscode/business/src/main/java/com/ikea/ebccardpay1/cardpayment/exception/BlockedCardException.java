/*
 * Created on 2007-mar-05
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class BlockedCardException extends CardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7483021127791952238L;

	/**
	 * 
	 */
	public BlockedCardException() {
		super();
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.BlockedCard();
	}

}
