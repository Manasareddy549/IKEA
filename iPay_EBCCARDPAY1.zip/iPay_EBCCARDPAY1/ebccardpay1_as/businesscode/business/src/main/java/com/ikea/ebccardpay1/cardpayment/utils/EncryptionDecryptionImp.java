package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import com.ibm.ejs.ras.SystemOutStream;
import com.ikea.ebccardpay1.cardpayment.bec.BecCardImpl;
import com.ikea.ebcframework.services.EbcProperties;
import com.vormetric.pkcs11.wrapper.*;
import com.vormetric.pkcs11.wrapper.params.CK_GCM_PARAMS;

import static com.vormetric.pkcs11.wrapper.PKCS11Constants.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.security.*;

public class EncryptionDecryptionImp implements EncryptionDecryption{
	
	private EbcProperties mEbcProperties;
	
	public EncryptionDecryptionImp(EbcProperties pEbcProperties) {
		
		mEbcProperties = pEbcProperties;
	}
	
	private final static Logger mCategory = LoggerFactory.getLogger(EncryptionDecryptionImp.class);

	public static final String defKeyName = "iPay_VAE_PoC_v6";
    public static final byte[] iv = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
    
    String libPath = null;
    String headermode = "";//  none 
    int genAction = 0;//  generate non-versioned key 
    Vpkcs11Session session = null;
    public static final String keyValue = "this is my sample key data 54321";
    String utfMode = "UTF-8";
    int radix = 0;


    public static void usage()
    {
        System.out.println("usage: java [-cp CLASSPATH] com.vormetric.pkcs11.sample.EncryptDecryptMetaData -p pin [-k keyName] [-m module] [-g genaction] [-h headermode]");
        System.out.println("genaction: 0...generate versioned key, 1...rotate versioned key, 2...migrate non-versioned key to versioned key, 3...generate non-versioned key");
        System.out.println("headermode: v1.5, v1.5base64, v2.1, or v2.7");
        System.exit (1);
    }

	@SuppressWarnings("restriction")
	@Override
	public synchronized String encrypt(String inputData) {
		
		String pin = mEbcProperties.getString("VaePin", "Ikeadt@123");
		String keyName = mEbcProperties.getString("VaeKeyName", "iPay_VAE_PoC_v6");
		int lifespan = mEbcProperties.getInt("VaeKeyLifeSpan", 365);
		String encryptedTextStr=null;
        if (pin==null)     usage();
        if (keyName==null) usage();
        byte[] outText = { };
        ByteArrayOutputStream fpeIVBytes;
        DataOutputStream dos;
        byte[] charSet;
        charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".getBytes();
        byte[] tweak = {0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
        radix = charSet.length;
        
		try
	    {
			fpeIVBytes = new ByteArrayOutputStream(9 + charSet.length);
        	dos = new DataOutputStream(fpeIVBytes);
            dos.write(tweak, 0, 8);
            dos.write((charSet.length) & 0xFF);
            dos.write(charSet, 0, charSet.length);
            dos.flush();
            
            CK_MECHANISM encMechFpe = new CK_MECHANISM(0x80004001L, fpeIVBytes.toByteArray());
			

			if(keyName == null)
				keyName = defKeyName;
			
			mCategory.info("Start EncryptDecryptMetaData ...");
            session = Helper.startUp(Helper.getPKCS11LibPath(libPath), pin);
            
            long keyID = Helper.findKey(session,keyName.trim()) ;

            if (keyID == 0)
            {
            	mCategory.info("the key is not found, creating it...");
                keyID = Helper.createKey(session, keyName, genAction, lifespan);
                mCategory.info("Key successfully Created. Key Handle: "+ keyID);
            }

			 //encrypt, decrypt with key 
			
			int encryptedDataLen = 0;
			byte[] inputDataBytes = inputData.getBytes();

			//This is for user passed in logging data; format can be any string. 
			String metadata = "META: This is test meta data: Encryption: ";
			
			session.p11.C_EncryptInit(session.sessionHandle, encMechFpe, keyID);
			mCategory.info("C_EncryptInit succeed");

			mCategory.info("InputData length = " + inputData.length() + " InputData byte length: " + inputData.getBytes().length );

			outText = metadata.getBytes();
			encryptedDataLen = session.p11.C_Encrypt (session.sessionHandle, inputDataBytes, 0, inputData.length(), outText, 0, 0);
			mCategory.info("C_Encrypt success. encrypted data len = " + encryptedDataLen);
			
			outText = new byte[encryptedDataLen];
			encryptedDataLen = session.p11.C_Encrypt (session.sessionHandle, inputDataBytes, 0, inputData.length(), outText, 0, outText.length);
			mCategory.info("C_Encrypt 2nd call success. encrypted data len = " + encryptedDataLen);
		
			
			encryptedTextStr = new String (outText, 0, encryptedDataLen);
			mCategory.info("Encrypted Text length =  " + encryptedTextStr.length());
			
	    }
		catch (PKCS11Exception e)
	    {
			e.printStackTrace();
	    }
		catch (Exception e)
	    {
            e.printStackTrace();
	    }
	    finally {
            Helper.closeDown(session);
	    }
		return encryptedTextStr;
	}
	
	@SuppressWarnings("restriction")
	@Override
	public synchronized String decrypt(String encryptedData) {
		
		String pin = mEbcProperties.getString("VaePin", "Ikeadt@123");
		String keyName = mEbcProperties.getString("VaeKeyName", "iPay_VAE_PoC_v6");
		int lifespan = mEbcProperties.getInt("VaeKeyLifeSpan", 365);
		String decryptedTextStr=null;
		if (pin==null)     usage();
        if (keyName==null) usage();
        ByteArrayOutputStream fpeIVBytes;
        DataOutputStream dos;
        byte[] charSet;
        charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".getBytes();
        byte[] tweak = {0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
        radix = charSet.length;
        
		try
	    {
			fpeIVBytes = new ByteArrayOutputStream(9 + charSet.length);
        	dos = new DataOutputStream(fpeIVBytes);
            dos.write(tweak, 0, 8);
            dos.write((charSet.length) & 0xFF);
            dos.write(charSet, 0, charSet.length);
            dos.flush();
            
            CK_MECHANISM decMechFpe = new CK_MECHANISM(0x80004001L, fpeIVBytes.toByteArray());
			
			if(keyName == null)
				keyName = defKeyName;

			mCategory.info("Start DecryptMetaData ..." );
            session = Helper.startUp(Helper.getPKCS11LibPath(libPath), pin);

            long keyID = Helper.findKey(session, keyName) ;

            if (keyID == 0)
            {
            	mCategory.info ("the key is not found, creating it..." );
                keyID = Helper.createKey(session, keyName, genAction, lifespan);
                mCategory.info("Key successfully Created. Key Handle: " + keyID);
            }

			//encrypt, decrypt with key 
			byte[] decryptedText = { };
			int decryptedDataLen = 0;
			int encryptedDataLen = encryptedData.length();
			byte[] encryptedDataBytes = encryptedData.getBytes();

			session.p11.C_DecryptInit (session.sessionHandle, decMechFpe, keyID);
			mCategory.info("C_DecryptInit success");
			
			mCategory.info("input data length " +encryptedDataLen+ " inputs byte length " +encryptedDataBytes.length);

			//This is for user passed in logging data; format can be any string, recommend using JSON 
			String metadata = "META: This is test meta data: Decryption: ";
			decryptedText = metadata.getBytes();
			decryptedDataLen = session.p11.C_Decrypt (session.sessionHandle, encryptedDataBytes, 0, encryptedDataLen, decryptedText, 0, 0);
			mCategory.info("C_Decrypt 1st call success. Decrypted data length = " + decryptedDataLen);
			
			decryptedText = new byte [decryptedDataLen];
			decryptedDataLen = session.p11.C_Decrypt (session.sessionHandle, encryptedDataBytes, 0, encryptedDataLen, decryptedText, 0, decryptedText.length);
			mCategory.info("C_Decrypt 2nd call success. Decrypted data length = " + decryptedDataLen);
			
			decryptedTextStr = new String (decryptedText, 0, decryptedDataLen);
			mCategory.info("C_Decrypt succeed.");
			mCategory.info("Decrypted Text length = " + decryptedText.length + " decrypted string length = " + decryptedTextStr.length());
			mCategory.info("C_Decrypt succeed."+ decryptedTextStr);
			
	    }
		catch (PKCS11Exception e)
	    {
			e.printStackTrace();
	    }
		catch (Exception e)
	    {
            e.printStackTrace();
	    }
	    finally {
			
            Helper.closeDown(session);
	    }
		
		return decryptedTextStr;
	}
	
	public CK_MECHANISM getMechanism() {
		
		ByteArrayOutputStream fpeIVBytes;
        DataOutputStream dos;
        byte[] charSet;
        charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".getBytes();
        byte[] tweak = {0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
        radix = charSet.length;
        CK_MECHANISM  MechFpe = null;
        try{
        	fpeIVBytes = new ByteArrayOutputStream(9 + charSet.length);
        	dos = new DataOutputStream(fpeIVBytes);
            dos.write(tweak, 0, 8);
            dos.write((charSet.length) & 0xFF);
            dos.write(charSet, 0, charSet.length);
            dos.flush();
            
            MechFpe = new CK_MECHANISM(0x80004001L, fpeIVBytes.toByteArray());
        }
		catch (Exception e)
	    {
            e.printStackTrace();
	    }
        
        return MechFpe;
        
	}

}
