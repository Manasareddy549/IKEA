package com.ikea.ebccardpay1.cardpayment.be;

import com.ikea.mdsd.BusinessEntity;

public class JobCreatorSchedule extends BusinessEntity {
	/**
	 * Storage: JOB_CREATOR_SCHEDULE_T
	 */

	/**
	 * Primary key
	 */
	private long mJobCreatorScheduleId;

	/**
	 * Common attributes
	 */
	private int mVersionNo;
	private String mCreatedBy;
	private java.util.Date mCreatedDateTime;
	private String mUpdatedBy;
	private java.util.Date mUpdatedDateTime;

	/**
	 * Data
	 */
	private String mJobName;
	private String mCronTab;

	public long getJobCreatorScheduleId() {
		return mJobCreatorScheduleId;
	}

	public void setJobCreatorScheduleId(long pJobCreatorScheduleId) {
		mJobCreatorScheduleId = pJobCreatorScheduleId;
	}

	public int getVersionNo() {
		return mVersionNo;
	}

	public void setVersionNo(int pVersionNo) {
		mVersionNo = pVersionNo;
	}

	public String getCreatedBy() {
		return mCreatedBy;
	}

	public void setCreatedBy(String pCreatedBy) {
		mCreatedBy = pCreatedBy;
	}

	public java.util.Date getCreatedDateTime() {
		return mCreatedDateTime;
	}

	public void setCreatedDateTime(java.util.Date pCreatedDateTime) {
		mCreatedDateTime = pCreatedDateTime;
	}

	public String getUpdatedBy() {
		return mUpdatedBy;
	}

	public void setUpdatedBy(String pUpdatedBy) {
		mUpdatedBy = pUpdatedBy;
	}

	public java.util.Date getUpdatedDateTime() {
		return mUpdatedDateTime;
	}

	public void setUpdatedDateTime(java.util.Date pUpdatedDateTime) {
		mUpdatedDateTime = pUpdatedDateTime;
	}

	public String getJobName() {
		return mJobName;
	}

	public void setJobName(String pJobName) {
		mJobName = pJobName;
	}

	public String getCronTab() {
		return mCronTab;
	}

	public void setCronTab(String pCronTab) {
		mCronTab = pCronTab;
	}
}
