package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

public class ReverseAmountCheckException extends CardPayException {
	
	/**
	 * 
	 */
	public ReverseAmountCheckException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public ReverseAmountCheckException(String pMessage) {
		super(pMessage);
	}

	/**
	 * 
	 */
	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.InvalidAuthorizationAmount();
	}

}
