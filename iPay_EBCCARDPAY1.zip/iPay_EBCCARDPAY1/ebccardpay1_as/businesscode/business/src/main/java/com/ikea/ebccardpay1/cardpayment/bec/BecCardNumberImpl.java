/*
 * Created on 2006-maj-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.exception.CardNumberNotFoundException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardCheckDigitException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardIssuerException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardTypeDigitException;
import com.ikea.ebccardpay1.cardpayment.utils.CardPaymentLogger;
import com.ikea.ebccardpay1.cardpayment.utils.CheckDigits;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import static org.apache.commons.lang.Validate.notNull;

/**
 * @author anms
 *
 */
public class BecCardNumberImpl implements BecCardNumber {

	private final static Logger mCategory =
		LoggerFactory.getLogger(BecCardNumberImpl.class.getName());

	private final static String CARD_ISSUER_IKEA = "627598";

	private final static int ISSUER_LEN = 6;
	private final static int TYPE_DIDGIT_LEN = 1;
	private final static int ACCOUNT_NUMBER_LEN = 11;
	private final static int CHECK_DIGIT_LEN = 1;
	private final static int CARD_NUMBER_LEN =
		ISSUER_LEN + TYPE_DIDGIT_LEN + ACCOUNT_NUMBER_LEN + CHECK_DIGIT_LEN;
	private final static String CARD_NUMBER_REGEXP =
		"^[0-9]{" + CARD_NUMBER_LEN + "}$";

	private CardNumber mCardNumber = null;

	// Dependencies injected at creation
	private BefCardNumber mBefCardNumber = null;
	private Constants mConstants = null;
	private EncryptionDecryption mEncryptionDecryption=null;

	protected BecCardNumberImpl(
		BefCardNumber pBefCardNumber,
		Constants pConstants,EncryptionDecryption pEncryptionDecryption) {
		// Hold on to the dependencies
		mBefCardNumber = pBefCardNumber;
		mConstants = pConstants;
		mEncryptionDecryption = pEncryptionDecryption;
	}
	
	void validate() {
		notNull(mBefCardNumber);
		notNull(mConstants);
		notNull(mEncryptionDecryption);
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#init(long)
	 */
	public BecCardNumber init(long pCardNumbeId) {
		mCardNumber = mBefCardNumber.findByPrimaryKey(pCardNumbeId);
		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#createCardNumber(String)
	 */
	//iPay4.8.1- Sprint2
	public void createCardNumber(String pCardNumberString)
		throws InvalidCardNumberException {

		mCategory.info(
			"Creating card number "
				+ CardPaymentLogger.cardNumberToString(pCardNumberString));
		mCardNumber = mBefCardNumber.create();

		VoCardNumber vVoCardNumber = splitCardNumber(pCardNumberString);

		mCardNumber.setIssuer(vVoCardNumber.getIssuer());
		mCardNumber.setCardTypeDigit(vVoCardNumber.getCardTypeDigit());
		mCardNumber.setAccountNumberEnc(mEncryptionDecryption.encrypt(vVoCardNumber.getAccountNumber()));
		//mCardNumber.setAccountNumber(vVoCardNumber.getAccountNumber());
		mCardNumber.setCheckDigit(vVoCardNumber.getCheckDigit());
		mCardNumber.setIssuerCountryCode(vVoCardNumber.getAccountNumber().substring(0, 2));
		
		mBefCardNumber.save(mCardNumber);
		
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#createCardNumber(java.lang.String, java.lang.String)
	 */
	//iPay4.8.1- Sprint2
	public void createCardNumber(
		String pCardNumberString,
		String pVerificationCode)
		throws InvalidCardNumberException {

		mCategory.info(
			"Creating card number with verification code "
				+ CardPaymentLogger.cardNumberToString(pCardNumberString)
				+ " verificationcode '"
				+ pVerificationCode
				+ "'");
		mCardNumber = mBefCardNumber.create();

		VoCardNumber vVoCardNumber = splitCardNumber(pCardNumberString);

		mCardNumber.setIssuer(vVoCardNumber.getIssuer());
		mCardNumber.setCardTypeDigit(vVoCardNumber.getCardTypeDigit());
		mCardNumber.setAccountNumberEnc(mEncryptionDecryption.encrypt(vVoCardNumber.getAccountNumber()));
		//mCardNumber.setAccountNumber(vVoCardNumber.getAccountNumber());
		mCardNumber.setCheckDigit(vVoCardNumber.getCheckDigit());
		mCardNumber.setVerificationCodeEnc(mEncryptionDecryption.encrypt(pVerificationCode));
		mCardNumber.setIssuerCountryCode(vVoCardNumber.getAccountNumber().substring(0, 2));
		//mCardNumber.setVerificationCode(pVerificationCode);
		

		mBefCardNumber.save(mCardNumber);

	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#createCardNumber(java.lang.String, int, long)
	 */
	public void createCardNumber(
		String pIssuer,
		int pCardTypeDigit,
		long pAccountNumber)
		throws InvalidCardNumberException {

		String vCardNumberStringWithoutCheck =
			pIssuer + pCardTypeDigit + padAccountNumber(pAccountNumber);

		createCardNumber(
			vCardNumberStringWithoutCheck
				+ CheckDigits.getValidCheckDigit(vCardNumberStringWithoutCheck));
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#findCardNumber(String)
	 */
	public void findCardNumber(String pCardNumberString)
		throws InvalidCardNumberException, CardNumberNotFoundException {

		VoCardNumber vVoCardNumber = splitCardNumber(pCardNumberString);
		mCardNumber =
			mBefCardNumber.findByCardNumber(
				vVoCardNumber.getIssuer(),
				vVoCardNumber.getCardTypeDigit(),
				//vVoCardNumber.getAccountNumber(),
				vVoCardNumber.getCheckDigit(),
				mEncryptionDecryption.encrypt(vVoCardNumber.getAccountNumber()));
		
		if (mCardNumber == null) {
			throw new CardNumberNotFoundException("Card number not found in database.");
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#composeCardNumberString(String)
	 */
	//iPay4.8.1- Sprint2
	public String composeCardNumberString(CardNumber pCardNumber) {
		
	/*	if(pCardNumber.getAccountNumberEnc()== null || pCardNumber.getAccountNumberEnc().length()==0) {

		return composeCardNumberStringInternal(
			pCardNumber.getIssuer(),
			pCardNumber.getCardTypeDigit(),
			//pCardNumber.getAccountNumber(),
			pCardNumber.getAccountNumber(),
			pCardNumber.getCheckDigit());
	}
		else {*/
			

				return composeCardNumberStringInternal(
					pCardNumber.getIssuer(),
					pCardNumber.getCardTypeDigit(),
					//pCardNumber.getAccountNumber(),
					mEncryptionDecryption.decrypt(pCardNumber.getAccountNumberEnc()),
					pCardNumber.getCheckDigit());
			}
		//}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#splitCardNumber(String)
	 */
	public VoCardNumber splitCardNumber(String pCardNumberString)
		throws InvalidCardNumberException {

		if (pCardNumberString == null
			|| pCardNumberString.length() != (CARD_NUMBER_LEN)) {
			throw new InvalidCardNumberException(
				"The total length of the card number string is not correct. Should be '"
					+ CARD_NUMBER_LEN
					+ "' for internal card numbers.");
		}
		if (!pCardNumberString.matches(CARD_NUMBER_REGEXP)) {
			throw new InvalidCardNumberException(
				"The card number string does not match the regexp '"
					+ CARD_NUMBER_REGEXP
					+ "'.");
		}
		if (!CheckDigits.isValidCheckDigit(pCardNumberString)) {
			throw new InvalidCardCheckDigitException();
		}

		VoCardNumber vVoCardNumber = new VoCardNumber();
		int vCurrentPossion = 0;

		// Issuer
		vVoCardNumber.setIssuer(
			pCardNumberString.substring(
				vCurrentPossion,
				vCurrentPossion += ISSUER_LEN));

		// Card type digit
		String vCardTypeDigitString =
			pCardNumberString.substring(
				vCurrentPossion,
				vCurrentPossion += TYPE_DIDGIT_LEN);
		vVoCardNumber.setCardTypeDigit(
			new Integer(vCardTypeDigitString).intValue());

		// Account number
		vVoCardNumber.setAccountNumber(
			pCardNumberString.substring(
				vCurrentPossion,
				vCurrentPossion += ACCOUNT_NUMBER_LEN));

		// Check digit
		String vCheckDigitString =
			pCardNumberString.substring(
				vCurrentPossion,
				vCurrentPossion += TYPE_DIDGIT_LEN);
		vVoCardNumber.setCheckDigit(new Integer(vCheckDigitString).intValue());

		// Validate issuer
		checkValidIssuer(vVoCardNumber.getIssuer());

		// Validate the card type digit
		checkCardTypeDigit(vVoCardNumber.getCardTypeDigit());

		vVoCardNumber.setCardNumberString(
			composeCardNumberStringInternal(
				vVoCardNumber.getIssuer(),
				vVoCardNumber.getCardTypeDigit(),
				vVoCardNumber.getAccountNumber(),
				vVoCardNumber.getCheckDigit()));

		return vVoCardNumber;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#getCardNumber()
	 */
	public CardNumber getCardNumber() {
		return mCardNumber;
	}

	/**
	 * @param pCardNumber
	 */
	protected void setCardNumber(CardNumber pCardNumber) {
		mCardNumber = pCardNumber;
	}

	// ---------- Internal methods, must be protected so unit tests can access them ----------

	/**
	 * 
	 */
	protected String padAccountNumber(long pAccountNumber)
		throws InvalidCardNumberException {

		String vAccountNumberString = "" + pAccountNumber;

		if (vAccountNumberString.length() > ACCOUNT_NUMBER_LEN) {
			throw new InvalidCardNumberException(
				"The account number is too big to fit into a string of '"
					+ ACCOUNT_NUMBER_LEN
					+ "' chars. Account number is '"
					+ pAccountNumber
					+ "'.");
		}
		for (int i = vAccountNumberString.length();
			i < ACCOUNT_NUMBER_LEN;
			i++) {
			vAccountNumberString = "0" + vAccountNumberString;
		}

		return vAccountNumberString;
	}

	/**
	 * @param pIssuer
	 * @param pCardTypeDigit
	 * @param pAccountNumber
	 * @param pCheckDigit
	 * @return
	 */
	public String composeCardNumberStringInternal(
		String pIssuer,
		int pCardTypeDigit,
		String pAccountNumber,
		int pCheckDigit) {

		String vCardNumberString =
			pIssuer + pCardTypeDigit + pAccountNumber + pCheckDigit;

		return vCardNumberString;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#checkValidIssuer(java.lang.String)
	 */
	public void checkValidIssuer(String pIssuer)
		throws InvalidCardIssuerException {

		// Today we just have one valid issuer
		if (!CARD_ISSUER_IKEA.equals(pIssuer)) {
			throw new InvalidCardIssuerException(
				"Issuer '" + pIssuer + "' is not a valid issuer for iPay.");

		}
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber#checkCardTypeDigit(int)
	 */
	public void checkCardTypeDigit(int pCardTypeDigit)
		throws InvalidCardTypeDigitException {

		try {
			mConstants.getCardType(pCardTypeDigit);
		} catch (CardTypeDigitNotFoundException e) {
			throw new InvalidCardTypeDigitException(
				"Card type digit '" + pCardTypeDigit + "' is not valid.");
		}
	}

}
