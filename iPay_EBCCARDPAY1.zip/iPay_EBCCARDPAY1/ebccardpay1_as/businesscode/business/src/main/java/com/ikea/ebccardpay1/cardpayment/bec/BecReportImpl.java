package com.ikea.ebccardpay1.cardpayment.bec;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;


import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.ikea.ebccardpay1.cardpayment.be.BsLog;
import com.ikea.ebccardpay1.cardpayment.be.Parameter;
import com.ikea.ebccardpay1.cardpayment.be.Report;
import com.ikea.ebccardpay1.cardpayment.bef.BefBsLog;
import com.ikea.ebccardpay1.cardpayment.bef.BefReport;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromToDateException;
import com.ikea.ebccardpay1.cardpayment.exception.ReportException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.ReportParameter;
import com.ikea.ebccardpay1.cardpayment.utils.Restrictions;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import com.ikea.ebccardpay1.cardpayment.vo.VoParameter;
import com.ikea.ebccardpay1.cardpayment.vo.VoReport;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportKPI;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportResults;
import com.ikea.ebccardpay1.cardpayment.vo.VoReportTransaction;
import com.ikea.mdsd.CodeGeneration;
import com.ikea.mdsd.ValueObjects;

//import jcifs.smb.NtlmPasswordAuthentication;
//import jcifs.smb.SmbException;
//import jcifs.smb.SmbFileOutputStream;
import ch.swaechter.smbjwrapper.SmbConnection;
import ch.swaechter.smbjwrapper.SmbDirectory;
import ch.swaechter.smbjwrapper.SmbFile;
import ch.swaechter.smbjwrapper.SmbItem;
//import jcifs.smb.SmbFileOutputStream;
import ch.swaechter.smbjwrapper.streams.SmbOutputStream;

import static org.apache.commons.lang.Validate.notNull;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import com.ikea.ebcframework.services.EbcProperties;
/**
 *
 */
public class BecReportImpl implements BecReport {

	private final static Logger mCategory =
			LoggerFactory.getLogger(BecReportImpl.class);

	// Date format used to parse date parameters
	// Remove Static Reference
	private  DateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");

	// Date format used to parse month parameters
	//Remove Static Reference.
	private  DateFormat sMonthFormat = new SimpleDateFormat("yyyy-MM");

	// Dependencies injected at creation of this BEC
	private BefReport mBefReport = null;
	private EncryptionDecryption mEncryptionDecryption=null;

	// Dependencies that need to be set with init
	private UserEnvironment mUserEnvironment;

	// Entity that this BEC operates on
	private Report mReport = null;
	
	private BsLog mBsLog = new BsLog();
	
	private BefBsLog mBefBsLog=null;
	
	private EbcProperties mEbcProperties;

	//
	List<VoParameter> mVoParameterList;

	/**
	 * Dependecy injection
	 */
	protected BecReportImpl(BefReport pBefReport, EncryptionDecryption pEncryptionDecryption, BefBsLog pBefBsLog,EbcProperties pEbcProperties) {

		mBefReport = pBefReport;
		mEncryptionDecryption = pEncryptionDecryption;
		mBefBsLog = pBefBsLog;
		mEbcProperties = pEbcProperties;
	}

	void validate() {
		notNull(mBefReport);
		notNull(mEncryptionDecryption);
		notNull(mBefBsLog);

	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#init(com.ikea.ebccardpay1.cardpayment.utils.UserEnvironment)
	 */
	public BecReport init(UserEnvironment pUserEnvironment) {

		mUserEnvironment = pUserEnvironment;
		return this;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#findAll()
	 */
	public List<VoReport> findAll() {
		List<VoReport> vList = new ArrayList<VoReport>();

		List<Report> vReports = mBefReport.findAll();
		for (Iterator<Report> i = vReports.iterator(); i.hasNext();) {
			Report vReport = (Report) i.next();

			VoReport vVoReport = new VoReport();
			vVoReport.setVoParameterList(new ArrayList<VoParameter>());

			ValueObjects.assignToValueObject(vVoReport, vReport);

			for (Iterator<Parameter> j = vReport.getParameters().iterator();
					j.hasNext();
					) {
				Parameter vParameter = (Parameter) j.next();

				VoParameter vVoParameter = new VoParameter();
				ValueObjects.assignToValueObject(vVoParameter, vParameter);
				vVoReport.getVoParameterList().add(vVoParameter);
			}

			vList.add(vVoReport);
		}

		return vList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#setReport(long)
	 */
	public void setReport(long pReportId) {
		mReport = mBefReport.findByPrimaryKey(pReportId);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#setParameters(com.ikea.ebccardpay1.cardpayment.vo.VoParameter)
	 */
	public void setParameters(List<VoParameter> pVoParameterList) {
		mVoParameterList = pVoParameterList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#isKPIReport()
	 */
	public boolean isKPIReport()
			throws ValueMissingException, ReportException {

		requireReport();

		return mReport.getKpiReport();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#retrieveTransactionReport()
	 */
	public List<VoReportTransaction> retrieveTransactionReport()
			throws ValueMissingException, ReportException {

		requireReport();

		checkAccess();

		//Used for control if an aggregation should be made or not.
		boolean vAggregate = true;

		// Transfer parameter into a report parameter list
		List<ReportParameter> vParameterList = getParameterList();

		// Retrieve report
		List<Map<String, Object>> vMapList =
				mBefReport.retrieveReport(
						mReport.getQuery1(),
						mReport.getQuery2(),
						vParameterList);

		// Transfer to Report Transaction list
		List<VoReportTransaction> vVoReportTransactionList =
				new ArrayList<VoReportTransaction>();

		for (Iterator<Map<String, Object>> j = vMapList.iterator(); j.hasNext();) {
			Map<String, Object> vMap = j.next();

			VoReportTransaction vVoReportTransaction =
					new VoReportTransaction();
			ValueObjects.assignFromMap(vVoReportTransaction, vMap);
			//iPay4.8.1R- Sprint2
			//if (vVoReportTransaction.getCardNumberString().length()>19) {
				VoCardNumber vVoCardNumber = new VoCardNumber();
				vVoCardNumber.setIssuer(vVoReportTransaction.getCardNumberString().substring(0, 6));
				vVoCardNumber.setCardTypeDigit(new Integer(vVoReportTransaction.getCardNumberString().substring(6,7)).intValue());
				vVoCardNumber.setAccountNumber(mEncryptionDecryption.decrypt(vVoReportTransaction.getCardNumberString().substring(7, 18)));
				vVoCardNumber.setCheckDigit(new Integer(vVoReportTransaction.getCardNumberString().substring(18, 19)).intValue());
				vVoCardNumber.setCardNumberString(vVoCardNumber.getIssuer()+vVoCardNumber.getCardTypeDigit()+vVoCardNumber.getAccountNumber()+vVoCardNumber.getCheckDigit());
				vVoReportTransaction.setCardNumberString(vVoCardNumber.getCardNumberString());
			//}
			
			vVoReportTransactionList.add(
					vVoReportTransaction);

			//Check if this is NOT an original transaction report
			if (vMap.containsKey("not_aggregate")) {
				vAggregate = false;
			}
		}

		//Only do this aggregation if it is a true transaction report.
		if (vAggregate) {
			mCategory.debug("Call getCompressedVo");
			return getCompressedVo(vVoReportTransactionList);
		}

		return vVoReportTransactionList;
	}
	
	public List<VoReportTransaction> retrieveAdocReport(String query)
			throws ValueMissingException, ReportException{
				
			List<VoReportTransaction> vVoReportTransactionList =
						new ArrayList<VoReportTransaction>();
						
			requireUserEnvironment();

			String VUserId = mUserEnvironment.getUserId();
			
			List<Map<String, Object>> vMapList =
					mBefReport.retrieveAdocReport(
							query);
			if(vMapList.isEmpty()){
				throw new ReportException("No Records found for the query");
			}
			
			if (query.contains("from card_number_t")) {
				
				mBsLog.setBsInputs(query);
				mBsLog.setBsName("BsAdocReport");
				mBsLog.setCreatedBy(VUserId);
				
				java.util.Date dt = new java.util.Date();

				mBsLog.setCreatedDateTime(dt);
				mBefBsLog.save(mBsLog);
				
			}
			
			
							
			HSSFWorkbook workbook = new HSSFWorkbook();
		     HSSFSheet sheet = workbook.createSheet("Sample sheet");
		     					
					Map<String, Object> vFirstMap = vMapList.get(0);
					Set<String> keyset1 = vFirstMap.keySet();
					
					HSSFRow header = sheet.createRow(0);
					int headerRow = 0;
					
					for(String key : keyset1) {
						HSSFCell cell = header.createCell(headerRow);
						cell.setCellValue(key);
						headerRow++;
					}
					
		    
					int rownum = 1;
				SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
		     for (Iterator<Map<String, Object>> j = vMapList.iterator(); j.hasNext();) {
					
					Map<String, Object> vMap = j.next();
					
					
					
					HSSFRow row = sheet.createRow(rownum++);
					int cellnum = 0;
					for(Map.Entry<String, Object> entry : vMap.entrySet()) {
						
						
						
						Object obj = entry.getValue();
						
													
							if(entry.getKey().equals("ACCOUNT_NUMBER_ENC") || entry.getKey().equals("VERIFICATION_CODE_ENC")) {
								obj=mEncryptionDecryption.decrypt((String)obj);
							}
							HSSFCell cell = row.createCell(cellnum++);
							//cell.setCellValue((String)obj);
							if (obj instanceof Date) {
								cell.setCellValue(formatter.format((Date) obj));
							} else if (obj instanceof Boolean) {
								cell.setCellValue((Boolean) obj);
							} else if (obj instanceof String) {
								cell.setCellValue((String) obj);
							} else if (obj instanceof Double) {
								cell.setCellValue((Double) obj);
							} else if (obj instanceof Number)  {
								cell.setCellValue(  ((Number) obj).intValue());
							}/*else if (obj instanceof Blob)  {
								
								try {
								
								byte[] bdata = (byte[]) ((Blob) obj).getBytes(1, (int) ((Blob) obj).length());
								 String blobData = new String(bdata);
								 //String[] textArray= splitByNumber(blobData,30000);
								 //for(String stringData: textArray) {
									 cell.setCellValue( blobData.substring(0, 30000));
								 //}
								
								}
								catch(Exception e) {
									
								}
							}*/
							
						}
					}	
		     
		     try {
		    	 
		    	 String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		    	 String FilePath = mEbcProperties.getString("FilePath", "IPAY_ADHOC_REPORTS/ipayadhoc");
		    	 mCategory.info("FilePath="+FilePath);
		    	 
		    	 String User = mEbcProperties.getString("User","s-adcipay-a-ppseelm");
		    	// mCategory.info("User="+User);
		    	 String Password =mEbcProperties.getString("Password","AdoWigsSat9");
		    	// mCategory.info("Password="+Password);
		    	 String Domain = mEbcProperties.getString("Domain","IKEADT");
		    	// mCategory.info("Domain="+Domain);
		    	 String Address = mEbcProperties.getString("Address","10.230.62.37");

		    	    String sharedFolder=mEbcProperties.getString("SharedFolder","Common_A");
		    	    String path=FilePath+timestamp+".xls";
		    	    
		    	    SmbConfig smbConfig = SmbConfig.builder().withSoTimeout(3000).build();
		            AuthenticationContext authenticationContext = new AuthenticationContext(User, Password.toCharArray(), Domain);
		            try (SmbConnection smbConnection = new SmbConnection(Address, sharedFolder, authenticationContext, smbConfig)) {
		            	SmbDirectory rootDirectory = new SmbDirectory(smbConnection);
		            	SmbFile smbFile = new SmbFile(smbConnection,path);
		            	byte[] byteArray = workbook.getBytes();
		            	InputStream inputStream = new ByteArrayInputStream(byteArray);
		            	OutputStream outputStream = smbFile.getOutputStream();
		            	
		            	 //smbFile.createFile();
		            	 
		            	 //FileOutputStream out = new FileOutputStream(smbFile);
		            	 
		            	 
		            	 
		            	 

		            	    // Append to the file
		            	   // OutputStream outputStream = smbFile.getOutputStream(true);

		            	    IOUtils.copy(inputStream, outputStream);
		            	//workbook.write(smbFile.getOutputStream());

		                	inputStream.close();
		                    outputStream.close();
		            	 
		            	 //workbook.write(smbFile);
		            }
		                
		    	    
		    	   /* mCategory.info("Path="+path);
		    	    NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(Domain,User, Password);
		    	    mCategory.info("auth done");
		    	    SmbFile smbFile = new SmbFile(path,auth);
		    	    mCategory.info("smbfile created");
		    	    SmbFileOutputStream smbfos = new SmbFileOutputStream(smbFile);
		    	      mCategory.info("OuputStream");
		    	   smbfos.write("testing....and writing to a file".getBytes());
		    	    System.out.println("completed ...nice !");
		    	   workbook.write(smbfos);*/
		     //FileOutputStream out = new FileOutputStream(new File(FilePath+timestamp+".xls"));
		     //workbook.write(out);
		     //out.close();
		     System.out.println("Excel Succesfully created");
		     		     } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }catch(Exception e ) {
		        	e.printStackTrace();
		        }
			
			for (Iterator<Map<String, Object>> j = vMapList.iterator(); j.hasNext();) {
				
				Map<String, Object> vMap = j.next();
				
				VoReportTransaction vVoReportTransaction =
						new VoReportTransaction();
				vVoReportTransaction.setBuCode("030");
				ValueObjects.assignFromMap(vVoReportTransaction, vMap);
				
				vVoReportTransactionList.add(
						vVoReportTransaction);
				}
				
			return vVoReportTransactionList;
			
	}
	
	public List<VoReportResults> retrieveCardDetails(String query)
			throws ValueMissingException, ReportException{
				
			List<VoReportResults> vVoReportResultList =
					new ArrayList<VoReportResults>();
					
			String cardType=query.substring(6, 7);
			
			requireUserEnvironment();

			String VUserId = mUserEnvironment.getUserId();
			if (cardType.equalsIgnoreCase("2")||cardType.equalsIgnoreCase("4")) {
				
				mBsLog.setBsInputs(query);
				mBsLog.setBsName("BsAdocReport");
				mBsLog.setCreatedBy(VUserId);
				
				java.util.Date dt = new java.util.Date();
				
				mBsLog.setCreatedDateTime(dt);
				mBefBsLog.save(mBsLog);
				
			}
			
			VoCardNumber vVoCardNumber = new VoCardNumber();
			vVoCardNumber.setIssuer(query.substring(0, 6));
			vVoCardNumber.setCardTypeDigit(new Integer(query.substring(6,7)).intValue());
			vVoCardNumber.setAccountNumber(mEncryptionDecryption.encrypt(query.substring(7, 18)));
			vVoCardNumber.setCheckDigit(new Integer(query.substring(18, 19)).intValue());
			
			/*String query1 = "select a.cardNumberId, a.verificationCode, b.cardId, b.cardState from Card b INNER JOIN b.cardNumber as a where a.issuer = '"
								+vVoCardNumber.getIssuer()+"' and a.cardTypeDigit = "+vVoCardNumber.getCardTypeDigit()+" and a.accountNumber = '"+vVoCardNumber.getAccountNumber()
								+"' and a.checkDigit = "+vVoCardNumber.getCheckDigit();*/
			
			
			VoReportResults vVoReportResults = mBefReport.retrieveCardDetails(
					vVoCardNumber);
			
			vVoReportResults.setVerificationCode(mEncryptionDecryption.decrypt(vVoReportResults.getVerificationCode()));
			
			vVoReportResultList.add(
					vVoReportResults);
			
			return vVoReportResultList;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bec.BecReport#retrieveKPIReport()
	 */
	public List<VoReportKPI> retrieveKPIReport()
			throws ValueMissingException, ReportException {

		requireReport();

		checkAccess();

		List<VoReportKPI> vVoReportKPIList = new ArrayList<VoReportKPI>();

		// Transfer parameter into a report parameter list
		List<ReportParameter> vParameterList = getParameterList();

		// Retrieve report
		List<Map<String,Object>> vList =
				mBefReport.retrieveReport(
						mReport.getQuery1(),
						mReport.getQuery2(),
						vParameterList);

		// Transfer to VoKPI list
		for (Iterator<Map<String,Object>> j = vList.iterator(); j.hasNext();) {
			Map<String, Object> vMap = j.next();

			VoReportKPI vVoReportKPI = new VoReportKPI();

			ValueObjects.assignFromMap(vVoReportKPI, vMap);

			if (vVoReportKPI.getCreditAmount() != null
					&& vVoReportKPI.getDebitAmount() != null) {
				vVoReportKPI.setDebtAmount(
						Amounts.subtract(
								vVoReportKPI.getCreditAmount(),
								vVoReportKPI.getDebitAmount()));
			}

			vVoReportKPIList.add(vVoReportKPI);
		}

		return vVoReportKPIList;
	}

	// ---------- Internal methods, must be protected so unit tests can access them ----------

	/**
	 * Fill the VO list with transaction values in a collection of value maps.
	 * Then can the value maps be used to create VoTransaction, VoTransactionBrief, 
	 * VoReportTransaction or TransactionCard.
	 */
	protected List<VoReportTransaction> getCompressedVo(List<VoReportTransaction> pInputList)
			throws ValueMissingException {

		List<VoReportTransaction> vVoReportTransactionList =
				new ArrayList<VoReportTransaction>();

		if (pInputList == null || pInputList.size() == 0) {
			return vVoReportTransactionList;
		}

		// Group them into a map structure to compress the info
		Map<Long, Map<String, Object>> vMap = new TreeMap<Long, Map<String, Object>>();
		Map<String, Object> vVoTransactionValues;

		for(VoReportTransaction vInput: pInputList){

			if (vMap.containsKey(new Long(vInput.getTransactionNo()))) {
				vVoTransactionValues =
						vMap.get(new Long(vInput.getTransactionNo()));
				// If one of them is insufficient amount then set to true
				if (vInput.getInsufficientAmount()) {
					vVoTransactionValues.put(
							"insufficientAmount",
							CodeGeneration.toObject(true));
				}
				// Take the largest and set as requested redeem amount
				if (Amounts
						.isLessOrEqual(
								(BigDecimal) vVoTransactionValues.get(
										"requestedAmount"),
										vInput.getRequestedAmount())) {
					vVoTransactionValues.put(
							"requestedAmount",
							vInput.getRequestedAmount());
				}
			} else {
				vVoTransactionValues = new HashMap<String, Object>();
				vVoTransactionValues = ValueObjects.assignToMap(vInput);
				// Create initial values
				vVoTransactionValues.put("creditAmount", Amounts.zero());
				vVoTransactionValues.put("debitAmount", Amounts.zero());

				vMap.put(
						new Long(vInput.getTransactionNo()),
						vVoTransactionValues);
			}
			// Add the sums
			vVoTransactionValues.put(
					"creditAmount",
					Amounts.add(
							(BigDecimal) vVoTransactionValues.get("creditAmount"),
							vInput.getCreditAmount()));
			vVoTransactionValues.put(
					"debitAmount",
					Amounts.add(
							(BigDecimal) vVoTransactionValues.get("debitAmount"),
							vInput.getDebitAmount()));
		}

		Collection<Map<String, Object>> vMapValuesList = vMap.values();
		for (Iterator<Map<String, Object>> i = vMapValuesList.iterator(); i.hasNext();) {
			Map<String, Object> vMapValus = i.next();
			VoReportTransaction vVoReportTransaction =
					new VoReportTransaction();
			ValueObjects.assignFromMap(vVoReportTransaction, vMapValus);

			vVoReportTransactionList.add(
					vVoReportTransaction);
		}

		return vVoReportTransactionList;
	}

	/**
	 * Transfer parameter into a report parameter list
	 * @return
	 */
	protected List<ReportParameter> getParameterList()
			throws ValueMissingException, ReportException {

		// Check to see if this is a KPI report
		boolean vKPI = mReport.getKpiReport();

		List<ReportParameter> vParameterList = new LinkedList<ReportParameter>();

		// Build a list of report parameters from the VO parameter list
		Collection<Parameter> vParameters = mReport.getParameters();
		for (Iterator<Parameter> i = vParameters.iterator(); i.hasNext();) {
			Parameter vParameter = (Parameter) i.next();

			// Extract useful values
			String vType = vParameter.getParameterType();
			String vValue = getParameterValue(vType);
			boolean vEmpty = vValue == null || vValue.length() == 0;

			// If parameter is optional and the value is empty, we skip this parameter
			if (!vParameter.getMandatory() && vEmpty)
				continue;
			else if (vEmpty) {
				throw new ReportException(
						"The parameter " + vType + " is mandatory");
			}

			// Create report parameter
			ReportParameter vReportParam = new ReportParameter();
			Restrictions vRestrictions = new Restrictions();

			// Convert to List
			List<String> vValues =
					vParameter.getAllowList()
					? Arrays.asList(vValue.split(","))
							: Collections.singletonList(vValue);

					// Set value either as list or as a singular value
					if (vValues.size() > 1) {
						vReportParam.setValues(vValues);
						vReportParam.setOperator(ReportParameter.OPERATOR_IN);
					} else if (vValues.size() == 1) {
						vReportParam.setValue((String) vValues.get(0));
					}

					// Set parameter names, based on type
					setParameterNames(vKPI, vType, vReportParam);

					// Add parameter to list
					vParameterList.add(vReportParam);

					// Check if any of the parameters have single parameter restrictions to verify
					mCategory.info("Start checking report parameter restrictions");
					vRestrictions.checkRestrictions(vParameter, vValue);

		}

		//Check special date ranges which is dependent of two parameters
		checkDateRange(vParameterList);

		return vParameterList;
	}

	protected void checkDateRange(List<ReportParameter> pParameterList) throws ReportException {

		// Check fromMonthDate --> toMonthDate with format yyyy-MM
		// with restrictions attached
		Date vFromMonth =
				(Date) getParameterValue(pParameterList,
						Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_MONTH);
		Date vToMonth =
				(Date) getParameterValue(pParameterList,
						Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_MONTH);
		if (vFromMonth != null && vToMonth != null) {

			DateTime vNewFromMonth =
					(DateTime) Dates.getDateTime(
							Dates.withoutTime(Dates.getDateTime(vFromMonth)));
			DateTime vOriginalToMonth =
					(DateTime) Dates.getDateTime(
							Dates.withoutTime(Dates.getDateTime(vToMonth)));

			DateTime vNewToMonth =
					(DateTime) Dates.getDateTime(
							Dates.withoutTime(Dates.getDateTime(vToMonth)));

			mCategory.info("vNewFromMonth: " + vNewFromMonth);
			mCategory.info("From month: " + vFromMonth);
			mCategory.info("To month: " + vOriginalToMonth);
			mCategory.info("vNewToMonth: " + vNewToMonth);

			// Get restrictions from the KPI_FROM_MONTH parameter
			String maxMonths =
					(String) getParameterRestrictionValue(mReport.getParameters(),
							Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_MONTH);

			if (maxMonths != null) {

				mCategory.info("Max months in range: " + maxMonths);
				mCategory.info(
						"New To Date: "
								+ vNewFromMonth.plusMonths(Integer.parseInt(maxMonths)));
				// Calculate the max ToMonth
				vNewToMonth =
						vNewFromMonth.plusMonths(Integer.parseInt(maxMonths));

				// Check if the input range is over max range
				if (vOriginalToMonth.toDate().after(vNewToMonth.toDate())) {
					throw new InvalidFromToDateException(
							"Invalid range of from date - to date. Can not be larger than "
									+ maxMonths
									+ " months");
				}

			}

			vNewToMonth =
					(DateTime) Dates.getDateTime(
							Dates.withoutTime(Dates.getDateTime(vToMonth)));
			// Check ordinary fromDate --> toDate with format yyyy-mm-dd without restrictions
			if (vNewFromMonth != null
					&& vNewToMonth != null
					&& vNewFromMonth.isAfter(vNewToMonth)) {
				throw new InvalidFromToDateException("From date is greater than to date");
			}

		}

		//Check parameters KPI_FROM_DATE -->KPI_TO_DATE 
		Date vFromDate =
				(Date) getParameterValue(pParameterList,
						Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_DATE);
		Date vToDate =
				(Date) getParameterValue(pParameterList,
						Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_DATE);

		if (vFromDate != null && vToDate != null && vFromDate.after(vToDate)) {
			//throw new ReportException("From date is greater than to date");
			throw new InvalidFromToDateException("From date is greater than to date");
		}

	}

	/**
	 * @param pKPI
	 * @param pParameterType
	 * @param pReportParameter
	 * @throws ReportException
	 */
	private void setParameterNames(
			boolean pKPI,
			String pParameterType,
			ReportParameter pReportParameter)
					throws ReportException {

		pReportParameter.setParameterType(pParameterType);

		// We need to know the table aliases in order to match the right table
		// so an assumption is made here and it is diffrent depending on the type
		// of report, KPI or Transaction based.
		if (Constants.PARAMETER_TYPE_CONSTANT_BU_TYPE.equals(pParameterType)) {
			if (pKPI)
				pReportParameter.setNames("a.buType", "buType");
			else
				pReportParameter.setNames("t.buType", "buType");
		} else if (Constants.PARAMETER_TYPE_CONSTANT_BU_CODE
				.equals(pParameterType)) {
			if (pKPI)
				pReportParameter.setNames("a.buCode", "buCode");
			else
				pReportParameter.setNames("t.buCode", "buCode");

		} else if (Constants.PARAMETER_TYPE_CONSTANT_FROM_BU_TYPE
				.equals(pParameterType)) {
			pReportParameter.setNames("a.fromBuType", "fromBuType");

		} else if (Constants.PARAMETER_TYPE_CONSTANT_FROM_BU_CODE
				.equals(pParameterType)) {
			pReportParameter.setNames("a.fromBuCode", "fromBuCode");

		} else if (Constants.PARAMETER_TYPE_CONSTANT_COUNTRY_CODE
				.equals(pParameterType)) {
			pReportParameter.setNames("c.countryCode", "countryCode");
		} else if (Constants.PARAMETER_TYPE_CONSTANT_FROM_COUNTRY_CODE
				.equals(pParameterType)) {
			pReportParameter.setNames("a.fromCountryCode", "fromCountryCode");
		} else if (Constants.PARAMETER_TYPE_CONSTANT_TO_COUNTRY_CODE
				.equals(pParameterType)) {
			pReportParameter.setNames("a.toCountryCode", "toCountryCode");

		} else if (Constants.PARAMETER_TYPE_CONSTANT_COMPANY_CODE.equals(pParameterType)) {
			pReportParameter.setNames("b.companyCode", "companyCode");
		} else if (Constants.PARAMETER_TYPE_CONSTANT_FROM_COMPANY_CODE.equals(pParameterType)) {
			pReportParameter.setNames("c.companyCode", "fromCompanyCode");

		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_DATE.equals(
						pParameterType)) {
			validateDateValue(pReportParameter);
			pReportParameter.setNames("a.kpiInterval", "kpiInterval");
		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_MONTH.equals(
						pParameterType)) {
			validateMonthValue(pReportParameter);
			pReportParameter.setNames("a.kpiInterval", "kpiInterval");
			pReportParameter.setOperator(ReportParameter.OPERATOR_SUBSTRING);
		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_MONTH.equals(
						pParameterType)) {
			validateMonthValue(pReportParameter);
			pReportParameter.setNames(
					"substring(a.kpiInterval,1,7)",
					"fromKpiMonth");
			pReportParameter.setOperator(
					ReportParameter.OPERATOR_GREATER_OR_EQUAL);
		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_MONTH.equals(
						pParameterType)) {
			validateMonthValue(pReportParameter);
			pReportParameter.setNames(
					"substring(a.kpiInterval,1,7)",
					"toKpiMonth");
			pReportParameter.setOperator(
					ReportParameter.OPERATOR_LESS_OR_EQUAL);
		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_FROM_DATE.equals(
						pParameterType)) {
			validateDateValue(pReportParameter);
			pReportParameter.setNames("a.kpiInterval", "fromKpiInterval");
			pReportParameter.setOperator(
					ReportParameter.OPERATOR_GREATER_OR_EQUAL);
		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_KPI_TO_DATE.equals(
						pParameterType)) {
			validateDateValue(pReportParameter);
			pReportParameter.setNames("a.kpiInterval", "toKpiInterval");
			pReportParameter.setOperator(
					ReportParameter.OPERATOR_LESS_OR_EQUAL);

		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_CARD_TYPE.equals(
						pParameterType)) {
			if (pKPI)
				pReportParameter.setNames("a.cardType", "cardType");
			else
				pReportParameter.setNames("c.cardType", "cardType");

		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_SOURCE_SYSTEM.equals(
						pParameterType)) {
			if (pKPI)
				pReportParameter.setNames("a.sourceSystem", "sourceSystem");
			else
				pReportParameter.setNames("t.sourceSystem", "sourceSystem");

		} else if (
				Constants.PARAMETER_TYPE_CONSTANT_SALES_DAY.equals(
						pParameterType)) {
			validateDateValue(pReportParameter);
			pReportParameter.setNames("t.salesDay", "salesDay");

		} else if (
				Constants
				.PARAMETER_TYPE_CONSTANT_LAST_TRANSACTION_DATE_TIME
				.equals(
						pParameterType)) {
			validateaAndSetDateValue(pReportParameter);
			pReportParameter.setNames(
					"c.lastTransactionDateTime",
					"lastTransactionDateTime");
			// To make use of the true datatype "Date" as parameter mapping	
			pReportParameter.setUseObject(true);
			pReportParameter.setOperator(ReportParameter.OPERATOR_LESS);
		} else {
			throw new ReportException(
					"This parameter type name is not valid: " + pParameterType);
		}
	}

	/**
	 * @param pReportParameter
	 * @throws ReportException
	 */
	protected void validateDateValue(ReportParameter pReportParameter)
			throws ReportException {

		String vValue = pReportParameter.getValue();
		if (vValue != null && vValue.length() > 0) {
			try {
				synchronized(sDateFormat) //Execute parsing in Synchronized block
				{
					pReportParameter.setObjectValue(sDateFormat.parse(vValue));
				}
			} catch (ParseException e) {
				throw new ReportException();

			}
		}
	}

	/**
	 * @param pReportParameter
	 */
	protected void validateaAndSetDateValue(ReportParameter pReportParameter) {

		String vValue = pReportParameter.getValue();
		if (vValue != null && vValue.length() > 0) {
			pReportParameter.setObjectValue(
					Dates.withoutTime(Dates.parseDate(vValue)));
		}
	}

	/**
	 * @param pReportParameter
	 * @throws ReportException
	 */
	protected void validateMonthValue(ReportParameter pReportParameter)
			throws ReportException {

		String vValue = pReportParameter.getValue();
		mCategory.info("validateMonthValue value:" + vValue);
		if (vValue != null && vValue.length() > 0) {
			try {
				pReportParameter.setObjectValue(sMonthFormat.parse(vValue));
				mCategory.info(
						"validateMonthValue parsed value:"
								+ sMonthFormat.parse(vValue));
			} catch (ParseException e) {
				throw new ReportException();
			}
		}
	}

	/**
	 * @param pParameterType
	 * @return
	 */
	protected String getParameterValue(String pParameterType)
			throws ValueMissingException, ReportException {

		requireParameterList();
		for(VoParameter vVoParameter :mVoParameterList){

			// Extract useful values
			String vType = vVoParameter.getParameterType();
			String vValue = vVoParameter.getParameterValue();

			if (vType != null && vType.equals(pParameterType)) {
				return vValue;
			}
		}

		return null;
	}

	/**
	 * @param pParameterType
	 * @return
	 */
	protected Object getParameterValue(
			Collection<ReportParameter> pParameters,
			String pParameterType)
					throws ReportException {

		for (Iterator<ReportParameter> i = pParameters.iterator(); i.hasNext();) {
			ReportParameter vReportParameter = (ReportParameter) i.next();
			if (vReportParameter != null
					&& pParameterType.equals(vReportParameter.getParameterType())) {
				return vReportParameter.getObjectValue();
			}
		}

		return null;
	}

	/**
	 * @param pParameterType
	 * @return
	 */
	protected Object getParameterRestrictionValue(
			Collection<Parameter> pParameters,
			String pParameterType)
					throws ReportException {

		for (Iterator<Parameter> i = pParameters.iterator(); i.hasNext();) {
			Parameter vParameter = (Parameter) i.next();
			if (vParameter != null
					&& pParameterType.equals(vParameter.getParameterType())) {
				return vParameter.getRestrictions();
			}
		}

		return null;
	}

	/**
	 * @throws ReportException
	 */
	protected void checkAccess()
			throws ValueMissingException, ReportException {

		requireReport();
		requireUserEnvironment();

		String VUserId = mUserEnvironment.getUserId();

		// Retirve privilege
		String vPrivilege = mReport.getPrivilege();

		// Check privilege
		if (vPrivilege != null && vPrivilege.length() > 0) {
			boolean vHasPrivilege = false;
			vHasPrivilege = mUserEnvironment.hasPrivilege(vPrivilege);

			if (!vHasPrivilege) {
				throw new ReportException(
						"User '"
								+ VUserId
								+ "' does not have access to report '"
								+ mReport.getName()
								+ "', the privilege '"
								+ vPrivilege
								+ "' is needed");
			}
		}
	}

	/**
	 * 
	 * @throws ReportException
	 */
	protected void requireReport() throws ValueMissingException {
		if (mReport == null)
			throw new ValueMissingException("Tried to use BecReport without required Report.");
	}

	/**
	 * 
	 * @throws ReportException
	 */
	protected void requireParameterList() throws ValueMissingException {
		if (mVoParameterList == null)
			throw new ValueMissingException("Tried to use BecReport without required List<VoParameter>.");
	}

	/**
	 * 
	 * @throws ReportException
	 */
	protected void requireUserEnvironment() throws ValueMissingException {
		if (mUserEnvironment == null)
			throw new ValueMissingException("Tried to use BecReport without required UserEnvironment.");
	}


}
