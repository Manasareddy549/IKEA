///**
// *	Automatically generated file
// */
//package com.ikea.ebccardpay1.cardpayment.bef;
//
//import com.ikea.framework.exception.IkeaException;
//
//public class BefFactorySingleton {
//
//    protected static BefFactory sInstance;
//
//    synchronized public static BefFactory getInstance() throws IkeaException {
//        if (sInstance == null) {
//            throw new IllegalStateException("Should have been initiated by Spring Framework");
//        }
//        return sInstance;
//    }
//
//    synchronized public static void setInstance(BefFactory pFactory) {
//        sInstance = pFactory;
//    }
//}