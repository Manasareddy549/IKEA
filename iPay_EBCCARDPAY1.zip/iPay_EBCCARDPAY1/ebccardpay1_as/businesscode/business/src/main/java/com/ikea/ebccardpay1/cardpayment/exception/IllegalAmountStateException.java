/*
 * Created on 2006-maj-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;


/**
 * @author anms
 */
public class IllegalAmountStateException extends AmountException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7444631914964472283L;
	public IllegalAmountStateException() {
		super();
	}
	public IllegalAmountStateException(String pMessage) {
		super(pMessage);
	}
}
