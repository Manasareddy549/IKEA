package com.ikea.ebccardpay1.cardpayment.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.common.Constants;

public class DefaultPriorityEvaluator implements PriorityEvaluator {

	public BigDecimal evaluatePriority(Set<Amount> pAmounts, int pBasePriority) {
		// Create a real priority out of base priority
		BigDecimal vLowPriority = Priorities.priority(pBasePriority);

		// Create the next base priority
		BigDecimal vHighPriority = Priorities.priority(pBasePriority
				+ Constants.AMOUNT_PRIORITY_INTERVAL);

		// Find all other amounts with the same amount type
		List<Amount> vList = new ArrayList<Amount>();

		if (pAmounts != null) {
			for (Iterator<Amount> i = pAmounts.iterator(); i.hasNext();) {
				Amount vAmount = (Amount) i.next();
				if (vAmount != null
						&& Priorities
								.less(vAmount.getPriority(), vHighPriority)
						&& Priorities.greaterOrEquals(vAmount.getPriority(),
								vLowPriority)) {
					// vLowPriority <= vAmount.getPriority() < vHighPriority
					vList.add(vAmount);
				}
			}
		}

		Collections.sort(vList, sPriorityComparator);
		
		// First amount in the type gets the base priority
		if (vList.size() == 0) {
			return vLowPriority;
		}

		// Find the last amount
		Amount vAmount = (Amount) vList.get(vList.size() - 1);

		// Create new priority between high and low
		return Priorities.newPriority(vAmount.getPriority(), vHighPriority);
	}

	public static final Comparator<Amount> sPriorityComparator = new Comparator<Amount>() {
		public int compare(Amount o1, Amount o2) {
			return ((Amount) o1).getPriority().compareTo(
					((Amount) o2).getPriority());
		}
	};

}
