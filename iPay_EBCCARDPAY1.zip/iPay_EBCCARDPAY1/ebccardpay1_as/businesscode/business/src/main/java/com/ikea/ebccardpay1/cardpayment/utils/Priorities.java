/*
 * Created on 2006-aug-07
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import java.math.BigDecimal;

import com.ikea.ebccardpay1.common.Constants;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Priorities {
	public static final int SCALE = 35;
	private static final BigDecimal DIVISOR = new BigDecimal(Constants.AMOUNT_PRIORITY_INTERVAL);

	/**
	 * 
	 * @param pPriority
	 * @return
	 */
	public static BigDecimal priority(int pPriority) {
		BigDecimal vPriority = new BigDecimal(pPriority);
		vPriority = vPriority.setScale(SCALE);
		return vPriority;
	}
	
	
	public static boolean less(BigDecimal pLeft, BigDecimal pRight) {
		return pLeft.compareTo(pRight) == -1;
	}
	public static boolean greaterOrEquals(BigDecimal pLeft, BigDecimal pRight) {
		return pLeft.compareTo(pRight) >= 0;
	}
	

	public static BigDecimal newPriority(BigDecimal pLowPriority, BigDecimal pHighPriority) {
		BigDecimal vPriority = pHighPriority.subtract(pLowPriority);
		vPriority = vPriority.divide(DIVISOR, BigDecimal.ROUND_HALF_EVEN);
		vPriority = pLowPriority.add(vPriority);
		vPriority = vPriority.setScale(SCALE);
		return vPriority;
	}

}
