/*
 * Created on 2007-jan-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

import com.ikea.ebcframework.error.ApplicationError;

/**
 * @author anms
 *
 */
public class ReferenceAlreadyExistsException extends ReferenceCheckException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6882729534839848003L;

	/**
	 * @param pMessage
	 */
	public ReferenceAlreadyExistsException(
		String pSourceSystem,
		String pReference
		//String pSalesDay)
		){
		super(pSourceSystem, pReference);
	}

	public ApplicationError createApplicationError() {
		return new EbcCardPay1ApplError.ReferenceAlreadyExists(
			mSourceSystem,
			mReference);
	}
}
