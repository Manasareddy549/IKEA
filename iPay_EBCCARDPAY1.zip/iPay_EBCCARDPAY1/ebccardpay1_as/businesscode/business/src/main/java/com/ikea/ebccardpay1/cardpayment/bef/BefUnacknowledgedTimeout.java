/**
 * 
 */
package com.ikea.ebccardpay1.cardpayment.bef;


import com.ikea.ebccardpay1.cardpayment.be.*;

public interface BefUnacknowledgedTimeout extends Bef<UnacknowledgedTimeout>{
	
	public UnacknowledgedTimeout getUnacknowledgedTimeout(String pBuCode,String pBuType,String pSourceSystem);

	

}