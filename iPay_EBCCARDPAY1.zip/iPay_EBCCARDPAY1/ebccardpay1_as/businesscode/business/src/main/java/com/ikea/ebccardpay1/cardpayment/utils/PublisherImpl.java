package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ikea.ebccardpay1.cardpayment.utils.entities.EBCPAYLOAD;
import com.ikea.ebcframework.services.EbcProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;

import com.ikea.ebccardpay1.cardpayment.be.Message;
import com.ikea.ebccardpay1.cardpayment.bef.BefMessage;

public class PublisherImpl implements Publisher {

	private final static Logger mLogger = LoggerFactory.getLogger(PublisherImpl.class);
	private EbcProperties mEbcProperties;
	private BefMessage mBefMessage;
	private final String MASS_LOAD = "MASS_LOAD";

	public PublisherImpl(EbcProperties pEbcProperties, BefMessage pBefMessage) {
		mEbcProperties = pEbcProperties;
		mBefMessage = pBefMessage;
	}

	@Override
	public void publishMessage(EBCPAYLOAD pEBCPAYLOAD) {

		String mqExchange = mEbcProperties.getString("mqExchange", "PrimaryExchange");
		String mqHost = mEbcProperties.getString("mqHost", "10.232.43.70");
		int mqPort = mEbcProperties.getInt("mqPort", 32282);
		String mqUsername = mEbcProperties.getString("mqUsername", "user");
		String mqPassword = mEbcProperties.getString("mqPassword", "$RABBITMQ_PASSWORD");

		mLogger.debug("MQ_EXCHANGE :" + mqExchange);
		mLogger.debug("MQ_HOST :" + mqHost);
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		EBCPAYLOAD vEBCPAYLOAD = new EBCPAYLOAD();
		vEBCPAYLOAD = pEBCPAYLOAD;

		ConnectionFactory factory = new ConnectionFactory();

		factory.setHost(mqHost);
		factory.setPort(mqPort);
		factory.setUsername(mqUsername);
		factory.setPassword(mqPassword);

		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(EBCPAYLOAD.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			// Display result to console
			//marshaller.marshal(vEBCPAYLOAD, System.out);
			marshaller.marshal(vEBCPAYLOAD, bos);
			mLogger.info("Transaction ID - " + vEBCPAYLOAD.getData().getTransactionId());
			mLogger.info("Transaction Type - " + vEBCPAYLOAD.getData().getTransactionType());
		} catch (JAXBException e1) {
			mLogger.error("Error while marshalling ebc payload - " + "Transaction ID - " + vEBCPAYLOAD.getData().getTransactionId());
			
			e1.printStackTrace();
		}

		try (Connection connection = factory.newConnection(); Channel channel = connection.createChannel()) {
			channel.basicPublish(mqExchange, "", MessageProperties.PERSISTENT_TEXT_PLAIN, bos.toByteArray());
			mLogger.info("Message has been pushed to RabbitMQ - " + "Transaction ID - " + vEBCPAYLOAD.getData().getTransactionId());
		} catch (Exception e) {
			mLogger.error("Message has been failed to send to RabbitMQ - " + "Transaction ID - " + vEBCPAYLOAD.getData().getTransactionId());
			if ((null != vEBCPAYLOAD && null != vEBCPAYLOAD.getData())
				&& (!MASS_LOAD.equalsIgnoreCase(vEBCPAYLOAD.getData().getTransactionType()))) {
				saveMessage(vEBCPAYLOAD, bos);
				mLogger.info("Message has been pushed to MESSAGE_T table.");
			}
		}

	}

	private void saveMessage(EBCPAYLOAD pEBCPAYLOAD, ByteArrayOutputStream bos) {

		Message message = mBefMessage.create();
		try {
			message.setMessage(new SerialBlob(bos.toByteArray()));
		} catch (SQLException e) {
			e.printStackTrace();
			mLogger.info("Error while saving blob in MESSAGE_T table.");
		}

		mBefMessage.save(message);

	}
	
	@Override
	public void publishMessage(List<EBCPAYLOAD> pEBCPayloadList) {


		String mqExchange = mEbcProperties.getString("mqExchange", "PrimaryExchange");
		String mqHost = mEbcProperties.getString("mqHost", "10.232.43.70");
		int mqPort = mEbcProperties.getInt("mqPort", 32282);
		String mqUsername = mEbcProperties.getString("mqUsername", "user");
		String mqPassword = mEbcProperties.getString("mqPassword", "$RABBITMQ_PASSWORD");

		mLogger.debug("MQ_EXCHANGE :" + mqExchange);
		mLogger.debug("MQ_HOST :" + mqHost);
		
		
		

		ConnectionFactory factory = new ConnectionFactory();

		factory.setHost(mqHost);
		factory.setPort(mqPort);
		factory.setUsername(mqUsername);
		factory.setPassword(mqPassword);

		
		try {
			Connection connection = factory.newConnection();
			Channel channel = connection.createChannel();
			
			JAXBContext jaxbContext = JAXBContext.newInstance(EBCPAYLOAD.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			for(EBCPAYLOAD ebc : pEBCPayloadList) {
				
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				// Display result to console
				//marshaller.marshal(ebc, System.out);
				marshaller.marshal(ebc, bos);
				mLogger.info("Transaction ID - " + ebc.getData().getTransactionId());
				mLogger.info("Transaction Type - " + ebc.getData().getTransactionType());
				channel.basicPublish(mqExchange, "", MessageProperties.PERSISTENT_TEXT_PLAIN, bos.toByteArray());
				mLogger.info("Message has been pushed to RabbitMQ.");
			}
			pEBCPayloadList.clear();
		} catch (Exception e) {
			mLogger.error("Message has been failed to send to RabbitMQ.");
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(EBCPAYLOAD.class);
				Marshaller marshaller = jaxbContext.createMarshaller();
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
	
				for(EBCPAYLOAD ebc : pEBCPayloadList) {
					
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					// Display result to console
					marshaller.marshal(ebc, System.out);
					marshaller.marshal(ebc, bos);
					
					saveMessage(ebc, bos);
				}
				mLogger.info("Message has been pushed to MESSAGE_T table.");
				pEBCPayloadList.clear();
			} catch(JAXBException vJAXBException) {
				mLogger.error("Message has been failed to send to MESSAGE_T table.");
				pEBCPayloadList.clear();
			}
		}
	}

}
