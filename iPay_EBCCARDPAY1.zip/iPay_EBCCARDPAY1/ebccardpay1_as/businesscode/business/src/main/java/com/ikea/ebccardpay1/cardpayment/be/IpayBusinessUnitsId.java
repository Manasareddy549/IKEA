
package com.ikea.ebccardpay1.cardpayment.be;

import java.io.Serializable;

public class IpayBusinessUnitsId implements Serializable {
	
	static final long serialVersionUID = -687991492884005033L;
	
	private String mBuType;
	private String mBuCode;
	
	public IpayBusinessUnitsId() {};
	
	public IpayBusinessUnitsId (String pBuType, String pBuCode) {
		mBuType=pBuType;
		mBuCode=pBuCode;
	}
	
	/**											
	 * @return Returns the buType.													
	 */											
	public String getBuType() {
		return mBuType;
	}
	/**
	 * @param pBuType The buType to set.
	 */
	public void setBuType(String pBuType) {
		mBuType = pBuType;
	}

	/**											
	 * @return Returns the buCode.													
	 */											
	public String getBuCode() {
		return mBuCode;
	}
	/**
	 * @param pBuCode The buCode to set.
	 */
	public void setBuCode(String pBuCode) {
		mBuCode = pBuCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mBuCode == null) ? 0 : mBuCode.hashCode());
		result = prime * result + ((mBuType == null) ? 0 : mBuType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IpayBusinessUnitsId other = (IpayBusinessUnitsId) obj;
		if (mBuCode == null) {
			if (other.mBuCode != null)
				return false;
		} else if (!mBuCode.equals(other.mBuCode))
			return false;
		if (mBuType == null) {
			if (other.mBuType != null)
				return false;
		} else if (!mBuType.equals(other.mBuType))
			return false;
		return true;
	}
	


	

}
