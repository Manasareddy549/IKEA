package com.ikea.ebccardpay1.cardpayment.bef;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.CnCard;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;

public class BefCnCardImpl extends BefAbstract<CnCard> implements BefCnCard{
	private static final Logger mLog = LoggerFactory
			.getLogger(BefCnCardImpl.class);

	protected BefCnCardImpl(SessionFactory pSessionFactory, TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Class<CnCard> getBusinessEntityClass() {
		// TODO Auto-generated method stub
		return CnCard.class;
	}

	@Override
	public void registerTheCards(long cnJobId) {
		// TODO Auto-generated method stub

		Session vSession = mSessionFactory.getCurrentSession();

		GenericCriteria<CnCard> vCriteria = new GenericCriteria<CnCard>(vSession.createCriteria(CnCard.class));

		vCriteria.add(Restrictions.eq("cnBatchJobId", cnJobId));

		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<CnCard> vList = vCriteria.list();

		if(vList!=null)
		{
			if(vList.size()>0)
			{
				mLog.debug("Found "+Integer.toString(vList.size())+" Transactions");
				for(CnCard mCnCard:vList)
				{
					mCnCard.setRegistered("Y");
					update(mCnCard);
				}
				mLog.debug("Transactions Updated");				
			}
			else{
				mLog.debug("Found Zero Transactions");
			}
		}
		else{
			mLog.debug("Found Zero Transactions");
		}
	}
	
}
