/*
 * Created on 2006-maj-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.bef;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Range;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.GenericCriteria;
import com.ikea.ebccardpay1.cardpayment.utils.GenericQuery;
import com.ikea.common.TimeSource;

/**
 * @author anms
 * @author tpon
 *
 */
public class BefCardNumberImpl extends BefAbstract<CardNumber> implements BefCardNumber {

	private final static Logger mLog_findByCardNumber =
		LoggerFactory.getLogger(
			BefCardNumberImpl.class.getName() + ".findByCardNumber");

	private final static Logger mLog_findByRange =
		LoggerFactory.getLogger(
			BefCardNumberImpl.class.getName() + ".findByRange");

	private final static Logger mLog_findByRangeId =
		LoggerFactory.getLogger(
			BefCardNumberImpl.class.getName() + ".findByRangeId");
	

	/**
	 * Dependency injection
	 * 
	 * @param pSessionFactory
	 * @param pTimeSource
	 */
	public BefCardNumberImpl(
		SessionFactory pSessionFactory,
		TimeSource pTimeSource) {
		super(pSessionFactory, pTimeSource);
	}
	
	

	/* (non-Javadoc)
	 * @see com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber#findCardNumber(java.lang.String, int, java.lang.String, int)
	 */
	public CardNumber findByCardNumber(
		String pIssuer,
		int pCardTypeDigit,
		int pCheckDigit,
		String pEncAccounNumber) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		Criteria vCriteria = vSession.createCriteria(CardNumber.class);
		vCriteria.add(Restrictions.eq("issuer", pIssuer));
		vCriteria.add(
				Restrictions.eq("cardTypeDigit", new Integer(pCardTypeDigit)));
		vCriteria.add(Restrictions.disjunction()
				.add(Restrictions.eq("accountNumberEnc", pEncAccounNumber)));
				//.add(Restrictions.eq("accountNumber", pAccountNumber)));
		/*if(findCardEncrypted(pIssuer,pCardTypeDigit,pAccountNumber,pCheckDigit,vSession)) {
			vCriteria.add(Restrictions.eq("accountNumberEnc", pEncAccounNumber));
		}
		else {
			vCriteria.add(Restrictions.eq("accountNumber", pAccountNumber));
		}*/
		vCriteria.add(Restrictions.eq("checkDigit", new Integer(pCheckDigit)));

		if (mLog_findByCardNumber.isDebugEnabled()) {
			mLog_findByCardNumber.debug(
				"Criteria: " + vCriteria.toString());
		}
		CardNumber vCardNumber = null;
try{
		 vCardNumber = (CardNumber) vCriteria.uniqueResult();
		 
}catch(Exception e ){
	
	mLog_findByCardNumber.info(e.getMessage());
}
		if (vCardNumber == null) {
			mLog_findByCardNumber.info("No card number found.");
		}
		return vCardNumber;
	}
	
	public boolean findCardEncrypted(
			String pIssuer,
			int pCardTypeDigit,
			String pAccountNumber,
			int pCheckDigit) {
		
		boolean encrypted = true;
		
		Session vSession = mSessionFactory.getCurrentSession();

		String vHql = "from CardNumber where issuer = :issuer and cardTypeDigit = :cardTypeDigit and accountNumber = :accountNumber and checkDigit = :checkDigit";
		
		CardNumber vCardNumber = (CardNumber)(vSession.createQuery(vHql).setParameter("issuer", pIssuer).setParameter("cardTypeDigit", pCardTypeDigit).setParameter("accountNumber", pAccountNumber).setParameter("checkDigit", pCheckDigit).uniqueResult());
	    
		if (vCardNumber != null) {
		if (vCardNumber.getAccountNumberEnc()==null) {
	    	  encrypted = false;
	    }
		}
		return encrypted;
		
	}

	public List<CardNumber> findByRangeId(long pRangeId) {

		Session vSession = mSessionFactory.getCurrentSession();

		// Use criteria to get the joins declared in the mapping files.
		GenericCriteria<CardNumber> vCriteria = new GenericCriteria<CardNumber>( vSession.createCriteria(CardNumber.class, "alias"));

		vCriteria.createCriteria("ranges").add(
			Restrictions.idEq(new Long(pRangeId)));

		if (mLog_findByRangeId.isDebugEnabled()) {
			mLog_findByRangeId.debug("Criteria: " + vCriteria.toString());
		}

		// To get just one per campaign
		vCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<CardNumber> vList = vCriteria.list();

		if (vList == null || vList.size() == 0) {
			mLog_findByRangeId.info(
				"No card numbers found in range with id " + pRangeId + ".");
		} else {
			mLog_findByRangeId.info(
				"Found "
					+ vList.size()
					+ " card numbers in range with id "
					+ pRangeId
					+ ".");
		}
		return vList;
	}
	
	public List<BigDecimal> findByRange(Collection<Range> pRanges,
			long pCurrentCardNumberId, int pMaxResultCount) {

		Collection<Long> vRangeIds = new ArrayList<Long>();

		for (Range vRange : pRanges) {
			vRangeIds.add(new Long(vRange.getRangeId()));	
		}

		Session vSession = mSessionFactory.getCurrentSession();

		String vSql =
			"select CARD_NUMBER_ID from CARD_NUMBER_RANGE_T "
				+ "where RANGE_ID in (:rangeIds) "
				+ "and CARD_NUMBER_ID >= :currentCardNumberId "
				+ "group by CARD_NUMBER_ID "
				+ "order by CARD_NUMBER_ID ";

		if (mLog_findByRange.isDebugEnabled()) {
			mLog_findByRange.debug("SQL: " + vSql);
			mLog_findByRange.debug(
				"Params: range id "
					+ vRangeIds
					+ " current card number "
					+ pCurrentCardNumberId);
		}

		GenericQuery<BigDecimal> query = new GenericQuery<BigDecimal>(vSession
				.createSQLQuery(vSql)
				.setParameterList("rangeIds", vRangeIds)
				.setLong("currentCardNumberId", pCurrentCardNumberId));

		if (pMaxResultCount > 0)
			query.setMaxResults(pMaxResultCount);
		
		List<BigDecimal> vList = query.list();

		if (vList == null || vList.size() == 0) {
			mLog_findByRange.info(
				"No card numbers found in range with id " + vRangeIds + ".");
		} else {
			mLog_findByRange.info(
				"Found "
					+ vList.size()
					+ " card numbers in range with id "
					+ vRangeIds
					+ ".");
		}
		return vList;
	}

	@Override
	protected Class<CardNumber> getBusinessEntityClass() {
		return CardNumber.class;
	}
	
	
	//Added by Bisweswar
	public List<BigDecimal> findByCardNumberId(long pCradNumberId){
		
		Session vSession = mSessionFactory.getCurrentSession();
		
		String vSql =
			"select RANGE_ID from CARD_NUMBER_RANGE_T "
			+ "where CARD_NUMBER_ID = :currentCardNumberId ";
		
		
		if (mLog_findByRange.isDebugEnabled()) {
			mLog_findByRange.debug("SQL: " + vSql);
			mLog_findByRange.debug(				
					" current card number "
					+ pCradNumberId);
		}
		
		GenericQuery<BigDecimal> query = new GenericQuery<BigDecimal>(vSession
				.createSQLQuery(vSql)
				.setLong("currentCardNumberId", pCradNumberId));
		
		
		List<BigDecimal> vList = query.list();

		if (vList == null || vList.size() == 0) {
			mLog_findByRange.info(
				"No range ids found  with card number id " + pCradNumberId + ".");
		} else {
			mLog_findByRange.info(
				"Found "
					+ vList.size()
					+ " ranges with cardnumber id "
					+ pCradNumberId
					+ ".");
		}
		return vList;
		
	}
}
