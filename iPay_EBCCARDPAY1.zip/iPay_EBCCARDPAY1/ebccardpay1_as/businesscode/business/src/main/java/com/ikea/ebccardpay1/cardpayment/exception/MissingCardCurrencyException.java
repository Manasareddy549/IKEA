/*
 * Created on 2007-okt-11
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author dalq
 *
 *
 */
public class MissingCardCurrencyException extends CurrencyException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2068212237474649947L;

	/**
	 * 
	 */
	public MissingCardCurrencyException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public MissingCardCurrencyException(String pMessage) {
		super(pMessage);

	}

}
