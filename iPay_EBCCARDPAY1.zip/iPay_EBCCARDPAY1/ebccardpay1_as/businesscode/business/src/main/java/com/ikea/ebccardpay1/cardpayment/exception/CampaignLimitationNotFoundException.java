/*
 * Created on 2007-apr-02
 *
 */
package com.ikea.ebccardpay1.cardpayment.exception;

/**
 * @author anms
 *
 */
public class CampaignLimitationNotFoundException extends CampaignException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8553898013863135102L;

	/**
	 * 
	 */
	public CampaignLimitationNotFoundException() {
		super();
	}

	/**
	 * @param pMessage
	 */
	public CampaignLimitationNotFoundException(String pMessage) {
		super(pMessage);
	}

}
