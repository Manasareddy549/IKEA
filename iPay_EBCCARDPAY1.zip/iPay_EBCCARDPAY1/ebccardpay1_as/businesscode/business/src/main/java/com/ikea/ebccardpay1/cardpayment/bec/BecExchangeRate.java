/*
 * Created on 2007-aug-28
 *
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;


/**
 * @author dalq
 *
 *
 */
public interface BecExchangeRate {

	/**
	 * @param mVoCountry
	 */
	public void init(VoCountry mVoCountry);

	/**
	 * 
	 * @param pVoExchangeRates
	 * @throws ValueMissingException
	 */
	public void manage(VoExchangeRate pVoExchangeRate)
		throws
			ValueMissingException,
			InvalidFromDateException,
			InvalidFromCurrencyException,
			InvalidToCurrencyException;

	/**
	 * @return
	 */
	public VoExchangeRate getVoExchangeRate()throws ValueMissingException;

}
