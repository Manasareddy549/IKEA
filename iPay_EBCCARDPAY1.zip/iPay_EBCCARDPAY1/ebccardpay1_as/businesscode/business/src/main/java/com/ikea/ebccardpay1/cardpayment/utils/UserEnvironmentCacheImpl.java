package com.ikea.ebccardpay1.cardpayment.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.cache.IncrementalCache;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.spring.BeanFactory;
import com.ikea.eicywp01.client.bs.BsGetPerson;
import com.ikea.eicywp01.client.bs.BsGetSystemUser;
import com.ikea.eicywp01.client.vo.VoPersonDetail;
import com.ikea.eicywp01.client.vo.VoPersonKey;
import com.ikea.eicywp01.client.vo.VoPrivs;
import com.ikea.eicywp01.client.vo.VoRoles;
import com.ikea.eicywp01.client.vo.VoSystemUser;
import com.ikea.eicywp01.client.vo.VoSystemUserFindCriteria;

/**
 * 
 * @author Henrik Reinhold
 *
 */
public class UserEnvironmentCacheImpl extends IncrementalCache implements
UserEnvironmentCache {

	private final static Logger mLog = LoggerFactory.getLogger(UserEnvironmentCacheImpl.class);
    
	/**
	 * Gets the instance of this cache (only one subset).
	 * @return a cache for information
	 */
	public static UserEnvironmentCacheImpl getInstance() {
		return (UserEnvironmentCacheImpl) getCache(
				UserEnvironmentCacheImpl.class.getName(),
				null);
	}


	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	void setBefIpayBusinessUnits(BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefIpayBusinessUnits = pBefIpayBusinessUnits;
	}

	public UserEnvironment fetch(String pUserId) {
		try {

			return (UserEnvironment) fetchObject(pUserId);

		} catch (Exception e) {
			mLog.error("Error fetching user '" + pUserId
					+ "' from UserEnvironmentCache");
			return null;
		}
	}

	@Override
	protected Object fetchSingle(String pUserId) throws Exception {
		VoPersonDetail vVoPersonDetail = retrievePersonDetailFromCds(pUserId);
		VoBusinessUnit vVoBusinessUnit = null;
		Set<String> vPrivileges = null;
		if(vVoPersonDetail!=null){
			vPrivileges = resolvePrivileges(vVoPersonDetail);
			vVoBusinessUnit = resolveBusinessUnit(vVoPersonDetail);
		} else {
			VoSystemUser vVoSystemUser = retrieveSystemUserDetailFromCds(pUserId);
			vPrivileges = resolvePrivileges(vVoSystemUser);			
		}
		return new UserEnvironment(pUserId, vVoBusinessUnit, vPrivileges);
	}

	@Override
	protected Object newObject(String pArg0, ByteArrayInputStream pArg1)
	throws IOException {
		return null;
	}

	@Override
	protected void objectToBytes(Object pArg0, ByteArrayOutputStream pArg1)
	throws IOException {
	}

	protected VoPersonDetail retrievePersonDetailFromCds(String pUserId)
	throws IkeaException {
		// Create person key VO
		VoPersonKey vVoPersonKey = new VoPersonKey();
		vVoPersonKey.setUid(pUserId);

		// Create service
		BsGetPerson vBsGetPerson = new BsGetPerson();

		// Set input VO
		vBsGetPerson.setVoPersonKey(vVoPersonKey);

		// Execute service
		mLog.debug("Calling EICYWP for Person user");
		BsExecuter bsExecuter = BeanFactory.getBsExecuter();
		bsExecuter.executeBs(vBsGetPerson);
		mLog.debug("Returned from EICYWP");

		if (vBsGetPerson.getVoPersonDetail() == null) {
			/*throw new IkeaException("The user " + pUserId
					+ " does not have an entry in CDS.");*/
			mLog.debug("The user " + pUserId
					+ " does not have an entry in CDS.");
			return null;
		}
		return vBsGetPerson.getVoPersonDetail();
	}

	@SuppressWarnings("unchecked")
	private Set<String> resolvePrivileges(VoPersonDetail pPersonDetail) {

		Set<String> vPrivileges = new HashSet<String>();

		for(VoRoles vVoRoles : pPersonDetail.getVoRolesList()){

			mLog.debug("Role " + vVoRoles.getRoleName());
			List<VoPrivs> vVoPrivsList = vVoRoles.getVoPrivsList();

			if (vVoPrivsList != null) {
				for(VoPrivs vVoPrivs :vVoPrivsList){
					mLog.debug("Priv " + vVoPrivs.getRealmPrivName());
					vPrivileges.add(vVoPrivs.getRealmPrivName());
				}
			} else {
				mLog.debug("No privs for this role ");
			}
		}
		return vPrivileges;
	}
	
	protected VoSystemUser retrieveSystemUserDetailFromCds(String pUserId)
	throws IkeaException {
		// Create SystemUserFindCriteria VO
		VoSystemUserFindCriteria vVoSystemUserFindCriteria = new VoSystemUserFindCriteria();
		vVoSystemUserFindCriteria.setUid(pUserId);

		// Create service
		BsGetSystemUser vBsGetSystemUser = new BsGetSystemUser();

		// Set input VO
		vBsGetSystemUser.setVoSystemUserFindCriteria(vVoSystemUserFindCriteria);

		// Execute service
		mLog.debug("Calling EICYWP for System User");
		BsExecuter bsExecuter = BeanFactory.getBsExecuter();
		bsExecuter.executeBs(vBsGetSystemUser);
		mLog.debug("Returned from EICYWP");
		
		if (vBsGetSystemUser.getVoSystemUser() == null) {
			throw new IkeaException("The user " + pUserId
					+ " does not have an entry in CDS.");
		}

		return vBsGetSystemUser.getVoSystemUser();
	}

	@SuppressWarnings("unchecked")
	private Set<String> resolvePrivileges(VoSystemUser pSystemUser) {

		Set<String> vPrivileges = new HashSet<String>();

		for(VoRoles vVoRoles : pSystemUser.getVoRolesList()){

			mLog.debug("Role " + vVoRoles.getRoleName());
			List<VoPrivs> vVoPrivsList = vVoRoles.getVoPrivsList();

			if (vVoPrivsList != null) {
				for(VoPrivs vVoPrivs :vVoPrivsList){
					mLog.debug("Priv " + vVoPrivs.getRealmPrivName());
					vPrivileges.add(vVoPrivs.getRealmPrivName());
				}
			} else {
				mLog.debug("No privs for this role ");
			}
		}
		return vPrivileges;
	}


	private VoBusinessUnit resolveBusinessUnit(VoPersonDetail pPersonDetail) {
		// Create business unit VO
		VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
		vVoBusinessUnit.setBuType("STO");

		// Get country and BU for the user in CDS
		vVoBusinessUnit.setCountryCode(pPersonDetail.getCountryCode());

		if (pPersonDetail.getVoSite() != null) {
			vVoBusinessUnit
			.setSiteName(pPersonDetail.getVoSite().getSiteName());

		} else {
			mLog.info("User " + pPersonDetail.getUid()
					+ " does not have a site in CDS/IKEA People.");
		}

		if (pPersonDetail.getVoBusinessUnit() != null) {
			mLog.debug("BuCode of the User in cds: "+pPersonDetail.getVoBusinessUnit().getBusinessUnitCode());
			mLog.debug("BuType of the User in cds: "+pPersonDetail.getVoBusinessUnit().getBusinessUnitType());
			vVoBusinessUnit.setBuType(pPersonDetail.getVoBusinessUnit()
					.getBusinessUnitType());

			vVoBusinessUnit.setBuCode(pPersonDetail.getVoBusinessUnit()
					.getBusinessUnitCode());			

		} else {
			mLog.info("User " + pPersonDetail.getUid()
					+ " does not have a Business Unit set in CDS/IKEA People.");
		}

		//Get company data from database

		try{
			if ((vVoBusinessUnit.getBuType() != null) && (vVoBusinessUnit.getBuType().length() != 0 )&& (vVoBusinessUnit.getBuCode() != null )&& (vVoBusinessUnit.getBuCode().length() != 0))
			{
				mLog.debug("BuType of the User in Vo: "+vVoBusinessUnit.getBuType());
				mLog.debug("BuCode of the User in Vo: "+vVoBusinessUnit.getBuCode());

				IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(vVoBusinessUnit.getBuType(), vVoBusinessUnit.getBuCode());
				if(vIpayBusinessUnits!=null){	
					vVoBusinessUnit.setCompanyCode(vIpayBusinessUnits.getCompanyCode());
					vVoBusinessUnit.setCompanyName(vIpayBusinessUnits.getCompanyName());
				}

			}else {
				mLog.info("User " + pPersonDetail.getUid()
						+ " does not have BuCode and BuType set in CDS/IKEA People.");

			}
			//return vVoBusinessUnit;

		}catch (Exception e) {
			mLog.error("Error fetching Company Information from Database");
		}
		return vVoBusinessUnit;

	}
}
