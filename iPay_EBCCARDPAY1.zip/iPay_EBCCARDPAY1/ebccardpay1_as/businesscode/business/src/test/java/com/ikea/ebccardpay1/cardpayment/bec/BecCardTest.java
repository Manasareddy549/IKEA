/*
 * Created on 2006-maj-12
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.LifeCycle;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefLifeCycle;
import com.ikea.ebccardpay1.cardpayment.bef.BefReservedCardHistory;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.exception.*;
import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.cardpayment.vo.*;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import junit.framework.Assert;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.*;

/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class BecCardTest extends EbcCardPay1TestSetup {

  // Mock card BEF
  @Mock
  public BefCard mBefCardMock;
  // Mock life cycle BEF
  @Mock
  public BefLifeCycle mBefLifeCycleMock;
  // Mock card type constant
  @Mock
  public Constants mConstantsMock;
  //Mock Encryption decryption
  @Mock
  public EncryptionDecryption mEncryptionDecryptionMock;
  // Mock environment class
  @Mock
  public EbcEnvironment mEnvironmentMock;
  // Mock bec factory
  @Mock
  public BecFactory mBecFactoryMock;
  // Mock card number BEC
  @Mock
  public BecCardNumber mBecCardNumberMock;
  // Mock card number BEC
  @Mock
  public BecAmounts mBecAmountsMock;
  // Mock reference check BEC
  @Mock
  public BecReferenceCheck mBecReferenceCheckMock;
  @Mock
  public BusinessUnitEnvironment mBusinessUnitEnvironmentMock;
  @Mock
  public TransactionEnvironment mTransactionEnvironmentMock;
  @Mock
  public BecExternalCard mBecExternalCardMock;
  @Mock
  public UtilsFactory vUtilsFactoryMock;
  
  public BefTransaction mBefTransaction;
  public BefReservedCardHistory mBefReservedCardHistory; 

  private BecCardImpl createBecCardImpl() {
    return new BecCardImpl(mBecFactoryMock, null, mBefCardMock, mBefLifeCycleMock, null, null, mUnitTestTimeSource,
            mConstantsMock,mBefTransaction,null,null,null,mBefReservedCardHistory);
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_bindCard_wrongState() throws Exception {
    // --- Set up for test ---

    // Set up values
    Card vCard = new Card();
    vCard.setCardState("Not a valid state");
    new VoSourceSystem();
    new VoBusinessUnit();

    // Expect

    // --- Run test ---
    replayAll();

    BecCardImpl vBec = createBecCardImpl();
    vBec.init(mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);
    vBec.setCard(vCard);
    try {
      vBec.bindCard("SEK", "SE");
      fail("Should throw exception.");
    } catch(Exception e) {
      assertEquals(IllegalCardStateException.class, e.getClass());
    }

    // --- Assert and verify the result ---
    verifyAll();
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_addCardTypes() throws Exception {
    // Set up values
    Card vCard = new Card();
    CardNumber vCardNumber = new CardNumber();
    vCardNumber.connectCard(vCard);
    vCardNumber.setCardTypeDigit(42);

    // Expect
    expect(mConstantsMock.getCardType(vCardNumber.getCardTypeDigit())).andThrow(new CardTypeDigitNotFoundException());

    // --- Run test ---
    replayAll();

    BecCardImpl vBec = createBecCardImpl();
    vBec.setCard(vCard);
    try {
      vBec.setCardTypeFromCardNumber();
      fail("Should throw exception.");
    } catch(Exception e) {
      assertEquals(InvalidCardTypeDigitException.class, e.getClass());
    }

    // --- Assert and verify the result ---
    verifyAll();
  }

  /**
   * @throws Exception
   */
  private void subtest_mapLifeCycleType(String pState, String pType) throws Exception {

    BecCardImpl vBec = createBecCardImpl();
    String vActualType = vBec.mapLifeCycleType(pState);
    assertEquals(pType, vActualType);
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_mapLifeCycleType() throws Exception {
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_ACTIVE, Constants.LIFE_CYCLE_TYPE_CONSTANT_ACTIVATED);
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_ARCHIVED, Constants.LIFE_CYCLE_TYPE_CONSTANT_ARCHIVED);
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_BLOCKED, Constants.LIFE_CYCLE_TYPE_CONSTANT_BLOCKED);
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_BOUND, Constants.LIFE_CYCLE_TYPE_CONSTANT_TRANSACTION);
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_EXPIRED, Constants.LIFE_CYCLE_TYPE_CONSTANT_EXPIRED);
    subtest_mapLifeCycleType(Constants.CARD_STATE_CONSTANT_INACTIVE, null);

    try {
      subtest_mapLifeCycleType("an invalid state", null);
      fail("subtest_mapLifeCycleType should throw exception for an invalid state.");
    } catch(Exception e) {
      assertEquals(IllegalArgumentException.class, e.getClass());
    }
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_changeCardState() throws Exception {

    // Expect
    Card vCard = new Card();
    String vPrevState = null;
    String vCardStateConstant = "any state";
    final String vLifeCycleType = "any type";
    VoSourceSystem vVoSourceSystem = new VoSourceSystem();
    vVoSourceSystem.setSourceSystem("any source");
    VoBusinessUnit vVoBusinessUnit = new VoBusinessUnit();
    vVoBusinessUnit.setBuCode("xxx");
    vVoBusinessUnit.setBuType("STO");

    LifeCycle vExpectedLifeCycle = new LifeCycle();
    expect(mBefLifeCycleMock.create()).andReturn(vExpectedLifeCycle);
    mBefLifeCycleMock.save(vExpectedLifeCycle);

    expect(mTransactionEnvironmentMock.getSourceSystem()).andReturn("any source").times(2);
    expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
    expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("xxx");
    expect(mConstantsMock.isPointOfSale(vVoSourceSystem.getSourceSystem())).andReturn(false);

    // --- Run test ---
    replayAll();
    BecCardImpl vBec = new BecCardImpl(mBecFactoryMock, null, mBefCardMock, mBefLifeCycleMock, null, null,
            mUnitTestTimeSource, mConstantsMock,mBefTransaction,null,null,null,mBefReservedCardHistory) {
      protected String mapLifeCycleType(String pCardStateConstant) throws IllegalArgumentException {
        return vLifeCycleType;
      }
    };
    vBec.setCard(vCard);
    vBec.init(mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);
    vBec.changeCardState(vCardStateConstant, "");
    Card vActualOuput = vBec.getCard();

    // --- Assert and verify the result ---
    verifyAll();

    assertEquals("card state,", vCardStateConstant, vActualOuput.getCardState());
    assertEquals("last operation date on card,", mUnitTestTimeSource.currentDate(),
            vActualOuput.getLastLifeCycleDateTime());
    assertEquals("last transaction date on card,", null, vActualOuput.getLastTransactionDateTime());
    // Theire shall not be any life cycle objects connected to the POJO, but
    // in the databse thier will be
    // We do not want to read in the hole set of life cycles just to create
    // one new.
    assertEquals("number of life cycles,", 1, vActualOuput.getLifeCycles().size());
    LifeCycle vActualLifeCycle = vExpectedLifeCycle;

    assertEquals(vLifeCycleType, vActualLifeCycle.getLifeCycleType());
    assertEquals(vPrevState, vActualLifeCycle.getPrevState());
    assertEquals(vCardStateConstant, vActualLifeCycle.getNextState());
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_createCard() throws Exception {

    // Set up values
    VoSourceSystem vVoSourceSystem = new VoSourceSystem();
    vVoSourceSystem.setSourceSystem("any");
    new VoBusinessUnit();
    final Card vCard = new Card();

    LifeCycle vLifeCycle = new LifeCycle();
    vLifeCycle.setCreatedDateTime(new Date());

    String vCardNumberInput = "Anything";
    final CardNumber vCardNumber = new CardNumber();

    // Expect
    expect(mBefLifeCycleMock.create()).andReturn(vLifeCycle);
    expect(mBefCardMock.create()).andReturn(vCard);

    mBefCardMock.save(vCard);

    expect(mBecFactoryMock.createBecAmounts()).andReturn(mBecAmountsMock);
    expect(mBecAmountsMock.init(vCard, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock)).andReturn
            (mBecAmountsMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
    expect(mBecReferenceCheckMock.init(vCard, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock)).
            andReturn(mBecReferenceCheckMock);
    String vCardType = "any type";
    expect(mConstantsMock.getCardType(0)).andReturn(vCardType);
    expect(mTransactionEnvironmentMock.getSourceSystem()).andReturn("any source");
    expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
    expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("xxx");

    // --- Run test ---
    replayAll();
    BecCard vBec = new BecCardImpl(mBecFactoryMock, null, mBefCardMock, mBefLifeCycleMock, null, null,
            mUnitTestTimeSource, mConstantsMock,mBefTransaction,null,null,null, mBefReservedCardHistory) {
      protected void findOrCreateCardNumber(String pCardNumberString) throws InvalidCardNumberException,
              DuplicateCardException {
        vCardNumber.connectCard(vCard);
      }
    };
    vBec.init(mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);
    vBec.createCard(vCardNumberInput);
    Card vActualOuput = vBec.getCard();

    // --- Assert and verify the result ---
    verifyAll();

    // Check card
    assertEquals("card number object,", vCardNumber, vActualOuput.getCardNumber());
    assertEquals("card object", vCard, vActualOuput);
    assertEquals("card state,", Constants.CARD_STATE_CONSTANT_ACTIVE, vActualOuput.getCardState());
    assertEquals("card last operation date,", vLifeCycle.getCreatedDateTime(), vActualOuput.getLastLifeCycleDateTime());
    assertEquals("card last transaction date,", null, vActualOuput.getLastTransactionDateTime());

    // Check card type
    assertEquals("card type,", vCardType, vActualOuput.getCardType());

    // Check life cycle object(s)
    assertEquals("number of life cycle objects,", 1, vActualOuput.getLifeCycles().size());
    LifeCycle vActualLifeCycle = (LifeCycle) vActualOuput.getLifeCycles().iterator().next();

    assertEquals("life cycle type,", Constants.LIFE_CYCLE_TYPE_CONSTANT_ACTIVATED, vActualLifeCycle.getLifeCycleType());
    assertEquals("life cycle prev card state,", null, vActualLifeCycle.getPrevState());
    assertEquals("life cycle next card state,", Constants.CARD_STATE_CONSTANT_ACTIVE, vActualLifeCycle.getNextState());
  }

  /**
   * Test if an amount is valid at a certain date
   *
   * @throws Exception
   */
  /*
	 * final public void testIsValid() throws Exception { // --- Set up mock
	 * behaviour --- // Boot Mock Java Framework MockEbcControl vMockEbcControl =
	 * MockEbcControlFactory.createControl(EBC_NAME, BS_NAME); // --- Run the
	 * test --- // Replay Mocks and MockEbcControl vMockEbcControl.replay();
	 * MockUtils.replay(this);
	 * 
	 * Date vTestDate = DataTypeUtil.parseDate("2006-05-19T17:04:05Z");
	 * mUnitTestTimeSource.setCurrent(vTestDate);
	 * 
	 * runIsValid(null, null, true); runIsValid(vTestDate, vTestDate, true);
	 * runIsValid( DataTypeUtil.parseDate("2006-05-01T17:04:05Z"),
	 * DataTypeUtil.parseDate("2006-05-22T17:04:05Z"), true);
	 * 
	 * runIsValid(DataTypeUtil.parseDate("2006-05-01T17:04:05Z"), null, true);
	 * runIsValid(null, DataTypeUtil.parseDate("2006-05-22T17:04:05Z"), true);
	 * runIsValid(DataTypeUtil.parseDate("2006-05-22T17:04:05Z"), null, false);
	 * runIsValid(null, DataTypeUtil.parseDate("2006-05-01T17:04:05Z"), false);
	 * 
	 * runIsValid(vTestDate, null, true); runIsValid(null, vTestDate, true);
	 * 
	 * try {
	 * 
	 * runIsValid( DataTypeUtil.parseDate("2006-05-22T17:04:05Z"),
	 * DataTypeUtil.parseDate("2006-05-01T17:04:05Z"), false); fail("Should
	 * throw IllegalArgumentException, ValidFrom is after ValidUntil!"); } catch
	 * (Exception e) { assertEquals( "Should throw IllegalArgumentException,
	 * ValidFrom is after ValidUntil!", IllegalArgumentException.class,
	 * e.getClass()); } // Verify Mocks and MockEbcControl
	 * vMockEbcControl.verify(); MockUtils.verify(this); }
	 * 
	 * private void runIsValid( Date pValidFromDate, Date pValidUntilDate,
	 * boolean pIsValidResult) throws Exception {
	 * 
	 * Amount vAmount = new Amount(); vAmount.setValidFromDate(pValidFromDate);
	 * vAmount.setValidUntilDate(pValidUntilDate);
	 * 
	 * boolean vActualOuput = BecAmountsImpl.isActive(vAmount,
	 * mUnitTestTimeSource.currentDate()); // --- Assert and verify the result
	 * ---
	 * 
	 * assertEquals( "Wrong output from isValid. " + pValidFromDate + " <= " +
	 * mUnitTestTimeSource.currentDate() + " >= " + pValidUntilDate,
	 * pIsValidResult, vActualOuput); }
	 */

  /**
   * Test finding a card
   *
   * @throws Exception
   */
  @Test
  final public void testFindCard() throws Exception {

    // --- Set up mock behaviour ---

    // Read input values
    VoCardNumber vVoCardNumber = (VoCardNumber) loadProperties("BecCardTest_findCardInternal_input.properties",
            VoCardNumber.class);

    String vCardNumberStringInput = vVoCardNumber.getCardNumberString();
    // Expected should contian amounts and types too, but we have to wait
    // until we can load them from file together with the card info.

    Card vExpectedOuput = new Card();
    loadProperties("BecCardTest_findCardInternal_output.properties", vExpectedOuput);
    CardNumber vExpectedCardNumber = new CardNumber();
    vExpectedCardNumber.setCard(vExpectedOuput);

    mBecCardNumberMock.findCardNumber(vVoCardNumber.getCardNumberString());
    expect(mBecCardNumberMock.getCardNumber()).andReturn(vExpectedCardNumber);
    expect(mBecCardNumberMock.getCardNumber()).andReturn(vExpectedCardNumber);
    expect(mBecCardNumberMock.getCardNumber()).andReturn(vExpectedCardNumber);
    expect(mBecCardNumberMock.getCardNumber()).andReturn(vExpectedCardNumber);
    expect(mBecFactoryMock.createBecAmounts()).andReturn(mBecAmountsMock);
    expect(mBecFactoryMock.createBecAmounts()).andReturn(mBecAmountsMock);
    expect(mBecAmountsMock.init(vExpectedOuput, null, null)).andReturn(mBecAmountsMock);
    expect(mBecAmountsMock.init(vExpectedOuput, null, null)).andReturn(mBecAmountsMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
    expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
    expect(mBecReferenceCheckMock.init(vExpectedOuput, null, null)).andReturn(mBecReferenceCheckMock);
    expect(mBecReferenceCheckMock.init(vExpectedOuput, null, null)).andReturn(mBecReferenceCheckMock);

		/*
		 * Do not need this since transaction env is null!
		 * mBecReferenceCheckMock.cancelUnacknowledged();
		 * 
		 * String vSourceSystsem = "kalle";
		 * mTransactionEnvironmentControl.expectAndReturn(
		 * mTransactionEnvironmentMock.getSourceSystem(), vSourceSystsem);
		 * 
		 * mConstantsControl.expectAndReturn(
		 * mConstantsMock.isPointOfSale(vSourceSystsem), true);
		 */

    // --- Run the test ---
    // Replay Mocks and MockEbcControl
    replayAll();

    BecCardImpl vBec = createBecCardImpl();
    vBec.setCard(new Card());

    try {
      vBec.findCard(vCardNumberStringInput);
    } catch(CardNotFoundException e) {
      Assert.fail("Should NOT throw " + e);
    } catch(InvalidCardNumberException e) {
      Assert.fail("Should NOT throw " + e);
    }

    Card vActualOuput = vBec.getCard();

    // --- Assert and verify the result ---

    assertEquals("Result of find card not okey.", vExpectedOuput, vActualOuput);

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  /**
   * Test finding a card
   *
   * @throws Exception
   */
  @Test
  final public void testCalculateBalance() throws Exception {

    // --- Set up mock behaviour ---

    // Have to read all the entities one by one since
    // VoFactory.loadProperties only works for VOs.
    Card vCardInput = new Card();
    List<Amount> vList = new ArrayList<Amount>();

    // Need to have them sorted
    vCardInput.setAmounts(new LinkedHashSet<Amount>());
    CardNumber vCardNumberInput = new CardNumber();
    loadProperties("BecCardTest_calculateBalance_input_cardnumber.properties", vCardNumberInput);
    vCardInput.setCardNumber(vCardNumberInput);

    Amount vAmountInput = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount.properties", vAmountInput);
    vCardInput.getAmounts().add(vAmountInput);
    vList.add(vAmountInput);

    Amount vAmountInput2 = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount2.properties", vAmountInput2);
    vCardInput.getAmounts().add(vAmountInput2);
    vList.add(vAmountInput2);

    Amount vAmountInput3 = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount3.properties", vAmountInput3);
    vCardInput.getAmounts().add(vAmountInput3);
    vList.add(vAmountInput3);

//    VoCard vVoCardInput = (VoCard) loadProperties("BecCardTest_calculateBalance_input_vo.properties",
//            VoCard.class);
    List<VoCard> voCards = loadPropertiesToList("BecCardTest_calculateBalance_input_vo.properties", VoCard.class);
    final VoCard vVoCardInput = voCards.get(0);

    List<VoCard> voCards1 = loadPropertiesToList("BecCardTest_calculateBalance_output_vo.properties", VoCard.class);
    VoCard vExpectedOutput = voCards1.get(0);

    mUnitTestTimeSource.setCurrent(vExpectedOutput.getBalanceDateTime());

    expect(mBecAmountsMock.findActiveAmounts(vExpectedOutput.getBalanceDateTime(), null, "STO",
            "107")).andReturn(vList);
    expect(mBecFactoryMock.createBecAmounts()).andReturn(mBecAmountsMock);
    expect(mBecAmountsMock.init(vCardInput, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock)).andReturn
            (mBecAmountsMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
    expect(mBecReferenceCheckMock.init(vCardInput, mBusinessUnitEnvironmentMock,
            mTransactionEnvironmentMock)).andReturn(mBecReferenceCheckMock);
    expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
    expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("107");

    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();
    BecCardImpl vBec = new BecCardImpl(mBecFactoryMock, null, mBefCardMock, mBefLifeCycleMock, null, null,
            mUnitTestTimeSource, mConstantsMock,mBefTransaction,null,null,null, mBefReservedCardHistory) {
      protected VoCard createVoCard() {
        return vVoCardInput;
      }
    };

    vBec.init(mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);
    vBec.assignCard(vCardInput);
    VoCard vActualOuput = vBec.calculateBalance();

    // --- Assert and verify the result ---

    //assertEquals("Result of calculateBalance not okey.", vExpectedOutput, vActualOuput);

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  /**
   * Test finding a card
   *
   * @throws Exception
   */
  @Test
  final public void testCreateVo() throws Exception {

    // --- Set up mock behavior ---

    // Have to read all the entities one by one since
    // VoFactory.loadProperties only works for VOs.
    Card vCardInput = new Card();
    // Need to have them sorted
    vCardInput.setAmounts(new LinkedHashSet<Amount>());
    CardNumber vCardNumberInput = new CardNumber();
    loadProperties("BecCardTest_calculateBalance_input_cardnumber.properties", vCardNumberInput);
    vCardInput.setCardNumber(vCardNumberInput);

    Amount vAmountInput = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount.properties", vAmountInput);
    vCardInput.getAmounts().add(vAmountInput);

    Amount vAmountInput2 = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount2.properties", vAmountInput2);
    vCardInput.getAmounts().add(vAmountInput2);

    Amount vAmountInput3 = new Amount();
    loadProperties("BecCardTest_calculateBalance_input_amount3.properties", vAmountInput3);
    vCardInput.getAmounts().add(vAmountInput3);

    vCardInput.setCardType("GIFT");
    vCardInput.setCardState("ACTIVE");
    vCardInput.setCurrencyCode("SEK");

    VoCard vExpectedOutput = (VoCard) loadProperties("BecCardTest_createVo_output_vo.properties", VoCard.class);

    // Mock BEC call
    expect(mBecCardNumberMock.composeCardNumberString(vCardNumberInput)).
            andReturn(vExpectedOutput.getCardNumberString());

    mUnitTestTimeSource.setCurrent(vExpectedOutput.getBalanceDateTime());
    expect(mBecFactoryMock.createBecAmounts()).andReturn(mBecAmountsMock);
    expect(mBecAmountsMock.init(vCardInput, null, null)).andReturn(mBecAmountsMock);
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
    expect(mBecReferenceCheckMock.init(vCardInput, null, null)).andReturn(mBecReferenceCheckMock);

    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();

    BecCardImpl vBec = createBecCardImpl();

    vBec.assignCard(vCardInput);
    VoCard vActualOuput = vBec.createVoCard();

    // --- Assert and verify the result ---

    assertEquals("Result of createVo not okey.", vExpectedOutput, vActualOuput);

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  /**
   * Test
   *
   * @throws Exception
   */
  @Test
  final public void test_findCard_cardNotFound() throws Exception {
    // --- Set up mock behaviour ---

    String vCardNumberInput = "Anything";

//    UtilsFactorySingleton.setInstance(vUtilsFactoryMock);

    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    mBecCardNumberMock.findCardNumber(vCardNumberInput);
    expectLastCall().andThrow(new InvalidCardNumberException());
    expect(mBecFactoryMock.createBecExternalCard()).andReturn(mBecExternalCardMock);

    mBecExternalCardMock.findExternal(vCardNumberInput);
    expectLastCall().andThrow(new ExternalCardNotFoundException());
    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();

    BecCard vBec = new BecCardImpl(mBecFactoryMock, null, mBefCardMock, mBefLifeCycleMock, null, null,
            mUnitTestTimeSource, mConstantsMock,mBefTransaction,null,null,null, mBefReservedCardHistory) {
      protected boolean pointOfSaleContext() {
        return true;
      }
    };
    try {
      vBec.findCard(vCardNumberInput);
      fail("Should throw Exception.");
    } catch(Exception e) {
      assertEquals("Should throw InvalidCardNumberException.", InvalidCardNumberException.class, e.getClass());
    }
    Card vActualOuput = vBec.getCard();

    // --- Assert and verify the result ---

    assertEquals("Result of findCard not okey.", null, vActualOuput);

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  @Test
  public void testCheckVerificationCode_ThrowInvalidVerificationCode() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("1111");
    underTest.init(cardNumber);
    try {
      underTest.checkVerificationCode("6789", "CALYPSO");
      fail();
    } catch(Exception e) {
      assertTrue(e instanceof com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode);
    }

  }

  @Test
  public void testCheckVerificationCode_ThrowInvalidVerificationCode_EmptyStringIn() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("1111");
    underTest.init(cardNumber);
    try {
      underTest.checkVerificationCode("", "CALYPSO");
      fail();
    } catch(Exception e) {
      assertTrue(e instanceof com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode);
    }

  }

  @Test
  public void testCheckVerificationCode_ThrowInvalidVerificationCode_NullIn() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("1111");
    underTest.init(cardNumber);
    try {
      underTest.checkVerificationCode(null, "CALYPSO");
      fail();
    } catch(Exception e) {
      assertTrue(e instanceof com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode);
    }
  }

  @Test
  public void testIRWCheckVerificationCode_ThrowInvalidVerificationCode_NullIn() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("1111");
    underTest.init(cardNumber);
    try {
      underTest.checkVerificationCode(null, "IRW");
      fail();
    } catch(Exception e) {
      assertTrue(e instanceof com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode);
    }
  }

  @Test
  public void testIRWCheckVerificationCode_ThrowInvalidVerificationCode_EmptyStringIn() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("1111");
    underTest.init(cardNumber);
    try {
      underTest.checkVerificationCode("", "IRW");
      fail();
    } catch(Exception e) {
      assertTrue(e instanceof com.ikea.ebccardpay1.cardpayment.exception.InvalidVerificationCode);
    }
  }

  @Test
  public void testCheckVerificationCode_OkWithCode() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "IPAY");
  }

  @Test
  public void testIRWCheckVerificationCode_OkWithCode() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {

      protected void assignCard(Card pcard) {
        Card card = new Card();
        card.setCardType("GIFT");
        setCard(card);
      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "IRW");

  }

  @Test
  public void testCheckVerificationCode_OkNoCode1() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc(null);
    underTest.checkVerificationCode("", "CALYPSO");
  }

  @Test
  public void testCheckVerificationCode_OkNoCode2() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("", "4690");
  }

  @Test
  public void testCheckVerificationCode_OkNoCode3() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "STOREPOINT");
  }

  @Test
  public void testCheckVerificationCode_OkNoCode4() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "TPNET");
  }

  @Test
  public void testCheckVerificationCode_OkEmptyStringInCardNumber() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "CALYPSO");
  }

  @Test
  public void testCheckVerificationCode_OkNullInCardNumber() throws Exception {
    BecCard underTest = new BecCardImpl(null, null, null, null, null, null, null, null,null,null,null,null,null) {
      protected void assignCard(Card card) {

      }
    };
    CardNumber cardNumber = new CardNumber();
    cardNumber.setCardNumberId(43217978219L);
    cardNumber.setVerificationCodeEnc("6789");
    underTest.init(cardNumber);
    underTest.checkVerificationCode("6789", "CALYPSO");
  }
}
