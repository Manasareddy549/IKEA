package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.ExchangeRateSpread;
import com.ikea.ebccardpay1.cardpayment.bef.BefExchangeRateSpread;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import org.hibernate.Session;

public class BecExchangeRatesImplTest {

	@Test
	public void testAddSpreadToRate() throws Exception {
		BecExchangeRatesImpl underTest = new BecExchangeRatesImpl(null, null, null, new BefExchangeRateSpread() {

			public ExchangeRateSpread findCurrent() {
				ExchangeRateSpread exchangeRateSpread = new ExchangeRateSpread();
				exchangeRateSpread.setExchangeRateSpread(new BigDecimal("0.03"));
				return exchangeRateSpread;
			}

			public ExchangeRateSpread create() {
				// TODO Auto-generated method stub
				return null;
			}

			public void delete(ExchangeRateSpread entity) {
				// TODO Auto-generated method stub

			}

			public List<ExchangeRateSpread> findAll() {
				// TODO Auto-generated method stub
				return null;
			}

			public ExchangeRateSpread findByPrimaryKey(long id) {
				// TODO Auto-generated method stub
				return null;
			}

			public void save(ExchangeRateSpread entity) {
				// TODO Auto-generated method stub

			}

			// @Override
			public void saveOrUpdate(ExchangeRateSpread entity) {
				// TODO Auto-generated method stub

			}

			//@Override
			public void update(ExchangeRateSpread entity) {
				// TODO Auto-generated method stub

			}

			//@Override
			public Session getOpenSession() {
				// TODO Auto-generated method stub
				return null;
			}

			//@Override
			public Session getCurrentSession() {
				// TODO Auto-generated method stub
				return null;
			}

			//@Override
			public void merge(ExchangeRateSpread entity) {
				// TODO Auto-generated method stub

			}

		}, null, null
				);


		BigDecimal rateWithAddedSpread = underTest.getRateWithAddedSpread(new BigDecimal("10"));

		assertEquals("10.30", rateWithAddedSpread.toString());
	}
}
