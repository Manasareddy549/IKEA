/*
 * Created on 2007-sep-18
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.be.MainCurrency;
import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpay1.cardpayment.vo.VoMainCurrency;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static org.junit.Assert.*;

/**
 * @author dalq
 *
 *
 */
public class BecCountryTest extends EbcCardPay1TestSetup {

	private final static Logger mLog = LoggerFactory.getLogger(BecCountryTest.class);

	public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();	
	public Units mUnits = new UnitsImpl(mUnitTestTimeSource, mUnitsCache);

	protected BecCountryImpl createBec () {
		return new BecCountryImpl(null, mUnitTestTimeSource, mUnits, null, null);
	}
	

	
	private static String EXCHANGE_MODE = "MANUAL";

  @Test
	final public void test_checkCountry() throws Exception {
		
		BecCountryImpl vBec = createBec();

		// --- Test ---

		vBec.checkValues("SE", EXCHANGE_MODE);
		vBec.checkValues("NO", EXCHANGE_MODE);

		// --- Assert ---		
	
	}

  @Test
	final public void test_checkCountry_BusinessUnitException() throws Exception  {
		BecCountryImpl vBec = createBec();

		// --- Test ---
		try {
			vBec.checkValues("GGG", EXCHANGE_MODE);
			fail("Should throw BusinessUnitException");
		} catch (Exception e) {

			assertEquals(
				"Should throw exception",
			BusinessUnitException.class,
				e.getClass());
		}		
		
	}



	/**
	 * Verify that the main_currency sets correctly
	 * 
	 * @throws Exception
	 */
  @Test
	final public void test_main_currency_now () throws Exception {
		
		BecCountryImpl vBec = createBec();
		vBec.init(new Country());
		Country vCountry =  vBec.getCountry();
		Set vMainCurrencies = new HashSet();
		MainCurrency vMainCurrency  = new MainCurrency();
		vMainCurrency.setCurrencyCode("SEK");
		vMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(20)));
		//vCountry.setMainCurrencies(Set);		
		vMainCurrencies.add(vMainCurrency);
		
		vMainCurrency  = new MainCurrency();
		vMainCurrency.setCurrencyCode("EUR");
		vMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(10)));
		vMainCurrencies.add(vMainCurrency);
		
		vMainCurrency  = new MainCurrency();
		vMainCurrency.setCurrencyCode("DKK");
		vMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(5)));
		vMainCurrencies.add(vMainCurrency);

		vCountry.setMainCurrencies(vMainCurrencies);		
		
		VoCountry vVoCountry = new VoCountry();
		List<VoMainCurrency> vVoMainCurrencyList = new ArrayList<VoMainCurrency>();
		
		VoMainCurrency vVoMainCurrency = new VoMainCurrency();
		// Oldest 
		vVoMainCurrency.setCurrencyCode("SEK");	
		//.minusDays(10).toDate()
		vVoMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(20)));
		vVoMainCurrencyList.add(vVoMainCurrency);
		
		vVoMainCurrency = new VoMainCurrency();
		// Older
		vVoMainCurrency.setCurrencyCode("EUR");
		vVoMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(10)));
		vVoMainCurrencyList.add(vVoMainCurrency);
		
		vVoMainCurrency = new VoMainCurrency();
		
		// Current
		vVoMainCurrency.setCurrencyCode("DKK");
		vVoMainCurrency.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(5)));
		vVoMainCurrencyList.add(vVoMainCurrency);
		

		vVoCountry.setVoMainCurrencyList(vVoMainCurrencyList);

		// --- Test ---


		vBec.calculateAndSetMainCurrencyNow(vVoCountry);
		assertNotSame("SEK", vBec.getVoCountry().getMainCurrencyNow());
		assertNotSame("EUR", vBec.getVoCountry().getMainCurrencyNow());
		assertEquals("DKK", vBec.getVoCountry().getMainCurrencyNow());
/*
		try {
			vBec.padAccountNumber(999000000000L);
			fail("Should throw exception");
		} catch (Exception e) {
			assertEquals(InvalidCardNumberException.class, e.getClass());
		}		
		*/
	}




}
