/*
 * Created on 2007-jun-21
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebccardpay1.cardpayment.vo.VoTransactionBrief;
import com.ikea.ebccardpay1.cardpayment.vo.*;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class BecTransactionsTest extends EbcCardPay1TestSetup {

  @Mock
  public BecFactory mBecFactoryMock;
  @Mock
  public BecCardNumber mBecCardNumberMock;
  @Mock
  public BefAuthorization mBefAuthorizationMock;

  /**
   * Testing compession of Transactions into VOs
   */
  @Test
  final public void test_compressCard() throws Exception {
    // --- Prepare ---

    BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(mBecFactoryMock, null, null, null, null, null,
            mBefAuthorizationMock, null,null, null, null);

    List vTransactions = new ArrayList();

    Transaction vTransaction1 = new Transaction();
    vTransaction1.setTransactionNo(10);
    vTransaction1.setBalanceChange(Amounts.amount(1));
    vTransaction1.setCardBalanceChange(Amounts.amount(10));
    vTransaction1.setRequestedAmount(Amounts.amount(98));
    vTransactions.add(vTransaction1);

    Transaction vTransaction2 = new Transaction();
    vTransaction2.setTransactionNo(10);
    vTransaction2.setBalanceChange(Amounts.amount(2));
    vTransaction2.setCardBalanceChange(Amounts.amount(20));
    vTransaction2.setRequestedAmount(Amounts.amount(100));
    vTransaction2.setInsufficientAmount(true);
    vTransactions.add(vTransaction2);

    Transaction vTransaction3 = new Transaction();
    vTransaction3.setTransactionNo(10);
    vTransaction3.setBalanceChange(Amounts.amount(3));
    vTransaction3.setCardBalanceChange(Amounts.amount(30));
    vTransaction3.setRequestedAmount(Amounts.amount(120));
    vTransaction3.setInsufficientAmount(true);
    vTransactions.add(vTransaction3);

    CardNumber vCardNumber = new CardNumber();
    vCardNumber.setIssuer("627598");
    vCardNumber.setCardTypeDigit(2);
    vCardNumber.setAccountNumberEnc("00000000005");
    vCardNumber.setCheckDigit(3);

    Card vCard = new Card();
    vCard.setCardState(Constants.CARD_STATE_CONSTANT_BOUND);
    vCard.setCardType(Constants.CARD_TYPE_CONSTANT_GIFT);
    vCard.setCardNumber(vCardNumber);

    vBecTransactionsImpl.initTransactions(vTransactions);
    vBecTransactionsImpl.mCard = vCard;

    // --- Expect ---
    //Create a BecCardNumber
    expect(mBecFactoryMock.createBecCardNumber()).andReturn(mBecCardNumberMock);
    // Create a cardnumber string
    expect(mBecCardNumberMock.composeCardNumberString(vCard.getCardNumber())).andReturn("6275982000000000053");

    Authorization vAuthorization = new Authorization();
    vAuthorization.setAuthorizationNumber("455612");
    expect(mBefAuthorizationMock.findByTransactionNo(vTransaction2.getTransactionNo())).andReturn(vAuthorization);

    // --- Replay ---
    replayAll();

    // --- Test ---
    List<VoTransactionCard> vActual = vBecTransactionsImpl.compressCard();

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertNotNull("list", vActual);
    assertEquals("list size", 1, vActual.size());

    VoTransactionCard vVoTransactionCard = vActual.get(0);

    assertEquals("transaction no", 10, vVoTransactionCard.getTransactionNo());
    assertEquals("sum balance change", Amounts.amount(6), vVoTransactionCard.getSumBalanceChange());
    assertEquals("sum card balance change", Amounts.amount(60), vVoTransactionCard.getSumCardBalanceChange());
    assertEquals("requested amount", Amounts.amount(120), vVoTransactionCard.getRequestedAmount());

    assertEquals("cardstate", Constants.CARD_STATE_CONSTANT_BOUND, vVoTransactionCard.getCardState());

    assertEquals("cardType", Constants.CARD_TYPE_CONSTANT_GIFT, vVoTransactionCard.getCardType());

    assertEquals("authorization", "455612", vVoTransactionCard.getAuthorizationNumber());
  }

  /**
   * Testing compession of Transactions into VOs
   */
  @Test
  final public void test_compressBrief() throws Exception {

    // --- Prepare ---
    BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(null, null, null, null, null, null, null, null,null, null, null);

    List vTransactions = new ArrayList();

    Transaction vTransaction1 = new Transaction();
    vTransaction1.setTransactionNo(100);
    vTransaction1.setBalanceChange(Amounts.amount(10));
    vTransaction1.setCardBalanceChange(Amounts.amount(100));
    vTransaction1.setRequestedAmount(Amounts.amount(55));
    vTransactions.add(vTransaction1);

    Transaction vTransaction2 = new Transaction();
    vTransaction2.setTransactionNo(100);
    vTransaction2.setBalanceChange(Amounts.amount(20));
    vTransaction2.setCardBalanceChange(Amounts.amount(200));
    vTransaction2.setRequestedAmount(Amounts.amount(160));
    vTransaction2.setInsufficientAmount(true);
    vTransactions.add(vTransaction2);

    Transaction vTransaction3 = new Transaction();
    vTransaction3.setTransactionNo(100);
    vTransaction3.setBalanceChange(Amounts.amount(30));
    vTransaction3.setCardBalanceChange(Amounts.amount(300));
    vTransaction3.setRequestedAmount(Amounts.amount(110));
    vTransaction3.setInsufficientAmount(true);
    vTransactions.add(vTransaction3);

    vBecTransactionsImpl.initTransactions(vTransactions);

    // --- Expect ---


    // --- Test ---
    List<VoTransactionBrief> vActual = vBecTransactionsImpl.compressBrief();

    // --- Assert ---
    assertNotNull("list", vActual);
    assertEquals("list size", 1, vActual.size());

    VoTransactionBrief vVoTransactionBrief = vActual.get(0);

    assertEquals("transaction no", 100, vVoTransactionBrief.getTransactionNo());
    assertEquals("sum balance change", Amounts.amount(60), vVoTransactionBrief.getSumBalanceChange());
    assertEquals("sum card balance change", Amounts.amount(600), vVoTransactionBrief.getSumCardBalanceChange());
    assertEquals("requested amount", Amounts.amount(160), vVoTransactionBrief.getRequestedAmount());

  }

  /**
   * Testing compession of Transactions into VOs
   */
  @Test
  final public void test_compressDetailed() throws Exception {
    // --- Prepare ---
    BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(null, null, null, null, null, null, null, null,null, null, null);

    List vTransactions = new ArrayList();

    Transaction vTransaction1 = new Transaction();
    vTransaction1.setTransactionNo(1);
    vTransaction1.setBalanceChange(Amounts.amount(1));
    vTransaction1.setCardBalanceChange(Amounts.amount(10));
    vTransaction1.setRequestedAmount(Amounts.amount(98));
    vTransactions.add(vTransaction1);

    Transaction vTransaction2 = new Transaction();
    vTransaction2.setTransactionNo(1);
    vTransaction2.setBalanceChange(Amounts.amount(2));
    vTransaction2.setCardBalanceChange(Amounts.amount(20));
    vTransaction2.setRequestedAmount(Amounts.amount(100));
    vTransaction2.setInsufficientAmount(true);
    vTransactions.add(vTransaction2);

    vBecTransactionsImpl.initTransactions(vTransactions);


    // --- Test ---
    List<VoTransaction> vActual = vBecTransactionsImpl.compressDetailed();

    // --- Assert ---
    assertNotNull("list", vActual);
    assertEquals("list size", 1, vActual.size());

    VoTransaction vVoTransaction = vActual.get(0);

    assertEquals("transaction no", 1, vVoTransaction.getTransactionNo());
    assertEquals("sum balance change", Amounts.amount(3), vVoTransaction.getSumBalanceChange());
    assertEquals("sum card balance change", Amounts.amount(30), vVoTransaction.getSumCardBalanceChange());
    assertEquals("requested amount", Amounts.amount(100), vVoTransaction.getRequestedAmount());
    assertEquals("insufficient amount", true, vVoTransaction.getInsufficientAmount());

    List<VoTransactionDetail> vDetailList = vVoTransaction.getVoTransactionDetailList();

    assertEquals("details list length", 2, vDetailList.size());

    VoTransactionDetail vDetail1 = vDetailList.get(0);
    VoTransactionDetail vDetail2 = vDetailList.get(1);

    assertEquals("detail1 Balance Change", Amounts.amount(1), vDetail1.getBalanceChange());
    assertEquals("detail1 Insufficient Amount", false, vDetail1.getInsufficientAmount());
    assertEquals("detail2 Balance Change", Amounts.amount(2), vDetail2.getBalanceChange());
    assertEquals("detail2 Insufficient Amount", true, vDetail2.getInsufficientAmount());

  }

  /**
   * Testing compession of Transactions into VOs
   */
  @Test
  final public void test_compressReport() throws Exception {

    // --- Prepare ---
    BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(null, null, null, null, null, null, null, null,null, null, null);

    List vTransactions = new ArrayList();

    Transaction vTransaction1 = new Transaction();
    vTransaction1.setTransactionNo(1);
    vTransaction1.setBalanceChange(Amounts.amount(1));
    vTransaction1.setCardBalanceChange(Amounts.amount(10));
    vTransaction1.setRequestedAmount(Amounts.amount(98));
    vTransactions.add(vTransaction1);

    Transaction vTransaction2 = new Transaction();
    vTransaction2.setTransactionNo(2);
    vTransaction2.setBalanceChange(Amounts.amount(5));
    vTransaction2.setCardBalanceChange(Amounts.amount(5));
    vTransaction2.setRequestedAmount(Amounts.amount(500));
    vTransaction2.setInsufficientAmount(true);
    vTransactions.add(vTransaction2);

    Transaction vTransaction3 = new Transaction();
    vTransaction3.setTransactionNo(2);
    vTransaction3.setBalanceChange(Amounts.amount(6));
    vTransaction3.setCardBalanceChange(Amounts.amount(6));
    vTransaction3.setRequestedAmount(Amounts.amount(600));
    vTransaction3.setInsufficientAmount(true);
    vTransactions.add(vTransaction3);

    vBecTransactionsImpl.initTransactions(vTransactions);
    // --- Test ---
    List<VoReportTransaction> vActual = vBecTransactionsImpl.compressReport();

    // --- Assert ---
    assertNotNull("list", vActual);
    assertEquals("list size", 2, vActual.size());

    // Check first transaction

    VoReportTransaction vFirst = vActual.get(0);

    assertEquals("first transaction no", 1, vFirst.getTransactionNo());
    assertEquals("first sum balance change", Amounts.amount(1), vFirst.getSumBalanceChange());
    assertEquals("first sum card balance change", Amounts.amount(10), vFirst.getSumCardBalanceChange());
    assertEquals("first requested amount", Amounts.amount(98), vFirst.getRequestedAmount());
    assertEquals("first insufficient amount", false, vFirst.getInsufficientAmount());

    List<VoTransactionDetail> vFirstDetailList = vFirst.getVoTransactionDetailList();

    assertEquals("first details list length", 1, vFirstDetailList.size());

    VoTransactionDetail vDetail1 = vFirstDetailList.get(0);

    assertEquals("first detail1 Balance Change", Amounts.amount(1), vDetail1.getBalanceChange());
    assertEquals("first detail1 Insufficient Amount", false, vDetail1.getInsufficientAmount());

    // Check second transaction no

    VoReportTransaction vSecond = vActual.get(1);

    assertEquals("second transaction no", 2, vSecond.getTransactionNo());
    assertEquals("second sum balance change", Amounts.amount(11), vSecond.getSumBalanceChange());
    assertEquals("second sum card balance change", Amounts.amount(11), vSecond.getSumCardBalanceChange());
    assertEquals("second requested amount", Amounts.amount(600), vSecond.getRequestedAmount());
    assertEquals("second insufficient amount", true, vSecond.getInsufficientAmount());

    List<VoTransactionDetail> vSecondDetailList = vSecond.getVoTransactionDetailList();

    assertEquals("details list length", 2, vSecondDetailList.size());

    VoTransactionDetail vDetail2_1 = vSecondDetailList.get(0);
    VoTransactionDetail vDetail2_2 = vSecondDetailList.get(1);

    assertEquals("second detail1 Balance Change", Amounts.amount(5), vDetail2_1.getBalanceChange());
    assertEquals("second detail1 Insufficient Amount", true, vDetail2_1.getInsufficientAmount());
    assertEquals("second detail2 Balance Change", Amounts.amount(6), vDetail2_2.getBalanceChange());
    assertEquals("second detail2 Insufficient Amount", true, vDetail2_2.getInsufficientAmount());

  }
  @Test
  public void testCalculateAuthorizationNumberBasedOnCardAndBalanceChange() {
    BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(null, null, null, null, null, null, null, null,null, null, null);
    String authNum = vBecTransactionsImpl.calculateAuthorizationNumberBasedOnCardAndBalanceChange("12002079179", 4,
            new BigDecimal("14.99"));
    assertEquals("91637", authNum);

  }

}
