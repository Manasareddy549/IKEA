package com.ikea.ebccardpay1.cardpayment.bec;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.util.Assert;

@ContextConfiguration(locations={"becfactorywiringtest-context.xml", "/bec-context.xml"})
public class BecMassLoadWiringTest extends AbstractJUnit4SpringContextTests {

	@Autowired
	private BecMassLoad bec;
	
	@Test
	public void testBecMassLoadWired() {
		Assert.notNull(bec);
	}
}
