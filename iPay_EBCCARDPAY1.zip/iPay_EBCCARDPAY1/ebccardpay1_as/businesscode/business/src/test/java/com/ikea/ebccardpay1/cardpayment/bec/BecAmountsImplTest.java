package com.ikea.ebccardpay1.cardpayment.bec;

import java.util.Date;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class BecAmountsImplTest {

    @Test
    public void testBefore_SameDateDiffTime() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// //Mon Mar 30 14:38:33 CEST 2009
		assertFalse(underTest.before("2009-03-30", date));
	}
    @Test
	public void testBefore_isBeforeDate() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// Mon Mar 30 14:38:33 CEST 2009
		assertTrue(underTest.before("2009-03-29", date));
	}
    @Test
	public void testBefore_isNotBeforeDate() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// Mon Mar 30 14:38:33 CEST 2009
		assertFalse(underTest.before("2009-03-31", date));
	}
    @Test
	public void testAfter_SameDateDiffTime() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// Mon Mar 30 14:38:33 CEST 2009
		assertFalse(underTest.after("2009-03-30", date));
	}
    @Test
	public void testAfter_SameDateDiffTimeCloseToMidnight() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L - (14L * 3600000L));// Mon Mar 30
																// 00:38:33 CEST
																// 2009
		//System.out.println(date);
		assertFalse(underTest.after("2009-03-30", date));
	}
    @Test
	public void testAfter_isAfterDate() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// Mon Mar 30 14:38:33 CEST 2009
		assertTrue(underTest.after("2009-03-31", date));
	}
    @Test
	public void testAfter_isNotAfterDate() {
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		Date date = new Date(1238416713310L);// Mon Mar 30 14:38:33 CEST 2009
		assertFalse(underTest.after("2009-03-29", date));
	}


}
