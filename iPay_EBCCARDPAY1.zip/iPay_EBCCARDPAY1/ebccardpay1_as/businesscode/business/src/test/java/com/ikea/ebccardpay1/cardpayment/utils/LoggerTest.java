/*
 * Created on 2007-jan-31
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.bec.BecAmountsImpl;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * @author anms
 */
public class LoggerTest {

	private final static Logger mLog = LoggerFactory.getLogger(LoggerTest.class);

  @Test
  final public void test_cardNumberToString() throws Exception {
    sub_test_cardNumberToString("1234567890", "12****7890");
    sub_test_cardNumberToString("", "");
    sub_test_cardNumberToString("12345678", "****5678");
    sub_test_cardNumberToString("1234567", "***4567");
    sub_test_cardNumberToString("123456", "**3456");
    sub_test_cardNumberToString("12345", "*2345");
    sub_test_cardNumberToString("1234", "1234");
  }

  final public void sub_test_cardNumberToString(
          String pInput, String pExpected) throws Exception {
    String vActual = CardPaymentLogger.cardNumberToString(pInput);
    assertEquals("Logger.cardNumberToString", pExpected, vActual);

  }
}
