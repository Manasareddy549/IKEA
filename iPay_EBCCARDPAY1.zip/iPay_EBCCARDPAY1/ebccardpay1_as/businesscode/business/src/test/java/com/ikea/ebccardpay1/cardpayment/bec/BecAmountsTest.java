/*
 * Created on 2006-aug-07
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.be.CampaignLimitation;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertEquals;

/**
 * @author snug
 */

@RunWith(EasyMockRunner.class)
public class BecAmountsTest extends EbcCardPay1TestSetup {

	private final static Logger mCategory = LoggerFactory.getLogger(BecAmountsTest.class);

	public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();
	public Units mUnits = new UnitsImpl(mUnitTestTimeSource, mUnitsCache);

	@Mock
	private PriorityEvaluator mPriorityEvaluatorMock;

	@Mock
	private BefIpayBusinessUnits mBefIpayBusinessUnitsMock;

	@TestSubject
	public BecAmountsImpl mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock, null,null,null);


	@Test
	final public void test_isActiveCampaign() throws Exception {

		// --- Fixed values ---
		Campaign vCampaign = new Campaign();
		vCampaign.setAuthorizedDateTime(new Date());
		vCampaign.setMonday(true);
		vCampaign.setTuesday(true);
		vCampaign.setWednesday(true);
		vCampaign.setThursday(true);

		Set<CampaignLimitation> vSet = new HashSet<CampaignLimitation>();
		CampaignLimitation vCampaignLimitations2 = new CampaignLimitation();
		vCampaignLimitations2.setBuType("STO");
		vCampaignLimitations2.setBuCode("107");
		vSet.add(vCampaignLimitations2);
		CampaignLimitation vCampaignLimitations = new CampaignLimitation();
		vCampaignLimitations.setBuType("STO");
		vCampaignLimitations.setBuCode("109");
		vSet.add(vCampaignLimitations);
		vCampaign.setCampaignLimitations(vSet);

		vCampaign.setMinPurchaseAmount(new BigDecimal(100));

		Date vCalcDate = Dates.parse("2007-04-04 13:00:00");

		// --- Prepare ---
		//boot();
		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		// --- Expect ---

		// --- Replay ---

		//expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","107")).andReturn(null);
		//expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","107")).andReturn(null);
		//expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","011")).andReturn(null);
		replayAll();

		// --- Test ---
		//sub_test_isActiveCampaign("107", vCalcDate, new BigDecimal(123), true, vCampaign);
		//sub_test_isActiveCampaign("011", vCalcDate, new BigDecimal(123), false, vCampaign);
		sub_test_isActiveCampaign(null, vCalcDate, new BigDecimal(123), true, vCampaign);
		sub_test_isActiveCampaign(null, vCalcDate, new BigDecimal(66), false, vCampaign);
		sub_test_isActiveCampaign(null, vCalcDate, null, true, vCampaign);

		vCampaign.setIntervalStartDate(Dates.parse("2007-04-01 00:00:00"));
		vCampaign.setIntervalEndDate(Dates.parse("2007-04-30 00:00:00"));
		//sub_test_isActiveCampaign("107", Dates.parse("2007-01-01 08:00:00"), null, false, vCampaign);
		vCampaign.setWithdrawnDateTime(new Date());
		sub_test_isActiveCampaign(null, vCalcDate, null, false, vCampaign);

		// --- Verify ---
		verifyAll();

		// --- Assert ---
	}

	final public void sub_test_isActiveCampaign(
			String pBuCode, Date pCalcDate, BigDecimal pTotalAmount, boolean pExpect,
			Campaign pCampaign) throws Exception {

		Amount vAmount = new Amount();
		vAmount.setCampaign(pCampaign);

		boolean vActual = mTested.isActiveCampaign(vAmount, pCalcDate, pTotalAmount, "STO", pBuCode, mBefIpayBusinessUnitsMock);
		assertEquals("isActiveCampaign", pExpect, vActual);
	}

	final public void sub_test_activeForLimitations(
			String pBuCode, boolean pExpect, Campaign pCampaign) throws Exception {

		boolean vActual = mTested.activeForLimitations("STO", pBuCode, pCampaign);
		assertEquals("activeForLimitations", pExpect, vActual);
	}

	@Test
	final public void test_activeForLimitations() throws Exception {

		// --- Fixed values ---
		Campaign vCampaign = new Campaign();
		Set<CampaignLimitation> vSet = new HashSet<CampaignLimitation>();
		CampaignLimitation vCampaignLimitations2 = new CampaignLimitation();
		vCampaignLimitations2.setBuType("STO");
		vCampaignLimitations2.setBuCode("107");
		vSet.add(vCampaignLimitations2);
		CampaignLimitation vCampaignLimitations = new CampaignLimitation();
		vCampaignLimitations.setBuType("STO");
		vCampaignLimitations.setBuCode("109");
		vSet.add(vCampaignLimitations);
		vCampaign.setCampaignLimitations(vSet);

		// --- Prepare ---
		//boot();
		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		// --- Expect ---

		// --- Replay ---
		replay();

		// --- Test ---
		sub_test_activeForLimitations("107", true, vCampaign);
		sub_test_activeForLimitations("109", true, vCampaign);
		sub_test_activeForLimitations("115", false, vCampaign);
		sub_test_activeForLimitations(null, true, vCampaign);

		vCampaign.setCampaignLimitations(null);
		sub_test_activeForLimitations("107", true, vCampaign);
		sub_test_activeForLimitations("109", true, vCampaign);
		sub_test_activeForLimitations("115", true, vCampaign);
		sub_test_activeForLimitations(null, true, vCampaign);

		// --- Verify ---
		verify();

		// --- Assert ---
	}

	@Test
	final public void test_activeForWeekdays() throws Exception {

		// --- Fixed values ---
		Campaign vCampaign = new Campaign();
		vCampaign.setMonday(true);
		vCampaign.setWednesday(true);

		// --- Prepare ---
		//boot();
		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		// --- Expect ---

		// --- Replay ---
		replay();

		// --- Test ---
		boolean vActual = mTested.activeForWeekdays("2007-04-04", vCampaign);

		// --- Verify ---
		verify();

		// --- Assert ---
		assertEquals("active weekday", vActual, true);
	}

	final public void sub_test_activeForTime(
			String pCalcDate, Campaign pCampaign, boolean pExpected) throws Exception {

		DateTime vDateTime = Dates.parseDateTime(pCalcDate);
		mCategory.debug("vDateTime " + vDateTime);
		Date vCalcDate = vDateTime.toDate();
		mCategory.debug("vCalcDate " + vCalcDate);

		DateTime vDateTime2 = new DateTime(vCalcDate, Dates.dateTimeZoneForId("UTC"));
		mCategory.debug("vDateTime2 " + vDateTime2);

		Date vCalcDate2 = vDateTime2.toDate();
		mCategory.debug("vCalcDate2 " + vCalcDate2);

		boolean vActual = mTested.activeForTime(vCalcDate, "STO", "107", pCampaign);
		assertEquals("activeForTime", pExpected, vActual);

	}

	@Test
	final public void test_activeForTime() throws Exception {

		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK);

		// --- Fixed values ---
		Campaign vCampaign = new Campaign();
		vCampaign.setFromTime("08:00");
		vCampaign.setUntilTime("15:00");

		mCategory.debug("vCampaign.getFromTime " + vCampaign.getFromTime());
		mCategory.debug("vCampaign.getUntilTime " + vCampaign.getUntilTime());

		// --- Prepare ---
		//boot();
		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		// --- Expect ---

		// --- Replay ---
		replay();

		// --- Test ---
		// Local time 02:00
		sub_test_activeForTime("2007-04-16 00:00:00", vCampaign, false);
		// Local time 07:35
		sub_test_activeForTime("2007-04-04 05:35:00", vCampaign, false);
		// Local time 09:35
		sub_test_activeForTime("2007-04-04 07:35:00", vCampaign, true);
		// Local time 16:00
		sub_test_activeForTime("2007-04-04 14:00:00", vCampaign, false);
		// Local time 15:00
		sub_test_activeForTime("2007-04-04 13:00:01", vCampaign, false);
		// Local time 15:00
		sub_test_activeForTime("2007-01-01 13:00:00", vCampaign, true);
		// Local time 14:00:01 (winter time)
		sub_test_activeForTime("2007-01-01 13:00:01", vCampaign, true);

		vCampaign.setFromTime(null);
		// Local time 01:00:01
		sub_test_activeForTime("2008-01-01 00:00:01", vCampaign, true);
		// Local time 17:00
		sub_test_activeForTime("2008-01-01 16:00:00", vCampaign, false);

		vCampaign.setUntilTime(null);
		sub_test_activeForTime("2008-01-01 00:00:00", vCampaign, true);
		sub_test_activeForTime("2008-01-01 23:59:59", vCampaign, true);

		// --- Verify ---
		verify();

		// --- Assert ---
	}

	final public void sub_test_beforeTime(
			String pLeft, String pRight, boolean pExpected) throws Exception {

		boolean vActual = mTested.beforeTime(pLeft, pRight);
		assertEquals("beforeTime", pExpected, vActual);

	}

	@Test
	final public void test_beforeTime() throws Exception {

		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		sub_test_beforeTime("08:00:00", "20:00", true);
		sub_test_beforeTime("08:00:00", "07:00", false);
		sub_test_beforeTime("08:00:00", "08:00", false);

		sub_test_beforeTime("17:59:00", "18:00", true);
		sub_test_beforeTime("18:00:00", "18:00", false);
		sub_test_beforeTime("18:01:00", "18:00", false);
		sub_test_beforeTime("17:59:58", "18:00", true);

	}

	final public void sub_test_afterTime(
			String pLeft, String pRight, boolean pExpected) throws Exception {

		boolean vActual = mTested.afterTime(pLeft, pRight);
		assertEquals("afterTime", pExpected, vActual);

	}

	@Test
	final public void test_afterTime() throws Exception {

		//mTested = new BecAmountsImpl(null, mUnits, mPriorityEvaluatorMock);

		sub_test_afterTime("08:00:00", "20:00", false);
		sub_test_afterTime("08:00:00", "07:00", true);
		sub_test_afterTime("08:00:00", "08:00", false);

		sub_test_afterTime("17:59:00", "18:00", false);
		sub_test_afterTime("18:00:00", "18:00", false);
		sub_test_afterTime("18:01:00", "18:00", true);
		sub_test_afterTime("18:00:01", "18:00", true);
	}
}
