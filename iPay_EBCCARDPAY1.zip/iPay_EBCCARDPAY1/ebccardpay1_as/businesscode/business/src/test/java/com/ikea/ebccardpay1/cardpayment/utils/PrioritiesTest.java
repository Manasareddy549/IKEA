/*
 * Created on 2007-apr-11
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;

/**
 * @author anms
 */
public class PrioritiesTest {

  @Test
  final public void test_less() throws Exception {

    assertEquals("", true, Priorities.less(new BigDecimal(100), new BigDecimal(200)));
    assertEquals("", false, Priorities.less(new BigDecimal(100), new BigDecimal(100)));
    assertEquals("", true, Priorities.less(new BigDecimal(100), new BigDecimal(100.0003)));
    assertEquals("", false, Priorities.less(new BigDecimal(100), new BigDecimal(3)));

  }

  @Test
  final public void test_greaterOrEqualsn() throws Exception {

    assertEquals("", false, Priorities.greaterOrEquals(new BigDecimal(100), new BigDecimal(200)));
    assertEquals("", true, Priorities.greaterOrEquals(new BigDecimal(100), new BigDecimal(100)));
    assertEquals("", false, Priorities.greaterOrEquals(new BigDecimal(100), new BigDecimal(100.0003)));
    assertEquals("", true, Priorities.greaterOrEquals(new BigDecimal(100), new BigDecimal(3)));

  }

}
