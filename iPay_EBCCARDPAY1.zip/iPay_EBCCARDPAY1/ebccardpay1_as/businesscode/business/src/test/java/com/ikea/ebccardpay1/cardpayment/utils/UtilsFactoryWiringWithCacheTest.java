package com.ikea.ebccardpay1.cardpayment.utils;

import static junit.framework.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
@Ignore
@ContextConfiguration(locations={"utilsfactorywiringwithcachetest-context.xml", "/caches-context.xml"})
public class UtilsFactoryWiringWithCacheTest extends AbstractJUnit4SpringContextTests  {

	@Autowired
	UtilsFactory utilsfactory;
	
	
	@Test
	public void testUtilsFactoryWired() {
		
		assertNotNull(utilsfactory);
	}
		
	
	
	
	
	
	
}
