/*
 * Created on 2007-aug-24
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.ExternalCard;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidCardNumberException;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author anms
 */
public class BecExternalCardTest extends EbcCardPay1TestSetup {

	private final static Logger mLog = LoggerFactory.getLogger(BecExternalCardTest.class);


  protected BecExternalCardImpl createBec() {
    return new BecExternalCardImpl(null, null, null, null, null);
  }

  @Test
  public void test_checkNumberRegExp() throws Exception {

    // --- Prepare  and expect ---
    ExternalCard vExternalCard = new ExternalCard();
    vExternalCard.setCardNumberString("6024271232850552");

    BecExternalCardImpl vBec = createBec();
    vBec.init(vExternalCard);

    // --- Test ---

    vBec.checkNumberRegExp("^[0-9]{2,20}$");
    vBec.checkNumberRegExp("^[0-9]{16,16}$");

    // --- Assert ---
  }

  @Test
  public void test_checkNumberRegExp_InvalidCardNumber() throws Exception {

    // --- Test ---
    sub_test_checkNumberRegExp_InvalidCardNumber("a6024271232850552", "^[0-9]{2,20}$");
    sub_test_checkNumberRegExp_InvalidCardNumber("552", "^[0-9]{16,16}$");

  }

  public void sub_test_checkNumberRegExp_InvalidCardNumber(
          String pCardNumberString, String pRegexp) throws Exception {

    ExternalCard vExternalCard = new ExternalCard();
    vExternalCard.setCardNumberString(pCardNumberString);

    BecExternalCardImpl vBec = createBec();
    vBec.init(vExternalCard);

    try {
      vBec.checkNumberRegExp(pRegexp);
      fail("Should throw InvalidCardNumberException");
    } catch(Exception e) {

      assertEquals("Should throw exception", InvalidCardNumberException.class, e.getClass());
    }
  }

}
