package com.ikea.ebccardpay1.cardpayment.utils;

import static junit.framework.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

@ContextConfiguration(locations="utilsfactorywiringtest-context.xml")
public class UtilsFactoryWiringTest extends AbstractJUnit4SpringContextTests  {

	@Autowired
	UtilsFactory utilsfactory;
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void testUtilsFactoryWired() {
		
		assertNotNull(utilsfactory);
	}
		
	
	
	
	
	
	
}
