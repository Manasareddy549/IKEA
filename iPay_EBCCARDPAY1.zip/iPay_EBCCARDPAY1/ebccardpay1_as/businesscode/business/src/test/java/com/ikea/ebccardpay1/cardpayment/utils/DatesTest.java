/*
 * Created on 2006-aug-22
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.bec.BecAmountsImpl;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Test;
import org.slf4j.LoggerFactory;

import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * @author anms
 */
public class DatesTest {

	private final static Logger mCategory = LoggerFactory.getLogger(DatesTest.class);

  private static DateTimeFormatter sFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

  @Test
  final public void test_nextDay() throws Exception {

    sub_nextDay("2006-11-13 10:16:34", "2006-11-14 10:16:34");
    sub_nextDay("2006-11-30 10:16:34", "2006-12-01 10:16:34");
    sub_nextDay("2006-12-31 10:16:34", "2007-01-01 10:16:34");
    sub_nextDay("2004-02-28 04:00:00", "2004-02-29 04:00:00");
    // Day light saving dates (in Sweden) using UTC dates here
    sub_nextDay("2006-10-28 03:35:00", "2006-10-29 03:35:00");
    sub_nextDay("2007-03-24 02:35:00", "2007-03-25 02:35:00");
    sub_nextDay("2007-03-24 01:35:00", "2007-03-25 01:35:00");

    sub_nextDay("2006-10-28 00:00:00", "2006-10-29 00:00:00");
    sub_nextDay("2006-10-28 02:00:00", "2006-10-29 02:00:00");
    sub_nextDay("2006-10-28 03:00:00", "2006-10-29 03:00:00");
    sub_nextDay("2006-10-29 00:00:00", "2006-10-30 00:00:00");
  }

  private void sub_nextDay(String pTestDate, String pExpected) throws Exception {

    DateTime vDateTime = Dates.parseDateTime(pTestDate);

    mCategory.debug("vDateTime" + vDateTime);

    DateTime vActual = Dates.withNextDay(vDateTime);
    mCategory.debug("vActual" + vActual);

    String vActualString = Dates.formatDateTime(vActual, true);

    mCategory.debug("vActualString" + vActualString);

    assertEquals("Dates.nextDay", pExpected, vActualString);
  }
  @Test
  final public void test_stringToDate() throws IkeaException {

    sub_test_stringToDate("2006-11-10", "2006-11-10 00:00:00");
    sub_test_stringToDate("2006-01-01", "2006-01-01 00:00:00");
    sub_test_stringToDate("2006-12-31", "2006-12-31 00:00:00");
  }

  private void sub_test_stringToDate(String pTestDate, String pExpected) throws IkeaException {

    DateTime vActual = Dates.parseDate(pTestDate);

    String vActualString = Dates.formatDateTime(vActual, true);

    assertEquals("Dates.stringToDate", pExpected, vActualString);
  }
  @Test
  final public void test_dateToString() throws Exception {

    sub_test_dateToString("2006-11-10 09:53:05", "2006-11-10");
    sub_test_dateToString("2006-01-05 09:53:05", "2006-01-05");
    sub_test_dateToString("2006-12-31 00:00:00", "2006-12-31");
    sub_test_dateToString("2006-12-31 23:59:00", "2006-12-31");
    sub_test_dateToString("2007-01-01 00:00:00", "2007-01-01");

    // Change to daylight saving time at 29th
    sub_test_dateToString("2006-10-29 00:00:05", "2006-10-29");
    sub_test_dateToString("2006-10-29 03:00:05", "2006-10-29");
    sub_test_dateToString("2006-10-29 23:58:05", "2006-10-29");

  }

   private void sub_test_dateToString(String pTestDate, String pExpected) throws Exception {

    DateTime vDateTime = sFormatter.parseDateTime(pTestDate);
    mCategory.debug("vDateTime" + vDateTime);

    String vActual = Dates.formatDate(vDateTime);
    mCategory.debug("vActual" + vActual);

    assertEquals("Dates.dateToString", pExpected, vActual);
  }

  @Test
  final public void test_Dates() throws Exception {
    // Sweden
    sub_test_Dates("2006-11-20 15:00:00", "Europe/Stockholm", "2006-11-20 16:00:00");
    sub_test_Dates("2006-08-16 15:00:00", "Europe/Stockholm", "2006-08-16 17:00:00");
    sub_test_Dates("2006-10-29 01:00:00", "Europe/Stockholm", "2006-10-29 02:00:00");
    sub_test_Dates("2006-12-31 23:57:00", "Europe/Stockholm", "2007-01-01 00:57:00");
    // UK
    sub_test_Dates("2006-11-13 12:24:00", "Europe/London", "2006-11-13 12:24:00");
    sub_test_Dates("2006-07-13 12:24:00", "Europe/London", "2006-07-13 13:24:00");

    sub_test_Dates("2006-11-13 02:00:00", "Australia/Sydney", "2006-11-13 13:00:00");
  }

  private void sub_test_Dates(
          String pUTC, String pTimeZone, String pExpectedLocal) throws Exception {

    mCategory.debug("pUTC " + pUTC);

    // --- Fixed values ---
    DateTime vDateTime = Dates.parseDateTime(pUTC);
    mCategory.debug("vDateTime " + vDateTime);
    Date vUTC = vDateTime.toDate();
    mCategory.debug("vUTC " + vUTC);

    // --- Test ---
    DateTime vActualInLocal = Dates.localDateTime(vUTC, pTimeZone);
    mCategory.debug("vActualInLocal " + vActualInLocal);
    String vActualInLocalString = Dates.formatDateTime(vActualInLocal, true);
    mCategory.debug("vActualInLocalString " + vActualInLocalString);

    // --- Assert ---
    assertEquals("Dates.localDate", pExpectedLocal, vActualInLocalString);
  }

  @Test
  final public void test_stringToDateTime_TimeZone() throws Exception {

    DateTime vCalculationDateTime = Dates.parseDateTime("2006-11-20 17:05:40");
    mCategory.info("Before           " + CardPaymentLogger.jodaToString(vCalculationDateTime));

    vCalculationDateTime = vCalculationDateTime.withZone(Dates.getZoneInfoProvider().getZone("Australia/Sydney"));

    mCategory.info("Australia/Sydney " + CardPaymentLogger.jodaToString(vCalculationDateTime));
    assertEquals("HOUR_OF_DAY for Sydney", 4, vCalculationDateTime.hourOfDay().get());
    assertEquals("DAY_OF_MONTH for Sydney", 21, vCalculationDateTime.dayOfMonth().get());
  }

  @Test
  final public void test_stringToDateTime_TimeZoneInit() throws Exception {

    DateTime vCalculationDateTime = Dates.parseDateTime("2006-11-20 17:05:40", "Australia/Sydney");
    mCategory.info("Before           " + CardPaymentLogger.jodaToString(vCalculationDateTime));

    vCalculationDateTime = vCalculationDateTime.withZone(Dates.getZoneInfoProvider().getZone("Australia/Sydney"));

    mCategory.info("Australia/Sydney " + CardPaymentLogger.jodaToString(vCalculationDateTime));
    assertEquals("HOUR_OF_DAY for Sydney", 17, vCalculationDateTime.hourOfDay().get());
    assertEquals("DAY_OF_MONTH for Sydney", 20, vCalculationDateTime.dayOfMonth().get());
  }
  /**
   * @throws Exception
   */
  /*
  final public void test_stringToDate_TimeZoneInit() throws Exception {
	
		Calendar vCalculationCalendar =
			Dates.stringToDate("2006-11-20 17:05:40", "Australia/Sydney");
		mCategory.info(
			"Before           "
				+ Logger.calendarToString(vCalculationCalendar));
	
		vCalculationCalendar.setTimeZone(
			TimeZone.getTimeZone("Australia/Sydney"));
	
		mCategory.info(
			"Australia/Sydney "
				+ Logger.calendarToString(vCalculationCalendar));
		assertEquals(
			"HOUR_OF_DAY for Sydney",
			0,
			vCalculationCalendar.get(Calendar.HOUR_OF_DAY));
		assertEquals(
			"DAY_OF_MONTH for Sydney",
			20,
			vCalculationCalendar.get(Calendar.DAY_OF_MONTH));
	}
	*/
  /**
   * @throws Exception
   */
	/*
	final public void test_Dates_conversions() throws Exception {
	
		// --- Fixed values ---
		SimpleDateFormat formatter =
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
		Calendar vTest1 = Calendar.getInstance();
		vTest1.setTime(formatter.parse("2006-11-21 00:00:00"));
	
		Calendar vTest2 = Calendar.getInstance();
		vTest2.setTime(formatter.parse("2006-11-01 00:00:00"));
	
		// --- Prepare ---
	
		// --- Expect ---
	
		// --- Replay ---
		MockUtils.replay(this);
	
		Calendar vResult1 = null;
		Calendar vResult2 = null;
	
		// --- Test ---
		try {
	
			vResult1 = Dates.stringToDate(Dates.dateToString(vTest1));
			vResult2 = Dates.stringToDate(Dates.dateToString(vTest2));
		} catch (Exception e) {
			Assert.fail("Should NOT throw [" + e + "]", e);
		}
	
		// --- Verify ---
		MockUtils.verify(this);
	
		assertCalendar(vTest1, vResult1, false);
		assertCalendar(vTest2, vResult2, false);
	}
	*/
  /**
   *
   * @param pTest
   * @param pResult
   */
	/*
	private void assertCalendar(
		Calendar pTest,
		Calendar pResult,
		boolean pIncludeTime) {
		// --- Assert ---
		assertEquals(pResult.get(Calendar.YEAR), pTest.get(Calendar.YEAR));
		assertEquals(pResult.get(Calendar.MONTH), pTest.get(Calendar.MONTH));
		assertEquals(
			pResult.get(Calendar.DAY_OF_MONTH),
			pTest.get(Calendar.DAY_OF_MONTH));
	
		if (pIncludeTime) {
			assertEquals(
				Dates.hourOfDayWithDST(pResult),
				Dates.hourOfDayWithDST(pTest));
		}
	}
	*/
  /**
   *
   * @param pCalendar
   * @return
   */
	/*
	public static int hourOfDayWithDST(Calendar pCalendar) {
		return pCalendar.get(Calendar.HOUR_OF_DAY)
			+ (pCalendar.get(Calendar.DST_OFFSET) / 1000 / 60 / 60);
	}
	*/
}
