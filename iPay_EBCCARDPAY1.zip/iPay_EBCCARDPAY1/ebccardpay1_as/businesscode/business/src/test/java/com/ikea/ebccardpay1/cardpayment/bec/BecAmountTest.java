/*
 * Created on 2006-aug-07
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import java.math.BigDecimal;
import java.util.Date;

import com.ikea.ebccardpay1.cardpayment.utils.*;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.joda.time.DateTime;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.vo.VoLoadAmount;
import com.ikea.ebccardpay1.cardpayment.vo.VoRequestAmount;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 */

@RunWith(EasyMockRunner.class)
public class BecAmountTest extends EbcCardPay1TestSetup {

  @Mock
  private BefAmount mBefAmountMock;

  @Mock
  private BefTransaction mBefTransactionMock;
  
  @Mock
  private BefReasonCodeTransaction mBefReasonCodeTransactionMock;

  @Mock
  private BusinessUnitEnvironment mBusinessUnitEnvironmentMock;

  @Mock
  private TransactionEnvironment mTransactionEnvironmentMock;

  @Mock
  private Constants mConstantsMock;

  @Mock
  private BefIpayBusinessUnits mBefIpayBusinessUnitsMock;
  @Mock
  private EncryptionDecryption mEncryptionDecryption;

  private UnitsCache mUnitsCache = new UnitsCacheStaticImpl();

  @TestSubject
  private BecAmount mTested = new BecAmountImpl(mBefAmountMock, new BecTransactionImpl(mBefTransactionMock,mBefReasonCodeTransactionMock, null, null,null,mEncryptionDecryption),
          mBefIpayBusinessUnitsMock);

//  @After
//  public void tearDown() throws Exception {
//
//    mTested = null;
//    //mMockEbcControl = null;
//    mBefAmountMock = null;
//    mBefTransactionMock = null;
//    mBusinessUnitEnvironmentMock = null;
//    mTransactionEnvironmentMock = null;
//    mBefIpayBusinessUnitsMock = null;
//  }

  /*@Test
  final public void test_calculateSalesDay() {

    sub_test_calculateSalesDay("107", "2006-11-07 15:00:00", "2006-11-07");
    sub_test_calculateSalesDay("107", "2006-11-07 00:15:00", "2006-11-06");
    sub_test_calculateSalesDay("107", "2006-11-07 00:59:59", "2006-11-06");
    sub_test_calculateSalesDay("107", "2006-11-07 01:00:00", "2006-11-06");
    sub_test_calculateSalesDay("107", "2006-11-07 01:15:00", "2006-11-06");
    sub_test_calculateSalesDay("107", "2006-11-07 02:15:00", "2006-11-07");

    // Day light saving dates
    sub_test_calculateSalesDay("107", "2006-08-15 23:15:00", "2006-08-15");
    sub_test_calculateSalesDay("107", "2006-08-16 00:00:00", "2006-08-15");
    sub_test_calculateSalesDay("107", "2006-08-16 00:15:00", "2006-08-15");
    sub_test_calculateSalesDay("107", "2006-08-16 01:00:00", "2006-08-16");
    sub_test_calculateSalesDay("107", "2006-08-16 01:15:00", "2006-08-16");
    sub_test_calculateSalesDay("107", "2006-08-16 02:15:00", "2006-08-16");
  }*/

  @Test
  final public void test_createCash_successful() {

    // --- Fixed values ---
    Card vCard = new Card();
    Amount vAmount = new Amount();

    // --- Prepare ---
    mTested.init(vCard, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);

    // --- Expect ---
    expect(mBefAmountMock.create()).andReturn(vAmount);
    //mBefAmountControl.expectAndReturn(mBefAmountMock.create(), vAmount);
    expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
    //mBusinessUnitEnvironmentControl.expectAndReturn(mBusinessUnitEnvironmentMock.getBuType(), "STO");
    expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("107");
    //mBusinessUnitEnvironmentControl.expectAndReturn(mBusinessUnitEnvironmentMock.getBuCode(), "107");

    // --- Replay ---
    replayAll();

    // --- Test ---
    try {
      mTested.createCash(Priorities.priority(Constants.AMOUNT_PRIORITY_GIFT));
    } catch(Exception e) {
      fail("Should NOT throw [" + e + "]");
    }

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("Amount type wrong.", Constants.AMOUNT_TYPE_CONSTANT_CASH, vAmount.getAmountType());
    assertEquals("Current amount was wrong.", Amounts.zero(), vAmount.getCurrentAmount());
    assertEquals("Priority was wrong.", Priorities.priority(Constants.AMOUNT_PRIORITY_GIFT), vAmount.getPriority());
  }
  @Test
  final public void test_createCash_failureNoCard() {

    new Amount();

    // --- Prepare ---
    mTested = new BecAmountImpl(mBefAmountMock, null, mBefIpayBusinessUnitsMock);

    // --- Expect ---

    // --- Replay ---
    replayAll();

    // --- Test ---
    try {
      mTested.createCash(Priorities.priority(Constants.AMOUNT_PRIORITY_GIFT));
      fail("Should throw exception.");
    } catch(Exception e) {
      assertEquals("Not the expected message", e.getMessage(), "Tried to use BecAmount without required Card.");
    }

    // --- Verify ---
    verifyAll();

    // --- Assert ---
  }

  @Test
  final public void test_load_successful() throws Exception {

    // --- Fixed values ---
    Card vCard = new Card();
    Amount vAmount = new Amount();
    Transaction vTransaction = new Transaction();
    VoLoadAmount vVoLoadAmount = new VoLoadAmount();
    //IpayBusinessUnits vIpayBusinessUnits= new IpayBusinessUnits();
    vTransaction.setCreatedDateTime(mUnitTestTimeSource.currentDate());
    vTransaction.setBuType("STO");
    vTransaction.setBuCode("107");

    vCard.setCurrencyCode("SEK");
    vCard.setCountryCode("SE");

    vAmount.setCurrentAmount(Amounts.zero());
    vAmount.setOriginalAmount(Amounts.zero());

    vVoLoadAmount.setCurrencyCode("SEK");
    vVoLoadAmount.setLoadAmount(Amounts.amount(10));

    String vSourceSystem = "CALYPSO";

    // --- Prepare ---
    mTested = new BecAmountImpl(mBefAmountMock, new BecTransactionImpl(mBefTransactionMock,mBefReasonCodeTransactionMock, mConstantsMock, null, null,mEncryptionDecryption),
            mBefIpayBusinessUnitsMock);
    mTested.init(vCard, vAmount, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);

    // --- Expect ---
    mBefAmountMock.save(vAmount);
    expect(mBefTransactionMock.create()).andReturn(vTransaction);
    mBefTransactionMock.save(vTransaction);

    expect(mTransactionEnvironmentMock.getReference()).andReturn("x.x.x");
    expect(mTransactionEnvironmentMock.getSourceSystem()).andReturn(vSourceSystem).times(2);
    expect(mTransactionEnvironmentMock.getTransmissionDateTime()).andReturn(new Date());
    expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
    expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("107");
    expect(mBusinessUnitEnvironmentMock.getCountryCode()).andReturn("SE").times(2);
    expect(mTransactionEnvironmentMock.getEmployee()).andReturn("sven").times(1);
    expect(mTransactionEnvironmentMock.getTransactionNo()).andReturn((long) 567);
    expect(mTransactionEnvironmentMock.getSwiped()).andReturn("N");
    expect(mTransactionEnvironmentMock.getPointOfSale()).andReturn(null);
    expect(mTransactionEnvironmentMock.getReceipt()).andReturn(null);
    expect(mBusinessUnitEnvironmentMock.getSalesDay()).andReturn(null);

    expect(mConstantsMock.isPointOfSale(vSourceSystem)).andReturn(true);

    expect(mBefIpayBusinessUnitsMock.findByPrimaryKey(null, null)).andReturn(null);
    // --- Replay ---
    replayAll();

    // --- Test ---
    mTested.load(vVoLoadAmount,vSourceSystem,null);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("Current amount was wrong.", Amounts.amount(10), vAmount.getCurrentAmount());
    assertEquals("Requested amount was wrong.", Amounts.amount(10), vTransaction.getRequestedAmount());
    assertEquals("Balance change was wrong.", Amounts.amount(10), vTransaction.getBalanceChange());
    assertEquals("Currency was wrong (Transaction).", "SEK", vTransaction.getRequestedCurrencyCode());
  }

  @Test
  final public void test_redeem_zeroLeft() throws Exception {

    // --- Fixed values ---
    Card vCard = new Card();
    Amount vAmount = new Amount();
    Transaction vTransaction = new Transaction();
    VoRequestAmount vVoRequestAmount = new VoRequestAmount();
    BigDecimal vExsistingAmount = Amounts.amount(10);
    BigDecimal vRedeemAmount = Amounts.amount(10);

    vTransaction.setCreatedDateTime(mUnitTestTimeSource.currentDate());
    vTransaction.setBuType("STO");
    vTransaction.setBuCode("107");

    vCard.setCurrencyCode("SEK");
    vCard.setCountryCode("SE");

    vAmount.setCurrentAmount(vExsistingAmount);

    vVoRequestAmount.setCurrencyCode("SEK");
    vVoRequestAmount.setRequestAmount(vRedeemAmount);

    // --- Prepare ---
    mTested = new BecAmountImpl(mBefAmountMock, new BecTransactionImpl(mBefTransactionMock,mBefReasonCodeTransactionMock, mConstantsMock, null,null,mEncryptionDecryption),
            mBefIpayBusinessUnitsMock);
    mTested.init(vCard, vAmount, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);

    // --- Expect ---
    //	mBefAmountMock.save(vAmount);
        /*	mBefTransactionControl.expectAndReturn(
      mBefTransactionMock.create(),
			vTransaction);
		mBefTransactionMock.save(vTransaction);

				mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getReference(),
			"x.x.x");
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getSourceSystem(),
			vSourceSystem,
			2);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getTransmissionDateTime(),
			new Date());
		mBusinessUnitEnvironmentControl.expectAndReturn(
			mBusinessUnitEnvironmentMock.getBuType(),
			"STO");
		mBusinessUnitEnvironmentControl.expectAndReturn(
			mBusinessUnitEnvironmentMock.getBuCode(),
			"107");
				mBusinessUnitEnvironmentControl.expectAndReturn(
			mBusinessUnitEnvironmentMock.getCountryCode(),
			"SE",
			2);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getEmployee(),
			"stina",
			1);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getTransactionNo(),
			2345);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getSwiped(),
			false);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getPointOfSale(),
			null);
		mTransactionEnvironmentControl.expectAndReturn(
			mTransactionEnvironmentMock.getReceipt(),
			null);
		mBusinessUnitEnvironmentControl.expectAndReturn(
			mBusinessUnitEnvironmentMock.getSalesDay(),
			null);

		mConstantsControl.expectAndReturn(
			mConstantsMock.isPointOfSale(vSourceSystem),
			true);*/

    // --- Replay ---
    replayAll();

    // --- Test ---
    mTested.redeem(vVoRequestAmount, vVoRequestAmount.getRequestAmount());

    // --- Assert ---

    assertEquals("Current amount was wrong.", Amounts.amount(0), vAmount.getCurrentAmount());

    // No transaction entity is created!
/*		Assert.assertEquals(
      "Requested amount was wrong.",
			vVoRequestAmount.getRequestAmount(),
			vTransaction.getRequestedAmount());
		Assert.assertEquals(
			"Insufficient amount,",
			false,
			vTransaction.getInsufficientAmount());
		Assert.assertEquals(
			"Balance change was wrong.",
			vRedeemAmount,
			vTransaction.getBalanceChange());
		Assert.assertEquals(
			"Currency was wrong (Transaction).",
			"SEK",
			vTransaction.getRequestedCurrencyCode());*/

    // --- Verify ---
    verifyAll();
  }

  final public void sub_test_calculateSalesDay(
          String pBuCode, String pUtc, String pExpectedSalesDay) {

    DateTime vDateTime = Dates.parseDateTime(pUtc);

    String vActual = Dates.calculateSalesDay(new UnitsImpl(mUnitTestTimeSource, mUnitsCache), vDateTime.toDate(),
            "STO", pBuCode, mBefIpayBusinessUnitsMock);

    assertEquals("sales day", pExpectedSalesDay, vActual);
  }

}
