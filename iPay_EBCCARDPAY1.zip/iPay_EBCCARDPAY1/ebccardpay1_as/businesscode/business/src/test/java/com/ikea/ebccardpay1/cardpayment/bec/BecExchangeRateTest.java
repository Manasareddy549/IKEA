/*
 * Created on 2007-sep-18
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidFromDateException;
import com.ikea.ebccardpay1.cardpayment.exception.InvalidToCurrencyException;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.cardpayment.vo.VoExchangeRate;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * @author dalq
 */
public class BecExchangeRateTest extends EbcCardPay1TestSetup {

	private final static Logger mCategory = LoggerFactory.getLogger(BecExchangeRateTest.class);
	
  protected BecExchangeRateImpl createBec() {
    return new BecExchangeRateImpl(null, null, null, mUnitTestTimeSource);
  }

  public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();
  public Units mUnits = new UnitsImpl(mUnitTestTimeSource, mUnitsCache);

  @Test
  final public void test_checkValues() throws InvalidFromDateException, InvalidFromCurrencyException,
          InvalidToCurrencyException, ValueMissingException {

    BecExchangeRateImpl vBec = createBec();

    VoExchangeRate vVoExchangeRate = new VoExchangeRate();

    vVoExchangeRate.setFromCurrencyCode("SEK");
    vVoExchangeRate.setToCurrencyCode("NOK");

    vVoExchangeRate.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date())));

    mCategory.info("From date set: " + vVoExchangeRate.getFromDate());


    vBec.checkValues(vVoExchangeRate);

    sub_test_checkValues_InvalidToCurrencyException("SEK", "SEK", mUnitTestTimeSource.currentDate());

    //mUnitTestTimeSource.currentDate()
    //Dates.getDateTime(new Date())

    mCategory.info("Current date:" + Dates.withoutTime(Dates.getDateTime(new Date()).minusDays(10))
    );

    sub_test_checkValues_InvalidFromCurrencyException("SEK", "NOK", Dates.getDateTime(new Date()).minusDays(10)
            .toDate());

  }

  private void sub_test_checkValues_InvalidToCurrencyException(
          String pFromCurr, String pToCurr, Date pFromDate) {

    BecExchangeRateImpl vBec = createBec();

    VoExchangeRate vVoExchangeRate = new VoExchangeRate();

    vVoExchangeRate.setFromCurrencyCode(pFromCurr);
    vVoExchangeRate.setToCurrencyCode(pToCurr);

    vVoExchangeRate.setFromDate(Dates.withoutTime(Dates.getDateTime(new Date())));

    mCategory.info("From date set: " + vVoExchangeRate.getFromDate());

    try {
      vBec.checkValues(vVoExchangeRate);

    } catch(Exception e) {

      assertEquals("Should throw exception", InvalidToCurrencyException.class, e.getClass());
    }

  }

  private void sub_test_checkValues_InvalidFromCurrencyException(
          String pFromCurr, String pToCurr, Date pFromDate) {

    BecExchangeRateImpl vBec = createBec();

    VoExchangeRate vVoExchangeRate = new VoExchangeRate();

    vVoExchangeRate.setFromCurrencyCode(pFromCurr);
    vVoExchangeRate.setToCurrencyCode(pToCurr);

    vVoExchangeRate.setFromDate(pFromDate);

    mCategory.info("From date set: " + vVoExchangeRate.getFromDate());

    try {
      vBec.checkValues(vVoExchangeRate);

    } catch(Exception e) {

      assertEquals("Should throw exception", InvalidFromDateException.class, e.getClass());
    }
  }

}
