/*
 * Created on 2006-nov-20
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.bef.BefKPI;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.utils.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Date;
import java.util.List;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;

/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class BecKPITest extends EbcCardPay1TestSetup {

  @Mock
  public BefKPI mBefKPIMock;

  @Mock
  public TimeSource mTimeSourceMock;
  
  @Mock
  public BefIpayBusinessUnits mBefIpayBusinessUnitsMock;

  public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();

  public BecKPIImpl mTested;

  protected void tearDown() throws Exception {
    mTested = null;
    mTimeSourceMock = null;
    mBefKPIMock = null;
    mBefIpayBusinessUnitsMock= null;
  }

  /**
   * Testing a bug with day light saving time found during tests.
   */
  @Test
  final public void test_findUncalculatedKPIDates_375_dayLightSavingBreak() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock );

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "375";
    String vLastKpi = "2006-10-29";

    // --- Expect ---
    // Set UTC in time
    Date vNow = Dates.parseDateTime("2006-12-07 10:10:00").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(vLastKpi);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","375")).andReturn(null);
	
    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 38, vActual.size());
    assertEquals("First date", "2006-10-30", vActual.get(0));
    assertEquals("Second date", "2006-10-31", vActual.get(1));
    //	[2006-10-29, 2006-10-30, 2006-10-31, 2006-11-01, 2006-11-02, 2006-11-03, 2006-11-04, 2006-11-05, 2006-11-06,
    // 2006-11-07, 2006-11-08, 2006-11-09, 2006-11-10, 2006-11-11, 2006-11-12, 2006-11-13, 2006-11-14, 2006-11-15,
    // 2006-11-16, 2006-11-17, 2006-11-18, 2006-11-19, 2006-11-20, 2006-11-21, 2006-11-22, 2006-11-23, 2006-11-24,
    // 2006-11-25, 2006-11-26, 2006-11-27, 2006-11-28, 2006-11-29, 2006-11-30, 2006-12-01, 2006-12-02, 2006-12-03,
    // 2006-12-04, 2006-12-05, 2006-12-06]

  }

  @Test
  final public void test_findUncalculatedKPIDates_noPrev() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "107";

    // --- Expect ---
    // Set UTC in time
    Date vNow = Dates.parseDateTime("2006-11-20 23:21:43").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(null);
   	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","107")).andReturn(null);
    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 1, vActual.size());
    assertEquals("First date", "2006-11-20", vActual.get(0));
  }

  @Test
  final public void test_findUncalculatedKPIDates_noPrev_Sydney() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "380";

    // --- Expect ---
    // Will be next date (21:st) in Syndney
    // Set UTC in time
    Date vNow = Dates.parseDateTime("2006-11-20 18:21:43").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(null);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","380")).andReturn(null);

    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 1, vActual.size());
    assertEquals("First date", "2006-11-20", vActual.get(0));
  }

  @Test
  final public void test_findUncalculatedKPIDates_Prev_SE() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "107";
    String vLastKpi = "2006-11-05";
    //vLastKpi.setKpiTimeZone("Europe/Stockholm");

    // --- Expect ---
    // Set UTC time
    Date vNow = Dates.parseDateTime("2006-11-09 00:21:43").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(vLastKpi);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","107")).andReturn(null);

    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 3, vActual.size());
    assertEquals("Fisrt date", "2006-11-06", vActual.get(0));
    assertEquals("Second date", "2006-11-07", vActual.get(1));
  }

  @Test
  final public void test_findUncalculatedKPIDates_Sydney() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "380";
    String vLastKpi = "2006-11-17";
    //vLastKpi.setKpiTimeZone("Australia/Sydney");

    // --- Expect ---
    // Set UTC time
    Date vNow = Dates.parseDateTime("2006-11-21 14:21:43").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(vLastKpi);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","380")).andReturn(null);
    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 4, vActual.size());
    assertEquals("First date", "2006-11-18", vActual.get(0));
    assertEquals("Second date", "2006-11-19", vActual.get(1));
    assertEquals("Third date", "2006-11-20", vActual.get(2));
  }

  @Test
  final public void test_findUncalculatedKPIDates_Sydney2() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "380";
    String vLastKpi = "2006-11-17";
    //vLastKpi.setKpiTimeZone("Australia/Sydney");

    // --- Expect ---
    Date vNow = Dates.parseDateTime("2006-11-21 16:00:01").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(vLastKpi);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","380")).andReturn(null);
    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 4, vActual.size());
    assertEquals("First date", "2006-11-18", vActual.get(0));
    assertEquals("Second date", "2006-11-19", vActual.get(1));
    assertEquals("Third date", "2006-11-20", vActual.get(2));
    assertEquals("Fourth date", "2006-11-21", vActual.get(3));
  }

  @Test
  final public void test_findUncalculatedKPIDates_Sydney_noDates() throws Exception {
    // --- Prepare ---
    mTested = new BecKPIImpl(mBefKPIMock, mTimeSourceMock, new UnitsImpl(mTimeSourceMock, mUnitsCache), mBefIpayBusinessUnitsMock);

    String vKpiType = "any type"; //Constants.KPI_TYPE_CONSTANT_STORE
    String vBuType = "STO";
    String vBuCode = "380";
    String vLastKpi = "2006-11-20";
    //vLastKpi.setKpiTimeZone("Australia/Sydney");

    // --- Expect ---
    // Set UTC in time
    Date vNow = Dates.parseDateTime("2006-11-21 14:00:01").toDate();
    expect(mTimeSourceMock.currentDate()).andReturn(vNow);
    expect(mBefKPIMock.findLastKPI(vKpiType, vBuType, vBuCode)).andReturn(vLastKpi);
	expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO","380")).andReturn(null);

    // --- Replay ---
    replayAll();

    // --- Test ---
    List<String> vActual = mTested.findUncalculatedKPIDates(vKpiType, vBuType, vBuCode, mBefIpayBusinessUnitsMock);

    // --- Verify ---
    verifyAll();

    // --- Assert ---
    assertEquals("List size", 1, vActual.size());
  }
}
