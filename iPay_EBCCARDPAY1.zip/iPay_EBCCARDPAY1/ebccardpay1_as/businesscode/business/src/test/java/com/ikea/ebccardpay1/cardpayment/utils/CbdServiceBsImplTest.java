package com.ikea.ebccardpay1.cardpayment.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import com.ikea.ebccbd1.client.bs.BsFindParents1;
import com.ikea.ebccbd1.client.bs.BsGetBuFull;
import com.ikea.ebccbd1.client.bs.BsGetCompFunc;
import com.ikea.ebccbd1.client.vo.VoBuFull;
import com.ikea.ebccbd1.client.vo.VoCluGet;
import com.ikea.ebccbd1.client.vo.VoCluStrMember;
import com.ikea.ebccbd1.client.vo.VoCluStrMember;
import com.ikea.ebccbd1.client.vo.VoCluStructure;
import com.ikea.ebccbd1.client.vo.VoCompCompFuncDetails;
import com.ikea.ebccbd1.client.vo.VoCompFuncGet;
import com.ikea.ebccbd1.client.vo.VoExcrtByValidAt;
import com.ikea.ebccbd1.client.vo.VoExcrtByValidAt;
import com.ikea.ebccbd1.client.vo.VoStructureGet;
import com.ikea.ebccbd1.client.vo.VoStructureGet;
import com.ikea.ebccbd1.client.vo.VoStructureResult;
import com.ikea.ebccbd1.client.vo.VoStructureResult;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class CbdServiceBsImplTest{

	private List<String> currencyList = new ArrayList<String>(Arrays
			.asList(new String[] { "SEK", "DKK", "EUR" }));
	private Set<String> currencies = new HashSet<String>(currencyList);

	private CbdServiceBsImpl underTest = new CbdServiceBsImpl();

  @Test
	public void testConvertToCurrencyCodeAndRate() throws Exception {
		List<VoExcrtByValidAt> ListVoExcrtByValidAt = new ArrayList<VoExcrtByValidAt>();
		VoExcrtByValidAt sekToDkk = new VoExcrtByValidAt();
		sekToDkk.setConvertFromCurCode("SEK");
		sekToDkk.setConvertToCurCode("DKK");
		sekToDkk.setExchangeRate(1.40);
		ListVoExcrtByValidAt.add(sekToDkk);

		VoExcrtByValidAt sekToEur = new VoExcrtByValidAt();
		sekToEur.setConvertFromCurCode("SEK");
		sekToEur.setConvertToCurCode("EUR");
		sekToEur.setExchangeRate(10.90);
		ListVoExcrtByValidAt.add(sekToEur);

		CbdExchangeRates convertToCurrencyCodeAndRate = underTest
				.convertToCurrencyCodeAndRate(ListVoExcrtByValidAt, currencies);

		assertEquals(2, convertToCurrencyCodeAndRate.getAllCurrencyCode()
				.size());
		assertEquals(new Double(1.4), convertToCurrencyCodeAndRate
				.getRate("DKK"));
		assertEquals(new Double(10.90), convertToCurrencyCodeAndRate
				.getRate("EUR"));
	}
  @Test
	public void testWhenListContainsTheFromCurrencyThenRemoveFromResult()
			throws Exception {
		List<VoExcrtByValidAt> ListVoExcrtByValidAt = new ArrayList<VoExcrtByValidAt>();
		VoExcrtByValidAt sekToDkk = new VoExcrtByValidAt();
		sekToDkk.setConvertFromCurCode("SEK");
		sekToDkk.setConvertToCurCode("DKK");
		sekToDkk.setExchangeRate(1.40);
		ListVoExcrtByValidAt.add(sekToDkk);

		VoExcrtByValidAt sekToEur = new VoExcrtByValidAt();
		sekToEur.setConvertFromCurCode("SEK");
		sekToEur.setConvertToCurCode("SEK");
		sekToEur.setExchangeRate(10.90);
		ListVoExcrtByValidAt.add(sekToEur);

		CbdExchangeRates convertToCurrencyCodeAndRate = underTest
				.convertToCurrencyCodeAndRate(ListVoExcrtByValidAt, currencies);

		assertEquals(1, convertToCurrencyCodeAndRate.getAllCurrencyCode()
				.size());
		assertEquals(new Double(1.4), convertToCurrencyCodeAndRate
				.getRate("DKK"));
	}
  @Test
	public void testWhenListContainsMoreCurrenciesThanAskedForThenRemoveThemFromResult()
			throws Exception {

		List<VoExcrtByValidAt> ListVoExcrtByValidAt = new ArrayList<VoExcrtByValidAt>();
		VoExcrtByValidAt sekToDkk = new VoExcrtByValidAt();
		sekToDkk.setConvertFromCurCode("SEK");
		sekToDkk.setConvertToCurCode("DKK");
		sekToDkk.setExchangeRate(1.40);
		ListVoExcrtByValidAt.add(sekToDkk);

		VoExcrtByValidAt sekToEur = new VoExcrtByValidAt();
		sekToEur.setConvertFromCurCode("SEK");
		sekToEur.setConvertToCurCode("EUR");
		sekToEur.setExchangeRate(10.90);
		ListVoExcrtByValidAt.add(sekToEur);

		VoExcrtByValidAt sekToZar = new VoExcrtByValidAt();
		sekToZar.setConvertFromCurCode("SEK");
		sekToZar.setConvertToCurCode("Zar");
		sekToZar.setExchangeRate(1.70);
		ListVoExcrtByValidAt.add(sekToZar);

		CbdExchangeRates convertToCurrencyCodeAndRate = underTest
				.convertToCurrencyCodeAndRate(ListVoExcrtByValidAt, currencies);

		assertEquals(2, convertToCurrencyCodeAndRate.getAllCurrencyCode()
				.size());
		assertEquals(new Double(1.4), convertToCurrencyCodeAndRate
				.getRate("DKK"));
		assertEquals(new Double(10.90), convertToCurrencyCodeAndRate
				.getRate("EUR"));
	}
  @Test
	public void testSetupBsGetBuFull() throws Exception {
		Date vValidAt = underTest.getValidAt();
		BsGetBuFull vBsGetBuFull = underTest.setupBsGetBuFull("ABC", "123");
		VoCluGet vVoCluGet = vBsGetBuFull.getVoCluGetIn();
		assertEquals("Wrong ClutType", "ABC", vVoCluGet.getClutType());
		assertEquals("Wrong CluCode", "123", vVoCluGet.getCluCode());
		assertEquals("Wrong ValidAt", vValidAt, vVoCluGet.getValidAt());
	}
  @Test
	public void testSetupBsGetCompFunc() throws Exception {
		Date vValidAt = underTest.getValidAt();
		BsGetCompFunc vBsGetCompFunc = underTest.setupBsGetCompFunc("ABC");
		VoCompFuncGet vVoCompFuncGet = vBsGetCompFunc.getVoCompFuncGetIn();
		assertEquals("Wrong CUTClass", "CF", vVoCompFuncGet.getCUTClass());
		assertEquals("Wrong CUTType", "RET", vVoCompFuncGet.getCUTType());
		assertEquals("Wrong CompFuncCode", "ABC", vVoCompFuncGet
				.getCompFuncCode());
		assertEquals("Wrong ValidAt", vValidAt, vVoCompFuncGet.getValidAt());
	}
  @Test
	public void testSetupBsFindParents1() throws Exception {
		BsFindParents1 vBsFindParents1 = underTest.setupBsFindParents1("123");
		List<VoStructureGet> vVoStructureGetList = vBsFindParents1
				.getVoFindParents1InList();
		VoStructureGet vVoStructureGet = (VoStructureGet) vVoStructureGetList.get(0);
		assertEquals("Wrong ClassType", "CF", vVoStructureGet.getClassType());
		assertEquals("Wrong ClassUnitType", "RET", vVoStructureGet
				.getClassUnitType());
		assertEquals("Wrong ClassUnitCode", "123", vVoStructureGet
				.getClassUnitCode());
		assertEquals("Wrong StructureType", "CFUNC", vVoStructureGet
				.getStructureType());
		assertEquals("Wrong ClassTypeFound", "BU", vVoStructureGet
				.getClassTypeFound());
		assertEquals("Wrong ClassUnitTypeFound", "COM", vVoStructureGet
				.getClassUnitTypeFound());
	}
  @Test
	public void testExtractClassUnitCode() throws Exception {
		VoBuFull vVoBuFull = new VoBuFull();
		VoCluStructure vBuStructure = new VoCluStructure();
		List<VoCluStrMember> vVoCluStrParentList = new ArrayList<VoCluStrMember>();
		VoCluStrMember vCluStrMemberLEG = new VoCluStrMember();
		vCluStrMemberLEG.setStructureType("LEG");
		vCluStrMemberLEG.setClassUnitCode("123");
		vVoCluStrParentList.add(vCluStrMemberLEG);
		VoCluStrMember vCluStrMemberORG = new VoCluStrMember();
		vCluStrMemberORG.setStructureType("ORG");
		vCluStrMemberORG.setClassUnitCode("456");
		vVoCluStrParentList.add(vCluStrMemberORG);
		vBuStructure.setVoCluStrParentList(vVoCluStrParentList);
		vVoBuFull.setVoBuStructure(vBuStructure);
		String vClassUnitCode = underTest.extractClassUnitCode("STO", //
				vVoBuFull);
		assertEquals("Wrong ClassUnitCode STO", "123", vClassUnitCode);
		vClassUnitCode = underTest.extractClassUnitCode("CSC", //
				vVoBuFull);
		assertEquals("Wrong ClassUnitCode CSC", "456", vClassUnitCode);
		vVoCluStrParentList.remove(vCluStrMemberLEG);
		vClassUnitCode = underTest.extractClassUnitCode("STO", //
				vVoBuFull);
		assertNull("Expected null ClassUnitCode", vClassUnitCode);
	}
  @Test
	public void testExtractParentBuCode() throws Exception {
		VoCompCompFuncDetails vVoCompCompFuncDetails = new VoCompCompFuncDetails();
		vVoCompCompFuncDetails.setBUCode("123");
		String vParentBuCode = underTest
				.extractParentBuCode(vVoCompCompFuncDetails);
		assertEquals("Wrong ", "123", vParentBuCode);
		vVoCompCompFuncDetails.setBUCode(null);
		vParentBuCode = underTest
				.extractParentBuCode(vVoCompCompFuncDetails);
		assertNull("Expected null ParentBuCode", vParentBuCode);
	}
  @Test
	public void testExtractCompany() throws Exception {
		BsFindParents1 vBsFindParents1 = new BsFindParents1();
		List<VoStructureResult> vVoStructureResultList = new ArrayList<VoStructureResult>();
		VoStructureResult vVoStructureResult0 = new VoStructureResult();
		vVoStructureResult0.setClassUnitNameFound("Name0");
		vVoStructureResultList.add(vVoStructureResult0);
		VoStructureResult vVoStructureResult1 = new VoStructureResult();
		vVoStructureResult1.setClassUnitNameFound("Name1");
		vVoStructureResultList.add(vVoStructureResult1);
		vBsFindParents1.setVoFindParents1OutList(vVoStructureResultList);
		Company vCompany = underTest.extractCompany("123", vBsFindParents1);
		assertEquals("Wrong CompanyCode", "123", vCompany.getCompanyCode());
		assertEquals("Wrong CompanyName", "Name0", vCompany.getCompanyName());
		vVoStructureResultList.remove(vVoStructureResult0);
		vCompany = underTest.extractCompany("456", vBsFindParents1);
		assertEquals("Wrong CompanyCode", "456", vCompany.getCompanyCode());
		assertEquals("Wrong CompanyName", "Name1", vCompany.getCompanyName());
		vVoStructureResultList.remove(vVoStructureResult1);
		vCompany = underTest.extractCompany("789", vBsFindParents1);
		assertNull("Expected null Company", vCompany);
	}
}
