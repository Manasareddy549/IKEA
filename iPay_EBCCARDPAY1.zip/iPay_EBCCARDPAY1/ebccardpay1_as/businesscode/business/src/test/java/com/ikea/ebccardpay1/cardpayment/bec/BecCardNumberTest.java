/*
 * Created on 2006-maj-30
 *
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.exception.*;
import com.ikea.ebccardpay1.cardpayment.utils.CheckDigits;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebccardpay1.cardpayment.vo.VoCardNumber;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;


/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class BecCardNumberTest extends EbcCardPay1TestSetup {

  // Mock card type constant
  @Mock
  public Constants mConstantsMock;

  // Mock card number BEF
  @Mock
  public BefCardNumber mBefCardNumberMock;

  private BecCardNumberImpl createBecCardNumberImpl() {
    return new BecCardNumberImpl(mBefCardNumberMock, mConstantsMock,null);
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_padAccountNumber() throws Exception {

    BecCardNumberImpl vBec = createBecCardNumberImpl();

    assertEquals("00000000001", vBec.padAccountNumber(1));
    assertEquals("00000000500", vBec.padAccountNumber(500));
    assertEquals("99000000000", vBec.padAccountNumber(99000000000L));

    try {
      vBec.padAccountNumber(999000000000L);
      fail("Should throw exception");
    } catch(Exception e) {
      assertEquals(InvalidCardNumberException.class, e.getClass());
    }
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_regExp() throws Exception {

    assertEquals(true, "1234567890".matches("^[0-9]{10}$"));
    assertEquals(true, "1234567890".matches("[0-9]{10}"));
    assertEquals(true, "1234567890".matches("[0-9]{10}"));
    assertEquals(true, "abcABC123".matches("^[a-zA-Z0-9]{2,9}$"));
    assertEquals(true, "abcABC-123".matches("^[-_a-zA-Z0-9]{2,20}$"));


    assertEquals(true, "6006261192126082".matches("^[0-9]{16,16}$"));
    assertEquals(false, "6006261192126082".matches("^[0-9](16)$"));

    assertEquals(false, "100".matches("^[0-9](2,10)$"));
    assertEquals(true, "100".matches("^[0-9]{2,10}$"));
  }

  /**
   * @throws Exception
   */
  @Test
  final public void test_createCardNumber() throws Exception {

    // Expect
    CardNumber vExpectedOutput = new CardNumber();
    String vCardNumberStringInput = "6275982990000000931";
    loadProperties("BecCardNumberTest_createCardNumber_output.properties", vExpectedOutput);

    expect(mConstantsMock.getCardType(vExpectedOutput.getCardTypeDigit())).andReturn("any_string");
    mUnitTestTimeSource.setCurrent(vExpectedOutput.getCreatedDateTime());
    setUserIdInUserProfile(vExpectedOutput.getCreatedBy());

    expect(mBefCardNumberMock.create()).andReturn(vExpectedOutput);
    mBefCardNumberMock.save(vExpectedOutput);

    // --- Run test ---
    replayAll();
    BecCardNumberImpl vBec = createBecCardNumberImpl();
    vBec.createCardNumber(vCardNumberStringInput);
    CardNumber vActualOutput = vBec.getCardNumber();

    // --- Assert and verify the result ---
    verifyAll();
    assertEquals(vExpectedOutput.getIssuer(), vActualOutput.getIssuer());
    assertEquals(vExpectedOutput.getAccountNumberEnc(), vActualOutput.getAccountNumberEnc());
    assertEquals(vExpectedOutput.getCardTypeDigit(), vActualOutput.getCardTypeDigit());
    assertEquals(vExpectedOutput.getCheckDigit(), vActualOutput.getCheckDigit());
    assertEquals(vExpectedOutput.getCreatedBy(), vActualOutput.getCreatedBy());
    assertEquals(vExpectedOutput.getCreatedDateTime(), vActualOutput.getCreatedDateTime());
    assertEquals(vExpectedOutput, vActualOutput);
  }

  /**
   * Test if the check digit if valid
   *
   * @throws Exception
   */
  @Test
  final public void testIsValidCheckDigit() throws Exception {

    // --- Run the test ---

    runIsValidCheckDigit("539", true);
    runIsValidCheckDigit("8573", true);
    runIsValidCheckDigit("8570", false);
    runIsValidCheckDigit("8571", false);
    runIsValidCheckDigit("8572", false);
    runIsValidCheckDigit("8574", false);
    runIsValidCheckDigit("8575", false);
    runIsValidCheckDigit("8576", false);
    runIsValidCheckDigit("8577", false);
    runIsValidCheckDigit("8578", false);
    runIsValidCheckDigit("8579", false);
    runIsValidCheckDigit("6275982990000000931", true);
    runIsValidCheckDigit("6275982990000000938", false);
    runIsValidCheckDigit("6275982991111115675", true);
    runIsValidCheckDigit("6275982991111115671", false);

  }

  private void runIsValidCheckDigit(String pToValidate, boolean pIsValidResult) throws Exception {
    boolean vActualOuput = CheckDigits.isValidCheckDigit(pToValidate);

    // --- Assert and verify the result ---

    assertEquals("Wrong output from isValidCheckDigit. Card number '" + pToValidate + "'.", pIsValidResult,
            vActualOuput);
  }

  /**
   * Test split of full card number string
   *
   * @throws Exception
   */
  @Test
  final public void testSplitCardNumber() throws Exception {
    VoCardNumber vExpectedOuput = (VoCardNumber) loadProperties("BecCardNumberTest_split_output.properties",
            VoCardNumber.class);
    String vCardNumberStringInput = "6275982990000000931";

    expect(mConstantsMock.getCardType(vExpectedOuput.getCardTypeDigit())).andReturn(Constants.CARD_TYPE_CONSTANT_GIFT);

    // --- Run the test ---
    replayAll();

    BecCardNumberImpl vBec = createBecCardNumberImpl();
    VoCardNumber vActualOuput = vBec.splitCardNumber(vCardNumberStringInput);

    // --- Assert and verify the result ---

    assertEquals("Result of split of card number not okey.", vExpectedOuput, vActualOuput);

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  /**
   * Test split of full card number string
   *
   * @throws Exception
   */
  @Test
  final public void testSplitCardNumber_invalid() throws Exception {

    expect(mConstantsMock.getCardType(7)).andThrow(new CardTypeDigitNotFoundException());

    // --- Run the test ---

    replayAll();

    runSplitCardNumber_invalid("wrong_length", InvalidCardNumberException.class.getName());
    runSplitCardNumber_invalid("invalid_card_number", InvalidCardNumberException.class.getName());
    runSplitCardNumber_invalid("6275982990000000939", InvalidCardCheckDigitException.class.getName());
    runSplitCardNumber_invalid("6275987990000000936", InvalidCardTypeDigitException.class.getName());
    runSplitCardNumber_invalid("1275982000000000934", InvalidCardIssuerException.class.getName());

    // --- Assert and verify the result ---

    verifyAll();
  }

  private void runSplitCardNumber_invalid(String pCardNumberStringInput, String pExpectedException) throws Exception {
    BecCardNumberImpl vBec = createBecCardNumberImpl();

    try {
      vBec.splitCardNumber(pCardNumberStringInput);
      fail("Should throw InvalidCardNumberException.");
    } catch(Exception e) {
      assertEquals("Split of card number should throw exception for card number string '" + pCardNumberStringInput +
                      "'.", pExpectedException, e.getClass().getName()
      );
    }
  }

  /**
   * Test split of full card number string
   *
   * @throws Exception
   */
  @Test
  final public void testComposeCardNumberString() throws Exception {

    // --- Set up mock behaviour ---

    CardNumber vCardNumber = new CardNumber();
    vCardNumber.setIssuer("any");
    vCardNumber.setCardTypeDigit(4);
    vCardNumber.setAccountNumberEnc("account");
    vCardNumber.setCheckDigit(9);

    String vExpectedOutput = "any4account9";

    // --- Run the test ---

    replayAll();

    BecCardNumberImpl vBec = createBecCardNumberImpl();
    String vActualOuput = vBec.composeCardNumberString(vCardNumber);

    // --- Assert and verify the result ---

    assertEquals("Wrong output from composeCardNumberString.", vExpectedOutput, vActualOuput);

    // --- Assert and verify the result ---

    verifyAll();
  }

  /**
   * Test split of full card number string
   *
   * @throws Exception
   */
  @Test
  final public void testFindCardNumber() throws Exception {

    // --- Set up mock behaviour ---

    CardNumber vExpectedOutput = new CardNumber();
    loadProperties("BecCardNumberTest_findCardNumber_output" + ".properties", vExpectedOutput);
    String vCardNumberStringInput = "6275982990000000931";

    expect(mBefCardNumberMock.findByCardNumber(vExpectedOutput.getIssuer(), vExpectedOutput.getCardTypeDigit(),
             vExpectedOutput.getCheckDigit(),vExpectedOutput.getAccountNumberEnc())).andReturn(vExpectedOutput);

    expect(mConstantsMock.getCardType(vExpectedOutput.getCardTypeDigit())).andReturn("any_string");

    // --- Run the test ---
    replayAll();

    BecCardNumberImpl vBec = createBecCardNumberImpl();
    vBec.setCardNumber(new CardNumber());
    vBec.findCardNumber(vCardNumberStringInput);
    CardNumber vActualOuput = vBec.getCardNumber();

    // --- Assert and verify the result ---

    assertEquals("Wrong output from findCardNumber.", vExpectedOutput, vActualOuput);

    // --- Assert and verify the result ---
    verifyAll();
  }

  /**
   * Test split of full card number string
   *
   * @throws Exception
   */
  @Test
  final public void testFindCardNumber_notFound() throws Exception {
    CardNumber vExpectedOutput = null;
    CardNumber vInput = new CardNumber();
    loadProperties("BecCardNumberTest_findCardNumber_output" + ".properties", vInput);
    String vCardNumberStringInput = "6275982990000000931";

    expect(mBefCardNumberMock.findByCardNumber(vInput.getIssuer(), vInput.getCardTypeDigit(),
            vInput.getCheckDigit(), vInput.getAccountNumberEnc())).andReturn(vExpectedOutput);

    expect(mConstantsMock.getCardType(vInput.getCardTypeDigit())).andReturn("any_string");

    // --- Run the test ---
    replayAll();

    BecCardNumberImpl vBec = createBecCardNumberImpl();
    vBec.setCardNumber(new CardNumber());

    try {
      vBec.findCardNumber(vCardNumberStringInput);
      fail("Should throw CardNumberNotFoundException.");
    } catch(Exception e) {
      assertEquals("Should throw CardNumberNotFoundException.", CardNumberNotFoundException.class, e.getClass());
    }
    CardNumber vActualOuput = vBec.getCardNumber();

    // --- Assert and verify the result ---

    assertEquals("Wrong output from findCardNumber.", vExpectedOutput, vActualOuput);
    verifyAll();

  }

}
