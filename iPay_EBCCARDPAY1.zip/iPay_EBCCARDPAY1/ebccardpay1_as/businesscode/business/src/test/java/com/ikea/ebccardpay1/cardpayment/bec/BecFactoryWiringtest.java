package com.ikea.ebccardpay1.cardpayment.bec;

import static junit.framework.Assert.assertNotNull;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

@ContextConfiguration(locations="becfactorywiringtest-context.xml")
public class BecFactoryWiringtest extends AbstractJUnit4SpringContextTests  {

	@Autowired
	BecFactory becfactory;
	
	
	@Test
	public void testBecFactoryWired() {
		
		assertNotNull(becfactory);
	}
	
	@Test
	public void testCreateBecCampaign() {
		BecCampaign bec = becfactory.createBecCampaign();
		assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCampaigns() {
		BecCampaigns bec = becfactory.createBecCampaigns();
		assertNotNull(bec);
	}
	
	@Test
	public void testBecCard() {
		BecCard bec = becfactory.createBecCard();
		assertNotNull(bec);
	}
	
	@Test
	public void testBecCards() {
		BecCards bec = becfactory.createBecCards();
		assertNotNull(bec);
	}
	
	
	@Test
	public void testCreateBecAmount() {
		BecAmount ba = becfactory.createBecAmount();
		Assert.assertNotNull(ba);
	}
	
	@Test
	public void testCreateBecAmounts() {
		BecAmounts ba = becfactory.createBecAmounts();
		Assert.assertNotNull(ba);
	}
	@Test
	public void testCreateBecCardNumber() {
		BecCardNumber bec = becfactory.createBecCardNumber();
		Assert.assertNotNull(bec);
		
	}
	
	@Test
	public void testCreateBecKPI() {
		BecKPI bec = becfactory.createBecKPI();
		Assert.assertNotNull(bec);
		
	}
	
	@Test
	public void testCreateBecReport() {
		BecReport bec = becfactory.createBecReport();
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecTransaction() {
		BecTransaction bec = becfactory.createBecTransaction();
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecTransactions() {
		BecTransactions bec = becfactory.createBecTransactions();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecReferenceCheck() {
		BecReferenceCheck bec = becfactory.createBecReferenceCheck();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecReferenceChecks() {
		BecReferenceChecks bec = becfactory.createBecReferenceChecks();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecRange() {
		BecRange bec = becfactory.createBecCardRange();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCampaignLimitation() {
		BecCampaignLimitation bec = becfactory.createBecCampaignLimitation();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecMassLoad() {
		BecMassLoad bec = becfactory.createBecMassLoad();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecMassLoads() {
		BecMassLoads bec = becfactory.createBecMassLoads();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecBonusCode() {
		BecBonusCode bec = becfactory.createBecBonusCode();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecBonusCodes() {
		BecBonusCodes bec = becfactory.createBecBonusCodes();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecBonus() {
		BecBonus bec = becfactory.createBecBonus();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecBonuses() {
		BecBonuses bec = becfactory.createBecBonuses();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCountrySetup() {
		BecCountrySetup bec = becfactory.createBecCountrySetup();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCountrySetups() {
		BecCountrySetups bec = becfactory.createBecCountrySetups();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecExternalCard() {
		BecExternalCard bec = becfactory.createBecExternalCard();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecExternalCardSystem() {
		BecExternalCardSystem bec = becfactory.createBecExternalCardSystem();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecMainCurrency() {
		BecMainCurrency bec = becfactory.createBecMainCurrency();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecMainCurrencies() {
		BecMainCurrencies bec = becfactory.createBecMainCurrencies();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecExchangeRate() {
		BecExchangeRate bec = becfactory.createBecExchangeRate();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecExchangeRates() {
		BecExchangeRates bec = becfactory.createBecExchangeRates();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCountries() {
		BecCountries bec = becfactory.createBecCountries();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecCountry() {
		BecCountry bec = becfactory.createBecCountry();
		
		Assert.assertNotNull(bec);
	}
	
	@Test
	public void testCreateBecUnacknowledgedTimeout() {
		BecUnacknowledgedTimeout bec = becfactory.createBecUnacknowledgedTimeout();
		
		Assert.assertNotNull(bec);
	}
	
	
	
	
	
}
