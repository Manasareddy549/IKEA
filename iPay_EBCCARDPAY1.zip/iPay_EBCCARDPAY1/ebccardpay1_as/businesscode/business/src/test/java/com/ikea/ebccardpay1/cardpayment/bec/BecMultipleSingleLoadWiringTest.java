package com.ikea.ebccardpay1.cardpayment.bec;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.util.Assert;
@ContextConfiguration(locations={ "becfactorywiringtest-context.xml","/bec-context.xml"})
public class BecMultipleSingleLoadWiringTest extends
		AbstractJUnit4SpringContextTests {

	@Autowired
	private BecMultipleSingleLoad bec;
	
	@Test
	public void testWiring() {
		Assert.notNull(bec);
	}
}
