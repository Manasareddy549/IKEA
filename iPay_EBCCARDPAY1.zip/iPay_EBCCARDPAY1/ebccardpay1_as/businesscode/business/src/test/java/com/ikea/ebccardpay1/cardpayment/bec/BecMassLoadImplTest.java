package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoMassLoad;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@RunWith(EasyMockRunner.class)
public class BecMassLoadImplTest extends EbcCardPay1TestSetup {

  @Mock
  public Units mUnitsMock;

  @Test
  public void testCreateMassLoadWithNonExistingBU() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, mUnitsMock, null, null, null, null, null,
            null, null, null,null, null, null, null);

    VoMassLoad voMassLoad = new VoMassLoad();
    voMassLoad.setBuType("STO");
    voMassLoad.setBuCode("107 ");


    mUnitsMock.checkValidBusinessUnit("STO", "107 ");
    expectLastCall().andThrow(new BusinessUnitException());


    replayAll();
    try {
      underTest.createMassLoad(voMassLoad);
      fail();
    } catch(Exception e) {
      assertEquals(BusinessUnitException.class.toString(), e.getClass().toString());
    }
    verifyAll();

  }

  @Test
  public void testAppendLockMessage_FirstError() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, null, null, null, null, null, null, null, null, null,null, null, null, null);

    StringBuffer messages = new StringBuffer();

    StringBuffer expected = new StringBuffer("62759829900****0055: Some crazy error message\n");
    //Test
    underTest.appendLockMessage(messages, "6275982990000000055", "Some crazy error message");
    //Assert
    assertEquals(expected.toString(), messages.toString());
  }

  @Test
  public void testAppendLockMessage_LessThan4000Char() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, null, null, null, null, null, null, null, null, null,null, null, null, null);

    StringBuffer messages = new StringBuffer();
    messages.append("hdsjdjslajdkslajdkslajdkslajdskla");

    StringBuffer expected = new StringBuffer("hdsjdjslajdkslajdkslajdkslajdskla62759829900****0055: Some crazy error " +
            "message\n");
    //Test
    underTest.appendLockMessage(messages, "6275982990000000055", "Some crazy error message");
    //Assert
    assertEquals(expected.toString(), messages.toString());
  }

  @Test
  public void testAppendLockMessage_ResultingErrorMoreThan4000Char() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, null, null, null, null, null, null, null, null, null,null, null, null, null);

    StringBuffer messages = new StringBuffer();
    for(int i = 0; i < 3970; i++) {
      messages.append("1");
    }
    StringBuffer expected = new StringBuffer(messages.toString() + "...[unable to save all errors]");
    //Test
    underTest.appendLockMessage(messages, "6275982990000000055", "Some crazy error message");
    //Assert
    assertEquals(4000, messages.length());
    assertEquals(expected.toString(), messages.toString());
  }

  @Test
  public void testAppendLockMessage_ExistingErrorPlusEndingMoreThan4000Char() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, null, null, null, null, null, null, null, null, null,null, null, null, null);

    StringBuffer messages = new StringBuffer();
    for(int i = 0; i < 3990; i++) {
      messages.append("1");
    }
    StringBuffer expected = new StringBuffer();
    for(int i = 0; i < 3970; i++) {
      expected.append("1");
    }
    expected.append("...[unable to save all errors]");
    //Test
    underTest.appendLockMessage(messages, "6275982990000000055", "Some crazy error message");
    //Assert
    assertEquals(4000, messages.length());
    assertEquals(expected.toString(), messages.toString());
  }

  @Test
  public void testAppendLockMessage_AlreadyToLongMessageSentIn() throws Exception {

    BecMassLoadImpl underTest = new BecMassLoadImpl(null, null, null, null, null, null, null, null, null, null, null, null, null,null, null, null, null);

    StringBuffer expected = new StringBuffer();
    for(int i = 0; i < 3970; i++) {
      expected.append("1");
    }
    expected.append("...[unable to save all errors]");

    StringBuffer messages = new StringBuffer(expected.toString());
    //Test
    underTest.appendLockMessage(messages, "6275982990000000055", "Some crazy error message");
    //Assert
    assertEquals(4000, messages.length());
    assertEquals(expected.toString(), messages.toString());
  }

}
