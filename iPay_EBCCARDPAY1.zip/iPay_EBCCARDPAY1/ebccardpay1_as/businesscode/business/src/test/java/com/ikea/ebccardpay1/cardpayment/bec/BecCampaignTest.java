/*
 * Created on 2006-aug-07
 */
package com.ikea.ebccardpay1.cardpayment.bec;

import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.exception.CampaignException;
import org.joda.time.DateTime;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * @author snug
 */
public class BecCampaignTest {

  public BecCampaignImpl mTested = new BecCampaignImpl(null, null, null, null, null, null, null, null, null, null,null, null, null, null, null);

  final public void sub_test_checkConstraints(
          DateTime pStart, DateTime pEnd, String pFrom, String pUntil, boolean pExpectException) throws Exception {

    // --- Set up for test ---
    Campaign vCampaign = new Campaign();
    vCampaign.setIntervalStartDate(pStart.toDate());
    vCampaign.setIntervalEndDate(pEnd.toDate());

    vCampaign.setFromTime(pFrom);
    vCampaign.setUntilTime(pUntil);

    vCampaign.setSunday(true);

    // --- Prepare ---

    mTested.setCampaign(vCampaign);

    try {
      mTested.checkConstraints();
      assertEquals("CampaignException", pExpectException, false);

    } catch(Exception e) {
      assertEquals("CampaignException", pExpectException, true);
      assertEquals("CampaignException class", CampaignException.class, e.getClass());
    }

  }

  @Test
  final public void test_checkConstraints() throws Exception {

    sub_test_checkConstraints(new DateTime(2007, 4, 23, 0, 0, 0, 0), new DateTime(2007, 5, 8, 0, 0, 0, 0), "08:15",
            "16:00", false);

    sub_test_checkConstraints(new DateTime(2007, 4, 23, 0, 0, 0, 0), new DateTime(2007, 5, 8, 0, 0, 0, 0), "20:15",
            "16:00", true);

    sub_test_checkConstraints(new DateTime(2007, 6, 23, 0, 0, 0, 0), new DateTime(2007, 5, 8, 0, 0, 0, 0), "08:15",
            "16:00", true);

    sub_test_checkConstraints(new DateTime(2007, 4, 23, 0, 0, 0, 0), new DateTime(2007, 5, 8, 0, 0, 0, 0), "08:15",
            null, false);

    sub_test_checkConstraints(new DateTime(2007, 4, 23, 0, 0, 0, 0), new DateTime(2007, 4, 23, 0, 0, 0, 0), "08:00",
            "08:00", true);

  } 

}
