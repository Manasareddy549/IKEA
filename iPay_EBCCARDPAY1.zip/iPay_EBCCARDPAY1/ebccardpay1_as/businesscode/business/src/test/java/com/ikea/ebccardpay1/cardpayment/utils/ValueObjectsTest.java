package com.ikea.ebccardpay1.cardpayment.utils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.client.vo.VoTransaction;
import com.ikea.mdsd.ValueObjects;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 */
public class ValueObjectsTest {

  @Test
  final public void test_assignToMapVo() throws Exception {
    VoTransaction vVoTransaction = new VoTransaction();

    vVoTransaction.setBuCode("XXX");

    Map vMap = ValueObjects.assignToMap(vVoTransaction);

    assertEquals("map", 29, vMap.size());
    assertEquals("buCode", "XXX", vMap.get("buCode"));
  }

  @Test
  final public void test_assignFromMapVo() throws Exception {
    VoTransaction vVoTransaction = new VoTransaction();

    Map vMap = new HashMap();
    vMap.put("buCode", "XXX");

    ValueObjects.assignFromMap(vVoTransaction, vMap);

    assertEquals("buCode", "XXX", vVoTransaction.getBuCode());
  }

  @Test
  final public void test_assignToMapBe() throws Exception {
    Transaction vTransaction = new Transaction();

    vTransaction.setBuCode("XXX");

    Map vMap = vTransaction.assignToMap();

    assertEquals("map", 30, vMap.size());
    assertEquals("buCode", "XXX", vMap.get("buCode"));
  }

  @Test
  final public void test_assignFromMapBe() throws Exception {
    Transaction vTransaction = new Transaction();

    Map vMap = new HashMap();
    vMap.put("buCode", "XXX");

    vTransaction.assignFromMap(vMap);

    assertEquals("buCode", "XXX", vTransaction.getBuCode());
  }

  @Test
  final public void test_assignToValueObject() throws Exception {
    Transaction vTransaction = new Transaction();
    VoTransaction vVoTransaction = new VoTransaction();

    vTransaction.setBuCode("XXX");

    ValueObjects.assignToValueObject(vVoTransaction, vTransaction);

    assertEquals("buCode", "XXX", vVoTransaction.getBuCode());
  }
}
