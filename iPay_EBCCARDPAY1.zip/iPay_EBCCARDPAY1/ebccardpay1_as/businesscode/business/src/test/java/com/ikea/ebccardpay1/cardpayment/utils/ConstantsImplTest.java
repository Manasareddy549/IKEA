/*
 * Created on 2006-maj-29
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.be.CardTypeConstant;
import com.ikea.ebccardpay1.cardpayment.be.SourceSystemConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardTypeConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefConstants;
import com.ikea.ebccardpay1.cardpayment.bef.BefReasonCode;
import com.ikea.ebccardpay1.cardpayment.bef.BefSourceSystemConstant;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class ConstantsImplTest extends EbcCardPay1TestSetup {

  private static final String EBC_NAME = "EBCCARDPAY1";
  private static final String BS_NAME = "BsCheckBalance";
  // Mock card BEF
  @Mock
  public BefCardTypeConstant mBefBefCardTypeConstantMock;
  @Mock
  public BefSourceSystemConstant mBefSourceSystemConstantMock;
  @Mock
  public BefConstants mBefConstantsMock;
  @Mock
  public BefReasonCode mBefReasonCodeMock;

  @Test
  final public void test_checkValidAmountType() throws Exception {
    sub_test_checkValidAmountType("CASH", false);
    sub_test_checkValidAmountType("DISCOUNT", false);
    sub_test_checkValidAmountType("cash", true);
    sub_test_checkValidAmountType("", true);
    sub_test_checkValidAmountType(null, true);
  }

  /**
   * @param pAmountType
   * @param pExpectedException
   * @throws Exception
   */
  final private void sub_test_checkValidAmountType(
          String pAmountType, boolean pExpectedException) throws Exception {
    ConstantsImpl vConstantsImpl = new ConstantsImpl(null,null, null, null);

    try {
      vConstantsImpl.checkValidAmountType(pAmountType);
      if(pExpectedException) {
        fail("Should throw exception");
      }
    } catch(Exception e) {
      if(!pExpectedException) {
        fail("Should not throw exception");
      }
      assertEquals("Wrong exception", AmountTypeNotSupportedException.class, e.getClass());
    }

  }

  @Test
  final public void test_isPointOfSale() throws Exception {

    // --- Set up mock behaviour ---

    List vExpectedOuput = new ArrayList();
    SourceSystemConstant vItem1 = new SourceSystemConstant();
    vItem1.setSourceSystem("ETT");
    vItem1.setPointOfSale(true);
    vExpectedOuput.add(vItem1);

    SourceSystemConstant vItem2 = new SourceSystemConstant();
    vItem2.setSourceSystem("TV�");
    vItem2.setPointOfSale(false);
    vExpectedOuput.add(vItem2);

    SourceSystemConstant vItem3 = new SourceSystemConstant();
    vItem3.setSourceSystem("TRE");
    vItem3.setPointOfSale(true);
    vExpectedOuput.add(vItem3);

    expect(mBefSourceSystemConstantMock.findAll()).andReturn(vExpectedOuput);

    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();
    ConstantsImpl vConstantsImpl = new ConstantsImpl(mBefBefCardTypeConstantMock, mBefSourceSystemConstantMock,
            mBefConstantsMock,mBefReasonCodeMock);
    vConstantsImpl.getAllSourceSystems();

    // --- Assert and verify the result ---
    Hashtable vActual = vConstantsImpl.getSourceSystems();
    assertEquals("Size not same,", vExpectedOuput.size(), vActual.size());

    assertEquals("First source system,", true, vConstantsImpl.isPointOfSale("ETT"));
    assertEquals("Second source system,", false, vConstantsImpl.isPointOfSale("TV�"));

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  @Test
  final public void test_getAllCardTypes() throws Exception {

    // --- Set up mock behaviour ---


    List vExpectedOuput = new ArrayList();
    CardTypeConstant vCardTypeConstant = new CardTypeConstant();
    vCardTypeConstant.setCardTypeDigit(1);
    vCardTypeConstant.setCardType("ETTA");
    vExpectedOuput.add(vCardTypeConstant);

    CardTypeConstant vCardTypeConstant2 = new CardTypeConstant();
    vCardTypeConstant2.setCardTypeDigit(2);
    vCardTypeConstant2.setCardType("TV�A");
    vExpectedOuput.add(vCardTypeConstant2);

    expect(mBefBefCardTypeConstantMock.findAll()).andReturn(vExpectedOuput);

    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();
    ConstantsImpl vConstantsImpl = new ConstantsImpl(mBefBefCardTypeConstantMock, mBefSourceSystemConstantMock,
            mBefConstantsMock,mBefReasonCodeMock);
    vConstantsImpl.getAllCardTypes();

    // --- Assert and verify the result ---
    Hashtable vActual = vConstantsImpl.getCardTypeDigits();
    assertEquals("Size not same,", vExpectedOuput.size(), vActual.size());
    assertEquals("First digit not same,", ((CardTypeConstant) vExpectedOuput.get(0)).getCardType(),
            vActual.get(new Integer(1)));
    assertEquals("Second digit not same,", ((CardTypeConstant) vExpectedOuput.get(1)).getCardType(),
            vActual.get(new Integer(2)));
    assertEquals("Third digit not same (should be null),", null, vActual.get(new Integer(3)));

    // Verify Mocks and MockEbcControl
    verifyAll();
  }

  @Test
  final public void test_getCardType() throws Exception {

    // --- Set up mock behaviour ---

    Hashtable vExpectedOuput = new Hashtable();
    vExpectedOuput.put(new Integer(1), "ETTA");
    vExpectedOuput.put(new Integer(2), "TV�A");

    // --- Run the test ---

    // Replay Mocks and MockEbcControl

    ConstantsImpl vConstantsImpl = new ConstantsImpl(mBefBefCardTypeConstantMock, mBefSourceSystemConstantMock,
            mBefConstantsMock,mBefReasonCodeMock);
    vConstantsImpl.setCardTypeDigits(vExpectedOuput);

    assertEquals("ETTA", vConstantsImpl.getCardType(1));
    assertEquals("TV�A", vConstantsImpl.getCardType(2));

    try {
      vConstantsImpl.getCardType(999);
      fail("Should throw exception.");
    } catch(Exception e) {
      assertEquals("Should throw InvalidCardTypeDigit", CardTypeDigitNotFoundException.class, e.getClass());
    }

    // --- Assert and verify the result ---


  }

}
