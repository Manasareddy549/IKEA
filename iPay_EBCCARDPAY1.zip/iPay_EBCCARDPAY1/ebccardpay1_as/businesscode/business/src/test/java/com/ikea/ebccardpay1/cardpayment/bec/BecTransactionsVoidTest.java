package com.ikea.ebccardpay1.cardpayment.bec;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Authorization;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.cardpayment.be.Transaction;
import com.ikea.ebccardpay1.cardpayment.be.TransactionFilter;
import com.ikea.ebccardpay1.cardpayment.bef.BefAmount;
import com.ikea.ebccardpay1.cardpayment.bef.BefAuthorization;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardTypeConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefConstants;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefLifeCycle;
import com.ikea.ebccardpay1.cardpayment.bef.BefReasonCodeTransaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefSourceSystemConstant;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransaction;
import com.ikea.ebccardpay1.cardpayment.bef.BefTransactionFilter;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironmentImpl;
import com.ikea.ebccardpay1.cardpayment.utils.CountrySetups;
import com.ikea.ebccardpay1.cardpayment.utils.Currencies;
import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.EncryptionDecryption;
import com.ikea.ebccardpay1.cardpayment.utils.PriorityEvaluator;
import com.ikea.ebccardpay1.cardpayment.utils.TransactionEnvironment;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.utils.UnitsCache;
import com.ikea.ebccardpay1.cardpayment.utils.UnitsCacheStaticImpl;
import com.ikea.ebccardpay1.cardpayment.utils.UserEnvironmentCache;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactory;
import com.ikea.ebccardpay1.cardpayment.utils.UtilsFactoryImpl;
import com.ikea.ebccardpay1.cardpayment.vo.*;
import com.ikea.ebcframework.services.EbcProperties;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(EasyMockRunner.class)
public class BecTransactionsVoidTest extends EbcCardPay1TestSetup {
	@Mock
	public BecFactory mBecFactoryMock;
	@Mock
	public BefFactory mBefFactoryMock;
	@Mock
	private BefReasonCodeTransaction mBefReasonCodeTransactionMock;
	@Mock
	public TimeSource mTimeSourceMock;
	@Mock
	public BefAmount mBefAmountMock;
	@Mock
	public BefCardNumber mBefCardNumberMock;
	@Mock
	public BefCardTypeConstant mBefCardTypeConstantMock;
	@Mock
	public BefSourceSystemConstant mBefSourceSystemConstantMock;
	@Mock
	public BefConstants mBefConstantsMock;
	@Mock
	public BefCard mBefCardMock;
	@Mock
	public BefLifeCycle mBefLifeCycleMock;
	@Mock
	public BefTransaction mBefTransactionMock;
	@Mock
	public CountrySetups mCountrySetupsMock;
	@Mock
	public BusinessUnitEnvironment mBusinessUnitEnvironmentMock;
	@Mock
	public TransactionEnvironment mTransactionEnvironmentMock;
	@Mock
	public BecReferenceCheck mBecReferenceCheckMock;
	@Mock
	public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();
	@Mock
	public Units mUnitsMock;
	@Mock
	public Constants mConstantsMock;
	@Mock
	public PriorityEvaluator mPriorityEvaluatorMock;
	@Mock
	public BefIpayBusinessUnits mBefIpayBusinessUnitsMock;
	@Mock
	public EbcProperties mEbcPropertiesMock;
	@Mock
	public BefAuthorization mBefAuthorizationMock;
	@Mock
	public BecCardNumber mBecCardNumberMock;
	@Mock
	public UtilsFactory mUtilsFactoryMock;
	@Mock
	public BefTransactionFilter mBefTransactionFilterMock;
	
	@Mock
	private EncryptionDecryption mEncryptionDecryption;

//This test case verifies the valid transaction has taken and upon that void action has been acted.
	@Test
	public void testVoidForAcknoledgedTransaction() throws Exception {


		BecTransactionsImpl vBecTransactionsImpl = new BecTransactionsImpl(mBecFactoryMock, mUtilsFactoryMock, null, null, mBefTransactionFilterMock, null,
				mBefAuthorizationMock, null,null, null, null);

		List vTransactions = new ArrayList();

		Transaction vTransaction1 = new Transaction();
		vTransaction1.setTransactionNo(1);
		vTransaction1.setTransactionType("REDEEM");
		vTransaction1.setReference(new Date().toString());
		vTransaction1.setBalanceChange(Amounts.amount(10));
		vTransaction1.setCardBalanceChange(Amounts.amount(10));
		vTransaction1.setRequestedAmount(Amounts.amount(100));
		vTransaction1.setRequestedCurrencyCode("SEK");
		vTransaction1.setFinancialType("DEBIT");
		vTransaction1.setSourceSystem("IRW");
		vTransaction1.setCancelled(false);
		vTransaction1.setBuType("STO");
		vTransaction1.setBuCode("011");
		vTransaction1.setCountryCode("SE");
		vTransaction1.setInsufficientAmount(true);
		vTransaction1.setEmployee("AAA");
		vTransaction1.setSwiped("N");
		vTransaction1.setPointOfSale("POS1");
		vTransaction1.setReceipt("POS12");


		CardNumber vCardNumber = new CardNumber();
		vCardNumber.setIssuer("627598");
		vCardNumber.setCardTypeDigit(2);
		vCardNumber.setAccountNumberEnc("00000000005");
		vCardNumber.setCheckDigit(3);



		Card vCard = new Card();
		vCard.setCardState(Constants.CARD_STATE_CONSTANT_BOUND);
		vCard.setCardType(Constants.CARD_TYPE_CONSTANT_GIFT);
		vCard.setCardNumber(vCardNumber);
		//vCard.setAmounts(pAmounts);

		Amount vAmount= new Amount();
		vAmount.setAmountId(1);
		vAmount.setAmountType("CASH");
		vAmount.setBuCode("011");
		vAmount.setBuType("STO");
		//vAmount.setCard(vCard);
		vAmount.setCurrentAmount(Amounts.amount(10));
		vAmount.setOriginalAmount(Amounts.amount(100));
		vAmount.setCard(vCard);

		vTransaction1.setAmount(vAmount);
		vTransaction1.setCard(vCard);
		vTransactions.add(vTransaction1);
		vBecTransactionsImpl.initTransactions(vTransactions);
		expect(mBecCardNumberMock.composeCardNumberString(vCard.getCardNumber())).andReturn("6275982000000000053");
		// Create a cardnumber string


		Authorization vAuthorization = new Authorization();
		//		vAuthorization.setAuthorizationNumber("455612");
		expect(mBefAuthorizationMock.findByTransactionNo(vTransaction1.getTransactionNo())).andReturn(null).times(2);
		expect(mBefAuthorizationMock.create()).andReturn(vAuthorization).times(2);
		mBefAuthorizationMock.save(vAuthorization);
		EasyMock.expectLastCall().times(2);

		expect(mUtilsFactoryMock.createTransactionEnvironment("IRW", vTransaction1)).andReturn(mTransactionEnvironmentMock);

		TransactionFilter vTransactionFilter = new TransactionFilter();
		expect(mBefTransactionFilterMock
				.findByTransactionNo(vTransaction1.getTransactionNo())).andReturn(vTransactionFilter);

		BecAmounts vBecAmounts = new BecAmountsImpl(mBecFactoryMock, mUnitsMock, mPriorityEvaluatorMock, mEbcPropertiesMock, mBefIpayBusinessUnitsMock,null);
		vBecAmounts.init(vCard, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);


		BecAmount vBecAmount = new BecAmountImpl(mBefAmountMock, new BecTransactionImpl(mBefTransactionMock,mBefReasonCodeTransactionMock,
				mConstantsMock, null,null,mEncryptionDecryption), mBefIpayBusinessUnitsMock );
		vBecAmount.init(vCard,vTransaction1.getAmount(), mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);

		expect(mBecFactoryMock.createBecAmounts()).andReturn(vBecAmounts);

		expect(mBecFactoryMock.createBecAmount()).andReturn(vBecAmount);
		expect(mBecFactoryMock.createBecReferenceCheck()).andReturn(mBecReferenceCheckMock);
		expect(mBecReferenceCheckMock.init(vCard, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock)).
		andReturn(mBecReferenceCheckMock);

		mBecReferenceCheckMock.checkAndCreate(true);
		expect(mBefAmountMock.create()).andReturn(vAmount);
		mBefAmountMock.save(vAmount);

		BecTransaction vBecTransaction= new BecTransactionImpl(mBefTransactionMock,mBefReasonCodeTransactionMock, mConstantsMock, mUtilsFactoryMock,null,mEncryptionDecryption);
		vBecTransaction.init(vCard, vAmount, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);

		expect(mBecFactoryMock.createBecTransaction()).andReturn(vBecTransaction);

		expect(mBefTransactionMock.create()).andReturn(vTransaction1);
		mBefTransactionMock.save(vTransaction1);

		//		TransactionFilter vTransactionFilter1= new TransactionFilter();
		//		vTransactionFilter1.setVoided(true);
		//		vTransactionFilter1.setTransactionNo(vTransaction1.getTransactionNo());
		//		vTransactionFilter1 mvTransactionFilter1=
		expect(mBefTransactionFilterMock.create()).andReturn(vTransactionFilter);
		//		//expect(mBefTransactionMock.create()).andReturn(vTransaction1);
		mBefTransactionFilterMock.save(vTransactionFilter);
		//BefTransactionFilter

		//	    mBefAmountMock.save(vAmount);
		//	    EasyMock.expectLastCall().once();

		//BecTransaction vBecTransaction= new BecTransactionImpl(mBefTransactionMock, mConstantsMock, mUtilsFactoryMock);


		expect(mTransactionEnvironmentMock.getReference()).andReturn(vTransaction1.getReference());
		expect(mTransactionEnvironmentMock.getSourceSystem()).andReturn("IRW").times(2);
		expect(mTransactionEnvironmentMock.getTransmissionDateTime()).andReturn(new Date());
		expect(mBusinessUnitEnvironmentMock.getCountryCode()).andReturn("SE");
		expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
		expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("011");
		expect(mTransactionEnvironmentMock.getEmployee()).andReturn("AAA").times(2);
		expect(mTransactionEnvironmentMock.getTransactionNo()).andReturn((long) 1).times(2);
		expect(mTransactionEnvironmentMock.getSwiped()).andReturn("N");
		expect(mTransactionEnvironmentMock.getPointOfSale()).andReturn("POS1");
		expect(mTransactionEnvironmentMock.getReceipt()).andReturn("POS12");
		expect(mBusinessUnitEnvironmentMock.getSalesDay()).andReturn("2016-05-05");

		expect(mCountrySetupsMock.getExpireDays("SE", vCard.getCardType())).andReturn(1);
		expect(mConstantsMock.isPointOfSale("IRW")).andReturn(true);

		expect(mBefIpayBusinessUnitsMock.findByPrimaryKey("STO", "011")).andReturn(null);
		// --- Replay ---
		expect(mEbcPropertiesMock.getString("FilterCountryToAllowReload","NOSOURCE")).andReturn("NOSOURCE");
		expect(mEbcPropertiesMock.getString("server_environment","production")).andReturn("production");

		replayAll();

		vBecTransactionsImpl.init(mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);
		vBecTransactionsImpl.mCard=vCard;
		vBecTransactionsImpl.mTransactions=vTransactions;
		//vBecTransaction.init(vTransaction1, mBusinessUnitEnvironmentMock, mTransactionEnvironmentMock);	    



		 vBecTransactionsImpl.voidTransactions("IRW", true, true);

	}
}



