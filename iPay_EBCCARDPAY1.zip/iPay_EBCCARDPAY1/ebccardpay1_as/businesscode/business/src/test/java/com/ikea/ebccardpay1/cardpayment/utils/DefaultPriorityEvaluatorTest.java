package com.ikea.ebccardpay1.cardpayment.utils;

import static junit.framework.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.common.Constants;


public class DefaultPriorityEvaluatorTest {

	@Test
	public void testWhenEvaluatePriorityOnEmptyCardThenReturnLowPriority() {

		DefaultPriorityEvaluator vEvaluator = new DefaultPriorityEvaluator();

		BigDecimal vPriority = vEvaluator.evaluatePriority(null,Constants.AMOUNT_PRIORITY_REFUND);
		assertEquals("Amount type wrong.", Priorities
				.priority(Constants.AMOUNT_PRIORITY_REFUND), vPriority);
	}
	

	@Test
	public void testWhenEvaluatePriorityWithMixedAmountsThenReturnCorrectPriority() throws Exception {

		Card vCard = new Card();
		Amount vAmount1 = new Amount();
		vAmount1.setPriority(new BigDecimal(Constants.AMOUNT_PRIORITY_REFUND));
		vAmount1.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		vCard.connectAmount(vAmount1);

		Amount vAmount2 = new Amount();
		vAmount2.setPriority(
			new BigDecimal(Constants.AMOUNT_PRIORITY_CAMPAIGN));
		vAmount2.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		vCard.connectAmount(vAmount2);

		Amount vAmount22 = new Amount();
		vAmount22.setPriority(
			new BigDecimal(
				Constants.AMOUNT_PRIORITY_CAMPAIGN
					+ Constants.AMOUNT_PRIORITY_INTERVAL));
		vAmount22.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		vCard.connectAmount(vAmount22);

		Amount vAmount3 = new Amount();
		vAmount3.setPriority(
			new BigDecimal(Constants.AMOUNT_PRIORITY_MASSLOAD));
		vAmount3.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		vCard.connectAmount(vAmount3);

		Amount vAmount4 = new Amount();
		vAmount4.setPriority(new BigDecimal(Constants.AMOUNT_PRIORITY_GIFT));
		vAmount4.setAmountType(Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT);
		vCard.connectAmount(vAmount4);

		
		DefaultPriorityEvaluator vEvaluator = new DefaultPriorityEvaluator();

		// --- Test ---
		BigDecimal vPriority = vEvaluator.evaluatePriority(vCard.getAmounts(),
				Constants.AMOUNT_PRIORITY_CAMPAIGN);

		assertEquals("Prio", Priorities.priority(101), vPriority);
	}
}
