/*
 * Created on 2006-aug-22
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.common.TimeSource;
import com.ikea.ebccardpay1.cardpayment.exception.BusinessUnitException;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import org.easymock.Mock;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;


/**
 * @author anms
 */
public class UnitsTest extends EbcCardPay1TestSetup {

    @Mock
    public TimeSource mTimeSourceMock;

    public UnitsCache mUnitsCache = new UnitsCacheStaticImpl();

    public Units mTested;


    @Test
    final public void test_checkValidCountryCode() throws Exception {
        sub_test_checkValidCountryCode("SE", false);
        sub_test_checkValidCountryCode("se", true);
        sub_test_checkValidCountryCode("XX", true);
        sub_test_checkValidCountryCode("", true);
        sub_test_checkValidCountryCode(null, true);
    }

    private void sub_test_checkValidCountryCode(
            String pCountryCode, boolean pExpectedException) throws Exception {

        UnitsImpl vUnitsImpl = new UnitsImpl(mTimeSourceMock, mUnitsCache);

        try {
            vUnitsImpl.checkValidCountryCode(pCountryCode);
            if (pExpectedException) {
                fail("Should throw exception");
            }
        } catch (Exception e) {
            if (!pExpectedException) {
                fail("Should not throw exception");
            }
            assertEquals("Wrong exception", BusinessUnitException.class, e.getClass());
        }
    }

    @Test
    final public void test_closedStores() throws Exception {
        // No stores closed
        sub_test_closedStores("2006-11-21 12:05:00", 0, null);

        // Austrailien stores except Brisbane (Brisbane do not have day light saving time!!)
        sub_test_closedStores("2006-12-21 16:05:00", 4, "[380, 382, 383, 384]");

        // Russian stores in Moscow
        sub_test_closedStores("2006-11-21 00:05:00", 4, "[335, 336, 341, 426]");

        // Asian stores in Shanghai
        sub_test_closedStores("2006-11-21 22:05:00", 2, "[801, 803]");

        // Most of Europe
        sub_test_closedStores("2006-11-23 03:05:00", 150, null);

        // Austrailien stores including Brisbane (winter time=no dayligt saving time)
        sub_test_closedStores("2006-06-21 17:05:00", 5, "[380, 381, 382, 383, 384]");
    }

    private void sub_test_closedStores(
            String pTestDate, int pExcptedListSize, String pExpectedList) throws Exception {

        Date vNow = Dates.parseDateTime(pTestDate).toDate();
        mUnitTestTimeSource.setCurrent(vNow);
        UnitsImpl vUnitsImpl = new UnitsImpl(mUnitTestTimeSource, mUnitsCache);

        List vActualList = vUnitsImpl.closedStores();
        List vBuCodeList = new ArrayList();

        for (Iterator i = vActualList.iterator(); i.hasNext(); ) {
            VoBusinessUnit vVoBusinessUnit = (VoBusinessUnit) i.next();
            vBuCodeList.add(vVoBusinessUnit.getBuCode());
        }

        assertEquals("list size", pExcptedListSize, vBuCodeList.size());
        if (pExpectedList != null) {
            assertEquals("list", pExpectedList, vBuCodeList.toString());
        }
    }

    @Test
    public void testGettingUnitsForCountryCode_SE() throws Exception {

        UnitsImpl underTest = new UnitsImpl(null, mUnitsCache);

        //Exec
        long start = System.currentTimeMillis();
        Collection actual = underTest.getUnitsForCountryCode("SE");
        long end = System.currentTimeMillis();

        long executionTime = end - start;
        System.out.println(executionTime);
        //Assert
        assertEquals(14, actual.size());

        for (Iterator iterator = actual.iterator(); iterator.hasNext(); ) {
            VoBusinessUnit object = (VoBusinessUnit) iterator.next();
            assertEquals("SE", object.getCountryCode());
        }

    }

    @Test
    public void testGettingUnitsForCountryCode_DE() throws Exception {

        UnitsImpl underTest = new UnitsImpl(null, mUnitsCache);

        //Exec
        Collection actual = underTest.getUnitsForCountryCode("DE");

        //Assert
        assertEquals(34, actual.size());
        for (Iterator iterator = actual.iterator(); iterator.hasNext(); ) {
            VoBusinessUnit object = (VoBusinessUnit) iterator.next();
            assertEquals("DE", object.getCountryCode());
        }
    }

    @Test
    public void testGettingUnitsForCountryCode_Null() throws Exception {

        UnitsImpl underTest = new UnitsImpl(null, mUnitsCache);

        //Exec
        Collection actual = underTest.getUnitsForCountryCode(null);

        //Assert
        assertEquals(0, actual.size());
    }

    @Test
    public void testGettingUnitsForCountryCode_NonExisting() throws Exception {

        UnitsImpl underTest = new UnitsImpl(null, mUnitsCache);

        //Exec
        Collection actual = underTest.getUnitsForCountryCode("Olle");

        //Assert
        assertEquals(0, actual.size());
    }

}
