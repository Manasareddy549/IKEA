package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.cardpayment.vo.VoCurrency;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class CurrenciesImplTest {

  @Test
  public void testAddToMaps() {
    CurrenciesImpl underTest = new CurrenciesImpl() {
      @Override
      protected void init() {
        //Do nothing
      }
    };

    underTest.addToMaps(new Iso4217("UY", "URUGUAY", "Uruguay Peso en Unidades Indexadas", "UYI"));

    List<VoCurrency> currencyForCountry = underTest.getCurrencyForCountry("UY");
    assertEquals("UYI", (currencyForCountry.get(0)).getCurrencyCode());

    List<VoCurrency> allVoCurrency = underTest.allVoCurrency();
    assertEquals(1, allVoCurrency.size());

    List<String> allCurrencyCodes = underTest.allCurrencyCodes();
    assertEquals("UYI", allCurrencyCodes.get(0));

    List<String> allCurrencyNames = underTest.allCurrencyNames();
    assertEquals("UYI, Uruguay Peso en Unidades Indexadas", allCurrencyNames.get(0));
  }

  @Test
  public void testInit() {
    CurrenciesImpl underTest = new CurrenciesImpl();

    List<VoCurrency> currencyForCountry = underTest.getCurrencyForCountry("UY");
    assertEquals("UYU", currencyForCountry.get(0).getCurrencyCode());
    assertEquals("UYI", currencyForCountry.get(1).getCurrencyCode());

    assertEquals(159, underTest.allCurrencyCodes().size());
    assertEquals(159, underTest.allCurrencyNames().size());
    assertEquals(168, underTest.allVoCurrency().size());

  }

}
