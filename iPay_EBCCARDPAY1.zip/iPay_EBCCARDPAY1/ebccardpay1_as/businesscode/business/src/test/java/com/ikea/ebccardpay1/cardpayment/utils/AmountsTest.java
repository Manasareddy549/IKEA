/*
 * Created on 2006-aug-22
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.junit.Test;

import com.ikea.ebccardpay1.common.Amounts;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author anms
 */
public class AmountsTest {

  @Test
  final public void test_multiply() throws Exception {

    assertEquals("", Amounts.amount(20), Amounts.multiply(Amounts.amount(200), new BigDecimal(0.1)));
    assertEquals("", Amounts.amount(2, 0), Amounts.multiply(Amounts.amount(200), new BigDecimal(0.01)));

    assertEquals("", Amounts.amount(7, 2), Amounts.multiply(Amounts.amount(1, 2), new BigDecimal(6.93)));


  }

  @Test
  public void testMultiply_EuroToGbp() throws Exception {
    BigDecimal euroAmount = new BigDecimal("36.52");
    BigDecimal euroToGbpExchangeRate = new BigDecimal("0.95");

    BigDecimal expectedGbpAmount = new BigDecimal("34.69");

    assertEquals(expectedGbpAmount, Amounts.multiply(euroAmount, euroToGbpExchangeRate));
  }

  @Test
  final public void test_divide() throws Exception {

    assertEquals("", Amounts.amount(20000), Amounts.divide(Amounts.amount(200), new BigDecimal(0.01)));
    assertEquals("", Amounts.amount(9900), Amounts.divide(Amounts.amount(99), new BigDecimal(0.01)));
    assertEquals("", Amounts.amount(99), Amounts.divide(Amounts.amount(99, 2), new BigDecimal(0.01)));
    assertEquals("", Amounts.amount(99, 2), Amounts.divide(Amounts.amount(99, 2), new BigDecimal(1.000009)));
    assertEquals("", Amounts.amount(99, 2), Amounts.divide(Amounts.amount(99, 2), new BigDecimal(0.999)));

  }

  @Test
  final public void test_unscaledAmount() throws Exception {

    assertEquals("scale 0,", 99L, Amounts.unscaledAmount(Amounts.amount(9900, 2), 0));
    assertEquals("scale 2,", 9900L, Amounts.unscaledAmount(Amounts.amount(9900, 2), 2));
    assertEquals("scale 2,", 990000L, Amounts.unscaledAmount(Amounts.amount(9900, 0), 2));
    assertEquals("scale 2,", 9968L, Amounts.unscaledAmount(Amounts.amount(9968, 2), 2));
    assertEquals("scale 2,", -57338L, Amounts.unscaledAmount(Amounts.amount(-57338, 2), 2));
    assertEquals("scale 2,", -57338L, Amounts.unscaledAmount(Amounts.amount(-573380, 3), 2));

    try {
      assertEquals("scale 0,", 0, Amounts.unscaledAmount(Amounts.amount(9968, 2), 0));
      fail("Should throw ArithmeticException.");
    } catch(Exception e) {
      assertEquals(ArithmeticException.class, e.getClass());
    }

    assertEquals("scale 1,", 994, Amounts.unscaledAmount(Amounts.amount(9940, 2), 1));

    try {
      assertEquals("scale 0,", 0, Amounts.unscaledAmount(Amounts.amount(9940, 2), 0));
      fail("Should throw ArithmeticException.");
    } catch(Exception e) {
      assertEquals(ArithmeticException.class, e.getClass());
    }

  }

  @Test
  final public void test_scale() throws Exception {

    assertEquals("scale 2", Amounts.amount(99), Amounts.amount(9900, 2));
    assertEquals("scale 1", Amounts.amount(99), Amounts.amount(990, 1));
    assertEquals("scale 0", Amounts.amount(99), Amounts.amount(99, 0));
    assertEquals("scale 3", Amounts.amount(99), Amounts.amount(99000, 3));

    try {
      assertEquals("scale 3", Amounts.amount(99), Amounts.amount(99001, 3));
      fail("Should throw ArithmeticException.");
    } catch(Exception e) {
      assertEquals(ArithmeticException.class, e.getClass());
    }

    assertEquals("scale 2", "10.78", "" + Amounts.amount(1078, 2));
    assertEquals("scale 3", "10.78", "" + Amounts.amount(10780, 3));
    assertEquals("scale 3", "-10.78", "" + Amounts.amount(-10780, 3));
    assertEquals("scale 1", "-10.50", "" + Amounts.amount(-105, 1));

  }

  private void subtest_isLessOrEqual(
          BigDecimal vLeft, BigDecimal vRight, boolean vValid) throws Exception {

    assertEquals("isLessOrEqual " + vLeft + " <= " + vRight, vValid, Amounts.isLessOrEqual(vLeft, vRight));

  }

  @Test
  final public void test_isLessOrEqual() throws Exception {

    subtest_isLessOrEqual(Amounts.amount(10), Amounts.amount(1000), true);
    subtest_isLessOrEqual(Amounts.amount(0), Amounts.amount(0), true);

    subtest_isLessOrEqual(new BigDecimal(10.02), new BigDecimal(10.03), true);
    subtest_isLessOrEqual(new BigDecimal(10.03), new BigDecimal(10.02), false);
    subtest_isLessOrEqual(new BigDecimal(10.0), new BigDecimal(10.0), true);

  }

  private void subtest_add(
          BigDecimal vLeft, BigDecimal vRight, BigDecimal vResult) throws Exception {
    assertEquals("add " + vLeft + " + " + vRight, vResult, Amounts.add(vLeft, vRight));

  }

  @Test
  final public void test_add() throws Exception {

    subtest_add(Amounts.zero(), Amounts.zero(), Amounts.zero());
    subtest_add(new BigDecimal(0), new BigDecimal(0), Amounts.zero());
    subtest_add(new BigDecimal(0.0), new BigDecimal(0.0), Amounts.zero());
    subtest_add(new BigDecimal(0.5), new BigDecimal(-0.5), Amounts.zero());
    subtest_add(new BigDecimal(10), new BigDecimal(-10), Amounts.zero());
    subtest_add(Amounts.amount(10), Amounts.amount(100), Amounts.amount(110));
    subtest_add(Amounts.amount(-10), Amounts.amount(-100), Amounts.amount(-110));
    subtest_add(Amounts.amount(10), Amounts.amount(-100), Amounts.amount(-90));
    subtest_add(Amounts.amount(0), Amounts.amount(999999999), Amounts.amount(999999999));
    subtest_add(Amounts.amount(1), Amounts.amount(999999999999998L), Amounts.amount(999999999999999L));

    try {
      subtest_add(Amounts.amount(100), new BigDecimal(0.000002), null);
      fail("Should throw ArithmeticException.");
    } catch(Exception e) {
      assertEquals(ArithmeticException.class, e.getClass());
    }

  }

  private void subtest_subtract(
          BigDecimal vLeft, BigDecimal vRight, BigDecimal vResult) throws Exception {
    assertEquals("subtract " + vLeft + " - " + vRight, vResult, Amounts.subtract(vLeft, vRight));

  }

  @Test
  final public void test_subtract() throws Exception {

    subtest_subtract(Amounts.zero(), Amounts.zero(), Amounts.zero());
    subtest_subtract(new BigDecimal(0), new BigDecimal(0), Amounts.zero());
    subtest_subtract(new BigDecimal(0.0), new BigDecimal(0.0), Amounts.zero());
    subtest_subtract(new BigDecimal(0.5), new BigDecimal(0.5), Amounts.zero());
    subtest_subtract(new BigDecimal(10), new BigDecimal(10), Amounts.zero());
    subtest_subtract(Amounts.amount(10), Amounts.amount(100), Amounts.amount(-90));
    subtest_subtract(Amounts.amount(-10), Amounts.amount(-100), Amounts.amount(90));
    subtest_subtract(Amounts.amount(10), Amounts.amount(-100), Amounts.amount(110));
    subtest_subtract(Amounts.amount(999999999), Amounts.amount(0), Amounts.amount(999999999));
    subtest_subtract(Amounts.amount(999999999999999L), Amounts.amount(1), Amounts.amount(999999999999998L));

    try {
      subtest_subtract(Amounts.amount(100), new BigDecimal(0.000002), null);
      fail("Should throw ArithmeticException.");
    } catch(Exception e) {
      assertEquals(ArithmeticException.class, e.getClass());
    }

  }

}
