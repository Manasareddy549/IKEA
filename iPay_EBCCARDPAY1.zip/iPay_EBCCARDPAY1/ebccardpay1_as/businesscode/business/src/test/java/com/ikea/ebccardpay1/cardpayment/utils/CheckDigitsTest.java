/*
 * Created on 2006-aug-22
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import org.junit.Test;

import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * @author anms
 * 
 */
public class CheckDigitsTest extends EbcCardPay1TestSetup {

	@Test
	final public void test_generateAuthorizationNumber() throws Exception {

		assertEquals("authorizationNumber", "11221", CheckDigits
				.generateAuthorizationNumber("9900"));

	}
  @Test
	final public void test_generateAuthorizationNumberRandomized()
			throws Exception {

		assertTrue(CheckDigits.isValidCheckDigit(CheckDigits
				.generateAuthorizationNumber()));

	}
  @Test
	final public void test_generateAuthorizationNumber_1234() throws Exception {
		assertEquals("authorizationNumber", "34561", CheckDigits
				.generateAuthorizationNumber("1234"));

	}
  @Test
	final public void test_generateAuthorizationNumber_5678() throws Exception {
		assertEquals("authorizationNumber", "78907", CheckDigits
				.generateAuthorizationNumber("5678"));

	}
  @Test
	final public void test_generateAuthorizationNumber_9123() throws Exception {
		assertEquals("authorizationNumber", "13458", CheckDigits
				.generateAuthorizationNumber("9123"));

	}
  @Test
	final public void test_generateAuthorizationNumber_7941() throws Exception {
		assertEquals("authorizationNumber", "91637", CheckDigits
				.generateAuthorizationNumber("7941"));

	}
  @Test
	final public void test_generateAuthorizationNumber_7942() throws Exception {
		assertEquals("authorizationNumber", "91645", CheckDigits
				.generateAuthorizationNumber("7942"));

	}
  @Test
	final public void test_generateAuthorizationNumber_0358() throws Exception {
		assertEquals("authorizationNumber", "25700", CheckDigits
				.generateAuthorizationNumber("0358"));

	}
}
