package com.ikea.ebccardpay1.cardpayment.bec;

import static org.junit.Assert.*;

import org.junit.Test;

public class BecMultipleSingleLoadImplTest {

	@Test
	public void whenInvalidAmountsThenThrowException() throws Exception {
		BecMultipleSingleLoadImpl vBec = new BecMultipleSingleLoadImpl();
		vBec.validateAmount(".1");
		vBec.validateAmount("0.1");
		vBec.validateAmount("10");
		vBec.validateAmount("10.1");
		vBec.validateAmount("10.12");
		vBec.validateAmount("10.123");

		try {
			vBec.validateAmount(",1");
			fail("Should throw eception");
		} catch (IllegalArgumentException e) {

		}
		try {
			vBec.validateAmount("0,1");
			fail("Should throw eception");
		} catch (IllegalArgumentException e) {

		}
		try {
			vBec.validateAmount("10,1");
			fail("Should throw eception");
		} catch (IllegalArgumentException e) {

		}
		try {
			vBec.validateAmount("10,12");
			fail("Should throw eception");
		} catch (IllegalArgumentException e) {

		}
		try {
			vBec.validateAmount("10,123");
			fail("Should throw eception");
		} catch (IllegalArgumentException e) {

		}
	}
}
