package com.ikea.ebccardpay1.cardpayment.bec;

import static org.easymock.EasyMock.expect;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.ikea.ebccardpay1.cardpayment.be.Amount;
import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.be.CardNumber;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebccardpay1.cardpayment.utils.BusinessUnitEnvironment;

@RunWith(EasyMockRunner.class)
public class BecPromotionalCardsTest extends EbcCardPay1TestSetup{
	@Mock
	public BusinessUnitEnvironment mBusinessUnitEnvironmentMock;
	@Test
	public void testRedeemPromotionalCardsInSameCountry() throws Exception {
		CardNumber vCardNumber = new CardNumber();
		vCardNumber.setIssuer("627598");
		vCardNumber.setCardTypeDigit(9);
		vCardNumber.setAccountNumberEnc("00000000007");
		vCardNumber.setCheckDigit(3);



		Card vCard = new Card();
		vCard.setCardState(Constants.CARD_STATE_CONSTANT_BOUND);
		vCard.setCardType(Constants.CARD_TYPE_CONSTANT_VOUCHER);
		vCard.setCardNumber(vCardNumber);
		vCard.setCountryCode("SE");
		//vCard.setAmounts(pAmounts);

		Amount vAmount= new Amount();
		vAmount.setAmountId(1);
		vAmount.setAmountType("DISCOUNT");
		vAmount.setBuCode("011");
		vAmount.setBuType("STO");
		//vAmount.setCard(vCard);
		vAmount.setCurrentAmount(Amounts.amount(100));
		vAmount.setOriginalAmount(Amounts.amount(100));
		vAmount.setCard(vCard);
		expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
		expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("268");
		expect(mBusinessUnitEnvironmentMock.getCountryCode()).andReturn("SE");
		
		
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		underTest.init(vCard, mBusinessUnitEnvironmentMock, null);
		
		
	}
	@Test
	public void testRedeemPromotionalCardsInForeignCountry() throws Exception {
		CardNumber vCardNumber = new CardNumber();
		vCardNumber.setIssuer("627598");
		vCardNumber.setCardTypeDigit(9);
		vCardNumber.setAccountNumberEnc("00000000007");
		vCardNumber.setCheckDigit(3);



		Card vCard = new Card();
		vCard.setCardState(Constants.CARD_STATE_CONSTANT_BOUND);
		vCard.setCardType(Constants.CARD_TYPE_CONSTANT_VOUCHER);
		vCard.setCardNumber(vCardNumber);
		vCard.setCountryCode("SE");
		//vCard.setAmounts(pAmounts);

		Amount vAmount= new Amount();
		vAmount.setAmountId(1);
		vAmount.setAmountType("DISCOUNT");
		vAmount.setBuCode("011");
		vAmount.setBuType("STO");
		//vAmount.setCard(vCard);
		vAmount.setCurrentAmount(Amounts.amount(100));
		vAmount.setOriginalAmount(Amounts.amount(100));
		vAmount.setCard(vCard);
		expect(mBusinessUnitEnvironmentMock.getBuType()).andReturn("STO");
		expect(mBusinessUnitEnvironmentMock.getBuCode()).andReturn("406");
		expect(mBusinessUnitEnvironmentMock.getCountryCode()).andReturn("ES");
		
		
		BecAmountsImpl underTest = new BecAmountsImpl(null,null,null,null,null,null);
		underTest.init(vCard, mBusinessUnitEnvironmentMock, null);
		
	}

}
