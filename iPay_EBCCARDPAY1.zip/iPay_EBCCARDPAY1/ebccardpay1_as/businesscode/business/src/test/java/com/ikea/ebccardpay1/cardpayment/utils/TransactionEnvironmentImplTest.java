/*
 * Created on 2006-sep-04
 *
 */
package com.ikea.ebccardpay1.cardpayment.utils;

import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebcframework.persistence.keygenerator.IkeaKeyGenerator;
import com.ikea.ebcframework.services.BsContext;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.util.ReflectionTestUtils;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

//import com.ikea.ebccardpay1.EbcCardPay1TestCase;

/**
 * @author anms
 */
@RunWith(EasyMockRunner.class)
public class TransactionEnvironmentImplTest extends EbcCardPay1TestSetup {

  protected static final String EBC_NAME = "EBCCARDPAY1";

  @Mock
  private IkeaKeyGenerator ikeaKeyGeneratorMock;

  @Mock
  private BsContext bsContextMock;

  @Test
  public void test_getTransactionNo() throws Exception {

    long vNextNumber = 78;
    expect(bsContextMock.getEbcName()).andReturn(EBC_NAME);
    expect(ikeaKeyGeneratorMock.getNextKey(EBC_NAME, "TRANSACTION_NO")).andReturn(vNextNumber);

    replayAll();
    TransactionEnvironmentImpl vTested = new TransactionEnvironmentImpl(null, null, null, false, null, null, null,
            null, 0, null, null);

    ReflectionTestUtils.setField(vTested, "mIkeaKeyGenerator", ikeaKeyGeneratorMock);
    ReflectionTestUtils.setField(vTested, "mBsContext", bsContextMock);
    long vActual = vTested.getTransactionNo();

    assertEquals("transaction no,", vNextNumber, vActual);
    verifyAll();
  }

  @Test
  public void test_getTransactionNo_exception() throws Exception {

    expect(bsContextMock.getEbcName()).andReturn(EBC_NAME);
    expect(ikeaKeyGeneratorMock.getNextKey(EBC_NAME, "TRANSACTION_NO")).andThrow(new IllegalStateException("Excepted " +
            "exception in unit test."));

    replayAll();
    TransactionEnvironmentImpl vTested = new TransactionEnvironmentImpl(null, null, null, false, null, null, null,
            null, 0, null, null);
    ReflectionTestUtils.setField(vTested, "mIkeaKeyGenerator", ikeaKeyGeneratorMock);
    ReflectionTestUtils.setField(vTested, "mBsContext", bsContextMock);
    try {
      vTested.getTransactionNo();

      fail("Should throw IllegalStateException.");
    } catch(Exception e) {
      assertEquals(IllegalStateException.class, e.getClass());

    }
    verifyAll();
  }

}
