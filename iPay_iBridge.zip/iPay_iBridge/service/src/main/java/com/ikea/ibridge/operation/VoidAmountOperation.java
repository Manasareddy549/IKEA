/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.List;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsVoidAmount;
import com.ikea.ebccardpay1.client.vo.VoCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoManualTransaction;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 */
public class VoidAmountOperation implements Operation {
    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	/**
	 * Log category for messages
	 */
	private static final Logger mLog = 
		LoggerFactory.getLogger(VoidAmountOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing operation void amount");

		// Create card entry VO
		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setSwiped(pRequestInfo.isSwiped());
		vVoCardEntry.setCardNumberString(pRequestInfo.getCardNumber());

		// Create environment VO
		VoEnvironment vVoEnvironment = new VoEnvironment();
		vVoEnvironment.setOffline(false);
		vVoEnvironment.setAutoAcknowledge(pRequestInfo.isAutoAcknowledge());

		// Create manual transaction VO
		VoManualTransaction vVoManualTransaction = new VoManualTransaction();
		if (Constants
			.TRANSACTION_TYPE_CONSTANT_LOAD
			.equals(pRequestInfo.getTransactionType())) {

			vVoManualTransaction.setAmount(
				Amounts.amount(
					pRequestInfo.getLoadAmountInteger(),
					pRequestInfo.getLoadAmountDecimals()));
			vVoManualTransaction.setCurrencyCode(
				pRequestInfo.getLoadAmountCurrency());
			vVoManualTransaction.setTransactionType(
				Constants.TRANSACTION_TYPE_CONSTANT_VOID_LOAD);
		} else {
			vVoManualTransaction.setAmount(
				Amounts.amount(
					pRequestInfo.getRequestAmountInteger(),
					pRequestInfo.getRequestAmountDecimals()));
			vVoManualTransaction.setCurrencyCode(
				pRequestInfo.getRequestAmountCurrency());
			vVoManualTransaction.setTransactionType(
				Constants.TRANSACTION_TYPE_CONSTANT_VOID_REDEEM);
		}

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());
		vVoOriginator.setPointOfSale(pRequestInfo.getPointOfSale());
		vVoOriginator.setReceipt(pRequestInfo.getReceipt());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(pRequestInfo.getTransmissionDateTime());

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create service
		BsVoidAmount vBsVoidAmount = new BsVoidAmount();

		// Set input VO
		vBsVoidAmount.setVoCardEntry(vVoCardEntry);
		vBsVoidAmount.setVoEnvironment(vVoEnvironment);
		vBsVoidAmount.setVoManualTransaction(vVoManualTransaction);
		vBsVoidAmount.setVoOriginator(vVoOriginator);
		vBsVoidAmount.setVoReference(vVoReference);
		vBsVoidAmount.setVoSourceSystem(vVoSourceSystem);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
		bsExecuter.executeBs(vBsVoidAmount,"Originator");

		// Check for application errors
		List vApplErrors = vBsVoidAmount.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}
		
		
		// Read response
		VoCard vVoCard = vBsVoidAmount.getVoCard();

		pResponseInfo.setBalanceAmount(vVoCard.getBalanceAmount());
		pResponseInfo.setBalanceCurrencyCode(vVoCard.getCurrencyCode());
		pResponseInfo.setPaidAmount(Amounts.zero());
		pResponseInfo.setBalanceDate(vVoCard.getBalanceDateTime());
		pResponseInfo.setExpireDate(vVoCard.getExpireDate());

		

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing operation void amount in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		pResponseInfo.setPaidAmount(Amounts.zero());
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
