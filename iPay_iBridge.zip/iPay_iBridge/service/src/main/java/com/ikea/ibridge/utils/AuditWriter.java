/*
 * Created on 2007-apr-13
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utils;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AuditWriter implements Appendable, Flushable, Closeable {

	private Writer mNext = null;
	private StringBuffer mBuffer = new StringBuffer();

	/**
	 * @param pNext
	 */
	public AuditWriter(Writer pNext) {
		mNext = pNext;
	}

	/* (non-Javadoc)
	 * @see java.lang.Appendable#append(java.lang.CharSequence)
	 */
	public Appendable append(CharSequence arg0) throws IOException {
		mBuffer.append(arg0);
		return mNext.append(arg0);
	}

	/* (non-Javadoc)
	 * @see java.lang.Appendable#append(java.lang.CharSequence, int, int)
	 */
	public Appendable append(CharSequence arg0, int arg1, int arg2)
		throws IOException {
		mBuffer.append(arg0, arg1, arg2);
		return mNext.append(arg0, arg1, arg2);
	}

	/* (non-Javadoc)
	 * @see java.lang.Appendable#append(char)
	 */
	public Appendable append(char arg0) throws IOException {
		mBuffer.append(arg0);
		return mNext.append(arg0);
	}

	/* (non-Javadoc)
	 * @see java.io.Closeable#close()
	 */
	public void close() throws IOException {
		mNext.close();
	}

	/* (non-Javadoc)
	 * @see java.io.Flushable#flush()
	 */
	public void flush() throws IOException {
		mNext.flush();

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return mBuffer.toString();
	}

}
