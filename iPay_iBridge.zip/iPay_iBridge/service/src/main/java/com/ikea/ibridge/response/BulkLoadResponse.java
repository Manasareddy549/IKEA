/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BulkLoadResponse extends XmlResponse {

	private CalypsoCountries mCalypsoCountries = null;
	
	public BulkLoadResponse(CalypsoCountries pCalypsoCountries) {
		super();
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<BulkloadResponse>\n");

		// Source system tags
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);

		/*int vBalanceDecimals = 2;
		long vBalance = 0;
		if (pResponseInfo.getBalanceAmount() != null) {
			vBalanceDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getBalanceCurrencyCode());
			
			vBalance = getRoundedUnscaledAmount(pResponseInfo.getBalanceAmount(), vBalanceDecimals);
		}*/
		
		pAppendable.append("<card>\n");
		pAppendable.append(Tags.tag("fromCardNumber", pResponseInfo.getFromCardNumberString()));
		pAppendable.append(Tags.tag("UntilCardNumber", pResponseInfo.getUntilCardNumberString()));
		pAppendable.append(Tags.tag("TotalCards", pResponseInfo.getLockCount()));
		pAppendable.append("</card>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag("AmountOnCard", pResponseInfo.getAmount()));
		pAppendable.append(Tags.tag("TotalAmount", pResponseInfo.getTotalAmount()));
		pAppendable.append(
			Tags.tag("currency", pResponseInfo.getCurrencyCode()));
		pAppendable.append("</amount>\n");
	
		pAppendable.append(Tags.tag("MassLoadexpires", pResponseInfo.getExpiryDate()));

		pAppendable.append("</BulkloadResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
		//
	}
}
