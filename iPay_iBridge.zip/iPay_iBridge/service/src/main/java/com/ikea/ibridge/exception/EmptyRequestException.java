/*
 * Created on 2007-jun-18
 *
 */
package com.ikea.ibridge.exception;

/**
 * @author anms
 *
 */
public class EmptyRequestException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 860121513401674595L;

	/**
	 * 
	 * @param pClass
	 * @param pMessage
	 */
	public EmptyRequestException(String pMessage) {
		super(pMessage);
	}

}
