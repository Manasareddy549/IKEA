package com.ikea.ibridge.utils;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.error.ApplicationErrorParam;

public class IbridgeError {
	private String mEbcName;
    public String getEbcName() {
		return mEbcName;
	}


	public void setEbcName(String mEbcName) {
		this.mEbcName = mEbcName;
	}


	public int getErrorCode() {
		return mErrorCode;
	}


	public void setErrorCode(int mErrorCode) {
		this.mErrorCode = mErrorCode;
	}


	public String getMessage() {
		return mMessage;
	}


	public void setMessage(String mMessage) {
		this.mMessage = mMessage;
	}
	 public List<ApplicationErrorParam> getParams() {
	        return Collections.unmodifiableList(mParams);
	 }


	private int mErrorCode;
    private String mMessage;
    private List<ApplicationErrorParam> mParams = new LinkedList<ApplicationErrorParam>();
    public void addParam(List<ApplicationErrorParam> list) {
        mParams.addAll(list);
    }
	
	 public IbridgeError(ApplicationError error) {
		 
		 setEbcName(error.getEbcName());
		 setErrorCode(error.getErrorCode());
		 setMessage(error.getMessage());
		 addParam(error.getParams());
	        
	    }
	 	
	    
	    public String toString() {
	        String head = MessageFormat.format("[ApplicationError|{0}: code=\"{1}\", message=\"{2}\"", getEbcName(),
	                Integer.toString(getErrorCode()), getMessage());

	        StringBuilder vStr = new StringBuilder(head);

	        List<ApplicationErrorParam> params = getParams();
	        vStr.append(" Params [");
	        if (params != null) {
	            vStr.append(StringUtils.join(params, ", "));
	        }
	        vStr.append("]");
	        return vStr.toString();
	    }

}
