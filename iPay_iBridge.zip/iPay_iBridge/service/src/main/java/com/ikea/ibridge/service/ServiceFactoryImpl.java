package com.ikea.ibridge.service;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Executors;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.operation.OperationFactory;
import com.ikea.ibridge.request.RequestFactory;
import com.ikea.ibridge.response.ResponseFactory;

/**
 * 
 * @author snug
 *
 * Implements the ServiceFactory interface and provides access
 * to instances of Service and ServiceRequest classes
 * 
 */
public class ServiceFactoryImpl implements ServiceFactory {

	/**
	 * Dependencies
	 */
	private final RequestFactory mRequestFactory;
	private final ResponseFactory mResponseFactory;
	private final OperationFactory mOperationFactory;

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.ServiceFactory#createService()
	 */
	public Service createService() {
		return new ServiceImpl(
			Executors.newCachedThreadPool(Executors.defaultThreadFactory()),
			this);
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.ServiceFactory#createServiceRequest(java.net.Socket, long, long)
	 */
	public ServiceRequest createServiceRequest(
		Socket pSocket,
		long pRequestDelay,
		long pResponseDelay)
		throws IkeaException {

		try {
			Object vWriter = mRequestFactory.createWriter(pSocket);
			return new ServiceRequestImpl(
				pSocket,
				mRequestFactory.createReadable(pSocket),
				(Appendable) vWriter,
				(Flushable) vWriter,
				(Closeable) vWriter,
				mRequestFactory.createCharBuffer(),
				mRequestFactory.createRequestInfo(),
				mResponseFactory.createResponseInfo(),
				mRequestFactory.createInitialRequest(),
				mOperationFactory,
				mResponseFactory,
				pRequestDelay,
				pResponseDelay);
		} catch (IOException e) {
			throw new IkeaException( e);
		}
	}

	/**
	 * Constructs a ServiceFactoryImpl with the needed dependecies injected
	 * 
	 * @param pRequestFactory To provide access to request related classes
	 * @param pResponseFactory To provide access to response related classes
	 * @param pOperationFactory To provide access to operation related classes
	 */
	public ServiceFactoryImpl(
		RequestFactory pRequestFactory,
		ResponseFactory pResponseFactory,
		OperationFactory pOperationFactory) {

		// Inject dependencies
		mRequestFactory = pRequestFactory;
		mResponseFactory = pResponseFactory;
		mOperationFactory = pOperationFactory;
	}

}
