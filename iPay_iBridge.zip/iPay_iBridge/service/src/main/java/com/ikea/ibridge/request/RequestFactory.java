/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.io.IOException;
import java.net.Socket;
import java.nio.CharBuffer;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface RequestFactory {
	/**
	 * Create a InitialRequest instance.
	 * @return
	 */
	Request createInitialRequest();

	/**
	 * Create a XMLRequest instance.
	 * @return
	 */
	Request createXMLRequest();

	/**
	 * Create a CalypsoRequest instance.
	 * @return
	 */
	Request createCalypsoRequest();

	/**
	 * 
	 * @param pSocket
	 * @return
	 */
	Readable createReadable(Socket pSocket) throws IOException;

	/**
	 * 
	 * @param pSocket
	 * @return
	 */
	Object createWriter(Socket pSocket) throws IOException;

	/**
	 * 
	 * @return
	 */
	CharBuffer createCharBuffer();

	/**
	 * 
	 * @return
	 */
	RequestInfo createRequestInfo();
}
