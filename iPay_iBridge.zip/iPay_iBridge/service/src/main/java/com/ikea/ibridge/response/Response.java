/*
 * Created on 2006-maj-09
 *
 */
package com.ikea.ibridge.response;

import java.io.IOException;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.request.RequestInfo;

/**
 * @author snug
 *
 */
public interface Response {

	static final String RESPONSE_CODE_NORMAL = "NORMAL";
	static final String RESPONSE_CODE_ERROR = "ERROR";

	static final String ERROR_TYPE_INVALID_CARD = "INVALID_CARD";
	static final String ERROR_TYPE_INVALID_PIN = "INVALID_PIN";
	static final String ERROR_TYPE_TRY_AGAIN = "TRY_AGAIN";
	static final String ERROR_TYPE_CALL_CENTER = "CALL_CENTER";

	static final String ERROR_TYPE = "error.type";
	static final String ERROR_MESSAGE = "error.message";
	static final String ERROR_DETAILS = "error.details";

	/**
	 * 
	 * @param pAppendable
	 * @param pResponseInfo
	 * @throws IkeaException
	 */
	void write(Appendable pAppendable, RequestInfo pRequestInfo,
			ResponseInfo pResponseInfo) throws IkeaException, IOException;
}
