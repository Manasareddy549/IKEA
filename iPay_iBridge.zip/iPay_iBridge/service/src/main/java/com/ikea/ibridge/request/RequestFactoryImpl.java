/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.CharBuffer;

import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.response.ResponseFactory;
import com.ikea.ibridge.utils.AuditWriter;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RequestFactoryImpl implements RequestFactory {
	private static final int ALLOCATE_BUFFER_SIZE = 1024;
	/**
	 * Dependencies
	 */
	private final ResponseFactory mResponseFactory;
	private final ConfigurationFactory mConfigurationFactory;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public RequestFactoryImpl(
		ResponseFactory pResponseFactory,
		ConfigurationFactory pConfigurationFactory) {

		mResponseFactory = pResponseFactory;
		mConfigurationFactory = pConfigurationFactory;
	}

	/**
	 */
	public Request createInitialRequest() {
		return new InitialRequest(this);
	}

	/**
	 */
	public Request createXMLRequest() {
		return new XmlRequest(
			mResponseFactory,
			mConfigurationFactory.getConfiguration());
	}

	/**
	 */
	public Request createCalypsoRequest() {
		return new CalypsoMessageRequest(
			mResponseFactory,
			mConfigurationFactory.getCalypsoCountries());
	}

	/**
	 * 
	 * @param pSocket
	 * @return
	 */
	public Readable createReadable(Socket pSocket) throws IOException {
		return new BufferedReader(
			new InputStreamReader(pSocket.getInputStream()));
	}

	/**
	 * 
	 * @param pSocket
	 * @return
	 */
	public Object createWriter(Socket pSocket) throws IOException {
		return new AuditWriter(
			new BufferedWriter(
				new OutputStreamWriter(pSocket.getOutputStream())));
	}

	/**
	 * 
	 * @return
	 */
	public CharBuffer createCharBuffer() {
		return CharBuffer.allocate(ALLOCATE_BUFFER_SIZE);
	}

	/**
	 * 
	 * @return
	 */
	public RequestInfo createRequestInfo() {
		return new RequestInfo();
	}
}
