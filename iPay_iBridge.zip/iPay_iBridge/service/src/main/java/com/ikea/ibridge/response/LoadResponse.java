/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class LoadResponse extends XmlResponse {

	private CalypsoCountries mCalypsoCountries = null;
	
	public LoadResponse(CalypsoCountries pCalypsoCountries) {
		super();
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<loadResponse>\n");

		// Source system tags
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);

		int vBalanceDecimals = 2;
		long vBalance = 0;
		if (pResponseInfo.getBalanceAmount() != null) {
			vBalanceDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getBalanceCurrencyCode());
			
			vBalance = getRoundedUnscaledAmount(pResponseInfo.getBalanceAmount(), vBalanceDecimals);
		}
		
		pAppendable.append("<balanceAmount>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag("integer", vBalance));
		pAppendable.append(Tags.tag("decimals", vBalanceDecimals));
		pAppendable.append(
			Tags.tag("currency", pResponseInfo.getBalanceCurrencyCode()));
		pAppendable.append("</amount>\n");
		pAppendable.append(
			Tags.tag("balanceDateTime", pResponseInfo.getBalanceDate()));
		pAppendable.append("</balanceAmount>\n");

		pAppendable.append(Tags.tag("expires", pResponseInfo.getExpireDate()));

		pAppendable.append("</loadResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}
}
