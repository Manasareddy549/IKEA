/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.IOException;
import java.nio.CharBuffer;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class GenericRequest implements Request {
	/**
	 * The length of the test header is 3 characters
	 */
	public static final int TEST_LENGTH = 3;
	/**
	 * 
	 */
	private CharBuffer mMessage = null;
	private char[] mBuffer = null;

	/**
	 * @param pReadable
	 * @param pCharBuffer
	 * @param pMessageLength
	 * @throws IkeaException
	 */
	protected final void prepare(
		Readable pReadable,
		CharBuffer pCharBuffer,
		int pMessageLength)
		throws IkeaException {
		try {
			mBuffer = new char[pMessageLength];

			// We need to have at least pMessageLength characters in the char buffer
			// to analyze the message. NOTE that CALYPSO does not close the output stream
			// after writing data. So we can not call read until we get -1 since this will
			// hang iBridge. This is reported in CQ as a change to CALYPSO.
			if (pCharBuffer.position() < pMessageLength) {
				int vLength = 0;
				do {
					vLength = pReadable.read(pCharBuffer);
				} while (
					vLength >= 0 && pCharBuffer.position() < pMessageLength);
			}

			if (pCharBuffer.position() < pMessageLength) {
				throw new IkeaException(
					"The client did not send a complete message, expected "
						+ pMessageLength
						+ " but was "
						+ pCharBuffer.position());
			}

			// Prepare header for reading
			mMessage = pCharBuffer.asReadOnlyBuffer();
			mMessage.flip();
		} catch (IOException e) {
			throw new IkeaException( e);
		}
	}

	/**
	 * Helper method for reading charcters at specified position in the char buffer
	 * @param pStart The start position
	 * @param pLength The length to read
	 * @return The read result as a string
	 * @throws IkeaException If an error occur
	 */
	protected final String readFromBuffer(int pStart, int pLength)
		throws IkeaException {
		mMessage.position(pStart);
		mMessage.get(mBuffer, 0, pLength);
		return new String(mBuffer, 0, pLength);
	}

	/**
	 * @param pString
	 * @return
	 * @throws IkeaException
	 */
	protected final String flip(String pString) throws IkeaException {

		if (pString == null) {
			return null;
		}

		StringBuffer vResult = new StringBuffer(pString.length());

		for (int i = 0; i < pString.length(); i++) {
			char vChar = pString.charAt(i);
			if ('0' == vChar) {
				vResult.append("1");
			} else if ('1' == vChar) {
				vResult.append("0");
			} else {
				throw new IkeaException(
					"The string '" + pString + "' can't be flipped");
			}
		}

		return vResult.toString();
	}
}
