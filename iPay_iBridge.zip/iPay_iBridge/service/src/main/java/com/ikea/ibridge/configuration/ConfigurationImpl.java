package com.ikea.ibridge.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author snug
 *
 * Implements the Configuration interface an provides configuration information
 * for the iBridge service by reading a property file called iBridge.properties
 * located in the class path or at the location of the system property ibridge.configuration
 * that can be set to an URL by starting the Java VM with -Dibridge.configuration=file:<somepath>
 * 
 */
public class ConfigurationImpl implements Configuration {

	private static final int DEFAULT_PORTNUMBER = 9101;

	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(ConfigurationImpl.class);

	/**
	 * Keys to the property file
	 */
	private static final String TIMEOUT = "timeout";
	private static final String PORTNUMBER = "port";
	private static final String SIMULATED = "simulated";
	private static final String PROTOCOL = "protocol";
	private static final String SIMULATION_URL = "simulation.url";
	private static final String REQUEST_DELAY = "request.delay";
	private static final String RESPONSE_DELAY = "response.delay";
	private static final String VALIDATE_SCHEME = "validate.schema";
	private static final String VERSION = "version";
	static final private String SERIALIZE_REQUESTINFO = "serialize.requestinfo";
	

	/**
	 * The current settings value
	 */
	private int mTimeOut = 0;
	private int mPortNumber = DEFAULT_PORTNUMBER;
	private boolean mSimulated = false;
	private URL mSimulationURL = null;
	private long mRequestDelay = 0;
	private long mResponseDelay = 0;
	private String mVersion = null;
	private String mProtocol = null;
	private boolean mValidateScheme = false;
	private boolean mSerializeRequestinfo = false;

	/**
	 * Constructor that calls reload. This constructor should not be called directly.
	 * An instance of Configuration can be found with ConfigurationFactorySingleton.getInstance().getConfiguration().
	 * The constructor is public so that the test cases can use it.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public ConfigurationImpl() throws IkeaException {
		reload();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#getPortNumber()
	 */
	public int getPortNumber() {
		return mPortNumber;
	}

	public String getProtocol() {
			return mProtocol;
		}
		
	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#getTimeout()
	 */
	public int getTimeout() {
		return mTimeOut;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#isSimulated()
	 */
	public boolean isSimulated() {
		return mSimulated;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#isSerializingRequestInfo()
	 */
	public boolean isSerializingRequestInfo() {
		return mSerializeRequestinfo;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#isValidateScheme()
	 */
	public boolean isValidateSchema() {
		return mValidateScheme;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#getSimulationURL()
	 */
	public URL getSimulationURL() {
		return mSimulationURL;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#getRequestDelay()
	 */
	public long getRequestDelay() {
		return mRequestDelay;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#getResponseDelay()
	 */
	public long getResponseDelay() {
		return mResponseDelay;
	}

	/**
	 * This method will return the version of iBridge
	 */
	public String getVersion() {
		if (mVersion == null || mVersion.length() == 0) {
			mVersion = "not set";
		}
		return mVersion;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#reload()
	 */
	public void reload() throws IkeaException {

		// Load configuration properties
		Properties vConfiguration =
			loadProperties(
				"ibridge.configuration",
				"ibridge.properties",
				false);

		// Copy values from the properties instance to local variables (with validation)
		setTimeOut(vConfiguration.getProperty(TIMEOUT));
		setPortNumber(vConfiguration.getProperty(PORTNUMBER));
		setSerializeRequestinfo(vConfiguration.getProperty(SERIALIZE_REQUESTINFO));
		setSimulated(vConfiguration.getProperty(SIMULATED));
		setSimulationURL(vConfiguration.getProperty(SIMULATION_URL));
		setRequestDelay(vConfiguration.getProperty(REQUEST_DELAY));
		setResponseDelay(vConfiguration.getProperty(RESPONSE_DELAY));
		setProtocol(vConfiguration.getProperty(PROTOCOL));
		setValidateScheme(vConfiguration.getProperty(VALIDATE_SCHEME));
		// Load version properties
		Properties vVersion =
			loadProperties("version.configuration", "version.properties", true);

		if (vVersion != null) {
			mVersion = vVersion.getProperty(VERSION);
		}
	}

	/**
	 * @param pPropertyName
	 * @param pDefaultLocation
	 * @param allowEmpty
	 * @return
	 * @throws IkeaException
	 */
	private Properties loadProperties(
		String pPropertyName,
		String pDefaultLocation,
		boolean pAllowEmpty)
		throws IkeaException {

		InputStream vInputStream = null;

		try {
			URL vURL = null;

			// Check for system property for alternate location of properties
			String vPropertiesLocation = System.getProperty(pPropertyName);

			// Create URL to property file in the classpath or alternate location
			if (vPropertiesLocation != null
				&& vPropertiesLocation.length() > 0) {
				mLog.info(
					"Using properties from external settings ["
						+ vPropertiesLocation
						+ "]");
				vURL = new URL(vPropertiesLocation);
			} else {
				mLog.info("Using properties from class loader");
				vURL =
					Thread.currentThread().getContextClassLoader().getResource(
						pDefaultLocation);
			}

			// Check for URL
			if (vURL == null) {
				if (!pAllowEmpty) {
					throw new IkeaException(
						pDefaultLocation + " could not be found, URL was null");
				}
				return null;
			}

			// Open input stream
			vInputStream = vURL.openStream();

			// Check for input stream
			if (vInputStream == null) {
				if (!pAllowEmpty) {
					throw new IkeaException(
						vURL.toString()
							+ " could not be found, input stream was null");
				}
				return null;
			}

			Properties vProperties = new Properties();
			vProperties.load(vInputStream);
			return vProperties;

		} catch (Exception e) {
			throw new IkeaException( e);
		} finally {
			try {
				// Close stream
				if (vInputStream != null) {
					vInputStream.close();
				}
			} catch (IOException e) {
				mLog.error(e.getMessage());
			}
		}
	}

	/**
	 * Sets the port number value after validation
	 * 
	 * @param pPortNumber The new port number
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setPortNumber(String pPortNumber) throws IkeaException {

		if (pPortNumber == null) {
			throw new IkeaException(
				"Required attribute "
					+ PORTNUMBER
					+ " was missing from iBridge properties");
		} else {
			try {
				mPortNumber = Integer.parseInt(pPortNumber);
			} catch (NumberFormatException e) {
				throw new IkeaException(
					"Required attribute "
						+ PORTNUMBER
						+ " was not an integer in iBridge properties");
			}
		}
	}

	/**
	 * Sets the timeout value after validation
	 * 
	 * @param pTimeOut The new timeout
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setTimeOut(String pTimeOut) throws IkeaException {
		if (pTimeOut == null) {
			throw new IkeaException(
				"Required attribute "
					+ TIMEOUT
					+ " was missing from iBridge properties");
		} else {
			try {
				mTimeOut = Integer.parseInt(pTimeOut);
			} catch (NumberFormatException e) {
				throw new IkeaException(
					"Required attribute "
						+ TIMEOUT
						+ " was not an integer in iBridge properties");
			}
		}
	}

	/**
	 * Sets the simulated value after validation
	 * 
	 * @param pSimulated The new simualted setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setSimulated(String pSimulated) throws IkeaException {
		mSimulated = Boolean.parseBoolean(pSimulated);
		if (mSimulated) {
			mLog.info("iBridge is running in simulation mode");
		}
	}
	
	
	/**
	 * Set the value if a serialization of requestInfo objects should be done
	 * 
	 * @param pSerializeRequestinfo
	 * @throws IkeaException
	 */
	private void setSerializeRequestinfo(String pSerializeRequestinfo) throws IkeaException {
		mSerializeRequestinfo = Boolean.parseBoolean(pSerializeRequestinfo);
		if (mSerializeRequestinfo) {
			mLog.info("iBridge is serializing every incomming RequestInfo to disc.");
		}
	}	

	
	/**
	 * Set the value if a validation of scheme is active
	 * 
	 * @param pValidateScheme
	 * @throws IkeaException
	 */
	private void setValidateScheme(String pValidateScheme) throws IkeaException {
		mValidateScheme = Boolean.parseBoolean(pValidateScheme);
		if (mValidateScheme) {
			mLog.info("iBridge is validating scheme for incoming requests");
		}
	}	

	private void setProtocol(String pProtocol) throws IkeaException {
			mProtocol = pProtocol;
	//		if (mSimulated) {
	//			mCategory.info("iBridge is running in simulation mode");
	//		}
		}
	/**
	 * Sets the simulation URL value after validation
	 * 
	 * @param pSimulationURL The new simualted setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setSimulationURL(String pSimulationURL) throws IkeaException {
		if (pSimulationURL != null && pSimulationURL.length() > 0) {
			try {
				mSimulationURL = new URL(pSimulationURL);
			} catch (MalformedURLException e) {
				throw new IkeaException(
					"Optional attribute "
						+ SIMULATION_URL
						+ " was not well formed");
			}
			if (mSimulated) {
				mLog.info(
					"iBridge is using simulation URL: " + mSimulationURL);
			}
		}
	}

	/**
	 * Sets the request delay value after validation
	 * 
	 * @param pRequestDelay The new request delay
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setRequestDelay(String pRequestDelay) throws IkeaException {

		if (pRequestDelay != null) {
			try {
				mRequestDelay = Long.parseLong(pRequestDelay);
			} catch (NumberFormatException e) {
				throw new IkeaException(
					"Optional attribute "
						+ REQUEST_DELAY
						+ " was not a long value in iBridge properties");
			}
		}
	}

	/**
	 * Sets the response delay value after validation
	 * 
	 * @param pResponseDelay The new response delay
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setResponseDelay(String pResponseDelay) throws IkeaException {

		if (pResponseDelay != null) {
			try {
				mResponseDelay = Long.parseLong(pResponseDelay);
			} catch (NumberFormatException e) {
				throw new IkeaException(
					"Optional attribute "
						+ RESPONSE_DELAY
						+ " was not a long value in iBridge properties");
			}
		}
	}


}
