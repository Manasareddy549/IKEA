/*
 * Created on 2006-maj-09
 *
 */
package com.ikea.ibridge.request;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Stack;

import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.response.Response;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RequestInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7869916738102391128L;

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = LoggerFactory.getLogger(RequestInfo.class);

	/**
	 * Map to hold parsed request data
	 */
	private Map mRequestMap = new HashMap();

	/**
	 *
	 */
	transient Response mResponse = null;

	/**
	 * Create a RequestInfo without request map
	 *
	 */
	public RequestInfo() {
	}

	/**
	 * Creates a RequestInfo with a given request map
	 * @param pRequestMap
	 * @throws IkeaException if pRequestMap is null
	 */
	public RequestInfo(Map pRequestMap) throws IkeaException {
		setRequestMap(pRequestMap);
	}

	/**
	 * Gets the request map with parsed request data
	 * @return The request map
	 */
	public Map getRequestMap() {
		return mRequestMap;
	}

	/**
	 * Sets a request map with parsed request data
	 * @param pRequestMap The map with data
	 * @throws IkeaException if pRequestMap is null
	 */
	public void setRequestMap(Map pRequestMap) throws IkeaException {
		// Check for null
		if (pRequestMap == null) {
			throw new IkeaException(
					"Request map may not be null");
		}

		// Assign to member
		mRequestMap = pRequestMap;

		// Require that source system and operation is set
		getSourceSystem();
		getOperation();
	}

	/**
	 * Returns the number of parameters in the request data
	 * @return The number of paramters
	 * @throws IkeaException if pRequestMap is null
	 */
	public int size() throws IkeaException {
		// Check for null
		if (mRequestMap == null) {
			throw new IkeaException("Request map is null");
		}

		return mRequestMap.size();
	}

	/**
	 * 
	 * @param pStack
	 * @param pValue
	 */
	public void addToRequestMap(Stack pStack, String pValue) {

		try {
			// Ignore the ipay root tag
			if ("ipay".equals(pStack.lastElement())) {

				// Check for operation keys and transform from key to value
			} else if (isOperation(pStack.lastElement())) {

				setOperation(pStack.lastElement());

				// Normal values
			} else if (pStack.size() > 0) {

				// Calculate key name
				String vKey = "";
				for (ListIterator i = pStack.listIterator(); i.hasNext();) {
					String vNext = (String) i.next();
					if (i.nextIndex() > 2)
						vKey = vKey + (vKey.length() > 0 ? "." : "") + vNext;
				}

				addListParameter(vKey, pValue, true);
			}
		} catch (IkeaException e) {
			mLog.error(e.getMessage());
		}
	}

	/**
	 * Gets the Response to use for writing
	 * @return The response object
	 */
	public Response getResponse() {
		return mResponse;
	}

	/**
	 * Sets the Response to use for writing
	 * @param  pResponse pResponse object
	 */
	public void setResponse(Response pResponse) {
		mResponse = pResponse;
	}

	/**
	 * Gets the source system parameter
	 * @return The source system
	 * @throws IkeaException if problems occured with the value
	 */
	public String getSourceSystem() throws IkeaException {
		return getStringParameter(
				Request.SOURCE_SYSTEM_NAME_KEY,
				false,
				-1,
				-1);
	}

	/**
	 * Sets the source system parameter
	 * @param pSourceSystem The source system
	 * @throws IkeaException if problems occured with the value
	 */
	public void setSourceSystem(Object pSourceSystem) throws IkeaException {
		setStringParameter(
				Request.SOURCE_SYSTEM_NAME_KEY,
				pSourceSystem,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the operation type of the request (Balanace, Echo, Redeem etc.)
	 * @return The operation type
	 * @throws IkeaException if problems occured with the value
	 */
	public String getOperation() throws IkeaException {
		return getStringParameter(Request.OPERATION_KEY, false, -1, -1);
	}

	/**
	 * Sets the operation type of the request (Balanace, Echo, Redeem etc.)
	 * @param pOperation The operation type
	 * @throws IkeaException if problems occured with the value
	 */
	public void setOperation(Object pOperation) throws IkeaException {
		setStringParameter(Request.OPERATION_KEY, pOperation, false, -1, -1);
	}

	/**
	 * Gets the transaction type of the request (Balance, Echo, Redeem etc.)
	 * @return The transaction type
	 * @throws IkeaException if problems occured with the value
	 */
	public String getTransactionType() throws IkeaException {
		return getStringParameter(Request.TRANSACTION_TYPE_KEY, true, -1, -1);
	}

	/**
	 * Sets the transaction type of the request (Balanace, Echo, Redeem etc.)
	 * @param pTransactionType The transaction type
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTransactionType(Object pTransactionType)
			throws IkeaException {
		setStringParameter(
				Request.TRANSACTION_TYPE_KEY,
				pTransactionType,
				true,
				-1,
				-1);
	}

	/**
	 * Gets the message parameter
	 * @return The message
	 * @throws IkeaException if problems occured with the value
	 */
	public String getMessage() throws IkeaException {
		return getStringParameter(Request.MESSAGE_KEY, false, -1, -1);
	}

	/**
	 * Gets the message parameter
	 * @param pMessage The message
	 * @throws IkeaException if problems occured with the value
	 */
	public void setMessage(Object pMessage) throws IkeaException {
		setStringParameter(Request.MESSAGE_KEY, pMessage, false, -1, -1);
	}

	/**
	 * Gets the BU type parameter
	 * @return The BU type
	 * @throws IkeaException if problems occured with the value
	 */
	public String getBuType() throws IkeaException {
		return getStringParameter(Request.ORIGINATOR_BU_TYPE_KEY, false, 3, 3);
	}

	/**
	 * Sets the BU type parameter
	 * @param pBuType The BU type
	 * @throws IkeaException if problems occured with the value
	 */
	public void setBuType(Object pBuType) throws IkeaException {
		setStringParameter(
				Request.ORIGINATOR_BU_TYPE_KEY,
				pBuType,
				false,
				3,
				3);
	}

	/**
	 * Gets the BU code parameter
	 * @return The BU code
	 * @throws IkeaException if problems occured with the value
	 */
	public String getBuCode() throws IkeaException {
		return getStringParameter(Request.ORIGINATOR_BU_CODE_KEY, false, 3, 5);
	}

	/**
	 * Sets the BU code parameter
	 * @param pBuCode The BU code
	 * @throws IkeaException if problems occured with the value
	 */
	public void setBuCode(Object pBuCode) throws IkeaException {
		setStringParameter(
				Request.ORIGINATOR_BU_CODE_KEY,
				pBuCode,
				false,
				3,
				5);
	}

	/**
	 * Gets the employee parameter
	 * @return The employee
	 * @throws IkeaException if problems occured with the value
	 */
	public String getEmployee() throws IkeaException {
		return getStringParameter(
				Request.ORIGINATOR_EMPLOYEE_KEY,
				false,
				-1,
				-1);
	}

	/**
	 * Sets the employee parameter
	 * @param pEmployee The employee
	 * @throws IkeaException if problems occured with the value
	 */
	public void setEmployee(Object pEmployee) throws IkeaException {
		setStringParameter(
				Request.ORIGINATOR_EMPLOYEE_KEY,
				pEmployee,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the swiped parameter
	 * @return swiped
	 * @throws IkeaException if problems occured with the value
	 */
	public boolean isSwiped() throws IkeaException {
		return getBooleanParameter(Request.CARDENTRY_SWIPED_KEY, false, true);
	}

	/**
	 * Sets the swiped parameter
	 * @param pSwiped swiped
	 * @throws IkeaException if problems occured with the value
	 */
	public void setSwiped(Object pSwiped) throws IkeaException {
		setBooleanParameter(Request.CARDENTRY_SWIPED_KEY, pSwiped, false, true);
	}

	/**
	 * Gets the auto acknowledge parameter
	 * @return auto acknowledge
	 * @throws IkeaException if problems occured with the value
	 */
	public boolean isAutoAcknowledge() throws IkeaException {
		return getBooleanParameter(
				Request.ENVIRONMENT_AUTO_ACKNOWLEDGE_KEY,
				true,
				false);
	}

	/**
	 * Sets the auto acknowledge parameter
	 * @param pAutoAcknowledge auto acknowledge
	 * @throws IkeaException if problems occured with the value
	 */
	public void setAutoAcknowledge(Object pAutoAcknowledge)
			throws IkeaException {
		setBooleanParameter(
				Request.ENVIRONMENT_AUTO_ACKNOWLEDGE_KEY,
				pAutoAcknowledge,
				true,
				false);
	}

	/**
	 * Gets the card number parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getCardNumber() throws IkeaException {
		return getStringParameter(
				Request.CARDENTRY_CARDNUMBER_KEY,
				false,
				-1,
				-1);
	}

	/**
	 * Sets the card number parameter
	 * @param pCardNumber The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setCardNumber(Object pCardNumber) throws IkeaException {
		setStringParameter(
				Request.CARDENTRY_CARDNUMBER_KEY,
				pCardNumber,
				false,
				-1,
				-1,
				true);
	}
	/**
	 * Gets the massload id parameter
	 * @return The massload id
	 * @throws IkeaException if problems occured with the value
	 */
	public long getMassLoadId() throws IkeaException {
		return getLongParameter(Request.MASSLOADKEY_MASSLOADID);
	}

	/**
	 * Sets the massload Id parameter
	 * @param pMassLoadId The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setMassLoadId(Object pMassLoadId) throws IkeaException {
		setStringParameter(
			Request.MASSLOADKEY_MASSLOADID,
			pMassLoadId,
			false,
			-1,
			-1,
			true);
	}
	/**
	 * Gets the BU type parameter
	 * @return The BU type
	 * @throws IkeaException if problems occured with the value
	 */
	public String getPosBuType() throws IkeaException {
		return getStringParameter(Request.POSMASSLOAD_BUTYPE, false, 2, 3);
	}

	/**
	 * Sets the BU type parameter
	 * @param pBuType The BU type
	 * @throws IkeaException if problems occured with the value
	 */
	public void setPosBuType(Object pBuType) throws IkeaException {
		setStringParameter(
			Request.POSMASSLOAD_BUTYPE,
			pBuType,
			false,
			2,
			3);
	}

	/**
	 * Gets the BU code parameter
	 * @return The BU code
	 * @throws IkeaException if problems occured with the value
	 */
	public String getPosBuCode() throws IkeaException {
		return getStringParameter(Request.POSMASSLOAD_BUCODE, false, 3, 5);
	}

	/**
	 * Sets the BU code parameter
	 * @param pBuCode The BU code
	 * @throws IkeaException if problems occured with the value
	 */
	public void setPosBuCode(Object pBuCode) throws IkeaException {
		setStringParameter(
			Request.POSMASSLOAD_BUCODE,
			pBuCode,
			false,
			3,
			5);
	}

	/**
	 * Gets the employee parameter
	 * @return The employee
	 * @throws IkeaException if problems occured with the value
	 */
	public String getEmployeeId() throws IkeaException {
		return getStringParameter(
			Request.POSMASSLOAD_EMPLOYEEID,
			false,
			-1,
			-1);
	}

	/**
	 * Sets the employee parameter
	 * @param pEmployee The employee
	 * @throws IkeaException if problems occured with the value
	 */
	public void setEmployeeId(Object pEmployee) throws IkeaException {
		setStringParameter(
			Request.POSMASSLOAD_EMPLOYEEID,
			pEmployee,
			false,
			-1,
			-1);
	}
	/**
	 * Sets the country code parameter
	 * Only used for Calypso!
	 * @param pCountryCode Type country code
	 * @throws IkeaException if problems occured with the value
	 */
	public void setPosCountryCode(Object pCountryCode) throws IkeaException {
		setStringParameter(Request.POSMASSLOAD_COUNTRYCODE, pCountryCode, false, -1, -1);
	}

	/**
	 * Gets the load amount interger parameter
	 * Only used for Calypso!
	 * @return The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public String getPosCountryCode() throws IkeaException {
		return getStringParameter(Request.POSMASSLOAD_COUNTRYCODE, false, -1, -1);
	}



	/**
	 * Gets the verificationcode
	 * @return The verificationcode
	 * @throws IkeaException if problems occured with the value
	 */
	public String getVerificationCode() throws IkeaException {
		return getStringParameter(Request.VERIFICATION_CODE, true, -1, -1);
	}

	/**
	 * Sets the verificationcode. Only valid for xml.
	 * @param pVerificationCode
	 * @throws IkeaException if problems occured with the value
	 */
	public void setVerificationCode(Object pVerificationCode)
			throws IkeaException {
		setStringParameter(
				Request.VERIFICATION_CODE,
				pVerificationCode,
				true,
				-1,
				-1,
				false);
	}

	public long getPosExpiryDate() throws IkeaException {
		return getLongParameter(Request.CARDENTRY_POS_Expire_DATE);
	}

	/**
	 * Sets the expire date. Only valid for xml.
	 * @param pExpires
	 * @throws IkeaException if problems occured with the value
	 */
	public void setPosExpiryDate(Object pExpires)
			throws IkeaException {
		setStringParameter(
				Request.CARDENTRY_POS_Expire_DATE,
				pExpires,
				true,
				-1,
				-1,
				false);
	}




	/**
	 * Gets the transmission date parameter
	 * @return The transmission date
	 * @throws IkeaException if problems occured with the value
	 */
	public Date getTransmissionDateTime() throws IkeaException {
		return getDateTimeParameter(Request.SOURCE_SYSTEM_TRANSMISSION_KEY);
	}

	/**
	 * Sets the transmission date parameter
	 * @param pTransmissionDate The transmission date
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTransmissionDateTime(Object pTransmissionDate)
			throws IkeaException {
		setDateTimeParameter(
				Request.SOURCE_SYSTEM_TRANSMISSION_KEY,
				pTransmissionDate);
	}

	/**
	 * Gets the source system reference parameter
	 * @return The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public String getSourceSystemReference() throws IkeaException {
		return getSingleStringListParameter(
				Request.SOURCE_SYSTEM_REFERENCE_KEY,
				false);
	}

	/**
	 * Sets the source system reference parameter
	 * @param pReference The source system reference
	 * @throws IkeaException if problems occured with the value
	 */
	public void setSourceSystemReference(Object pReference)
			throws IkeaException {
		setStringParameter(
				Request.SOURCE_SYSTEM_REFERENCE_KEY,
				pReference,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the reference list parameter
	 * @return The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public List getReferenceList() throws IkeaException {
		return getListParameter(Request.REFERENCE_LIST_KEY, false);
	}

	/**
	 * Add to the reference list parameter
	 * @param pReference The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public void addReferenceList(Object pReference) throws IkeaException {
		addListParameter(Request.REFERENCE_LIST_KEY, pReference, false);
	}

	/**
	 * Gets the card number parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getReceipt() throws IkeaException {
		return getStringParameter(Request.SOURCE_SYSTEM_RECEIPT, false, -1, -1);
	}

	/**
	 * Sets the card number parameter
	 * @param pReceipt The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setReceipt(Object pReceipt) throws IkeaException {
		setStringParameter(
				Request.SOURCE_SYSTEM_RECEIPT,
				pReceipt,
				false,
				-1,
				-1);
	}
	/**
	 * Gets the card number parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getPointOfSale() throws IkeaException {
		return getStringParameter(Request.SOURCE_SYSTEM_POS, false, -1, -1);
	}

	/**
	 * Sets the card number parameter
	 * @param pPointOfSale The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setPointOfSale(Object pPointOfSale) throws IkeaException {
		setStringParameter(
				Request.SOURCE_SYSTEM_POS,
				pPointOfSale,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the load amount type parameter
	 * @return The load amount type
	 * @throws IkeaException if problems occured with the value
	 */
	public String getLoadAmountType() throws IkeaException {
		return getStringParameter(Request.LOAD_AMOUNT_TYPE, false, -1, -1);
	}

	/**
	 * Sets the load amount type parameter
	 * @param pAmountType load amount type
	 * @throws IkeaException if problems occured with the value
	 */
	public void setLoadAmountType(Object pAmountType) throws IkeaException {
		setStringParameter(
				Request.LOAD_AMOUNT_TYPE,
				pAmountType,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the load amount interger parameter
	 * @return The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public long getLoadAmountInteger() throws IkeaException {
		return getLongParameter(Request.LOAD_AMOUNT_INTEGER);
	}

	/**
	 * Sets the load amount interger parameter
	 * @param pAmountInteger The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public void setLoadAmountInteger(Object pAmountInteger)
			throws IkeaException {
		setStringParameter(
				Request.LOAD_AMOUNT_INTEGER,
				pAmountInteger,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the load amount decimals parameter
	 * @return The load amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public int getLoadAmountDecimals() throws IkeaException {
		return getIntParameter(Request.LOAD_AMOUNT_DECIMALS);
	}

	/**
	 * Sets the load amount decimals parameter
	 * @param pAmountDecimals The load amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public void setLoadAmountDecimals(Object pAmountDecimals)
			throws IkeaException {
		setStringParameter(
				Request.LOAD_AMOUNT_DECIMALS,
				pAmountDecimals,
				true,
				-1,
				-1);
	}

	/**
	 * Gets the reference parameter
	 * @return The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public String getLoadAmountCurrency() throws IkeaException {
		return getStringParameter(Request.LOAD_AMOUNT_CURRENCY, false, -1, -1);
	}

	/**
	 * Sets the reference parameter
	 * @param pReference The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public void setLoadAmountCurrency(Object pReference) throws IkeaException {
		setStringParameter(
				Request.LOAD_AMOUNT_CURRENCY,
				pReference,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the load amount interger parameter
	 * @return The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public long getRequestAmountInteger() throws IkeaException {
		return getLongParameter(Request.REQUEST_AMOUNT_INTEGER);
	}

	/**
	 * Sets the load amount interger parameter
	 * @param pAmountInteger The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public void setRequestAmountInteger(Object pAmountInteger)
			throws IkeaException {
		setStringParameter(
				Request.REQUEST_AMOUNT_INTEGER,
				pAmountInteger,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the load amount decimals parameter
	 * @return The load amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public int getRequestAmountDecimals() throws IkeaException {
		return getIntParameter(Request.REQUEST_AMOUNT_DECIMALS);
	}

	/**
	 * Sets the load amount decimals parameter
	 * @param pAmountDecimals The load amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public void setRequestAmountDecimals(Object pAmountDecimals)
			throws IkeaException {
		setStringParameter(
				Request.REQUEST_AMOUNT_DECIMALS,
				pAmountDecimals,
				true,
				-1,
				-1);
	}

	/**
	 * Gets the total amount integer parameter
	 * @return The total amount integer
	 * @throws IkeaException if problems occured with the value
	 */
	public long getTotalAmountInteger() throws IkeaException {
		return getLongParameter(Request.TOTAL_AMOUNT_INTEGER);
	}

	/**
	 * Sets the total amount integer parameter
	 * @param pAmountInteger The total amount integer
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTotalAmountInteger(Object pAmountInteger)
			throws IkeaException {
		setStringParameter(
				Request.TOTAL_AMOUNT_INTEGER,
				pAmountInteger,
				false,
				-1,
				-1);
	}

	/**
	 * Gets the total amount decimals parameter
	 * @return The total amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public int getTotalAmountDecimals() throws IkeaException {
		return getIntParameter(Request.TOTAL_AMOUNT_DECIMALS);
	}

	/**
	 * Sets the total amount decimals parameter
	 * @param pAmountDecimals The total amount decimals
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTotalAmountDecimals(Object pAmountDecimals)
			throws IkeaException {
		setStringParameter(
				Request.TOTAL_AMOUNT_DECIMALS,
				pAmountDecimals,
				true,
				-1,
				-1);
	}

	/**
	 * Gets the reference parameter
	 * @return The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public String getRequestAmountCurrency() throws IkeaException {
		return getStringParameter(
				Request.REQUEST_AMOUNT_CURRENCY,
				false,
				-1,
				-1);
	}

	/**
	 * Sets the reference parameter
	 * @param pReference The reference
	 * @throws IkeaException if problems occured with the value
	 */
	public void setRequestAmountCurrency(Object pReference)
			throws IkeaException {
		setStringParameter(
				Request.REQUEST_AMOUNT_CURRENCY,
				pReference,
				false,
				-1,
				-1);
	}

	/**
	 * Sets the country code parameter
	 * Only used for Calypso!
	 * @param pCountryCode Type country code
	 * @throws IkeaException if problems occured with the value
	 */
	public void setCountryCode(Object pCountryCode) throws IkeaException {
		setStringParameter(Request.COUNTRY_CODE, pCountryCode, false, -1, -1);
	}

	/**
	 * Gets the load amount interger parameter
	 * Only used for Calypso!
	 * @return The load amount interger
	 * @throws IkeaException if problems occured with the value
	 */
	public String getCountryCode() throws IkeaException {
		return getStringParameter(Request.COUNTRY_CODE, false, -1, -1);
	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @param pMayBeNull True if the parameter can be null
	 * @param pMinLength If positive the minimum length of the parameter is checked
	 * @param pMaxLength If positive the maximum length of the parameter is checked
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private String getStringParameter(
			String pParameter,
			boolean pMayBeNull,
			int pMinLength,
			int pMaxLength)
					throws IkeaException {
		// Check for null Map
		if (mRequestMap == null) {
			throw new IkeaException("Request map is null");
		}

		// Check that parameter exists.
		// Ugly exception is if the parameter is the NOT Mandatory tag verification code.
		if (!mRequestMap.containsKey(pParameter)
				&& !pParameter.equals(Request.VERIFICATION_CODE)
				&& !pParameter.equals(Request.TRAINING_MODE)
				&& !pParameter.equals(Request.CARDENTRY_POS_Expire_DATE)) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not found in request");
		}

		// Retrieve parameter
		Object vObject = mRequestMap.get(pParameter);

		// Check for null
		if (!pMayBeNull && vObject == null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' may not be null");
		}

		// Check parameter type
		if (!(vObject instanceof String) && vObject != null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not a String value");
		}

		// Coerce to String
		String vString = (String) vObject;

		// Check parameter min length
		if (vString != null) {
			boolean vMinFailure =
					pMinLength > 0 && vString.length() < pMinLength;
					boolean vMaxFailure =
							pMaxLength > 0 && vString.length() > pMaxLength;
							if (vMinFailure || vMaxFailure) {
								throw new IkeaException(
										"Parameter '" + pParameter + "' had wrong length");
							}
		}

		return vString;
	}

	/**
	 * Helper method for setting parameters from the map.
	 * @param pParameter The Parameter to set
	 * @param pParameterValue The value of the parameter
	 * @param pMayBeNull True if the parameter can be null
	 * @param pMinLength If positive the minimum length of the parameter is checked
	 * @param pMaxLength If positive the maximum length of the parameter is checked
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private String setStringParameter(
			String pParameter,
			Object pParameterValue,
			boolean pMayBeNull,
			int pMinLength,
			int pMaxLength)
					throws IkeaException {
		return setStringParameter(
				pParameter,
				pParameterValue,
				pMayBeNull,
				pMinLength,
				pMaxLength,
				false);
	}
	/**
	 * Helper method for setting parameters from the map.
	 * @param pParameter The Parameter to set
	 * @param pParameterValue The value of the parameter
	 * @param pMayBeNull True if the parameter can be null
	 * @param pMinLength If positive the minimum length of the parameter is checked
	 * @param pMaxLength If positive the maximum length of the parameter is checked
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private String setStringParameter(
			String pParameter,
			Object pParameterValue,
			boolean pMayBeNull,
			int pMinLength,
			int pMaxLength,
			boolean pTrim)
					throws IkeaException {
		// Check for null Map
		if (mRequestMap == null) {
			throw new IkeaException("Request map is null");
		}

		// Check for null
		if (!pMayBeNull && pParameterValue == null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' may not be null");
		}

		// Check parameter type
		if (!(pParameterValue instanceof String) && pParameterValue != null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not a String value");
		}

		// Coerce to String
		String vString = (String) pParameterValue;

		if (pTrim) {
			vString = vString.trim();
		}

		// Check parameter min length
		if (vString != null) {
			boolean vMinFailure =
					pMinLength > 0 && vString.length() < pMinLength;
					boolean vMaxFailure =
							pMaxLength > 0 && vString.length() > pMaxLength;
							if (vMinFailure || vMaxFailure) {
								throw new IkeaException(
										"Parameter '" + pParameter + "' had wrong length");
							}
		}

		mRequestMap.put(pParameter, vString);

		return vString;
	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @param pMayBeNull True if the parameter can be null
	 * @param pDefault Value returned if parameter is null
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private boolean getBooleanParameter(
			String pParameter,
			boolean pMayBeNull,
			boolean pDefault)
					throws IkeaException {

		// Coerce to String
		String vString = getStringParameter(pParameter, pMayBeNull, -1, -1);

		// Null or empty returns default value
		if (pMayBeNull && (vString == null || vString.length() == 0)) {
			return pDefault;
		}

		// Check valid values for boolean
		if (!(vString.equals("0")
				|| vString.equals("1")
				|| vString.equals("N")
				|| vString.equals("Y")
				|| vString.equals("true")
				|| vString.equals("false"))) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' can't be converted to boolean");
		}

		return vString.equals("1")
				|| vString.equals("Y")
				|| vString.equals("true");
	}

	/**
	 * Helper method for setting parameters from the map.
	 * @param pParameter The Parameter to set
	 * @param pParameterValue The value of the parameter
	 * @param pMayBeNull True if the parameter can be null
	 * @param pDefault If positive the length of the parameter is checked
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private void setBooleanParameter(
			String pParameter,
			Object pParameterValue,
			boolean pMayBeNull,
			boolean pDefault)
					throws IkeaException {

		// Coerce to String
		String vString =
				setStringParameter(pParameter, pParameterValue, pMayBeNull, -1, -1);

		// Null or empty returns default value
		if (pMayBeNull && (vString == null || vString.length() == 0)) {
			vString = pDefault ? "1" : "0";
		}

		// Check valid values for boolean
		if (!(vString.equals("0")
				|| vString.equals("1")
				|| vString.equals("N")
				|| vString.equals("Y")
				|| vString.equals("true")
				|| vString.equals("false"))) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' can't be converted to boolean");
		}

		mRequestMap.put(pParameter, vString);
	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private Date getDateTimeParameter(String pParameter) throws IkeaException {

		// Coerce to String
		String vString = getStringParameter(pParameter, false, -1, -1);

		// Try to convert to date
		try {
			return new SimpleDateFormat("yyyyMMddHHmmss").parse(vString);
		} catch (ParseException e) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' can't be converted to Date");
		}
	}

	/**
	 * Helper method for setting parameters from the map.
	 * @param pParameter The Parameter to set
	 * @param pParameterValue The value of the parameter
	 * @throws IkeaException if parameter was not found or not a string
	 */
	private void setDateTimeParameter(
			String pParameter,
			Object pParameterValue)
					throws IkeaException {

		// Coerce to String
		String vString =
				setStringParameter(pParameter, pParameterValue, false, -1, -1);

		// Try to convert to date
		try {
			new SimpleDateFormat("yyyyMMddHHmmss").parse(vString);
		} catch (ParseException e) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' can't be converted to Date");
		}

		mRequestMap.put(pParameter, vString);
	}

	/**
	 * Gets the training mode parameter
	 * @return training mode
	 * @throws IkeaException if problems occured with the value
	 */
	public boolean isTrainingMode() throws IkeaException {
		return getBooleanParameter(
				Request.TRAINING_MODE,
				true,
				false);
	}

	/**
	 * Sets the training mode parameter
	 * @param pTrainingMode training mode
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTrainingMode(Object pTrainingMode)
			throws IkeaException {
		setBooleanParameter(
				Request.TRAINING_MODE,
				pTrainingMode,
				true,
				false);
	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a long
	 */
	private long getLongParameter(String pParameter) throws IkeaException {

		// Coerce to String
		String vString;
		if(pParameter.equals(Request.CARDENTRY_POS_Expire_DATE))
		{
			try{
				vString = getStringParameter(pParameter, true, 8, 8);
			} catch (IkeaException e) {
				throw new EmptyRequestException("The POS system sent an invalid Expire Date");
			}
		}
		else{

			vString = getStringParameter(pParameter, false, -1, -1);
		}

		// Try to convert to long
		if(vString!=null)
		{
			try {
				BigDecimal vValue = new BigDecimal(vString);
				return vValue.longValue();
			} catch (NumberFormatException e) {
				throw new IkeaException(
						"Parameter '"
								+ pParameter
								+ "' can't be converted to long. String:"
								+ vString);
			}
		}
		else{
			return 0L;
		}

	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a int
	 */
	private int getIntParameter(String pParameter) throws IkeaException {

		// Coerce to String
		String vString = getStringParameter(pParameter, false, -1, -1);

		// Try to convert to long
		try {
			Integer vValue = new Integer(vString);
			return vValue.intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Parameter '"
							+ pParameter
							+ "' can't be converted to int. String:"
							+ vString);
		}
	}

	/**
	 * Helper method for retrieving parameters from the map.
	 * @param pParameter The Parameter to get
	 * @return The value of the parameter
	 * @throws IkeaException if parameter was not found or not a list
	 */
	private List getListParameter(String pParameter, boolean pMayBeNull)
			throws IkeaException {

		// Check for null Map
		if (mRequestMap == null) {
			throw new IkeaException("Request map is null");
		}

		// Check that parameter exists
		if (!mRequestMap.containsKey(pParameter)) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not found in request");
		}

		// Retrieve parameter
		Object vObject = mRequestMap.get(pParameter);

		// Check for null
		if (!pMayBeNull && vObject == null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' may not be null");
		}

		List vList = null;

		if (vObject instanceof List) {
			vList = (List) vObject;
		} else {
			vList = new LinkedList();
			vList.add(vObject);
		}

		return vList;
	}

	/**
	 * 
	 * @param pParameter
	 * @param pMayBeNull
	 * @return
	 * @throws IkeaException
	 */
	private String getSingleStringListParameter(
			String pParameter,
			boolean pMayBeNull)
					throws IkeaException {
		List vList = getListParameter(pParameter, pMayBeNull);

		if ((vList == null || vList.size() == 0) && !pMayBeNull) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not found in the request");
		}
		if (vList.size() > 1) {
			throw new IkeaException(
					"Parameter '"
							+ pParameter
							+ "' occured more than once in the request");
		}

		Object vObject = vList.get(0);

		// Check parameter type
		if (!(vObject instanceof String) && vObject != null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' was not a String value");
		}

		return (String) vObject;
	}

	/**
	 * 
	 * @param pParameter
	 * @param pParameterValue
	 * @param pMayBeNull
	 * @throws IkeaException
	 */
	private void addListParameter(
			String pParameter,
			Object pParameterValue,
			boolean pMayBeNull)
					throws IkeaException {

		// Check for null Map
		if (mRequestMap == null) {
			throw new IkeaException("Request map is null");
		}

		// Check for null
		if (!pMayBeNull && pParameterValue == null) {
			throw new IkeaException(
					"Parameter '" + pParameter + "' may not be null");
		}

		// Add value
		if (mRequestMap.containsKey(pParameter)) {
			// Check existing tags
			Object vObject = mRequestMap.get(pParameter);
			List vList = null;

			// Transform from String to List if needed
			if (vObject instanceof String) {
				vList = new LinkedList();
				vList.add(vObject);
			} else {
				vList = (List) vObject;
			}

			vList.add(pParameterValue);
			mRequestMap.put(pParameter, vList);
		} else {

			mRequestMap.put(pParameter, pParameterValue);
		}
	}

	/**
	 * 
	 * @param name
	 * @return
	 */
	private static final boolean isOperation(Object name) {

		for (int i = 0; i < Request.OPERATIONS.length; i++) {
			if (Request.OPERATIONS[i].equals(name)) {
				return true;
			}
		}
		return false;
	}
}
