package com.ikea.ibridge.configuration;

import com.ikea.ebcframework.exception.IkeaException;

import java.net.URL;

/*
 * 
 * @author snug
 *
 * Interface for providing configuration information the the iBridge service.
 * This is typically read from a configuration file.
 * 
 */
public interface Configuration {

	/**
	 * Specifies the port for listening for the service. By default this is 9101, but
	 * that could be configured otherwise.
	 * 
	 * @return The portnumber to use for listening
	 */
	int getPortNumber();

	/**
	 * Specifies the timeout that the socket will block while waiting for a new connection.
	 * A value of zero blocks forever. The purpose of the timeout is to provide the ability
	 * to stop the service in a controlled way, since when the timeout is reached the service
	 * checks for the stop flag, if it's set it exits in a controlled way. This setting has no
	 * impact if the service is regularly stopped by terminating the Java VM, since this will
	 * close the socket regdless of the timeout value.
	 * 
	 * @return The timeout for the socket
	 */
	int getTimeout();

	/**
	 * Specifies the simulation settings
	 * 
	 * @return The simulation settings
	 */
	boolean isSimulated();

	/**
	 * Specifies the simulation URL/directory
	 * 
	 * @return The simulation URL/directory
	 */
	URL getSimulationURL();

	/**
	 * Specifies the delay to use after processing a request. Can be used
	 * to simulate slow connections between till and iBridge. Use Zero in production!
	 * 
	 * @return The delay in seconds
	 */
	long getRequestDelay();

	/**
	 * Specifies the delay to use before sending a response. Can be used
	 * to simulate slow connections between till and iBridge. Use Zero in production!
	 * 
	 * @return The delay in seconds
	 */
	long getResponseDelay();

	/**
	 * 
	 * @return The version number of the service
	 */
	String getVersion();


	String getProtocol();
	
	
	/**
	 * 
	 * @return true if the validation of scheme is set in properties
	 * Should be false in production environment to avoid unnecessary checks
	 */
	public abstract boolean isValidateSchema();

	/**
	 * 
	 * @return true if all RequestInfo objects are set to be serialized to disc
	 */
	public abstract boolean isSerializingRequestInfo();
	
	/**
	 * A call to reload signals the the settings should be read again.
	 * @throws IkeaException When a error occurs
	 */
	void reload() throws IkeaException;
}
