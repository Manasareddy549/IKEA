/*
 * Created on 2007-jun-29
 *
 */
package com.ikea.ibridge.response;

import java.io.IOException;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.request.RequestInfo;

/**
 * @author anms
 *
 */
public class StaticErrorResponse implements Response {

	private String mMessage;
	private String mDetails;

	/**
	 * 
	 */
	public StaticErrorResponse(String pMessage, String pDetails) {
		super();
		mMessage = pMessage;
		mDetails = pDetails;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.request.RequestInfo, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void write(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<errorResponse>\n");

		// Can not detemin source system

		// Write a static error message
		pAppendable.append("<error>\n");

		pAppendable.append(
			"<type>" + Response.ERROR_TYPE_TRY_AGAIN + "</type>\n");
		pAppendable.append("<message>" + mMessage + "</message>\n");
		pAppendable.append("<details>" + mDetails + "</details>\n");
		//			"<details>Static error message since could not generate an error message basen on the problem!</details>\n");

		pAppendable.append("</error>\n");

		pAppendable.append("</errorResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}

}
