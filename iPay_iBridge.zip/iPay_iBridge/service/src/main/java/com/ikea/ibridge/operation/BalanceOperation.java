/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsCheckBalance;
import com.ikea.ebccardpay1.client.vo.VoCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ibridge.request.CalypsoProperties;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BalanceOperation implements Operation {
    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	/**
	 * Log category for messages
	 */
    private final static Logger mLog = LoggerFactory.getLogger(BalanceOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing operation check balance");

		// Create card entry VO
		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setSwiped(pRequestInfo.isSwiped());
		vVoCardEntry.setCardNumberString(pRequestInfo.getCardNumber());

		// Create environment VO
		VoEnvironment vVoEnvironment = new VoEnvironment();
		vVoEnvironment.setOffline(false);
		vVoEnvironment.setAutoAcknowledge(pRequestInfo.isAutoAcknowledge());

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());
		vVoOriginator.setPointOfSale(pRequestInfo.getPointOfSale());
		vVoOriginator.setReceipt(pRequestInfo.getReceipt());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(pRequestInfo.getTransmissionDateTime());

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create service
		BsCheckBalance vBsCheckBalance = new BsCheckBalance();

		// Set input VO
		vBsCheckBalance.setVoCardEntry(vVoCardEntry);
		vBsCheckBalance.setVoEnvironment(vVoEnvironment);
		vBsCheckBalance.setVoOriginator(vVoOriginator);
		vBsCheckBalance.setVoReference(vVoReference);
		vBsCheckBalance.setVoSourceSystem(vVoSourceSystem);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
		bsExecuter.executeBs(vBsCheckBalance,"Originator");

		// Check for application errors
		List vApplErrors = vBsCheckBalance.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			
			// If source system is calypso, the card is a family card and the
			// card is not activated (not found), then don't return an error
			if (pRequestInfo.getSourceSystem().equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_CALYPSO) &&
					CalypsoProperties.isFamily(pRequestInfo.getCardNumber())) {
				for (Iterator iter = vApplErrors.iterator(); iter.hasNext();) {
					ApplicationError vApplError = (ApplicationError)iter.next();
					if (vApplError.getErrorCode() == ApplicationErrorCodes.INVALID_CARD_NOT_FOUND ||
						(vApplError.getErrorCode() == ApplicationErrorCodes.NON_TRANSLATABLE &&
						 (vApplError.getMessage().toLowerCase().startsWith("card has never been loaded") ||
						  vApplError.getMessage().toLowerCase().startsWith("card number not found") ||
						  vApplError.getMessage().toLowerCase().startsWith("card number found but no card connected")))) {

						pResponseInfo.setBalanceAmount(Amounts.amount(0));
						//pResponseInfo.setBalanceCurrencyCode(vVoRequestAmount.getCurrencyCode());
						pResponseInfo.setBalanceDate(new Date());

						pResponseInfo.setPaidAmount(Amounts.amount(0));

						pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
						return;
					}
				}
			}
			
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}

		// Read response
		VoCard vVoCard = vBsCheckBalance.getVoCard();

		pResponseInfo.setBalanceAmount(vVoCard.getBalanceAmount());
		pResponseInfo.setBalanceCurrencyCode(vVoCard.getCurrencyCode());
		pResponseInfo.setPaidAmount(Amounts.zero());
		pResponseInfo.setBalanceDate(vVoCard.getBalanceDateTime());
		pResponseInfo.setExpireDate(vVoCard.getExpireDate());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);

	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing operation check balance in training mode");
		
		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode("EUR");
		pResponseInfo.setPaidAmount(Amounts.zero());
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
