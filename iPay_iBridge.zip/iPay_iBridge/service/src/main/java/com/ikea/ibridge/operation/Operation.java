/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.exception.SystemErrorException;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface Operation {

	/**
	 * 
	 * @param pRequestInfo
	 * @param pResponseInfo
	 * @return
	 * @throws SystemErrorException if the business service could not be executed.
	 * @throws IkeaException unexpected error.
	 */
	public abstract void perform(
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws SystemErrorException, IkeaException;

	/**
	 * 
	 * @param pRequestInfo
	 * @param pResponseInfo
	 * @return
	 */
	public abstract void performTrainingMode(
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException;
}
