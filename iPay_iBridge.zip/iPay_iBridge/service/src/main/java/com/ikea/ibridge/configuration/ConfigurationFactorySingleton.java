package com.ikea.ibridge.configuration;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * Provides access to the <code>ConfigurationFacory</code> instance
 * 
 */
public class ConfigurationFactorySingleton {

	/**
	 * The single instance of the Configuration factory
	 */
	private static ConfigurationFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private ConfigurationFactorySingleton() {
	}

	/**
	 * Provices access to the <code>ConfigurationFacory</code> instance
	 * 
	 * @return The <code>ConfigurationFacory</code> instance
	 * @throws IkeaException If the factory could not be created
	 */
	synchronized public static ConfigurationFactory getInstance() throws IkeaException {

		// Create a new ConfigurationFactory if it's null
		if (sInstance == null) {
			sInstance = new ConfigurationFactoryImpl();
		}

		// Return the instance
		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	synchronized public static void setInstance(ConfigurationFactory pFactory) {
		sInstance = pFactory;
	}
}
