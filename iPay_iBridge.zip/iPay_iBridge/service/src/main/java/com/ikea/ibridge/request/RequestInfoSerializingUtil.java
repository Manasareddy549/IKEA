package com.ikea.ibridge.request;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;

public class RequestInfoSerializingUtil {

	public String serializeRequestInfo(RequestInfo requestInfo) {
		String path = getRequestFolderPath();
		String filename = path + "/" + System.nanoTime() + "RequestInfo.data";

		XStream xstream = new XStream(new JettisonMappedXmlDriver());
		xstream.alias("requestInfo", RequestInfo.class);
		String json = xstream.toXML(requestInfo);
		System.out.println(json);
		BufferedWriter out = null;
		try {
			out = new BufferedWriter(new FileWriter(filename));
			out.write(json);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return filename;
	}

	public String getRequestFolderPath() {
		String path = new String("requests");
		File folder = new File(path);
		if (!folder.exists()) {
			folder.mkdir();
		}
		return path;
	}

	public RequestInfo deserializeRequestInfo(String fileName) {

		String json = null;
		BufferedReader input = null;
		try {
			input = new BufferedReader(new FileReader(fileName));
			json = input.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		if (json == null) {
			System.out.println("Error!!");
		}
		XStream xstream = new XStream(new JettisonMappedXmlDriver());
		xstream.alias("requestInfo", RequestInfo.class);
		RequestInfo requestInfo = (RequestInfo) xstream.fromXML(json);

		return requestInfo;
	}

}
