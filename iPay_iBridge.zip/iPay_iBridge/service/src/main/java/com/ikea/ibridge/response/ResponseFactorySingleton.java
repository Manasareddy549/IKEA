/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ResponseFactorySingleton {

	private static ResponseFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private ResponseFactorySingleton() {
	}

	/**
	 * 
	 * @return
	 * @throws IkeaException
	 */
	public synchronized static ResponseFactory getInstance()
		throws IkeaException {

		if (sInstance == null) {
			sInstance =
				new ResponseFactoryImpl(
					ConfigurationFactorySingleton.getInstance());
		}

		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	public synchronized static void setInstance(ResponseFactory pFactory) {
		sInstance = pFactory;
	}

}
