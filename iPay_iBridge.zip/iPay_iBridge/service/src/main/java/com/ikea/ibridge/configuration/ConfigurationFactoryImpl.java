package com.ikea.ibridge.configuration;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * Implements the ConfigurationFactory interface and provides access to
 * the Configuration instance
 * 
 */
public class ConfigurationFactoryImpl implements ConfigurationFactory {

	private final Configuration mConfiguration;
	private final CalypsoCountries mCalypsoCountries;

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.ConfigurationFactory#getConfiguration()
	 */
	public Configuration getConfiguration()
	{
		return mConfiguration;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.ConfigurationFactory#getCalypsoCountries()
	 */
	public CalypsoCountries getCalypsoCountries()
	{
		return mCalypsoCountries;
	}

	/**
	 * Constructs a ConfigurationFactoryImpl and initializes a Configuration
	 * instance
	 * 
	 * @throws IkeaException
	 */
	public ConfigurationFactoryImpl() throws IkeaException {

		// Create default dependencies
		mConfiguration = new ConfigurationImpl();
		mCalypsoCountries = new CalypsoCountriesImpl();
	}
}
