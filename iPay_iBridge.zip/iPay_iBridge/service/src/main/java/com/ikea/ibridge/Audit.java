package com.ikea.ibridge;

import java.nio.CharBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author snug
 *
 * Main class that initializes and starts the service.
 * 
 */
public class Audit {
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(Audit.class);

	/**
	 * @param pCharBuffer
	 */
	public static void recieve(CharBuffer pCharBuffer) {
		mLog.info("->[" + pCharBuffer.asReadOnlyBuffer().flip() + "]");
	}

	/**
	 * @param pCharBuffer
	 */
	public static String recieveAsString(CharBuffer pCharBuffer) {
		return "->[" + pCharBuffer.asReadOnlyBuffer().flip() + "]";
	}

	/**
	 * @param pAppendable
	 */
	public static void send(Appendable pAppendable) {
		mLog.info("<-[" + pAppendable.toString() + "]");
	}
}