package com.ikea.ibridge.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.net.Socket;

/**
 * 
 * @author snug
 *
 * Interface that provides access to service related instances such as
 * the Service and ServiceRequest classes
 */
public interface ServiceFactory {

	/**
	 * Creates a new Service instance. Normally this is only called once in
	 * order to create the service that listen to incoming connections. However
	 * multiple instances are possible to handle more than one port. Each service
	 * will be provided with a new ExecutorService instance
	 * 
	 * @return The new Service
	 */
	Service createService();

	/**
	 * Creates a new ServiceRequest to handle an incoming request
	 * 
	 * @param pSocket The socket that contains the new communication
	* @ param pRequestDelay The delay to use after processing request
	* @ param pResponseDelay The delay to use before sending the response
	 * @return A new service request
	 * @throws IkeaException If the service request could not be created
	 */
	ServiceRequest createServiceRequest(Socket pSocket, long pRequestDelay,
			long pResponseDelay) throws IkeaException;

}
