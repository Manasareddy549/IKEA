package com.ikea.ibridge.request;

import com.ikea.ebcframework.exception.IkeaException;

import java.nio.CharBuffer;


/**
 */
public interface Request {

	static final String MESSAGE_KEY = "message";

	static final String OPERATION_KEY = "operation";

	static final String OPERATION_ECHO = "echo";
	static final String OPERATION_BALANCE = "balance";
	static final String OPERATION_REDEEM = "redeem";
	static final String OPERATION_ACKNOWLEDGE = "acknowledge";
	static final String OPERATION_LOAD = "load";
	static final String OPERATION_VERIFY_LOAD = "verifyLoad";
	static final String OPERATION_VOID = "void";
	static final String OPERATION_VOID_AMOUNT = "voidAmount";
	static final String OPERATION_CHECK_TRANSACTIONS =
		"checkTransactions";
	static final String OPERATION_BULKLOAD = "BulkLoad";
	static final String OPERATION_VOID_BULKLOAD = "VoidBulkLoad";
	static final String[] OPERATIONS =
		{
			OPERATION_ECHO,
			OPERATION_BALANCE,
			OPERATION_REDEEM,
			OPERATION_ACKNOWLEDGE,
			OPERATION_LOAD,
			OPERATION_VERIFY_LOAD,
			OPERATION_VOID,
			OPERATION_CHECK_TRANSACTIONS,
			OPERATION_BULKLOAD,
			OPERATION_VOID_BULKLOAD};
	
	static final String MASSLOADKEY_MASSLOADID = "massLoadKey.massLoadId";
	static final String POSMASSLOAD_BUCODE = "posMassLoad.buCode";
	static final String POSMASSLOAD_BUTYPE = "posMassLoad.buType";
	static final String POSMASSLOAD_EMPLOYEEID = "posMassLoad.employeeId";
	static final String POSMASSLOAD_COUNTRYCODE= "posMassLoad.countryCode";

	static final String TRANSACTION_TYPE_KEY = "transactionType";

	static final String CARDENTRY_SWIPED_KEY = "cardEntry.swiped";
	static final String CARDENTRY_CARDNUMBER_KEY =
		"cardEntry.cardNumber";
	static final String CARDENTRY_POS_Expire_DATE =
			"cardEntry.expires";
	static final String VERIFICATION_CODE = "verificationCode";

	static final String ENVIRONMENT_AUTO_ACKNOWLEDGE_KEY =
		"sourceSystem.autoAcknowledge";

	static final String SOURCE_SYSTEM_NAME_KEY = "sourceSystem.name";
	static final String SOURCE_SYSTEM_REFERENCE_KEY =
		"sourceSystem.reference";
	static final String SOURCE_SYSTEM_RECEIPT = "sourceSystem.receipt";
	static final String SOURCE_SYSTEM_POS = "sourceSystem.pointOfSale";
	static final String SOURCE_SYSTEM_TRANSMISSION_KEY =
		"sourceSystem.transmissionDateTime";

	static final String REFERENCE_LIST_KEY = "reference";

	static final String ORIGINATOR_BU_TYPE_KEY = "originator.butype";
	static final String ORIGINATOR_BU_CODE_KEY = "originator.bucode";
	static final String ORIGINATOR_EMPLOYEE_KEY = "originator.employee";

	static final String LOAD_AMOUNT_TYPE = "loadAmount.amountType";
	static final String LOAD_AMOUNT_INTEGER =
		"loadAmount.amount.integer";
	static final String LOAD_AMOUNT_DECIMALS =
		"loadAmount.amount.decimals";
	static final String LOAD_AMOUNT_CURRENCY =
		"loadAmount.amount.currency";

	static final String REQUEST_AMOUNT_INTEGER =
		"requestAmount.amount.integer";
	static final String REQUEST_AMOUNT_DECIMALS =
		"requestAmount.amount.decimals";
	static final String REQUEST_AMOUNT_CURRENCY =
		"requestAmount.amount.currency";

	static final String TOTAL_AMOUNT_INTEGER =
		"requestAmount.totalAmount.integer";
	static final String TOTAL_AMOUNT_DECIMALS =
		"requestAmount.totalAmount.decimals";

	static final String TRAINING_MODE = "trainingMode";

	/**
	 * Only used for Calypso protocol!
	 */
	static final String COUNTRY_CODE = "calypso.countryCode";

	/**
	 * Reads the request and analysis the result. The Request interface is implemented by a series of classes
	 * that understands diffrent types of requests. The read method will return the Request that is most
	 * suitable to handle the Request.
	 * 
	 * @param pReadable The Readable to read from
	 * @param pCharBuffer The buffer containing characters already consumed from the Readable
	 * @param pRequestInfo A RequestInfo that is filled in by the Requests as they are analyzing the request
	 * @return The same or a new Request instance that is the most specialized for the Request
	 * @throws IkeaException If an error occur
	 */
	Request read(Readable pReadable, CharBuffer pCharBuffer,
			RequestInfo pRequestInfo) throws IkeaException;
}
