package com.ikea.ibridge.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 */
public class Tags {
	
	private static final DateFormat DF = new SimpleDateFormat("yyyyMMddHHmmss");

	private Tags(){
		
	}
	
	/**
	 * 
	 * @param pTag
	 * @param pValue
	 * @return
	 */
	public static final String tag(String pTag, Object pValue) {
		String vValue = "";
		if (pValue != null) {
			vValue = pValue.toString();
		}
		return "<" + pTag + ">" + vValue + "</" + pTag + ">\n";
	}

	/**
	 * 
	 * @param pTag
	 * @param pValue
	 * @return
	 */
	public static final String tag(String pTag, Date pValue) {
		String vValue = "";
		if (pValue != null) {
			vValue = DF.format(pValue);
		}
		return "<" + pTag + ">" + vValue + "</" + pTag + ">\n";
	}

	/**
	 * 
	 * @param pTag
	 * @param pValue
	 * @return
	 */
	public static final String tag(String pTag, boolean pValue) {
		return "<" + pTag + ">" + (pValue ? "1" : "0") + "</" + pTag + ">\n";
	}

	/**
	 * 
	 * @param pTag
	 * @param pValue
	 * @return
	 */
	public static final String tag(String pTag, long pValue) {
		return "<" + pTag + ">" + pValue + "</" + pTag + ">\n";
	}

}
