/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.request.Request;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ResponseFactoryImpl implements ResponseFactory {

	private ConfigurationFactory mConfigurationFactory = null;

	protected ResponseFactoryImpl(ConfigurationFactory pConfigurationFactory) {
		mConfigurationFactory = pConfigurationFactory;
	}

	/**
	 * 
	 * @return
	 */
	public Response createCalypsoResponse() {
		return new CalypsoResponse(mConfigurationFactory.getCalypsoCountries());
	}

	/**
	 * 
	 * @return
	 */
	public Response createSimulationResponse() {
		return new SimulationResponse();
	}

	/**
	 * 
	 * @return
	 */
	public Response createErrorResponse(String pMessage, String pDetails) {
		return new StaticErrorResponse(pMessage, pDetails);
	}

	/**
	 * 
	 * @return
	 */
	public Response createXmlResponse(String pOperation) throws IkeaException {
		CalypsoCountries vCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
		
		if (Request.OPERATION_ECHO.equals(pOperation)) {
			return new EchoResponse();
		} else if (Request.OPERATION_BALANCE.equals(pOperation)) {
			return new BalanceResponse(vCalypsoCountries);
		} else if (Request.OPERATION_REDEEM.equals(pOperation)) {
			return new RedeemResponse(vCalypsoCountries);
		} else if (Request.OPERATION_ACKNOWLEDGE.equals(pOperation)) {
			return new AcknowledgeResponse();
		} else if (Request.OPERATION_LOAD.equals(pOperation)) {
			return new LoadResponse(vCalypsoCountries);
		} else if (Request.OPERATION_VERIFY_LOAD.equals(pOperation)) {
			return new VerifyLoadResponse();
		} else if (Request.OPERATION_VOID.equals(pOperation)) {
			return new VoidResponse(vCalypsoCountries);
		} else if (Request.OPERATION_CHECK_TRANSACTIONS.equals(pOperation)) {
			return null;
		} else if (Request.OPERATION_BULKLOAD.equals(pOperation)) {
			 return new BulkLoadResponse(vCalypsoCountries);
		} else if (Request.OPERATION_VOID_BULKLOAD.equals(pOperation)) {
			 return new VoidBulkLoadResponse(vCalypsoCountries);
		} else {
			throw new IkeaException(
				"Unknown operation");
		}
	}

	/**
	 * 
	 * @return
	 */
	public ResponseInfo createResponseInfo() {
		return new ResponseInfo();
	}

}
