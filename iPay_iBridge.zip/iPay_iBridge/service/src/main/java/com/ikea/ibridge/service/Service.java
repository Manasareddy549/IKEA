package com.ikea.ibridge.service;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author snug
 *
 * Interface that represents a iBridge service endpoint. There is usually
 * only one service instance, but you could have an iBridge server that runs
 * several services on different port numbers.
 */
public interface Service extends Runnable {

	/**
	 * Start a service at a specified port number and with a given timeout. The timeout
	 * set on the <code>ServerSocket</code> using <code>setSOTimeout</code> and controls
	 * the timeout of the accept call. A low timeout means that the service reponds faster
	 * to a stop call. A timeout of zero means that the service cannot be stopped without
	 * making a connection in order to wake it up.
	 * 
	 * The service is executed on a separate thread so the call to start will return once the
	 * service is up and running.
	 * 
	 * @param pPortNumber The port number to listen to
	 * @param pTimeOut The timeout to set on the socket in milliseconds
	 * @param pRequestDelay The delay to use after processing request
	 * @param pResponseDelay The delay to use before sending the response
	 * @throws IkeaException If an error occurs
	 */
	void start(int pPortNumber, int pTimeout, long pRequestDelay,
			long pResponseDelay) throws IkeaException;

	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	void stop() throws IkeaException;
}
