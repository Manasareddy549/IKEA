/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.net.URL;
import java.nio.Buffer;
import java.nio.CharBuffer;
import java.util.Stack;

import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.response.ResponseFactory;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class XmlRequest implements Request {
	/**
	 * Log category for messages
	 */
	private static final Logger mCategory = LoggerFactory.getLogger(XmlRequest.class);

	/**
	 * Dependencies
	 */
	private ResponseFactory mResponseFactory;
	private Configuration mConfiguration;

	/**
	 * Schema is thread-safe but the Validator is not
	 */
	private static Schema mSchema = null;

	private static final String XSD = "ibridge.xsd";

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public XmlRequest(
		ResponseFactory pResponseFactory,
		Configuration pConfiguration) {
		mResponseFactory = pResponseFactory;
		mConfiguration = pConfiguration;

		mCategory.info(
			"Validating scheme is set to " + mConfiguration.isValidateSchema());

		if (mSchema == null && mConfiguration.isValidateSchema()) {
			try {
				URL vURL =
					Thread.currentThread().getContextClassLoader().getResource(
						XSD);
				if (vURL == null) {
					mCategory.warn(
						"Could not load '"
							+ XSD
							+ "' as resource in context class loader.");
				} else {
					SchemaFactory vSchemaFactory =
						SchemaFactory.newInstance(
							XMLConstants.W3C_XML_SCHEMA_NS_URI);
					mSchema = vSchemaFactory.newSchema(vURL);
				}
			} catch (Exception e) {
				mCategory.warn("Could not get XSD for validating XML.", e);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		final Readable pReadable,
		final CharBuffer pCharBuffer,
		final RequestInfo pRequestInfo)
		throws IkeaException {

		try {
			// Construct a new Reader that returns the characters we have already consumed in
			// pCharBuffer joined with what is left in the pReadable. PushbackReader can be used
			// for just that by allocating a buffer of the same size as pCharBuffer and "unreading"
			// the pCharBuffer. Another problem is that PushbackReader does not except a Readable
			// interface, so we have to wrap on in a Reader subclass  
			Buffer vBuffer = pCharBuffer.asReadOnlyBuffer().flip();
			PushbackReader vPushbackReader = new PushbackReader(new Reader() {
				public int read(char[] arg0, int arg1, int arg2)
					throws IOException {
					return pReadable.read(CharBuffer.wrap(arg0, arg1, arg2));
				}
				public void close() throws IOException {
				}
			}, vBuffer.limit());
			vPushbackReader.unread(
				vBuffer.toString().toCharArray(),
				0,
				vBuffer.limit());

			// Create SAX parser and set namespace and schema
			SAXParserFactory vFactory = SAXParserFactory.newInstance();
			vFactory.setNamespaceAware(true);
			if (mConfiguration.isValidateSchema()) {
				vFactory.setSchema(mSchema);
			}

			// Create parser
			SAXParser vSaxParser = vFactory.newSAXParser();

			// Access the request map of the request info
			final StringBuffer vCurrent = new StringBuffer();
			final Stack<String> vStack = new Stack<String>();

			// Parse XML content to map
			vSaxParser
				.parse(new InputSource(vPushbackReader), new DefaultHandler() {

				public void startElement(String uri, String localName,
								String qName, Attributes attributes)
								throws SAXException {
							vStack.push(qName);
							vCurrent.setLength(0);
						}

						public void endElement(String uri, String localName,
								String qName) throws SAXException {

							pRequestInfo.addToRequestMap(vStack, vCurrent
									.toString());
							vStack.pop();
							vCurrent.setLength(0);
						}

						public void characters(char[] ch, int start, int length)
								throws SAXException {

							vCurrent.append(ch, start, length);
						}

						public void error(SAXParseException e)
								throws SAXException {
							throw e;
						}
			});

			// Set a XmlResponse
			setXmlResponse(pRequestInfo);

			return this;
		} catch (SAXException e) {
			throw new IkeaException(
				"Parsing error when reading XML request",e);

		} catch (Exception e) {
			throw new IkeaException("Unknown error when reading request",e);
		}
	}

	protected void setXmlResponse(final RequestInfo pRequestInfo)
			throws IkeaException {
		pRequestInfo.setResponse(
			mResponseFactory.createXmlResponse(
				pRequestInfo.getOperation()));
	}
}
