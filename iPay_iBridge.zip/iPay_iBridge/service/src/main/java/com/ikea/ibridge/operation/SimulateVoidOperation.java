/*
 * Created on 2007-sep-19
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Date;

import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.persistent.Persist;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SimulateVoidOperation implements Operation {

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = 
		LoggerFactory.getLogger(SimulateVoidOperation.class);
	
	private final Configuration mConfiguration;
	
	public SimulateVoidOperation(Configuration vConfiguration){
		mConfiguration = vConfiguration;
	}

	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing SimulateVoidOperation ");
		BigDecimal vBalance = new BigDecimal(0);
		BigDecimal vNewBalance = new BigDecimal(0);
		BigDecimal vVoidAmount =  new BigDecimal(0);
		
		String vCardNumber = ".";
		ResultSet result = null;

		try {
			Persist dbPersist = new Persist();
			dbPersist.PersistDB(mConfiguration.getSimulationURL().toString());
			result = dbPersist.query("SELECT * FROM REFERENCE WHERE REFERENCE = '" + pRequestInfo.getReferenceList() + "'");
			result.next();
			vCardNumber = result.getString("CARDNUMBER");
			vVoidAmount = result.getBigDecimal("AMOUNT").negate();
			result = dbPersist.query("SELECT * FROM CARDS WHERE Number = " + vCardNumber);
			result.next();
			vBalance = result.getBigDecimal("BALANCE");
			vNewBalance = vBalance.add(vVoidAmount);
			try{
				dbPersist.update("UPDATE CARDS SET Balance = " + vNewBalance +" WHERE Number = " + vCardNumber);					
				dbPersist.update("DELETE FROM REFERENCE WHERE REFERENCE = '" + pRequestInfo.getReferenceList().toString() + "'");
			}catch(Exception e){
				throw new IkeaException("Could not perform Void simulation - Could not find Refernce");
			}
			pResponseInfo.setBalanceDate(pRequestInfo.getTransmissionDateTime());

			pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
		} catch (Exception e) {
			pRequestInfo.setMessage(e.getMessage());
			throw new IkeaException(

				"Could not perform simulation - DB access doesn't work",e);
		}
	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing SimulateVoidOperation in training mode");
		
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
