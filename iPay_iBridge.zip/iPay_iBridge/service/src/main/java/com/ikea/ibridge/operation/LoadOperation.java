/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.List;

import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsLoadCard;
import com.ikea.ebccardpay1.client.vo.VoCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoLoadAmount;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class LoadOperation implements Operation {
    private BsExecuter bsExecuter= BsExecuterFactory.getBsExecuter();

	private CalypsoCountries mCalypsoCountries;
	private ConfigurationFactory mConfigurationFactory;
	
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(LoadOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mConfigurationFactory = ConfigurationFactorySingleton.getInstance();
		mCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
		
		mLog.info("Performing operation load");

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create environment VO
		VoEnvironment vVoEnvironment = new VoEnvironment();
		vVoEnvironment.setOffline(false);
		vVoEnvironment.setAutoAcknowledge(pRequestInfo.isAutoAcknowledge());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(pRequestInfo.getTransmissionDateTime());

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());
		vVoOriginator.setPointOfSale(pRequestInfo.getPointOfSale());
		vVoOriginator.setReceipt(pRequestInfo.getReceipt());

		// Create card entry VO
		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setSwiped(pRequestInfo.isSwiped());
		vVoCardEntry.setCardNumberString(pRequestInfo.getCardNumber());
		vVoCardEntry.setPosExpiryDate(pRequestInfo.getPosExpiryDate());

		// Create load amount VO
		VoLoadAmount vVoLoadAmount = new VoLoadAmount();
		vVoLoadAmount.setAmountType(pRequestInfo.getLoadAmountType());
		
		
		// Currency validation
		if (mCalypsoCountries.isValidCurrency(pRequestInfo.getLoadAmountCurrency())){
			vVoLoadAmount.setCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		}else{
			throw new EmptyRequestException("The POS system sent an invalid Currency Code");
		}
		
		vVoLoadAmount.setLoadAmount(
			Amounts.amount(
				pRequestInfo.getLoadAmountInteger(),
				pRequestInfo.getLoadAmountDecimals()));

		// Create service
		BsLoadCard vBsLoadCard = new BsLoadCard();

		// Set input VO
		vBsLoadCard.setVoSourceSystem(vVoSourceSystem);
		vBsLoadCard.setVoEnvironment(vVoEnvironment);
		vBsLoadCard.setVoOriginator(vVoOriginator);
		vBsLoadCard.setVoReference(vVoReference);

		vBsLoadCard.setVoCardEntry(vVoCardEntry);
		vBsLoadCard.setVoLoadAmount(vVoLoadAmount);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
        bsExecuter.executeBs(vBsLoadCard,"Originator");

		// Check for application errors
		List vApplErrors = vBsLoadCard.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}

		// Read response
		VoCard vVoCard = vBsLoadCard.getVoCard();

		pResponseInfo.setBalanceAmount(vVoCard.getBalanceAmount());
		pResponseInfo.setBalanceCurrencyCode(vVoCard.getCurrencyCode());
		pResponseInfo.setPaidAmount(vVoLoadAmount.getLoadAmount());
		pResponseInfo.setBalanceDate(vVoCard.getBalanceDateTime());
		pResponseInfo.setExpireDate(vVoCard.getExpireDate());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);

	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing operation load in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		pResponseInfo.setPaidAmount(Amounts.amount(
				pRequestInfo.getLoadAmountInteger(),
				pRequestInfo.getLoadAmountDecimals()));
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
