package com.ikea.ibridge.service;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.operation.OperationFactorySingleton;
import com.ikea.ibridge.request.RequestFactorySingleton;
import com.ikea.ibridge.response.ResponseFactorySingleton;

/**
 * 
 * @author snug
 *
 * Provides access to the <code>ServiceFactory</code> instance
 * 
 */
public class ServiceFactorySingleton {

	/**
	 * The single instance of the ServiceFactory factory
	 */
	private static ServiceFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private ServiceFactorySingleton() {
	}

	/**
	 * Provices access to the <code>ServiceFactory</code> instance
	 * 
	 * @return The <code>ServiceFactory</code> instance
	 * @throws IkeaException If the factory could not be created
	 */
	public synchronized static ServiceFactory getInstance()
		throws IkeaException {

		// Create a new ServiceFactory if it's null
		if (sInstance == null) {
			sInstance =
				new ServiceFactoryImpl(
					RequestFactorySingleton.getInstance(),
					ResponseFactorySingleton.getInstance(),
					OperationFactorySingleton.getInstance());
		}

		// Return the instance
		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	public synchronized static void setInstance(ServiceFactory pFactory) {
		sInstance = pFactory;
	}
}
