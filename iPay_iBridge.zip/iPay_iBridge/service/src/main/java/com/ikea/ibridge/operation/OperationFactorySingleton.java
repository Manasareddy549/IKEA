/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.response.ResponseFactorySingleton;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class OperationFactorySingleton {
	protected static OperationFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private OperationFactorySingleton() {
	}

	/**
	 * 
	 * @return
	 * @throws IkeaException
	 */
	synchronized public static OperationFactory getInstance()
		throws IkeaException {

		if (sInstance == null) {
			sInstance =
				new OperationFactoryImpl(
					ConfigurationFactorySingleton
						.getInstance()
						.getConfiguration(),
					ResponseFactorySingleton.getInstance());
		}

		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	synchronized public static void setInstance(OperationFactory pFactory) {
		sInstance = pFactory;
	}

}
