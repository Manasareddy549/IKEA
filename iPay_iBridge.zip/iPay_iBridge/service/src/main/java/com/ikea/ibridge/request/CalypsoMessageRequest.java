/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.nio.CharBuffer;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.response.ResponseFactory;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CalypsoMessageRequest extends GenericRequest {
	/**
	 * The length of the communication header is 8 characters
	 * The length of the message header is 128 characters
	 */
	public static final int HEADER_LENGTH = 136;

	/**
	 */
	public static final int OPERATION_START = 8;
	public static final int OPERATION_LENGTH = 5;
	public static final int MESSAGE_START = 13;
	public static final int MESSAGE_LENGTH = 123;
	public static final int TRAINING_START = 13;
	public static final int TRAINING_LENGTH = 1;
	public static final int OFFLINE_START = 14;
	public static final int OFFLINE_LENGTH = 1;
	public static final int STORE_START = 22;
	public static final int STORE_LENGTH = 3;
	public static final int REFERENCE_POS_START = 26;
	public static final int REFERENCE_POS_LENGTH = 2;
	public static final int REFERENCE_REC_START = 29;
	public static final int REFERENCE_REC_LENGTH = 4;
	public static final int REFERENCE_SEQ_START = 34;
	public static final int REFERENCE_SEQ_LENGTH = 4;
	public static final int TRANSMISSION_DATE_START = 38;
	public static final int TRANSMISSION_DATE_LENGTH = 14;
	public static final int EMPLOYEE_START = 52;
	public static final int EMPLOYEE_LENGTH = 8;
	public static final int COUNTRY_START = 73;
	public static final int COUNTRY_LENGTH = 2;

	/**
	 * 
	 */
	public static final String CALYPSO_REDEEM_OPERATION = "+0112";
	public static final String CALYPSO_LOAD_OPERATION = "+0116";
	public static final String CALYPSO_BALANCE_OPERATION = "+0150";

	/*
	 * Dependecies
	 */
	private final ResponseFactory mResponseFactory;
	private CalypsoCountries mCalypsoCountries = null;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public CalypsoMessageRequest(
		ResponseFactory pResponseFactory,
		CalypsoCountries pCalypsoCountries) {

		mResponseFactory = pResponseFactory;
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		Readable pReadable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo)
		throws IkeaException {

		// Set a CalypsoResponse
		pRequestInfo.setResponse(mResponseFactory.createCalypsoResponse());

		// Prepare for reading
		prepare(pReadable, pCharBuffer, HEADER_LENGTH);

		// Operation
		// Note that Void is set by CalypsoLoadRequest
		pRequestInfo.setOperation(
			translateCalypsoOperation(
				readFromBuffer(OPERATION_START, OPERATION_LENGTH)));

		// Complete message header
		pRequestInfo.setMessage(readFromBuffer(MESSAGE_START, MESSAGE_LENGTH));

		// Training
		if ("1".equals(readFromBuffer(TRAINING_START, TRAINING_LENGTH))) {
			throw new IkeaException(
				"Training mode not supported in iPay");
		}

		// Auto Acknowledge is always on for Calypso protocol
		pRequestInfo.setAutoAcknowledge("1");

		// Store
		String vBuType = "STO";
		String vBuCode = readFromBuffer(STORE_START, STORE_LENGTH);
		pRequestInfo.setBuType(vBuType);
		pRequestInfo.setBuCode(vBuCode);

		// Get reference and receipt number
		String vReferencePosStr =
			readFromBuffer(REFERENCE_POS_START, REFERENCE_POS_LENGTH);
		String vReferenceReceiptStr =
			readFromBuffer(REFERENCE_REC_START, REFERENCE_REC_LENGTH);
		String vReferenceSequenceNoStr =
			readFromBuffer(REFERENCE_SEQ_START, REFERENCE_SEQ_LENGTH);

		long vReferencePos = Long.parseLong(vReferencePosStr);
		long vReferenceReceipt = Long.parseLong(vReferenceReceiptStr);
		long vReferenceSequenceNo = Long.parseLong(vReferenceSequenceNoStr);

		// Build up a unique reference
		pRequestInfo.setSourceSystemReference(
			vBuType
				+ "."
				+ vBuCode
				+ "."
				+ vReferencePos
				+ "."
				+ vReferenceReceipt
				+ "."
				+ vReferenceSequenceNo);
		// Receipt
		pRequestInfo.setReceipt("" + vReferenceReceipt);
		pRequestInfo.setPointOfSale("" + vReferencePos);

		// Transmission Date
		pRequestInfo.setTransmissionDateTime(
			readFromBuffer(TRANSMISSION_DATE_START, TRANSMISSION_DATE_LENGTH));

		// Employee
		pRequestInfo.setEmployee(
			readFromBuffer(EMPLOYEE_START, EMPLOYEE_LENGTH));

		// Employee
		pRequestInfo.setCountryCode(
			readFromBuffer(COUNTRY_START, COUNTRY_LENGTH));

		// Source System, assume CALYPSO
		pRequestInfo.setSourceSystem(
			CalypsoProperties.getSourceSytem(pRequestInfo.getCountryCode()));

		if (Request.OPERATION_BALANCE.equals(pRequestInfo.getOperation())) {
			return new CalypsoBalanceRequest().read(
				pReadable,
				pCharBuffer,
				pRequestInfo);

		} else if (
			Request.OPERATION_LOAD.equals(pRequestInfo.getOperation())) {
			return new CalypsoLoadRequest(mCalypsoCountries).read(
				pReadable,
				pCharBuffer,
				pRequestInfo);
		} else if (
			Request.OPERATION_REDEEM.equals(pRequestInfo.getOperation())) {
			return new CalypsoRedeemRequest(mCalypsoCountries).read(
				pReadable,
				pCharBuffer,
				pRequestInfo);

		} else {
			throw new IkeaException(
				"Unknown operation");
		}
	}

	/**
	 * 
	 */
	private static final String translateCalypsoOperation(String pCalypsoOperation)
		throws IkeaException {

		if (CALYPSO_BALANCE_OPERATION.equals(pCalypsoOperation)) {
			return Request.OPERATION_BALANCE;
		} else if (CALYPSO_LOAD_OPERATION.equals(pCalypsoOperation)) {
			return Request.OPERATION_LOAD;
		} else if (CALYPSO_REDEEM_OPERATION.equals(pCalypsoOperation)) {
			return Request.OPERATION_REDEEM;
		} else {
			throw new IkeaException(
				"Unknown operation");
		}
	}
}
