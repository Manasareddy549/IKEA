package com.ikea.ibridge.configuration;

public class CountrySetting {

	/**
	 * The default decimals to return if special value for country code is not specified
	 */
	private static final int DEFAULT_DECIMALS = 2;
	
	private String mCurrencyCode;
	private int mDecimals = DEFAULT_DECIMALS;

	public String getCurrencyCode() {
		return mCurrencyCode;
	}

	public void setCurrencyCode(String pCurrencyCode) {
		mCurrencyCode = pCurrencyCode;
	}

	public int getDecimals() {
		return mDecimals;
	}

	public void setDecimals(int pDecimals) {
		mDecimals = pDecimals;
	}
}
