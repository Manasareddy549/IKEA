package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsVerifyLoadCard;
import com.ikea.ebccardpay1.client.vo.VoCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoLoadAmount;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;

import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;

public class VerifyLoadOperation implements Operation {
    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	private CalypsoCountries mCalypsoCountries;
	private ConfigurationFactory mConfigurationFactory;
	/**
	 * Log category for messages
	 */
	private static final Logger mLog = 
		LoggerFactory.getLogger(VerifyLoadOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mConfigurationFactory = ConfigurationFactorySingleton.getInstance();
		mCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
		
		mLog.info("Performing operation verify load");

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create environment VO
		VoEnvironment vVoEnvironment = new VoEnvironment();
		vVoEnvironment.setOffline(false);
		//vVoEnvironment.setAutoAcknowledge(pRequestInfo.isAutoAcknowledge());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(pRequestInfo.getTransmissionDateTime());

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());
		vVoOriginator.setPointOfSale(pRequestInfo.getPointOfSale());
		vVoOriginator.setReceipt(pRequestInfo.getReceipt());

		// Create card entry VO
		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setSwiped(pRequestInfo.isSwiped());
		vVoCardEntry.setCardNumberString(pRequestInfo.getCardNumber());

		// Create load amount VO
		VoLoadAmount vVoLoadAmount = new VoLoadAmount();
		vVoLoadAmount.setAmountType(pRequestInfo.getLoadAmountType());

		// Currency validation
		if (mCalypsoCountries.isValidCurrency(pRequestInfo.getLoadAmountCurrency())){
			vVoLoadAmount.setCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		}else{
			throw new EmptyRequestException("The POS system sent an invalid Currency Code");
		}
		
		vVoLoadAmount.setLoadAmount(
			Amounts.amount(
				pRequestInfo.getLoadAmountInteger(),
				pRequestInfo.getLoadAmountDecimals()));

		//TODO Uncomment when the new service exists
		// Create service
		BsVerifyLoadCard vBsVerifyLoadCard = new BsVerifyLoadCard();

		// Set input VO
		vBsVerifyLoadCard.setVoSourceSystem(vVoSourceSystem);
		vBsVerifyLoadCard.setVoEnvironment(vVoEnvironment);
		vBsVerifyLoadCard.setVoOriginator(vVoOriginator);
		vBsVerifyLoadCard.setVoReference(vVoReference);

		vBsVerifyLoadCard.setVoCardEntry(vVoCardEntry);
		vBsVerifyLoadCard.setVoLoadAmount(vVoLoadAmount);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
		bsExecuter.executeBs(vBsVerifyLoadCard,"Originator");

		// Check for application errors
		List vApplErrors = vBsVerifyLoadCard.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}

		// Read response
		VoCard vVoCard = vBsVerifyLoadCard.getVoCard();

		pResponseInfo.setBalanceAmount(vVoCard.getBalanceAmount());
		pResponseInfo.setBalanceCurrencyCode(vVoCard.getCurrencyCode());
		pResponseInfo.setPaidAmount(vVoLoadAmount.getLoadAmount());
		pResponseInfo.setBalanceDate(vVoCard.getBalanceDateTime());
		pResponseInfo.setExpireDate(vVoCard.getExpireDate());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);

	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mConfigurationFactory = ConfigurationFactorySingleton.getInstance();
		mCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
	
		mLog.info("Performing operation verify load in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		pResponseInfo.setPaidAmount(Amounts.amount(
				pRequestInfo.getLoadAmountInteger(),
				pRequestInfo.getLoadAmountDecimals()));
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}

}
