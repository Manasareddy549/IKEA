package com.ikea.ibridge.service;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.net.Socket;
import java.nio.CharBuffer;
import java.util.Arrays;

import com.ikea.ebcframework.error.SystemError;
import com.ikea.ebcframework.exception.SystemErrorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.log4j.NDC;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.operation.Operation;
import com.ikea.ibridge.operation.OperationFactory;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.request.RequestInfoSerializingUtil;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseFactory;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * 
 * @author snug
 *
 * Implements the ServiceRequest interface and also the Runnable interface. The
 * run method of Runnable is called by the ExecutorService thread pool when there
 * is an available thread to execute it. The ServiceRequest is the coordinator between
 * the Request, Operation and Response phases. The ServiceRequestImpl has a lot of
 * dependencies since it is the spider in the web.
 * 
 */
public class ServiceRequestImpl implements ServiceRequest {

	private static final int NUMBER_OF_MILLISECONDS_IN_A_SECOND = 1000;

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = LoggerFactory.getLogger(ServiceImpl.class
			.getName());

	/**
	 * Dependency
	 */
	private Socket mSocket = null;
	private Readable mReadable = null;
	private Appendable mAppendable = null;
	private Flushable mFlushable = null;
	private Closeable mCloseable = null;
	private CharBuffer mCharBuffer = null;
	private RequestInfo mRequestInfo = null;
	private ResponseInfo mResponseInfo = null;
	private Request mInitialRequest = null;
	private OperationFactory mOperationFactory = null;
	private ResponseFactory mResponseFactory = null;
	private long mRequestDelay = 0;
	private long mResponseDelay = 0;

	/**
	 * Construct a ServiceRequestImpl with it's needed dependecies
	 * 
	 * @param pSocket The socket that is established for communication
	 * @param pReadable The readable to use for reading from the socket
	 * @param pAppendable The appendable to use for writing to the socket
	 * @param pCharBuffer The charbuffer holds already processed data
	 * @param pRequestInfo Holds information about parsed data from the request
	 * @param pResponseInfo Holds information about the response to be written to the response
	 * @param pInitialRequest The initial request to use for parsing
	 * @param pOperationFactory A factory for creating the correct operation
	 * @param pRequestDelay The delay to use after processing request
	 * @param pResponseDelay The delay to use before sending the response
	 */
	public ServiceRequestImpl(
		Socket pSocket,
		Readable pReadable,
		Appendable pAppendable,
		Flushable pFlushable,
		Closeable pCloseable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo,
		Request pInitialRequest,
		OperationFactory pOperationFactory,
		ResponseFactory pResponseFactory,
		long pRequestDelay,
		long pResponseDelay) {

		mSocket = pSocket;
		mReadable = pReadable;
		mAppendable = pAppendable;
		mFlushable = pFlushable;
		mCloseable = pCloseable;
		mCharBuffer = pCharBuffer;
		mRequestInfo = pRequestInfo;
		mResponseInfo = pResponseInfo;
		mInitialRequest = pInitialRequest;
		mOperationFactory = pOperationFactory;
		mResponseFactory = pResponseFactory;
		mRequestDelay = pRequestDelay;
		mResponseDelay = pResponseDelay;
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		// Get remote adress
		String vRemote = "Unkown host";
		if (mSocket != null && mSocket.getRemoteSocketAddress() != null) {
			vRemote = mSocket.getRemoteSocketAddress().toString();
		}

		// Push to log4j
		NDC.push(vRemote);

		try {

			// Try to run the service
			service();
		} catch (EmptyRequestException e) {

			// Log this as info, EDGE will ping with empty request data every 10th second.
			if (mLog.isInfoEnabled()) {
				mLog.info(e.getMessage());
			}
		} catch (Exception e) {

			// Log the error
			mLog.error(e.getMessage());
		} finally {

			// Close socket as the last thing we do in this thread
			if (mSocket != null) {
				try {
					mFlushable.flush();
					mCloseable.close();
					mSocket.close();
				} catch (Exception e) {
					// Log the error
					mLog.info(e.getMessage());
				}
			}
			mLog.info("Ending servie");
			NDC.pop();
		}
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.ServiceRequest#service()
	 */
	public void service() throws IkeaException {

		try {
			// Read request
			readRequest();

			// Delay if told to do so
			if (mRequestDelay > 0) {
				delay(mRequestDelay);
			}

			// Perform operation
			performOperation();

			// Delay if told to do so
			if (mResponseDelay > 0) {
				delay(mResponseDelay);
			}

		} catch (IkeaException e) {
			mLog.warn(e.getMessage());
			mRequestInfo.setResponse(
				mResponseFactory.createErrorResponse(
					"Could not read request",
					e.toString()));
		}

		// Write Response
		writeResponse();

	}

	/**
	 * @throws IkeaException
	 */
	private void readRequest() throws IkeaException {

		mLog.info("Reading request");
		try {

			// Read at least one character from Reader to see that data is
			// really provided
			int vLength = 0;
			do {
				vLength = mReadable.read(mCharBuffer);
			} while (vLength >= 0 && mCharBuffer.position() < 1);

			// Error checking
			if (mCharBuffer.position() < 1) {
				throw new EmptyRequestException("The client did not send any data");
			}

			// Try to read. The read method may return another request that
			// where deemed to be more appropriate for the request
			mInitialRequest.read(mReadable, mCharBuffer, mRequestInfo);

			// Error checking
			if (mRequestInfo.size() == 0) {
				throw new IkeaException(
						"The request could not be read");
			} else if (ConfigurationFactorySingleton.getInstance()
					.getConfiguration().isSerializingRequestInfo()) {
				getRequestInfoSerializingUtil().serializeRequestInfo(
						mRequestInfo);
			}
		} catch (IOException e) {
			throw new IkeaException( "Got IOException when reading request.",e);
		}
	}

	private RequestInfoSerializingUtil getRequestInfoSerializingUtil() {
		return new RequestInfoSerializingUtil();
	}

	/**
	 * @throws IkeaException
	 */
	private void performOperation() throws IkeaException {

		try {
			// Create the operation
			Operation vOperation =
				mOperationFactory.createOperation(mRequestInfo.getOperation());

			// Perform operation
			if (mRequestInfo.isTrainingMode())
				vOperation.performTrainingMode(mRequestInfo, mResponseInfo);
			else
				vOperation.perform(mRequestInfo, mResponseInfo);

		} catch (SystemErrorException e) {
			mResponseInfo.setResponseCode(Response.RESPONSE_CODE_ERROR);
			mResponseInfo.setErrorType(Response.ERROR_TYPE_TRY_AGAIN);
			SystemError vSysError = e.getSystemError();
			mResponseInfo.setErrorMessage(vSysError.getMessage());
			mResponseInfo.setErrorDetails(vSysError.toString());

			mLog.error(
				"Got system error when executing Business Service. Sending back response with error type '"
					+ mResponseInfo.getErrorType()
					+ "' and message '"
					+ mResponseInfo.getErrorMessage()
					+ "' and details '"
					+ mResponseInfo.getErrorDetails()
					+ "'.",
				e);
		} catch (Exception e) {
			mResponseInfo.setResponseCode(Response.RESPONSE_CODE_ERROR);
			mResponseInfo.setErrorType(Response.ERROR_TYPE_TRY_AGAIN);
			mResponseInfo.setErrorMessage(e.toString());
			mResponseInfo.setErrorDetails(Arrays.toString(e.getStackTrace()));

			mLog.error(
				"Got exception when performing operation. Sending back response with error type '"
					+ mResponseInfo.getErrorType()
					+ "' and message '"
					+ mResponseInfo.getErrorMessage()
					+ "' and details '"
					+ mResponseInfo.getErrorDetails()
					+ "'.",
				e);
		}
	}

	/**
	 * @throws IkeaException
	 */
	private void writeResponse() throws IkeaException {

		try {
			// Get request
			if (mRequestInfo.getResponse() == null) {
				throw new IkeaException(
					"The response object was not set");
			}

			// Write response
			mLog.info("Writing response");
			mRequestInfo.getResponse().write(
				mAppendable,
				mRequestInfo,
				mResponseInfo);

		} catch (IOException e) {
			throw new IkeaException(
				"Got IOException when writing response.",e);
		}
	}

	/**
	 * @param pSeconds
	 */
	private void delay(long pSeconds) {
		mLog.info("Delaying for " + pSeconds + " seconds");
		try {
			Thread.sleep(pSeconds * NUMBER_OF_MILLISECONDS_IN_A_SECOND);
		} catch (InterruptedException e) {
		}
		mLog.info("Continuing after delay");
	}

}
