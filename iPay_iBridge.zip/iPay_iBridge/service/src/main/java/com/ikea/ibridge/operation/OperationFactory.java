/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface OperationFactory {

	/**
	 * 
	 * @param pOperation
	 * @return
	 * @throws IkeaException
	 */
	public abstract Operation createOperation(String pOperation) throws IkeaException;
}
