/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.List;
import java.util.*;

import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsWithdrawMassLoad;
import com.ikea.ebccardpay1.client.vo.VoMassLoadKey;
import com.ikea.ebccardpay1.client.vo.VoPosMassLoad;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ebccardpay1.client.vo.VoMassLoad;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class VoidBulkLoadOperation implements Operation {
    private BsExecuter bsExecuter= BsExecuterFactory.getBsExecuter();

	private CalypsoCountries mCalypsoCountries;
	private ConfigurationFactory mConfigurationFactory;
	
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(LoadOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mConfigurationFactory = ConfigurationFactorySingleton.getInstance();
		mCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
		
		mLog.info("Performing operation VoidBulkload");
		
		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());
		

		// Create VoMassLoadKey VO
		VoMassLoadKey vVoMassLoadKey = new VoMassLoadKey();
		vVoMassLoadKey.setMassLoadId(pRequestInfo.getMassLoadId());
		
		// Create VoPosMassLoad Vo
		VoPosMassLoad vVoPosMassLoad = new VoPosMassLoad();
		vVoPosMassLoad.setBuCode(pRequestInfo.getPosBuCode());
		vVoPosMassLoad.setBuType(pRequestInfo.getPosBuType());
		vVoPosMassLoad.setCountryCode(pRequestInfo.getPosCountryCode());
		vVoPosMassLoad.setEmployeeId(pRequestInfo.getEmployeeId());

		// Create service
		BsWithdrawMassLoad vBsWithdrawMassLoad = new BsWithdrawMassLoad();

		// Set input VO
		vBsWithdrawMassLoad.setVoMassLoadKey(vVoMassLoadKey);
		vBsWithdrawMassLoad.setPosMassLoad(vVoPosMassLoad);
		
		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
        bsExecuter.executeBs(vBsWithdrawMassLoad,"Originator");

		// Check for application errors
		List vApplErrors = vBsWithdrawMassLoad.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}

		// Read response
		VoMassLoad vVoMassLoad = vBsWithdrawMassLoad.getVoMassLoad(); 
		

		pResponseInfo.setMassLoadId(vVoMassLoad.getMassLoadId());
		


		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);}

	
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing operation VoidBulkload in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getLoadAmountCurrency());
		pResponseInfo.setPaidAmount(Amounts.amount(
				pRequestInfo.getLoadAmountInteger(),
				pRequestInfo.getLoadAmountDecimals()));
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
	//
}

