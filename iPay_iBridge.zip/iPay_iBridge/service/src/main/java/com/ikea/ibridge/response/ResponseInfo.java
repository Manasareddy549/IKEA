/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ibridge.utils.IbridgeError;

/**
 * @author snug
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ResponseInfo {

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = LoggerFactory.getLogger(ResponseInfo.class
			.getName());

	/**
	 * 
	 */
	private String mErrorDetails = null;
	private String mErrorMessage = null;
	private String mErrorType = null;
	private String mResponseCode = null;
	private BigDecimal mPaidAmount = null;
	private BigDecimal mBalanceAmount = null;
	private BigDecimal mRequestAmount = null;
	private BigDecimal mRequestTotalAmount = null;
	private BigDecimal mRedeemAmount = null;
	private String mBalanceCurrencyCode = null;
	private String mRequestCurrencyCode = null;
	private String mRedeemCurrencyCode = null;
	private Date mBalanceDate = null;
	private Date mExpireDate = null;
	private String mFromCardNumberString = null;
	private String mUntilCardNumberString = null;
	private long mMassLoadLockCount = 0;
	private BigDecimal mMassLoadCardAmount = null;
	private BigDecimal mMassLoadTotalAmount = null;
	private String mMassLoadCurrencyCode = null;
	private Date mMassLoadExpiryDate = null;
	private long mMassLoadId = 0;
	

	/**
	 * Create a RequestInfo without request map
	 * 
	 */
	public ResponseInfo() {
	}

	/**
	 * Gets the value
	 * 
	 * @return
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getErrorDetails() throws IkeaException {
		return checkStringParameter(mErrorDetails, "ErrorDetails", true, -1);
	}

	/**
	 * Sets the value
	 * 
	 * @param pErrorDetails
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setErrorDetails(String pErrorDetails) {
		mErrorDetails = pErrorDetails;
	}

	/**
	 * Gets the value
	 * 
	 * @return
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getErrorMessage() throws IkeaException {
		return checkStringParameter(mErrorMessage, "ErrorMessage", true, -1);
	}

	/**
	 * Sets the value
	 * 
	 * @param pErrorMessage
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setErrorMessage(String pErrorMessage) {
		mErrorMessage = pErrorMessage;
	}

	/**
	 * Gets the value
	 * 
	 * @return
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getErrorType() throws IkeaException {
		return checkStringParameter(mErrorType, "ErrorType", true, -1);
	}

	/**
	 * Sets the value
	 * 
	 * @param pErrorType
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setErrorType(String pErrorType) {
		mErrorType = pErrorType;
	}

	/**
	 * Gets the response code parameter
	 * 
	 * @return The response code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getResponseCode() throws IkeaException {
		return checkStringParameter(mResponseCode, "responseCode", false, -1);
	}

	/**
	 * Sets the response code parameter
	 * 
	 * @param pResponseCode
	 *            The response code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setResponseCode(String pResponseCode) {
		mResponseCode = pResponseCode;
	}

	/**
	 * Gets the paid amount parameter
	 * 
	 * @return paid amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public BigDecimal getPaidAmount() throws IkeaException {
		return checkBigDecimalParameter(mPaidAmount, "paidAmount", true, null);
	}

	/**
	 * Sets the paid amount parameter
	 * 
	 * @param pPaidAmount
	 *            paid amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setPaidAmount(BigDecimal pPaidAmount) throws IkeaException {
		mPaidAmount = pPaidAmount;
	}

	/**
	 * Gets the balance amount parameter
	 * 
	 * @return The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public BigDecimal getBalanceAmount() throws IkeaException {
		return checkBigDecimalParameter(mBalanceAmount, "balanceAmount", true,
				null);
	}

	/**
	 * Sets the balance amount parameter
	 * 
	 * @param pBalanceAmount
	 *            The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setBalanceAmount(BigDecimal pBalanceAmount)
			throws IkeaException {
		mBalanceAmount = pBalanceAmount;
	}

	/**
	 * Gets the Currency code parameter
	 * 
	 * @return The Currency code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getBalanceCurrencyCode() throws IkeaException {
		return checkStringParameter(mBalanceCurrencyCode,
				"balanceCurrencyCode", true, -1);
	}

	/**
	 * Sets the Currency parameter
	 * 
	 * @param pCurrencyCode
	 *            The Currency Code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setBalanceCurrencyCode(String pCurrencyCode)
			throws IkeaException {
		mBalanceCurrencyCode = pCurrencyCode;
	}

	/**
	 * Gets the balance amount parameter
	 * 
	 * @return The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public BigDecimal getRequestAmount() throws IkeaException {
		return checkBigDecimalParameter(mRequestAmount, "RequestAmount", true,
				null);
	}

	/**
	 * Sets the balance amount parameter
	 * 
	 * @param pRequestAmount
	 *            The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setRequestAmount(BigDecimal pRequestAmount)
			throws IkeaException {
		mRequestAmount = pRequestAmount;
	}

	/**
	 * Gets the balance amount parameter
	 * 
	 * @return The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public BigDecimal getRequestTotalAmount() throws IkeaException {
		return checkBigDecimalParameter(mRequestTotalAmount,
				"RequestTotalAmount", true, null);
	}

	/**
	 * Sets the balance amount parameter
	 * 
	 * @param pRequestTotalAmount
	 *            The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setRequestTotalAmount(BigDecimal pRequestTotalAmount)
			throws IkeaException {
		mRequestTotalAmount = pRequestTotalAmount;
	}

	/**
	 * Gets the Currency code parameter
	 * 
	 * @return The Currency code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getRequestCurrencyCode() throws IkeaException {
		return checkStringParameter(mRequestCurrencyCode,
				"RequestCurrencyCode", true, -1);
	}

	/**
	 * Sets the Currency parameter
	 * 
	 * @param pRequestCurrencyCode
	 *            The Currency Code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setRequestCurrencyCode(String pRequestCurrencyCode)
			throws IkeaException {
		mRequestCurrencyCode = pRequestCurrencyCode;
	}

	/**
	 * Gets the balance amount parameter
	 * 
	 * @return The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public BigDecimal getRedeemAmount() throws IkeaException {
		return checkBigDecimalParameter(mRedeemAmount, "RedeemAmount", true,
				null);
	}

	/**
	 * Sets the balance amount parameter
	 * 
	 * @param pRedeemAmount
	 *            The balance amount
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setRedeemAmount(BigDecimal pRedeemAmount) throws IkeaException {
		mRedeemAmount = pRedeemAmount;
	}

	/**
	 * Gets the Currency code parameter
	 * 
	 * @return The Currency code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public String getRedeemCurrencyCode() throws IkeaException {
		return checkStringParameter(mRedeemCurrencyCode, "RedeemCurrencyCode",
				true, -1);
	}

	/**
	 * Sets the Currency parameter
	 * 
	 * @param pRedeemCurrencyCode
	 *            The Currency Code
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setRedeemCurrencyCode(String pRedeemCurrencyCode)
			throws IkeaException {
		mRedeemCurrencyCode = pRedeemCurrencyCode;
	}

	/**
	 * Gets the balance date parameter
	 * 
	 * @return The balance date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public Date getBalanceDate() throws IkeaException {
		return checkDateParameter(mBalanceDate, "balanceDate", true, null);
	}

	/**
	 * Sets the balance date parameter
	 * 
	 * @param pBalanceDate
	 *            The balance date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setBalanceDate(Date pBalanceDate) throws IkeaException {
		mBalanceDate = pBalanceDate;
	}

	/**
	 * Gets the expire date parameter
	 * 
	 * @return The expire date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public Date getExpireDate() throws IkeaException {
		return checkDateParameter(mExpireDate, "expireDate", true, null);
	}

	/**
	 * Sets the expire date parameter
	 * 
	 * @param pExpireDate
	 *            The expire date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setExpireDate(Date pExpireDate) throws IkeaException {
		mExpireDate = pExpireDate;
	}
	
	/**
	 * Gets the fromCardNumberString parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getFromCardNumberString() throws IkeaException {
		return checkStringParameter(mFromCardNumberString,"fromCardNumber",true,-1);
	}

	/**
	 * Sets the fromCardNumberString parameter
	 * @param pCardNumber The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setFromCardNumber(String pFromCardNumberString) throws IkeaException {
		mFromCardNumberString = pFromCardNumberString;
	}
	
	/**
	 * Gets the untilCardNumberString parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getUntilCardNumberString() throws IkeaException {
		return checkStringParameter(mUntilCardNumberString,"UntilCardNumber",true,-1);
	}

	/**
	 * Sets the UntilCardNumberString parameter
	 * @param pCardNumber The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setUntilCardNumber(String pUntilCardNumberString) throws IkeaException {
		mUntilCardNumberString = pUntilCardNumberString;
	}
	
	/**
	 * Gets the LockCount parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public long getLockCount() throws IkeaException {
		return checklongParameter(mMassLoadLockCount,"TotalCards",true,0);
	}

	/**
	 * Sets the LockCount parameter
	 * @param pMassLoadLockCount The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setLockCount(long pMassLoadLockCount) throws IkeaException {
		mMassLoadLockCount = pMassLoadLockCount;
	}
	
	/**
	 * Gets the LockCount parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public long getMassLoadId() throws IkeaException {
		return checklongParameter(mMassLoadId,"MassLoadId",true,0);
	}

	/**
	 * Sets the LockCount parameter
	 * @param pMassLoadLockCount The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setMassLoadId(long pMassLoadId) throws IkeaException {
		mMassLoadId = pMassLoadId;
	}
	
	/**
	 * Gets the AmountOnCard parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public BigDecimal getAmount() throws IkeaException {
		return checkBigDecimalParameter(mMassLoadCardAmount,"AmountOnCard",true,null);
	}

	/**
	 * Sets the AmountOnCard parameter
	 * @param pMassLoadCardAmount The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setAmountOnCard(BigDecimal pMassLoadCardAmount) throws IkeaException {
		mMassLoadCardAmount = pMassLoadCardAmount;
	}
	
	/**
	 * Gets the AmountOnCard parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public BigDecimal getTotalAmount() throws IkeaException {
		return checkBigDecimalParameter(mMassLoadTotalAmount,"TotalAmount",true,null);
	}

	/**
	 * Sets the AmountOnCard parameter
	 * @param pMassLoadCardAmount The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setTotalAmount(BigDecimal pMassLoadTotalAmount) throws IkeaException {
		mMassLoadTotalAmount = pMassLoadTotalAmount;
	}
	
	/**
	 * Gets the AmountOnCard parameter
	 * @return The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public String getCurrencyCode() throws IkeaException {
		return checkStringParameter(mMassLoadCurrencyCode,"currency",true,-1);
	}

	/**
	 * Sets the AmountOnCard parameter
	 * @param pMassLoadCardAmount The card number
	 * @throws IkeaException if problems occured with the value
	 */
	public void setCurrencyCode(String pMassLoadCurrencyCode) throws IkeaException {
		mMassLoadCurrencyCode = pMassLoadCurrencyCode;
	}
	/**
	 * Gets the expire date parameter
	 * 
	 * @return The expire date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public Date getExpiryDate() throws IkeaException {
		return checkDateParameter(mMassLoadExpiryDate, "MassLoadexpires", true, null);
	}

	/**
	 * Sets the expire date parameter
	 * 
	 * @param pExpireDate
	 *            The expire date
	 * @throws IkeaException
	 *             if problems occured with the value
	 */
	public void setExpiryDate(Date pMassLoadExpiryDate) throws IkeaException {
		mMassLoadExpiryDate = pMassLoadExpiryDate;
	}

	/**
	 * Helper method for checking parameters.
	 * 
	 * @param pParameter
	 *            The Parameter to check
	 * @param pParameterName
	 *            The Parameter name
	 * @param pMayBeNull
	 *            True if the parameter can be null
	 * @param pLength
	 *            If positive the length of the parameter is checked
	 * @return The value of the parameter
	 * @throws IkeaException
	 *             if parameter was not found or not a string
	 */
	private static final String checkStringParameter(String pParameter,
			String pParameterName, boolean pMayBeNull, int pLength)
			throws IkeaException {

		// Check for null
		if (!pMayBeNull && pParameter == null) {
			throw new IkeaException("Parameter '"
					+ pParameterName + "' may not be null");
		}

		// Check parameter length
		if (pParameter != null && pLength > 0 && pLength != pParameter.length()) {
			throw new IkeaException("Parameter '"
					+ pParameterName + "' had wrong length");
		}

		return pParameter;
	}

	/**
	 * Helper method for checking parameters.
	 * 
	 * @param pParameter
	 *            The Parameter to check
	 * @param pParameterName
	 *            The Parameter name
	 * @param pMayBeNull
	 *            True if the parameter can be null
	 * @param pDefault
	 *            Value returned if parameter is null
	 * @return The value of the parameter
	 * @throws IkeaException
	 *             if parameter was not found or not a string
	 */
	private static BigDecimal checkBigDecimalParameter(
			BigDecimal pParameter, String pParameterName, boolean pMayBeNull,
			BigDecimal pDefault) throws IkeaException {

		// Null returns default value
		if (pMayBeNull && pParameter == null) {
			return pDefault;
		} else if (pParameter == null) {
			throw new IkeaException("Parameter '"
					+ pParameterName + "' may not be null");
		}

		return pParameter;
	}

	/**
	 * Helper method for checking parameters.
	 * 
	 * @param pParameter
	 *            The Parameter to check
	 * @param pParameterName
	 *            The Parameter name
	 * @param pMayBeNull
	 *            True if the parameter can be null
	 * @param pDefault
	 *            Value returned if parameter is null
	 * @return The value of the parameter
	 * @throws IkeaException
	 *             if parameter was not found or not a string
	 */
	private static Date checkDateParameter(Date pParameter,
			String pParameterName, boolean pMayBeNull, Date pDefault)
			throws IkeaException {

		// Null returns default value
		if (pMayBeNull && pParameter == null) {
			return pDefault;
		} else if (pParameter == null) {
			throw new IkeaException("Parameter '"
					+ pParameterName + "' may not be null");
		}

		return pParameter;
	}
	
	
	private static long checklongParameter(long pParameter,
			String pParameterName, boolean pMayBeNull, long pDefault)
			throws IkeaException {

		// Null returns default value
		if (pMayBeNull == false && pParameter == 0) {
			return pDefault;
		} else if (pParameter == 0) {
			throw new IkeaException("Parameter '"
					+ pParameterName + "' may not be null");
		}

		return pParameter;
	}
	

	@SuppressWarnings("unchecked")
	public void translateApplicationErrors(List vApplErrors)
			throws IkeaException {
		Iterator errorlist=vApplErrors.iterator();
		ArrayList iBridgeErrorlist= new ArrayList();
		IbridgeError vApplError=null;
		while (errorlist.hasNext()) {
			ApplicationError error = (ApplicationError)errorlist.next(); //vApplErrors.get(0);
			vApplError= new IbridgeError(error);
			iBridgeErrorlist.add(vApplError);
		}
		vApplError=(IbridgeError) iBridgeErrorlist.get(0);

		setResponseCode(Response.RESPONSE_CODE_ERROR);

		// Get the first application error and translate it.
		//ApplicationError vApplError = (ApplicationError) vApplErrors.get(0);
		String vErrorType;

		switch (vApplError.getErrorCode()) {
		case ApplicationErrorCodes.INVALID_VERIFICATION_CODE:
			vErrorType = Response.ERROR_TYPE_INVALID_PIN;
			break;
		case ApplicationErrorCodes.INVALID_INPUT_GENERAL:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_AMOUNT:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_CARD_NUMBER:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_CURRENCY:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_ENVIRONMENT:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_ORIGINATOR:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_REFERENCE:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_SOURCE_SYSTEM:
		case ApplicationErrorCodes.INVALID_INPUT_MISSING_TRANSMISSION_DATE:

			vErrorType = Response.ERROR_TYPE_CALL_CENTER;
			break;

		case ApplicationErrorCodes.INVALID_AMOUNT_GENERAL:
		case ApplicationErrorCodes.INVALID_CARD_DUPLICATE_CARD:
		case ApplicationErrorCodes.INVALID_CARD_GENERAL:
		case ApplicationErrorCodes.INVALID_CARD_INVALID_CHECK_DIGIT:
		case ApplicationErrorCodes.INVALID_CARD_INVALID_ISSUER:
		case ApplicationErrorCodes.INVALID_CARD_INVALID_NUMBER:
		case ApplicationErrorCodes.INVALID_CARD_INVALID_TYPE_DIGIT:
		case ApplicationErrorCodes.INVALID_CARD_EXPIRED_CARD:
		case ApplicationErrorCodes.INVALID_CARD_BLOCKED_CARD:
		case ApplicationErrorCodes.INVALID_CARD_NOT_FOUND:

			vErrorType = Response.ERROR_TYPE_INVALID_CARD;
			break;

		default:
			mLog.warn("Unmapped application error code '"
					+ vApplError.getErrorCode()
					+ "'. Sending back internal error type.");
			vErrorType = Response.ERROR_TYPE_TRY_AGAIN;
			break;
		}

		setErrorType(vErrorType);
		setErrorMessage(vApplError.getMessage());
		setErrorDetails(Arrays.toString(iBridgeErrorlist.toArray()));

		if (mLog.isInfoEnabled()) {
			mLog
					.info("Got application error when performing operation. Sending back response with error type '"
							+ getErrorType()
							+ "' and message '"
							+ getErrorMessage()
							+ "' and details '"
							+ getErrorDetails() + "'.");
		}

	}
}
