/*
 * Created on 2007-jun-29
 *
 */
package com.ikea.ibridge.response;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author anms
 *
 */
public abstract class XmlResponse implements Response {

	/**
	 * 
	 */
	public XmlResponse() {
		super();
	}

	/**
	 * 
	 * @param pAppendable
	 * @param pRequestInfo
	 * @param pResponseInfo
	 * @throws IkeaException
	 * @throws IOException
	 */
	public abstract void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException;

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.request.RequestInfo, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void write(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		if (Response
			.RESPONSE_CODE_NORMAL
			.equals(pResponseInfo.getResponseCode())) {

			writeXml(pAppendable, pRequestInfo, pResponseInfo);
		} else {
			writeError(pAppendable, pRequestInfo, pResponseInfo);
		}

	}

	protected void writeSourceSystem(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		if (pRequestInfo.getSourceSystem() != null
			&& pRequestInfo.getSourceSystem().length() > 0) {

			pAppendable.append("<sourceSystem>\n");
			pAppendable.append(
				Tags.tag("name", pRequestInfo.getSourceSystem()));
			pAppendable.append(
				Tags.tag("reference", pRequestInfo.getSourceSystemReference()));
			pAppendable.append(
				Tags.tag(
					"transmissionDateTime",
					pRequestInfo.getTransmissionDateTime()));
			if(!Request.OPERATION_VERIFY_LOAD.equals(pRequestInfo.getOperation())){
				pAppendable.append(
						Tags.tag("autoAcknowledge", pRequestInfo.isAutoAcknowledge()));
			}
			pAppendable.append(Tags.tag("receipt", pRequestInfo.getReceipt()));
			pAppendable.append(
				Tags.tag("pointOfSale", pRequestInfo.getPointOfSale()));
			pAppendable.append("</sourceSystem>\n");
		}
	}

	/**
	 * 
	 * @param pAppendable
	 * @param pRequestInfo
	 * @param pResponseInfo
	 * @throws IkeaException
	 * @throws IOException
	 */
	protected void writeError(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");
		pAppendable.append("<errorResponse>\n");

		// Get source system if available
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);

		// Write the error message
		pAppendable.append("<error>\n");

		pAppendable.append(
			"<type>" + pResponseInfo.getErrorType() + "</type>\n");
		pAppendable.append(
			"<message>" + pResponseInfo.getErrorMessage() + "</message>\n");
		pAppendable.append(
			"<details>" + pResponseInfo.getErrorDetails() + "</details>\n");

		pAppendable.append("</error>\n");

		pAppendable.append("</errorResponse>\n");
		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}

	/**
	 * Get the unscaled amount, but first rounds down the amount so it won't have
	 * decimals left after the unscale operation (which gives an exception)
	 * 
	 * @param pAmount
	 * @param pScale
	 * @return long
	 */
	protected long getRoundedUnscaledAmount(BigDecimal pAmount, int pScale) {
		if (pAmount.scale() > pScale)
			pAmount = pAmount.setScale(pScale, RoundingMode.DOWN);
		
		return Amounts.unscaledAmount(pAmount, pScale);
	}
}
