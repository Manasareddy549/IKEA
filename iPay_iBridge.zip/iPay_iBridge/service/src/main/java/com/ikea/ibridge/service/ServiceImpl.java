package com.ikea.ibridge.service;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author snug
 *
 * Implements the Service interface
 * 
 */
public class ServiceImpl implements Service {

	private static final int WAIT_TIME_IN_SECONDS = 120;

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = LoggerFactory.getLogger(ServiceImpl.class);

	/**
	 * Dependencies
	 */
	private ExecutorService mExecutorService = null;
	private ServiceFactory mServiceFactory = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	/**
	 * The service thread that handles incoming connections
	 */
	private Thread mServiceThread = null;

	/**
	 * Barrier for syncronizing between the calling thread and the service thread
	 */
	private CyclicBarrier mBarrier = new CyclicBarrier(2);

	/**
	 * The server socket used for incoming connections
	 */
	private ServerSocket mServerSocket = null;

	private long mRequestDelay = 0;
	private long mResponseDelay = 0;

	/**
	 * Dependency injector constructor, used by factory and unit testing. Don't call
	 * the constructor directly, use ServiceFactorySingleton.getInstance().createService().
	 * The constructor is public so it can be used by the test cases.
	 */
	public ServiceImpl(
		ExecutorService pExecutorService,
		ServiceFactory pServiceFactory) {

		mExecutorService = pExecutorService;
		mServiceFactory = pServiceFactory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.Service#start(int, int, long, long)
	 */
	public void start(
		int pPortNumber,
		int pTimeout,
		long pRequestDelay,
		long pResponseDelay)
		throws IkeaException {

		// Check running flag
		if (mRunning) {
			throw new IkeaException("Service is already running");
		}

		// Info in the log
		mLog.info("Starting iBridge service on port " + pPortNumber);

		mRequestDelay = pRequestDelay;
		mResponseDelay = pResponseDelay;

		try {
			// Bind to socket
			mServerSocket = new ServerSocket(pPortNumber);

			// Set timeout
			mServerSocket.setSoTimeout(pTimeout);

			// Set running flag to true to indicate that the service is executing
			mRunning = true;

			// Create new thread to accept incoming connections
			mServiceThread = new Thread(this);
			mServiceThread.setName("iBridge Service");
			mServiceThread.start();

			// Wait for the new thread to start
			mBarrier.await();

		} catch (Exception e) {

			// Shutdown thread pool
			mExecutorService.shutdown();
			throw new IkeaException(e);
		}

		mLog.info("iBridge started");
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.Service#stop()
	 */
	public void stop() throws IkeaException {

		// Check running flag
		if (!mRunning) {
			throw new IkeaException("Service is not running");
		}

		try {

			// Set running flag to false to indicate that the service is stopped
			mRunning = false;

			// Close incoming socket
			mServerSocket.close();

			// Wait for the service thread to stop executing
			mServiceThread.join();

			// Shutdown thread pool
			mExecutorService.shutdown();

			// Wait for all threads to stop
			mExecutorService.awaitTermination(WAIT_TIME_IN_SECONDS, TimeUnit.SECONDS);

		} catch (Exception e) {
			throw new IkeaException(e);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		try {
			// Wait on the barrier to signal to the main thread that the service is up		
			mBarrier.await();

			// Info in the log
			mLog.info("Accepting incoming connections");

			// Keep processing incoming connections until stop has been called
			while (mRunning) {

				try {
					// Start accepting incoming connections
					Socket vSocket = mServerSocket.accept();

					if (vSocket != null) {
						// Create service request
						ServiceRequest vServiceRequest =
							mServiceFactory.createServiceRequest(
								vSocket,
								mRequestDelay,
								mResponseDelay);

						// Let the pool handle it
						mExecutorService.execute(vServiceRequest);
					}
				} catch (SocketTimeoutException e) {

					// Time outs can be ignored
					mLog.debug(e.getMessage());
				} catch (IOException e) {

					// Other IO exceptions needs to be logged
					mLog.error(e.getMessage());
				} catch (IkeaException e) {

					// Ikea exceptions needs to be logged
					mLog.error(e.getMessage());
				}
			}
		} catch (BrokenBarrierException e) {

			// Barrier related, bail out
			mLog.error(e.getMessage());
		} catch (InterruptedException e) {

			// Barrier related, bail out
			mLog.error(e.getMessage());
		}
	}
}
