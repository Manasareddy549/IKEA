/*
 * Created on 2006-apr-24
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.response.ResponseFactorySingleton;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RequestFactorySingleton {

	private static RequestFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private RequestFactorySingleton() {
	}

	/**
	 * 
	 * @return
	 * @throws IkeaException
	 */
	public synchronized static RequestFactory getInstance()
		throws IkeaException {

		if (sInstance == null) {
			sInstance =
				new RequestFactoryImpl(
					ResponseFactorySingleton.getInstance(),
					ConfigurationFactorySingleton.getInstance());
		}

		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	public synchronized static void setInstance(RequestFactory pFactory) {
		sInstance = pFactory;
	}

}
