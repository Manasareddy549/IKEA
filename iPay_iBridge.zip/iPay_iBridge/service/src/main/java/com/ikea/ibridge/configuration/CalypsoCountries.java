package com.ikea.ibridge.configuration;


import com.ikea.ebcframework.exception.IkeaException;

/*
 * Interface for providing country settings information the the iBridge service.
 * This is typically read from a configuration file.
 * 
 */
public interface CalypsoCountries {

	/**
	 * Given a country code (two letter) it returns the currency code (three letter)
	 * for that country
	 * 
	 * @param pCountryCode The country code for the country
	 * @return The currency code
	 */
	String getCurrencyCode(String pCountryCode) throws IkeaException;

	/**
	 * Given a country code (two letter) it returns the number of decimals for that
	 * country
	 * 
	 * @param pCountryCode The country code for the country
	 * @return The number of decimals
	 */
	int getDecimals(String pCountryCode) throws IkeaException;

	/**
	 * Read the country settings for an external XML file. this method should only be called once
	 * before accepting incoming connections
	 * 
	 * @throws IkeaException
	 */
	void readCountries() throws IkeaException;

	/**
	 * Updates the country settings based on an external XML file. This method can be scheduled at
	 * regular intervals
	 */
	void updateCountries();
	
	/**
	 * Updates the currency settings based on an external XML file. This method can be scheduled at
	 * regular intervals
	 */
	boolean isValidCurrency(String pCurrency) throws IkeaException;
	
	/**
	 * Find the first entry with the specified currency and return the decimals for it
	 */
	int getDecimalsByCurrency(String pCurrency) throws IkeaException;

}
