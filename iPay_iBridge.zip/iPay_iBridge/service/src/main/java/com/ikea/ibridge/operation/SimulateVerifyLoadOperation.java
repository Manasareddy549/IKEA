package com.ikea.ibridge.operation;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Date;

import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.persistent.Persist;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

public class SimulateVerifyLoadOperation implements Operation {

		/**
		 * Log category for messages
		 */
		private static final Logger mLog = 
			LoggerFactory.getLogger(SimulateVerifyLoadOperation.class.getName());
		
		private final Configuration mConfiguration;
		
		public SimulateVerifyLoadOperation(Configuration vConfiguration){
			mConfiguration = vConfiguration;
		}

		public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
			throws IkeaException {
			
			mLog.info("Performing SimulateVerifyLoadOperation");
			String vCurrency = "";
			int vDecimals = 0;
			String vCardNumber = ".";
			ResultSet result = null;

			try {
				Persist dbPersist = new Persist();
				dbPersist.PersistDB(mConfiguration.getSimulationURL().toString());
				
				vCardNumber = pRequestInfo.getCardNumber();
				result = dbPersist.query("SELECT * FROM CARDS WHERE Number = " + vCardNumber);
				result.next();
				vDecimals = result.getInt("DECIMAL");
				BigDecimal vBalance = result.getBigDecimal("BALANCE");
				vCurrency = result.getString("CURRENCY");
				if (pRequestInfo.getLoadAmountCurrency().equals(vCurrency)){
					
					BigDecimal vNewBalance = vBalance.add(new BigDecimal((pRequestInfo.getLoadAmountInteger())));
					
					if (mConfiguration.getProtocol().equalsIgnoreCase("calypso") & vDecimals == 0){
						pResponseInfo.setBalanceAmount(vNewBalance);	
					}else{
						pResponseInfo.setBalanceAmount(vNewBalance.movePointLeft(vDecimals));	
					} 
					pResponseInfo.setBalanceCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setBalanceDate(pRequestInfo.getTransmissionDateTime());
					pResponseInfo.setExpireDate(pRequestInfo.getTransmissionDateTime());
				} else {
					throw new IkeaException("Could not perform simulation - Currency mismatch");
				}
					
				pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
			} catch (Exception e) {
				pRequestInfo.setMessage(e.getMessage());
				throw new IkeaException(
					"Could not perform simulation - DB access doesn't work",e);
			}
		}
		
		public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
			throws IkeaException {		
			
			mLog.info("Performing SimulateVerifyLoadOperation in training mode");

			pResponseInfo.setBalanceAmount(Amounts.amount(200));
			pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getLoadAmountCurrency());
			pResponseInfo.setBalanceDate(new Date());
			pResponseInfo.setExpireDate(new Date(112, 9, 11));

			pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
		}

}
