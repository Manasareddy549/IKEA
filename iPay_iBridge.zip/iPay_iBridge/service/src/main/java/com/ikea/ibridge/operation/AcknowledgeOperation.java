package com.ikea.ibridge.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ikea.ebccardpay1.client.bs.BsAcknowledge;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoReferenceSpecifier;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ebcframework.services.BsExecuterFactory;

import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AcknowledgeOperation implements Operation {

    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	/**
	 * Log category for messages
	 */
    private final static Logger mLog = LoggerFactory.getLogger(AcknowledgeOperation.class);

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing operation acknowledge");

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(pRequestInfo.getTransmissionDateTime());

		// Create reference specifier list VO
		List vList = pRequestInfo.getReferenceList();
		List<VoReferenceSpecifier> vVoReferenceSpecifierList =
			new ArrayList<VoReferenceSpecifier>();
		for (Iterator i = vList.iterator(); i.hasNext();) {
			String vReference = (String) i.next();
			VoReferenceSpecifier vVoReferenceSpecifier =
				new VoReferenceSpecifier();
			vVoReferenceSpecifier.setReference(vReference);
			vVoReferenceSpecifierList.add(
				vVoReferenceSpecifier);
		}

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create service
		BsAcknowledge vBsAcknowledge = new BsAcknowledge();

		// Set input VO
		vBsAcknowledge.setVoOriginator(vVoOriginator);
		vBsAcknowledge.setVoReference(vVoReference);
		vBsAcknowledge.setVoSourceSystem(vVoSourceSystem);
		vBsAcknowledge.setVoReferenceSpecifierList(vVoReferenceSpecifierList);

		// Execute service
        //BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
		bsExecuter.executeBs(vBsAcknowledge,"Originator");

		// Check for application errors
		List vApplErrors = vBsAcknowledge.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			pResponseInfo.translateApplicationErrors(vApplErrors);
			return;
		}

		// Read response

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo) {
	
		mLog.info("Performing operation acknowledge in training mode");
		
		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
