/*
 * Created on 2007-sep-19
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.persistent.Persist;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SimulateRedeemOperation implements Operation {

	/**
	 * Log category for messages
	 */
	private static final Logger mLog = 
		LoggerFactory.getLogger(SimulateRedeemOperation.class.getName());
	
	private final Configuration mConfiguration;
	
	public SimulateRedeemOperation(Configuration vConfiguration){
		mConfiguration = vConfiguration;
	}

	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		mLog.info("Performing SimulateRedeemOperation");
		String vCurrency = "";
		int vDecimals = 0;
		String vCardNumber = ".";
		ResultSet result = null;
		BigDecimal vNewBalance = null;
		try {
			Persist dbPersist = new Persist();
			dbPersist.PersistDB(mConfiguration.getSimulationURL().toString());
			
			vCardNumber = pRequestInfo.getCardNumber();
			result = dbPersist.query("SELECT * FROM CARDS WHERE Number = " + vCardNumber);
			result.next();
			vDecimals = result.getInt("DECIMAL");
			BigDecimal vBalance = result.getBigDecimal("BALANCE");
			vCurrency = result.getString("CURRENCY");
							
			if (pRequestInfo.getRequestAmountCurrency().equals(vCurrency)){
				if (vBalance.compareTo(new BigDecimal(pRequestInfo.getRequestAmountInteger())) == -1){
					vNewBalance = new BigDecimal(0);
					dbPersist.update("UPDATE CARDS SET Balance = " + vNewBalance +" WHERE Number = " + vCardNumber);
					dbPersist.update("INSERT INTO REFERENCE VALUES('[" + pRequestInfo.getSourceSystemReference().toString() + "]'," + vBalance.negate()+ ",'" + vCardNumber + "')" );
					pResponseInfo.setRedeemAmount(vBalance.movePointLeft(vDecimals));
					pResponseInfo.setRequestAmount(( new BigDecimal(pRequestInfo.getRequestAmountInteger())).movePointLeft(vDecimals));
					pResponseInfo.setRedeemCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setRequestTotalAmount ((new BigDecimal(pRequestInfo.getTotalAmountInteger())).movePointLeft(vDecimals));
					pResponseInfo.setRequestCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setBalanceCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setBalanceAmount(vNewBalance.movePointLeft(vDecimals));
					pResponseInfo.setBalanceDate(pRequestInfo.getTransmissionDateTime());
					pResponseInfo.setExpireDate(pRequestInfo.getTransmissionDateTime());
				} else {
					
					vNewBalance = vBalance.subtract(new BigDecimal(pRequestInfo.getRequestAmountInteger()));
					
					dbPersist.update("UPDATE CARDS SET Balance = " + vNewBalance +" WHERE Number = " + vCardNumber);
					dbPersist.update("INSERT INTO REFERENCE VALUES('[" + pRequestInfo.getSourceSystemReference().toString() + "]'," + (new BigDecimal(pRequestInfo.getRequestAmountInteger())).negate()+ "," + vCardNumber + ")" );
					pResponseInfo.setRedeemAmount((new BigDecimal(pRequestInfo.getRequestAmountInteger())).movePointLeft(vDecimals));
					pResponseInfo.setRedeemCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setRequestAmount(( new BigDecimal(pRequestInfo.getRequestAmountInteger())).movePointLeft(vDecimals));
					pResponseInfo.setRequestTotalAmount ((new BigDecimal(pRequestInfo.getTotalAmountInteger())).movePointLeft(vDecimals));
					pResponseInfo.setRequestCurrencyCode(result.getString("CURRENCY"));
					pResponseInfo.setBalanceCurrencyCode(result.getString("CURRENCY"));
					if (mConfiguration.getProtocol().equalsIgnoreCase("calypso") & vDecimals == 0){
						pResponseInfo.setBalanceAmount(vNewBalance);	
					}else{
						pResponseInfo.setBalanceAmount(vNewBalance.movePointLeft(vDecimals));
					} 
					
					
					pResponseInfo.setBalanceDate(pRequestInfo.getTransmissionDateTime());
					pResponseInfo.setExpireDate(pRequestInfo.getTransmissionDateTime());
				}
			}else {
				throw new IkeaException("Could not perform simulation - Currency mismatch");
			}
		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
		} catch (Exception e) {
			pRequestInfo.setMessage(e.getMessage());
			throw new IkeaException(
				"Could not perform simulation - DB access doesn't work",e);
		}
	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing SimulateRedeemOperation in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getRequestAmountCurrency());
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setRequestAmount(Amounts.amount(
				pRequestInfo.getRequestAmountInteger(),
				pRequestInfo.getRequestAmountDecimals()));
		pResponseInfo.setRequestTotalAmount(Amounts.amount(
				pRequestInfo.getTotalAmountInteger(),
				pRequestInfo.getTotalAmountDecimals()));

		pResponseInfo.setRedeemAmount(Amounts.amount(150));

		pResponseInfo.setRequestCurrencyCode(pRequestInfo.getRequestAmountCurrency());
		pResponseInfo.setRedeemCurrencyCode(pRequestInfo.getRequestAmountCurrency());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
