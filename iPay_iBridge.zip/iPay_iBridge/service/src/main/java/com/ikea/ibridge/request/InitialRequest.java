/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.nio.CharBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class InitialRequest extends GenericRequest {

	/**
	 * Log category for messages
	 */
	private static final Logger mLog =
		LoggerFactory.getLogger(InitialRequest.class);

	/**
	 */
	public static final int TEST_LENGTH = 3;

	/*
	 * Dependecies
	 */
	private final RequestFactory mRequestFactory;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public InitialRequest(RequestFactory pRequestFactory) {
		mRequestFactory = pRequestFactory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		Readable pReadable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo)
		throws IkeaException {

		// Prepare for reading
		prepare(pReadable, pCharBuffer, TEST_LENGTH);

		Request vRequest = null;
		Request vReturnRequest = null;

		// Access first 3 characters of the charbuffer
		String test = readFromBuffer(0, TEST_LENGTH);
		if (test.equals("ICE")) {
			vRequest = mRequestFactory.createCalypsoRequest();
		} else {
			vRequest = mRequestFactory.createXMLRequest();
		}

		try {
			vReturnRequest =
				vRequest.read(pReadable, pCharBuffer, pRequestInfo);
		} catch (IkeaException e) {
			// Log the incomming chars together with the error in the log file for tracabillity
			mLog.error(Audit.recieveAsString(pCharBuffer), e);
			throw e;
		} catch (RuntimeException e) {
			// Log the incomming chars together with the error in the log file for tracabillity
			mLog.error(Audit.recieveAsString(pCharBuffer), e);
			throw e;
		} finally {
			Audit.recieve(pCharBuffer);
		}
		return vReturnRequest;

	}

}
