/*
 * Created on 2006-maj-12
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CalypsoResponse implements Response {

	/**
	 * Log category for messages
	 */
	private static final Logger mLog =
		LoggerFactory.getLogger(CalypsoResponse.class.getName());

	/**
	 * 
	 */
	public static final String CALYPSO_RESPONSE = "+0195";

	/**
	 * These are the error codes and the menaing of them in iCard
	 */
	public static final String CALYPSO_SUCCESS = "+000";
	public static final String CALYPSO_CALL_CENTER = "+100";
	public static final String CALYPSO_TRY_AGAIN = "+200";
	public static final String CALYPSO_INVALID_CARD = "+300";
	public static final String CALYPSO_INVALID_PIN = "+310";

	/**
	 * 
	 */
	public static final int STORENUMBER_LENGTH = 4;

	/**
	 * Dependency injected
	 */
	private CalypsoCountries mCalypsoCountries = null;

	private DateFormat mDateFormat;

	public CalypsoResponse(CalypsoCountries pCalypsoCountries) {
		mCalypsoCountries = pCalypsoCountries;
		mDateFormat = new SimpleDateFormat("yyyyMMdd");
	}

	/**
	 * 
	 * @param pAppendable
	 * @param pResponseInfo
	 * @throws IkeaException
	 */
	public void write(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Communication header
		pAppendable.append("ICE+1000");

		// Message header
		pAppendable.append(CALYPSO_RESPONSE);
		pAppendable.append(pRequestInfo.getMessage());

		// Response
		pAppendable.append(padPositive("", "unused", 5));
		pAppendable.append(pad("", "eightNotUsedChars", 8, '0'));
		pAppendable.append(
			translateCalypsoResponseCode(
				pResponseInfo.getResponseCode(),
				pResponseInfo.getErrorType()));

		// Amounts
		int vScale =
			mCalypsoCountries.getDecimals(pRequestInfo.getCountryCode());
		pAppendable.append(
			padAmount(
				getAuthorizedAmount(pRequestInfo, pResponseInfo),
				vScale,
				"authorizedAmount",
				11));

/**
*Special HU och JP
* because of non decimals
*/

		if ( (vScale == 0) && !(pResponseInfo.getBalanceCurrencyCode() =="JPY" |  pResponseInfo.getBalanceCurrencyCode() =="HUF" ))
		{


		pAppendable.append(
			padAmount(
				pResponseInfo.getBalanceAmount().setScale(0, RoundingMode.DOWN),
				vScale,
				"balanceAmount",
				11));

		}

		else
		{

		pAppendable.append(
			padAmount(
				pResponseInfo.getBalanceAmount(),
				vScale,
				"balanceAmount",
				11));
	} 


		// Authorization (always zero)
		pAppendable.append(padInt(0, "authorization", 24));

		// Expire
		if (pResponseInfo.getExpireDate() != null) {
			pAppendable.append(
				mDateFormat.format(pResponseInfo.getExpireDate()));
		} else {
			pAppendable.append("        ");
		}

		pAppendable.append(pad("", "futureUseMaybe", 824, '0'));

		Audit.send(pAppendable);
	}

	/**
	 * 
	 * @param vParameter
	 * @param vLength
	 */
	private static final String pad(
		String vParameter,
		String vParameterName,
		int vLength,
		char vPadCharacter)
		throws IkeaException {

		StringBuffer vBuffer = new StringBuffer("");
		String vPadString = "" + vPadCharacter;

		if (vParameter == null)
			vParameter = "";

		if (vParameter.length() > (vLength - 1)) {
			mLog.warn(
				"Parameter '"
					+ vParameterName
					+ "' exceeds valid length of "
					+ vLength
					+ ". Filling with char '9'.");
			vPadString = "9";
			vParameter = "9";
		}

		int pad = vLength - vParameter.length();
		for (int i = 0; i < pad; i++) {
			vBuffer.append(vPadString);
		}

		vBuffer.append(vParameter);

		return vBuffer.toString();
	}

	/**
	 * 
	 * @param vParameter
	 * @param vLength
	 */
	private static final String padPositive(
		String vParameter,
		String vParameterName,
		int vLength)
		throws IkeaException {

		return "+" + pad(vParameter, vParameterName, vLength - 1, '0');
	}

	/**
	 * 
	 * @param vParameter
	 * @param vLength
	 */
	private static final String padInt(
		int vParameter,
		String vParameterName,
		int vLength)
		throws IkeaException {

		return pad("" + vParameter, vParameterName, vLength, ' ');
	}

	/**
	 * 
	 * @param vParameter
	 * @param vLength
	 */
	private static final String padNumberWithSign(
		long vParameter,
		String vParameterName,
		int vLength)
		throws IkeaException {

		String vSign = "";
		String vString = null;

		if (vParameter < 0) {
			vSign = "-";
			vString = "" + (-1) * vParameter;
		} else {
			vSign = "+";
			vString = "" + vParameter;
		}

		return vSign + pad(vString, vParameterName, vLength - 1, '0');
	}

	/**
	 * @param pRequestInfo
	 * @param pResponseInfo
	 * @return If request was REDEEM get redeemedAmount else paidAmount
	 */
	private BigDecimal getAuthorizedAmount(
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo) throws IkeaException {

		try {
			if (pRequestInfo.getOperation() != null
				&& pRequestInfo.getOperation().equals(Request.OPERATION_REDEEM))
				return pResponseInfo.getRedeemAmount();
			else {
				return pResponseInfo.getPaidAmount();
			}
		} catch (IkeaException e) {
			return pResponseInfo.getPaidAmount();
		}
	}

	/**
	 * 
	 * @param vParameter
	 * @param vLength
	 */
	private static final String padAmount(
		BigDecimal vParameter,
		int pScale,
		String vParameterName,
		int vLength)
		throws IkeaException {

		if (vParameter == null) {
			return padNumberWithSign(0, vParameterName, vLength);
		}

		long vNumber = 0;

		try {
			vNumber = Amounts.unscaledAmount(vParameter, pScale);
		} catch (ArithmeticException e) {
			throw new IkeaException(
				"The amount for '"
					+ vParameterName
					+ "' contains unexpected decimal values!",e);
		}

		return padNumberWithSign(vNumber, vParameterName, vLength);
	}

	/**
	 * 
	 */
	private static final String translateCalypsoResponseCode(
		String pResponseCode,
		String pErrorType)
		throws IkeaException {

		if (Response.RESPONSE_CODE_NORMAL.equals(pResponseCode)) {
			return CALYPSO_SUCCESS;
		} else if (Response.RESPONSE_CODE_ERROR.equals(pResponseCode)) {

			if (Response.ERROR_TYPE_INVALID_CARD.equals(pErrorType)) {
				return CALYPSO_INVALID_CARD;
			} else if (Response.ERROR_TYPE_INVALID_PIN.equals(pErrorType)) {
				return CALYPSO_CALL_CENTER;
			} else if (Response.ERROR_TYPE_CALL_CENTER.equals(pErrorType)) {
				return CALYPSO_CALL_CENTER;
			} else if (Response.ERROR_TYPE_TRY_AGAIN.equals(pErrorType)) {
				return CALYPSO_TRY_AGAIN;
			} else {
				return CALYPSO_TRY_AGAIN;
			}

		} else {
			throw new IkeaException(
				"Unknown response code");
		}
	}

}
