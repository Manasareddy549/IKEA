/*
 * Created on 2006-maj-12
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.nio.CharBuffer;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CalypsoBalanceRequest extends GenericRequest {
	/**
	 * The length of the balance message is 75 characters
	 */
	public static final int BALANCE_LENGTH = 75;
	public static final int MESSAGE_LENGTH =
		CalypsoMessageRequest.HEADER_LENGTH + BALANCE_LENGTH;

	/**
	 */
	public static final int SWIPED_START = 190;
	public static final int SWIPED_LENGTH = 1;
	public static final int CARDNUMBER_START = 191;
	public static final int CARDNUMBER_LENGTH = 19;


	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		Readable pReadable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo)
		throws IkeaException {

		// Prepare for reading
		prepare(pReadable, pCharBuffer, MESSAGE_LENGTH);

		// Swiped
		pRequestInfo.setSwiped(readFromBuffer(SWIPED_START, SWIPED_LENGTH));

		// Card number
		pRequestInfo.setCardNumber(
			readFromBuffer(CARDNUMBER_START, CARDNUMBER_LENGTH));

		return this;
	}
}
