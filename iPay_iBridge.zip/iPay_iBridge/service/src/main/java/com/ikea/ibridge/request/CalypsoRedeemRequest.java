/*
 * Created on 2006-aug-29
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.request;

import java.nio.CharBuffer;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;

/**
 * @author anms
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CalypsoRedeemRequest extends GenericRequest {

	/**
	 * The length of the redeem message is ? characters
	 */
	public static final int REDEEM_LENGTH = 75;
	public static final int MESSAGE_LENGTH =
		CalypsoMessageRequest.HEADER_LENGTH + REDEEM_LENGTH;

	// Lengt of the communication header before the message header
	public static final int OFFSET = 8;

	public static final int SWIPED_START = OFFSET + 148;
	public static final int SWIPED_LENGTH = 1;

	public static final int CARDNUMBER_START = OFFSET + 183;
	public static final int CARDNUMBER_LENGTH = 19;

	/**
	 * Thier are two amounts in the request 'Payment Amount' and 
	 * 'Subtotal Amount'. This is 'Payment Amount'.
	 */
	public static final int REDEEM_AMOUNT_START = OFFSET + 161;
	public static final int REDEEM_AMOUNT_LENGTH = 11;

	/**
	 * This is 'Subtotal Amount'.
	 */
	public static final int REDEEM_TOTAL_AMOUNT_START = OFFSET + 172;
	public static final int REDEEM_TOTAL_AMOUNT_LENGTH = 11;

	/**
	 * Dependacy injected
	 */
	private CalypsoCountries mCalypsoCountries = null;

	protected CalypsoRedeemRequest(CalypsoCountries pCalypsoCountries) {
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		Readable pReadable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo)
		throws IkeaException {

		// Prepare for reading
		prepare(pReadable, pCharBuffer, MESSAGE_LENGTH);

		// Swiped
		pRequestInfo.setSwiped(
			flip(readFromBuffer(SWIPED_START, SWIPED_LENGTH)));

		// Card number
		pRequestInfo.setCardNumber(
			readFromBuffer(CARDNUMBER_START, CARDNUMBER_LENGTH));

		// Set currecy based on country code
		pRequestInfo.setRequestAmountCurrency(
			mCalypsoCountries.getCurrencyCode(pRequestInfo.getCountryCode()));

		// Load amount
		pRequestInfo.setRequestAmountInteger(
			readFromBuffer(REDEEM_AMOUNT_START, REDEEM_AMOUNT_LENGTH));

		// Set decaimal scale based on country code
		pRequestInfo.setRequestAmountDecimals(
			"" + mCalypsoCountries.getDecimals(pRequestInfo.getCountryCode()));

		// Total amount
		pRequestInfo.setTotalAmountInteger(
			readFromBuffer(
				REDEEM_TOTAL_AMOUNT_START,
				REDEEM_TOTAL_AMOUNT_LENGTH));

		// Decimal for total amount
		pRequestInfo.setTotalAmountDecimals(
			"" + mCalypsoCountries.getDecimals(pRequestInfo.getCountryCode()));

		// Set dummy null to avoid error for old protocol. Verification code only possible in XML.
		pRequestInfo.setVerificationCode(null);

		return this;

	}

}
