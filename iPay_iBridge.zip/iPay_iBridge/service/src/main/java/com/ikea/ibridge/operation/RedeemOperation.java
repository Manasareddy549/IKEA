/*
 * Created on 2006-maj-08
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.operation;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.client.bs.BsRedeemCard;
import com.ikea.ebccardpay1.client.vo.VoCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoRedeemAmount;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoRequestAmount;
import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.ConfigurationFactory;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.exception.EmptyRequestException;
import com.ikea.ibridge.request.CalypsoProperties;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;

import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RedeemOperation implements Operation {
    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	/**
	 * Log category for messages
	 */
	private static final Logger mLog = 
		LoggerFactory.getLogger(RedeemOperation.class.getName());

	/**
	 * 
	 */
	public void perform(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {

		ConfigurationFactory mConfigurationFactory = ConfigurationFactorySingleton.getInstance();
		CalypsoCountries mCalypsoCountries = mConfigurationFactory.getCalypsoCountries();
		
		mLog.info("Performing operation redeem");

		// Create card entry VO
		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setSwiped(pRequestInfo.isSwiped());
		vVoCardEntry.setCardNumberString(pRequestInfo.getCardNumber());
		vVoCardEntry.setVerificationCode(pRequestInfo.getVerificationCode());
		
		// Set flag if Verification Code is not used.
		if (pRequestInfo.getVerificationCode() == null) {
			vVoCardEntry.setVerify(false);
		}else  {
			vVoCardEntry.setVerify(true);
		}	


		// Create request amount VO
		VoRequestAmount vVoRequestAmount = new VoRequestAmount();
		
//		vVoRequestAmount.setCurrencyCode(
//			pRequestInfo.getRequestAmountCurrency());
		
		// Currency validation
		
		if (mCalypsoCountries.isValidCurrency(pRequestInfo.getRequestAmountCurrency())){
			vVoRequestAmount.setCurrencyCode(pRequestInfo.getRequestAmountCurrency());
		}else{
			throw new EmptyRequestException("The POS system sent an invalid Currency Code");
		}
		
		vVoRequestAmount.setRequestAmount(
			Amounts.amount(
				pRequestInfo.getRequestAmountInteger(),
				pRequestInfo.getRequestAmountDecimals()));
		vVoRequestAmount.setTotalAmount(
			Amounts.amount(
				pRequestInfo.getTotalAmountInteger(),
				pRequestInfo.getTotalAmountDecimals()));

		// Create source system VO
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
		vVoSourceSystem.setSourceSystem(pRequestInfo.getSourceSystem());

		// Create originator VO
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType(pRequestInfo.getBuType());
		vVoOriginator.setBuCode(pRequestInfo.getBuCode());
		vVoOriginator.setEmployee(pRequestInfo.getEmployee());
		vVoOriginator.setPointOfSale(pRequestInfo.getPointOfSale());
		vVoOriginator.setReceipt(pRequestInfo.getReceipt());

		// Create environment VO
		VoEnvironment vVoEnvironment = new VoEnvironment();
		vVoEnvironment.setOffline(false);
		vVoEnvironment.setAutoAcknowledge(pRequestInfo.isAutoAcknowledge());

		// Create reference VO
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(pRequestInfo.getSourceSystemReference());
		vVoReference.setTransmissionDateTime(
			pRequestInfo.getTransmissionDateTime());

		// Create service
		BsRedeemCard vBsRedeemCard = new BsRedeemCard();

		// Set input VOs
		vBsRedeemCard.setVoCardEntry(vVoCardEntry);
		vBsRedeemCard.setVoRequestAmount(vVoRequestAmount);
		vBsRedeemCard.setVoSourceSystem(vVoSourceSystem);
		vBsRedeemCard.setVoOriginator(vVoOriginator);
		vBsRedeemCard.setVoReference(vVoReference);
		vBsRedeemCard.setVoEnvironment(vVoEnvironment);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
		bsExecuter.executeBs(vBsRedeemCard,"Originator");

		// Check for application errors
		List vApplErrors = vBsRedeemCard.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			
			// If source system is calypso, the card is a family card and the
			// card is not activated (not found), then don't return an error
			if (pRequestInfo.getSourceSystem().equalsIgnoreCase(Constants.SOURCE_SYSTEM_CONSTANT_CALYPSO) &&
					CalypsoProperties.isFamily(pRequestInfo.getCardNumber())) {
				for (Iterator iter = vApplErrors.iterator(); iter.hasNext();) {
					ApplicationError vApplError = (ApplicationError)iter.next();
					if (vApplError.getErrorCode() == ApplicationErrorCodes.INVALID_CARD_NOT_FOUND ||
						(vApplError.getErrorCode() == ApplicationErrorCodes.NON_TRANSLATABLE &&
						 (vApplError.getMessage().toLowerCase().startsWith("card has never been loaded") ||
						  vApplError.getMessage().toLowerCase().startsWith("card number not found") ||
						  vApplError.getMessage().toLowerCase().startsWith("card number found but no card connected")))) {

						pResponseInfo.setBalanceAmount(Amounts.amount(0));
						pResponseInfo.setBalanceCurrencyCode(vVoRequestAmount.getCurrencyCode());
						pResponseInfo.setBalanceDate(new Date());

						pResponseInfo.setRequestAmount(vVoRequestAmount.getRequestAmount());
						pResponseInfo.setRequestCurrencyCode(vVoRequestAmount.getCurrencyCode());
						pResponseInfo.setRequestTotalAmount(vVoRequestAmount.getTotalAmount());

						pResponseInfo.setRedeemAmount(Amounts.amount(0));
						pResponseInfo.setRedeemCurrencyCode(vVoRequestAmount.getCurrencyCode());
						
						pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
						return;
					}
				}
			}
			
			pResponseInfo.translateApplicationErrors(vApplErrors);			
			return;
		}

		// Set response values
		VoCard vVoCard = vBsRedeemCard.getVoCard();
		VoRedeemAmount vVoRedeemAmount = vBsRedeemCard.getVoRedeemAmount();

		pResponseInfo.setBalanceAmount(vVoCard.getBalanceAmount());
		pResponseInfo.setBalanceCurrencyCode(vVoCard.getCurrencyCode());
		pResponseInfo.setBalanceDate(vVoCard.getBalanceDateTime());
		pResponseInfo.setExpireDate(vVoCard.getExpireDate());

		pResponseInfo.setRequestAmount(vVoRequestAmount.getRequestAmount());
		pResponseInfo.setRequestCurrencyCode(
			vVoRequestAmount.getCurrencyCode());
		pResponseInfo.setRequestTotalAmount(vVoRequestAmount.getTotalAmount());

		pResponseInfo.setRedeemAmount(vVoRedeemAmount.getRedeemAmount());
		// Redeemed amount is in the same currency as requested.
		pResponseInfo.setRedeemCurrencyCode(vVoRequestAmount.getCurrencyCode());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);

	}
	
	public void performTrainingMode(RequestInfo pRequestInfo, ResponseInfo pResponseInfo)
		throws IkeaException {
	
		mLog.info("Performing operation redeem in training mode");

		pResponseInfo.setBalanceAmount(Amounts.amount(200));
		pResponseInfo.setBalanceCurrencyCode(pRequestInfo.getRequestAmountCurrency());
		pResponseInfo.setBalanceDate(new Date());
		pResponseInfo.setExpireDate(new Date(112, 9, 11));

		pResponseInfo.setRequestAmount(Amounts.amount(
				pRequestInfo.getRequestAmountInteger(),
				pRequestInfo.getRequestAmountDecimals()));
		pResponseInfo.setRequestTotalAmount(Amounts.amount(
				pRequestInfo.getTotalAmountInteger(),
				pRequestInfo.getTotalAmountDecimals()));

		pResponseInfo.setRedeemAmount(Amounts.amount(150));

		pResponseInfo.setRequestCurrencyCode(pRequestInfo.getRequestAmountCurrency());
		pResponseInfo.setRedeemCurrencyCode(pRequestInfo.getRequestAmountCurrency());

		pResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
	}
}
