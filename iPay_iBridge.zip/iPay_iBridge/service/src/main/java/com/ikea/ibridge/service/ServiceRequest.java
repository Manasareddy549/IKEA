package com.ikea.ibridge.service;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * Interface for handling service requests
 * 
 */
public interface ServiceRequest extends Runnable {
	
	/**
	 * Call service to handle a the communication with a single transaction.
	 * The only call to service is performed in the implementting class ServiceRequestImpl
	 * and the only reason to have this method here in the interface is so that
	 * we can test the code better through mocking
	 * 
	 * @throws IkeaException If an error occurs
	 */
	void service() throws IkeaException;
}
