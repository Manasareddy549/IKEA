/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;
import java.math.BigDecimal;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RedeemResponse extends XmlResponse {

	private CalypsoCountries mCalypsoCountries = null;
	
	public RedeemResponse(CalypsoCountries pCalypsoCountries) {
		super();
		mCalypsoCountries = pCalypsoCountries;
	}

	private static final String TAG_CURRENCY = "currency";
	private static final String TAG_DECIMALS = "decimals";
	private static final String TAG_INTEGER = "integer";

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<redeemResponse>\n");

		// Source system tags
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);
		
		int vRequestDecimals = 2;
		long vRequestAmount = 0;
		long vRequestTotalAmount = 0;
		if (pResponseInfo.getRequestAmount() != null) {
			vRequestDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getRequestCurrencyCode());
			
			vRequestAmount = getRoundedUnscaledAmount(pResponseInfo.getRequestAmount(), vRequestDecimals);
		}
		if (pResponseInfo.getRequestTotalAmount() != null) {
			vRequestTotalAmount = getRoundedUnscaledAmount(pResponseInfo.getRequestTotalAmount(), vRequestDecimals);
		}
		
		pAppendable.append("<requestAmount>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag(TAG_INTEGER, vRequestAmount));
		pAppendable.append(Tags.tag(TAG_DECIMALS, vRequestDecimals));
		pAppendable.append(Tags.tag(TAG_CURRENCY, pResponseInfo.getRequestCurrencyCode()));
		pAppendable.append("</amount>\n");

		pAppendable.append("<totalAmount>\n");
		pAppendable.append(Tags.tag(TAG_INTEGER, vRequestTotalAmount));
		pAppendable.append(Tags.tag(TAG_DECIMALS, vRequestDecimals));
		pAppendable.append(Tags.tag(TAG_CURRENCY, pResponseInfo.getRequestCurrencyCode()));
		pAppendable.append("</totalAmount>\n");

		pAppendable.append("</requestAmount>\n");

		int vRedeemDecimals = 2;
		long vRedeemAmount = 0;
		if (pResponseInfo.getRedeemAmount() != null) {
			vRedeemDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getRedeemCurrencyCode());
			
			vRedeemAmount = getRoundedUnscaledAmount(pResponseInfo.getRedeemAmount(), vRedeemDecimals);
		}
		pAppendable.append("<redeemAmount>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag(TAG_INTEGER, vRedeemAmount));
		pAppendable.append(Tags.tag(TAG_DECIMALS, vRedeemDecimals));
		pAppendable.append(Tags.tag(TAG_CURRENCY, pResponseInfo.getRedeemCurrencyCode()));
		pAppendable.append("</amount>\n");
		pAppendable.append("</redeemAmount>\n");

		int vBalanceDecimals = 2;
		long vBalanceAmount = 0;
		if (pResponseInfo.getBalanceAmount() != null) {
			vBalanceDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getBalanceCurrencyCode());
			
			vBalanceAmount = getRoundedUnscaledAmount(pResponseInfo.getBalanceAmount(), vBalanceDecimals);
		}
		pAppendable.append("<balanceAmount>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag(TAG_INTEGER, vBalanceAmount));
		pAppendable.append(Tags.tag(TAG_DECIMALS, vBalanceDecimals));
		pAppendable.append(Tags.tag(TAG_CURRENCY, pResponseInfo.getBalanceCurrencyCode()));
		pAppendable.append("</amount>\n");
		pAppendable.append(Tags.tag("balanceDateTime", pResponseInfo.getBalanceDate()));
		pAppendable.append("</balanceAmount>\n");

		pAppendable.append(Tags.tag("expires", pResponseInfo.getExpireDate()));

		pAppendable.append("</redeemResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}
}
