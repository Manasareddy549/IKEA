/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface ResponseFactory {

	/**
	 * 
	 * @return
	 */
	Response createCalypsoResponse();

	/**
	 * 
	 * @return
	 */
	Response createSimulationResponse();

	/**
	 * 
	 * @return
	 */
	Response createErrorResponse(
		String pMessage,
		String pDetails);

	/**
	 * 
	 * @return
	 */
	Response createXmlResponse(String pOperation)
		throws IkeaException;

	/**
	 * 
	 * @return
	 */
	ResponseInfo createResponseInfo();
}
