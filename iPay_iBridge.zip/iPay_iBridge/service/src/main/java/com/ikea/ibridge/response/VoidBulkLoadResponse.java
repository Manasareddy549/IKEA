

/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class VoidBulkLoadResponse extends XmlResponse {

	private CalypsoCountries mCalypsoCountries = null;
	
	public VoidBulkLoadResponse(CalypsoCountries pCalypsoCountries) {
		super();
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<VoidBulkloadResponse>\n");

		// Source system tags
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);
		
		pAppendable.append(Tags.tag("MassLoadId", pResponseInfo.getMassLoadId()));

		pAppendable.append("</VoidBulkloadResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}
}

