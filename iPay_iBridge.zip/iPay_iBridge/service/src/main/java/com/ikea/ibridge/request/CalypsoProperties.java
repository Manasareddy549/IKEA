/*
 * Created on 2006-aug-25
 *
 */
package com.ikea.ibridge.request;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author anms
 *
 */
public class CalypsoProperties {

	private CalypsoProperties() {}
	
	// private static final int CARD_TYPE_POSITION = 6;
	private static final char CARD_TYPE_GIFT_CHAR = '2';
	private static final char CARD_TYPE_FAMILY_CHAR = '0';

	private static final String IKEA_ISSUER = "627598";
	private static final String IKEA_GIFT_START =
		IKEA_ISSUER + CARD_TYPE_GIFT_CHAR;
	private static final String IKEA_FAMILY_START =
		IKEA_ISSUER + CARD_TYPE_FAMILY_CHAR;
	private static final int IKEA_CARD_LENGTH = 19;

	public static String getAmountType(String pCardNumberString)
		throws IkeaException {
		String vAmountType;

		// If the Card Type is GIFT then set the amount type to CASH otherwise it is DISCOUNT.
		if (isIkeaGiftCard(pCardNumberString)) {
			vAmountType = Constants.AMOUNT_TYPE_CONSTANT_CASH;
		} else {
			vAmountType = Constants.AMOUNT_TYPE_CONSTANT_DISCOUNT;
		}

		return vAmountType;

	}
	public static boolean isFamily(String pCardNumberString)
		throws IkeaException {

		if (isIkeaFamilyCard(pCardNumberString)) {
			return true;
		}
		return false;
	}
	public static String getSourceSytem(String pCountryCode)
		throws IkeaException {

		// Is is only US and Canada that are using the old Calypso protocol from 4690.
		if ("US".equals(pCountryCode) || "CA".equals(pCountryCode)) {
			return Constants.SOURCE_SYSTEM_CONSTANT_4690;
		}

		return Constants.SOURCE_SYSTEM_CONSTANT_CALYPSO;
	}

	private static boolean isIkeaGiftCard(String pCardNumberString)
		throws IkeaException {
		if (pCardNumberString == null) {
			throw new IkeaException("Card Number String must be not be null to determine the amount type for IKEA cards!");
		}
		if (pCardNumberString.length() != IKEA_CARD_LENGTH) {
			return false;
		}
		return pCardNumberString.startsWith(IKEA_GIFT_START);
	}
	private static boolean isIkeaFamilyCard(String pCardNumberString)
		throws IkeaException {
		if (pCardNumberString == null) {
			throw new IkeaException("Card Number String must be not be null to determine if it is an IKEA FAMILY card!");
		}
		if (pCardNumberString.length() != IKEA_CARD_LENGTH) {
			return false;
		}
		return pCardNumberString.startsWith(IKEA_FAMILY_START);
	}
}
