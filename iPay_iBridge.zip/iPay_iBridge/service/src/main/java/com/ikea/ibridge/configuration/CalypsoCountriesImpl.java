package com.ikea.ibridge.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ikea.ebcframework.exception.IkeaException;

public class CalypsoCountriesImpl implements CalypsoCountries {


	private Map<String, String> pMap = new HashMap<String, String>();

	
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(CalypsoCountriesImpl.class);

	/*
	 * Maps country code to country settings
	 */
	private ConcurrentMap<String, CountrySetting> mCountrySettings = new ConcurrentHashMap<String, CountrySetting>();

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#getCurrencyCode(java.lang.String)
	 */
	public String getCurrencyCode(String pCountryCode) throws IkeaException {

		return getCountrySetting(pCountryCode).getCurrencyCode();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#getDecimals(java.lang.String)
	 */
	public int getDecimals(String pCountryCode) throws IkeaException {

		return getCountrySetting(pCountryCode).getDecimals();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#isValidCurrency(java.lang.String)
	 */
	public boolean isValidCurrency(String pCurrency) throws IkeaException{
		return pMap.containsKey(pCurrency);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#readCountries()
	 */
	public void readCountries() throws IkeaException {

		if (mCountrySettings.size() > 0) {
			throw new IkeaException("Not allowed to call readCountries after country settings have been added");
		}

		mCountrySettings.putAll(readSettings());
		mLog.info("Loaded initial country settings");
		// XML currency validation
		//pMap = readCurrencies();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#updateCountries()
	 */
	public void updateCountries() {

		try {
			mCountrySettings.putAll(readSettings());
			mLog.info("Updated country settings");
		} catch (IkeaException e) {
			mLog.error(e.getMessage());
		}
	}

	/**
	 * Returns a CountrySetting for a given country code. This method returns
	 * an empty currency setting object if the country code could not be found
	 * 
	 * @param pCountryCode The Country code to look for
	 * @return The country setting
	 */
	private CountrySetting getCountrySetting(String pCountryCode)
		throws IkeaException {

		CountrySetting setting =
			(CountrySetting) mCountrySettings.get(pCountryCode);

		if (setting == null) {
			throw new IkeaException(
				"Country code "
					+ pCountryCode
					+ " could not be found in countries.xml.");
		}

		return setting;
	}

	/**
	 * Loads an XML file from disk, parses it and builds a regular map keyed on country code as a string
	 * with a CountrySetting object as value.
	 * 
	 * @return A map with country settings
	 */
	private Map<String, CountrySetting> readSettings() throws IkeaException {
		Map<String, CountrySetting> vMap = new HashMap<String, CountrySetting>();
		pMap.clear();
		URL vURL = null;
		InputStream vInputStream = null;

		try {

			// Check for system property for alternate location of countries.xml
			String vCountries = System.getProperty("countries.configuration");

			// Create URL to property file in the classpath or alternate location
			if (vCountries != null && vCountries.length() > 0) {
				mLog.info(
					"Using countries from external settings ["
						+ vCountries
						+ "]");
				vURL = new URL(vCountries);
			} else {
				mLog.info("Using countries.xml from class loader");
				vURL =
					Thread.currentThread().getContextClassLoader().getResource(
						"countries.xml");
			}

			// Check for URL
			if (vURL == null) {
				throw new IkeaException(
					"countries.xml could not be found, URL was null");
			}

			// Open input stream
			vInputStream = vURL.openStream();

			// Check for input stream
			if (vInputStream == null) {
				throw new IkeaException(
					"countries.xml could not be found, input stream was null");
			}

			// Create a Document instance and load it from the stream
			DocumentBuilderFactory vDocumentBuilderFactory =
				DocumentBuilderFactory.newInstance();
			vDocumentBuilderFactory.setValidating(false);
			Document vDocument =
				vDocumentBuilderFactory.newDocumentBuilder().parse(
					vInputStream);

			// Get all country tags
			NodeList vNodeList = vDocument.getElementsByTagName("country");
			for (int i = 0; i < vNodeList.getLength(); i++) {
				Element vElement = (Element) vNodeList.item(i);

				// Extract attributes
				String countryCode = vElement.getAttribute("code");
				String currencyCode = vElement.getAttribute("currency");
				String decimals = vElement.getAttribute("decimals");

				// Create settings
				CountrySetting vCountrySetting = new CountrySetting();
				vCountrySetting.setCurrencyCode(currencyCode);
				if (decimals != null && decimals.length() > 0) {
					try {
						vCountrySetting.setDecimals(Integer.parseInt(decimals));
					} catch (NumberFormatException e) {
						mLog.error(e.getMessage());
					}
				}

				// Add settings
				vMap.put(countryCode, vCountrySetting);
				pMap.put(currencyCode, countryCode);
			}

		} catch (Exception e) {
			throw new IkeaException( e);
		} finally {
			try {
				// Close stream
				if (vInputStream != null) {
					vInputStream.close();
				}
			} catch (IOException e) {
				mLog.error(e.getMessage());
			}
		}

		return vMap;
	}
	
	/**
	 * Find the first entry with the specified currency and return the decimals for it
	 */
	public int getDecimalsByCurrency(String pCurrency) throws IkeaException {
		// If no currency is specified then return 0 decimals
		if (pCurrency == null || pCurrency.length() == 0)
			return 0;
		
		String vCountryCode = pMap.get(pCurrency);		
		if (vCountryCode == null) {
			throw new IkeaException(
					"Currency "
						+ pCurrency
						+ " could not be found in countries.xml.");
		}
		
		CountrySetting vCountrySetting = mCountrySettings.get(vCountryCode);	
		if (vCountrySetting == null) {
			throw new IkeaException(
					"Country code "
						+ vCountryCode
						+ " could not be found in countries.xml.");
		}
		
		return vCountrySetting.getDecimals();
	}
}
