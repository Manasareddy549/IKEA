package com.ikea.ibridge;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.configuration.ConfigurationFactorySingleton;
import com.ikea.ibridge.service.Service;
import com.ikea.ibridge.service.ServiceFactorySingleton;

/**
 * @author snug
 *
 * Main class that initializes and starts the service.
 * 
 */
public class IBridge {
	private static final int TIMEOUT_LIMIT_IN_SECONDS = 10;

	private static final int HOURS = 24;

	private static final int MINUTES = 60;

	private static final int SECONDS = 60;

	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(IBridge.class);
	
	/**
	 * Reference to the configuration instance for retrieving port and timeout
	 */
	private Configuration mConfiguration = null;

	/**
	 * Reference to the Calypso countries instance for retrieving country settings
	 */
	private CalypsoCountries mCalypsoCountries = null;

	/**
	 * The iBridge service instance
	 */
	private Service mService = null;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public IBridge(
		Configuration pConfiguration,
		CalypsoCountries pCalypsoCountries,
		Service pServer) {
		mConfiguration = pConfiguration;
		mCalypsoCountries = pCalypsoCountries;
		mService = pServer;
	}

	/**
	 * Fetches configurations, validates and starts the services
	 */
	public void start() throws IkeaException {

		// Fetch the configuration information
		int vPortNumber = mConfiguration.getPortNumber();
		int vTimeOut = mConfiguration.getTimeout();
		long vRequestDelay = mConfiguration.getRequestDelay();
		long vResponseDelay = mConfiguration.getResponseDelay();

		mLog.info("Version: " + mConfiguration.getVersion());

		// Read all Calypso countries settings
		mCalypsoCountries.readCountries();

		// Update Calypso settings once per day
		long vInterval = SECONDS * MINUTES * HOURS;
		Executors.newScheduledThreadPool(
			1).scheduleAtFixedRate(new Runnable() {
			public void run() {
				mCalypsoCountries.updateCountries();
			}
		}, 0, vInterval, TimeUnit.SECONDS);

		// Validate configuration
		if (vTimeOut < TIMEOUT_LIMIT_IN_SECONDS) {
			throw new IkeaException(
				"Illegal value for timeout [" + vTimeOut + "]");
		}
		
		// Write port number (could be 9101, 9102 or 55980, or other)
		mLog.info("Port number: " + vPortNumber);

		// Check request delay
		if (vRequestDelay > 0) {
			mLog.warn(
				"iBridge started with a request delay of "
					+ vRequestDelay
					+ " seconds");
		}

		// Check response delay
		if (vResponseDelay > 0) {
			mLog.warn(
				"iBridge started with a response delay of "
					+ vResponseDelay
					+ " seconds");
		}

		// Start the service
		mService.start(vPortNumber, vTimeOut, vRequestDelay, vResponseDelay);
	}

	/**
	 * @throws IkeaException
	 */
	public void stop() throws IkeaException {
		mService.stop();
		mLog.info("iBridge stoppped");
	}

	/**
	 * iBridge entry point, creates the iBridge instance and starts iBridge
	 * 
	 * @param args Command line arguments
	 */
	public static void main(String[] args) throws IkeaException {

		// Create iBridge instance by providing dependencies from the factory
		//ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		IBridge vIBridge =
			new IBridge(
				ConfigurationFactorySingleton.getInstance().getConfiguration(),
				ConfigurationFactorySingleton
					.getInstance()
					.getCalypsoCountries(),
				ServiceFactorySingleton.getInstance().createService());

		// Start service
		vIBridge.start();
	}
}