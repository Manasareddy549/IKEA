package com.ikea.ibridge.operation;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.response.ResponseFactory;

/**
 */
public class OperationFactoryImpl implements OperationFactory {
	/**
	 * Dependency
	 */
	private final Configuration mConfiguration;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public OperationFactoryImpl(
		Configuration pConfiguration,
		ResponseFactory pResponseFactory) {
		mConfiguration = pConfiguration;
	}

	/**
	 * 
	 * @param pOperation
	 * @return
	 * @throws IkeaException
	 */
	public Operation createOperation(String pOperation) throws IkeaException {

		System.out.println("Operation: " + pOperation);

		// Find the operation
		if (mConfiguration.isSimulated() & Request.OPERATION_BALANCE.equals(pOperation)) {
			return new SimulateBalanceOperation(mConfiguration);
		} else if (mConfiguration.isSimulated() & Request.OPERATION_LOAD.equals(pOperation)) {
			return new SimulateLoadOperation(mConfiguration);
		} else if (mConfiguration.isSimulated() & Request.OPERATION_VERIFY_LOAD.equals(pOperation)) {
			return new SimulateVerifyLoadOperation(mConfiguration);	
		} else if (mConfiguration.isSimulated() & Request.OPERATION_REDEEM.equals(pOperation)) {
			return new SimulateRedeemOperation(mConfiguration);
		} else if (mConfiguration.isSimulated() & Request.OPERATION_VOID.equals(pOperation)) {
			return new SimulateVoidOperation(mConfiguration);
		} else if (mConfiguration.isSimulated() & Request.OPERATION_VOID_AMOUNT.equals(pOperation)) {
			return new SimulateCalypsoVoidOperation(mConfiguration);	
		} else if (Request.OPERATION_VOID_BULKLOAD.equals(pOperation)) {
			return new VoidBulkLoadOperation();
		} else if (Request.OPERATION_ECHO.equals(pOperation)) {
			return new EchoOperation();
		} else if (Request.OPERATION_BALANCE.equals(pOperation)) {
			return new BalanceOperation();
		} else if (Request.OPERATION_LOAD.equals(pOperation)) {
			return new LoadOperation();
		} else if (Request.OPERATION_BULKLOAD.equals(pOperation)) {
			return new BulkLoadOperation();
		} else if (Request.OPERATION_VERIFY_LOAD.equals(pOperation)) {
			return new VerifyLoadOperation();
		}else if (Request.OPERATION_REDEEM.equals(pOperation)) {
			return new RedeemOperation();
		} else if (Request.OPERATION_ACKNOWLEDGE.equals(pOperation)) {
			return new AcknowledgeOperation();
		} else if (Request.OPERATION_VOID.equals(pOperation)) {
			return new VoidOperation();
		} else if (Request.OPERATION_VOID_AMOUNT.equals(pOperation)) {
			return new VoidAmountOperation();
		} else {
			throw new IkeaException(
				"Unknown operation");
		}
	}

}
