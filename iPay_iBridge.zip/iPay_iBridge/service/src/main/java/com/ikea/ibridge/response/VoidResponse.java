/*
 * Created on 2006-maj-15
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.response;

import java.io.IOException;
import java.util.Date;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.Audit;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.utils.Tags;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class VoidResponse extends XmlResponse {

	private CalypsoCountries mCalypsoCountries = null;
	
	public VoidResponse(CalypsoCountries pCalypsoCountries) {
		super();
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.response.Response#write(java.lang.Appendable, com.ikea.ibridge.response.ResponseInfo)
	 */
	public void writeXml(
		Appendable pAppendable,
		RequestInfo pRequestInfo,
		ResponseInfo pResponseInfo)
		throws IkeaException, IOException {

		// Write message
		pAppendable.append("<?xml version=\"1.0\"?>\n");
		pAppendable.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">\n");

		pAppendable.append("<voidResponse>\n");

		// Source system tags
		writeSourceSystem(pAppendable, pRequestInfo, pResponseInfo);

		int vBalanceDecimals = 2;
		long vBalanceAmount = 0;
		if (pResponseInfo.getBalanceAmount() != null) {
			vBalanceDecimals =
				mCalypsoCountries.getDecimalsByCurrency(pResponseInfo.getBalanceCurrencyCode());
			vBalanceAmount = getRoundedUnscaledAmount(pResponseInfo.getBalanceAmount(), vBalanceDecimals);
		}
		pAppendable.append("<balanceAmount>\n");
		pAppendable.append("<amount>\n");
		pAppendable.append(Tags.tag("integer", vBalanceAmount));
		pAppendable.append(Tags.tag("decimals", vBalanceDecimals));
		pAppendable.append(Tags.tag("currency", pResponseInfo.getBalanceCurrencyCode()));
		pAppendable.append("</amount>\n");

		Date vDate = new Date();

		if (pResponseInfo.getBalanceDate() != null) {
			vDate = pResponseInfo.getBalanceDate();
		}
		pAppendable.append(Tags.tag("balanceDateTime", vDate));
		pAppendable.append("</balanceAmount>\n");

		pAppendable.append(Tags.tag("expires", pResponseInfo.getExpireDate()));

		pAppendable.append("</voidResponse>\n");

		pAppendable.append("</ipay>");

		Audit.send(pAppendable);
	}
}
