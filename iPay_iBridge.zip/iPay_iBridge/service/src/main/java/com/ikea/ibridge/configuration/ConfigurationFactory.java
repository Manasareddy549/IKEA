package com.ikea.ibridge.configuration;

/**
 * @author snug
 *
 * Provides access to the <code>Configuration</code> instance
 * 
 */
public interface ConfigurationFactory {

	/**
	 * Get the Configuration instance
	 * @return the same instance every time.
	 */
	Configuration getConfiguration();

	/**
	 * Get the CalypsoCountries instance
	 * @return the same instance every time.
	 */
	CalypsoCountries getCalypsoCountries();

}
