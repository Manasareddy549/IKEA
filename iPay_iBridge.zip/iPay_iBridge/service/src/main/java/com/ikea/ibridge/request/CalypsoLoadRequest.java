/*
 * Created on 2006-aug-24
 *
 */
package com.ikea.ibridge.request;

import java.nio.CharBuffer;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;

/**
 * @author anms
 *
 */
public class CalypsoLoadRequest extends GenericRequest {

	/**
	 * The length of the load message is ? characters
	 */
	public static final int LOAD_LENGTH = 121;
	public static final int MESSAGE_LENGTH =
		CalypsoMessageRequest.HEADER_LENGTH + LOAD_LENGTH;

	// Length of the communication header before the message header
	public static final int OFFSET = 8;

	public static final int SWIPED_START = OFFSET + 152;
	public static final int SWIPED_LENGTH = 1;

	public static final int VOID_START = OFFSET + 153;
	public static final int VOID_LENGTH = 1;

	public static final int CARDNUMBER_START = OFFSET + 209;
	public static final int CARDNUMBER_LENGTH = 19;

	public static final int LOAD_AMOUNT_START = OFFSET + 195;
	public static final int LOAD_AMOUNT_LENGTH = 11;

	/**
	 * Dependency injected
	 */
	private CalypsoCountries mCalypsoCountries = null;

	protected CalypsoLoadRequest(CalypsoCountries pCalypsoCountries) {
		mCalypsoCountries = pCalypsoCountries;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.request.Request#read(java.lang.Readable, java.nio.CharBuffer, com.ikea.ibridge.request.RequestInfo)
	 */
	public Request read(
		Readable pReadable,
		CharBuffer pCharBuffer,
		RequestInfo pRequestInfo)
		throws IkeaException {

		// Prepare for reading
		prepare(pReadable, pCharBuffer, MESSAGE_LENGTH);

		// Swiped
		pRequestInfo.setSwiped(
			flip(readFromBuffer(SWIPED_START, SWIPED_LENGTH)));

		// Check for Void
		String vVoid = readFromBuffer(VOID_START, VOID_LENGTH);
		if ("1".equals(vVoid)) {
			pRequestInfo.setOperation(Request.OPERATION_VOID_AMOUNT);
			pRequestInfo.setTransactionType(
				Constants.TRANSACTION_TYPE_CONSTANT_LOAD);
		}

		// Card number
		pRequestInfo.setCardNumber(
			readFromBuffer(CARDNUMBER_START, CARDNUMBER_LENGTH));

		// Set the amount type based on the card number
		pRequestInfo.setLoadAmountType(
			CalypsoProperties.getAmountType(pRequestInfo.getCardNumber()));

		// Set currecy based on country code
		pRequestInfo.setLoadAmountCurrency(
			mCalypsoCountries.getCurrencyCode(pRequestInfo.getCountryCode()));

		// Set decimal scale based on country code
		pRequestInfo.setLoadAmountDecimals(
			"" + mCalypsoCountries.getDecimals(pRequestInfo.getCountryCode()));

		// Load amount
		pRequestInfo.setLoadAmountInteger(
			readFromBuffer(LOAD_AMOUNT_START, LOAD_AMOUNT_LENGTH));

		// Handle compensation loads in old calypso protocol
		// If a redeem is performed and it was unsufficient amount then the cashier
		// gets a question if s/he wants to continue or not. If the cashier presses cancel
		// then calypso send a new transaction, a load transaction on the corresponding amount.
		// The correct behaiour would be to send a void from calypso of the previous redeem.
		// Mean while we will hinder loads on fammily cards by just assuming that they ment void on that amount.
		if (CalypsoProperties.isFamily(pRequestInfo.getCardNumber())) {
			pRequestInfo.setOperation(Request.OPERATION_VOID_AMOUNT);
			pRequestInfo.setTransactionType(
				Constants.TRANSACTION_TYPE_CONSTANT_REDEEM);

			// Since we are faking a Redeem void we need to copy from load to request attributes
			pRequestInfo.setRequestAmountCurrency(
				pRequestInfo.getLoadAmountCurrency());
			pRequestInfo.setRequestAmountDecimals(
				"" + pRequestInfo.getLoadAmountDecimals());
			pRequestInfo.setRequestAmountInteger(
				"" + pRequestInfo.getLoadAmountInteger());
		}

		return this;
	}

}
