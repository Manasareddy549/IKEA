All log files for iBridge will end up in this directory.
We must have a file in this directory, I could not get an empty directory when zipping it up.