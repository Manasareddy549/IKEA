/*
 * Created on 2006-maj-11
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.io.IOException;
import java.nio.CharBuffer;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.CalypsoMessageRequest;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.ResponseFactory;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class CalypsoMessageRequestTest extends EasyMockSupport {

    @Mock
	public Readable mReadableMock;

    @Mock
	public ResponseFactory mResponseFactoryMock;

    @Mock
	public CalypsoCountries mCalypsoCountriesMock;

	public CalypsoMessageRequest mTested;


	/**
	 */
    @Test
	public void testRequest_echo() throws Exception {
        mTested =
                new CalypsoMessageRequest(
                        mResponseFactoryMock,
                        mCalypsoCountriesMock);

		// Create and prepare CharBuffer
		String vMessage =
			"ICE+0511+015000000000+107+03+0180+000120060420070644  232323             SE+0040                                                        +0000              0000000000000000000000000000000000006275982990000001210                     ";

		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
		vCharBuffer.put(vMessage);

		// Set up expectations on mock ResponseFactory
		expect(
                mResponseFactoryMock.createCalypsoResponse()).andReturn(
                null);

		// Replay
		replayAll();

		RequestInfo vRequestInfo = new RequestInfo();
		try {
			mTested.read(mReadableMock, vCharBuffer, vRequestInfo);
			vRequestInfo.getSourceSystem();
			vRequestInfo.getOperation();
			vRequestInfo.getBuType();
			vRequestInfo.getBuCode();
			vRequestInfo.getSourceSystemReference();
			vRequestInfo.getTransmissionDateTime();
			vRequestInfo.getEmployee();
			vRequestInfo.isSwiped();
			vRequestInfo.getCardNumber();
		} catch (IkeaException e) {
			fail("Should NOT throw.");
		}

		assertEquals(
			"Unexpected operation.",
			Request.OPERATION_BALANCE,
			vRequestInfo.getOperation());
		assertEquals("Unexpected BU Type.", "STO", vRequestInfo.getBuType());
		assertEquals("Unexpected BU Code.", "107", vRequestInfo.getBuCode());
		assertEquals(
			"Unexpected reference.",
			"STO.107.3.180.1",
			vRequestInfo.getSourceSystemReference());
		assertEquals(
			"Unexpected card number.",
			"6275982990000001210",
			vRequestInfo.getCardNumber());
		assertEquals(
			"Unexpected message.",
			"00000000+107+03+0180+000120060420070644  232323             SE+0040                                                        ",
			vRequestInfo.getMessage());

        verifyAll();
	}

	/**
	 */
    @Test
	public void testRequest_failureNoData() throws Exception {
        mTested =
                new CalypsoMessageRequest(
                        mResponseFactoryMock,
                        mCalypsoCountriesMock);

		// Create and prepare CharBuffer
		CharBuffer vCharBuffer = CharBuffer.allocate(1);

		// Set up expectations on mock Readable
		expect(mReadableMock.read(vCharBuffer)).andReturn(-1);

		// Set up expectations on mock ResponseFactory
        expect(
			mResponseFactoryMock.createCalypsoResponse()).andReturn(
			null);


        replayAll();
		RequestInfo vRequestInfo = new RequestInfo();
		try {
			mTested.read(mReadableMock, vCharBuffer, vRequestInfo);
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"The client did not send a complete message, expected 136 but was 0");
		}

        verifyAll();
	}

	/**
	 */
    @Test
	public void testRequest_failureByException() throws Exception {
        mTested =
                new CalypsoMessageRequest(
                        mResponseFactoryMock,
                        mCalypsoCountriesMock);

		// Create and prepare CharBuffer
		CharBuffer vCharBuffer = CharBuffer.allocate(1);

		// Set up expectations on mock Readable
        expect(
			mReadableMock.read(vCharBuffer)).andThrow(
			new IOException("Planned exception from testing"));

		// Set up expectations on mock ResponseFactory
        expect(
			mResponseFactoryMock.createCalypsoResponse()).andReturn(
			null);


        replayAll();

		RequestInfo vRequestInfo = new RequestInfo();
		try {
			mTested.read(mReadableMock, vCharBuffer, vRequestInfo);
			fail("Should throw exception.");
		} catch (Exception e) {
		}

        verifyAll();
	}
}
