/*
 * Created on 2006-apr-12
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.net.URL;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.CalypsoCountriesImpl;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class CalypsoCountriesTest extends EasyMockSupport {

	public CalypsoCountries mTested = new CalypsoCountriesImpl();;

	/**
	 * Tests loading of countries.xml
	 */
    @Test
	public void testCalypsoCountries_loadXML() throws IkeaException {

		mTested.readCountries();
		assertEquals("Currency.", "SEK", mTested.getCurrencyCode("SE"));
		assertEquals("Decimals.", 2, mTested.getDecimals("SE"));
	}

	/**
	 * Tests loading of alternative properties
	 */
    @Test
	public void testCalypsoCountries_loadAltXML() throws IkeaException {
		URL vURL =
			Thread.currentThread().getContextClassLoader().getResource(
				"countries.xml");
		String vPath = vURL.toExternalForm();
		System.setProperty("countries.configuration", vPath);

		mTested.updateCountries();

		assertEquals("Currency.", "SEK", mTested.getCurrencyCode("SE"));
		assertEquals("Decimals.", 2, mTested.getDecimals("SE"));
	}
}
