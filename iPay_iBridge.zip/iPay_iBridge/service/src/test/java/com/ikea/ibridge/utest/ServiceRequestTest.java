/*
 * Created on 2006-apr-12
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.net.Socket;
import java.nio.CharBuffer;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.ikea.ibridge.operation.Operation;
import com.ikea.ibridge.operation.OperationFactory;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.EchoResponse;
import com.ikea.ibridge.response.ResponseInfo;
import com.ikea.ibridge.service.ServiceRequestImpl;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class ServiceRequestTest extends EasyMockSupport {

    @Mock
	public Readable mReadableMock;

    @Mock
	public Appendable mAppendableMock;

    @Mock
	public Flushable mFlushableMock;

    @Mock
	public Closeable mCloseableMock;

    @Mock
	public Request mRequestMock;

    @Mock
	public OperationFactory mOperationFactoryMock;

    @Mock
	public Operation mOperationMock;

	public ServiceRequestImpl mTested;


	/**
	 */
    @Test
	public void testServiceRequest_echo() throws Exception {

		// Create and prepare CharBuffer
		String vMessage = "message";
		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
		vCharBuffer.put(vMessage);

		// Create and prepare request map
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, Request.OPERATION_ECHO);
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.MESSAGE_KEY, vMessage);

		RequestInfo vRequestInfo = new RequestInfo(vRequestMap);
		vRequestInfo.setResponse(new EchoResponse());

		// Create and prepare response map
		ResponseInfo vResponseInfo = new ResponseInfo();

		// Set up expectations on mock Readable
		expect(
                mReadableMock.read(vCharBuffer)).andReturn(
                vMessage.length());

		// Set up expectations on mock Request
        expect(
			mRequestMock.read(mReadableMock, vCharBuffer, vRequestInfo)).andReturn(
			mRequestMock);

		// Set up expectations on mock OperationFactory
        expect(
			mOperationFactoryMock.createOperation(Request.OPERATION_ECHO)).andReturn(
			mOperationMock);

		// Set up expectations on mock Operation
		mOperationMock.perform(vRequestInfo, vResponseInfo);

		// Set up expectations on mock Appendable
        expect(
			mAppendableMock.append(vMessage)).andReturn(
			mAppendableMock);

		replayAll();

		try {
			// Running ServiceRequest
			mTested =
				new ServiceRequestImpl(
					null,
					mReadableMock,
					mAppendableMock,
					mFlushableMock,
					mCloseableMock,
					vCharBuffer,
					vRequestInfo,
					vResponseInfo,
					mRequestMock,
					mOperationFactoryMock,
					null,
					0,
					0);
			mTested.service();
		} catch (Exception e) {
			fail("Should NOT throw.");
		}

		// Verify the mock
		verifyAll();
	}



	/**
	 */
    @Test
	public void testServiceRequest_echoFailureByException1() throws Exception {
		String vMessage = "fail";
		Socket vSocket = new Socket();

		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
		vCharBuffer.put(vMessage);

		// Set up expectations on mock Readable
        expect(
			mReadableMock.read(vCharBuffer)).andThrow(
			new IOException("Planned exception from testing"));

		// Replay
		replayAll();

		try {
			// Running ServiceRequest
			mTested =
				new ServiceRequestImpl(
					vSocket,
					mReadableMock,
					mAppendableMock,
					mFlushableMock,
					mCloseableMock,
					vCharBuffer,
					null,
					null,
					null,
					null,
					null,
					0,
					0);
			mTested.service();
			fail("Should throw exception.");
		} catch (Exception e) {
		}

		// Verify the mock
		verifyAll();
	}

	/**
	 */
    @Test
	public void testServiceRequest_echoFailureNoData() throws Exception {
		String vMessage = "";

		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
		vCharBuffer.put(vMessage);

		// Set up expectations on mock Readable
        expect((mReadableMock.read(vCharBuffer))).andReturn(-1);

		// Replay
		replayAll();

		try {
			// Running ServiceRequest
			mTested =
				new ServiceRequestImpl(
					null,
					mReadableMock,
					mAppendableMock,
					mFlushableMock,
					mCloseableMock,
					vCharBuffer,
					null,
					null,
					mRequestMock,
					mOperationFactoryMock,
					null,
					0,
					0);
			mTested.service();
			fail("Should throw exception.");
		} catch (Exception e) {
			assertEquals(
				"Not the expected message",
				"The client did not send any data",
				e.getMessage());
		}

		// Verify the mock
		verifyAll();
	}

	/**
	 */
    @Test
	public void testServiceRequest_echoFailureNoDataMultipleReads()
		throws Exception {
		String vMessage = "";

		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
		vCharBuffer.put(vMessage);

		// Set up expectations on mock Readable
        expect((mReadableMock.read(vCharBuffer))).andReturn(0);
        expect((mReadableMock.read(vCharBuffer))).andReturn(0);
        expect((mReadableMock.read(vCharBuffer))).andReturn(0);
        expect((mReadableMock.read(vCharBuffer))).andReturn(-1);

		// Replay
		replayAll();

		try {
			// Running ServiceRequest
			mTested =
				new ServiceRequestImpl(
					null,
					mReadableMock,
					mAppendableMock,
					mFlushableMock,
					mCloseableMock,
					vCharBuffer,
					null,
					null,
					mRequestMock,
					mOperationFactoryMock,
					null,
					0,
					0);
			mTested.service();
			fail("Should throw exception.");
		} catch (Exception e) {
			assertEquals(
				"Not the expected message",
				"The client did not send any data",
				e.getMessage());
		}

		// Verify the mock
		verifyAll();
	}
}
