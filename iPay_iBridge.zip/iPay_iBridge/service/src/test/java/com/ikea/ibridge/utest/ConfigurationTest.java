/*
 * Created on 2006-apr-12
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.configuration.ConfigurationImpl;
import java.net.URL;
import com.ikea.ebcframework.exception.IkeaException;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class ConfigurationTest extends EasyMockSupport {

	public Configuration mTested = new ConfigurationImpl();


	/**
	 * Tests loading of properties
	 */
    @Test
	public void testConfiguration_loadProps() throws IkeaException {

		assertEquals("Unexpected portnumber.", mTested.getPortNumber(), 9101);
		assertEquals("Unexpected timeout.", mTested.getTimeout(), 10000);
	}

	/**
	 * Tests loading of alternative properties
	 */
    @Test
	public void testConfiguration_loadAltProps() throws IkeaException {
		URL vURL = Thread.currentThread().getContextClassLoader().getResource("ibridge2.properties");
		String vPath = vURL.toExternalForm();
		System.setProperty("ibridge.configuration", vPath);

		try {
			mTested.reload();
		} catch (IkeaException e) {
			fail("Should NOT throw.");
		}

		assertEquals("Unexpected portnumber.", mTested.getPortNumber(), 1234);
		assertEquals("Unexpected timeout.", mTested.getTimeout(), 1234);
	}

	/**
	 * Tests loading of missing timeout
	 */
    @Test
	public void testConfiguration_loadMissingTimeoutProps() throws IkeaException {
		URL vURL = Thread.currentThread().getContextClassLoader().getResource("ibridge3.properties");
		String vPath = vURL.toExternalForm();
		System.setProperty("ibridge.configuration", vPath);

		try {
			mTested.reload();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Required attribute timeout was missing from iBridge properties");
		}

		System.setProperty("ibridge.configuration", "");
	}

	/**
	 * Tests loading of faulty timeout
	 */
    @Test
	public void testConfiguration_loadFaultyTimeoutProps() throws IkeaException {
		URL vURL = Thread.currentThread().getContextClassLoader().getResource("ibridge4.properties");
		String vPath = vURL.toExternalForm();
		System.setProperty("ibridge.configuration", vPath);

		try {
			mTested.reload();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Required attribute timeout was not an integer in iBridge properties");
		}

		System.setProperty("ibridge.configuration", "");
	}


	/**
	 * Tests loading of missing port
	 */
    @Test
	public void testConfiguration_loadMissingPortProps() throws IkeaException {
		URL vURL = Thread.currentThread().getContextClassLoader().getResource("ibridge5.properties");
		String vPath = vURL.toExternalForm();
		System.setProperty("ibridge.configuration", vPath);

		try {
			mTested.reload();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Required attribute port was missing from iBridge properties");
		}

		System.setProperty("ibridge.configuration", "");
	}

	/**
	 * Tests loading of faulty port
	 */
    @Test
	public void testConfiguration_loadFaultyPortProps() throws IkeaException {
		URL vURL = Thread.currentThread().getContextClassLoader().getResource("ibridge6.properties");
		String vPath = vURL.toExternalForm();
		System.setProperty("ibridge.configuration", vPath);

		try {
			mTested.reload();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Required attribute port was not an integer in iBridge properties");
		}

		System.setProperty("ibridge.configuration", "");
	}

	/**
	 * Tests loading of non-existing properties
	 */
    @Test
	public void testConfiguration_loadNonExistingProps() throws IkeaException {
		System.setProperty("ibridge.configuration", "file:ibridge.properties");

		try {
			mTested.reload();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			// The exception thrown here is a wrapped Java exception that is not easily matched
			// with a particular message
		}

		System.setProperty("ibridge.configuration", "");
	}
}
