package com.ikea.ibridge.utest;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.IBridge;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.service.Service;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@RunWith(EasyMockRunner.class)
public class IbridgeTest extends EasyMockSupport {

    @Mock
	public Configuration mConfigurationMock;

    @Mock
    public CalypsoCountries mCalypsoCountriesMock;

    @Mock
    public Service mServiceMock;

	public IBridge mTested;


	/**
	 */
    @Test
	public void testConfiguration_parameterCheckOK() throws IkeaException {
        mTested =
                new IBridge(
                        mConfigurationMock,
                        mCalypsoCountriesMock,
                        mServiceMock);
		// Set up expectations on mock Configuration
		expect(
			mConfigurationMock.getTimeout()).andReturn(
                60);
		expect(
			mConfigurationMock.getPortNumber()).andReturn(
                9101);
		expect(
			mConfigurationMock.getRequestDelay()).andReturn((long)5);
		expect(
			mConfigurationMock.getResponseDelay()).andReturn((long)
                10);
		expect(
			mConfigurationMock.getVersion()).andReturn(
                "TEST");

		mCalypsoCountriesMock.readCountries();

		// Set up expectations on mock Server
		mServiceMock.start(9101, 60, 5, 10);


        replayAll();
		// Running iBridge
		try {
			mTested.start();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

        verifyAll();
	}

	/**
	 */
    @Test
	public void testConfiguration_parameterCheckFail() throws IkeaException {
        mTested =
                new IBridge(
                        mConfigurationMock,
                        mCalypsoCountriesMock,
                        mServiceMock);
		// Set up expectations on mock Configuration
		expect(
			mConfigurationMock.getTimeout()).andReturn(
                -1);
		expect(
			mConfigurationMock.getPortNumber()).andReturn(
                9101);
		expect(
			mConfigurationMock.getRequestDelay()).andReturn((long)
                5);
		expect(
			mConfigurationMock.getResponseDelay()).andReturn((long)
                10);
		expect(
			mConfigurationMock.getVersion()).andReturn(
                "TEST");

		mCalypsoCountriesMock.readCountries();


        replayAll();

		// Running iBridge
		try {
			mTested.start();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Illegal value for timeout [-1]");
		}

        verifyAll();
	}


}
