/*
 * Created on 2006-apr-07
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.service.Service;
import com.ikea.ibridge.service.ServiceFactory;
import com.ikea.ibridge.service.ServiceImpl;
import com.ikea.ibridge.service.ServiceRequest;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class ServiceTest extends EasyMockSupport {

    @Mock
    public ExecutorService mExecutorServiceMock;

    @Mock
    public ServiceRequest mServiceRequestMock;

    @Mock
    public ServiceFactory mServiceFactoryMock;

    public Service mTested;


    /**
     */
    @Test
    public void testService_startStop()
            throws IkeaException, InterruptedException {

        // Set up expectations on mock ExecutorService
        mExecutorServiceMock.shutdown();
        expect(
                mExecutorServiceMock.awaitTermination(120, TimeUnit.SECONDS)).andReturn(
                true);


        replayAll();

        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);
            mTested.start(9101, 10000, 0, 0);
            mTested.stop();
        } catch (IkeaException e) {
            fail("Should NOT throw.");
        }

        verifyAll();
    }

    /**
     */
    @Test
    public void testService_doubleStart() throws IkeaException {

        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);
            mTested.start(9101, 10000, 0, 0);
            mTested.start(9101, 10000, 0, 0);
            fail("Should throw exception.");
        } catch (IkeaException e) {
            assertEquals(
                    "Not the expected message",
                    e.getMessage(),
                    "Service is already running");
        }
        mTested.stop();
    }

    /**
     */
    @Test
    public void testService_stop()
            throws IkeaException, CloneNotSupportedException {

        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);
            mTested.stop();
            fail("Should throw exception.");
        } catch (IkeaException e) {
            assertEquals(
                    "Not the expected message",
                    e.getMessage(),
                    "Service is not running");
        }
    }

    /**
     */
    @Test
    public void testService_stopFailure()
            throws IkeaException, CloneNotSupportedException {

        // Set up expectations on mock ExecutorService
        mExecutorServiceMock.shutdown();
        expectLastCall().andThrow(new IllegalStateException("shutdown failed"));

//        mExecutorServiceControl.setThrowable(
//                new IllegalStateException("shutdown failed"));


        replayAll();
        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);
            mTested.start(9101, 10000, 0, 0);
            mTested.stop();
            fail("Should throw exception.");
        } catch (IkeaException e) {
        }

        // Verify the mock
        verifyAll();
    }

    /**
     */
    @Test
    public void testService_connect() throws Exception, InterruptedException {

        // Set up expectations on mock ExecutorService
        mExecutorServiceMock.execute(mServiceRequestMock);
        mExecutorServiceMock.shutdown();
        expect(
                mExecutorServiceMock.awaitTermination(120, TimeUnit.SECONDS)).andReturn(
                true);

        // Set up expectations on mock ServiceRequestFactory
        expect(mServiceFactoryMock.createServiceRequest((Socket)anyObject(), anyLong(), anyLong())).andReturn(mServiceRequestMock);
//        mServiceFactoryControl.setMatcher(MockControl.ALWAYS_MATCHER);
//        mServiceFactoryControl.setReturnValue(mServiceRequestMock);

        // Replay
        replayAll();

        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);

            mTested.start(9101, 10000, 0, 0);

            Socket vSocket = new Socket("localhost", 9101);
            OutputStream os = vSocket.getOutputStream();
            os.write(1);
            os.flush();
            vSocket.close();

            // Wait a while to allow the reciving end to handle the request before stopping
            Thread.sleep(1000);

            mTested.stop();
        } catch (Exception e) {
            fail("Should NOT throw.");
        }

        verifyAll();
    }

    /**
     */
    @Test
    public void testService_connectFailure()
            throws Exception, InterruptedException {

        // Set up expectations on mock ExecutorService
        mExecutorServiceMock.execute(mServiceRequestMock);
        expectLastCall().andThrow(new IllegalArgumentException("Planned exception from testing"));
//        mExecutorServiceControl.setThrowable(
//                new IllegalArgumentException("Planned exception from testing"));
        mExecutorServiceMock.shutdown();
        expect(
                mExecutorServiceMock.awaitTermination(120, TimeUnit.SECONDS)).andReturn(
                true);

        // Set up expectations on mock ServiceRequestFactory
        expect(mServiceFactoryMock.createServiceRequest((Socket)anyObject(), anyLong(), anyLong())).andReturn(mServiceRequestMock);
//        mServiceFactoryControl.setMatcher(MockControl.ALWAYS_MATCHER);
//        mServiceFactoryControl.setReturnValue(mServiceRequestMock);

        // Replay
        replayAll();

        // Running Service
        try {
            mTested =
                    new ServiceImpl(mExecutorServiceMock, mServiceFactoryMock);

            mTested.start(9101, 10000, 0, 0);

            Socket vSocket = new Socket("localhost", 9101);
            OutputStream os = vSocket.getOutputStream();
            os.write(1);
            os.flush();
            vSocket.close();

            // Wait a while to allow the reciving end to handle the request before stopping
            Thread.sleep(1000);

            mTested.stop();
        } catch (Exception e) {
            fail("Should NOT throw.");
        }

        // Verify the mock
        verifyAll();
    }
}
