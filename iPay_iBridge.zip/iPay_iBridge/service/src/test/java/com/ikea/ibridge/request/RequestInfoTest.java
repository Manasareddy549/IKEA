package com.ikea.ibridge.request;
import java.util.HashMap;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertNull;

@RunWith(EasyMockRunner.class)
public class RequestInfoTest extends EasyMockSupport {

    @Test
	public void testGetVerificationCode() throws Exception {

		HashMap hashMap = new HashMap();
		hashMap.put("sourceSystem.name", "utest");
		hashMap.put("operation", "test");
		RequestInfo underTest = new RequestInfo(hashMap);

		String verificationCode = underTest.getVerificationCode();
		
		assertNull(verificationCode);

	}
}
