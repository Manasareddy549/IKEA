/*
 * Created on 2006-maj-10
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class RequestInfoTest extends EasyMockSupport {

	public RequestInfo mTested = new RequestInfo();

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_nullMap() throws IkeaException {
		try {
			mTested.setRequestMap(null);
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Request map may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_size() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "CALYPSO");

		int value = 0;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.size();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected source system.", value, 2);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_sourceSystemSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "CALYPSO");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystem();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected source system.", value, "CALYPSO");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_sourceSystemNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystem();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.name' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_sourceSystemNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystem();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.name' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_sourceSystemDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystem();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.name' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_sourceSystemDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystem();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected source system.", value, "");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, Request.OPERATION_ECHO);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected operation.", value, Request.OPERATION_ECHO);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'operation' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'operation' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationNull() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'operation' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'operation' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_operationDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getOperation();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected operation.", value, "");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_messageSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.MESSAGE_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getMessage();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected message.", value, "TEST");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_messagenNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getMessage();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'message' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_messageNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.MESSAGE_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getMessage();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'message' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_messageDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.MESSAGE_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getMessage();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'message' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_messageDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.MESSAGE_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getMessage();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected message.", value, "");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_storeNumberSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_BU_CODE_KEY, "00107");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getBuCode();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected store number.", "00107", value);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_storeNumberNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getBuCode();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.bucode' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_storeNumberNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_BU_CODE_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getBuCode();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.bucode' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_storeNumberDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_BU_CODE_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getBuCode();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.bucode' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_employeeSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_EMPLOYEE_KEY, "11111");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getEmployee();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected employee.", value, "11111");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_employeeNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getEmployee();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.employee' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_employeeNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_EMPLOYEE_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getEmployee();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.employee' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_employeeDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_EMPLOYEE_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getEmployee();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'originator.employee' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_employeeDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.ORIGINATOR_EMPLOYEE_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getEmployee();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected employee.", value, "");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedSuccessful1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "1");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected swiped value.", value, true);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedSuccessfulY() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "Y");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected swiped value.", value, true);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedSuccessful0() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "0");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected swiped value.", value, false);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedSuccessfulN() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "N");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected swiped value.", value, false);
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.swiped' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedNotBoolean1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, new Long(1));

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.swiped' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedNotBoolean2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "X");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.swiped' can't be converted to boolean");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, null);

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.swiped' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_swipedDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_SWIPED_KEY, "");

		boolean value = false;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.isSwiped();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.swiped' can't be converted to boolean");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_cardNumberSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(
			Request.CARDENTRY_CARDNUMBER_KEY,
			"6275982150001714762");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getCardNumber();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected card number.", value, "6275982150001714762");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_cardNumberNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getCardNumber();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.cardNumber' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_cardNumberNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_CARDNUMBER_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getCardNumber();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.cardNumber' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_cardNumberDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_CARDNUMBER_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getCardNumber();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'cardEntry.cardNumber' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_cardNumberDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.CARDENTRY_CARDNUMBER_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getCardNumber();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected card number.", value, "");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_transmissionTimeSuccessful()
		throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(
			Request.SOURCE_SYSTEM_TRANSMISSION_KEY,
			"20060223143008");

		Date value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getTransmissionDateTime();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		Calendar vCal = Calendar.getInstance();
		vCal.clear();
		vCal.set(2006, 1, 23, 14, 30, 8);

		assertEquals("Unexpected transmission time.", value, vCal.getTime());
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_transmissionTimeNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		Date value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getTransmissionDateTime();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.transmissionDateTime' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_transmissionTimeNotDate()
		throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_TRANSMISSION_KEY, new Long(1));

		Date value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getTransmissionDateTime();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.transmissionDateTime' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_transmissionTimeDefault1()
		throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_TRANSMISSION_KEY, null);

		Date value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getTransmissionDateTime();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.transmissionDateTime' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_transmissionTimeDefault2()
		throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_TRANSMISSION_KEY, "");

		Date value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getTransmissionDateTime();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.transmissionDateTime' can't be converted to Date");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_referenceSuccessful() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_REFERENCE_KEY, "7.125.1");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystemReference();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected reference.", value, "7.125.1");
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_referenceNotSet() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystemReference();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.reference' was not found in request");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_referenceNotString() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_REFERENCE_KEY, new Long(1));

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystemReference();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.reference' was not a String value");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_referenceDefault1() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_REFERENCE_KEY, null);

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystemReference();
			fail("Should throw exception.");
		} catch (IkeaException e) {
			assertEquals(
				"Not the expected message",
				e.getMessage(),
				"Parameter 'sourceSystem.reference' may not be null");
		}
	}

	/**
	 * Tests RequestInfo
	 */
    @Test
	public void testRequestInfo_referenceDefault2() throws IkeaException {
		Map vRequestMap = new HashMap();
		vRequestMap.put(Request.SOURCE_SYSTEM_NAME_KEY, "TEST");
		vRequestMap.put(Request.OPERATION_KEY, "TEST");
		vRequestMap.put(Request.SOURCE_SYSTEM_REFERENCE_KEY, "");

		String value = null;
		try {
			mTested.setRequestMap(vRequestMap);
			value = mTested.getSourceSystemReference();
		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		assertEquals("Unexpected reference.", value, "");
	}
}
