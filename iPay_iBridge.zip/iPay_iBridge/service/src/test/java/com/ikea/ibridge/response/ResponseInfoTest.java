package com.ikea.ibridge.response;

import java.util.ArrayList;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.error.ApplicationError;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;

@RunWith(EasyMockRunner.class)
public class ResponseInfoTest extends EasyMockSupport {

    @Test
	public void testTranslateApplicationErrors_Pin() throws Exception {
		
		ResponseInfo underTest = new ResponseInfo();
		ArrayList input = new ArrayList();

		ApplicationError applicationError = new ApplicationError(null,ApplicationErrorCodes.INVALID_VERIFICATION_CODE,null);
		input.add(applicationError);
		underTest.translateApplicationErrors(input);
		
		assertEquals(Response.ERROR_TYPE_INVALID_PIN, underTest.getErrorType());
	}

    @Test
	public void testTranslateApplicationErrors_InvalidInput() throws Exception {
		
		ResponseInfo underTest = new ResponseInfo();
		ArrayList input = new ArrayList();

		ApplicationError applicationError = new ApplicationError(null,ApplicationErrorCodes.INVALID_INPUT_GENERAL,null);
		input.add(applicationError);
		underTest.translateApplicationErrors(input);
		
		assertEquals(Response.ERROR_TYPE_CALL_CENTER, underTest.getErrorType());
	}

    @Test
	public void testTranslateApplicationErrors_AMOUNT_GENERAL() throws Exception {
		
		ResponseInfo underTest = new ResponseInfo();
		ArrayList input = new ArrayList();

		ApplicationError applicationError = new ApplicationError(null,ApplicationErrorCodes.INVALID_AMOUNT_GENERAL,null);
		input.add(applicationError);
		underTest.translateApplicationErrors(input);
		
		assertEquals(Response.ERROR_TYPE_INVALID_CARD, underTest.getErrorType());
	}

    @Test
	public void testTranslateApplicationErrors_SomethingElse() throws Exception {
		
		ResponseInfo underTest = new ResponseInfo();
		ArrayList input = new ArrayList();

		ApplicationError applicationError = new ApplicationError(null,27163271,null);
		input.add(applicationError);
		underTest.translateApplicationErrors(input);
		
		assertEquals(Response.ERROR_TYPE_TRY_AGAIN, underTest.getErrorType());
	}
	
}
