/*
 * Created on 2006-maj-02
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.Buffer;
import java.nio.CharBuffer;
import java.util.Arrays;

import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.configuration.Configuration;
import com.ikea.ibridge.request.Request;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.request.XmlRequest;
import com.ikea.ibridge.response.CalypsoResponse;
import com.ikea.ibridge.response.ResponseFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class XmlRequestTest extends EasyMockSupport {

    @Mock
	public Readable mReadableMock;

    @Mock
	public ResponseFactory mResponseFactoryMock;

    @Mock
	public Configuration mConfigurationMock;

    @Mock
	public CalypsoCountries mCalypsoCountriesMock;

	public XmlRequest mTested;


	/**
	 */
    @Test
	public void testRequest_echo() throws Exception {

		// Create and prepare CharBuffer
		StringBuffer vMessage = new StringBuffer("<?xml version=\"1.0\"?>");
		vMessage.append(
			"<ipay xmlns=\"http://www.ikea.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.ikea.com ibridge.xsd\">");
		vMessage.append("<echo>");
		vMessage.append("<message>TEST</message>");
		vMessage.append("</echo>");
		vMessage.append("</ipay>");

        System.out.println(vMessage.toString() + "\n" + vMessage.length());
		CharBuffer vCharBuffer = CharBuffer.allocate(vMessage.length());
        vCharBuffer.put(vMessage.toString());

        // Might be a problem with the number of times that are expected.
        //At least according to the old test cases.
        expect(mReadableMock.read((CharBuffer)anyObject())).andReturn(-1).times(2);

		expect(
                mConfigurationMock.isValidateSchema()).andReturn(
                false).times(
                3);

		expect(
			mResponseFactoryMock.createXmlResponse("echo")).andReturn(
                new CalypsoResponse(mCalypsoCountriesMock));

		
		replayAll();

		RequestInfo vRequestInfo = new RequestInfo();
		try {
			mTested = new XmlRequest(mResponseFactoryMock, mConfigurationMock);
			mTested.read(mReadableMock, vCharBuffer, vRequestInfo);
		} catch (IkeaException e) {
            Assert.fail("Should NOT throw.");
		}

		assertEquals(
			"Unexpected operation.",
			Request.OPERATION_ECHO,
			vRequestInfo.getOperation());
		assertEquals("Unexpected size.", 2, vRequestInfo.size());

		
		verifyAll();
	}

	/**
	 */
    @Test
	public void testRequest_load() throws Exception {

		// Create and prepare CharBuffer
		CharBuffer vCharBuffer = CharBuffer.allocate(1024);
		URL vURL =
			Thread.currentThread().getContextClassLoader().getResource(
				"checkbalance1.xml");
		new InputStreamReader(vURL.openStream()).read(vCharBuffer);

        // Might be a problem with the number of times that are expected.
        //At least according to the old test cases.
		expect(mReadableMock.read((CharBuffer)anyObject())).andReturn(-1).times(2);

		expect(
			mResponseFactoryMock.createXmlResponse("balance")).andReturn(
			new CalypsoResponse(mCalypsoCountriesMock));

		expect(
			mConfigurationMock.isValidateSchema()).andReturn(
			false).times(
			3);

		
		replayAll();

		RequestInfo vRequestInfo = new RequestInfo();
		try {
			mTested = new XmlRequest(mResponseFactoryMock, mConfigurationMock);
			mTested.read(mReadableMock, vCharBuffer, vRequestInfo);

		} catch (IkeaException e) {
			fail("Should NOT throw.");
		}

		assertEquals(
			"Unexpected operation.",
			Request.OPERATION_BALANCE,
			vRequestInfo.getOperation());

		
		verifyAll();
	}

	/**
	 */
    @Test
	public void testRequest_failureByException() throws Exception {

        // Create and prepare CharBuffer
        CharBuffer vCharBuffer = CharBuffer.allocate(1);

        //Added a char so that the test will pass long enough to throw a IOException
        vCharBuffer.put(" ");



        expect(mReadableMock.read((CharBuffer)anyObject())).andThrow(new IOException());

        expect(
                mConfigurationMock.isValidateSchema()).andReturn(
                false).times(
                3);

        replayAll();

        RequestInfo vRequestInfo = new RequestInfo();
        try {
            mTested = new XmlRequest(mResponseFactoryMock, mConfigurationMock);
            mTested.read(mReadableMock, vCharBuffer, vRequestInfo);
            fail("Should throw exception.");
        } catch (Exception e) {
        }

        verifyAll();
	}
}
