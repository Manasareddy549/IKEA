/*
 * Created on 2006-maj-16
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.utest;

import java.io.IOException;
import junit.framework.TestCase;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ibridge.configuration.CalypsoCountries;
import com.ikea.ibridge.request.RequestInfo;
import com.ikea.ibridge.response.CalypsoResponse;
import com.ikea.ibridge.response.Response;
import com.ikea.ibridge.response.ResponseInfo;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertEquals;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class CalypsoResponseTest extends EasyMockSupport {

	public CalypsoResponse mTested;

    @Mock
	public CalypsoCountries mCalypsoCountriesMock;


	/**
	 */
    @Test
	public void testCalypsoResponse_echo() throws Exception {
        mTested = new CalypsoResponse(mCalypsoCountriesMock);
		// Create buffer to hold response
		final StringBuffer vBuffer = new StringBuffer();

		// Create appendable
		Appendable vAppendable = new Appendable() {
			public Appendable append(CharSequence arg0) throws IOException {
				vBuffer.append(arg0);
				return this;
			}

			public Appendable append(CharSequence arg0, int arg1, int arg2)
				throws IOException {
				vBuffer.append(arg0, arg1, arg2);
				return this;
			}

			public Appendable append(char arg0) throws IOException {
				vBuffer.append(arg0);
				return this;
			}
		};

		expect(
                mCalypsoCountriesMock.getDecimals("SE")).andReturn(
                2);


        replayAll();

		RequestInfo vRequestInfo = new RequestInfo();
		ResponseInfo vResponseInfo = new ResponseInfo();
		try {
			vRequestInfo.setMessage(
				"00000000+107+03+0180+000120060420070644  232323             SE+0040                                                        ");
			vRequestInfo.setCountryCode("SE");
			vResponseInfo.setResponseCode(Response.RESPONSE_CODE_NORMAL);
			vResponseInfo.setBalanceAmount(Amounts.amount(150050, 2));
			vResponseInfo.setPaidAmount(Amounts.amount(0));

			mTested.write(vAppendable, vRequestInfo, vResponseInfo);

		} catch (IkeaException e) {
			Assert.fail("Should NOT throw.");
		}

		String vExpectedResponse =
			"ICE+1000+019500000000+107+03+0180+000120060420070644  232323             SE+0040                                                        +000000000000+000+0000000000+0000150050                       0        00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

		assertEquals(
			"Unexpected response.",
			vExpectedResponse,
			vBuffer.toString());

        verifyAll();
	}

}
