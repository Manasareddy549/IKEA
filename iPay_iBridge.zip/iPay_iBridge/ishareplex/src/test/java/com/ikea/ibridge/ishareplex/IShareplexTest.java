package com.ikea.ibridge.ishareplex;

import static junit.framework.Assert.assertEquals;

import java.util.List;

import org.junit.Test;


/**
 * Unit test for simple App.
 */
public class IShareplexTest {

	@Test
	public void verifyThatRequestFilesAreReadInCorrectOrder() throws Exception {
		IShareplex shareplex = new IShareplex();
        //When building in command line with maven we need the path "src/test/resources/test-requests"
        //When running the test manually from the class we need the path "IBRIDGE/ishareplex/src/test/resources/test-requests"
		List<String> requestFiles = shareplex.getRequestFiles("src/test/resources/test-requests");
		assertEquals("111111111TestRequest.txt", requestFiles.get(0));
		assertEquals("222222222TestRequest.txt", requestFiles.get(1));

	}
	
}
