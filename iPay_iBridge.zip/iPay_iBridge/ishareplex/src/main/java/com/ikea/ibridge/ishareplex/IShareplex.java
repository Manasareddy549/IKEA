package com.ikea.ibridge.ishareplex;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.exception.SystemErrorException;
import com.ikea.ibridge.operation.Operation;
import com.ikea.ibridge.operation.OperationFactorySingleton;
import com.ikea.ibridge.request.RequestInfoSerializingUtil;
import com.ikea.ibridge.response.ResponseInfo;
import org.apache.log4j.Logger;
import com.ikea.ibridge.request.RequestInfo;


public class IShareplex {

	private static Logger mLog = Logger.getLogger(IShareplex.class);

	private RequestInfoSerializingUtil requestInfoSerializingUtil;

	
	public void setRequestInfoSerializingUtil(
			RequestInfoSerializingUtil requestInfoSerializingUtil) {
		this.requestInfoSerializingUtil = requestInfoSerializingUtil;
	}

	private void execute() {

		String requestFolderPath = requestInfoSerializingUtil
				.getRequestFolderPath();		
	
		List<String> listOfFiles = getRequestFiles(requestFolderPath);

		for (String fileName : listOfFiles) {
			RequestInfo deserializedRequestInfo = requestInfoSerializingUtil.deserializeRequestInfo(requestFolderPath + "/" + fileName);
			mLog.debug("RequestInfo: " + deserializedRequestInfo.getRequestMap().toString());
			try {
				performSingleRequest(deserializedRequestInfo);
			} catch (Exception e) {
				mLog.error("Request '" + fileName
						+ "' was not successfully resent.", e);
			}
		}

	}

	protected List<String> getRequestFiles(String folderPath) {
		File folder = new File(folderPath);
		mLog.debug("The request should be in: " + folder.getAbsolutePath());
		List<String> filenames = new ArrayList<String>();

		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				filenames.add(listOfFiles[i].getName());
				mLog.debug("File found: " + listOfFiles[i].getName());
			}
		}
		Collections.sort(filenames);
		return filenames;
	}

	private void performSingleRequest(RequestInfo deserializeRequestInfo)
			throws IkeaException, SystemErrorException {
		// Create the operation
		Operation vOperation = OperationFactorySingleton.getInstance()
				.createOperation(deserializeRequestInfo.getOperation());

		// Perform operation
		ResponseInfo responseInfo = new ResponseInfo();

		vOperation.perform(deserializeRequestInfo, responseInfo);
		mLog.debug("ResponseInfo error is: " + responseInfo.getErrorDetails());
	}

	public static void main(String[] args) {
		IShareplex shareplex = new IShareplex();
		shareplex.setRequestInfoSerializingUtil(new RequestInfoSerializingUtil());
		mLog.debug("Starting iShareplex");
		shareplex.execute();
	}
}
