Place these files in C:/iBridgeSimulator

acknowledge_._088_007.0125.0003.xml
balance_6275982990000000931_088_007.0125.0001.xml
redeem_6275982990000000931_00088_007.0125.0001.xml
