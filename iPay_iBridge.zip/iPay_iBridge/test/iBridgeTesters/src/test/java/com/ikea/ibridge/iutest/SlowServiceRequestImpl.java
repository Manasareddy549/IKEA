/*
 * Created on 2006-apr-13
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.iutest;

import com.ikea.ibridge.service.ServiceRequest;
import org.apache.log4j.Logger;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SlowServiceRequestImpl implements ServiceRequest {
	private static final Logger mLogger =
		Logger.getLogger(SlowServiceRequestImpl.class);

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try {
			service();
		} catch (IkeaException e) {
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void service() throws IkeaException {
		try {
			mLogger.info("Starting slow connection");
			Thread.sleep(1000);
			mLogger.info("Ending slow connection");
		} catch (Exception e) {
			throw new IkeaException(e);
		}
	}

}
