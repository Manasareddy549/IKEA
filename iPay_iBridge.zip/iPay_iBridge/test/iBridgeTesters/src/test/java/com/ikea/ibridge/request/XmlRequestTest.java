package com.ikea.ibridge.request;


import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.CharBuffer;
import com.ikea.ibridge.configuration.ConfigurationImpl;
import com.ikea.ebcframework.exception.IkeaException;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(EasyMockRunner.class)
public class XmlRequestTest extends EasyMockSupport {

	//Test scenario when Security is OFF on till
    @Test
	public void testRead_ToVerifyThat_NoTag_EqualsNull_In_RequestInfo()
			throws IkeaException, IOException {

		ConfigurationImpl configurationImpl = new ConfigurationImpl();
		XmlRequest underTest = new XmlRequest(null, configurationImpl) {
			protected void setXmlResponse(RequestInfo requestInfo)
					throws IkeaException {
			}
		};
		RequestInfo requestInfo = new RequestInfo();
		URL vURL = Thread.currentThread().getContextClassLoader().getResource(
				"./redeem1.xml");

		InputStreamReader vReader = new InputStreamReader(vURL.openStream());
		
		CharBuffer vCharBuffer= CharBuffer.allocate(1024);
		int vLength = 0;
		do {
			vLength = vReader.read(vCharBuffer);
		} while (vLength >= 0 && vCharBuffer.position() < 1);
		
		underTest.read(vReader, vCharBuffer, requestInfo);
		
		assertNull(requestInfo.getVerificationCode());
	}
	
	//Test scenario when Security is ON on till
    @Test
	public void testRead_ToVerifyThat_EmptyTag_EqualsEmptyString_In_RequestInfo()
			throws IkeaException, IOException {

		ConfigurationImpl configurationImpl = new ConfigurationImpl();
		XmlRequest underTest = new XmlRequest(null, configurationImpl) {
			protected void setXmlResponse(RequestInfo requestInfo)
					throws IkeaException {
			}
		};
		RequestInfo requestInfo = new RequestInfo();
		URL vURL = Thread.currentThread().getContextClassLoader().getResource(
				"redeem2.xml");

		InputStreamReader vReader = new InputStreamReader(vURL.openStream());
		
		CharBuffer vCharBuffer= CharBuffer.allocate(1024);
		int vLength = 0;
		do {
			vLength = vReader.read(vCharBuffer);
		} while (vLength >= 0 && vCharBuffer.position() < 1);
		
		underTest.read(vReader, vCharBuffer, requestInfo);
		
		assertEquals("", requestInfo.getVerificationCode());
	}

}
