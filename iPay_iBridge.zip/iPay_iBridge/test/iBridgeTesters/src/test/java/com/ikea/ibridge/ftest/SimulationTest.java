/*
 * Created on 2006-maj-09
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.ftest;

import java.io.InputStreamReader;
import java.net.URL;
import java.nio.CharBuffer;

import com.ikea.ibridge.operation.BalanceOperation;
import com.ikea.ibridge.operation.OperationFactorySingleton;
import com.ikea.ibridge.request.RequestFactory;
import com.ikea.ibridge.request.RequestFactorySingleton;
import com.ikea.ibridge.response.ResponseFactorySingleton;
import com.ikea.ibridge.service.ServiceRequest;
import com.ikea.ibridge.service.ServiceRequestImpl;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * @author snug
 * These test will always "work" because there are no expected behavior here.
 * The best way would be to modify these test cases so that they actually expect some type of functionality.
 */
@RunWith(EasyMockRunner.class)
public class SimulationTest extends EasyMockSupport {

    @Mock
	public RequestFactory mRequestFactoryMock;

	public BalanceOperation mTested;

	/**
     * These test will always "work" because there are no expected behavior here.
     * The best way would be to modify these test cases so that they actually expect some type of functionality.
	 */
    @Test
	public void test_checkBalance1() throws Exception {

		exceuteAndPrint("checkbalance1.xml");
	}

	/**
     * These test will always "work" because there are no expected behavior here.
     * The best way would be to modify these test cases so that they actually expect some type of functionality.
	 */
    @Test
	public void test_redeem1() throws Exception {

		exceuteAndPrint("redeem1.xml");
	}

	/**
     * These test will always "work" because there are no expected behavior here.
     * The best way would be to modify these test cases so that they actually expect some type of functionality.
     * This test throws an null point exception, because the test does not expect any behavior i have added ignore to the test case.
     * This should be fixed once we know how these test cases are suppose to work, what they are supposed to expect.
	 */
    @Test
    @Ignore
	public void test_acknowledge1() throws Exception {

		exceuteAndPrint("acknowledge1.xml");
	}

	/**
     * These test will always "work" because there are no expected behavior here.
     * The best way would be to modify these test cases so that they actually expect some type of functionality.
	 */
    @Test
	public void test_load1_no_response_file_found() throws Exception {

		exceuteAndPrint("load1.xml");
	}

	/**
     * These test will always "work" because there are no expected behavior here.
     * The best way would be to modify these test cases so that they actually expect some type of functionality.
	 */
	private void exceuteAndPrint(String pFilename) throws Exception {

		// You must copy the simlutaion responses to C:/iBridgeSimulator

		// Create and prepare CharBuffer
		URL vURL =
			Thread.currentThread().getContextClassLoader().getResource(
				pFilename);

		InputStreamReader vReader = new InputStreamReader(vURL.openStream());
		CharBuffer vCharBuffer = CharBuffer.allocate(512);

		// Replay
		replayAll();

//        These test will always "work" because there are no expected behavior here.
//        The best way would be to modify these test cases so that they actually expect some type of functionality.

		// Running ServiceRequest
		ServiceRequest vServiceRequest =
			new ServiceRequestImpl(
				null,
				vReader,
				System.out,
				null,
				null,
				vCharBuffer,
				RequestFactorySingleton.getInstance().createRequestInfo(),
				ResponseFactorySingleton.getInstance().createResponseInfo(),
				RequestFactorySingleton.getInstance().createInitialRequest(),
				OperationFactorySingleton.getInstance(),
				ResponseFactorySingleton.getInstance(),
				0,
				0);
		vServiceRequest.service();

		// Verify the mock
		verifyAll();
	}
}
