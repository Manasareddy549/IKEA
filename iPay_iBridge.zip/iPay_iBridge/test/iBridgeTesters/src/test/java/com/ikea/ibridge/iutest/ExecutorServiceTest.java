/*
 * Created on 2006-apr-13
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge.iutest;

import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.Executors;

import com.ikea.ibridge.service.ServiceFactory;
import com.ikea.ibridge.service.ServiceImpl;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.easymock.EasyMock.anyLong;
import static org.easymock.EasyMock.anyObject;
import static org.easymock.EasyMock.expect;

/**
 * @author snug
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
@RunWith(EasyMockRunner.class)
public class ExecutorServiceTest extends EasyMockSupport {


    @Mock
	public ServiceFactory mServiceFactoryMock;

	public ServiceImpl mTested;

	/**
	 */
    @Test
	public void testExecutorService_overload() throws Exception {

        int testTimes = 10;
		// Set up expectations on mock ServiceFactory
		expect(mServiceFactoryMock.createServiceRequest((Socket)anyObject(), anyLong(), anyLong())).
                andReturn(new SlowServiceRequestImpl()).times(testTimes);
//		mServiceFactoryControl.setMatcher(MockControl.ALWAYS_MATCHER);
//		mServiceFactoryControl.setReturnValue(
//			new SlowServiceRequestImpl(),
//			MockControl.ONE_OR_MORE);


        replayAll();
		// Running Service
		try {

			mTested =
				new ServiceImpl(
					Executors.newFixedThreadPool(1),
					mServiceFactoryMock);

			mTested.start(9101, 10000, 0, 0);

			for (int i = 0; i < testTimes; i++) {
				Socket vSocket = new Socket("localhost", 9101);
				OutputStream os = vSocket.getOutputStream();
				os.write(1);
				os.flush();
				vSocket.close();
			}

			// Wait a while to allow the reciving end to handle the request before stopping
			Thread.sleep(10000);

			mTested.stop();
		} catch (Exception e) {
			Assert.fail("Should NOT throw.");
		}

        verifyAll();
	}

}
