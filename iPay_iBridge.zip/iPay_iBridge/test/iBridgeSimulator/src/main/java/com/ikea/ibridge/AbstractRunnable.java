/*
 * Created on 2006-okt-19
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge;


import com.ikea.ebccardpay1.client.vo.VoSourceSystem;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.services.BusinessService;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author anms
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AbstractRunnable {
	
	/**
	 * Log category for messages
	 */
    private static Logger log = LoggerFactory.getLogger(AbstractRunnable.class);

    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();

	protected VoSourceSystem createVoSourceSystem() {
		VoSourceSystem vVoSourceSystem = new VoSourceSystem();
        vVoSourceSystem.setSourceSystem(randomSourceSystem());
		return vVoSourceSystem;

	}

	protected int randomInt(int pMax) {
		return new Double(Math.random() * pMax).intValue();
	}
	protected String randomSourceSystem() {

		String v[] = new String[3];
		v[0] = "IPAY";
		v[1] = "CALYPSO";
		v[2] = "4690";

		return v[randomInt(v.length)];
	}
	protected String randomAmountType() {

		String v[] = new String[2];
		v[0] = "CASH";
		v[1] = "DISCOUNT";

		return v[randomInt(v.length)];
	}
	
	protected void executeBs(BusinessService pBs) throws Exception {
		//BsCallInfo bsCallInfo = new BsCallInfo("EBCCARDPAY1",null, null,0L, null,"Originator");
        log.info("bsExecuter : "+bsExecuter);
        log.info("pBs : "+pBs);
		bsExecuter.executeBs(pBs,"Originator");
		if (pBs.getApplicationErrors() != null
			&& pBs.getApplicationErrors().size() > 0) {

			for (int i = 0; i < pBs.getApplicationErrors().size(); i++) {
				ApplicationError vApplicationError = pBs.getApplicationErrors().get(i);
                log.warn("Apliaction error " + vApplicationError);

			}

			throw new IkeaException("Found application errors!");
		}

	}


}
