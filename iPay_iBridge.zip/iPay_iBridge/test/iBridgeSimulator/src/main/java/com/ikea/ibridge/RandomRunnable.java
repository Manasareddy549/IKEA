package com.ikea.ibridge;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.ikea.ebccardpay1.client.bs.BsLoadCard;
import com.ikea.ebccardpay1.client.bs.BsRedeemCard;
import com.ikea.ebccardpay1.client.vo.VoCardEntry;
import com.ikea.ebccardpay1.client.vo.VoEnvironment;
import com.ikea.ebccardpay1.client.vo.VoLoadAmount;
import com.ikea.ebccardpay1.client.vo.VoOriginator;
import com.ikea.ebccardpay1.client.vo.VoReference;
import com.ikea.ebccardpay1.client.vo.VoRequestAmount;
import org.apache.log4j.Logger;


/**
 */
public class RandomRunnable extends AbstractRunnable implements Runnable {

	/**
	 * Log category for messages
	 */
    private static Logger log = Logger.getLogger(RandomRunnable.class);

	private String mCardNumber = null;
	private int mTransactionCount = 0;
	private String mCurrencyCode;
	private int mCount = 1;

	/**
	 * 
	 * @param pCardNumber
	 * @param pTransactionCount
	 */
	public RandomRunnable(String pCardNumber, int pTransactionCount, String pCurrencyCode) {
		mCardNumber = pCardNumber;
		mTransactionCount = pTransactionCount;
		mCurrencyCode = pCurrencyCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		log.debug("Started thread.");

		try {

			for (int j = 0; j < mTransactionCount; j++) {

				BigDecimal vAmount = new BigDecimal(Math.random() * 1000);
				vAmount = vAmount.setScale(2, BigDecimal.ROUND_DOWN);

				String vResult =
					randomInt(2) == 0 ? load(vAmount) : redeem(vAmount);
			}

		} catch (Exception e) {
			log.error(e);
		}

		log.debug("Finished thread.");
	}

	private String load(BigDecimal vAmount) throws Exception {
		log.info(mCardNumber + " load " + vAmount + " " + mCurrencyCode);

		BsLoadCard vBs = new BsLoadCard();

		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setCardNumberString(mCardNumber);
		vVoCardEntry.setSwiped(true);
		vBs.setVoCardEntry(vVoCardEntry);

		VoLoadAmount vVoLoadAmount = new VoLoadAmount();
		vVoLoadAmount.setAmountType("CASH");
        vVoLoadAmount.setCurrencyCode(mCurrencyCode);
		vVoLoadAmount.setLoadAmount(vAmount);
		vBs.setVoLoadAmount(vVoLoadAmount);

		vBs.setVoEnvironment(createVoEnvironment());
		vBs.setVoOriginator(createVoOriginator());
		vBs.setVoReference(createVoReference());
		vBs.setVoSourceSystem(createVoSourceSystem());

		executeBs(vBs);

		return "load";
	}
	private String redeem(BigDecimal vAmount) throws Exception {
		log.info(mCardNumber + " redeem " + vAmount + " " + mCurrencyCode);

		BsRedeemCard vBs = new BsRedeemCard();

		VoCardEntry vVoCardEntry = new VoCardEntry();
		vVoCardEntry.setCardNumberString(mCardNumber);
		vVoCardEntry.setSwiped(true);
		vBs.setVoCardEntry(vVoCardEntry);

		VoRequestAmount vVoRequestAmount = new VoRequestAmount();
		vVoRequestAmount.setRequestAmount(vAmount);
		vVoRequestAmount.setCurrencyCode(mCurrencyCode);
		vBs.setVoRequestAmount(vVoRequestAmount);

		vBs.setVoEnvironment(createVoEnvironment());
		vBs.setVoOriginator(createVoOriginator());
		vBs.setVoReference(createVoReference());
		vBs.setVoSourceSystem(createVoSourceSystem());

		executeBs(vBs);

		return "redeem";
	}

	private VoEnvironment createVoEnvironment() {
		VoEnvironment vVoEnvironment = new VoEnvironment();
		return vVoEnvironment;

	}
	private VoOriginator createVoOriginator() {
		VoOriginator vVoOriginator = new VoOriginator();
		vVoOriginator.setBuType("STO");
		vVoOriginator.setBuCode("" + (randomInt(20) + 100));
		vVoOriginator.setEmployee("kassa" + randomInt(20));
		return vVoOriginator;

	}
	private VoReference createVoReference() {
		VoReference vVoReference = new VoReference();
		vVoReference.setReference(
			Thread.currentThread().getName()
				+ "."
				+ mCount++
				+ " "
				+ new SimpleDateFormat("yyyy.MM.dd HH:mm:ss z").format(
					new Date()));
		vVoReference.setTransmissionDateTime(new Date());
		return vVoReference;

	}

}
