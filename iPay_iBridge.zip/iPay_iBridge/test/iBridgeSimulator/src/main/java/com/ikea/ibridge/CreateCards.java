/*
 * Created on 2006-okt-19
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ibridge;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.ikea.ebccardpay1.client.bs.BsActivateCards;
import com.ikea.ebccardpay1.client.vo.VoCardBusinessKey;
import org.apache.log4j.Logger;

/**
 * @author anms
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CreateCards extends AbstractRunnable {

	/**
	 * Log category for messages
	 */
    private static Logger log = Logger.getLogger(CreateCards.class);

	private List mCardNumbers = null;

	/**
	 * 
	 * @param pCardNumbers
	 */
	public CreateCards(List pCardNumbers) {
		mCardNumbers = pCardNumbers;
	}

	public void run() throws Exception {
        log.debug("Started thread.");
		ThreadGroup vThreadGroup = new ThreadGroup("Create cards thread");

		BsActivateCards vBs = new BsActivateCards();
		List<VoCardBusinessKey> vList = new ArrayList<VoCardBusinessKey>();

		for (Iterator i = mCardNumbers.iterator(); i.hasNext();) {
			String vCardNumber = (String) i.next();

			VoCardBusinessKey vKey = new VoCardBusinessKey();
			vKey.setCardNumberString(vCardNumber);
			vList.add(vKey);
		}
        vBs.setInputVoCardBusinessKeyList(vList);
		vBs.setVoSourceSystem(createVoSourceSystem());

		executeBs(vBs);

		while (vThreadGroup.activeCount() > 0);
		log.debug("Finished thread.");
	}

}
