package com.ikea.ibridge;

import org.apache.log4j.Logger;

import java.util.Iterator;
import java.util.List;

/**
 */
public class RandomTransactions {

	/**
	 * Log category for messages
	 */
    private static Logger log = Logger.getLogger(RandomTransactions.class);

	private List mCardNumbers = null;
	private int mTransactionCount = 0;
	private String mCurrencyCode;

	/**
	 * 
	 * @param pCardNumbers
	 * @param pTransactionCount
	 */
	public RandomTransactions(List pCardNumbers, int pTransactionCount, String pCurrencyCode) {
		mCardNumbers = pCardNumbers;
		mTransactionCount = pTransactionCount;
		mCurrencyCode = pCurrencyCode;
	}

	/**
	 * 
	 *
	 */
	public void run() {
        log.debug("Starting threads.");
		ThreadGroup vThreadGroup = new ThreadGroup("Random threads");

		int idx = 1;
		for (Iterator i = mCardNumbers.iterator(); i.hasNext();) {
			String vCardNumber = (String) i.next();
			Thread vThread =
				new Thread(
					vThreadGroup,
					new RandomRunnable(vCardNumber, mTransactionCount, mCurrencyCode));
			vThread.setName("Random-" + idx++);
			vThread.start();
		}

		while (vThreadGroup.activeCount() > 0);
        log.debug("Finished threads.");
	}
}
