package com.ikea.ibridge;

import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

/**
 * @author anms
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
/**
 */
public class Simulator {
	/**
	 * Arguments
	 */
	private static final String RANDOM_MODE = "random";
	private static final String CREATE_MODE = "create";
	private static final String CURRENCY_CODE = "currency=";
	private static final String CARD_NUMBERS = "cardNumbers=";
	private static final String TRANSACTION_COUNT = "transactionCount=";

	// Without check digit!
	private static final String CARD_NUMBER_FROM = "cardNumberFrom=";
	private static final String CARD_NUMBER_COUNT = "cardNumberCount=";

	/**
	 * Log category for messages
	 */
    private static Logger log = Logger.getLogger(Simulator.class);

	static List mCardNumbers = new LinkedList();
	static boolean mRandom = false;
	static boolean mCreate = false;
	static int mTransactionCount = 1;
	static String mCurrencyCode = "";
	static long mCardNumberFrom = 627598299010000000L;
	static int mCardNumberCount = 0;

	/**
	 * Try this: create cardNumbers=6275982990000000337,6275982990000000345,6275982990000000352
	 * Try this: create cardNumberFrom=627598299010000000 cardNumberCount=3
	 * Try this: random transactionCount=2 currency=SEK cardNumbers=6275982990000000337,6275982990000000345,6275982990000000352
	 * Try this: random transactionCount=2 currency=EUR cardNumberFrom=627598299010000000 cardNumberCount=3
	 * @param pArguments
	 */
	public static void main(String[] pArguments) {
		log.info("Starting POS Simulator");

		try {
			parseArgs(pArguments);
			log.info("Transaction count is " + mTransactionCount);
			log.info("Using currency " + mCurrencyCode);

			addRange();

			if (mRandom) {
				RandomTransactions vRandomTransactions =
					new RandomTransactions(
						mCardNumbers,
						mTransactionCount,
						mCurrencyCode);
				vRandomTransactions.run();
			} else if (mCreate) {
				CreateCards vCreateCards = new CreateCards(mCardNumbers);
				vCreateCards.run();

			} else {
				log.error("Only random implemneted!");
			}

		} catch (Exception e) {
			log.error("Error when running simulator.", e);
		}

		log.info("Finished POS Simulator");
	}

	private static void addRange() {

		if (mCardNumberCount <= 0) {
			return;
		}

		for (int i = 0; i < mCardNumberCount; i++) {

			long vCardNumberWithoutCheck = mCardNumberFrom + i;
			String vCardNumber =
				""
					+ vCardNumberWithoutCheck
					+ getValidCheckDigit("" + vCardNumberWithoutCheck);
			if (!isValidCheckDigit(vCardNumber)) {
				throw new RuntimeException("Not correct check digit! Internal error.");
			}
			mCardNumbers.add(vCardNumber);
		}

	}
	/**
	 * Validates if it is a valid credit card number using Luhn (a.k.a Mod 10) formula. 
	 * @param pCardNumberWithoutCheck the card number including the check digit
	 * @return
	 */
	protected static int getValidCheckDigit(String pCardNumberWithoutCheck) {

		int sum = 0;
		int nDigits = pCardNumberWithoutCheck.length();
		int parity = nDigits % 2;
		for (int i = 0; i < nDigits; i++) {

			int digit =
				Integer.parseInt("" + pCardNumberWithoutCheck.charAt(i));
			if (!(i % 2 == parity)) {
				// It is a digit on a an ODD index (1,3,5,7,9,...) from the end, then multiplicate with 2.
				digit = digit * 2;
			}
			if (digit > 9) {
				// The digit is more then two digits, then reduce 9
				digit = digit - 9;
			}
			sum += digit;

		}
		sum = sum % 10;
		if (sum > 0)
			sum = 10 - sum;
		return sum;
	}
	/**
	 * Validates if it is a valid credit card number using Luhn (a.k.a Mod 10) formula. 
	 * @param pCardNumber the card number including the check digit
	 * @return
	 */
	protected static boolean isValidCheckDigit(String pCardNumber) {

		int sum = 0;
		int nDigits = pCardNumber.length();
		int parity = nDigits % 2;
		for (int i = 0; i < nDigits; i++) {

			int digit = Integer.parseInt("" + pCardNumber.charAt(i));
			if (i % 2 == parity) {
				// It is a digit on a an ODD index (1,3,5,7,9,...) from the end, then multiplicate with 2.
				digit = digit * 2;
			}
			if (digit > 9) {
				// The digit is more then two digits, then reduce 9
				digit = digit - 9;
			}
			sum += digit;

		}
		return (sum % 10) == 0;
	}

	private static void parseArgs(String[] pArguments) {
		// Parse arguments
		for (int i = 0; i < pArguments.length; i++) {
			String vArgument = pArguments[i];

			// Random mode
			if (vArgument.startsWith(RANDOM_MODE)) {
				mRandom = true;
				log.info("Choosing random mode");
			}
			// Random mode
			else if (vArgument.startsWith(CREATE_MODE)) {
				mCreate = true;
				log.info("Choosing create mode");
			}
			// Currency
			else if (vArgument.startsWith(CURRENCY_CODE)) {
				mCurrencyCode = vArgument.substring(CURRENCY_CODE.length());
			}

			// Number of transactions
			else if (vArgument.startsWith(TRANSACTION_COUNT)) {
				mTransactionCount =
					Integer.parseInt(
						vArgument.substring(TRANSACTION_COUNT.length()));

			}

			// List of card numbers
			else if (vArgument.startsWith(CARD_NUMBERS)) {
				String vCardNumberString =
					vArgument.substring(CARD_NUMBERS.length());

				StringTokenizer vStringTokenizer =
					new StringTokenizer(vCardNumberString, ",");
				while (vStringTokenizer.hasMoreTokens()) {
					mCardNumbers.add(vStringTokenizer.nextToken());
				}

				log.info(
					"Card numbers found [" + vCardNumberString + "]");
			}

			// Card number range
			else if (vArgument.startsWith(CARD_NUMBER_FROM)) {

				mCardNumberFrom =
					Long.parseLong(
						vArgument.substring(CARD_NUMBER_FROM.length()));

				log.info("Card number range from " + mCardNumberFrom);

			}
			// Card number range count
			else if (vArgument.startsWith(CARD_NUMBER_COUNT)) {

				mCardNumberCount =
					Integer.parseInt(
						vArgument.substring(CARD_NUMBER_COUNT.length()));

				log.info("Card number range count " + mCardNumberCount);

			}

		}

	}
}