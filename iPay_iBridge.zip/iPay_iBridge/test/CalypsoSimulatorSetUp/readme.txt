1) Double click on the exceutable jar file

2) Choose in the menu System->Config

3) Set the Host to the ip address of the machine that is running iBridge. (run ipconfig in cmd to check).

4) Set the port to 9101 (the same as in ibridge.properties)

5) Select one of the test files

6) Connect

7) Send


Note, you must have the EBC simulator running to get expected results when you use the files in "iPay test files"..