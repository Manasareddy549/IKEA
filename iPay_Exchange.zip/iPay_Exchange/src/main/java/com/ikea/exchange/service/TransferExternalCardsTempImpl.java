
package com.ikea.exchange.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.ikea.ebccardpay1.client.bs.BsImportExternalCards;
import com.ikea.ebccardpay1.client.bs.BsImportExternalCardsTemp;
import com.ikea.ebccardpay1.client.vo.VoExternalCard;
import com.ikea.ebccardpay1.client.vo.VoExternalCardSystem;
import com.ikea.ebccardpay1.client.vo.VoExternalCardTemp;
import com.ikea.ebccardpay1.client.vo.VoExternalCardTempOutput;
import com.ikea.ebccardpay1.client.vo.VoExternalCardTempStatus;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.SystemErrorException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author anagc
 *
 *
 */
public class TransferExternalCardsTempImpl implements TransferExternalCardsTemp {
	private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	private static final String WORKING_EXTENSION = ".working";
	private static final String FINISHED_EXTENSION = ".finished";
	private static final String FAILED_EXTENSION = ".failed";

	public final static String CARD_STATUS_IMPORT="IMPORT";

	private final static Logger log = LoggerFactory.getLogger(ExternalCardServiceImpl.class);

	private final static SimpleDateFormat sFormatter =
			new SimpleDateFormat("yyyyMMddHHmmss");

	/**
	 * Dependencies
	 */
	private ScheduledExecutorService mScheduledExecutorService = null;
	private ServiceFactoryImpl mServiceFactoryImpl = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	/**
	 * The scanning directory
	 */
	File mExternalCardScanningDirectory = null;

	/**
	 * The processed directory
	 */
	File mExternalCardProcessedDirectory = null;

	/**
	 * The failed directory
	 */
	File mExternalCardFailedDirectory = null;

	File mExternalCardVerificationScanningDirectory=null;

	File mLogDirectory=null;

	/**
	 * The scanning interval
	 */
	long mExternalCardScanningInterval = 60;

	/**
	 * Active File handler
	 */
	Map mCurrentScanning = new HashMap();

	/**
	 * 
	 * Dependency injector constructor, used by factory and unit testing. Don't call
	 * the constructor directly, use ServiceFactorySingleton.getInstance().createExternalCardService().
	 * The constructor is public so it can be used by the test cases.
	 *  
	 * @param pScheduledExecutorService
	 */
	public TransferExternalCardsTempImpl(
			ScheduledExecutorService pScheduledExecutorService,
			ServiceFactoryImpl pServiceFactoryImpl) {

		mScheduledExecutorService = pScheduledExecutorService;
		mServiceFactoryImpl = pServiceFactoryImpl;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ExternalCardService#start(java.io.File, long)
	 */
	public void start(
			File pExternalCardScanningDirectory,
			File pExternalCardVerificationScanningDirectory,
			File pExternalCardProcessedDirectory,
			File pExternalCardFailedDirectory,
			File pLogDirectory,
			long pExternalCardScanningInterval)
					throws IkeaException {

		// Check running flag
		if (mRunning) {
			throw new IkeaException("ExternalCardService is already running");
		}

		mExternalCardScanningDirectory = pExternalCardScanningDirectory;
		mExternalCardVerificationScanningDirectory = pExternalCardVerificationScanningDirectory;
		mExternalCardProcessedDirectory = pExternalCardProcessedDirectory;
		mExternalCardFailedDirectory = pExternalCardFailedDirectory;
		mLogDirectory=pLogDirectory;
		mExternalCardScanningInterval = pExternalCardScanningInterval;

		log.info(
				"Scanning interval"
						+ mExternalCardScanningInterval
						+ "  ...... "
						+ mExternalCardScanningDirectory.getPath());

		// Info in the log
		log.info(
				"Starting ExternalCardService on directory "
						+ mExternalCardScanningDirectory.getPath());

		mScheduledExecutorService.scheduleAtFixedRate(
				this,
				mExternalCardScanningInterval,
				mExternalCardScanningInterval,
				TimeUnit.SECONDS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;

	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ExternalCardService#stop()
	 */
	public void stop() throws IkeaException {
		// Check running flag
		if (!mRunning) {
			throw new IkeaException("ExternalCardService is not running");
		}

		// Set running flag to false to indicate that the service is stopped
		mRunning = false;

	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		// Info in the log
		log.info(
				"ExternalCardDirectoryScanning......"
						+ mExternalCardScanningDirectory.getName()
						+ "...");

		File[] vFileList = mExternalCardScanningDirectory.listFiles();
		log.info(
				vFileList.toString());

		for (int i = 0; i < vFileList.length; i++) {
			File vCurrent = vFileList[i];

			if (!vCurrent.exists()) {
				log.error(
						vCurrent.getName() + " does not exists. Skipping.....");
				continue;
			}
			if (!vCurrent.canRead()) {
				log.error(
						vCurrent.getName() + " can not be read. Skipping.....");
				continue;
			}
			if (!vCurrent.canWrite()) {
				log.error(
						vCurrent.getName() + " is not writable. Skipping.....");
				continue;
			}

			processFile(vCurrent);
		}
	}

	/**
	 * 
	 * @param pCurrentFile
	 */
	protected void processFile(File pCurrentFile) {

		String vFileName = pCurrentFile.getName();
		log.info("Processing " + vFileName + "...");

		if (vFileName.endsWith(WORKING_EXTENSION)
				|| vFileName.endsWith(FINISHED_EXTENSION)
				|| vFileName.endsWith(FAILED_EXTENSION)) {
			log.info("Skipping working file " + vFileName + "...");
			return;
		}

		File vWorking =
				renameFile(
						pCurrentFile,
						mExternalCardScanningDirectory,
						vFileName + WORKING_EXTENSION);

		if (vWorking == null) {
			return; // skip
		}

		// Process the file
		boolean success=false;

		ArrayList data=process(vWorking, vFileName);
		if(data.size()>0)
		{
			success=true;
		}

		if (success) {

			log.info("File " + vFileName + " successfully imported");
			// Set filename to finished and move


			String verificationFile="";
			if(vFileName.contains("GIFT"))
			{
				verificationFile=vFileName.replaceAll("_GIFT_", "_VER_");
			}
			else if(vFileName.contains("REFUND")){
				verificationFile=vFileName.replaceAll("_REFUND_", "_VER_");
			}

			log.info("Looking for verification file " + verificationFile + " successfully imported");
			verifyAndStartTransfer(verificationFile,data,vWorking,vFileName);


		} else {
			log.warn("File " + vFileName + " failed import");
			// Set filename to failed and move
			updateLog(vFileName, "\n\n[---------------import of file finished UnSuccessfully------------------]");
			updateLog(vFileName, "\n\n[---------------issue with Load Files. Please place proper file.------------------]");
			renameAndMove(
					vWorking,
					mExternalCardFailedDirectory,
					vFileName + FAILED_EXTENSION);
		}
	}

	private void verifyAndStartTransfer(String verificationFileName,ArrayList pData,File vWorking,String vFileName) {
		// TODO Auto-generated method stub
		log.info("Starting Transfer");
		BufferedReader br = null;
		FileReader fr = null;
		try{
			String file=mExternalCardVerificationScanningDirectory.getPath()+"\\"+verificationFileName;


			//br = new BufferedReader(new FileReader(FILENAME));
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String sCurrentLine=br.readLine();
			String[] vData=sCurrentLine.split(";");
			BigDecimal amount=new BigDecimal(vData[1]);
			boolean status=true;
			if(Integer.parseInt(vData[0])==(Integer)pData.get(1)
					&& amount.equals((BigDecimal)pData.get(2)))
			{
				log.info("Verification file matched, starting to transfer");
				for(int j=0; j<(Integer)pData.get(1);j++)
				{
					VoExternalCardTempStatus vVoExternalCardTempStatus= new VoExternalCardTempStatus();
					vVoExternalCardTempStatus.setErrorMessage("1000");
					vVoExternalCardTempStatus.setImportedFileName((String)pData.get(0));
					vVoExternalCardTempStatus.setStatus("TRANSFER");
					List<VoExternalCardTemp>  vlist= new ArrayList<VoExternalCardTemp>();
					List<VoExternalCardTempOutput> output=importExternalCardsTemp(
							vlist,
							vVoExternalCardTempStatus);
					boolean first=true;
					for(VoExternalCardTempOutput vVoExternalCardTempOutput:output)
					{
						if(vVoExternalCardTempOutput.getStatus().equalsIgnoreCase("FAILED"))
						{
							if(first)
							{
								updateLog(vFileName, "\n\n[---------------import of file finished Unsuccessfully With Below Errors------------------]");
								first=false;
							}
							updateLog(vFileName,"\n"+vVoExternalCardTempOutput.getCardNumberString()+";"+vVoExternalCardTempOutput.getErrorMessage());
							status=false;
						}
					}

					j+=1000;

					if(status)
					{
						updateLog(vFileName, "\n\n[---------------import of file finished Successfully------------------]");
						renameAndMove(
								vWorking,
								mExternalCardProcessedDirectory,
								vFileName + FINISHED_EXTENSION);
					}
					else{
						renameAndMove(
								vWorking,
								mExternalCardFailedDirectory,
								vFileName + FAILED_EXTENSION);
					}
				}



			}
			else{
				updateLog(vFileName, "\n\n[---------------import of file finished Unsuccessfully------------------]");
				updateLog(vFileName, "\n\n[---------------Load File and Verification file did not match------------------]");
				log.info("Load File and Verification file did not match");
				renameAndMove(
						vWorking,
						mExternalCardFailedDirectory,
						vFileName + FAILED_EXTENSION);

			}
		}
		catch(Exception e)
		{
			log.info(e.getLocalizedMessage());
			log.info("Transfer Failed");
			updateLog(vFileName, "\n\n[---------------import of file finished Unsuccessfully------------------]");
			updateLog(vFileName, "\n[---------------Contact Ipay Team------------------]");
			renameAndMove(
					vWorking,
					mExternalCardFailedDirectory,
					vFileName + FAILED_EXTENSION);

		}
		finally{
			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
	}


	/**
	 * 
	 * Handles the import of the External Cards and catches all possible errors
	 * that can occur when calling the BS BsImportExternalCards in iPay
	 *
	 * This method should only return true or false
	 * 
	 * @param pFile
	 * @param pFileName
	 * @return true if the import was successfull false if it failed.
	 */
	private ArrayList process(File pFile, String pFileName) {
		BufferedReader vReader = null;

		// Create externalcard list VO
		List<VoExternalCardTemp> vVoExternalCardTempList = new ArrayList<VoExternalCardTemp>();

		// Create ExternalCardSystem VO

		VoExternalCardTempStatus vVoExternalCardTempStatus = new VoExternalCardTempStatus();

		String vLine = null;
		int vRowCount = 0;
		int vLimit = 1000;
		int chunkNumber=0;
		int newCardCount=0;
		BigDecimal newAmt=new BigDecimal(0.0);
		int correctedCardCount=0;
		BigDecimal correctedAmt=new BigDecimal(0.0); 

		ArrayList passData= new ArrayList();

		List<VoExternalCardTempOutput> vVoExternalCardTempOutputList = new ArrayList<VoExternalCardTempOutput>();

		// Initiate IO zoo
		try {
			vReader =
					new BufferedReader(
							new InputStreamReader(new FileInputStream(pFile)));

			// Parse header
			vLine = vReader.readLine();

			// Create ExternalCardSystem VO from Header info 
			vVoExternalCardTempStatus = setStatus(pFileName);


			while (vLine != null) {

				vRowCount++;

				//Create ExternalCard from row and add VO to List
				VoExternalCardTemp mVoExternalCardTemp= createExternalCardTemp(vLine,pFileName);
				if(mVoExternalCardTemp!=null)
				{
					vVoExternalCardTempList.add(
							createExternalCardTemp(vLine,pFileName));
				}

				if (vVoExternalCardTempList.size() >= vLimit) {

					log.info("[--------Row -------]"+vRowCount);
					log.info("[--------Chunk -------]"+chunkNumber++);
					vVoExternalCardTempOutputList=
							importExternalCardsTemp(
									vVoExternalCardTempList,
									vVoExternalCardTempStatus);

					for(VoExternalCardTempOutput mVoExternalCardTempOutput:vVoExternalCardTempOutputList)
					{
						if(mVoExternalCardTempOutput.getStatus().equalsIgnoreCase(CARD_STATUS_IMPORT))
						{
							newCardCount++;
							newAmt=newAmt.add(mVoExternalCardTempOutput.getBalance());
						}
						else
						{
							correctedCardCount++;
							correctedAmt=correctedAmt.add(mVoExternalCardTempOutput.getBalance()); 
						}
					}


					// Create new List to reset values	
					vVoExternalCardTempOutputList = new ArrayList<VoExternalCardTempOutput>();
					vVoExternalCardTempList= new ArrayList<VoExternalCardTemp>();

				}

				vLine = vReader.readLine();
			}

			vVoExternalCardTempOutputList =
					importExternalCardsTemp(
							vVoExternalCardTempList,
							vVoExternalCardTempStatus);
			for(VoExternalCardTempOutput mVoExternalCardTempOutput:vVoExternalCardTempOutputList)
			{
				if(mVoExternalCardTempOutput.getStatus().equalsIgnoreCase(CARD_STATUS_IMPORT))
				{
					newCardCount++;
					newAmt=newAmt.add(mVoExternalCardTempOutput.getBalance());
				}
				else
				{
					correctedCardCount++;
					correctedAmt=correctedAmt.add(mVoExternalCardTempOutput.getBalance()); 
				}
			}

			int totalCards=newCardCount+correctedCardCount;
			BigDecimal fullCards=new BigDecimal(0.0);
			fullCards=fullCards.add(newAmt);
			fullCards=fullCards.add(correctedAmt);

			log.info("[-------- Import of file finished -------]");


			log.info( "[---------------Summary------------------]");
			log.info( "Total cards: " +totalCards);
			log.info( "Total Amount: " +fullCards);
			log.info("[----------------------------------------]");
			log.info( "[---------------New Card Summary--------]");
			log.info( "Total cards: " +newCardCount);
			log.info( "Total Amount: " +newAmt);
			log.info("[----------------------------------------]");
			log.info( "[---------------Updated CardSummary------]");
			log.info( "Total cards: " +correctedCardCount);
			log.info( "Total Amount: " +correctedAmt);
			log.info("[----------------------------------------]");

			passData.add(pFileName);
			passData.add(totalCards);
			passData.add(fullCards);
			passData.add(newCardCount);
			passData.add(newAmt);
			passData.add(correctedCardCount);
			passData.add(correctedAmt);


			uploadLogFile(pFileName,totalCards,fullCards,newCardCount,newAmt,correctedCardCount,correctedAmt);


			return passData;
		}catch (Exception e) {
			// Catch all and return false
			log.error(
					pFile.getName()
					+ " could not be processed. - Failed at row "
					+ vRowCount
					+ " Line info:"
					+ vLine,
					e);
		} finally {

			// Close file
			try {
				if (vReader != null)
					vReader.close();
			} catch (IOException e) {
				log.error(e.getLocalizedMessage());
			}
		}
		return passData;
	}

	private void uploadLogFile(String pFileName, int totalCards,
			BigDecimal fullCards, int newCardCount, BigDecimal newAmt,
			int correctedCardCount, BigDecimal correctedAmt) {
		// TODO Auto-generated method stub

		String FILENAME=(mLogDirectory.getPath()+"\\"+pFileName);

		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			String content =("[-------- Import of file finished -------]"
					+"\n[---------------Summary------------------]"
					+"\nTotal cards: " +totalCards
					+"\nTotal Amount: " +fullCards
					+"\n[----------------------------------------]"
					+"\n[---------------New Card Summary--------]"
					+"\nTotal cards: " +newCardCount
					+"\nTotal Amount: " +newAmt
					+"\n[---------------Updated CardSummary------]"
					+"\nTotal cards: " +correctedCardCount
					+"\nTotal Amount: " +correctedAmt
					+"\n[----------------------------------------]");


			fw = new FileWriter(FILENAME);
			bw = new BufferedWriter(fw);
			bw.write(content);

			//System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}




	}

	/**
	 * 
	 * Creates a VO object for ExternalCardSystem from the Header string in file.
	 * 
	 * @param pHeaderString - Header line from file contains ExternalCardSystem info 
	 * @return VoExternalCardSystem
	 */
	private VoExternalCardTempStatus setStatus(String pFileName) {

		log.info("Configure VoExternalCardTempStatus.....");

		VoExternalCardTempStatus vVoExternalCardTempStatus = new VoExternalCardTempStatus();

		vVoExternalCardTempStatus.setImportedFileName(pFileName);


		vVoExternalCardTempStatus.setStatus(CARD_STATUS_IMPORT);

		return vVoExternalCardTempStatus;

	}

	/**
	 * Creates a VO object for ExternalCard for each line in file
	 * 
	 * @param pLine - Line from importfile
	 * @return VoExternalCard
	 */
	private VoExternalCardTemp createExternalCardTemp(String pLine,String pFileName) {

		String[] vSplitRow = SplitString(pLine, ";");

		// Create VO and set External Card values from line
		VoExternalCardTemp vVoExternalCardTemp = new VoExternalCardTemp();

		try{// added try catch block to handle 
			// pos 1. CardNumber
			vVoExternalCardTemp.setCardNumberString(vSplitRow[0].trim());
			// pos 2. CurrencyCode
			vVoExternalCardTemp.setCurrencyCode(vSplitRow[1].trim());
			// pos 3. Original balance
			vVoExternalCardTemp.setBalance(new BigDecimal(vSplitRow[2].trim()));
			// pos 4. BuType
			vVoExternalCardTemp.setBuCode(vSplitRow[3].trim());
			// pos 5. BuCode
			try{
				vVoExternalCardTemp.setBuType(vSplitRow[4].trim());
			}
			catch(Exception e)
			{
				vVoExternalCardTemp.setBuType("STO");
			}
			vVoExternalCardTemp.setImportedRow(pLine);

			vVoExternalCardTemp.setImportedFile(pFileName);

			String[] vSplitFileName = SplitString(pFileName,"_");

			vVoExternalCardTemp.setExternalCardSystem(vSplitFileName[0].trim());

			vVoExternalCardTemp.setIkeaCardType(vSplitFileName[1].trim());
			return vVoExternalCardTemp;
		}
		catch(Exception e)
		{
			return null;
		}


	}

	/**
	 * 
	 * @param pStringToSplit
	 * @param pDelimiter
	 * @return
	 */
	private String[] SplitString(String pStringToSplit, String pDelimiter) {
		String[] vNewString = pStringToSplit.split(pDelimiter);
		return vNewString;

	}

	/**
	 * Method that makes the EBC call to ipay business service 
	 * BsImportExternalCards
	 * 
	 * @param vVoExternalCardList
	 * @param vVoExternalCardSystem
	 * @return
	 */
	private List<VoExternalCardTempOutput> importExternalCardsTemp(
			List<VoExternalCardTemp> vVoExternalCardTempList,
			VoExternalCardTempStatus vVoExternalCardTempStatus)
					throws IkeaException, SystemErrorException {

		// Create service
		BsImportExternalCardsTemp vBsImportExternalCardsTemp =
				new BsImportExternalCardsTemp();

		// Set input VO
		vBsImportExternalCardsTemp.setExternalCardTempList(vVoExternalCardTempList);
		vBsImportExternalCardsTemp.setExternalCardTempStatus(vVoExternalCardTempStatus);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
		bsExecuter.executeBs(vBsImportExternalCardsTemp,"Originator");

		// Check for application errors
		List<ApplicationError> vApplErrors = vBsImportExternalCardsTemp.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			throw new IkeaException(
					"Application errors found in import. " + vApplErrors);
		}

		// Check if ouput from import is OK
		if (vBsImportExternalCardsTemp.getExternalCardTempOutputList() == null) {
			throw new IkeaException("Got null ExternalCard ListTemp object back from BS");
		}

		return vBsImportExternalCardsTemp.getExternalCardTempOutputList();
	}

	/**
	 * Only made to clean up code a bit
	 *
	 * @param pFile
	 * @param pNewFileName
	 * @return
	 */
	private File renameFile(File pFile, File pDirectory, String pNewFileName) {
		File vWorking = new File(pDirectory, pNewFileName);

		if (!pFile.renameTo(vWorking)) {
			log.warn(
					"Could not rename "
							+ pFile
							+ " to "
							+ pNewFileName
							+ ", skipping... ");
			return null;
		}
		return vWorking;
	}

	/**
	 * 
	 * @param pFile
	 * @param pDirectory
	 * @param pNewFileName
	 */
	protected void renameAndMove(
			File pFile,
			File pDirectory,
			String pNewFileName) {

		File vWorking = new File(pDirectory, pNewFileName);

		if (!pFile.renameTo(vWorking)) {

			log.info(
					"Could not rename "
							+ pFile
							+ " to "
							+ vWorking
							+ ", trying to add timestamp");

			File vWorking2 =
					new File(
							pDirectory,
							pNewFileName + sFormatter.format(new Date()));
			if (!pFile.renameTo(vWorking2)) {

				log.warn(
						"Could not rename "
								+ pFile
								+ " to "
								+ vWorking2
								+ ", skipping... ");
			}
		}
	}

	private void updateLog(String pFileName, String Message) {
		// TODO Auto-generated method stub

		String FILENAME=(mLogDirectory.getPath()+"\\"+pFileName);

		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			fw = new FileWriter(FILENAME,true);
			bw = new BufferedWriter(fw);
			bw.write(Message);

			//System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}




	}



}
