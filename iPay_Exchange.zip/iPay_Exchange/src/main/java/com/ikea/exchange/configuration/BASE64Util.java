package com.ikea.exchange.configuration;
import java.nio.charset.Charset;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
public class BASE64Util {
	/**
	 * ??????
	 * @return
	 * @throws Exception
	 */
	public KeyPair pkAndPub() throws Exception{
		KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");
		gen.initialize(1024, new SecureRandom());
		KeyPair pair=gen.generateKeyPair();
		PrivateKey pk=pair.getPrivate();
		PublicKey pub=pair.getPublic();
        KeyPair kp=new KeyPair(pub, pk);
        return kp;
	}
	
	/**
	 * ????
	 * @param aesKey
	 * @param plainData
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("static-access")
	public String encryptAES(String aesKey,String plainData) throws Exception{
		BASE64Encoder encoder=new BASE64Encoder();
		KeyGenerator aesGen = KeyGenerator.getInstance("AES");
		SecureRandom secureRadmon= new SecureRandom().getInstance("SHA1PRNG");
		secureRadmon.setSeed(aesKey.getBytes());
		aesGen.init(128,secureRadmon);
		SecretKey secretKey =aesGen.generateKey();
		Cipher aesCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		aesCipher.init(Cipher.ENCRYPT_MODE,secretKey);
		byte[] aesData =aesCipher.doFinal(plainData.getBytes());
		String aesBase64 =encoder.encode(aesData).replaceAll("[\r\n]","");
		return aesBase64;
	}
	
	/**
	 * ????
	 * @param aesBase64
	 * @param aesKey
	 * @return
	 * @throws Exception
	 */
	public String decryptAES(String aesBase64,String aesKey) throws Exception{
		BASE64Decoder decoder=new BASE64Decoder();
		byte[] aesData =decoder.decodeBuffer(aesBase64);
		KeyGenerator aesGen = KeyGenerator.getInstance("AES");
		aesGen.init(128, new SecureRandom(aesKey.getBytes()));
		SecretKey secretKey = aesGen.generateKey();
		Cipher aesCipher=Cipher.getInstance("AES/ECB/PKCS5Padding");
		aesCipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] plain =aesCipher.doFinal(aesData);
		String  decrypt=new String(plain,Charset.forName("utf-8"));
		return decrypt;
	}
	

	/**	
	 * ??????
	 * @return
	 */
	public String getRandomkey(){
		SecureRandom  symkey =  new SecureRandom();
		long sym_l=symkey.nextLong();
		return ""+sym_l;
	}

	/**
	 * ????
	 * @param aesKey
	 * @param pk
	 * @return
	 * @throws Exception
	 */
	public String encryptRSA(String aesKey,PrivateKey pk) throws Exception{
		BASE64Encoder encoder=new BASE64Encoder();
		Cipher cipher =Cipher.getInstance("RSA/ECB/PKCs1padding");
		cipher.init(Cipher.ENCRYPT_MODE, pk);
		cipher.update(aesKey.getBytes());
		byte[] encryptData =cipher.doFinal();
		String keyBase64=encoder.encode(encryptData).replaceAll("[\r\n]","");
		return keyBase64;
	}
	
	/**
	 * ????
	 * @param keyBase64
	 * @param pub
	 * @return
	 * @throws Exception
	 */
	public String decryptRSA(String keyBase64,PublicKey pub) throws Exception{
		BASE64Decoder decoder=new BASE64Decoder();
		//???????????????aes??
		byte[] encryptData = decoder.decodeBuffer(keyBase64);
		Cipher cipher =Cipher.getInstance("RSA/ECB/PKCs1padding");
		cipher.init(Cipher.DECRYPT_MODE,pub);
		cipher.update(encryptData);
		byte[] data=cipher.doFinal();
		String decrypt=new String(data,Charset.forName("utf-8"));
		return decrypt;
	}
	/**
	 * ???public Key??
	 */
	public PublicKey getPublicKey(String key) throws Exception {
		byte[] keyBytes = (new BASE64Decoder()).decodeBuffer(key);
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey publicKey = keyFactory.generatePublic(keySpec);
		return publicKey;
	}
	/**
	 * ???PrivateKey??
	 */
	public PrivateKey getPrivateKey(String key) throws Exception {
		byte[] keyBytes;
		keyBytes = (new BASE64Decoder()).decodeBuffer(key);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
		return privateKey;
	}


}
