package com.ikea.exchange.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.client.bs.BsImportCardRange;
import com.ikea.ebccardpay1.client.vo.VoCardNumber;
import com.ikea.ebccardpay1.client.vo.VoCardRange;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.exchange.configuration.FileStatus;
import com.ikea.ebcframework.exception.SystemErrorException;

public class ExternalServiceExtender {

	private final static Logger mLog = LoggerFactory.getLogger(ExternalServiceExtender.class);

	private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();

	public final static int CARD_TYPE_CONSTANT_GIFT = 2;
	public final static int CARD_TYPE_CONSTANT_REFUND = 4;
	public final static int CARD_TYPE_CONSTANT_FAMILY = 0;
	public final static int CARD_TYPE_CONSTANT_VOUCHER = 9;
	public final static int CARD_TYPE_CONSTANT_QPC = 1;
	public final static int CARD_TYPE_CONSTANT_CAMPAIGN = 3;
	public final static int ISSUER=627598;

	private final static int CHUNK_LIMIT = 100;
	private final static String IMPORT_START = "START";
	private final static String IMPORT_DONE = "DONE";
	private final static String IMPORT_FAILED = "FAILED";

	private final static String SCANNING_DIRECTORY="ImportCards";
	private final static String PROCESSED_DIRECTORY="Processed";
	private final static String FAILED_DIRECTORY="Failed";

	private final static int CARD_NUMBER_LEN = 19;
	private final static String CARD_NUMBER_REGEXP = "[0-9]{" + CARD_NUMBER_LEN
			+ "}";

	private String fileName;
	private BufferedReader vReader;
	private int card_type=0;
	private String countryCode;
	private String fileTypeBatch;
	private ArrayList<String> errorList= new ArrayList<String>();
	private ArrayList<String> duplicateCards = new ArrayList<String>(); 

	private Connection mConnection=null;


	private HashMap<String,String> iPayCards;

	private FileStatus mFileStatus;

	public ExternalServiceExtender(String fileName,Connection mConnection)
	{
		this.fileName=fileName;
		this.mConnection=mConnection;
		mFileStatus=new FileStatus();
	}

	//@Override
	public FileStatus startTask() {

		mLog.info("Starting External Service Task Service");

		if(fileName.endsWith(".txt"))
		{
			Path frmPath= Paths.get(fileName.replace(".txt", ".working"));
			Path failedPath=Paths.get(fileName.replace(SCANNING_DIRECTORY, FAILED_DIRECTORY).replace(".txt", ".failed"));
			Path processedPath=Paths.get(fileName.replace(SCANNING_DIRECTORY, PROCESSED_DIRECTORY).replace(".txt", ".processed"));
			try{

				File file= new File(fileName);
				mFileStatus.setFileName(file.getName());
				file.renameTo(frmPath.toFile());
				this.countryCode=file.getParentFile().getName();
				mFileStatus.setCountry(this.countryCode);
				vReader = new BufferedReader(new InputStreamReader(new FileInputStream(frmPath.toFile())));
				String[] headerAndName=getHeader();
				HashMap<String,String> verifiedCards=getCards();
				mFileStatus.setCardBatchType(fileTypeBatch);
				if(errorList.size()==0)
				{
					mFileStatus.setCardBatchType(fileTypeBatch);
					dbResult(verifiedCards);
				}
				if(errorList.size()>0 || duplicateCards.size()>0)
				{
					if(duplicateCards.size()>0)
					{

						errorList.add("Found iPay Cards which are already existing in iPay Database "+
								Arrays.toString(duplicateCards.toArray(new String[duplicateCards.size()])));

					}
					vReader.close();
					Files.move(frmPath,failedPath,StandardCopyOption.REPLACE_EXISTING);

					mFileStatus.setFileUploadStatus(false);
				}
				else{
					processCards(headerAndName,verifiedCards);
					vReader.close();
					Files.move(frmPath,processedPath,StandardCopyOption.REPLACE_EXISTING);
					mFileStatus.setFileUploadStatus(true);
				}
			}
			catch(Exception e)
			{
				mFileStatus.setFileUploadStatus(false);
				try {
					vReader.close();
					Files.move(frmPath,failedPath,StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					mLog.error("File Movement issue");
				}
				errorList.add("Card Loading Failed due to"+e.getMessage()+"\n");

			}

		}
		mFileStatus.setErrorMessage(errorList);
		return mFileStatus;
	}

	private String[] getHeader()
	{
		mLog.info("Reading Header from iPay File");

		String[] headerAndName={"",""};
		String vName =null;
		String vHeader=null;
		try{
			vHeader = vReader.readLine();

			if (vHeader == null || vHeader.length() == 0 ) {
				throw new Exception("Header of the File is Empty");
			}
			if(!vHeader.startsWith("SELP"))
			{
				throw new Exception("Unkonwn Card vendor");
			}
			// Extract name
			vName = fileName.substring(fileName.lastIndexOf("\\")+1);
			String[] vSplit = vHeader.split("\t");
			if (vSplit.length >= 3) {
				vName = vSplit[2];
			}
		}
		catch(Exception e)
		{
			errorList.add("Unable to Find Header and Name for file "+mFileStatus.getFileName()+"\n Reason: "+e.getMessage());
		}
		headerAndName[0]=vHeader;
		headerAndName[1]=vName;

		return headerAndName;
	}

	private HashMap<String,String> getCards() throws Exception
	{
		mLog.info("Reading card Number and Pin Number from file");

		String vLine=vReader.readLine();
		HashMap<String,String> cards = new HashMap<String,String>();
		String vCardNumberString="";
		String vVerificationCode="";
		HashSet nonDuplicateCards= new HashSet();
		int lineNumber=1;
		while (vLine != null) {
			lineNumber++;
			try{
				if (vLine.length() >= 24 || (vLine.indexOf(";") != -1)) {

					if (vLine.indexOf(";") != -1) {
						String[] vLineSplit = vLine.split(";");
						vCardNumberString = vLineSplit[0];
						vVerificationCode = vLineSplit[1];
						if(vCardNumberString.matches(CARD_NUMBER_REGEXP) && 
								Integer.parseInt(vCardNumberString.substring(0, 6))==ISSUER)
						{

							if(nonDuplicateCards.add(vCardNumberString))
							{
								int card_digit=Integer.parseInt(vCardNumberString.substring(6, 7));
								if(card_digit==CARD_TYPE_CONSTANT_GIFT
										||card_digit==CARD_TYPE_CONSTANT_REFUND)
								{

									if(card_type==0)
									{
										card_type=card_digit;
										if(card_digit==CARD_TYPE_CONSTANT_GIFT)
										{
											fileTypeBatch="GIFT";
										}
										else if(card_digit==CARD_TYPE_CONSTANT_REFUND)
										{
											fileTypeBatch="REFUND";
										}
									}
									else{
										if(card_type!=card_digit)
										{
											errorList.add("Found Card number "+vCardNumberString +" improper in the "+fileTypeBatch +" file at line Number "+lineNumber);
										}
									}
									cards.put(vCardNumberString,vVerificationCode);
								}
								else{
									errorList.add("Only Gift or Refund Cards can be processed,fault found in line "+lineNumber);
								}
							}
							else{
								errorList.add("Duplicate Card found in Same File at Line Number "+lineNumber);
							}
						}
						else{
							errorList.add("Unknown String or non iPay Card Number found in line "+lineNumber);
						}

					}
				}

			}
			catch(Exception e)
			{
				errorList.add("Error in Reading Card info in file due to"+e.getMessage()+"\n");
			}
			vLine=vReader.readLine();
		}
		return cards;
	}


	private void dbResult(HashMap<String,String> cards) throws Exception
	{
		mLog.info("Verifying the cards are not existing in DB");

		try{
			Statement stmt=null;
			String queryString=new String("select (issuer||card_type_digit||account_number||check_digit) as card_number "
					+ "from EBCCARDPAY1.SELP_CARD_NUMBER_V where issuer="+ISSUER+ " and card_type_digit=" +card_type +" and account_number in (");
			StringBuffer modifiedString=new StringBuffer(queryString);
			int count=0;
			int incrementalCount=0;
			if(cards!=null)
			{
				if(cards.size()>0)
				{

					Set<String> cardSet= cards.keySet();
					for(String card:cardSet)
					{
						if(count<=1000 && incrementalCount<=cardSet.size())
						{
							modifiedString.append("'"+card.substring(7,18)+"'"+",");
							count++;
						}
						if(count>=1000 || incrementalCount==(cardSet.size()-1))
						{
							modifiedString.replace(modifiedString.lastIndexOf(","),modifiedString.lastIndexOf(",")+1,")");
							stmt= mConnection.createStatement();
							System.out.println(modifiedString.toString());
							ResultSet result=stmt.executeQuery(modifiedString.toString());							
							while(result.next())
							{
								String card_number=new String(result.getString("card_number"));
								duplicateCards.add(card_number);								
							}
							count=0;
							modifiedString=null;
							modifiedString=new StringBuffer(queryString);
						}


						incrementalCount++;
					}
				}
			}
			if(stmt!=null)
				stmt.close();
		}
		catch(Exception e)
		{
			throw new Exception("Error in Excecuting DB Querry or connecting to Database");
		}

	}

	private void processCards(String[] vHeaderAndName,HashMap<String,String> pCardList) throws Exception{

		mLog.info("Creating chunks of 100 cards if the card count is more than 100");

		VoCardRange vVoCardRange = new VoCardRange();
		vVoCardRange.setRangeId(0);
		vVoCardRange.setCountryCode(countryCode);
		vVoCardRange.setFileName(fileName.substring(fileName.indexOf("ExternalCardFromSFTP")));
		vVoCardRange.setHeader(vHeaderAndName[0]);
		vVoCardRange.setName(vHeaderAndName[1]);

		List<VoCardNumber> mVoCardNumberList= new ArrayList<VoCardNumber>();
		int count=0;
		int incrementalCount=0;
		if(pCardList!=null)
		{
			if(pCardList.size()>0)
			{
				try{

					Set<String> cardSet= pCardList.keySet();
					for(String card:cardSet)
					{
						if(count<=CHUNK_LIMIT && incrementalCount<(cardSet.size()-1))
						{
							VoCardNumber pVoCardNumber = new VoCardNumber();
							pVoCardNumber.setCardNumberString(card);
							pVoCardNumber.setVerificationCode(pCardList.get(card));
							mVoCardNumberList.add(pVoCardNumber);
							count++;
						}

						if(count>=CHUNK_LIMIT && incrementalCount<(cardSet.size()-1))
						{
							vVoCardRange.setImportState(IMPORT_START);
							vVoCardRange.setCount(incrementalCount+1);
							vVoCardRange = importRange(mVoCardNumberList,vVoCardRange);
							mVoCardNumberList=new ArrayList<VoCardNumber>();
							count=0;
						}

						if(count>=CHUNK_LIMIT || incrementalCount==(cardSet.size()-1))
						{
							if(verifyCardsInDb(vVoCardRange)==vVoCardRange.getCount())
							{
								vVoCardRange.setImportState(IMPORT_DONE);
								vVoCardRange.setCount(incrementalCount+1);
								vVoCardRange = importRange(mVoCardNumberList,vVoCardRange);
							}
							else{
								throw new Exception("Card Count in the file does not match with Card Import Details in DB");
							}

						}
						incrementalCount++;
					}
				}catch(Exception e)
				{
					vVoCardRange.setImportState(IMPORT_FAILED);
					vVoCardRange.setCount(incrementalCount+1);
					vVoCardRange = importRange(mVoCardNumberList,vVoCardRange);
				}
			}
		}
	}


	private VoCardRange importRange(List<VoCardNumber> pVoCardNumberList,
			VoCardRange pVoCardRange) throws IkeaException,
	SystemErrorException {

		mLog.debug("Calling BsImport Functionality");
		// Create service
		BsImportCardRange vBsImportCardRange = new BsImportCardRange();

		// Set input VO
		vBsImportCardRange.setVoCardNumberList(pVoCardNumberList);
		vBsImportCardRange.setInputVoCardRange(pVoCardRange);

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
		bsExecuter.executeBs(vBsImportCardRange,"Originator");

		// Check for application errors
		List vApplErrors = vBsImportCardRange.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			throw new IkeaException(getClass().getName() + " " +
					"Application errors found in import. " + vApplErrors);
		}

		return vBsImportCardRange.getOutputVoCardRange();
	}

	private Long verifyCardsInDb(VoCardRange pVoCardRange) throws Exception
	{
		mLog.info("Verifying Card Count in Database");

		String countVerification=new String("select count(RANGE_ID) as card_count from EBCCARDPAY1.SELP_CARD_NUMBER_V where RANGE_ID="+pVoCardRange.getRangeId());
		Statement stmt= mConnection.createStatement();
		ResultSet result=stmt.executeQuery(countVerification.toString());
		String card_count="";
		while(result.next())
		{
			card_count=new String(result.getString("card_count"));
		}
		stmt.close();

		return Long.parseLong(card_count);

	}

}
