package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.File;

/**
 * @author anagc
 *
 *
 */
public interface TransferExternalCardsTemp extends Runnable{


	/**
	 * 
	 */
	public void start(
			File pExternalCardScanningDirectory,
			File pExternalCardVerificationScanningDirectory,
			File pExternalCardProcessedDirectory,
			File pExternalCardFailedDirectory,
			File pLogDirectory,
			long pExternalCardScanningInterval)
					throws IkeaException;


	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public void stop() throws IkeaException;



}

