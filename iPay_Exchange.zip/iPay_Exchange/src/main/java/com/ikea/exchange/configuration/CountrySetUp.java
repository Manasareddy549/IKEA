package com.ikea.exchange.configuration;

/*
 * Interface for providing country settings information the the iBridge service.
 * This is typically read from a configuration file.
 * 
 */
public interface CountrySetUp {


	/**
	 * Updates the country folders. This method can be scheduled at
	 * regular intervals
	 */
	public void updateCountries();

}
