package com.ikea.exchange.service;

import java.io.*;
import java.text.*;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.exchange.configuration.BASE64Util;

import java.net.*;
import java.security.PrivateKey;

public class ChinaEncryptionServiceHandler extends Thread 
{
	private final static Logger mLog = LoggerFactory.getLogger(ChinaEncryptionServiceHandler.class);
	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;
	final String pkString;


	// Constructor
	public ChinaEncryptionServiceHandler(Socket s,String pkString, DataInputStream dis, DataOutputStream dos) 
	{
		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.pkString=pkString;
	}

	@Override
	public void run() 
	{
		String received;
		String toreturn;
		String streamInput;
		String[] streamInputSplit;
		BASE64Util util= new BASE64Util();

		while (true) 
		{
			try {

				// Ask user what he wants
				dos.writeUTF("What do you want?[RandomKey | AESEncryption | RSAEncryption]..\n"+
						"Type Exit to terminate connection.");

				// receive the answer from client
				streamInput=dis.readUTF();
				streamInputSplit = streamInput.split("\\\\n");
				received=streamInputSplit[0];

				if(received.equals("Exit"))
				{ 
					mLog.info("Client " + this.s + " sends exit...");
					mLog.info("Closing this connection.");
					this.s.close();
					mLog.info("Connection closed");
					break;
				}

				// creating Date object
				Date date = new Date();

				// write on output stream based on the
				// answer from the client
				switch (received) {

				case "RandomKey" :
					try{
						dos.writeUTF(util.getRandomkey());
					}
					catch(Exception e)
					{
						mLog.error("Error",e);
						dos.writeUTF("ERROR");
					}
					break;

				case "AESEncryption" :	
					try{
						dos.writeUTF(util.encryptAES(streamInputSplit[1], streamInputSplit[2]));
					}
					catch(Exception e)
					{
						mLog.error("Error",e);
						dos.writeUTF("ERROR");
					}
					break;

				case "RSAEncryption" :
					try{
						PrivateKey pk= util.getPrivateKey(pkString);
						dos.writeUTF(util.encryptRSA(streamInputSplit[1], pk));
					}
					catch(Exception e)
					{
						mLog.error("Error",e);
						dos.writeUTF("ERROR");
					}
					break;

				default:
					dos.writeUTF("Invalid input");
					break;
				}
			} catch (Exception e) {
				mLog.error("Error",e);
				try {
					s.close();
					break;
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}

		try
		{
			// closing resources
			this.dis.close();
			this.dos.close();

		}catch(IOException e){
			e.printStackTrace();
		}
	}
}