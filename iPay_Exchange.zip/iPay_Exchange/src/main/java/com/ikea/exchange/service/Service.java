package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.File;


/**
 */
public interface Service extends Runnable {

	/**
	 */
	public void start(
		File pScanningDirectory,
		File pProcessedDirectory,
		File pFailedDirectory,
		String pSubPath,
		long pScanningInterval,
		String pMailAddress,
		String pMailSmtpHost)
		throws IkeaException;

	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public void stop() throws IkeaException;
}
