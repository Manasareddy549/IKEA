package com.ikea.exchange.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import java.util.zip.Checksum;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.ikea.ebccardpay1.client.vo.*;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.exception.SystemErrorException;
import com.ikea.ebccardpay1.client.bs.BsImportCardRange;
import com.ikea.ebccardpay1.client.bs.BsInitiateMultipleSingleLoad;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author snug
 * 
 * Implements the Service interface
 * 
 */
public class ServiceImpl implements Service {

	private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();

	private static final String WORKING_EXTENSION = ".working";

	private final static int CARD_NUMBER_LEN = 19;
	public final static String CARD_NUMBER_REGEXP = "[0-9]{" + CARD_NUMBER_LEN
			+ "}";

	private final static SimpleDateFormat sFormatter = new SimpleDateFormat(
			"yyyyMMddHHmmss");

	private final static int CHUNK_LIMIT = 100;
	private final static String IMPORT_START = "START";
	private final static String IMPORT_DONE = "DONE";
	private final static String IMPORT_FAILED = "FAILED";

	private final static String FILE_TYPE_XML = "xml";
	private final static String FILE_TYPE_FLAT = "flat";

	/**
	 * Card Type Digits
	 */

	public final static int CARD_TYPE_CONSTANT_GIFT = 2;
	public final static int CARD_TYPE_CONSTANT_REFUND = 4;
	public final static int CARD_TYPE_CONSTANT_FAMILY = 0;
	public final static int CARD_TYPE_CONSTANT_VOUCHER = 9;
	public final static int CARD_TYPE_CONSTANT_QPC = 1;
	public final static int CARD_TYPE_CONSTANT_CAMPAIGN = 3;
	/**
	 * Log category for messages
	 */
	private final static Logger log = LoggerFactory.getLogger(ServiceImpl.class);

	/**
	 * Dependencies
	 */
	private ScheduledExecutorService mScheduledExecutorService = null;
	private ServiceFactory mServiceFactory = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	/**
	 * The scanning directory
	 */
	File mScanningDirectory = null;

	/**
	 * The processed directory
	 */
	File mProcessedDirectory = null;

	/**
	 * The failed directory
	 */
	File mFailedDirectory = null;

	/**
	 * The sub path we are scanning, or null if top level
	 */
	String mCountryCode = null;

	/**
	 * The scanning interval
	 */
	long mScanningInterval = 120;

	String mMailAddress = null;
	String mMailSmtpHost = null;

	/**
	 * Sub-scanning services
	 */
	Map mSubScanning = new HashMap();

	/**
	 * Handles import if fileformat is xml
	 */
	XmlParserImpl mXmlParserImpl = null;

	List<String> mSuccessList;
	List<String> mErrorList;
	String mExceptionMsg;

	/**
	 * Create Separate ArrayList for all the CardTypes
	 * 
	 */
	HashMap<String,String> pGiftCardList= new HashMap<String,String>();
	HashMap<String,String> pRefundCardList = new HashMap<String,String>();
	HashMap<String,String> pFamilyCardList = new HashMap<String,String>();
	HashMap<String,String> pVoucherCardList = new HashMap<String,String>();
	HashMap<String,String> pQpcCardList = new HashMap<String,String>();
	HashMap<String,String> pCampaignCardList = new HashMap<String,String>();

	int pGiftCardSize=0;
	int pRefundCardSize=0;
	int pFamilyCardSize=0;
	int pVoucherCardSize=0;
	int pQpcCardSize=0;
	int pCampaignCardSize=0;


	/**
	 * Dependency injector constructor, used by factory and unit testing. Don't
	 * call the constructor directly, use
	 * ServiceFactorySingleton.getInstance().createService(). The constructor is
	 * public so it can be used by the test cases.
	 */
	public ServiceImpl(ScheduledExecutorService pScheduledExecutorService,
			ServiceFactory pServiceFactory) {

		mScheduledExecutorService = pScheduledExecutorService;
		mServiceFactory = pServiceFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.exchange.service.Service#start(java.io.File)
	 */
	public void start(
			File pScanningDirectory,
			File pProcessedDirectory,
			File pFailedDirectory,
			String pCountryCode,
			long pScanningInterval,
			String pMailAddress,
			String pMailSmtpHost)
					throws IkeaException {

		// Check running flag
		if (mRunning) {
			throw new IkeaException("Service is already running");
		}

		mScanningDirectory = pScanningDirectory;
		mProcessedDirectory = pProcessedDirectory;
		mFailedDirectory = pFailedDirectory;
		mCountryCode = pCountryCode;
		mScanningInterval = pScanningInterval;
		mMailAddress = pMailAddress;
		mMailSmtpHost = pMailSmtpHost;

		// Info in the log
		log.info("Starting service on directory "
				+ mScanningDirectory.getName());

		mScheduledExecutorService.scheduleAtFixedRate(this,
				randomLong(pScanningInterval), pScanningInterval,
				TimeUnit.SECONDS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.exchange.service.Service#stop()
	 */
	public void stop() throws IkeaException {

		// Check running flag
		if (!mRunning) {
			throw new IkeaException("Service is not running");
		}

		// Set running flag to false to indicate that the service is stopped
		mRunning = false;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		// Info in the log
		log.debug("Scanning " + mScanningDirectory.getName()
				+ " with country code " + mCountryCode + "...");

		mSuccessList = new ArrayList<String>();
		mErrorList = new ArrayList<String>();
		mExceptionMsg = null;

		// Try processing files
		try {
			File[] vFileList = mScanningDirectory.listFiles();

			for (int i = 0; i < vFileList.length; i++) {
				File vCurrent = vFileList[i];

				// Start new service for sub directories
				if (vCurrent.isDirectory()) {
					String vPath = vCurrent.getAbsolutePath();

					// Check that we are not already scanning this directory
					if (!mSubScanning.containsKey(vPath)) {
						Service vSubService = mServiceFactory.createService();
						mSubScanning.put(vPath, vSubService);

						// Calculate country code from the two first characters
						// of the folder name
						String vCountryCode = vCurrent.getName();
						if (vCountryCode != null && vCountryCode.length() > 2) {
							vCountryCode = vCountryCode.substring(0, 2);
						}

						// Start new service on the sub folder
						vSubService.start(vCurrent, mProcessedDirectory,
								mFailedDirectory, vCountryCode,
								mScanningInterval, mMailAddress, mMailSmtpHost);
					}
				} else if (vCurrent.exists() && vCurrent.canRead()
						&& vCurrent.canWrite()) {

					String vFileName = vCurrent.getName();

					log.info("Processing " + vFileName + "...");

					if (vFileName.endsWith(WORKING_EXTENSION)) {
						log.info("Skipping working file " + vFileName
								+ "...");
						continue;
					}

					File vWorking = new File(mScanningDirectory, vFileName
							+ WORKING_EXTENSION);

					if (vCurrent.renameTo(vWorking)) {
						vCurrent = vWorking;
					} else {
						log.warn("Could not rename " + vFileName + " to "
								+ vWorking.getName() + ", skipping... ");
						mErrorList.add(vFileName + "\nCould not rename to " + vWorking.getName());
						continue;
					}

					// Process the file
					boolean success = process(vCurrent, vFileName);

					// Determine directory
					File vDestinationDirectory = null;
					if (success) {
						vDestinationDirectory = mProcessedDirectory;
					} else {
						vDestinationDirectory = mFailedDirectory;
					}

					// Sub
					File vSubDirectory = new File(vDestinationDirectory,
							mCountryCode);

					// Destination
					File vDestination = new File(vSubDirectory, vFileName);

					log.info("Moving to "
							+ vDestination.getAbsoluteFile());

					if (!vCurrent.renameTo(vDestination)) {
						// Try to add time stamp
						File vDestinationSecondTry = new File(vSubDirectory,
								vFileName + sFormatter.format(new Date()));
						log.info("Could not move to "
								+ vDestination.getAbsoluteFile() + " Trying "
								+ vDestinationSecondTry.getAbsoluteFile());
						if (!vCurrent.renameTo(vDestinationSecondTry)) {
							log.warn("Could not move to second try "
									+ vDestinationSecondTry.getAbsoluteFile());
						}
					}

				} else {
					log.error(vCurrent.getName()
							+ "could not be processed");
					mErrorList.add(vCurrent.getName() + "\nCould not be processed");
				}
			}
		} catch (IkeaException e) {

			// Ikea exceptions needs to be logged
			log.error(e.getLocalizedMessage());
			mExceptionMsg = e.toString();
		} finally {
			if (mSuccessList.size() > 0 || mErrorList.size() > 0 || mExceptionMsg != null) {
				sendMail();
			}
		}
	}

	/**
	 * 
	 * @param pFile
	 */
	private boolean process(File pFile, String pFileName) {

		BufferedReader vReader = null;

		try {

			// Create checksum
			Checksum vChecksum = new CRC32();

			// Initiate IO zoo
			vReader = new BufferedReader(new InputStreamReader(
					new CheckedInputStream(new FileInputStream(pFile),
							vChecksum)));

			// Check which file format xml or flatfile
			String vfileType = checkFileFormat(vReader);
			if (vfileType != null && vfileType.equals(FILE_TYPE_XML)) {
				// if (pFileName.contains(".xml")) {
				log.info("This is a XML file, use XML parser....");
				XmlParserImpl vXmlParserImpl = new XmlParserImpl();
				vXmlParserImpl.readXmlFile(vReader);
				if (vXmlParserImpl.getMVoCardRange() != null) {
					saveXmlFile(vXmlParserImpl, pFile, vChecksum);
					mSuccessList.add(pFileName);
				} else if (vXmlParserImpl.getMVoMultipleSingleLoadInitial() != null) {
					initiateXmlMultipleSingleLoad(vXmlParserImpl);
					mSuccessList.add(pFileName);
				} else {
					log.error("Wrong XML format, cannot handle file: " + pFile.getName());
					mErrorList.add(pFileName + "\nWrong XML format, cannot handle file");
				}
				return true;

			} else if (vfileType != null && vfileType.equals(FILE_TYPE_FLAT)) {
				log.info("This is a flat file parse text....");
				readFlatFile(vReader, pFile, pFileName, vChecksum);
				mSuccessList.add(pFileName);
				return true;
			}

		} catch (Throwable e) {

			log.error(e.getLocalizedMessage());
			mErrorList.add(pFileName + "\n" + e.toString());

		} finally {

			// Close file
			try {
				if (vReader != null)
					vReader.close();
			} catch (IOException e) {
				log.error(e.getLocalizedMessage());
			}
		}

		return false;
	}

	/**
	 * @param vReader
	 * @return
	 */
	private String checkFileFormat(BufferedReader vReader) {
		try {
			vReader.mark(10);
			String vFirstLine = vReader.readLine();
			log.info("Check file type, first line: " + vFirstLine);
			vReader.reset();
			if (vFirstLine.indexOf("<?xml") != -1) {
				return FILE_TYPE_XML;
			} else {
				return FILE_TYPE_FLAT;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * @param pXmlParserImpl
	 * @param pFile
	 * @param pChecksum
	 */
	private void saveXmlFile(XmlParserImpl pXmlParserImpl, File pFile,
			Checksum pChecksum) throws SystemErrorException, IkeaException {
		VoCardRange vVoCardRange = pXmlParserImpl.getMVoCardRange();
		vVoCardRange.setChecksum(pChecksum.getValue());
		vVoCardRange.setCountryCode(mCountryCode);
		vVoCardRange.setRangeId(0);
		vVoCardRange.setImportState(IMPORT_START);
		vVoCardRange.setFileName(pFile.getAbsolutePath());
		List<VoCardNumber> vVoCardNumberList = pXmlParserImpl
				.getMVoCardNumberList();
		log.info("Saving the parsed cardnumbers from xml file elements:"
				+ vVoCardNumberList.size());

		importXmlRange(vVoCardNumberList, vVoCardRange);

	}

	/**
	 * @param vVoCardNumberList
	 * @param vVoCardRange
	 */
	private void importXmlRange(List<VoCardNumber> vVoCardNumberList,
			VoCardRange vVoCardRange) throws SystemErrorException,
			IkeaException {

		List<VoCardNumber> vTempVoCardNumberList = new ArrayList<VoCardNumber>();
		int vCount = 0;

		log.info("Total list length:" + vVoCardNumberList.size());

		for (VoCardNumber vCardNumVoCardNumber : vVoCardNumberList){
			vTempVoCardNumberList.add(vCardNumVoCardNumber);

			try {
				if (vTempVoCardNumberList.size() >= CHUNK_LIMIT) {
					log.info("Saving list.....counter now = " + vCount);
					vVoCardRange.setCount(new Long(vCount).longValue());

					vVoCardRange = importRange(vTempVoCardNumberList,
							vVoCardRange);
					vTempVoCardNumberList = new ArrayList<VoCardNumber>();

				} else if (vVoCardNumberList.size() == vCount) {
					vVoCardRange.setImportState(IMPORT_DONE);
					vVoCardRange.setCount(new Long(vCount).longValue());
					vVoCardRange = importRange(vTempVoCardNumberList,
							vVoCardRange);
					log.info("Saving list finished.....counter ="
							+ vCount);

				}
			} catch (IkeaException e) {
				// Mark as failed
				vVoCardRange.setImportState(IMPORT_FAILED);
				vVoCardRange = importRange(new ArrayList<VoCardNumber>(), vVoCardRange);
				throw e;
			}
		}

	}

	/**
	 * @param pXmlParserImpl
	 */
	private void initiateXmlMultipleSingleLoad(XmlParserImpl pXmlParserImpl)
			throws IkeaException {

		VoMultipleSingleLoadInitial vVoMultipleSingleLoadInitial = pXmlParserImpl.getMVoMultipleSingleLoadInitial();
		vVoMultipleSingleLoadInitial.setCountryCode(mCountryCode);

		List<VoMultipleSingleLoadInitialCardAmount> vVoMultipleSingleLoadInitialCardAmountList =
				vVoMultipleSingleLoadInitial.getVoMultipleSingleLoadInitialCardAmountList();

		if (vVoMultipleSingleLoadInitialCardAmountList == null ||
				vVoMultipleSingleLoadInitialCardAmountList.size() == 0) {
			log.info("No multiple single load cards to load");
			return;
		}

		log.info("Multiple single load list length:" + vVoMultipleSingleLoadInitialCardAmountList.size());

		if (vVoMultipleSingleLoadInitialCardAmountList.size() > 1000) {
			throw new IkeaException("Max number of multiple single load cards exceeded");
		}

		initiateMultipleSingleLoad(vVoMultipleSingleLoadInitial);
	}

	/**
	 * @param vReader
	 */
	private boolean readFlatFile(BufferedReader vReader, File pFile,
			String pFileName, Checksum vChecksum) throws IOException,
			IkeaException {
		// Create card number list VO

		// Parse header
		String vHeader = vReader.readLine();

		// Sanity check
		if (vHeader == null || vHeader.length() == 0) {
			log.error(pFileName + " was empty");
		}

		// Extract name
		String vName = pFileName;
		String[] vSplit = vHeader.split("\t");
		if (vSplit.length >= 3) {
			vName = vSplit[2];
		}

		// Create card range VO


		// Parse card numbers
		int vRowCount = 0;

		try {
			String vLine = vReader.readLine();
			String vVerificationCode = "";
			String vCardNumberString = "";
			while (vLine != null) {

				vRowCount++;
				// Reset variables
				vVerificationCode = "";
				vCardNumberString = "";

				if (vLine.length() >= 24 || (vLine.indexOf(";") != -1)) {

					if (vLine.indexOf(";") != -1) {
						String[] vLineSplit = vLine.split(";");
						vCardNumberString = vLineSplit[0];
						vVerificationCode = vLineSplit[1];

						log.info("Line split: cardNumber ="
								+ vCardNumberString + " verfificationCode="
								+ vVerificationCode);

					} else {

						vCardNumberString = vLine.substring(5, 24);
					}
					if (vCardNumberString.matches(CARD_NUMBER_REGEXP)) {

						try {
							segregateCards(Integer.parseInt(vCardNumberString.substring(6, 7)), 
									vCardNumberString, vVerificationCode
									.trim());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							log.warn("Card number string '"
									+ vCardNumberString
									+ "' Not a Valid Card "
									+ CARD_NUMBER_REGEXP + ". Skipping row "
									+ vRowCount + " in file " + pFileName);
						}
					} else {
						log.warn("Card number string '"
								+ vCardNumberString
								+ "' does not match regexp "
								+ CARD_NUMBER_REGEXP + ". Skipping row "
								+ vRowCount + " in file " + pFileName);
					}

				} else {
					log.warn("Row " + vRowCount
							+ " is less than 24 chars. Skipping '" + vLine
							+ "' in file " + pFileName);
				}

				vLine = vReader.readLine();

			}


			sendForProcessing(pGiftCardList,pFile.getAbsolutePath(),vHeader,vName);
			sendForProcessing(pRefundCardList,pFile.getAbsolutePath(),vHeader,vName);
			sendForProcessing(pFamilyCardList,pFile.getAbsolutePath(),vHeader,vName);
			sendForProcessing(pVoucherCardList,pFile.getAbsolutePath(),vHeader,vName);
			sendForProcessing(pQpcCardList,pFile.getAbsolutePath(),vHeader,vName);
			sendForProcessing(pCampaignCardList,pFile.getAbsolutePath(),vHeader,vName);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

		/**
		 * 
		 * @param pVoCardNumberList
		 * @param pVoCardRange
		 * @return
		 * @throws IkeaException
		 * @throws SystemErrorException
		 */
		private VoCardRange importRange(List<VoCardNumber> pVoCardNumberList,
				VoCardRange pVoCardRange) throws IkeaException,
				SystemErrorException {

			// Create service
			BsImportCardRange vBsImportCardRange = new BsImportCardRange();

			// Set input VO
			vBsImportCardRange.setVoCardNumberList(pVoCardNumberList);
			vBsImportCardRange.setInputVoCardRange(pVoCardRange);

			// Execute service
			//BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
			bsExecuter.executeBs(vBsImportCardRange,"Originator");

			// Check for application errors
			List vApplErrors = vBsImportCardRange.getApplicationErrors();
			if (vApplErrors != null && !vApplErrors.isEmpty()) {
				throw new IkeaException(getClass().getName() + " " +
						"Application errors found in import. " + vApplErrors);
			}

			return vBsImportCardRange.getOutputVoCardRange();
		}

		/**
		 * Returns a random number between zero and pMax
		 * 
		 * @param pMax
		 *            The upper bound on the randiom number
		 * @return A random number between zero and pMax
		 */
		private static final long randomLong(long pMax) {
			return new Double(Math.random() * pMax).longValue();
		}


		/**
		 * 
		 * @param pVoMultipleSingleLoadInitial
		 * @return
		 * @throws IkeaException
		 */
		private VoMultipleSingleLoad initiateMultipleSingleLoad(
				VoMultipleSingleLoadInitial pVoMultipleSingleLoadInitial)
						throws IkeaException {

			// Create service
			BsInitiateMultipleSingleLoad vBsInitiateMultipleSingleLoad = new BsInitiateMultipleSingleLoad();

			// Set input VO
			vBsInitiateMultipleSingleLoad.setVoMultipleSingleLoadInitial(pVoMultipleSingleLoadInitial);

			// Execute service
			//BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
			bsExecuter.executeBs(vBsInitiateMultipleSingleLoad,"Originator");

			// Check for application errors
			List vApplErrors = vBsInitiateMultipleSingleLoad.getApplicationErrors();
			if (vApplErrors != null && !vApplErrors.isEmpty()) {
				throw new IkeaException(getClass().getName() + " " +
						"Application errors found in bs call. " + vApplErrors);
			}

			return vBsInitiateMultipleSingleLoad.getVoMultipleSingleLoad();
		}

		private void sendMail() {
			if (mMailAddress == null || mMailSmtpHost == null)
				return;

			if (mSuccessList.isEmpty() && mErrorList.isEmpty())
				return;

			boolean vSuccess = mErrorList.isEmpty();

			StringBuffer vMessage = new StringBuffer();
			if (mExceptionMsg != null)
				vMessage.append("The file process service failed with an exception.\n").append(mExceptionMsg);
			else if (vSuccess)
				vMessage.append("The file process service completed successfully");
			else
				vMessage.append("The file process service failed to process some files.");

			if (mSuccessList != null && mSuccessList.size() > 0) {
				vMessage.append("\n\nThe following files were processed:");
				for (String vStr : mSuccessList)
					vMessage.append("\n").append(vStr);
			}
			if (!vSuccess) {
				vMessage.append("\n\nThe following files failed while processing:");
				for (String vStr : mErrorList)
					vMessage.append("\n").append(vStr).append("\n");
			}

			Properties props = new Properties();
			props.put("mail.smtp.host", mMailSmtpHost);
			//props.put("mail.smtp.port", "465");

			Session mailSession = Session.getDefaultInstance(props);
			Message simpleMessage = new MimeMessage(mailSession);

			InternetAddress fromAddress = null;
			InternetAddress toAddress = null;
			try {
				fromAddress = new InternetAddress(mMailAddress);
				toAddress = new InternetAddress(mMailAddress);
			} catch (AddressException e) {
				e.printStackTrace();
			}

			try {
				simpleMessage.setFrom(fromAddress);
				simpleMessage.setRecipient(RecipientType.TO, toAddress);

				if (mExceptionMsg != null) {
					simpleMessage.setSubject("The file process service FAILED with an exception");
				} else if (vSuccess) {
					simpleMessage.setSubject("The file process service succeeded");
				} else {
					simpleMessage.setSubject("The file process service FAILED");
				}

				simpleMessage.setText(vMessage.toString());

				Transport.send(simpleMessage);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
		}

		private void segregateCards(int pCardType,String pCardSting,String pCvv) throws Exception
		{

			if(pCardType==CARD_TYPE_CONSTANT_GIFT)
			{
				pGiftCardList.put(pCardSting, pCvv);
			}
			else if(pCardType==CARD_TYPE_CONSTANT_REFUND)
			{
				pRefundCardList.put(pCardSting, pCvv);
			}
			else if(pCardType==CARD_TYPE_CONSTANT_FAMILY)
			{
				pFamilyCardList.put(pCardSting, pCvv);
			}
			else if(pCardType==CARD_TYPE_CONSTANT_VOUCHER)
			{
				pVoucherCardList.put(pCardSting, pCvv);
			}
			else if(pCardType==CARD_TYPE_CONSTANT_QPC)
			{
				pQpcCardList.put(pCardSting, pCvv);
			}
			else if(pCardType==CARD_TYPE_CONSTANT_CAMPAIGN)
			{
				pCampaignCardList.put(pCardSting, pCvv);
			}
			else{
				throw new Exception("Card type Undefined.");
			}
		}

		private void sendForProcessing(HashMap<String,String> pCardList,String fileName,String vHeader,String vName)
		{
			VoCardRange vVoCardRange = new VoCardRange();
			vVoCardRange.setRangeId(0);
			vVoCardRange.setCountryCode(mCountryCode);
			vVoCardRange.setFileName(fileName);
			vVoCardRange.setHeader(vHeader);
			vVoCardRange.setName(vName);

			List<VoCardNumber> mVoCardNumberList= new ArrayList<VoCardNumber>();
			int mTotalCards=0;
			try{
				for(String pCardString:pCardList.keySet())
				{
					VoCardNumber pVoCardNumber = new VoCardNumber();
					pVoCardNumber.setCardNumberString(pCardString);
					pVoCardNumber.setVerificationCode(pCardList.get(pCardString));
					mVoCardNumberList.add(pVoCardNumber);
					mTotalCards++;
					if(mVoCardNumberList.size()>=CHUNK_LIMIT)
					{
						vVoCardRange.setImportState(IMPORT_START);
						vVoCardRange.setCount(mTotalCards);
						vVoCardRange = importRange(mVoCardNumberList,vVoCardRange);
						mVoCardNumberList=new ArrayList<VoCardNumber>();
					}

				}
				if(mVoCardNumberList.size()<CHUNK_LIMIT && mTotalCards>0)
				{
					vVoCardRange.setImportState(IMPORT_DONE);
					vVoCardRange.setCount(mTotalCards);
					vVoCardRange = importRange(mVoCardNumberList,vVoCardRange);
				}
			}catch (IkeaException e) {
				// Mark as failed
				vVoCardRange.setImportState(IMPORT_FAILED);
				vVoCardRange = importRange(new ArrayList<VoCardNumber>(), vVoCardRange);
				throw e;
			}

		}

	}
