package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.File;
import java.util.ArrayList;


/**
 */
public interface DeleteProcessedFilesService extends Runnable {

	/**
	 */
	public void start(ArrayList<File> pProcessedDirectories, long pDeleteProcessedFilesInterval)
		throws IkeaException;

	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public void stop() throws IkeaException;
}
