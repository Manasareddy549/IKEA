package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;


/**
 * 
 * @author snug
 *
 * Implements the ServiceFactory interface and provides access
 * to instances of Service and ServiceRequest classes
 * 
 */
public class ServiceFactoryImpl implements ServiceFactory {

	/**
	 * Dependencies
	 */

	ScheduledExecutorService mScheduledExecutorService = null;

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.service.ServiceFactory#createService()
	 */
	public Service createService() {

		return new ServiceImpl(mScheduledExecutorService, this);
	}

	/**
	 * Constructs a ServiceFactoryImpl with the needed dependencies injected
	 */
	public ServiceFactoryImpl() {
		mScheduledExecutorService = Executors.newScheduledThreadPool(10);
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ServiceFactory#createExternalCardService()
	 */
	public ExternalCardService createExternalCardService() {
		return new ExternalCardServiceImpl(mScheduledExecutorService, this);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ServiceFactory#createExternalService()
	 */
	public ExternalService createExternalService() throws IkeaException {
		return new ExternalServiceImpl(mScheduledExecutorService);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ServiceFactory#createDeleteProcessedFilesService()
	 */
	public DeleteProcessedFilesService createDeleteProcessedFilesService() {
		return new DeleteProcessedFilesServiceImpl(mScheduledExecutorService);
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ServiceFactory#createDeleteProcessedFilesService()
	 */
	public TransferSaarecReportService createTransferSaarecReportService() {
		return new TransferSaarecReportServiceImpl(mScheduledExecutorService);
	}

	@Override
	public TransferExternalCardsTemp createTransferExternalCardsTemp() {
		// TODO Auto-generated method stub
		return new TransferExternalCardsTempImpl(mScheduledExecutorService, this);
	}
	
	public ChinaEncryptionService createChinaEncryptionService() {
		// TODO Auto-generated method stub
		return new ChinaEncryptionServiceImpl(mScheduledExecutorService);
	}
	
}
