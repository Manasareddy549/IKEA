/**
 * 
 */
package com.ikea.exchange.service;

import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.error.ApplicationError;

import com.ikea.ebccardpay1.client.bs.BsTransferSaarecReport;

/**
 * @author moans1
 *
 */
public class TransferSaarecReportServiceImpl implements
		TransferSaarecReportService {
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(TransferSaarecReportServiceImpl.class);
	
	private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	
	/**
	 * Dependencies
	 */
	
	private ScheduledExecutorService mScheduledExecutorService = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;
	/**
	 * The transfer interval
	 */
	long mTransferSarecReportInterval = 3600;

	/**
	 * Dependency injector constructor, used by factory and unit testing. Don't
	 * call the constructor directly, use
	 * ServiceFactorySingleton.getInstance().createTransferSaarecReportService(). The constructor is
	 * public so it can be used by the test cases.
	 */
	public TransferSaarecReportServiceImpl(ScheduledExecutorService pScheduledExecutorService) {

		mScheduledExecutorService = pScheduledExecutorService;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.TransferSaarecReportService#start(long)
	 */
	@Override
	public void start(long pTransferSarecReportInterval) throws IkeaException {
		// Check running flag
		if (mRunning) {
			throw new IkeaException("Service is already running");
		}

		mTransferSarecReportInterval = pTransferSarecReportInterval;

		// Info in the log
		mLog.info("Starting transfer service ");

		mScheduledExecutorService.scheduleAtFixedRate(this,
				1, mTransferSarecReportInterval, TimeUnit.SECONDS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;

	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.TransferSaarecReportService#stop()
	 */
	@Override
	public void stop() throws IkeaException {
		// Check running flag
		if (!mRunning) {
			throw new IkeaException("Service is not running");
		}

		// Set running flag to false to indicate that the service is stopped
		mRunning = false;

	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		BsTransferSaarecReport vBsTransferSaarecReport = new BsTransferSaarecReport();
		// Execute service
        //BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
        bsExecuter.executeBs(vBsTransferSaarecReport,"Originator");
        
     // Check for application errors
		List vApplErrors = vBsTransferSaarecReport.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			throw new IkeaException(getClass().getName() + " " +
					"Application errors found in transfer. " + vApplErrors);
		}


	}

}
