package com.ikea.exchange;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.exchange.configuration.Configuration;
import com.ikea.exchange.configuration.ConfigurationFactorySingleton;
import com.ikea.exchange.configuration.CountrySetUp;
import com.ikea.exchange.configuration.CountrySetUpImpl;
import com.ikea.exchange.service.ChinaEncryptionService;
import com.ikea.exchange.service.DeleteProcessedFilesService;
import com.ikea.exchange.service.ExternalCardService;
import com.ikea.exchange.service.ExternalService;
import com.ikea.exchange.service.Service;
import com.ikea.exchange.service.ServiceFactorySingleton;
import com.ikea.exchange.service.TransferExternalCardsTemp;
import com.ikea.exchange.service.TransferSaarecReportService;

/**
 */
public class IPayExchange {

	/**
	 * Log category for messages
	 */
	private final static Logger sLog = LoggerFactory.getLogger(IPayExchange.class);


	/**
	 * Reference to the configuration instance for retrieving port and timeout
	 */
	private Configuration mConfiguration = null;

	/**
	 * The iBridge service instance
	 */
	private Service mService = null;
	private ExternalCardService mExternalCardService = null;
	private ExternalService mExternalService = null;
	private DeleteProcessedFilesService mDeleteProcessedFilesService = null;
	private TransferSaarecReportService mTransferSaarecReportService = null;
	private TransferExternalCardsTemp mTransferExternalCardsTemp = null;
	private ChinaEncryptionService mChinaEncryptionService = null;

	private CountrySetUp mCountrySetUp = null;

	private File mScanningDirectory = null;
	private File mProcessedDirectory = null;
	private File mFailedDirectory = null;

	private File mExternalCardScanningDirectory = null;
	private File mExternalCardProcessedDirectory = null;
	private File mExternalCardFailedDirectory = null;

	private File mExternalCardTempScanningDirectory = null;
	private File mExternalCardTempProcessedDirectory = null;
	private File mExternalCardTempFailedDirectory = null;
	private File mExternalCardTempLogDirectory = null;
	private File mExternalCardTempVerificationDirectory=null;
	private File mSFTPCardProcessedDirectory=null;

	private String mFromMailAddress = null;
	private String mMailSmtpHost = null;
	
	private int mChinaPort=9104;

	private String pkString="";


	private String mSftpServerurl;


	private String mSftpServerUsername;


	private String mSftpServerpassword;


	private int mSftpServerPort;


	private String mIpayDbUrl;


	private String mIPayDbUser;


	private String mIPayDbPassword;


	private File mSFTPCardScanningDirectory;


	private File mSFTPCardFailedDirectory;


	private String mSftpPrivateKey;


	private String mToMailAddress;


	private String mCCMailAddress;

	/**
	 * Dependency injector constructor, used by factory and unit testing
	 */
	public IPayExchange(
			Configuration pConfiguration,
			Service pService,
			ExternalCardService pExternalCardService,
			ExternalService pExternalService,
			DeleteProcessedFilesService pDeleteProcessedFilesService,
			TransferSaarecReportService pTransferSaarecReportService,
			TransferExternalCardsTemp pTransferExternalCardsTemp,
			ChinaEncryptionService pChinaEncryptionService) {

		mConfiguration = pConfiguration;
		mService = pService;
		mExternalCardService = pExternalCardService;
		mExternalService = pExternalService;
		mDeleteProcessedFilesService = pDeleteProcessedFilesService;
		mTransferSaarecReportService = pTransferSaarecReportService;
		mTransferExternalCardsTemp=pTransferExternalCardsTemp;
		mChinaEncryptionService=pChinaEncryptionService;

	}

	/**
	 * Fetches configurations, validates and starts the services
	 * @throws IOException 
	 */
	public void start() throws IkeaException, IOException {

		sLog.info("Starting...");

		// Fetch the configuration information
		mScanningDirectory = mConfiguration.getScanningDirectory();
		mProcessedDirectory = mConfiguration.getProcessedDirectory();
		mFailedDirectory = mConfiguration.getFailedDirectory();
		long vScanningInterval = mConfiguration.getScanningInterval();

		// External Card configurations information
		mExternalCardScanningDirectory =
				mConfiguration.getExternalCardScanningDirectory();
		mExternalCardProcessedDirectory =
				mConfiguration.getExternalCardProcessedDirectory();
		mExternalCardFailedDirectory =
				mConfiguration.getExternalCardFailedDirectory();
		long vExternalCardScanningInterval =
				mConfiguration.getExternalCardScanningInterval();


		//External Temp Cards
		mExternalCardTempScanningDirectory =
				mConfiguration.getExternalCardTempScanningDirectory();
		mExternalCardTempVerificationDirectory =
				mConfiguration.getExternalCardTempVerificationDirectory();
		mExternalCardTempLogDirectory =
				mConfiguration.getExternalCardTempLogDirectory();
		mExternalCardTempProcessedDirectory =
				mConfiguration.getExternalCardTempProcessedDirectory();
		mExternalCardTempFailedDirectory =
				mConfiguration.getExternalCardTempFailedDirectory();
		long vExternalCardTempScanningInterval =
				mConfiguration.getExternalCardTempScanningInterval();


		long vTransferSarecReportInterval = mConfiguration.getTransferSarecReportInterval();

		// Configuration information for external exchange files
		long vExternalScanningInterval = mConfiguration.getExternalScanningInterval();
		long vDeleteProcessedFilesInterval = mConfiguration.getDeleteProcessedFilesInterval();

		mFromMailAddress = mConfiguration.getFromMailAddress();
		
		mToMailAddress = mConfiguration.getToMailAddress();
		
		mMailSmtpHost = mConfiguration.getMailSmtpHost();
		
		mCCMailAddress = mConfiguration.getCCMailAddress();
		
		mChinaPort=mConfiguration.getChinaEncryptionPort();
		pkString=mConfiguration.getChinaEncryptionPk();
		
		mSftpServerurl=mConfiguration.getSftpServerUrl();
		
		mSftpServerUsername=mConfiguration.getSftpServerUsername();
		
		mSftpServerpassword=mConfiguration.getSftpServerPassword();
		
		mSftpServerPort=mConfiguration.getSftpServerPort();
		
		mSftpPrivateKey=mConfiguration.getSftpPrivateKey();
		
		mIpayDbUrl=mConfiguration.getIPayDbUrl();
		
		mIPayDbUser=mConfiguration.getIPayDbUser();
		
		mIPayDbPassword=mConfiguration.getIpayDbPassword();
		
		mSFTPCardScanningDirectory=mConfiguration.getSftpDirectory();
		
		mSFTPCardProcessedDirectory=mConfiguration.getSftpProcessedDirectory();
		
		mSFTPCardFailedDirectory=mConfiguration.getSftpFailedDirectory();
		

		sLog.info(
				"ExternalCardScanningDirectory set: "
						+ mExternalCardScanningDirectory.getName());

		mCountrySetUp =
				new CountrySetUpImpl(
						mScanningDirectory,
						mProcessedDirectory,
						mFailedDirectory);

		sLog.info("Version: " + mConfiguration.getVersion());

		// Schedule to update once every hour.
		long vInterval = 60 * 60;
		Executors.newScheduledThreadPool(1).
		scheduleAtFixedRate(new Runnable() {
			public void run() {
				mCountrySetUp.updateCountries();
			}
		}, 0, vInterval, TimeUnit.SECONDS);

		 //For MDB Card Loading
		mService.start(
				mScanningDirectory,
				mProcessedDirectory,
				mFailedDirectory,
				null,
				vScanningInterval,
				mFromMailAddress,
				mMailSmtpHost);

		// Start ExternalCard service
		mExternalCardService.start(
				mExternalCardScanningDirectory,
				mExternalCardProcessedDirectory,
				mExternalCardFailedDirectory,
				vExternalCardScanningInterval);

		// Start External service
		mExternalService.start(mSftpServerurl,mSftpServerUsername,mSftpServerpassword,mSftpServerPort,mSftpPrivateKey,
			mSFTPCardScanningDirectory,mSFTPCardProcessedDirectory,mSFTPCardFailedDirectory,
			mIpayDbUrl,mIPayDbUser,mIPayDbPassword,mFromMailAddress,mToMailAddress,mCCMailAddress,mMailSmtpHost,vExternalScanningInterval);

		 //Start DeleteProcessedFiles service
		ArrayList<File> fileList= new ArrayList<File>();
		fileList.add(mProcessedDirectory);
		fileList.add(mExternalCardTempProcessedDirectory);
		fileList.add(mExternalCardProcessedDirectory);
		fileList.add(mSFTPCardProcessedDirectory);
		mDeleteProcessedFilesService.start(fileList,	vDeleteProcessedFilesInterval);

		// Start TransferSaarecReport service
		mTransferSaarecReportService.start(vTransferSarecReportInterval);

		mTransferExternalCardsTemp.start(
				mExternalCardTempScanningDirectory, 
				mExternalCardTempVerificationDirectory, 
				mExternalCardTempProcessedDirectory, 
				mExternalCardTempFailedDirectory, 
				mExternalCardTempLogDirectory, 
				vExternalCardTempScanningInterval);

		mChinaEncryptionService.start(mChinaPort, pkString);
	}

	/**
	 * @throws IkeaException
	 */
	public void stop() throws IkeaException {

		sLog.info("Stopping...");
	}

	/**
	 * iPayExchange entry point, creates the iPayExchange instance and starts iPay Exchange
	 * 
	 * @param args Command line arguments
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IkeaException, IOException {
		// Create iPay exchange instance by providing dependencies from the factory
		IPayExchange vIPayExchange =
				new IPayExchange(
						ConfigurationFactorySingleton.getInstance().getConfiguration(),
						ServiceFactorySingleton.getInstance().createService(),
						ServiceFactorySingleton.getInstance().createExternalCardService(),
						ServiceFactorySingleton.getInstance().createExternalService(),
						ServiceFactorySingleton.getInstance().createDeleteProcessedFilesService(),
						ServiceFactorySingleton.getInstance().createTransferSaarecReportService(),
						ServiceFactorySingleton.getInstance().createTransferExternalCardsTemp(),
						ServiceFactorySingleton.getInstance().createChinaEncryptionService());

		// Start service
		vIPayExchange.start();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		sLog.info("Ending iPayExchange.");
		super.finalize();
	}

}
