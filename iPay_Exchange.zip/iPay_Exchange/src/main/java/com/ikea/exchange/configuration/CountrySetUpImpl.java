package com.ikea.exchange.configuration;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.client.bs.BsRetrieveBaseData;
import com.ikea.ebccardpay1.client.vo.VoBusinessUnit;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.services.BsExecuterFactory;
import com.ikea.ebcframework.exception.IkeaException;

public class CountrySetUpImpl implements CountrySetUp {

	/**
	 * Log category for messages
	 */
	private final static Logger log = LoggerFactory.getLogger(CountrySetUpImpl.class);

	private File mScanningDirectory = null;
	private File mProcessedDirectory = null;
	private File mFailedDirectory = null;

	private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();

	public CountrySetUpImpl(
			File pScanningDirectory,
			File pProcessedDirectory,
			File pFailedDirectory) {

		mScanningDirectory = pScanningDirectory;
		mProcessedDirectory = pProcessedDirectory;
		mFailedDirectory = pFailedDirectory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.CalypsoCountries#updateCountries()
	 */
	public void updateCountries() {

		log.debug("Updating country folders...");

		try {
			String[] vCountryCodes = getCountryCodes();

			// Update failed and processed first so we do not come to a situation where the scanning start
			// befor we have created processed or fail diretcory. 
			createCountryCodeFolders(mFailedDirectory, vCountryCodes);
			createCountryCodeFolders(mProcessedDirectory, vCountryCodes);
			createCountryCodeFolders(mScanningDirectory, vCountryCodes);
		} catch (IkeaException e) {
			log.error(e.getLocalizedMessage());
		}
		log.debug("Updating country folders done.");
	}

	/**
	 * @param pParent
	 * @throws IkeaException
	 */
	private void createCountryCodeFolders(
			File pParent,
			String[] pvCountryCodes)
					throws IkeaException {

		File[] vFiles = pParent.listFiles();

		for (String vCountryCode : pvCountryCodes) {
			boolean vFound = false;

			for (int j = 0; j < vFiles.length; j++) {
				String vFileName = vFiles[j].getName();

				if (vCountryCode != null
						&& vCountryCode.equalsIgnoreCase(vFileName)) {
					vFound = true;
				}
			}

			if (!vFound) {
				File vCountryFile = new File(pParent, vCountryCode);
				vCountryFile.mkdir();
				log.info(
						"Created directory "
								+ vCountryCode
								+ " in parent "
								+ pParent.getAbsolutePath());
			}
		}
	}

	/**
	 * Retirves all countries for the known IKEA stores
	 * 
	 * @return
	 * @throws IkeaException
	 */
	private String[] getCountryCodes() throws IkeaException {

		String[] vCountryCodesStringArray = null;

		List vCountryCodes = new LinkedList();

		// Retrieve business unit list
		List<VoBusinessUnit> vVoBusinessUnitList = retrieveBusinessUnits();

		// Scan business units
		for (VoBusinessUnit vVoBusinessUnit : vVoBusinessUnitList){
			String vCountryCode = vVoBusinessUnit.getCountryCode();

			// Add country if not already there
			if (!vCountryCodes.contains(vCountryCode)) {
				vCountryCodes.add(vCountryCode);
			}
		}

		// Convert to array
		vCountryCodesStringArray =
				(String[]) vCountryCodes.toArray(new String[0]);

		return vCountryCodesStringArray;
	}

	/**
	 * Calls retirve base data in order to get a complete list of stores
	 * 
	 * @return
	 * @throws IkeaException
	 */
	private List<VoBusinessUnit> retrieveBusinessUnits() throws IkeaException {

		// Create service
		BsRetrieveBaseData vBsRetrieveBaseData = new BsRetrieveBaseData();

		// Execute service
		//BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
		bsExecuter.executeBs(vBsRetrieveBaseData,"Originator");

		// Check for application errors
		List<ApplicationError> vApplErrors = vBsRetrieveBaseData.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			for(ApplicationError error:vApplErrors)
			{
				log.error(error.getMessage());
				throw new IkeaException(
						"Application errors found in base data retrieve");
			}
		}

		return vBsRetrieveBaseData.getVoBusinessUnitList();
	}

}
