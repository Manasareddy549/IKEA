package com.ikea.exchange.service;


import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author snug
 *
 * Interface that provides access to service related instances such as
 * the Service and ServiceRequest classes
 */
public interface ServiceFactory {

	/**
	 * Creates a new Service instance. Each service will be provided with a
	 * new ExecutorService instance.
	 * 
	 * @return The new Service
	 */
	public abstract Service createService();

	/**
	 * 
	 * @return The new ExternalCardService
	 */
	public abstract ExternalCardService createExternalCardService();
	
	/**
	 * 
	 * @return The new ExternalService
	 */
	public abstract ExternalService createExternalService() throws IkeaException;
	
	/**
	 * 
	 * @return The new DeleteProcessedFilesService
	 */
	public abstract DeleteProcessedFilesService createDeleteProcessedFilesService();
	
	/**
	 * 
	 * @return The new TransferSaarecReportService
	 */
	public abstract TransferSaarecReportService createTransferSaarecReportService();
	
	public abstract TransferExternalCardsTemp createTransferExternalCardsTemp();

	public abstract ChinaEncryptionService createChinaEncryptionService();
	
}
