package com.ikea.exchange.configuration;

/**
 * @author snug
 *
 * Provides access to the <code>Configuration</code> instance
 * 
 */
public interface ConfigurationFactory {

	/**
	 * Get the Configuration instance
	 * @return the same instance every time.
	 */
	public abstract Configuration getConfiguration();

}
