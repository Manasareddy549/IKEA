/*
 * Created on 2007-aug-16
 *
 *
 */
package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.File;

/**
 * @author dalq
 *
 *
 */
public interface ExternalCardService extends Runnable{


	/**
	 * 
	 */
	public void start(
		File pExternalCardScanningDirectory,
		File pExternalCardProcessedDirectory,
		File pExternalCardFailedDirectory,
		long pExternalCardScanningInterval)
		throws IkeaException;
		

	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public void stop() throws IkeaException;



}
