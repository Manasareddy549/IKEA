/*
 * Created on 2008-apr-03
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.exchange.service;

import java.io.Reader;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * @author DALQ
 *
 */
public interface XmlParser {

	//Header tags
	public static final String ELEMENT_CAMPAIGN_INFORMATION = "CampaignInformation";
	public static final String CAMPAIGN_ID = "CampaignId";
	public static final String PROJECT_ID = "ProjectId";
	public static final String PROJECT_NAME = "ProjectName";
	public static final String PROJECT_CREATED = "ProjectCreated";

	// Customer tags
	public static final String ELEMENT_CUSTOMER_LIST = "CustomerList";
	public static final String ELEMENT_CUSTOMER = "Customer";
	public static final String FAMILY_CARD_NUMBER = "FamilyCardNumber";

	// Single load tags
	public static final String ELEMENT_MULTIPLE_SINGLE_LOAD = "MultipleSingleLoad";
	public static final String ELEMENT_CARD_AMOUNT_LIST = "CardAmountList";
	public static final String ELEMENT_CARD_AMOUNT = "CardAmount";
	public static final String AMOUNT = "Amount";
	public static final String CARD_NUMBER = "CardNumber";
	public static final String BU_TYPE = "BuType";
	public static final String BU_CODE = "BuCode";
	public static final String CURRENCY_CODE = "CurrencyCode";
	public static final String SINGLE_LOAD_NAME = "SingleLoadName";

	public abstract void readXmlFile(Reader pReader);

	public abstract void startElement(
		String uri,
		String localName,
		String qName,
		Attributes attributes)
		throws SAXException;

	public abstract void characters(char[] ch, int start, int length)
		throws SAXException;

	public abstract void endElement(String uri, String localName, String qName)
		throws SAXException;

}
