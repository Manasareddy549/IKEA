package com.ikea.exchange.configuration;


import com.ikea.ebcframework.exception.IkeaException;

/**
 * @author snug
 *
 * Implements the ConfigurationFactory interface and provides access to
 * the Configuration instance
 * 
 */
public class ConfigurationFactoryImpl implements ConfigurationFactory {

	protected final Configuration mConfiguration;

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.ConfigurationFactory#getConfiguration()
	 */
	public Configuration getConfiguration()
	{
		return mConfiguration;
	}

	/**
	 * Constructs a ConfigurationFactoryImpl and initializes a Configuration
	 * instance
	 * 
	 * @throws IkeaException
	 */
	public ConfigurationFactoryImpl() throws IkeaException {

		// Create default dependencies
		mConfiguration = new ConfigurationImpl();
	}
}
