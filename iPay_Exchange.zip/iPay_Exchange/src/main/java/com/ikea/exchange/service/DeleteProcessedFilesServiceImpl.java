package com.ikea.exchange.service;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 * @author mjdt
 * 
 * Implements the DeleteProcessedFilesService interface
 * 
 */
public class DeleteProcessedFilesServiceImpl implements DeleteProcessedFilesService {
	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(DeleteProcessedFilesServiceImpl.class);

	/**
	 * Dependencies
	 */
	private ScheduledExecutorService mScheduledExecutorService = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	/**
	 * The processed directory
	 */
	ArrayList<File> mProcessedDirectories = null;

	/**
	 * The scanning interval
	 */
	long mDeleteProcessedFilesInterval = 120;

	/**
	 * Dependency injector constructor, used by factory and unit testing. Don't
	 * call the constructor directly, use
	 * ServiceFactorySingleton.getInstance().createDeleteProcessedFilesService(). The constructor is
	 * public so it can be used by the test cases.
	 */
	public DeleteProcessedFilesServiceImpl(ScheduledExecutorService pScheduledExecutorService) {

		mScheduledExecutorService = pScheduledExecutorService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.exchange.service.DeleteProcessedFilesService#start(java.io.File, long)
	 */
	public void start(ArrayList<File> pProcessedDirectories, long pDeleteProcessedFilesInterval)
			throws IkeaException {

		// Check running flag
		if (mRunning) {
			throw new IkeaException("Service is already running");
		}

		mProcessedDirectories = pProcessedDirectories;
		mDeleteProcessedFilesInterval = pDeleteProcessedFilesInterval;

		// Info in the log
		mLog.info("Starting delete service on Processed directories" );

		mScheduledExecutorService.scheduleAtFixedRate(this,
				mDeleteProcessedFilesInterval, mDeleteProcessedFilesInterval, TimeUnit.SECONDS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ikea.exchange.service.DeleteProcessedFilesService#stop()
	 */
	public void stop() throws IkeaException {

		// Check running flag
		if (!mRunning) {
			throw new IkeaException("Service is not running");
		}

		// Set running flag to false to indicate that the service is stopped
		mRunning = false;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		try {
			for(File mProcessedDirectory:mProcessedDirectories)
			{
				// Info in the log
				mLog.debug("Deleting files in " + mProcessedDirectory.getName());

				// Try processing files

				File[] vFileList = mProcessedDirectory.listFiles();

				for (int i = 0; i < vFileList.length; i++) {
					File vCurrent = vFileList[i];

					if (vCurrent.isDirectory()) {
						File[] vCountryFileList = vCurrent.listFiles();

						for (int j = 0; j < vCountryFileList.length; j++) {
							mLog.debug("Deleting file " + vCountryFileList[j].getAbsolutePath());

							try {
								vCountryFileList[j].delete();
							} catch (Exception ex) {
								mLog.error("File " + vCountryFileList[j].getAbsolutePath() + " couldn't be deleted", ex);
							}
						}
					}
				}
			} 
		}catch (Exception e) {
			// Exceptions needs to be logged
			mLog.error(e.getMessage());
		}
	}
}
