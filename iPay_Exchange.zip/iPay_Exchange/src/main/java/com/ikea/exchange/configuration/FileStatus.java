package com.ikea.exchange.configuration;

import java.util.ArrayList;

public class FileStatus {
	
	private String mFileName;
	
	private String mCardBatchType;
	
	private String mCountry;
	
	private String mCardCount;
	
	private boolean mFileUploadStatus;
	
	private ArrayList<String> mErrorList;

	public String getFileName() {
		return mFileName;
	}

	public void setFileName(String mFileName) {
		this.mFileName = mFileName;
	}

	public String getCardBatchType() {
		return mCardBatchType;
	}

	public void setCardBatchType(String mCardBatchType) {
		this.mCardBatchType = mCardBatchType;
	}

	public String getCountry() {
		return mCountry;
	}

	public void setCountry(String mCountry) {
		this.mCountry = mCountry;
	}

	public String getCardCount() {
		return mCardCount;
	}

	public void setCardCount(String mCardCount) {
		this.mCardCount = mCardCount;
	}

	public boolean isFileUploadStatus() {
		return mFileUploadStatus;
	}

	public void setFileUploadStatus(boolean mFileUploadStatus) {
		this.mFileUploadStatus = mFileUploadStatus;
	}

	public ArrayList<String> getErrorMessage() {
		return mErrorList;
	}

	public void setErrorMessage(ArrayList<String> mErrorList) {
		this.mErrorList = mErrorList;
	}

}
