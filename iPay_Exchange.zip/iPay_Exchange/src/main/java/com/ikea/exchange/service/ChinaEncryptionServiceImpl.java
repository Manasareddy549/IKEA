package com.ikea.exchange.service;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebcframework.exception.IkeaException;

public class ChinaEncryptionServiceImpl implements ChinaEncryptionService{

	private final static Logger mLog = LoggerFactory.getLogger(ChinaEncryptionServiceImpl.class);

	private ScheduledExecutorService mScheduledExecutorService = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	private ServerSocket mServerSocket = null;

	private int mPortNumber;

	private String pkString;

	public ChinaEncryptionServiceImpl(ScheduledExecutorService pScheduledExecutorService) {
		// TODO Auto-generated constructor stub
		mScheduledExecutorService = pScheduledExecutorService;
	}

	@Override
	public void run() {
		Socket s = null;
		try
		{
			mServerSocket = new ServerSocket(mPortNumber);
			//mServerSocket.setSoTimeout(mTimeout);
			while (true) 
			{
				
				// socket object to receive incoming client requests
				s = mServerSocket.accept();

				mLog.info("A new client is connected : " + s);

				// obtaining input and out streams
				DataInputStream dis = new DataInputStream(s.getInputStream());
				DataOutputStream dos = new DataOutputStream(s.getOutputStream());

				mLog.info("Assigning new thread for this client");

				// create a new thread object
				Thread t = new ChinaEncryptionServiceHandler(s,pkString, dis, dos);

				// Invoking the start() method
				t.start();


			}
		}
		catch (Exception e){
			try {
				s.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				mLog.error("Error Details",e1);
				stop();
			}
			mLog.error("Error Details",e);
			stop();
		}
	}



	@Override
	public void start(int pPortNumber, String pkString) throws IkeaException, IOException {
		// TODO Auto-generated method stub

		mPortNumber=pPortNumber;
		this.pkString=pkString;

		// Check running flag
		if (mRunning) {
			throw new IkeaException("Service is already running");
		}

		mScheduledExecutorService.scheduleAtFixedRate(this,0, 365, TimeUnit.DAYS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;

	}

	@Override
	public void stop() throws IkeaException {

		// TODO Auto-generated method stub
		if (!mRunning) {
			throw new IkeaException("Service is not running");
		}

		try {

			// Set running flag to false to indicate that the service is stopped
			mRunning = false;

			// Close incoming socket
			mServerSocket.close();

			// Wait for the service thread to stop executing

		} catch (Exception e) {
			throw new IkeaException(e);
		}

	}
}

