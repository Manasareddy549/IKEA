package com.ikea.exchange.configuration;


import com.ikea.ebcframework.exception.IkeaException;

/*
 * 
 * @author mjdt
 *
 * Interface for providing configuration information for remove servers
 * This is typically read from a configuration file.
 * 
 */
public interface RemoteConfiguration {

	/**
	 * Specifies the remote ftp server address
	 * 
	 * @return The remote ftp server address
	 */
	public abstract String getServer();

	/**
	 * Specifies the remote ftp port (if other than default ftp port)
	 * 
	 * @return The remote ftp server address
	 */
	public abstract int getPort();

	/**
	 * Specifies the ftp user
	 * 
	 * @return The ftp user
	 */

	public abstract String getUser();

	/**
	 * Specifies the ftp password
	 * 
	 * @return The ftp password
	 */

	public abstract String getPwd();

	/**
	 * Specifies the sub path on the ftp server
	 * 
	 * @return The sub path
	 */

	public abstract String getSubPath();

	/**
	 * Specifies the private key file used against the ftp server
	 * 
	 * @return The private key file
	 */

	public abstract String getPrivateKeyFile();

	/**
	 * Specifies the country
	 * 
	 * @return The country
	 */

	public abstract String getCountry();
	
	/**
	 * A call to reload signals the the settings should be read again.
	 * @throws IkeaException When a error occurs
	 */
	public abstract void reload() throws IkeaException;
}
