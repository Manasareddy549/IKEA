package com.ikea.exchange.configuration;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ikea.ebcframework.exception.IkeaException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author snug
 *
 * Implements the Configuration interface an provides configuration information
 * for the iPay exchange service by reading a property file called exchange.properties
 * located in the class path or at the location of the system property exchange.configuration
 * that can be set to an URL by starting the Java VM with -Dexchange.configuration=file:<somepath>
 * 
 */
public class ConfigurationImpl implements Configuration {

	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(ConfigurationImpl.class);

	/**
	 * Keys to the property file
	 */
	static final private String SCANNING_DIRECTORY = "scanning.directory";
	static final private String PROCESSED_DIRECTORY = "processed.directory";
	static final private String FAILED_DIRECTORY = "failed.directory";
	static final private String SCANNING_INTERVAL = "scanning.interval";
	static final private String EXTERNAL_SCANNING_INTERVAL = "external.SFTPServer.scanning.interval";
	static final private String DELETE_PROCESSED_FILES_INTERVAL = "delete.processed.files.interval";

	static final private String EXTERNAL_CARD_SCANNING_DIRECTORY =
			"scanning.externalSourceSystem.card.directory";
	static final private String EXTERNAL_PROCESSED_DIRECTORY =
			"processed.externalSourceSystem.card.directory";
	static final private String EXTERNAL_FAILED_DIRECTORY =
			"failed.externalSourceSystem.card.directory";
	static final private String EXTERNAL_CARD_SCANNING_INTERVAL =
			"scanning.externalSourceSystem.card.interval";

	static final private String EXTERNAL_CARD_TEMP_SCANNING_DIRECTORY =
			"scanning.externaltemp.card.directory";
	static final private String EXTERNAL_CARD_TEMP_PROCESSED_DIRECTORY =
			"processed.externaltemp.card.directory";
	static final private String EXTERNAL_CARD_TEMP_FAILED_DIRECTORY =
			"failed.externaltemp.card.directory";
	static final private String EXTERNAL_CARD_TEMP_SCANNING_INTERVAL =
			"external.temp.scanning.interval";
	static final private String EXTERNAL_CARD_TEMP_VERIFICATION_DIRECTORY =
			"verification.externaltemp.card.directory";
	static final private String EXTERNAL_CARD_TEMP_LOG_DIRECTORY =
			"log.externaltemp.card.directory";

	static final private String EXTERNAL_CARD_TEMP_REMOTE_DIRECTORY =
			"remote.file.serverlocation";

	static final private String CHINA_ENCRYPTION_PORT ="china.encryption.port";

	static final private String CHINA_ENCRYPTION_ENVIRONMENT =
			"china.encryption.environment";

	static final private String CHINA_ENCRYPTION_PK_TEST =
			"china.encryption.pk.TEST";

	static final private String CHINA_ENCRYPTION_PK_PROD =
			"china.encryption.pk.PROD";

	static final private String VERSION = "version";

	static final private String MAIL_ADDRESS_FROM = "mail.address.from";
	static final private String MAIL_SMTP_HOST = "mail.smtp.host";
	static final private String MAIL_ADDRESS_TO = "mail.address.to";
	static final private String MAIL_ADDRESS_CC = "mail.address.cc";

	static final private String TRANSFER_SAREC_REPORT_INTERVAL =
			"transfer.sarec.report.interval";



	static final private String SFTP_SERVER_URL =
			"sftp.serverUrl";
	static final private String SFTP_SERVER_USERNAME =
			"sftp.username";
	static final private String SFTP_SERVER_PASSWORD =
			"sftp.password";
	static final private String SFTP_SERVER_PORT =
			"sftp.port";

	static final private String IPAY_DB_URL =
			"iPay.db.url";
	static final private String IPAY_DB_USERNAME =
			"iPay.db.username";
	static final private String IPAY_DB_PASSWORD =
			"iPay.db.password";


	static final private String EXTERNAL_SFTP_SERVER_LOCAL_DIRECTORY =
			"external.SFTPServer.local.card.directory";
	static final private String EXTERNAL_SFTP_SERVER_PROCESSED_DIRECTORY =
			"external.SFTPServer.local.card.directory.processed";
	static final private String EXTERNAL_SFTP_SERVER_PROCESSED_FAILED =
			"external.SFTPServer.local.card.directory.failed";





	/**
	 * The current settings value
	 */
	private File mScanningDirectory = null;
	private File mProcessedDirectory = null;
	private File mFailedDirectory = null;
	private int mScanningInterval = 120;
	private int mExternalScanningInterval = 240;
	private int mDeleteProcessedFilesInterval = 240;
	private String mVersion = null;
	private String mMailFromAddress = null;
	private String mMailToAddress = null;
	private String mMailCCAddress = null;
	private String mMailSmtpHost = null;
	private String mDirectoryRoot = null;

	// Params for External Cards file
	private File mExternalCardScanningDirectory = null;
	private File mExternalCardProcessedDirectory = null;
	private File mExternalCardFailedDirectory = null;
	private int mExternalCardScanningInterval = 120;

	private File mExternalCardTempScanningDirectory = null;
	private File mExternalCardTempVerificationDirectory = null;
	private File mExternalCardTempProcessedDirectory = null;
	private File mExternalCardTempFailedDirectory = null;
	private File mExternalCardTempLogDirectory = null;
	private int mExternalCardTempScanningInterval = 120;

	private int mChinaPort=9104;

	private String mChinaPk="";


	private String mSftpServerUrl=null;
	private String mSftpServerUsername=null;
	private String mSftpServerPassword=null;
	private String mPrivateKey=null;
	private int mSftpServerPort=0;
	private String iPayDbUrl=null;
	private String iPayDbUser=null;
	private String ipayDbPassword=null;
	private File mSftpDirectory=null;
	private File mSftpProcessedDirectory=null;
	private File mSftpFailedDirectory=null;



	//Param for Sarec+ Report Tranfer
	private int mTransferSarecReportInterval = 3600;


	/**
	 * Constructor that calls reload. This constructor should not be called directly.
	 * An instance of Configuation can be found with ConfigurationFactorySingleton.getInstance().getConfiguration().
	 * The constructor is public so that the test cases can use it.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public ConfigurationImpl() throws IkeaException {
		reload();
	}

	/**
	 * This method will return the version of iBridge
	 */
	public String getVersion() {
		if (mVersion == null || mVersion.length() == 0) {
			mVersion = "not set";
		}
		return mVersion;
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#reload()
	 */
	public void reload() throws IkeaException {

		// Load configuration properties
		Properties vConfiguration =
				loadProperties(
						"exchange.configuration",
						"exchange.properties",
						false);

		mDirectoryRoot = System.getenv("ALLUSERSPROFILE");

		setScanningDirectory(mDirectoryRoot + vConfiguration.getProperty(SCANNING_DIRECTORY));
		setProcessedDirectory(mDirectoryRoot + vConfiguration.getProperty(PROCESSED_DIRECTORY));
		setFailedDirectory(mDirectoryRoot + vConfiguration.getProperty(FAILED_DIRECTORY));
		setScanningInterval(vConfiguration.getProperty(SCANNING_INTERVAL));
		setExternalScanningInterval(vConfiguration.getProperty(EXTERNAL_SCANNING_INTERVAL));
		setDeleteProcessedFilesInterval(vConfiguration.getProperty(DELETE_PROCESSED_FILES_INTERVAL));

		setExternalCardScanningDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_SCANNING_DIRECTORY));
		setExternalCardProcessedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_PROCESSED_DIRECTORY));
		setExternalCardFailedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_FAILED_DIRECTORY));
		setExternalCardScanningInterval(vConfiguration.getProperty(EXTERNAL_CARD_SCANNING_INTERVAL));


		setExternalTempCardScanningDirectory( mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_TEMP_SCANNING_DIRECTORY));
		setExternalTempCardVerificationDirectory( mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_TEMP_VERIFICATION_DIRECTORY));
		setExternalTempCardLogDirectory( mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_TEMP_LOG_DIRECTORY));
		setExternalTempCardProcessedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_TEMP_PROCESSED_DIRECTORY));
		setExternalTempCardFailedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_CARD_TEMP_FAILED_DIRECTORY));
		setExternalTempCardScanningInterval(vConfiguration.getProperty(EXTERNAL_CARD_TEMP_SCANNING_INTERVAL));

		setSftpServerUrl(vConfiguration.getProperty(SFTP_SERVER_URL));
		setSftpServerUsername(vConfiguration.getProperty(SFTP_SERVER_USERNAME));
		setSftpServerPassword(vConfiguration.getProperty(SFTP_SERVER_PASSWORD));
		setSftpServerPort(vConfiguration.getProperty(SFTP_SERVER_PORT));
		setSftpPrivateKey("private.key");

		setIPayDbUrl(vConfiguration.getProperty(IPAY_DB_URL));
		setIPayDbUser(vConfiguration.getProperty(IPAY_DB_USERNAME));
		setIpayDbPassword(vConfiguration.getProperty(IPAY_DB_PASSWORD));

		setSftpDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_SFTP_SERVER_LOCAL_DIRECTORY));
		setSftpProcessedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_SFTP_SERVER_PROCESSED_DIRECTORY));
		setSftpFailedDirectory(mDirectoryRoot + vConfiguration.getProperty(EXTERNAL_SFTP_SERVER_PROCESSED_FAILED));

		setFromMailAddress(vConfiguration.getProperty(MAIL_ADDRESS_FROM));
		setMailSmtpHost(vConfiguration.getProperty(MAIL_SMTP_HOST));
		setToMailAddress(vConfiguration.getProperty(MAIL_ADDRESS_TO));
		setCCMailAddress(vConfiguration.getProperty(MAIL_ADDRESS_CC));

		setChinaPort(vConfiguration.getProperty(CHINA_ENCRYPTION_PORT));

		setChinaPk(vConfiguration.getProperty(CHINA_ENCRYPTION_ENVIRONMENT),
				vConfiguration.getProperty(CHINA_ENCRYPTION_PK_TEST),
				vConfiguration.getProperty(CHINA_ENCRYPTION_PK_PROD));

		setTransferSarecReportInterval(vConfiguration.getProperty(TRANSFER_SAREC_REPORT_INTERVAL));




		// Load version properties
		Properties vVersion =
				loadProperties("version.configuration", "version.properties", true);

		if (vVersion != null) {
			mVersion = vVersion.getProperty(VERSION);
		}

		//loadExternalProperties();
	}



	public File getExternalCardTempScanningDirectory() {
		return mExternalCardTempScanningDirectory;
	}



	public File getExternalCardTempVerificationDirectory() {
		return mExternalCardTempVerificationDirectory;
	}



	public File getExternalCardTempProcessedDirectory() {
		return mExternalCardTempProcessedDirectory;
	}



	public File getExternalCardTempFailedDirectory() {
		return mExternalCardTempFailedDirectory;
	}


	public File getExternalCardTempLogDirectory() {
		return mExternalCardTempLogDirectory;
	}



	public int getExternalCardTempScanningInterval() {
		return mExternalCardTempScanningInterval;
	}



	private void setExternalTempCardScanningInterval(String property) {
		// TODO Auto-generated method stub
		mExternalCardTempScanningInterval =
				new Integer(property).intValue();
	}

	private void setExternalTempCardFailedDirectory(String string) {
		// TODO Auto-generated method stub
		mExternalCardTempFailedDirectory= new File(string);
	}

	private void setExternalTempCardProcessedDirectory(String string) {
		// TODO Auto-generated method stub
		mExternalCardTempProcessedDirectory= new File(string);
	}

	private void setExternalTempCardLogDirectory(String string) {
		// TODO Auto-generated method stub
		mExternalCardTempLogDirectory= new File(string);
	}

	private void setExternalTempCardVerificationDirectory(String string) {
		// TODO Auto-generated method stub
		mExternalCardTempVerificationDirectory= new File(string);
	}

	private void setExternalTempCardScanningDirectory(String string) {
		// TODO Auto-generated method stub
		mExternalCardTempScanningDirectory= new File(string);
	}

	/**
	 * @param pPropertyName
	 * @param pDefaultLocation
	 * @param pAllowEmpty
	 * @return
	 * @throws IkeaException
	 */
	private Properties loadProperties(
			String pPropertyName,
			String pDefaultLocation,
			boolean pAllowEmpty)
					throws IkeaException {

		InputStream vInputStream = null;

		try {
			URL vURL = null;

			// Check for system property for alternate location of properties
			String vPropertiesLocation = System.getProperty(pPropertyName);

			// Create URL to property file in the classpath or alternate location
			if (vPropertiesLocation != null
					&& vPropertiesLocation.length() > 0) {
				mLog.info(
						"Using properties from external settings ["
								+ vPropertiesLocation
								+ "]");
				vURL = new URL(vPropertiesLocation);
			} else {
				mLog.info("Using properties from class loader");
				vURL =
						Thread.currentThread().getContextClassLoader().getResource(
								pDefaultLocation);
			}

			// Check for URL
			if (vURL == null) {
				if (!pAllowEmpty) {
					throw new IkeaException(
							pDefaultLocation + " could not be found, URL was null");
				}
				return null;
			}

			// Open input stream
			vInputStream = vURL.openStream();

			// Check for input stream
			if (vInputStream == null) {
				if (!pAllowEmpty) {
					throw new IkeaException(
							vURL.toString()
							+ " could not be found, input stream was null");
				}
				return null;
			}

			Properties vProperties = new Properties();
			vProperties.load(vInputStream);
			return vProperties;

		} catch (IkeaException e) {
			throw e;
		} catch (Exception e) {
			throw new IkeaException(e);
		} finally {
			try {
				// Close stream
				if (vInputStream != null) {
					vInputStream.close();
				}
			} catch (IOException e) {
				mLog.error(e.getLocalizedMessage());
			}
		}
	}

	/**
	 * @return
	 * @throws IkeaException
	 */
	//	private void loadExternalProperties() throws IkeaException {
	//		try {
	//			mRemoteConfigurationList.clear();
	//
	//			// Check for system property for alternate location of external property files
	//			String vPropertiesLocation = System.getProperty("external.location");
	//			
	//			URL vUrlDir = null;
	//
	//			if (vPropertiesLocation != null
	//				&& vPropertiesLocation.length() > 0) {
	//				mLog.info(
	//					"Using external property file location from external settings ["
	//						+ vPropertiesLocation
	//						+ "]");
	//				
	//				vUrlDir = new URL(vPropertiesLocation);
	//			} else {
	//				mLog.info("Using external property file location from class loader");
	//				vUrlDir = Thread.currentThread().getContextClassLoader().getResource(".");
	//			}
	//			
	//			File vDir = new File(vUrlDir.getFile());
	//
	//			// Check for URL
	//			if (vDir == null || !vDir.exists()) {
	//				throw new IkeaException(
	//					"External property file location could not be found");
	//			}
	//			
	//			String[] vPropertyFiles = vDir.list(new FilenameFilter() {
	//				public boolean accept(File dir, String name) {
	//					String lcName = name.toLowerCase();
	//					return (lcName.startsWith("company_") && lcName.endsWith(".properties"));
	//				}
	//			});
	//			
	//			if (vPropertyFiles != null) {
	//				for (int i = 0; i < vPropertyFiles.length; i++) {
	//					URL vPropertyUrl = null;
	//					
	//					if (vPropertiesLocation != null && vPropertiesLocation.length() > 0) {
	//						vPropertyUrl = new URL(vPropertiesLocation + "/" + vPropertyFiles[i]);
	//					} else {
	//						vPropertyUrl = Thread.currentThread().getContextClassLoader().getResource(vPropertyFiles[i]);
	//					}
	//					
	//					if (vPropertyUrl == null) {
	//						throw new IkeaException(
	//								vPropertyFiles[i] + " could not be found, URL was null");
	//					}
	//					
	//					mRemoteConfigurationList.add(new RemoteConfigurationImpl(vPropertyUrl));
	//				}
	//			}
	//		} catch (IkeaException e) {
	//			throw e;
	//		} catch (Exception e) {
	//			throw new IkeaException( e);
	//		}
	//	}
	//
	//	/**
	//	 * Sets the ScanningDirectory value after validation
	//	 * 
	//	 * @param pScanningDirectory The new ScanningDirectory setting
	//	 * @throws IkeaException If an error or validation problem occurs
	//	 */
	private void setScanningDirectory(String pScanningDirectory)
			throws IkeaException {

		mScanningDirectory = new File(pScanningDirectory);

		if (!mScanningDirectory.exists()
				|| !mScanningDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute " + SCANNING_DIRECTORY + " was not found");
		}
	}

	/**
	 * Sets the ExternalCardScanningDirectory value after validation
	 * 
	 * @param pExternalCardScanningDirectory
	 * @throws IkeaException
	 */
	private void setExternalCardScanningDirectory(String pExternalCardScanningDirectory)
			throws IkeaException {

		mExternalCardScanningDirectory =
				new File(pExternalCardScanningDirectory);

		if (!mExternalCardScanningDirectory.exists()
				|| !mExternalCardScanningDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_CARD_SCANNING_DIRECTORY
							+ " was not found");
		}
	}

	/**
	 * Sets the ProcessedDirectory value after validation
	 * 
	 * @param pProcessedDirectory The new ProcessedDirectory setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setProcessedDirectory(String pProcessedDirectory)
			throws IkeaException {

		mProcessedDirectory = new File(pProcessedDirectory);

		if (!mProcessedDirectory.exists()
				|| !mProcessedDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ PROCESSED_DIRECTORY
							+ " was not found");
		}
	}

	/**
	 * Sets the failed directory value after validation
	 * 
	 * @param pFailedDirectory The new failed directory setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setFailedDirectory(String pFailedDirectory)
			throws IkeaException {

		mFailedDirectory = new File(pFailedDirectory);

		if (!mFailedDirectory.exists() || !mFailedDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute " + FAILED_DIRECTORY + " was not found");
		}
	}

	/**
	 * Sets the scanning interval value after validation
	 * 
	 * @param pScanningInterval The new scanning interval setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setScanningInterval(String pScanningInterval)
			throws IkeaException {

		try {
			mScanningInterval = new Integer(pScanningInterval).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Mandatory attribute "
							+ SCANNING_INTERVAL
							+ " could not be interpreted as an integer");
		}
	}

	/**
	 * Sets the external scanning interval value after validation
	 * 
	 * @param pExternalScanningInterval The new scanning interval setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setExternalScanningInterval(String pExternalScanningInterval)
			throws IkeaException {

		try {
			mExternalScanningInterval = new Integer(pExternalScanningInterval).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_SCANNING_INTERVAL
							+ " could not be interpreted as an integer");
		}
	}

	/**
	 * Sets the delete processed files interval value after validation
	 * 
	 * @param pDeleteProcessedFilesInterval The new interval setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setDeleteProcessedFilesInterval(String pDeleteProcessedFilesInterval)
			throws IkeaException {

		try {
			mDeleteProcessedFilesInterval = new Integer(pDeleteProcessedFilesInterval).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Mandatory attribute "
							+ DELETE_PROCESSED_FILES_INTERVAL
							+ " could not be interpreted as an integer");
		}
	}

	/**
	 * 
	 * @param pExternalCardFailedDirectory
	 * @throws IkeaException
	 */
	public void setExternalCardFailedDirectory(String pExternalCardFailedDirectory)
			throws IkeaException {

		mExternalCardFailedDirectory = new File(pExternalCardFailedDirectory);

		if (!mExternalCardFailedDirectory.exists()
				|| !mExternalCardFailedDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_FAILED_DIRECTORY
							+ " was not found");
		}
	}

	/**
	 * 
	 * @param pExternalCardProcessedDirectory
	 * @throws IkeaException
	 */
	public void setExternalCardProcessedDirectory(String pExternalCardProcessedDirectory)
			throws IkeaException {

		mExternalCardProcessedDirectory =
				new File(pExternalCardProcessedDirectory);

		if (!mExternalCardProcessedDirectory.exists()
				|| !mExternalCardProcessedDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_PROCESSED_DIRECTORY
							+ " was not found");
		}
	}

	/**
	 * 
	 * @param pExternalCardScanningInterval
	 * @throws IkeaException
	 */
	public void setExternalCardScanningInterval(String pExternalCardScanningInterval)
			throws IkeaException {

		try {
			mExternalCardScanningInterval =
					new Integer(pExternalCardScanningInterval).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_CARD_SCANNING_INTERVAL
							+ " could not be interpreted as an integer");
		}

	}

	public void setFromMailAddress(String pMailAddress)
			throws IkeaException {

		if (pMailAddress == null || pMailAddress.length() == 0) {
			mMailFromAddress = null;
			return;
		}

		if (pMailAddress.indexOf("@") < 0) {
			throw new IkeaException(
					"Attribute " + MAIL_ADDRESS_FROM	+ " could not be interpreted as a mail address");
		}

		mMailFromAddress = pMailAddress;
	}

	public void setMailSmtpHost(String pMailSmtpHost)
			throws IkeaException {

		if (pMailSmtpHost == null || pMailSmtpHost.length() == 0) {
			mMailSmtpHost = null;
			return;
		}

		mMailSmtpHost = pMailSmtpHost;
	}

	/**
	 * Sets the transfer sarec report interval value after validation
	 * 
	 * @param pTransferSarecReportInterval The new transfer sarec report interval setting
	 * @throws IkeaException If an error or validation problem occurs
	 */
	private void setTransferSarecReportInterval(String pTransferSarecReportInterval)
			throws IkeaException {

		try {
			mTransferSarecReportInterval = new Integer(pTransferSarecReportInterval).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
					"Mandatory attribute "
							+ TRANSFER_SAREC_REPORT_INTERVAL
							+ " could not be interpreted as an integer");
		}
	}

	private void setChinaPk(String mChinaPkEnvironment,String mChinaPkTest,String mChinaPkProd) {
		// TODO Auto-generated method stub

		if(mChinaPkEnvironment.equalsIgnoreCase("TEST"))
		{
			this.mChinaPk= mChinaPkTest;
		}
		else if(mChinaPkEnvironment.equalsIgnoreCase("PROD"))
		{
			this.mChinaPk= mChinaPkProd;
		}
		else{
			this.mChinaPk=null;
		}

	}

	private void setChinaPort(String mTimeOut) {
		// TODO Auto-generated method stub
		mChinaPort = new Integer(mTimeOut).intValue();
	}


	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getScanningDirectory()
	 */
	public File getScanningDirectory() {
		return mScanningDirectory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getProcessedDirectory()
	 */
	public File getProcessedDirectory() {
		return mProcessedDirectory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getFailedDirectory()
	 */
	public File getFailedDirectory() {
		return mFailedDirectory;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getScanningInterval()
	 */
	public long getScanningInterval() {
		return mScanningInterval;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getExternalScanningInterval()
	 */
	public long getExternalScanningInterval() {
		return mExternalScanningInterval;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getDeleteProcessedFilesInterval()
	 */
	public long getDeleteProcessedFilesInterval() {
		return mDeleteProcessedFilesInterval;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getExternalCardScanningDirectory()
	 */
	public File getExternalCardScanningDirectory() {
		return mExternalCardScanningDirectory;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getExternalCardFailedDirectory()
	 */
	public File getExternalCardFailedDirectory() {
		return mExternalCardFailedDirectory;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getExternalCardProcessedDirectory()
	 */
	public File getExternalCardProcessedDirectory() {
		return mExternalCardProcessedDirectory;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getExternalCardScanningInterval()
	 */
	public long getExternalCardScanningInterval() {
		return mExternalCardScanningInterval;
	}

	public String getFromMailAddress() {
		return mMailFromAddress;
	}

	public String getMailSmtpHost() {
		return mMailSmtpHost;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getTransferSarecReportInterval()
	 */
	public long getTransferSarecReportInterval() {
		return mTransferSarecReportInterval;
	}

	/*
	 *  (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getRemoteConfigurationList()
	 */



	public int getChinaEncryptionPort() {
		return mChinaPort;
	}

	public String getChinaEncryptionPk() {
		return mChinaPk;
	}

	public String getSftpServerUrl() {
		return mSftpServerUrl;
	}

	public void setSftpServerUrl(String mSftpServerUrl) {
		this.mSftpServerUrl = mSftpServerUrl;
	}

	public String getSftpServerUsername() {
		return mSftpServerUsername;
	}

	public void setSftpServerUsername(String mSftpServerUsername) {
		this.mSftpServerUsername = mSftpServerUsername;
	}

	public String getSftpServerPassword() {
		return mSftpServerPassword;
	}

	public void setSftpServerPassword(String mSftpServerPassword) {
		this.mSftpServerPassword = mSftpServerPassword;
	}

	public String getIPayDbUrl() {
		return iPayDbUrl;
	}

	public void setIPayDbUrl(String iPayDbUrl) {
		this.iPayDbUrl = iPayDbUrl;
	}

	public String getIPayDbUser() {
		return iPayDbUser;
	}

	public void setIPayDbUser(String iPayDbUser) {
		this.iPayDbUser = iPayDbUser;
	}

	public String getIpayDbPassword() {
		return ipayDbPassword;
	}

	public void setIpayDbPassword(String ipayDbPassword) {
		this.ipayDbPassword = ipayDbPassword;
	}

	public File getSftpDirectory() {
		return mSftpDirectory;
	}

	public void setSftpDirectory(String mSftpDirectoryUrl) 
			throws IkeaException {

		mSftpDirectory =
				new File(mSftpDirectoryUrl);

		if (!mExternalCardScanningDirectory.exists()
				|| !mExternalCardScanningDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_SFTP_SERVER_LOCAL_DIRECTORY
							+ " was not found");
		}

		this.mSftpDirectory = mSftpDirectory;

	}

	public File getSftpProcessedDirectory() {
		return mSftpProcessedDirectory;
	}

	public void setSftpProcessedDirectory(String mSftpProcessedDirectoryUrl) 
			throws IkeaException {

		mSftpProcessedDirectory =
				new File(mSftpProcessedDirectoryUrl);

		if (!mExternalCardScanningDirectory.exists()
				|| !mExternalCardScanningDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_SFTP_SERVER_PROCESSED_DIRECTORY
							+ " was not found");
		}

		this.mSftpProcessedDirectory = mSftpProcessedDirectory;
	}

	public File getSftpFailedDirectory() {
		return mSftpFailedDirectory;
	}

	public void setSftpFailedDirectory(String mSftpFailedDirectoryUrl) 
			throws IkeaException {

		mSftpFailedDirectory =
				new File(mSftpFailedDirectoryUrl);

		if (!mExternalCardScanningDirectory.exists()
				|| !mExternalCardScanningDirectory.isDirectory()) {
			throw new IkeaException(
					"Mandatory attribute "
							+ EXTERNAL_CARD_SCANNING_DIRECTORY
							+ " was not found");
		}

		this.mSftpFailedDirectory = mSftpFailedDirectory;
	}

	public int getSftpServerPort() {
		return mSftpServerPort;
	}

	public void setSftpServerPort(String mSftpServerPort) {

		this.mSftpServerPort = Integer.parseInt(mSftpServerPort);
	}

	public String getSftpPrivateKey() {
		return mPrivateKey;
	}

	public void setSftpPrivateKey(String privateKeyFileName) {
		String vPropertiesLocation = System.getProperty(privateKeyFileName);
		URL vUrlDir = null;
		try {
			vUrlDir = new URL(vPropertiesLocation);
		}
		catch (MalformedURLException e) {
			throw new IkeaException("Mandatory attribute private key  was not found" + vUrlDir.getFile());
		}

		if (new File(vUrlDir.getFile()).exists())
		{
			this.mPrivateKey = vUrlDir.getFile();
		}
		else
			throw new IkeaException("Mandatory attribute private key  was not found" + vUrlDir.getFile());
	}

	public String getToMailAddress() {
		return mMailToAddress;
	}

	public void setToMailAddress(String mMailToAddress) {
		this.mMailToAddress = mMailToAddress;
	}

	public String getCCMailAddress() {
		return mMailCCAddress;
	}

	public void setCCMailAddress(String mMailCCAddress) {
		this.mMailCCAddress = mMailCCAddress;
	}
}



