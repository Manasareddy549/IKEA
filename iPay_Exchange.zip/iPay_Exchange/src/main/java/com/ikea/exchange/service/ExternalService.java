package com.ikea.exchange.service;


import java.io.File;

import com.ikea.ebcframework.exception.IkeaException;

/**
 */
public interface ExternalService extends Runnable {

	/**
	 * @param vExternalScanningInterval 
	 * @param mMailSmtpHost 
	 * @param mMailAddress 
	 * @param mIPayDbPassword 
	 * @param mIPayDbUser 
	 * @param mIpayDbUrl 
	 * @param mSFTPCardFailedDirectory 
	 * @param mSFTPCardProcessedDirectory 
	 * @param mSFTPCardScanningDirectory 
	 * @param mSftpPrivateKey 
	 * @param mSftpServerPort 
	 * @param mSftpServerUsername 
	 * @param mSftpServerurl 
	 * @param mSftpServerpassword 
	 * @param mCCMailAddress 
	 */
	public void start(String mSftpServerurl, String mSftpServerUsername, 
			String mSftpServerpassword, int mSftpServerPort, String mSftpPrivateKey, File mSFTPCardScanningDirectory, 
			File mSFTPCardProcessedDirectory, File mSFTPCardFailedDirectory, String mIpayDbUrl, 
			String mIPayDbUser, String mIPayDbPassword, 
			String mFromMailAddress,String mToMailAddress, String mCCMailAddress, String mMailSmtpHost, 
			long vExternalScanningInterval)
		throws IkeaException;

	/**
	 * Stops a running service. The call to stop will return once the service has stopped.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public void stop() throws IkeaException;
}
