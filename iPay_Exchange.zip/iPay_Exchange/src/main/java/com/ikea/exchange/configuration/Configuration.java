package com.ikea.exchange.configuration;

import com.ikea.ebcframework.exception.IkeaException;

import java.io.File;
import java.util.List;


/*
 * 
 * @author snug
 *
 * Interface for providing configuration information to the iPay Exchange service.
 * This is typically read from a configuration file.
 * 
 */
public interface Configuration {

	/**
	 * Specifies the scanning directory
	 * 
	 * @return The scanning directory
	 */
	public abstract File getScanningDirectory();

	/**
	 * 
	 * @return The scanning directory of external card file to import
	 */

	public abstract File getExternalCardScanningDirectory();

	/**
	 * 
	 * @return The failed directory of external card file import
	 */

	public abstract File getExternalCardFailedDirectory();
	/**
	 * 
	 * @return The processed directory of external card file imported
	 */

	public abstract File getExternalCardProcessedDirectory();
	/**
	 * 
	 * @return The scanning interval directory of external card file to import
	 */

	public abstract long getExternalCardScanningInterval();

	/**
	 * Specifies the processed directory
	 * 
	 * @return The processed directory
	 */
	public abstract File getProcessedDirectory();

	/**
	 * Specifies the failed directory
	 * 
	 * @return The failed directory
	 */
	public abstract File getFailedDirectory();

	/**
	 * Specifies the scanning interval
	 * 
	 * @return The scanning interval
	 */
	public abstract long getScanningInterval();

	/**
	 * Specifies the external scanning interval (through SFTP)
	 * 
	 * @return The scanning interval
	 */
	public abstract long getExternalScanningInterval();

	/**
	 * Specifies the interval for deleting already processed files
	 * 
	 * @return The delete interval
	 */
	public abstract long getDeleteProcessedFilesInterval();
	
	/**
	 * Specifies the transfer SAREC report interval (through SFTP)
	 * 
	 * @return The transfer SAREC report interval
	 */
	public abstract long getTransferSarecReportInterval();

	public abstract String getFromMailAddress();
	public abstract String getMailSmtpHost();
	public abstract String getToMailAddress();
	public abstract String getCCMailAddress();

	/**
	 * 
	 * @return The version number of the service
	 */
	public String getVersion();
	
	/**
	 * Gets a list containing configurations for remote services
	 * 
	 * @return A list with remote configurations
	 */

	/**
	 * A call to reload signals the the settings should be read again.
	 * @throws IkeaException When a error occurs
	 */
	public abstract void reload() throws IkeaException;
	
	public File getExternalCardTempScanningDirectory();
	

	public int getExternalCardTempScanningInterval();

	public File getExternalCardTempVerificationDirectory();

	

	public File getExternalCardTempProcessedDirectory(); 

	

	public File getExternalCardTempFailedDirectory(); 

	
	public File getExternalCardTempLogDirectory(); 

	

	public int getChinaEncryptionPort(); 
	
	
	public String getChinaEncryptionPk(); 
	
	
	public String getSftpServerUrl();
	
	public String getSftpServerUsername();
	
	public String getSftpServerPassword();
	
	public int getSftpServerPort();
	
	public String getIPayDbUrl();
	
	public String getIPayDbUser();
	
	public String getIpayDbPassword();
	
	public File getSftpDirectory();

	public File getSftpProcessedDirectory();
	
	public File getSftpFailedDirectory();
	
	
	public String getSftpPrivateKey();
	
	
	
	
	
}
