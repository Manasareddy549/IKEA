/*
 * Created on 2007-aug-16
 *
 *
 */
package com.ikea.exchange.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import com.ikea.ebccardpay1.client.bs.BsImportExternalCards;
import com.ikea.ebccardpay1.client.vo.VoExternalCard;
import com.ikea.ebccardpay1.client.vo.VoExternalCardSystem;
import com.ikea.ebcframework.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.BsExecuterFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dalq
 *
 *
 */
public class ExternalCardServiceImpl implements ExternalCardService {
    private BsExecuter bsExecuter = BsExecuterFactory.getBsExecuter();
	private static final String WORKING_EXTENSION = ".working";
	private static final String FINISHED_EXTENSION = ".finished";
	private static final String FAILED_EXTENSION = ".failed";

	private final static Logger log = LoggerFactory.getLogger(ExternalCardServiceImpl.class);

	private final static SimpleDateFormat sFormatter =
		new SimpleDateFormat("yyyyMMddHHmmss");

	/**
	 * Dependencies
	 */
	private ScheduledExecutorService mScheduledExecutorService = null;
	private ServiceFactoryImpl mServiceFactoryImpl = null;

	/*
	 * Controls if the service is running or not
	 */
	private boolean mRunning = false;

	/**
	 * The scanning directory
	 */
	File mExternalCardScanningDirectory = null;

	/**
	 * The processed directory
	 */
	File mExternalCardProcessedDirectory = null;

	/**
	 * The failed directory
	 */
	File mExternalCardFailedDirectory = null;

	/**
	 * The scanning interval
	 */
	long mExternalCardScanningInterval = 120;

	/**
	 * Active File handler
	 */
	Map mCurrentScanning = new HashMap();

	/**
	 * 
	 * Dependency injector constructor, used by factory and unit testing. Don't call
	 * the constructor directly, use ServiceFactorySingleton.getInstance().createExternalCardService().
	 * The constructor is public so it can be used by the test cases.
	 *  
	 * @param pScheduledExecutorService
	 * @param pServiceFactoryImpl
	 */
	public ExternalCardServiceImpl(
		ScheduledExecutorService pScheduledExecutorService,
		ServiceFactoryImpl pServiceFactoryImpl) {

		mScheduledExecutorService = pScheduledExecutorService;
		mServiceFactoryImpl = pServiceFactoryImpl;
	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ExternalCardService#start(java.io.File, long)
	 */
	public void start(
		File pExternalCardScanningDirectory,
		File pExternalCardProcessedDirectory,
		File pExternalCardFailedDirectory,
		long pExternalCardScanningInterval)
		throws IkeaException {

		// Check running flag
		if (mRunning) {
			throw new IkeaException("ExternalCardService is already running");
		}

		mExternalCardScanningDirectory = pExternalCardScanningDirectory;
		mExternalCardProcessedDirectory = pExternalCardProcessedDirectory;
		mExternalCardFailedDirectory = pExternalCardFailedDirectory;
		mExternalCardScanningInterval = pExternalCardScanningInterval;

		log.info(
			"Scanning interval"
				+ mExternalCardScanningInterval
				+ "  ...... "
				+ mExternalCardScanningDirectory.getPath());

		// Info in the log
		log.info(
			"Starting ExternalCardService on directory "
				+ mExternalCardScanningDirectory.getPath());

		mScheduledExecutorService.scheduleAtFixedRate(
			this,
			mExternalCardScanningInterval,
			mExternalCardScanningInterval,
			TimeUnit.SECONDS);

		// Set running flag to true to indicate that the service is executing
		mRunning = true;

	}

	/* (non-Javadoc)
	 * @see com.ikea.exchange.service.ExternalCardService#stop()
	 */
	public void stop() throws IkeaException {
		// Check running flag
		if (!mRunning) {
			throw new IkeaException("ExternalCardService is not running");
		}

		// Set running flag to false to indicate that the service is stopped
		mRunning = false;

	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		// Info in the log
		log.debug(
			"ExternalCardDirectoryScanning......"
				+ mExternalCardScanningDirectory.getName()
				+ "...");

		File[] vFileList = mExternalCardScanningDirectory.listFiles();

		for (int i = 0; i < vFileList.length; i++) {
			File vCurrent = vFileList[i];

			if (!vCurrent.exists()) {
				log.error(
					vCurrent.getName() + " does not exists. Skipping.....");
				continue;
			}
			if (!vCurrent.canRead()) {
				log.error(
					vCurrent.getName() + " can not be read. Skipping.....");
				continue;
			}
			if (!vCurrent.canWrite()) {
				log.error(
					vCurrent.getName() + " is not writable. Skipping.....");
				continue;
			}

			processFile(vCurrent);
		}
	}

	/**
	 * 
	 * @param pCurrentFile
	 */
	protected void processFile(File pCurrentFile) {

		String vFileName = pCurrentFile.getName();
		log.info("Processing " + vFileName + "...");

		if (vFileName.endsWith(WORKING_EXTENSION)
			|| vFileName.endsWith(FINISHED_EXTENSION)
			|| vFileName.endsWith(FAILED_EXTENSION)) {
			log.info("Skipping working file " + vFileName + "...");
			return;
		}

		File vWorking =
			renameFile(
				pCurrentFile,
				mExternalCardScanningDirectory,
				vFileName + WORKING_EXTENSION);

		if (vWorking == null) {
			return; // skip
		}

		// Process the file
		boolean success = process(vWorking, vFileName);

		if (success) {
			log.info("File " + vFileName + " successfully imported");
			// Set filename to finished and move
			renameAndMove(
				vWorking,
				mExternalCardProcessedDirectory,
				vFileName + FINISHED_EXTENSION);

		} else {
			log.warn("File " + vFileName + " failed import");
			// Set filename to failed and move
			renameAndMove(
				vWorking,
				mExternalCardFailedDirectory,
				vFileName + FAILED_EXTENSION);
		}
	}

	/**
	 * 
	 * Handles the import of the External Cards and catches all possible errors
	 * that can occur when calling the BS BsImportExternalCards in iPay
	 *
	 * This method should only return true or false
	 * 
	 * @param pFile
	 * @param pFileName
	 * @return true if the import was successfull false if it failed.
	 */
	private boolean process(File pFile, String pFileName) {
		BufferedReader vReader = null;

		// Create externalcard list VO
		List<VoExternalCard> vVoExternalCardList = new ArrayList<VoExternalCard>();

		// Create ExternalCardSystem VO
		VoExternalCardSystem vVoExternalCardSystem = new VoExternalCardSystem();

		String vHeader = null;
		String vLine = null;
		int vRowCount = 0;
		int vLimit = 1000;

		// Initiate IO zoo
		try {
			vReader =
				new BufferedReader(
					new InputStreamReader(new FileInputStream(pFile)));

			// Parse header
			vHeader = vReader.readLine();

			// Create ExternalCardSystem VO from Header info 
			vVoExternalCardSystem = setExternalCardSystem(vHeader);

			// Sanity check and header params
			if (vHeader == null || vHeader.length() == 0) {
				log.error(pFileName + " was empty");
			}

			// Parse External card numbers
			//int vCount = 0;

			vLine = vReader.readLine();

			while (vLine != null) {

				vRowCount++;

				//Create ExternalCard from row and add VO to List
				vVoExternalCardList.add(
                        createExternalCard(vLine));

				if (vVoExternalCardList.size() >= vLimit) {

					// Import in chunks
					vVoExternalCardSystem =
						importExternalCards(
							vVoExternalCardList,
							vVoExternalCardSystem);

					// Create new List to reset values	
					vVoExternalCardList = new ArrayList<VoExternalCard>();
				}

				vLine = vReader.readLine();
			}

			//This is the last lines. Set flag
			vVoExternalCardSystem.setIsLastCards(true);

			// Import the last lines from file
			vVoExternalCardSystem =
				importExternalCards(vVoExternalCardList, vVoExternalCardSystem);

			log.info("[-------- Import of file finished -------]");
			log.info(
				"[--- ExternalCardSystem: "
					+ vVoExternalCardSystem.getName()
					+ "  Number of lines: "
					+ vRowCount);
			log.info("[----------------------------------------]");

			return true;

		} catch (Exception e) {
			// Catch all and return false
			log.error(
				pFile.getName()
					+ " could not be processed. - Failed at row "
					+ vRowCount
					+ " Line info:"
					+ vLine
					+ " Header info:"
					+ vHeader,
				e);
		} finally {

			// Close file
			try {
				if (vReader != null)
					vReader.close();
			} catch (IOException e) {
				log.error(e.getLocalizedMessage());
			}
		}
		return false;
	}

	/**
	 * 
	 * Creates a VO object for ExternalCardSystem from the Header string in file.
	 * 
	 * @param pHeaderString - Header line from file contains ExternalCardSystem info 
	 * @return VoExternalCardSystem
	 */
	private VoExternalCardSystem setExternalCardSystem(String pHeaderString) {

		log.info("Start collecting header info.....");

		// Extract ExternalCardSystem information from Header line
		String[] vSplit = SplitString(pHeaderString, ";");

		VoExternalCardSystem vVoExternalCardSystem = new VoExternalCardSystem();

		// pos 1: Name
		vVoExternalCardSystem.setName(vSplit[0].trim());
		log.info("Name:" + vSplit[0]);

		// pos 2: CountryCode
		vVoExternalCardSystem.setCountryCode(vSplit[1].trim());
		log.info("CountryCode:" + vSplit[1]);

		// pos 3: CardNumberPattern
		vVoExternalCardSystem.setCardNumberPattern(vSplit[2].trim());
		log.info("CardNumberPattern:" + vSplit[2]);

		// pos 4: InitalCardNumber
		vVoExternalCardSystem.setInitialAccountNumber(
			Long.parseLong(vSplit[3].trim()));
		log.info("InitalCardNumber:" + vSplit[3]);

		// pos 5. MaxAccountNumber
		vVoExternalCardSystem.setMaxAccountNumber(
			Long.parseLong(vSplit[4].trim()));
		log.info("MaxAccountNumber:" + vSplit[4]);

		// pos 6. Issuer
		vVoExternalCardSystem.setIssuer(vSplit[5].trim());
		log.info("Issuer:" + vSplit[5]);

		//pos 7. AmountType
		vVoExternalCardSystem.setAmountType(vSplit[6]);
		log.info("AmountType:" + vSplit[6]);

		// pos 8. CardTypeDigit
		vVoExternalCardSystem.setCardTypeDigit(Integer.parseInt(vSplit[7]));
		log.info("CardTypeDigit:" + vSplit[7]);

		log.info("Finished collectiong header info.... ");
		return vVoExternalCardSystem;

	}

	/**
	 * Creates a VO object for ExternalCard for each line in file
	 * 
	 * @param pLine - Line from importfile
	 * @return VoExternalCard
	 */
	private VoExternalCard createExternalCard(String pLine) {

		String[] vSplitRow = SplitString(pLine, ";");

		// Create VO and set External Card values from line
		VoExternalCard vVoExternalCard = new VoExternalCard();

		// pos 1. CardNumber
		vVoExternalCard.setCardNumberString(vSplitRow[0].trim());
		// pos 2. CurrencyCode
		vVoExternalCard.setCurrencyCode(vSplitRow[1].trim());
		// pos 3. Original balance
		vVoExternalCard.setOriginalBalance(new BigDecimal(vSplitRow[2].trim()));
		// pos 4. BuType
		vVoExternalCard.setBuType(vSplitRow[3].trim());
		// pos 5. BuCode
		vVoExternalCard.setBuCode(vSplitRow[4].trim());

		// pos 6. Complete Import row from file (not mandatory)
		if (vSplitRow.length > 5) {
			vVoExternalCard.setImportedRow(vSplitRow[5]);
		}

		return vVoExternalCard;

	}

	/**
	 * 
	 * @param pStringToSplit
	 * @param pDelimiter
	 * @return
	 */
	private String[] SplitString(String pStringToSplit, String pDelimiter) {
		String[] vNewString = pStringToSplit.split(pDelimiter);
		return vNewString;

	}

	/**
	 * Method that makes the EBC call to ipay business service 
	 * BsImportExternalCards
	 * 
	 * @param vVoExternalCardList
	 * @param vVoExternalCardSystem
	 * @return
	 */
	private VoExternalCardSystem importExternalCards(
		List<VoExternalCard> vVoExternalCardList,
		VoExternalCardSystem vVoExternalCardSystem)
		throws IkeaException {

		// Create service
		BsImportExternalCards vBsImportExternalCards =
			new BsImportExternalCards();

		// Set input VO
		vBsImportExternalCards.setVoExternalCardList(vVoExternalCardList);
		vBsImportExternalCards.setInputVoExternalCardSystem(
			vVoExternalCardSystem);

		// Execute service
        //BsCallInfo bsCallInfo = new BsCallInfo(null, null, null, 0L, null, null,"Originator");
		bsExecuter.executeBs(vBsImportExternalCards,"Originator");

		// Check for application errors
		List vApplErrors = vBsImportExternalCards.getApplicationErrors();
		if (vApplErrors != null && !vApplErrors.isEmpty()) {
			throw new IkeaException(
				"Application errors found in import. " + vApplErrors);
		}

		// Check if ouput from import is OK
		if (vBsImportExternalCards.getOutputVoExternalCardSystem() == null) {
			throw new IkeaException("Got null ExternalCardSystem object back from BS");
		}

		return vBsImportExternalCards.getOutputVoExternalCardSystem();
	}

	/**
	 * Only made to clean up code a bit
	 *
	 * @param pFile
	 * @param pNewFileName
	 * @return
	 */
	private File renameFile(File pFile, File pDirectory, String pNewFileName) {
		File vWorking = new File(pDirectory, pNewFileName);

		if (!pFile.renameTo(vWorking)) {
			log.warn(
				"Could not rename "
					+ pFile
					+ " to "
					+ pNewFileName
					+ ", skipping... ");
			return null;
		}
		return vWorking;
	}

	/**
	 * 
	 * @param pFile
	 * @param pDirectory
	 * @param pNewFileName
	 */
	protected void renameAndMove(
		File pFile,
		File pDirectory,
		String pNewFileName) {

		File vWorking = new File(pDirectory, pNewFileName);

		if (!pFile.renameTo(vWorking)) {

			log.info(
				"Could not rename "
					+ pFile
					+ " to "
					+ vWorking
					+ ", trying to add timestamp");

			File vWorking2 =
				new File(
					pDirectory,
					pNewFileName + sFormatter.format(new Date()));
			if (!pFile.renameTo(vWorking2)) {

				log.warn(
					"Could not rename "
						+ pFile
						+ " to "
						+ vWorking2
						+ ", skipping... ");
			}
		}
	}

}
