package com.ikea.exchange.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.ikea.ebcframework.exception.IkeaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 * @author mjdt
 *
 * Implements the RemoteConfiguration interface an provides configuration information
 * for the iPay exchange service for remote servers by reading property files called country_xxx.properties
 * located in the class path or at the location of the system property external.location
 * that can be set to an URL by starting the Java VM with -Dexternal.location=file:<somepath>
 * The system property is used in class ConfigurationImpl when creating RemoteConfigurations
 * 
 */
public class RemoteConfigurationImpl implements RemoteConfiguration {

	/**
	 * Log category for messages
	 */
	private final static Logger mLog = LoggerFactory.getLogger(RemoteConfigurationImpl.class);
	
	/**
	 * Property file url
	 */
	private URL mPropertyFile;

	/**
	 * Keys to the property file
	 */
	static final private String SERVER = "server";
	static final private String PORT = "port";
	static final private String USER = "user";
	static final private String PWD = "pwd";
	static final private String SUB_PATH = "sub.path";
	static final private String COUNTRY = "country";
	static final private String PRIVATE_KEY_FILE = "private.key.file";

	/**
	 * The current settings value
	 */
	private String mServer = null;
	private int mPort = 22;
	private String mUser = null;
	private String mPwd = null;
	private String mSubPath = null;
	private String mPrivateKeyFile = null;
	private String mCountry = null;

	/**
	 * Constructor that calls reload. This constructor should not be called directly.
	 * The constructor is public so that the test cases can use it.
	 * 
	 * @throws IkeaException If an error occurs
	 */
	public RemoteConfigurationImpl(URL pPropertyFile) throws IkeaException {
		mPropertyFile = pPropertyFile;
		
		reload();
	}

	/* (non-Javadoc)
	 * @see com.ikea.ibridge.configuration.Configuration#reload()
	 */
	public void reload() throws IkeaException {

		// Load configuration properties
		Properties vConfiguration = loadProperties(mPropertyFile);

		// Copy values from the properties instance to local variables (with validation)
		setServer(vConfiguration.getProperty(SERVER));
		setPort(vConfiguration.getProperty(PORT));
		setUser(vConfiguration.getProperty(USER));
		setPwd(vConfiguration.getProperty(PWD));
		setSubPath(vConfiguration.getProperty(SUB_PATH));
		setCountry(vConfiguration.getProperty(COUNTRY));
		setPrivateKeyFile(vConfiguration.getProperty(PRIVATE_KEY_FILE));
	}

	/**
	 * @param pPropertyFile
	 * @return
	 * @throws IkeaException
	 */
	private Properties loadProperties(URL pPropertyFile)
		throws IkeaException {

		InputStream vInputStream = null;

		try {
			// Open input stream
			vInputStream = pPropertyFile.openStream();

			// Check for input stream
			if (vInputStream == null) {
				throw new IkeaException(
					pPropertyFile.toString() + " could not be found, input stream was null");
			}

			Properties vProperties = new Properties();
			vProperties.load(vInputStream);
			return vProperties;

		} catch (IkeaException e) {
			throw e;
		} catch (Exception e) {
			throw new IkeaException( e);
		} finally {
			try {
				// Close stream
				if (vInputStream != null) {
					vInputStream.close();
				}
			} catch (IOException e) {
				mLog.error(e.getLocalizedMessage());
			}
		}
	}

	/**
	 * Sets the server address
	 * 
	 * @param pServer The remote ftp server address
	 */
	private void setServer(String pServer) {
		mServer = pServer;
	}

	/**
	 * Sets the ExternalCardScanningDirectory value after validation
	 * 
	 * @param pPort
	 * @throws IkeaException
	 */
	private void setPort(String pPort)
		throws IkeaException {
		
		// Port number is not mandatory, will use default value otherwise
		if (pPort == null || pPort.length() == 0)
			return;

		try {
			mPort = new Integer(pPort).intValue();
		} catch (NumberFormatException e) {
			throw new IkeaException(
				"Mandatory attribute "
					+ PORT
					+ " could not be interpreted as an integer");
		}
	}

	/**
	 * Sets the ftp user
	 * 
	 * @param pUser The ftp user
	 */
	private void setUser(String pUser) {
		mUser = pUser;
	}

	/**
	 * Sets the ftp password
	 * 
	 * @param pPwd The ftp password
	 */
	private void setPwd(String pPwd) {
		mPwd = pPwd;
	}

	/**
	 * Sets the sub path on the ftp server
	 * 
	 * @param pSubPath The sub path
	 */
	private void setSubPath(String pSubPath) {
		mSubPath = pSubPath;
	}
	
	/**
	 * Sets the private key file used against the ftp server
	 * 
	 * @param pPrivateKeyFile
	 */
	private void setPrivateKeyFile(String pPrivateKeyFile) {
		mPrivateKeyFile = pPrivateKeyFile;
	}
	

	/**
	 * Sets the country
	 * 
	 * @param pCountry The country
	 */
	private void setCountry(String pCountry) {
		mCountry = pCountry;
	}
	

	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getServer()
	 */
	public String getServer() {
		return mServer;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getPort()
	 */
	public int getPort() {
		return mPort;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getUser()
	 */
	public String getUser() {
		return mUser;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getPwd()
	 */
	public String getPwd() {
		return mPwd;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getSubPath()
	 */
	public String getSubPath() {
		return mSubPath;
	}
	
	/* (non-Javadoc)
	 * @see com.ikea.exchange.configuration.RemoteConfiguration#getCountry()
	 */
	public String getCountry() {
		return mCountry;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ikea.exchange.configuration.Configuration#getPrivateKeyFile()
	 */
	public String getPrivateKeyFile() {
		return mPrivateKeyFile;
	}
}
