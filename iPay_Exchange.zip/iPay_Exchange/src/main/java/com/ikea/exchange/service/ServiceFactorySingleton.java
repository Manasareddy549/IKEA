package com.ikea.exchange.service;


import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author snug
 *
 * Provides access to the <code>ServiceFactory</code> instance
 * 
 */
public class ServiceFactorySingleton {

	/**
	 * The single instance of the ServiceFactory factory
	 */
	protected static ServiceFactory sInstance;

	/**
	 * Don't construct - it is a singleton.
	 */
	private ServiceFactorySingleton() {
	}

	/**
	 * Provices access to the <code>ServiceFactory</code> instance
	 * 
	 * @return The <code>ServiceFactory</code> instance
	 * @throws IkeaException If the factory could not be created
	 */
	synchronized public static ServiceFactory getInstance()
		throws IkeaException {

		// Create a new ServiceFactory if it's null
		if (sInstance == null) {
			sInstance = new ServiceFactoryImpl();
		}

		// Return the instance
		return sInstance;
	}

	/**
	 * Use this setter before the first invocation of the getter
	 * to prevent the creation of a default instance.
	 * 
	 * @param pFactory Null to reset the singleton
	 */
	synchronized public static void setInstance(ServiceFactory pFactory) {
		sInstance = pFactory;
	}
}
