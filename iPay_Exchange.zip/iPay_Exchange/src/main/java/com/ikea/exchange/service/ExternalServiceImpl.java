package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.exchange.configuration.FileStatus;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.UserInfo;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import oracle.jdbc.driver.OracleDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExternalServiceImpl
  implements ExternalService
{
  private static final Logger mLog = LoggerFactory.getLogger(ExternalServiceImpl.class);

  private boolean mRunning = false;
  private ScheduledExecutorService mScheduledExecutorService = null;
  private long mScanningInterval;
  private String vSftpServerurl;
  private String vSftpServerUsername;
  private int vSftpServerPort;
  private String vSftpPrivateKey;
  private File vSFTPCardScanningDirectory;
  private File vSFTPCardProcessedDirectory;
  private File vSFTPCardFailedDirectory;
  private String vIpayDbUrl;
  private String vIPayDbUser;
  private String vIPayDbPassword;
  private String vFromMailAddress;
  private boolean filestatus;
  private String vMailSmtpHost;
  private boolean operationStatus;
  private String vSftpServerpassword;
  private com.jcraft.jsch.Session vSession = null;

  private ChannelSftp vSftp = null;
  private String emailBody;
  private String vToMailAddress;
  private String vCCMailAddress;
  private ArrayList<String> localFiles;
  private Date regDate = null;
  private Driver jdbcDriver;
  private Connection mConnection = null;

  private String mailSubject = "";
  private String lastScanPath;

  public ExternalServiceImpl(ScheduledExecutorService mScheduledExecutorService)
  {
    this.mScheduledExecutorService = mScheduledExecutorService;
  }

  public void start(String mSftpServerurl, String mSftpServerUsername, String mSftpServerpassword, int mSftpServerPort, String mSftpPrivateKey, File mSFTPCardScanningDirectory, File mSFTPCardProcessedDirectory, File mSFTPCardFailedDirectory, String mIpayDbUrl, String mIPayDbUser, String mIPayDbPassword, String mFromMailAddress, String mToMailAddress, String mCCMailAddress, String mMailSmtpHost, long vExternalScanningInterval)
    throws IkeaException
  {
    if (this.mRunning) {
      throw new IkeaException("Service is already running");
    }
    mLog.info("Starting external service");
    this.vSftpServerurl = mSftpServerurl;
    this.vSftpServerUsername = mSftpServerUsername;
    this.vSftpServerpassword = mSftpServerpassword;
    this.vSftpServerPort = mSftpServerPort;
    this.vSftpPrivateKey = mSftpPrivateKey;
    this.vSFTPCardScanningDirectory = mSFTPCardScanningDirectory;
    this.vSFTPCardProcessedDirectory = mSFTPCardProcessedDirectory;
    this.vSFTPCardFailedDirectory = mSFTPCardFailedDirectory;
    this.vIpayDbUrl = mIpayDbUrl;
    this.vIPayDbUser = mIPayDbUser;
    this.vIPayDbPassword = mIPayDbPassword;
    this.vFromMailAddress = mFromMailAddress;
    this.vToMailAddress = mToMailAddress;
    this.vCCMailAddress = mCCMailAddress;
    this.vMailSmtpHost = mMailSmtpHost;
    this.mScanningInterval = vExternalScanningInterval;
    this.lastScanPath = this.vSftpPrivateKey.replace("key.txt", "LastScan.properties");

    this.mScheduledExecutorService.scheduleAtFixedRate(this, 30L, vExternalScanningInterval, TimeUnit.SECONDS);

    this.mRunning = true;
  }

  public void stop() throws IkeaException
  {
    if (!this.mRunning) {
      throw new IkeaException("Service is not running");
    }

    this.mRunning = false;
  }

  public void run()
  {
    try
    {
      this.localFiles = new ArrayList();
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      String date_string = sdf.format(new Date());
      this.mailSubject = ("SELP Batch Status for " + date_string);
      connectToSFTPServer(this.vSftpServerurl, this.vSftpServerUsername, this.vSftpServerpassword, this.vSftpServerPort, this.vSftpPrivateKey);
      mLog.info("Get latest File from SFTP Server and Copy to local Folder");
      getLastScanDate();
      getLatestFiles(null);

      updatePropertiesFile();
      mLog.info("Scan for Files from Local folder and add it to List");
      scanForFiles(this.vSFTPCardScanningDirectory.getAbsolutePath());
      if (this.localFiles.size() > 0)
      {
        processFiles();
        sendEmail();
      }
      else {
        mLog.info("No Files Coppied from SFTP or available for Processing");
      }
    }
    catch (Exception e) {
      try {
        sendEmail();
      }
      catch (MessagingException e1) {
        mLog.error(e.getMessage());
      }
    }
  }

  private void updatePropertiesFile() throws IOException, ParseException
  {
    mLog.info("Updating Property File");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    File property_file = new File(this.lastScanPath);
    FileInputStream file = new FileInputStream(property_file);
    OutputStream output = new FileOutputStream(property_file);
    Properties prop = new Properties();
    prop.load(file);
    String property_date = sdf.format(new Date());
    prop.setProperty("Last_Scan_Date", property_date);
    prop.store(output, null);
    output.flush();
    output.close();
  }

  private void connectToSFTPServer(String vSftpServerurl2, String vSftpServerUsername2, String vSftpServerpassword, int vSftpServerPort2, String vSftpPrivateKey2)
    throws Exception
  {
    mLog.info("Connecting to SFTP Server");
    this.operationStatus = false;
    try {
      JSch vJsch = new JSch();
      this.vSession = vJsch.getSession(vSftpServerUsername2, vSftpServerurl2, vSftpServerPort2);
      this.vSession.setUserInfo(new UserInfo() {
        public String getPassphrase() {
          return null;
        }
        public String getPassword() {
          return null;
        }
        public boolean promptPassphrase(String string) {
          return true;
        }
        public boolean promptPassword(String string) {
          return false;
        }
        public boolean promptYesNo(String string) {
          return true;
        }

        public void showMessage(String string)
        {
        }
      });
      vJsch.addIdentity(vSftpPrivateKey2, vSftpServerpassword);
      this.vSession.setPassword(vSftpServerpassword);
      this.vSession.connect();

      this.vSftp = ((ChannelSftp)this.vSession.openChannel("sftp"));
      this.vSftp.connect();

      mLog.info("Connected to SFTP Server Succesfully");
    }
    catch (Exception e)
    {
      mLog.error("SFTP Connection failed due to " + e.getMessage());
      this.emailBody = new String("Connection to SFTP Server " + vSftpServerurl2 + " failed due to " + e.getMessage());
      throw new Exception("Connection to SFTP Server " + vSftpServerurl2 + " failed due to " + e.getMessage());
    }
    this.operationStatus = true;
    this.emailBody = new String("Connected to SFTP Server " + vSftpServerurl2 + " Succesfully");
  }

  private void getLastScanDate() throws IOException
  {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    try
    {
      FileInputStream file = new FileInputStream(this.lastScanPath);
      Properties prop = new Properties();
      prop.load(file);
      String dateString = prop.getProperty("Last_Scan_Date");
      this.regDate = sdf.parse(dateString);
    }
    catch (Exception e)
    {
      OutputStream output = new FileOutputStream(this.lastScanPath);
      Properties prop = new Properties();
      Date currentDate = new Date();
      Calendar callendar = Calendar.getInstance();
      callendar.setTime(currentDate);
      callendar.set(11, 0);
      callendar.set(12, 0);
      callendar.set(13, 0);
      callendar.set(14, 0);
      long time = callendar.getTimeInMillis();
      this.regDate = new Date(time);
      String dateString = sdf.format(this.regDate);
      prop.put("Last_Scan_Date", dateString);
      prop.store(output, null);
      output.flush();
      output.close();
    }
  }

  private void getLatestFiles(ChannelSftp.LsEntry dir) throws Exception
  {
    try {
      if ((dir != null) && (dir.getAttrs().isDir()))
      {
        this.vSftp.cd(dir.getFilename());
      }
      Vector files = this.vSftp.ls("*");
      if (files.size() > 0)
      {
        for (int i = 0; i < files.size(); i++) {
          ChannelSftp.LsEntry file = (ChannelSftp.LsEntry)files.get(i);
          SftpATTRS attrs = file.getAttrs();
          int t = attrs.getMTime();
          Date modTime = new Date(t * 1000L);
          if ((attrs.isDir()) && (modTime.after(this.regDate)))
          {
            getLatestFiles(file);
          }
          else if (file.getFilename().endsWith(".txt"))
          {
            String country = file.getFilename().substring(17, 19);
            this.vSftp.get(file.getFilename(), this.vSFTPCardScanningDirectory.getAbsolutePath() + "\\" + country);
            mLog.info("File " + file.getFilename() + " copied from SFTP to local folder");
          }

        }

        this.vSftp.cd("..");
      }

      this.operationStatus = true;
      this.emailBody = new String("Latest Files Copied from SFTP server to Local Folder Succesfully");
    }
    catch (Exception e)
    {
      this.operationStatus = false;
      this.emailBody = new String("Unable to get Latest Files from SFTP Server to local Folder for Processing " + e.getMessage());
      throw new Exception("Unable to get Latest Files from SFTP Server to local Folder for Processing " + e.getMessage());
    }
  }

  private void scanForFiles(String path)
  {
    File[] files = new File(path).listFiles();
    for (File file : files)
    {
      if (file.isDirectory())
      {
        scanForFiles(file.getAbsolutePath());
      }
      else if (file.getAbsolutePath().endsWith(".txt"))
      {
        this.localFiles.add(file.getAbsolutePath());
      }
    }
  }

  private void checkDbConnection()
    throws Exception
  {
    mLog.info("Verifying DB Connection");

    this.jdbcDriver = new OracleDriver();
    DriverManager.registerDriver(this.jdbcDriver);
    this.mConnection = DriverManager.getConnection(this.vIpayDbUrl, this.vIPayDbUser, this.vIPayDbPassword);
    if (this.mConnection == null)
      throw new Exception("Database Connection Failed");
    mLog.info("Connected to IPAY DB Succesfully");
  }

  private void processFiles() throws Exception
  {
    mLog.info("Found " + this.localFiles.size() + " file/files for processing");

    mLog.info("Processing files");

    checkDbConnection();

    StringBuffer buffer = new StringBuffer();

    buffer.append("\nFound " + this.localFiles.size() + " file/files for processsing");

    this.operationStatus = false;
    boolean fileUploadStatus = false;
    for (String file : this.localFiles)
    {
      FileStatus status = new ExternalServiceExtender(file, this.mConnection).startTask();
      fileUploadStatus = status.isFileUploadStatus();
      buffer.append("\n\nUpload Staus for file '" + status.getFileName() + "' ,Card Batch Type: '" + status.getCardBatchType() + "'");
      if (!fileUploadStatus)
      {
        buffer.append("\n\nCard Upload Failed Due to Below Issues: ");
        for (String error : status.getErrorMessage())
        {
          buffer.append("\n" + error);
        }

        buffer.append("\n\nFile has been marked as Failed and has been moved to failed Directory");

        buffer.append("\nKindly Re-Upload the file in Server after fixing the errors");
      }
      else
      {
        buffer.append("\n\nFile has been processed Successfully and has been moved to Processed Directory");
      }
      buffer.append("\n-----------------------------------------------------------------------------------------------------------");
    }
    if (fileUploadStatus)
	  {
		this.operationStatus = true;
		this.filestatus=true;
		this.emailBody = buffer.toString();
	  }
	else {
		this.operationStatus = false;
		this.filestatus=false;
		this.emailBody = buffer.toString();
	  }
  }

  private void sendEmail()
    throws MessagingException
  {
    mLog.info("Job Completed, Sending Mail");

    Properties props = new Properties();
    props.put("mail.smtp.host", this.vMailSmtpHost);
    javax.mail.Session session = javax.mail.Session.getDefaultInstance(props);
    MimeMessage message = new MimeMessage(session);
    message.setFrom(new InternetAddress(this.vFromMailAddress));

    if (this.operationStatus == true)
    {
      message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(this.vToMailAddress));
      message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(this.vCCMailAddress));
      message.setSubject(this.mailSubject + "--Successful");
      message.setText(this.emailBody);
    }
    else {
    //iPay 4.4 - 248568
		if(!this.filestatus)
		{
			//Failure message to all
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(this.vToMailAddress));
			message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(this.vCCMailAddress));
			message.setSubject(this.mailSubject + "--Failed");
			message.setText(this.emailBody);
		}
		else {
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(this.vCCMailAddress));
			message.setSubject(this.mailSubject + "--Failed");
			message.setText(this.emailBody);
		}

	}
    Transport.send(message);
  }
}
