package com.ikea.exchange.service;

import com.ikea.ebcframework.exception.IkeaException;

public interface TransferSaarecReportService extends Runnable {

		/**
		 */
		public void start(long pTransferSarecReportInterval)
			throws IkeaException;

		/**
		 * Stops a running service. The call to stop will return once the service has stopped.
		 * 
		 * @throws IkeaException If an error occurs
		 */
		public void stop() throws IkeaException;

}
