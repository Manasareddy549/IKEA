/*
 * Created on 2008-apr-03
 *
 */
package com.ikea.exchange.service;

import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ikea.ebccardpay1.client.vo.VoCardNumber;
import com.ikea.ebccardpay1.client.vo.VoCardRange;
import com.ikea.ebccardpay1.client.vo.VoMultipleSingleLoadInitial;
import com.ikea.ebccardpay1.client.vo.VoMultipleSingleLoadInitialCardAmount;

/**
 * @author DALQ
 *
 */
public class XmlParserImpl extends DefaultHandler implements XmlParser {

	private final static Logger mLog = LoggerFactory.getLogger(XmlParserImpl.class);

	private static Schema mSchema = null;
	private static final String XSD = "campaign.xsd";

	private StringBuffer tempVal = new StringBuffer();
	private String vTrimmedCardNumber = "";
	private StringBuffer mHeaderInfo = null;
	private VoCardRange mVoCardRange = null;
	private VoCardNumber mVoCardNumber = null;
	private List<VoCardNumber> mVoCardNumberList = null;
	
	private VoMultipleSingleLoadInitial mVoMultipleSingleLoadInitial = null;
	private List<VoMultipleSingleLoadInitialCardAmount> mVoMultipleSingleLoadInitialCardAmountList = null;
	private VoMultipleSingleLoadInitialCardAmount mVoMultipleSingleLoadInitialCardAmount = null;

	/**
	 * 
	 */
	public XmlParserImpl() {
		super();

	}

	public void readXmlFile(Reader pReader) {
		//mCategory.info(
		//	"Validating scheme is set to " + mConfiguration.isValidateSchema());
		// TODO Implement validation setting true/false
		mLog.info("Validating scheme...");
		if (mSchema == null /*&& mConfiguration.isValidateSchema()*/
			) {
			try {
				URL vURL =
					Thread.currentThread().getContextClassLoader().getResource(
						XSD);
				if (vURL == null) {
					mLog.warn(
						"Could not load '"
							+ XSD
							+ "' as resource in context class loader.");
				} else {
					SchemaFactory vSchemaFactory =
						SchemaFactory.newInstance(
							XMLConstants.W3C_XML_SCHEMA_NS_URI);
					mSchema = vSchemaFactory.newSchema(vURL);
				}
			} catch (Exception e) {
				mLog.warn("Could not get XSD for validating XML.", e);
			}
		}

		parseXmlDocument(pReader);
	}

	/**
	 * @param pReader
	 */
	private void parseXmlDocument(Reader pReader) {
		//get a factory
		SAXParserFactory vSAXParserFactory = SAXParserFactory.newInstance();
		vSAXParserFactory.setNamespaceAware(true);

		//if (mConfiguration.isValidateSchema()) {
		vSAXParserFactory.setSchema(mSchema);
		//}		

		try {

			mLog.info("Start parsing xmlfile");
			//get a new instance of parser
			SAXParser vSAXParser = vSAXParserFactory.newSAXParser();

			//parse the file
			vSAXParser.parse(new InputSource(pReader), this);

		} catch (SAXException se) {
			se.printStackTrace();
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}
	}

	//Event Handlers
	public void startElement(
		String uri,
		String localName,
		String qName,
		Attributes attributes)
		throws SAXException {

		//reset
		//tempVal.setLength(0);

		if (mLog.isDebugEnabled()) {
			mLog.info("Reading start tag: " + qName);
		}

		if (qName.equalsIgnoreCase(ELEMENT_CAMPAIGN_INFORMATION)) {
			//create a new instance of VoCardRange
			mVoCardRange = new VoCardRange();
			mHeaderInfo = new StringBuffer();

		} else if (qName.equalsIgnoreCase(ELEMENT_CUSTOMER_LIST)) {
			mVoCardNumberList = new ArrayList<VoCardNumber>();
		} else if (qName.equalsIgnoreCase(ELEMENT_CUSTOMER)) {
			mVoCardNumber = new VoCardNumber();
		} else if (qName.equalsIgnoreCase(ELEMENT_MULTIPLE_SINGLE_LOAD)) {
			mVoMultipleSingleLoadInitial = new VoMultipleSingleLoadInitial();
		} else if (qName.equalsIgnoreCase(ELEMENT_CARD_AMOUNT_LIST)) {
			mVoMultipleSingleLoadInitialCardAmountList = new ArrayList<VoMultipleSingleLoadInitialCardAmount>();
		} else if (qName.equalsIgnoreCase(ELEMENT_CARD_AMOUNT)) {
			mVoMultipleSingleLoadInitialCardAmount = new VoMultipleSingleLoadInitialCardAmount();
		}
		tempVal.setLength(0);

	}

	public void characters(char[] ch, int start, int length)
		throws SAXException {
		//tempVal = "";
		//tempVal = new String(ch, start, length);
		tempVal.append(ch, start, length);
//		mCategory.info(
//			"After creation:"
//				+ tempVal
//				+ " ch lenght="
//				+ ch.length
//				+ " start:"
//				+ start
//				+ " length:"
//				+ length);

	}

	public void endElement(String uri, String localName, String qName)
		throws SAXException {

		if (mLog.isDebugEnabled()) {
			mLog.info("Reading end tag: " + qName);
		}

		if (qName.equalsIgnoreCase(ELEMENT_CUSTOMER)) {
			//add it to the list
			if (mVoCardNumberList != null) {
				if (mVoCardNumber.getCardNumberString() != null
					&& !mVoCardNumber.getCardNumberString().equals("")) {

					mVoCardNumberList.add(mVoCardNumber);
				} else {
					// Do not try to save this object
					return;
				}
			} else {
				mLog.error(
					"Customer list not initilized, start tag "
						+ ELEMENT_CUSTOMER_LIST
						+ " not found.");
			}
		} else if (mHeaderInfo != null && qName.equalsIgnoreCase(CAMPAIGN_ID)) {
			mHeaderInfo.append(tempVal);
		} else if (mHeaderInfo != null && qName.equalsIgnoreCase(PROJECT_ID)) {
			mHeaderInfo.append(" -- " + tempVal);
			mLog.info("Add to headerBuffer:" + tempVal);
		} else if (mHeaderInfo != null && qName.equalsIgnoreCase(PROJECT_NAME)) {
			mVoCardRange.setName(tempVal.toString());
			mHeaderInfo.append(" -- " + tempVal);
		} else if (mHeaderInfo != null && qName.equalsIgnoreCase(PROJECT_CREATED)) {
			mHeaderInfo.append(" -- " + tempVal);
		} else if (mVoCardNumber != null && qName.equalsIgnoreCase(FAMILY_CARD_NUMBER)) {
			vTrimmedCardNumber = trimZeros(tempVal.toString());
			mLog.info("Is leading zeros removed? :" + vTrimmedCardNumber);

			if (validateCardNumber(vTrimmedCardNumber)) {

				mVoCardNumber.setCardNumberString(vTrimmedCardNumber);
			}
		} else if (qName.equalsIgnoreCase(ELEMENT_CAMPAIGN_INFORMATION)) {
			mLog.info("Set headerBuffer:" + tempVal);
			mVoCardRange.setHeader(mHeaderInfo.toString());
		} else if (mVoMultipleSingleLoadInitial != null &&
				qName.equalsIgnoreCase(ELEMENT_CARD_AMOUNT_LIST)) {
			mVoMultipleSingleLoadInitial.setVoMultipleSingleLoadInitialCardAmountList(mVoMultipleSingleLoadInitialCardAmountList);
		} else if (mVoMultipleSingleLoadInitialCardAmountList != null &&
				qName.equalsIgnoreCase(ELEMENT_CARD_AMOUNT)) {
			if (mVoMultipleSingleLoadInitialCardAmount.getCardNumberString() != null
				&& !mVoMultipleSingleLoadInitialCardAmount.getCardNumberString().equals("")) {
				
				mVoMultipleSingleLoadInitialCardAmountList.add(mVoMultipleSingleLoadInitialCardAmount);
			}		
		} else if (mVoMultipleSingleLoadInitialCardAmount != null &&
				qName.equalsIgnoreCase(AMOUNT)) {
			mVoMultipleSingleLoadInitialCardAmount.setAmount(tempVal.toString());
		} else if (mVoMultipleSingleLoadInitialCardAmount != null &&
				qName.equalsIgnoreCase(CARD_NUMBER)) {
			
			vTrimmedCardNumber = trimZeros(tempVal.toString());
			mLog.info("Is leading zeros removed? :" + vTrimmedCardNumber);

			if (validateCardNumber(vTrimmedCardNumber)) {
				mVoMultipleSingleLoadInitialCardAmount.setCardNumberString(tempVal.toString());
			}
		} else if (mVoMultipleSingleLoadInitial != null && qName.equalsIgnoreCase(BU_TYPE)) {
			mVoMultipleSingleLoadInitial.setBuType(tempVal.toString());
		} else if (mVoMultipleSingleLoadInitial != null && qName.equalsIgnoreCase(BU_CODE)) {
			mVoMultipleSingleLoadInitial.setBuCode(tempVal.toString());
		} else if (mVoMultipleSingleLoadInitial != null && qName.equalsIgnoreCase(CURRENCY_CODE)) {
			mVoMultipleSingleLoadInitial.setCurrencyCode(tempVal.toString());
		} else if (mVoMultipleSingleLoadInitial != null && qName.equalsIgnoreCase(SINGLE_LOAD_NAME)) {
			mVoMultipleSingleLoadInitial.setName(tempVal.toString());
		}
		
		// Reset buffer
		tempVal.setLength(0);
	}

	/**
	 * @return
	 */
	public List<VoCardNumber> getMVoCardNumberList() {
		return mVoCardNumberList;
	}

	/**
	 * @return
	 */
	public VoCardRange getMVoCardRange() {
		return mVoCardRange;
	}

	/**
	 * @return
	 */
	public VoMultipleSingleLoadInitial getMVoMultipleSingleLoadInitial() {
		return mVoMultipleSingleLoadInitial;
	}

	/**
	 * @param list
	 */
	public void setMVoCardNumberList(List<VoCardNumber> list) {
		mVoCardNumberList = list;
	}

	/**
	 * @param range
	 */
	public void setMVoCardRange(VoCardRange range) {
		mVoCardRange = range;
	}

	/**
	 * @param singleLoad
	 */
	public void setMVoMultipleSingleLoadInitial(VoMultipleSingleLoadInitial singleLoad) {
		mVoMultipleSingleLoadInitial = singleLoad;
	}

	/**
	 * 
	 * @param pCardNumberString
	 * @return A formatted String were all the leading zeros have been removed
	 */
	private String trimZeros(String pCardNumberString) {
		//mCategory.info("Input before trim:" + pCardNumberString);
		if (pCardNumberString == null) {
			return null;
		}
		char[] chars = pCardNumberString.toCharArray();
		int index = 0;
		for (; index < pCardNumberString.trim().length(); index++) {
			if (chars[index] != '0') {
				break;
			}
		}
		return (index == 0)
			? pCardNumberString
			: pCardNumberString.substring(index);

	}

	private boolean validateCardNumber(String pCardNumberString) {
		if (!pCardNumberString.matches(ServiceImpl.CARD_NUMBER_REGEXP)) {
			mLog.warn(
				"Card number string '"
					+ pCardNumberString
					+ "' does not match regexp "
					+ ServiceImpl.CARD_NUMBER_REGEXP);

			return false;
		}
		if (!isValidCheckDigit(pCardNumberString)) {
			mLog.warn(
				"Card number string '"
					+ pCardNumberString
					+ "' has not a valid checkdigit");

			return false;
		}
		return true;

	}

	/**
	 * Validates if it is a valid number using Luhn (a.k.a Mod 10) formula. 
	 * @param pNumberWithCheck the number including the check digit
	 * @return
	 */
	private boolean isValidCheckDigit(String pNumberWithCheck) {

		int sum = 0;
		int nDigits = pNumberWithCheck.length();
		int parity = nDigits % 2;
		for (int i = 0; i < nDigits; i++) {

			int digit = Integer.parseInt("" + pNumberWithCheck.charAt(i));
			if (i % 2 == parity) {
				// It is a digit on a an ODD index (1,3,5,7,9,...) from the end, then multiplicate with 2.
				digit = digit * 2;
			}
			if (digit > 9) {
				// The digit is more then two digits, then reduce 9
				digit = digit - 9;
			}
			sum += digit;

		}
		return (sum % 10) == 0;
	}

}
