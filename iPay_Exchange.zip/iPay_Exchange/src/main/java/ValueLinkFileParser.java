/*
 * Created on 2007-aug-24
 *
 *
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 * Parser program for processing the raw file from VALUE-LINK and VALUE-LINK only!!
 * before the actual import to iPay
 * 
 * This program creates a new file according to the file format documentet
 * in iPay\Product_Doc\Requirements\DGL_iPayExchange_ExternalCardsFileDescription.doc 
 * which the BS BsImportExternalCards requires.
 * 
 * @author dalq
 *
 *
 */
public class ValueLinkFileParser {

	/**
	 * Log category for messages
	 */
	private final static Logger log = LoggerFactory.getLogger(ValueLinkFileParser.class);

	private static final String DELIMITER = ";";
	private static final String CURRENCY_CODE = "USD";
	private static final String BU_TYPE = "STO";
	private static final String REGEXP = "^[0-9]{16}$";
	private static final String DEFAULT_BU_CODE = "211";

	private File mInputFile = null;
	private File mOutputFile = null;
	private static ValueLinkFileParser mValueLinkFileParser = null;

	/**
	 *
	 */
	public ValueLinkFileParser() {
		super();

	}

	/**
	 * 
	 * @param args 1= Full path to inputfile to process 2 = Full path to outputfile
	 * 
	 */
	public static void main(String[] args) {
		// Set args
		mValueLinkFileParser = new ValueLinkFileParser();

		if (args.length < 2) {
            log.error(
				"No arguments found: [inputDir] [outputDir] must be applied");
		}
		// Full path to input file to parse
		if (args[0] != null) {
			// Inputfile to pars
			mValueLinkFileParser.mInputFile = new File(args[0]);
            log.info("Input file to parse: " + args[0]);

		}
		if (args[1] != null) {
			mValueLinkFileParser.mOutputFile = new File(args[1]);
            log.info("Output file to create: " + args[1]);

		}

		processFile(
			mValueLinkFileParser.mInputFile,
			mValueLinkFileParser.mOutputFile);

	}

	/**
	 * This method processes the import file and finaly writes the 
	 * new file set from the second argument to the application
	 * 
	 * This process collects all exceptions thrown and writes
	 * down the cause to the STO.
	 * 
	 * @param pInputFile  - Full path to the file to be processed
	 * @param pOutputFile - Full path to the file to be the ouputfile
	 */
	private static void processFile(File pInputFile, File pOutputFile) {
		//
		String vFileName = pInputFile.getName();
        log.info("Processing " + vFileName + "...");

		BufferedReader vReader = null;

		BufferedWriter vWriter = null;
		String vLine = null;
		String vNewLine = null;
		int vRowCount = 0;

		try {
			vReader =
				new BufferedReader(
					new InputStreamReader(new FileInputStream(pInputFile)));

			vWriter =
				new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(pOutputFile)));
			
			
			// Read first line
			vLine = vReader.readLine();

            log.info("Start....");
			while (vLine != null) {
				//
				vRowCount++;

				// Create new line
				vNewLine = mValueLinkFileParser.createOutputRow(vLine);

				// Write new line to outputfile
				vWriter.write(vNewLine);

				// Read next line
				vLine = vReader.readLine();
			}

            log.info("---------- Import finished -----------");
            log.info("----- Number of processed rows: " + vRowCount);

		} catch (Exception e) {
			// Catch all and return false
            log.error(
				pInputFile.getName()
					+ " could not be parsed. - Failed at row "
					+ vRowCount
					+ " Line info:"
					+ vLine,
				e);

		} finally {

			// Close file
			try {
				if (vReader != null)
					vReader.close();
				if (vWriter != null)
					vWriter.close();
			} catch (IOException e) {
                log.error(e.getLocalizedMessage());
			}
		}

	}

	/**
	 * 
	 * @param pStringToSplit
	 * @param pDelimiter
	 * @return
	 */
	private String[] SplitString(String pStringToSplit, String pDelimiter) {
		String[] vNewString = pStringToSplit.split(pDelimiter);
		return vNewString;

	}

	/**
	 * @param pLine
	 */
	private String createOutputRow(String pLine) throws Exception {

		StringBuffer vNewLine = new StringBuffer();

		String[] vSplitRow = mValueLinkFileParser.SplitString(pLine, ",");

		if (vSplitRow.length == 14) {

			// Pos 3 = BuCode
			// Pos 4 = CardNumber
			// Pos 11 = Original balance

			// Add Cardnumber
			checkCardNumber(vSplitRow[3].trim());
			vNewLine.append(vSplitRow[3].trim() + DELIMITER);

			// Add CurrencyCode
			vNewLine.append(CURRENCY_CODE + DELIMITER);

			// Add Original balance
			checkScale(vSplitRow[10].trim());
			vNewLine.append(vSplitRow[10].trim() + DELIMITER);

			// Add BuType
			vNewLine.append(BU_TYPE + DELIMITER);

			// Add BuCode
			vNewLine.append(createBuCode(vSplitRow[2]) + DELIMITER);

			// Add original line
			vNewLine.append(pLine + "\r\n");

		} else {
			//ValueLinkFileParser.mCategory.error(
			//	"Line not complete length: " + pLine);
			throw new Exception("Line not complete length: " + pLine);
		}

		return vNewLine.toString();
	}

	/**
	 * @param pBuCode
	 * @return
	 */
	private String createBuCode(String pBuCode) throws Exception {
		// BuCode must be 3digits, fill out with 0 from left
		//String vBuCode = ;
		if (pBuCode != null) {
			if (pBuCode.equals("0")) {
				// Set default value
				pBuCode = DEFAULT_BU_CODE;
			}
			while (pBuCode.length() < 3) {
				pBuCode = "0" + pBuCode;
			}

		} else {
			//ValueLinkFileParser.mCategory.error("No BuCode in line: ");
			throw new Exception("No BuCode in line");
		}

		return pBuCode;

	}

	/**
	 * Check the cardnumber with the regexp set
	 * @param vCardNumber
	 * @throws Exception
	 */
	private void checkCardNumber(String vCardNumber) throws Exception {

		// Does the external card number match the regexp?
		if (!vCardNumber.matches(REGEXP)) {
			throw new Exception(
				"The external card number "
					+ vCardNumber
					+ " does not match the regexp ");
		}

	}

	private void checkScale(String pOriginalAmount) throws Exception {
		BigDecimal vBD = new BigDecimal(pOriginalAmount);

		if (vBD.scale() != 2) {
			throw new Exception(
				"Original amount not correct scaled " + pOriginalAmount);
		}

		if (vBD.intValue() < 0 || (vBD.equals(new BigDecimal("0.00")))) {
			throw new Exception(
				"Original amount is equal to nothing = " + pOriginalAmount);
		}

	}

}
