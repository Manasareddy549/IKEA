package com.ikea.ebccardpaybatch1.batch;

import static junit.framework.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;
import com.ikea.framework.business.services.util.BSContext;
import com.ikea.framework.connector.UserProfile;
import com.ikea.framework.keygenerator.KeyGenerator;
import com.ikea.module.keygenerator.IkeaKeyGenerator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class CalculateKpiFunctionalTest extends
		AbstractValidatingBatchLauncherTests {
	@Autowired
	private SessionFactory mSessionFactory;

	@Autowired
	private JdbcTemplate mJdbcTemplate;

	@BeforeClass
	public static void oneTimeSetUp() {
		ContextHandler.setContext();
	}

	@Test
	public void testEmployeeKpiCalculation() throws Exception {
		String kpiInterval = "2009-05-20";
		String kpiType = "EMPLOYEE";
		String buCode = "107";
		String buType = "STO";

		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		IkeaKeyGenerator.setImplementation(new KeyGenerator() {

			int counter = 10000000;

			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}
		});

		setJobParameters(new JobParametersBuilder().addString("kpi.type",
				kpiType).addString("bu.type", buType).addString("bu.code",
				buCode).addString("kpi.interval", kpiInterval)
				.toJobParameters());

		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		int vActualNumberOfRows = mJdbcTemplate
				.queryForInt(
						"select count(kpi_id) from KPI_T where kpi_interval=? and kpi_type=? and bu_type=? and bu_code=?",
						new Object[] { kpiInterval, kpiType, buType, buCode });
		assertEquals(1, vActualNumberOfRows);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void whenCalculateCountryKpiIsRunThenCardAmountAndFromBuShouldBeSaved()
			throws Exception {
		String kpiInterval = "2009-10-22";
		String kpiType = "COUNTRY";
		String buCode = "227";
		String buType = "STO";

		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		IkeaKeyGenerator.setImplementation(new KeyGenerator() {

			int counter = 10000000;

			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}
		});

		setJobParameters(new JobParametersBuilder().addString("kpi.type",
				kpiType).addString("bu.type", buType).addString("bu.code",
				buCode).addString("kpi.interval", kpiInterval)
				.toJobParameters());

		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		List<Map<String,Object>> vActual = (List<Map<String,Object>>) mJdbcTemplate
				.query(
						"select credit_amount, debit_amount, card_credit_amount, card_debit_amount, from_bu_type, from_bu_code from KPI_T " +
						"where kpi_interval=? and kpi_type=? and bu_type=? and bu_code=? order by from_bu_code, source_system",
						new Object[] { kpiInterval, kpiType, buType, buCode },
						new RowMapper() {
							public Object mapRow(ResultSet pRs, int pArg1)
									throws SQLException {								
								
								Map<String, Object> vResult = new HashMap<String,Object>();
								vResult.put("credit_amount", pRs.getBigDecimal(1));
								vResult.put("debit_amount", pRs.getBigDecimal(2));
								vResult.put("card_credit_amount", pRs.getBigDecimal(3));
								vResult.put("card_debit_amount", pRs.getBigDecimal(4));
								vResult.put("from_bu_type", pRs.getString(5));
								vResult.put("from_bu_code", pRs.getString(6));
								
								return vResult;

							}
						});
		assertEquals(3, vActual.size());
		assertEquals(BigDecimal.valueOf(0), vActual.get(0).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(2), vActual.get(0).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(0).get("card_credit_amount"));
		assertEquals(BigDecimal.valueOf(20), vActual.get(0).get("card_debit_amount"));
		assertEquals("STO", vActual.get(0).get("from_bu_type"));
		assertEquals("107", vActual.get(0).get("from_bu_code"));
		
		assertEquals(BigDecimal.valueOf(0), vActual.get(1).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(1), vActual.get(1).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(1).get("card_credit_amount"));
		assertEquals(BigDecimal.valueOf(10), vActual.get(1).get("card_debit_amount"));
		assertEquals("STO", vActual.get(1).get("from_bu_type"));
		assertEquals("107", vActual.get(1).get("from_bu_code"));
		
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("card_credit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("card_debit_amount"));
		assertEquals(null, vActual.get(2).get("from_bu_type"));
		assertEquals(null, vActual.get(2).get("from_bu_code"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void whenCalculateKpiStoreIsRunThenAggregatesAndFromBuShouldBeSaved ()
			throws Exception {
		String kpiInterval = "2009-10-22";
		String kpiType = "STORE";
		String buCode = "227";
		String buType = "STO";

		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		IkeaKeyGenerator.setImplementation(new KeyGenerator() {

			int counter = 10000000;

			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}
		});

		setJobParameters(new JobParametersBuilder().addString("kpi.type",
				kpiType).addString("bu.type", buType).addString("bu.code",
				buCode).addString("kpi.interval", kpiInterval)
				.toJobParameters());

		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		List<Map<String,Object>> vActual = (List<Map<String,Object>>) mJdbcTemplate
				.query(
						"select credit_amount, debit_amount, credit_count, debit_count, from_bu_type, from_bu_code from KPI_T " +
						"where kpi_interval=? and kpi_type=? and bu_type=? and bu_code=? order by from_bu_code, source_system",
						new Object[] { kpiInterval, kpiType, buType, buCode },
						new RowMapper() {
							public Object mapRow(ResultSet pRs, int pArg1)
									throws SQLException {								
								
								Map<String, Object> vResult = new HashMap<String,Object>();
								vResult.put("credit_amount", pRs.getBigDecimal(1));
								vResult.put("debit_amount", pRs.getBigDecimal(2));
								vResult.put("credit_count", pRs.getBigDecimal(3));
								vResult.put("debit_count", pRs.getBigDecimal(4));
								vResult.put("from_bu_type", pRs.getString(5));
								vResult.put("from_bu_code", pRs.getString(6));
								
								return vResult;

							}
						});
		assertEquals(3, vActual.size());
		assertEquals(BigDecimal.valueOf(0), vActual.get(0).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(2), vActual.get(0).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(0).get("credit_count"));
		assertEquals(BigDecimal.valueOf(1), vActual.get(0).get("debit_count"));
		assertEquals("STO", vActual.get(0).get("from_bu_type"));
		assertEquals("107", vActual.get(0).get("from_bu_code"));
		
		assertEquals(BigDecimal.valueOf(0), vActual.get(1).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(1), vActual.get(1).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(1).get("credit_count"));
		assertEquals(BigDecimal.valueOf(1), vActual.get(1).get("debit_count"));
		assertEquals("STO", vActual.get(1).get("from_bu_type"));
		assertEquals("107", vActual.get(1).get("from_bu_code"));
		
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("credit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("debit_amount"));
		assertEquals(BigDecimal.valueOf(0), vActual.get(2).get("credit_count"));
		assertEquals(BigDecimal.valueOf(1), vActual.get(2).get("debit_count"));
		assertEquals(null, vActual.get(2).get("from_bu_type"));
		assertEquals(null, vActual.get(2).get("from_bu_code"));
	}


	@Override
	protected void validatePostConditions() throws Exception {
	}

}
