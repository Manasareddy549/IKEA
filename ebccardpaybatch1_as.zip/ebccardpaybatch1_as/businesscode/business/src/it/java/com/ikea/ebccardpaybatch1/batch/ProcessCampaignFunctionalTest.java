package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;
import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;
import com.ikea.framework.business.services.util.BSContext;
import com.ikea.framework.connector.UserProfile;
import com.ikea.framework.keygenerator.KeyGenerator;
import com.ikea.module.keygenerator.IkeaKeyGenerator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class ProcessCampaignFunctionalTest extends AbstractValidatingBatchLauncherTests {

	@Autowired
	private SessionFactory mSessionFactory;
	
	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
    @BeforeClass
    public static void oneTimeSetUp() {
    	ContextHandler.setContext();
    } 
    
	@Test
	public void testDontProcessCampaignsThatArentInStateProcessing() throws Exception {
		int campaignId = 3;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1","BsTest",vUserProfile,null));
		
		setJobParameters(new JobParametersBuilder().addString("campaign.id",Integer.toString(campaignId) ).toJobParameters());
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		String vActualState = (String) mJdbcTemplate.queryForObject("select campaign_state from campaign_T where campaign_id=?", new Object[]{campaignId}, String.class);
		Assert.assertEquals("INITIATED",vActualState);
	}
    
	@Test
	public void testProcessCampaignsFromProcessingToLocked() throws Exception {
		int campaignId = 4;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1","BsTest",vUserProfile,null));
		
		IkeaKeyGenerator.setImplementation(new KeyGenerator(){
			
			int counter=1000;
			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}});
		
		setJobParameters(new JobParametersBuilder().addString("campaign.id",Integer.toString(campaignId) ).toJobParameters());
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		String vActualState = (String) mJdbcTemplate.queryForObject("select campaign_state from campaign_T where campaign_id=?", new Object[]{campaignId}, String.class);
		Assert.assertEquals("LOCKED",vActualState);
	}
	
    
	@Test
	public void testProcessCampaignsFromProcessingToInitiated() throws Exception {
		int campaignId = 5;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1","BsTest",vUserProfile,null));
		
		IkeaKeyGenerator.setImplementation(new KeyGenerator(){
			
			int counter=10000;
			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}});
		
		setJobParameters(new JobParametersBuilder().addString("campaign.id",Integer.toString(campaignId) ).toJobParameters());
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		String vActualState = (String) mJdbcTemplate.queryForObject("select campaign_state from campaign_T where campaign_id=?", new Object[]{campaignId}, String.class);
		Assert.assertEquals("INITIATED",vActualState);
	}
	
	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
