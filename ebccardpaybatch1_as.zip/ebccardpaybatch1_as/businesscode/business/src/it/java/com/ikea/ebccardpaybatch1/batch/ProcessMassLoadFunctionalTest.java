package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;
import com.ikea.framework.business.services.util.BSContext;
import com.ikea.framework.connector.UserProfile;
import com.ikea.framework.keygenerator.KeyGenerator;
import com.ikea.module.keygenerator.IkeaKeyGenerator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class ProcessMassLoadFunctionalTest extends
		AbstractValidatingBatchLauncherTests {

	@Autowired
	public SessionFactory mSessionFactory;
	@Autowired
	public JdbcTemplate mJdbcTemplate;

	@BeforeClass
	public static void oneTimeSetUp() {
		ContextHandler.setContext();
	}

	@Test
	public void testDontProcessMassLoadsThatArentInStateProcessing()
			throws Exception {
		int massLoadId = 3;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		setJobParameters(new JobParametersBuilder().addString("mass.load.id",
				Integer.toString(massLoadId)).toJobParameters());
		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		String vActualState = (String) mJdbcTemplate.queryForObject(
				"select mass_load_state from mass_load_T where mass_load_id=?",
				new Object[] { massLoadId }, String.class);
		Assert.assertEquals("INITIATED", vActualState);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessMassLoadsFromProcessingToLocked() throws Exception {
		int massLoadId = 4;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		IkeaKeyGenerator.setImplementation(new KeyGenerator() {

			int counter = 1000;

			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
			}
		});

		setJobParameters(new JobParametersBuilder().addString("mass.load.id",
				Integer.toString(massLoadId)).toJobParameters());
		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		String vActualState = (String) mJdbcTemplate.queryForObject(
				"select mass_load_state from mass_load_T where mass_load_id=?",
				new Object[] { massLoadId }, String.class);
		Assert.assertEquals("LOCKED", vActualState);

		String vSqlQuery = "select ca.card_state, ca.currency_code, a.current_amount "
				+ "from card_t ca, card_number_range_t cnr, mass_load_t ml, amount_t a "
				+ "where (ml.mass_load_id = ? "
				+ "and ml.range_id = cnr.range_id "
				+ "and cnr.card_number_id = ca.card_number_id "
				+ "and ca.card_id = a.card_id)";

		Map<String, String> vActualResults = (Map<String, String>) mJdbcTemplate
				.queryForObject(vSqlQuery, new Object[] { massLoadId },
						new RowMapper() {
							public Object mapRow(ResultSet pRs, int pRowNum)
									throws SQLException {
								HashMap<String, String> vResult = new HashMap<String, String>();
								vResult.put("card_state", pRs.getString(1));
								vResult.put("currency_code", pRs.getString(2));
								vResult.put("current_amount", pRs.getString(3));
								return vResult;
							}
						});
		Assert.assertEquals("BOUND", vActualResults.get("card_state"));
		Assert.assertEquals("SEK", vActualResults.get("currency_code"));
		Assert.assertEquals("100", vActualResults.get("current_amount"));
	}

	@Test
	public void testProcessMassLoadsFromProcessingToUnLocked() throws Exception {
		int massLoadId = 5;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		setJobParameters(new JobParametersBuilder().addString("mass.load.id",
				Integer.toString(massLoadId)).toJobParameters());
		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		String vActualState = (String) mJdbcTemplate.queryForObject(
				"select mass_load_state from mass_load_T where mass_load_id=?",
				new Object[] { massLoadId }, String.class);
		Assert.assertEquals("INITIATED", vActualState);
	}

	@Test
	public void testProcessMassLoadsFromProcessingToWithDrawn()
			throws Exception {
		int massLoadId = 6;
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1", "BsTest",
				vUserProfile, null));

		setJobParameters(new JobParametersBuilder().addString("mass.load.id",
				Integer.toString(massLoadId)).toJobParameters());
		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to
		// the db.
		mSessionFactory.getCurrentSession().flush();

		String vActualState = (String) mJdbcTemplate.queryForObject(
				"select mass_load_state from mass_load_T where mass_load_id=?",
				new Object[] { massLoadId }, String.class);
		Assert.assertEquals("WITHDRAWN", vActualState);

	}

	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
