package com.ikea.ebccardpaybatch1.eicom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.framework.exception.IkeaException;

public class EicOmServiceMock implements EicOmService {

	private static final Logger mLog = LoggerFactory.getLogger(EicOmServiceMock.class);

	private WeeklySalesReport mActualSalesReport;
	
	public void sendWeeklySalesReport(WeeklySalesReport pSalesReports)
			throws IkeaException {
		mActualSalesReport = pSalesReports;
		mLog.info("Skipping call to EicOm3 for weeklysalesreport, year: "
				+ pSalesReports.getYear() + ", week: "
				+ pSalesReports.getWeek());
	}

	public WeeklySalesReport getActualSalesReport() {
		return mActualSalesReport;
	}

}
