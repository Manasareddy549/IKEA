package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpaybatch1.eicom.EicOmServiceMock;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class WeeklySalesReportFunctionalTest extends AbstractValidatingBatchLauncherTests {

	private SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
	private SimpleDateFormat weekFormat = new SimpleDateFormat("ww");
	private Date toDay = new Date();
	
	@Autowired
	private EicOmServiceMock mEicOmServiceMock;
	
	@Test
	public void testLaunchJob() throws Exception {
		String vYear = yearFormat.format(toDay);
		String vWeek = weekFormat.format(toDay);
		
		setJobParameters(new JobParametersBuilder().addString("year", vYear).addString("week", vWeek).toJobParameters());
		
		super.testLaunchJob();
		
		WeeklySalesReport vActualSalesReport = mEicOmServiceMock.getActualSalesReport();
		assertEquals(2, vActualSalesReport.getRows().size());
		assertEquals(vYear, vActualSalesReport.getYear());
		assertEquals(vWeek, vActualSalesReport.getWeek());
		assertEquals(BigDecimal.valueOf(551), vActualSalesReport.getRows().get(1).getAMOUNTINLOCALCURRENCY());
		assertEquals("107", vActualSalesReport.getRows().get(1).getBUCODE());
		assertEquals("STO", vActualSalesReport.getRows().get(1).getBUTYPE());
		assertEquals("SE", vActualSalesReport.getRows().get(1).getCOUNTRYCODE());
		assertEquals("SEK", vActualSalesReport.getRows().get(1).getCURRENCYCODE());
		assertEquals(BigDecimal.valueOf(11), vActualSalesReport.getRows().get(1).getNUMBEROFLOADTRANSACTIONS());
	}
	
	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
