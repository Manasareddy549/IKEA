package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;
import com.ikea.framework.business.services.util.BSContext;
import com.ikea.framework.connector.UserProfile;
import com.ikea.framework.keygenerator.KeyGenerator;
import com.ikea.module.keygenerator.IkeaKeyGenerator;
import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class RetrieveSiteDataFunctionalTest extends AbstractValidatingBatchLauncherTests {

	public static final String INSERT1 = "Insert into IPAY_BUSINESSUNITS_T (BU_CODE,BU_TYPE,BU_NAME,COUNTRY_CODE,COMPANY_CODE,COMPANY_NAME,TIMEZONE,CREATED_BY,CREATED_DATE_TIME,UPDATED_BY,UPDATED_DATE_TIME,VERSION_NO) values ('444','CSC','TEST CSC','SE','9999','SCS Company AB','Europe/Stockholm','thson1',to_timestamp('2012-09-17','RRRR-MM-DD HH24:MI:SSXFF'),null,null,0)";
	public static final String INSERT2 = "Insert into IPAY_BUSINESSUNITS_T (BU_CODE,BU_TYPE,BU_NAME,COUNTRY_CODE,COMPANY_CODE,COMPANY_NAME,TIMEZONE,CREATED_BY,CREATED_DATE_TIME,UPDATED_BY,UPDATED_DATE_TIME,VERSION_NO) values ('447','STO','Funabashi Store JP','JP','3400','IKEA JAPAN KABUSHIKI KAISHA','Europe/Stockholm','thson1',to_timestamp('2012-09-17','RRRR-MM-DD HH24:MI:SSXFF'),'thson1',to_timestamp('2012-09-17','RRRR-MM-DD HH24:MI:SSXFF'),1)";
	public static final String INSERT3 = "Insert into IPAY_BUSINESSUNITS_T (BU_CODE,BU_TYPE,BU_NAME,COUNTRY_CODE,COMPANY_CODE,COMPANY_NAME,TIMEZONE,CREATED_BY,CREATED_DATE_TIME,UPDATED_BY,UPDATED_DATE_TIME,VERSION_NO) values ('428','STO','ES Asturas store','ES',null,null,'Europe/Madrid','goyll',to_timestamp('2012-09-17 09:36:45,000000000','RRRR-MM-DD HH24:MI:SS,FF'),'thson1',to_timestamp('2012-09-17 16:07:46,000000000','RRRR-MM-DD HH24:MI:SS,FF'),1)";
	
	@Autowired
	private SessionFactory mSessionFactory;
	
	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
    @BeforeClass
    public static void oneTimeSetUp() {
    	ContextHandler.setContext();
    }   
    
	@SuppressWarnings("unchecked")
	@Test
	public void testLaunchJob() throws Exception {
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1","BsTest",vUserProfile,null));
		
		IkeaKeyGenerator.setImplementation(new KeyGenerator(){
			
			int counter=2;
			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
		}});
		mJdbcTemplate.execute("delete from IPAY_BUSINESSUNITs_T");
		mJdbcTemplate.execute("commit");
		mJdbcTemplate.execute(INSERT1);
		mJdbcTemplate.execute(INSERT2);
		mJdbcTemplate.execute(INSERT3);
		mJdbcTemplate.execute("commit");
		
		setJobParameters(new JobParametersBuilder().addDate("trigger.timestamp", new Date()).toJobParameters());
		
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		
		int vActualNumberOfRows = mJdbcTemplate.queryForInt("select count(*) from IPAY_BUSINESSUNITS_T");
		Assert.assertEquals(5,vActualNumberOfRows);
		
		List tempList = mJdbcTemplate.queryForList("select* from IPAY_BUSINESSUNITS_T " );
		Map<String, IpayBusinessUnits> resultMap = getResultMap (tempList);
		
		//Existing row in db with correct data. This row must be unchanged
		IpayBusinessUnits testRow = resultMap.get("CSC|444");
		Assert.assertTrue(equals(testRow,"TEST CSC","SE", "9999", "SCS Company AB", "Europe/Stockholm" ));

		//Existing row in db with wrong time zone. Time zone must have been updated from CDS
		testRow = resultMap.get("STO|447");
		Assert.assertTrue(equals(testRow,"Funabashi Store JP","JP", "3400", "IKEA JAPAN KABUSHIKI KAISHA", "Asia/Tokyo"));

		//Existing row in db with no company information. CompanyCode and ConmpanyName must have been set from CBD
		testRow = resultMap.get("STO|428");
		Assert.assertTrue(equals(testRow,"ES Asturas store","ES", "2600", "IKEA IBERICA S.A.", "Europe/Madrid" ));

		//New row. CompanyCode and ConmpanyName should be null. No info in CBD
		testRow = resultMap.get("STO|107");
		Assert.assertTrue(equals(testRow,"Helsingborg store","GB", null, null , "Europe/Stockholm" ));
		
		//New row. Must match CDS and CBD data. 
		testRow = resultMap.get("STO|045");
		Assert.assertTrue(equals(testRow,"Singapore Store (045)","SG", "7029", "IKANO PTE LTD", "Asia/Singapore" ));

	}

	@Override
	protected void validatePreConditions() throws Exception {
		
	}
	
	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}
	
	@SuppressWarnings("unchecked")
	private Map<String,IpayBusinessUnits> getResultMap(List pList) {
		
		Map<String,IpayBusinessUnits > vMap = new HashMap<String,IpayBusinessUnits>();
		
		if(pList==null){
			return vMap;
		}
		
		for (Object object:pList){
		   Map vRow = (Map) object;
		   IpayBusinessUnits vBu = new IpayBusinessUnits();
		   String key = vRow.get("bu_type") + "|" + vRow.get("bu_code");
		   vBu.setBuName((String) vRow.get("bu_name"));
		   vBu.setCountryCode((String) vRow.get("country_code"));
		   vBu.setCompanyName((String) vRow.get("company_name"));
		   vBu.setCompanyCode((String) vRow.get("company_code"));
		   vBu.setTimeZone((String) vRow.get("timezone"));
		   vMap.put(key,vBu);
		}
				
		return vMap;
	}
	private boolean equals(IpayBusinessUnits pResult, String pBuName, String pCountryCode, String pCompanyCode,
			String CompanyName, String pTimeZone) {
		
		if(pResult==null){
			return false;
		}
	
		boolean vTheSame = false;
		if(equals(pResult.getBuName(),pBuName) &&
		   equals(pResult.getCountryCode(),pCountryCode) &&
		   equals(pResult.getCompanyCode(),pCompanyCode) &&
		   equals(pResult.getCompanyName(),CompanyName) &&
		   equals(pResult.getTimeZone(),pTimeZone)){
		   vTheSame=true;
		}
			
		return vTheSame;
		
	}

	private boolean equals(String s1,String s2){
		
		if (s1==null && s2==null){
			return true;
		}
		
		if (s1!=null && s1.equals(s2)){
			return true;
		}
		return false;
	}
}
