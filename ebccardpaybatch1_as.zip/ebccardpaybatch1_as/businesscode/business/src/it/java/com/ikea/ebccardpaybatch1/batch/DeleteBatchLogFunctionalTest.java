package com.ikea.ebccardpaybatch1.batch;

import static junit.framework.Assert.assertEquals;

import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class DeleteBatchLogFunctionalTest extends AbstractValidatingBatchLauncherTests {

	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
    @BeforeClass
    public static void oneTimeSetUp() {
    	ContextHandler.setContext();
    } 
    
	@Test
	public void testDeleteJobInfoForAllOlderJobs() throws Exception {
		setJobParameters(new JobParametersBuilder().addString("days.to.keep","30").addDate("trigger.timestamp", new Date()).toJobParameters());
		super.testLaunchJob();
		
		Integer vNumberOfInstanceRows = (Integer) mJdbcTemplate.queryForObject("select count(*) from batch_job_instance", Integer.class);
		assertEquals(2,vNumberOfInstanceRows.intValue());

		Integer vNumberOfExecutionContextRows = (Integer) mJdbcTemplate.queryForObject("select count(*) from batch_job_execution_context", Integer.class);
		assertEquals(2,vNumberOfExecutionContextRows.intValue());

		Integer vNumberOfStepExecutionsRows = (Integer) mJdbcTemplate.queryForObject("select count(*) from batch_step_execution", Integer.class);
		assertEquals(1,vNumberOfStepExecutionsRows.intValue());
	}

	@Override
	protected void validatePostConditions() throws Exception {
	}

}
