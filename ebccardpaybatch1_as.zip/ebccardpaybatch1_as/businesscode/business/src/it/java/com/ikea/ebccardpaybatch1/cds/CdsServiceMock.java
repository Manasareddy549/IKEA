package com.ikea.ebccardpaybatch1.cds;

import java.util.HashMap;
import java.util.Map;

import com.ikea.ebccardpay1.cardpayment.utils.Unit;
import com.ikea.ebccardpaybatch1.cds.CdsService;

public class CdsServiceMock implements CdsService {
	
	private Map<String,Unit> mUnitMap =null;
	
	public CdsServiceMock() {
		super();
		
		mUnitMap = new HashMap<String,Unit>();
		mUnitMap.put("CSC|444",newUnit("CSC", "444", "TEST CSC", "SE", "Europe/Stockholm"));
		mUnitMap.put("STO|447",newUnit("STO", "447", "Funabashi Store JP", "JP", "Asia/Tokyo"));
		mUnitMap.put("STO|428",newUnit("STO", "428", "ES Asturas store", "ES", "Europe/Madrid"));
		mUnitMap.put("STO|107",newUnit("STO", "107", "Helsingborg store", "GB", "Europe/Stockholm"));
		mUnitMap.put("STO|045",newUnit("STO", "045", "Singapore Store (045)", "SG", "Asia/Singapore"));
	}

	public Map<String, Unit> GetAllBusinessUnitsForIpay() throws Exception {
		
		return mUnitMap;
	}

	private Unit newUnit(String pBuType, String pBuCode, String pSiteName, String pCountryCode, String pTimeZone){

		Unit unit = new Unit();
		unit.setBuType(pBuType);
		unit.setBuCode(pBuCode);
		unit.setSiteName(pSiteName);
		unit.setCountryCode(pCountryCode);
		unit.setTimeZone(pTimeZone);
		return unit;
	}
}

