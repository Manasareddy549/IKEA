package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class CancelUnAcknowledgedTransactionsFunctionalTest extends AbstractValidatingBatchLauncherTests {

	@Autowired
	private SessionFactory mSessionFactory;
	
	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
	@SuppressWarnings("unchecked")
	@Test
	public void testLaunchJob() throws Exception {
		Long referenceCheckId = new Long("1");

		setJobParameters(new JobParametersBuilder().addDate("trigger.timestamp", new Date()).toJobParameters());
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		// Assert the changed state of the only referencecheck that should be modified
		Map<String,String> vActualReferenceCheck = (Map<String, String>) mJdbcTemplate.queryForObject("select cancelled, waiting_ack, transaction_no from reference_check_T where reference_check_id=?", new Object[]{referenceCheckId}, new RowMapper() {
			public Object mapRow(ResultSet pRs, int pRowNum)
					throws SQLException {
				HashMap<String, String> vResult = new HashMap<String, String>();
				vResult.put("cancelled", pRs.getString(1));
				vResult.put("waiting_ack", pRs.getString(2));
				vResult.put("transaction_no", pRs.getString(3));
				return vResult;
			}});
		Assert.assertEquals("Y",vActualReferenceCheck.get("cancelled"));
		Assert.assertEquals("N",vActualReferenceCheck.get("waiting_ack"));
		
		// Assert that a new transaction is written.
		String vActualTransactionStatus = (String) mJdbcTemplate.queryForObject("select cancelled from transaction_t where transaction_no=?", new Object[]{vActualReferenceCheck.get("transaction_no")}, String.class);
		Assert.assertEquals("Y", vActualTransactionStatus);
	}

	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
