package com.ikea.ebccardpaybatch1.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.cardpayment.ipay.common.constant.BatchJobType;

@TransactionConfiguration(defaultRollback = true)
@Transactional
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/CronJobSchedulerTest-context.xml" })
public class CronJobSchedulerTest {

	@Autowired
	private CronJobScheduler cronJobScheduler;

	@Test
	public void whenFindActiveJobCreatorsWithNoExactDateThenReturnAtLeastSixJobCreators()
			throws Exception {
		List<JobCreator> jobCreators = cronJobScheduler.findActiveJobCreators();
		assertNotNull(jobCreators);
		assertTrue(6 <= jobCreators.size());
	}

	@Test
	public void whenFindActiveJobCreatorsWhenFirstDayOfMonthThenReturnSevenJobCreators()
			throws Exception {
		DateTime firstDayOfMonth = parseDateTime("2010-04-01 06:12:00");
		cronJobScheduler
				.setExactCalendar(firstDayOfMonth.toGregorianCalendar());
		List<JobCreator> jobCreators = cronJobScheduler.findActiveJobCreators();

		assertNotNull(jobCreators);
		assertEquals(7, jobCreators.size());

		boolean foundUpdateFromCbdJobCreator = false;
		for (JobCreator vJobCreator : jobCreators) {
			if (vJobCreator instanceof SimpleJobCreator
					&& ((SimpleJobCreator) vJobCreator).getJobType() == BatchJobType.updateExchangeRateFromCbdJob) {
				foundUpdateFromCbdJobCreator = true;
			}
		}
		assertTrue(
				"Couldn't find the expexcted updateExchangeRateFromCbdJobCreator in the list",
				foundUpdateFromCbdJobCreator);
	}

	@Test
	public void whenFindActiveJobCreatorsWhenMondayThenReturnSevenJobCreators()
			throws Exception {
		DateTime firstDayOfMonth = parseDateTime("2010-01-11 06:00:00");
		cronJobScheduler
				.setExactCalendar(firstDayOfMonth.toGregorianCalendar());
		List<JobCreator> jobCreators = cronJobScheduler.findActiveJobCreators();

		assertNotNull(jobCreators);
		assertEquals(7, jobCreators.size());

		boolean foundWeeklySalesJobCreator = false;
		for (JobCreator vJobCreator : jobCreators) {
			if (vJobCreator instanceof WeeklySalesReportJobCreator) {
				foundWeeklySalesJobCreator = true;
			}
		}
		assertTrue(
				"Couldn't find the expexcted weeklySalesReportJobCreator in the list",
				foundWeeklySalesJobCreator);
	}

	@Test
	public void whenFindActiveJobCreatorsWhenMondayIsFirstDayOfMonthThenReturnEightJobCreators()
			throws Exception {
		DateTime firstDayOfMonth = parseDateTime("2010-02-01 06:01:00");
		cronJobScheduler
				.setExactCalendar(firstDayOfMonth.toGregorianCalendar());
		List<JobCreator> jobCreators = cronJobScheduler.findActiveJobCreators();

		assertNotNull(jobCreators);
		assertEquals(8, jobCreators.size());

		boolean foundWeeklySalesJobCreator = false;
		boolean foundUpdateFromCbdJobCreator = false;
		for (JobCreator vJobCreator : jobCreators) {
			if (vJobCreator instanceof WeeklySalesReportJobCreator) {
				foundWeeklySalesJobCreator = true;
			}
			if (vJobCreator instanceof SimpleJobCreator
					&& ((SimpleJobCreator) vJobCreator).getJobType() == BatchJobType.updateExchangeRateFromCbdJob) {
				foundUpdateFromCbdJobCreator = true;
			}
		}
		assertTrue(
				"Couldn't find the expexcted weeklySalesReportJobCreator in the list",
				foundWeeklySalesJobCreator);
		assertTrue(
				"Couldn't find the expexcted updateExchangeRateFromCbdJobCreator in the list",
				foundUpdateFromCbdJobCreator);
	}
	

	@Test
	public void whenFindActiveJobCreatorsWhenMondayButWrongHourThenReturnSixJobCreators()
			throws Exception {
		DateTime firstDayOfMonth = parseDateTime("2010-01-11 07:00:00");
		cronJobScheduler
				.setExactCalendar(firstDayOfMonth.toGregorianCalendar());
		List<JobCreator> jobCreators = cronJobScheduler.findActiveJobCreators();

		assertNotNull(jobCreators);
		assertEquals(6, jobCreators.size());

		boolean foundWeeklySalesJobCreator = false;
		for (JobCreator vJobCreator : jobCreators) {
			if (vJobCreator instanceof WeeklySalesReportJobCreator) {
				foundWeeklySalesJobCreator = true;
			}
		}
		assertTrue(
				"Shouldn't find the weeklySalesReportJobCreator in the list",
				!foundWeeklySalesJobCreator);
	}
	
	private static DateTime parseDateTime(String pYYYYMMDD_HHMMSS) {
		DateTime vDateTime = new DateTime(Integer.parseInt(pYYYYMMDD_HHMMSS
				.substring(0, 4)), Integer.parseInt(pYYYYMMDD_HHMMSS.substring(
				5, 7)), Integer.parseInt(pYYYYMMDD_HHMMSS.substring(8, 10)),
				Integer.parseInt(pYYYYMMDD_HHMMSS.substring(11, 13)), Integer
						.parseInt(pYYYYMMDD_HHMMSS.substring(14, 16)), Integer
						.parseInt(pYYYYMMDD_HHMMSS.substring(17, 19)), 0,
				DateTimeZone.UTC);
		return vDateTime;
	}
}
