package com.ikea.ebccardpaybatch1.cbd;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.ikea.framework.exception.IkeaException;

public class CbdServiceMock implements CbdService {

	public CbdServiceMock() {
		super();
		mCompanyMap = new HashMap<String, Company>();
		mCompanyMap.put("STO:045", new Company("7029", "IKANO PTE LTD"));
		mCompanyMap.put("STO:428", new Company("2600", "IKEA IBERICA S.A."));
		mCompanyMap.put("STO:447", new Company("3400", "IKEA JAPAN KABUSHIKI KAISHA"));
	}

	public CbdExchangeRatesForCurrencies getExchangeRatesForCurrencies(
			Set<String> pCurrencyCodes) throws IkeaException {

		CbdExchangeRatesForCurrencies vCbdExchangeRatesForCurrencies = new CbdExchangeRatesForCurrencies();
		CbdExchangeRates vCbdExchangeRatesForSek = new CbdExchangeRates();
		vCbdExchangeRatesForSek.setExchangeRate("EUR", new Double(11.1));
		vCbdExchangeRatesForCurrencies.setExchangeRatesForCurrency("SEK",
				vCbdExchangeRatesForSek);
		CbdExchangeRates vCbdExchangeRatesForEur = new CbdExchangeRates();
		vCbdExchangeRatesForEur.setExchangeRate("SEK", new Double(0.09));
		vCbdExchangeRatesForCurrencies.setExchangeRatesForCurrency("EUR",
				vCbdExchangeRatesForEur);
		return vCbdExchangeRatesForCurrencies;
	}

	private Map<String, Company> mCompanyMap;

	public Company getCompanyForBusinessUnit(String buType, String buCode)
			throws IkeaException {
		return mCompanyMap.get(buType + ":" + buCode);
	}

}
