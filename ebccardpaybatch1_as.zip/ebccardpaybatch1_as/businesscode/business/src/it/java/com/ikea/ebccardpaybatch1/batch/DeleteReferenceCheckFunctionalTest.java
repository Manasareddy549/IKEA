package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class DeleteReferenceCheckFunctionalTest extends AbstractValidatingBatchLauncherTests {

	@Autowired
	private SessionFactory mSessionFactory;
	
	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
	@Test
	public void testLaunchJob() throws Exception {
		Long referenceCheckId = new Long("2");
		setJobParameters(new JobParametersBuilder().addDate("trigger.timestamp", new Date()).toJobParameters());
		super.testLaunchJob();

		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		// Assert the changed state of the only referencecheck that should be modified
		int vActualNumberReferenceChecks = mJdbcTemplate.queryForInt("select count(reference_check_id) from reference_check_T where reference_check_id=?", new Object[]{referenceCheckId});
		Assert.assertEquals(0,vActualNumberReferenceChecks);
		
	}

	@Override
	protected void validatePreConditions() throws Exception {
		
	}
	
	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
