package com.ikea.ebccardpaybatch1.batch;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ikea.framework.beans.spring.ContextHandler;
import com.ikea.framework.business.services.util.BSContext;
import com.ikea.framework.connector.UserProfile;
import com.ikea.framework.keygenerator.KeyGenerator;
import com.ikea.module.keygenerator.IkeaKeyGenerator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class UpdateExchangeRateFromCbdFunctionalTest extends AbstractValidatingBatchLauncherTests {

	@Autowired
	private SessionFactory mSessionFactory;
	
	@Autowired
	private JdbcTemplate mJdbcTemplate;
	
    @BeforeClass
    public static void oneTimeSetUp() {
    	ContextHandler.setContext();
    }    
    
	@Test
	public void testLaunchJob() throws Exception {
		UserProfile vUserProfile = new UserProfile();
		vUserProfile.setUID("itests");
		BSContext.setContext(new BSContext("EbcCardPayBatch1","BsTest",vUserProfile,null));
		
		IkeaKeyGenerator.setImplementation(new KeyGenerator(){
			
			int counter=2;
			public long getNextKey(String pEBCName, String pSequenceName) {
				return counter++;
		}});
		
		setJobParameters(new JobParametersBuilder().addDate("trigger.timestamp", new Date()).toJobParameters());
		
		super.testLaunchJob();
		
		// Make sure that Hibernate has flushed the new entities from memory to the db.
		mSessionFactory.getCurrentSession().flush();
		
		int vActualNumberOfRows = mJdbcTemplate.queryForInt("select count(exchange_rate_id) from EXCHANGE_RATE_T");
		Assert.assertEquals(2,vActualNumberOfRows);
		
		Double actualExchangeRate = (Double) mJdbcTemplate.queryForObject("select exchange_rate from exchange_rate_t where from_currency_code=? and to_currency_code=?", new Object[]{"SEK", "EUR"}, Double.class);
		Assert.assertEquals(11.1, actualExchangeRate);
	}

	@Override
	protected void validatePreConditions() throws Exception {
		
	}
	
	@Override
	protected void validatePostConditions() throws Exception {
		assertTrue(true);
	}

}
