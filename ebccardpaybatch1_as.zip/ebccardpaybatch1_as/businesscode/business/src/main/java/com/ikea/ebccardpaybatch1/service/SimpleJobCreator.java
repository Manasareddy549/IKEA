package com.ikea.ebccardpaybatch1.service;

import com.ikea.ebccardpay1.common.*;

public class SimpleJobCreator extends AbstractJobCreator {

	private BatchJobType jobType;
	
	public BatchJobType getJobType() {
		return jobType;
	}

	public void setJobTypeName(String pJobTypeName) {
		jobType = BatchJobType.valueOf(pJobTypeName);
	}

	public void createNewJobs() {
		sendAsyncJobExecutionRequest(jobType,null);
	}
}
