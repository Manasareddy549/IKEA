package com.ikea.ebccardpaybatch1.service;

import java.util.List;

import org.springframework.batch.core.JobParameters;

import com.ikea.ebccardpaybatch1.utils.EbccardpayBatchJobType;



public interface BatchExecutor {

	public void execute(EbccardpayBatchJobType batchJobType, JobParameters jobParameters);
	public List<Throwable> getExceptionList();

}