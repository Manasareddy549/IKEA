package com.ikea.ebccardpaybatch1.cds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTimeZone;

import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpay1.cardpayment.utils.Unit;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.spring.BeanFactory;
import com.ikea.eicywp01.client.bs.BsFindSite;
import com.ikea.eicywp01.client.bs.BsGetSite;
import com.ikea.eicywp01.client.vo.VoBusinessUnit;
import com.ikea.eicywp01.client.vo.VoSite;
import com.ikea.eicywp01.client.vo.VoSiteDetail;
import com.ikea.eicywp01.client.vo.VoSiteFindCriteria;
import com.ikea.eicywp01.client.vo.VoSiteKey;

public class CdsServiceBsImpl implements CdsService {
	
	private final static Logger mLog =
			LoggerFactory.getLogger(CdsServiceBsImpl.class);
	
	private static final String DEFAULT_TIMEZONE = "Europe/Stockholm";
	
	private static String BU_TYPE_STO = "STO";

	private static String BU_TYPE_SO = "SO";

	private static String BU_TYPE_CSC = "CSC";
	
	private static String EBC_NAME = "EBCCARDPAYBATCH1";

	/**
	 * Will get all sites from CDS and put them in mUnitMap
	 */
	public  Map<String, Unit> GetAllBusinessUnitsForIpay() throws Exception {
		
			try {			
				// Get all sites that have got BU type 'STO'.
				List<VoSiteFindCriteria> vList = new ArrayList<VoSiteFindCriteria>();
				VoSiteFindCriteria vVoSiteFindCriteria = new VoSiteFindCriteria();
				vVoSiteFindCriteria.setBusinessUnitType(BU_TYPE_STO);
				vList.add(vVoSiteFindCriteria);

				// Get all sites that have got BU type 'SO'.
				vVoSiteFindCriteria = new VoSiteFindCriteria();
				vVoSiteFindCriteria.setBusinessUnitType(BU_TYPE_SO);
				vList.add(vVoSiteFindCriteria);

				// Get all sites that have got BU type 'CSC'.
				vVoSiteFindCriteria = new VoSiteFindCriteria();
				vVoSiteFindCriteria.setBusinessUnitType(BU_TYPE_CSC);
				vList.add(vVoSiteFindCriteria);

				BsFindSite vBs = new BsFindSite();
				vBs.setVoSiteFindCriteriaList(vList);

				BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
				vBsExecuter.executeBs(vBs);
//				EBBConnector vEBBConnector = new EBBConnector();
//				vEBBConnector.setUserProfile(
//					EBCManager.getEBCContext(EBC_NAME).getDefaultUserProfile());
//				if (mLog.isInfoEnabled()) {
//					mLog.info(
//						"UserId "
//							+ vEBBConnector.getUserProfile().getUID()
//							+ " RunAs "
//							+ vEBBConnector.getUserProfile().getRunAsUID());
//				}
//				vEBBConnector.executeBs(vBs);

				Map<String, Unit> vResultMap = fetchDetails(vBs.getVoSiteList());
				return vResultMap;

			} catch (Exception e) {
				mLog.error("Could not get sites from EICYWP", e);
				throw e;
			}
	}
		/**
		 * @param pVoSiteList
		 * @throws IkeaException
		 */
		protected Map<String, Unit> fetchDetails(List<VoSite> pVoSiteList) throws Exception {

			if (pVoSiteList == null || pVoSiteList.size() == 0) {
				throw new IkeaException("No sites found with BU type STO!");
			}

			Map<String,Unit>  vUnitMap= new HashMap<String, Unit>();
			
			for (VoSite vVoSite : getVoSiteCollection(pVoSiteList)) {
				
				mLog.debug("Found site " + vVoSite.getSiteName());

				// Get the details for this site
				VoSiteKey vVoSiteKey = new VoSiteKey();
				vVoSiteKey.setSiteName(vVoSite.getSiteName());
				BsGetSite vBs = new BsGetSite();
				try {
				vBs.setVoSiteKey(vVoSiteKey);
				
				BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
				vBsExecuter.executeBs(vBs);
				
//				vEBBConnector.setUserProfile(
//					EBCManager.getEBCContext(EBC_NAME).getDefaultUserProfile());
//				if (mLog.isInfoEnabled()) {
//					mLog.info(
//						"UserId "
//							+ vEBBConnector.getUserProfile().getUID()
//							+ " RunAs "
//							+ vEBBConnector.getUserProfile().getRunAsUID());
//				}
				
				VoSiteDetail vVoSiteDetail = vBs.getVoSiteDetail();

				Unit vUnit = new Unit();
				vUnit.setSiteName(vVoSiteDetail.getSiteName());
				vUnit.setCountryCode(vVoSiteDetail.getCountry());
				vUnit.setTimeZone(vVoSiteDetail.getTimeZone());

				// Get BUs for this site
				if (vVoSiteDetail.getVoBusinessUnitList() != null) {
					for (VoBusinessUnit vVoBusinessUnit : getVoBusinessUnitCollection(vVoSiteDetail.getVoBusinessUnitList())) {

						if (BU_TYPE_STO
							.equals(vVoBusinessUnit.getBusinessUnitType())
							|| BU_TYPE_SO.equals(
								vVoBusinessUnit.getBusinessUnitType())
							|| BU_TYPE_CSC.equals(
								vVoBusinessUnit.getBusinessUnitType())) {

							// We have found a store!

							// Make a copy in case we find more then one STO on this site.
							Unit vNewUnit = (Unit) vUnit.clone();
							vUnit.setBuType(vVoBusinessUnit.getBusinessUnitType());
							vUnit.setBuCode(vVoBusinessUnit.getBusinessUnitCode());
							addUnit(vUnitMap, vUnit);
							vUnit = vNewUnit;
						}
					}
				}
			} catch (Exception e) {
				mLog.error("RetrieveSiteDataJob ERROR : failed while retriving site details for ["
						+ vBs.getVoSiteKey().getSiteName()+"] from CDS. Error message : "+e.getMessage());
			}

			}

		return vUnitMap;
	}
		
		/**
		 * @param pUnit
		 * @throws IkeaException
		 */
	protected void addUnit(Map<String,Unit> pUnitMap, Unit pUnit) throws IkeaException {

		if (mLog.isDebugEnabled()) {
			mLog.debug("Unit: " + pUnit.getSiteName() + " "
					+ pUnit.getCountryCode() + " " + pUnit.getBuType() + " "
					+ pUnit.getBuCode() + " " + pUnit.getTimeZone());
		}

		// Check country code
		if (pUnit.getCountryCode() == null
				|| pUnit.getCountryCode().length() == 0) {
			if (mLog.isInfoEnabled()) {
				mLog.info("Found a site without a country code set. Site: "
						+ pUnit.getSiteName() + " BU " + pUnit.getBuType()
						+ " " + pUnit.getBuCode() + ". Skipping this BU.");
			}
			return;
		}

		// Check the time zone
		if (pUnit.getTimeZone() == null || pUnit.getTimeZone().length() == 0) {
			if (mLog.isInfoEnabled()) {
				mLog.info("Found a site without a time zone set. Site: "
						+ pUnit.getSiteName() + " BU " + pUnit.getBuType()
						+ " " + pUnit.getBuCode() + ". Using default value = " + DEFAULT_TIMEZONE + ".");
			}
			pUnit.setTimeZone(DEFAULT_TIMEZONE);
		}

		// Check if it is a valid time zone using Joda Time (if it is one.
		try {
			DateTimeZone vZone = Dates.dateTimeZoneForId(pUnit.getTimeZone());
			if (mLog.isDebugEnabled()) {
				mLog.debug("Time zone id " + pUnit.getTimeZone()
						+ " gives time zone " + vZone);
			}
		} catch (Exception e) {
			mLog
					.error("Found a site with an invalid time zone set. Site: "
							+ pUnit.getSiteName()
							+ " BU "
							+ pUnit.getBuType()
							+ " "
							+ pUnit.getBuCode()
							+ ". Time zone ID from EICYWP: "
							+ pUnit.getTimeZone()
							+ " (the time zone database for this EBC is probably not updated to latest from CDS). Skipping this BU.");
			return;
		}

		// Check if this BU already exists, then it is connected to two sites in CDS.
		String vKey = key(pUnit.getBuType(), pUnit.getBuCode());
		if (pUnitMap.containsKey(vKey)) {
			Unit vOld = (Unit) pUnitMap.get(vKey);

			if (mLog.isDebugEnabled()) {
				mLog.debug("BU " + pUnit.getBuType() + " " + pUnit.getBuCode()
						+ " is conneted to two sites: " + pUnit.getSiteName()
						+ " and " + vOld.getSiteName() + ". Using "
						+ pUnit.getSiteName());
			}
		}
		// Add unit
		pUnitMap.put(vKey, pUnit);
	}

	@SuppressWarnings("unchecked")
	private List<VoSite> getVoSiteCollection(List<VoSite> pVoSiteList) {
		return pVoSiteList;
	}

	@SuppressWarnings("unchecked")
	private List<VoBusinessUnit> getVoBusinessUnitCollection(List<VoBusinessUnit> pVoBusinessUnitList) {
		return pVoBusinessUnitList;
	}
	
	/**
	 * Creates the key
	 * @param pBuType
	 * @param pBuCode
	 * @return
	 */
	protected String key(String pBuType, String pBuCode) {
		return pBuType + "|" + pBuCode;
	}
}
