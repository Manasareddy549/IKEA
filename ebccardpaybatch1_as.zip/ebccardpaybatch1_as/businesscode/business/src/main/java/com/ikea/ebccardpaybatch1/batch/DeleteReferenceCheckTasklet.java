package com.ikea.ebccardpaybatch1.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;

public class DeleteReferenceCheckTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(DeleteReferenceCheckTasklet.class);

	private BefReferenceCheck mBefReferenceCheck;

	private Units mUnits;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {

		mLog.info("Deleting acknowleded reference check entries for all stores.");

		// Group them by BU type
		Map<String,List<String>> vBuTypes = new HashMap<String,List<String>>();
		for (VoBusinessUnit vVoBusinessUnit : mUnits.allStores()) {
			List<String> vBuCodes = vBuTypes.get(vVoBusinessUnit.getBuType());

			if (vBuCodes == null) {
				vBuCodes = new ArrayList<String>();
				vBuTypes.put(vVoBusinessUnit.getBuType(), vBuCodes);
			}

			vBuCodes.add(vVoBusinessUnit.getBuCode());
		}

		// Delete one BU type at a time
		for (String vBuType : vBuTypes.keySet()) {
			List<String> vBuCodes = vBuTypes.get(vBuType);

			int vRowsDeletedOneBuType = mBefReferenceCheck.deleteAcknowledged(
					vBuType, vBuCodes);
			if (mLog.isInfoEnabled()) {
				mLog.info("Deleted " + vRowsDeletedOneBuType
						+ " reference checks for BU type: " + vBuType
						+ " BU codes: " + vBuCodes);
			}
		}

		return RepeatStatus.FINISHED;
	}


	public void setBefReferenceCheck(BefReferenceCheck pBefReferenceCheck) {
		mBefReferenceCheck = pBefReferenceCheck;
	}

	public void setUnits(Units pUnits) {
		mUnits = pUnits;
	}
}
