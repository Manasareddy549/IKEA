package com.ikea.ebccardpaybatch1.batch;

import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.be.Card;
import com.ikea.ebccardpay1.cardpayment.bec.BecCampaign;
import com.ikea.ebccardpay1.cardpayment.bec.BecCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCard;

public class ExpiredCardRedeemTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(ExpiredCardRedeemTasklet.class);

	private BecCard mBecCard;
		
	private String  fromDate;
	
	private String toDate;
	
	private String triggerTimestamp;
	
	
	public String getTriggerTimestamp() {
		return triggerTimestamp;
	}

	public void setTriggerTimestamp(String triggerTimestamp) {
		this.triggerTimestamp = triggerTimestamp;
	}


	//public static int count;
	
	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}


	
    
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		
		boolean isExpiredCardListEmpty = false;
		boolean isExpiredCampaignListEmpty = false;
		
		try {
			mLog.info("Executing ExpiredCardsRedeemTasklet......");

			mLog.info("Process start Time" + System.currentTimeMillis());
			
			mLog.info("fromDate : " + fromDate);
			
			mLog.info("toDate : " + toDate);
			

			
				
				isExpiredCardListEmpty = 
					mBecCard.getExpiredCards(fromDate, toDate);
				
			
			

			mLog.info("Process End Time" + System.currentTimeMillis());
			
			
			mLog.info("ExpiredCardsRedeemTasklet normal exit ......");
			
			

		} catch (Exception ex) {
			mLog.info("ExpiredCardsRedeemTasklet trew excpetion ......");
			
			throw new Exception("Error in ExpiredCardsRedeemTasklet", ex);
			
		}
		
			
			return RepeatStatus.FINISHED;
		
	}

	public void setBecCard(BecCard becCard) {
		mBecCard = becCard;
	}
    
	public BecCard getBecCard() {
		return mBecCard;
	}
	


	 public int getMaxRun(int size){
		 int listSize = size;
		 int indexSize = 3000;
		 int maxRun = listSize/indexSize;
		 return maxRun;
	 }
}
