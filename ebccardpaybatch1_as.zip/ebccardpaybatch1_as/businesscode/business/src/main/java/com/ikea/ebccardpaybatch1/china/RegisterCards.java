package com.ikea.ebccardpaybatch1.china;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CnCard;
import com.ikea.ebccardpaybatch1.utils.Request;


public class RegisterCards {
	private static final Logger mLog = LoggerFactory
			.getLogger(RegisterCards.class);
		
	private String serialNo;
	private String cardID;
	private String cardNo;
	private String cardMon;
	private String cardBalance;
	private String applyTime;
	private String beginDate;
	private String expiryDate;



	private  DateFormat sDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
	private  DateFormat sDateFormat2 = new SimpleDateFormat("yyyyMMddHHmmss");
	private  DateFormat sDateFormat3 = new SimpleDateFormat("yyyy-MM-dd");
	private  DateFormat sDateFormat4 = new SimpleDateFormat("yyyyMMdd");
	
	private BigDecimal zeroAmount= new BigDecimal(0.0);

	private StringBuffer jSonList= null;
	
	private ArrayList<CnCard> cnCardList = null;
	
	public void inputList(List<Object[]> pcardsList)
	{
		jSonList= new StringBuffer();
		cnCardList = new ArrayList<CnCard>();
		
		Request mRequestObject= new Request();
		
		for(int i=0;i<pcardsList.size();i++)
				
		{
			Object[] pRow=pcardsList.get(i);
			try{
				serialNo=pRow[0].toString();
				cardID=pRow[5].toString();
				cardNo=pRow[4].toString();
				
				BigDecimal amount= new BigDecimal(pRow[3].toString());
				
				cardMon=amount.toString();
				cardBalance=cardMon;
				
				
				Timestamp mapplyTimeStamp=(Timestamp)pRow[1];
				applyTime=sDateFormat2.format(new Date(mapplyTimeStamp.getTime()));

				beginDate=sDateFormat4.format(sDateFormat3.parse(pRow[2].toString()));
				if(beginDate.startsWith("1900")) throw  new Exception("Wrong Sales Day");
				
				Timestamp mexpiryDateTimeStamp=(Timestamp)pRow[6];
				expiryDate=sDateFormat4.format(new Date(mexpiryDateTimeStamp.getTime()));
				
				jSonList.append(mRequestObject.registerCard(serialNo, cardID, cardNo, cardMon, cardBalance, applyTime, beginDate, expiryDate));
				if(i<(pcardsList.size()-1))
				{
					jSonList.append("\r\n");
				}
				CnCard mCnCard= new CnCard();
				mCnCard.setCardId(Long.parseLong(cardID));
				mCnCard.setCardNumber(cardNo);
				cnCardList.add(mCnCard);
				
				
			}
			catch(Exception e)
			{

				mLog.warn("Exception while adding Data[ "+pRow[0].toString()+","+pRow[1].toString()+","+pRow[2].toString()+","+pRow[3].toString()+","+pRow[3].toString()+"," +pRow[4].toString()+","
						+pRow[5].toString()+","+pRow[6].toString()+" ] to the list. Exception Details: "+ e.getMessage());
			}

		}
	
	}




	public StringBuffer getjSonList() {
		return jSonList;
	}


	public ArrayList<CnCard> getCnCardList() {
		return cnCardList;
	}

}
