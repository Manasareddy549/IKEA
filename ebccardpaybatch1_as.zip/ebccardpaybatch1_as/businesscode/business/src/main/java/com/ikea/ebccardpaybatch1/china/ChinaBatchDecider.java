package com.ikea.ebccardpaybatch1.china;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

public class ChinaBatchDecider implements JobExecutionDecider{

	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {

		String jobFlow;

		try{
			jobFlow=new String(jobExecution.getJobParameters().getString("jobExecutionFlow"));
			if(jobFlow.equalsIgnoreCase("ALL")||jobFlow.equalsIgnoreCase("FROM2")||
					jobFlow.equalsIgnoreCase("DELETE")||jobFlow.equalsIgnoreCase("1")||
					jobFlow.equalsIgnoreCase("2")||jobFlow.equalsIgnoreCase("3"))
			{
				
				if(jobExecution.getJobParameters().getString("batchjobError").equalsIgnoreCase("0"))
				{
				
				return new FlowExecutionStatus(jobFlow);
				}
				else{
					throw new Exception("Reported Error");
				}
			}
			else
			{
				throw new Exception("Invalid Flow");
			}
		}
		catch(Exception e){
			jobFlow=new String("0");
			return new FlowExecutionStatus(jobFlow);
		}

	}
}
