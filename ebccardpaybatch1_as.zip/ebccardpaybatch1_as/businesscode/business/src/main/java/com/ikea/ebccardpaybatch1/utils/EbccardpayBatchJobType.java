package com.ikea.ebccardpaybatch1.utils;

public enum EbccardpayBatchJobType {

	cancelUnAcknowledgedTransactionsJob,
	deleteReferenceCheckJob,
	deleteBatchLogJob,
	processCampaignJob,
	processMassLoadJob,
	updateExchangeRateFromCbdJob,
	calculateKpiJob,
	weeklySalesReportJob,
	retrieveSiteDataJob,
	generateSarecReportJob,
	deleteSarecReportJob,
	expiredCardsJob,
	expiredCampaignsJob,
	expiredCardRedeemJob,
	chinaBatchJob
}
