package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.be.MassLoad;
import com.ikea.ebccardpay1.cardpayment.bec.BecMassLoads;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 * 
 */
@Component
public class ProcessMassLoadJobCreator extends AbstractJobCreator {

	@Autowired
	private BecMassLoads mBecMassLoads;

	public void createNewJobs() {
		List<MassLoad> vUnprocessedMassLoads = mBecMassLoads
				.findUnprocessedMassLoads();

		for (MassLoad vMassLoad : vUnprocessedMassLoads) {
			List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

			VoJobParam vMassLoadIdParam = new VoJobParam();
			vMassLoadIdParam.setName(BatchJobArguments.MASS_LOAD_ID);
			vMassLoadIdParam.setValue(Long.toString(vMassLoad.getMassLoadId()));
			vVoJobParamList.add(vMassLoadIdParam);
			VoJobParam vTriggerParam = new VoJobParam();
			vTriggerParam.setName(BatchJobArguments.MASS_LOAD_TRIGGER);
			vTriggerParam.setValue("BATCH");
			vVoJobParamList.add(vTriggerParam);
			VoJobParam vTriggerTimestampParam = new VoJobParam();
			vTriggerTimestampParam
					.setName(BatchJobArguments.MASS_LOAD_TRIGGER_TIMESTAMP);
			vTriggerTimestampParam.setValue((new DateTime()).toString());
			vVoJobParamList.add(vTriggerTimestampParam);
			sendAsyncJobExecutionRequest(BatchJobType.processMassLoadJob,
					vVoJobParamList);
		}
	}

}
