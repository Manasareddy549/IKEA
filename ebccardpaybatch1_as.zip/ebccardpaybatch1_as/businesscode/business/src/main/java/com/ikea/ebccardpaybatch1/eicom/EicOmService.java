package com.ikea.ebccardpaybatch1.eicom;

import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author Henrik Reinhold
 *
 *	Service class that interacts with EicOm (OutputManagement). Om will store the report
 *  in OnDemand.
 */
public interface EicOmService {

	void sendWeeklySalesReport(WeeklySalesReport pSalesReports) throws IkeaException;

}
