package com.ikea.ebccardpaybatch1.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;


import com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;

public class DeleteSarecReportTasklet implements Tasklet {
	private static final Logger mLog = LoggerFactory.getLogger(DeleteSarecReportTasklet.class);
	
	private BefSarecReport mBefSarecReport;
	
	private Units mUnits;
	
	public RepeatStatus execute(StepContribution pContribution,ChunkContext pChunkContext){
		mLog.info("Deleting Saarec report files older than 7 days and status is success or older than 14 days and status is failed." );
		
		// Group them by BU type
		Map<String,List<String>> vBuTypes = new HashMap<String,List<String>>();
		for (VoBusinessUnit vVoBusinessUnit : mUnits.allStores()) {
			List<String> vBuCodes = vBuTypes.get(vVoBusinessUnit.getBuType());

			if (vBuCodes == null) {
				vBuCodes = new ArrayList<String>();
				vBuTypes.put(vVoBusinessUnit.getBuType(), vBuCodes);
			}

			vBuCodes.add(vVoBusinessUnit.getBuCode());
		}

		// Delete one BU type at a time
		for (String vBuType : vBuTypes.keySet()) {
			List<String> vBuCodes = vBuTypes.get(vBuType);

			int vRowsDeletedOneBuType = mBefSarecReport.deleteSaarecReport(
					vBuType, vBuCodes);
			
					
			if (mLog.isInfoEnabled()) {
				mLog.info("Deleted " + vRowsDeletedOneBuType
						+ " saarec report status check for BU type: " + vBuType
						+ " BU codes: " + vBuCodes);
			}
		}

		return RepeatStatus.FINISHED;
	}


	public void setBefSarecReport(BefSarecReport pBefSarecReport) {
		mBefSarecReport = pBefSarecReport;
	}

	public void setUnits(Units pUnits) {
		mUnits = pUnits;
	}
	
}
