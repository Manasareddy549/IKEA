package com.ikea.ebccardpaybatch1.eicom;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReportRow;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.spring.BeanFactory;
import com.ikea.eicom3.cg.CgAccessAuthorization;
import com.ikea.eicom3.cg.CgDestinationType;
import com.ikea.eicom3.cg.CgOutputJobPriority;
import com.ikea.eicom3.cg.CgSecurityClass;
import com.ikea.eicom3.client.bs.BsSubmitSingleOutputJob;
import com.ikea.eicom3.client.vo.VoDocumentIndexField;
import com.ikea.eicom3.client.vo.VoDocumentInfo;
import com.ikea.eicom3.client.vo.VoOutputDestinationInfo;
import com.ikea.eicom3.client.vo.VoOutputJobInfo;

public class EicOmServiceBsImpl implements EicOmService {

	private static final String INDEX_WEEK = "Week";
	private static final String INDEX_YEAR = "Year";
	private static final String DOCUMENT_TYPE_WEEKLY_SALES_REPORT = "weekly-sales-report";
	private static final String IDENTIFICATION_IPAY = "ipay";
	private static final String OUTPUT_TYPE_IPAY = IDENTIFICATION_IPAY;

	
	private static final Logger mLog = LoggerFactory.getLogger(EicOmServiceBsImpl.class);
	
	
	public void sendWeeklySalesReport(WeeklySalesReport pSalesReport) throws IkeaException {
		
		String vXmlMessage = createXmlMessage(pSalesReport);
		
		mLog.debug("Generated report XML: " + vXmlMessage);
		
		BsSubmitSingleOutputJob vBs = new BsSubmitSingleOutputJob();
		
		VoOutputJobInfo vVoOutputJobInfo = new VoOutputJobInfo();
		vVoOutputJobInfo.setAccessAuthorization(CgAccessAuthorization.ALL);
		vVoOutputJobInfo.setExternalRef(pSalesReport.getYear() + "-" + pSalesReport.getWeek()); 
		vVoOutputJobInfo.setOutputType(OUTPUT_TYPE_IPAY); 
		vVoOutputJobInfo.setPriority(CgOutputJobPriority.STANDARD);
		vVoOutputJobInfo.setSecurityClass(CgSecurityClass.BASE);
		
		
		List<VoOutputDestinationInfo> vDestList = new ArrayList<VoOutputDestinationInfo>();
		VoOutputDestinationInfo vDest = new VoOutputDestinationInfo();
		vDest.setExternalRef(IDENTIFICATION_IPAY);
		vDest.setIdentification(IDENTIFICATION_IPAY);
		vDest.setOutputDestinationType(CgDestinationType.ARCHIVE);

		vDestList.add(vDest);
		
		//-- Set the output job destination
		vVoOutputJobInfo.setVoOutputDestinationInfoList(vDestList);

		VoDocumentInfo vVoDocumentInfo = new VoDocumentInfo();
		vVoDocumentInfo.setExternalRef(IDENTIFICATION_IPAY);
		vVoDocumentInfo.setDocumentType(DOCUMENT_TYPE_WEEKLY_SALES_REPORT);
		vVoDocumentInfo.setData(vXmlMessage);
		vVoDocumentInfo.setForDistributionIndicator(true);
		
		List<VoDocumentIndexField> vIndexList = new ArrayList<VoDocumentIndexField>(); 
		VoDocumentIndexField vIndexYear = new VoDocumentIndexField();
		vIndexYear.setName(INDEX_YEAR);
		vIndexYear.setValue(pSalesReport.getYear());
		vIndexList.add(vIndexYear); 
		VoDocumentIndexField vIndexWeek = new VoDocumentIndexField();
		vIndexWeek.setName(INDEX_WEEK);
		vIndexWeek.setValue(pSalesReport.getWeek());
		vIndexList.add(vIndexWeek);
		
		vVoDocumentInfo.setVoDocumentIndexFieldList(vIndexList);
	
		vBs.setVoOutputJobInfo(vVoOutputJobInfo);
		vBs.setVoDocumentInfo(vVoDocumentInfo);

		// Execute the business service, ignore the reply.
		BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
		vBsExecuter.executeBsAsync(vBs);
		
	}

	protected String createXmlMessage(WeeklySalesReport pSalesReport) {
		StringBuffer vXmlMessage = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		vXmlMessage.append("<salesreport year=\"").append(pSalesReport.getYear());
		vXmlMessage.append("\" week=\"").append(pSalesReport.getWeek()).append("\">\n");
		for (WeeklySalesReportRow vSalesReportRow : pSalesReport.getRows()) {
			vXmlMessage.append("<report-row country-code=\"").append(vSalesReportRow.getCOUNTRYCODE());
			vXmlMessage.append("\" bu-code=\"").append(vSalesReportRow.getBUCODE());
			vXmlMessage.append("\" bu-type=\"").append(vSalesReportRow.getBUTYPE());
			vXmlMessage.append("\" currency-code=\"").append(vSalesReportRow.getCURRENCYCODE());
			vXmlMessage.append("\" in-local-currency=\"").append(vSalesReportRow.getAMOUNTINLOCALCURRENCY());
			vXmlMessage.append("\" no-load-transactions=\"").append(vSalesReportRow.getNUMBEROFLOADTRANSACTIONS());
			vXmlMessage.append("\"/>\n");
		}
		vXmlMessage.append("</salesreport>");
		
		return vXmlMessage.toString();
	}

}
