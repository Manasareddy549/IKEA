package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.bec.BecSarecReport;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author moans1
 * 
 */
@Component
public class GenerateSarecReportJobCreator extends AbstractJobCreator {

	@Autowired
	private Units mUnits;
	
	@Autowired
	private BecSarecReport mBecSarecReport;
	
	@Autowired
	private BefFactory mBefFactory;

	private final static Logger sarecReportJobCreatorLogger = LoggerFactory
			.getLogger(GenerateSarecReportJobCreator.class);

	public void createNewJobs() {
		
		createNewJobs(false);

	}

	public void createNewJobs(boolean pOnlyYesterday) {
		int numberOfStoreHadErrors = 0;
		// Exception exceptionProcessingStores = null;

		for (VoBusinessUnit vVoBusinessUnit : mUnits.allStores()) {

			sarecReportJobCreatorLogger
					.debug("Next butype  beginning : buType "
							+ vVoBusinessUnit.getBuType() + " ,buCode : "
							+ vVoBusinessUnit.getBuCode());
			try {
				// Find intervals to generate Sarec Reports
				
				 List<String> vSarecReportSalesdates = mBecSarecReport.findUngeneratedSarecReportDates(vVoBusinessUnit.getBuType(), 
						 vVoBusinessUnit .getBuCode(),mBefFactory.getBefIpayBusinessUnits());
				 
				 if (pOnlyYesterday) { // Only calculate last day, i.e. get last entry from list vKPIIntervals 
					 if (vSarecReportSalesdates != null && vSarecReportSalesdates.size() > 0) 
						 createNewJob(vVoBusinessUnit.getBuCode(), vVoBusinessUnit.getBuType(),vSarecReportSalesdates.get(vSarecReportSalesdates.size()-1)); 
				 } else { 
					 for(String vSarecReportSalesdate : vSarecReportSalesdates) {
						 createNewJob(vVoBusinessUnit.getBuCode(),vVoBusinessUnit.getBuType(), vSarecReportSalesdate); 
					 } 
				}
							 
			} catch (Exception e) {
				numberOfStoreHadErrors++;
				// exceptionProcessingStores=e;
				sarecReportJobCreatorLogger
						.debug("Error  processing  butype  beginning : buType "
								+ vVoBusinessUnit.getBuType() + " ,buCode : "
								+ vVoBusinessUnit.getBuCode()
								+ " ,numberOfStoreHadErrors : "
								+ numberOfStoreHadErrors);
				e.printStackTrace();
			}
		}

	}

	private void createNewJob(String pBuCode, String pBuType, String pSalesDate) {
		List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

		VoJobParam vBuCodeParam = new VoJobParam();
		vBuCodeParam.setName(BatchJobArguments.SAREC_BU_CODE);
		vBuCodeParam.setValue(pBuCode);
		vVoJobParamList.add(vBuCodeParam);

		VoJobParam vBuTypeParam = new VoJobParam();
		vBuTypeParam.setName(BatchJobArguments.SAREC_BU_TYPE);
		vBuTypeParam.setValue(pBuType);
		vVoJobParamList.add(vBuTypeParam);

		VoJobParam vSarecSalesdateParam = new VoJobParam();
		vSarecSalesdateParam.setName(BatchJobArguments.SAREC_SALESDATE);
		vSarecSalesdateParam.setValue(pSalesDate);
		vVoJobParamList.add(vSarecSalesdateParam);

		sendAsyncJobExecutionRequest(BatchJobType.generateSarecReportJob,
				vVoJobParamList);
	}

}
