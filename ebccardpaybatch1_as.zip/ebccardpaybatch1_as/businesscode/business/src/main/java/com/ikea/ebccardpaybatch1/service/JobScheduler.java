package com.ikea.ebccardpaybatch1.service;

import java.util.List;

public interface JobScheduler {

	List<JobCreator> findActiveJobCreators() throws Exception;
}
