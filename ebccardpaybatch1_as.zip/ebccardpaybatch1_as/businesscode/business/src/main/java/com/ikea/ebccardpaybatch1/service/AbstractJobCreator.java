package com.ikea.ebccardpaybatch1.service;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.common.BatchJobType;
import com.ikea.ebccardpaybatch1.client.bs.BsRunBatch;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.spring.BeanFactory;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 *
 */
public abstract class AbstractJobCreator implements JobCreator{

	private static final Logger mLog = LoggerFactory
			.getLogger(AbstractJobCreator.class);
	
	@SuppressWarnings("unchecked")
	protected void sendAsyncJobExecutionRequest(BatchJobType pBatchJobType,
			List<VoJobParam> pJobParamList) {
		BsRunBatch vBsRunBatch = new BsRunBatch();
		vBsRunBatch.setOperation(pBatchJobType.toString());
		vBsRunBatch.setJobParamList(pJobParamList);
		if (mLog.isDebugEnabled()){
			StringBuffer vJobParamsString = new StringBuffer();
			if (vBsRunBatch.getJobParamList() != null
					&& vBsRunBatch.getJobParamList().size() > 0) {
				for (Iterator vIterator = vBsRunBatch.getJobParamList()
						.iterator(); vIterator.hasNext();) {
					VoJobParam vJobParam = (VoJobParam) vIterator.next();
					vJobParamsString.append("param: ").append(
							vJobParam.getName());
					vJobParamsString.append(" value: ").append(
							vJobParam.getValue()).append(", ");
				}
			} else {
				vJobParamsString.append("<empty>, ");
			}
			mLog.debug("Sending async EBB request to execute " + vBsRunBatch.getOperation() + " with parameters: " + vJobParamsString);
		}
		try {
			BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
			vBsExecuter.executeBsAsync(vBsRunBatch);
			
		} catch (IkeaException e) {
			mLog.error("Error sending asynch job execution request: " + e);
		}
	}
}
