package com.ikea.ebccardpaybatch1.service;

public interface JobCreator {

	void createNewJobs();
}
