package com.ikea.ebccardpaybatch1.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bef.BefReport;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpaybatch1.eicom.EicOmService;

public class WeeklySalesReportTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(WeeklySalesReportTasklet.class);

	private String mYear;
	
	private String mWeek;
	
	private BefReport mBefReport;
	
	private EicOmService mEicOmService;
	
	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext)
			throws Exception {
		mLog.info("Running batchjob for Weekly Sales Report, year: " + mYear + ", week: " + mWeek);
		
		WeeklySalesReport vWeeklySalesReport = mBefReport.retrieveSalesReportByWeek(mYear, mWeek);
		
		mEicOmService.sendWeeklySalesReport(vWeeklySalesReport);
		
		mLog.info("Batchjob done for Weekly Sales Report, year: " + mYear + ", week: " + mWeek);
		
		return RepeatStatus.FINISHED;
	}

	public void setYear(String pYear) {
		mYear = pYear;
	}

	public void setWeek(String pWeek) {
		mWeek = pWeek;
	}

	public void setBefReport(BefReport pBefReport) {
		mBefReport = pBefReport;
	}

	public void setEicOmService(EicOmService pEicOmService) {
		mEicOmService = pEicOmService;
	}

}
