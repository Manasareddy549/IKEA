package com.ikea.ebccardpaybatch1.batch;

import java.sql.Blob;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.be.IpaySarecReport;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport;
import com.ikea.ebccardpay1.cardpayment.utils.Units;

public class GenerateSarecReportTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
	.getLogger(GenerateSarecReportTasklet.class);
	
	private String buCode;
	private String buType;
	private String sarecSalesdate;

	private Units mUnits;

	private BefSarecReport mBefSarecReport;
	
	private BefIpayBusinessUnits mBefIpayBusinessUnits;
	
	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {
		mLog.info("Generating " + sarecSalesdate + " for " + buType + buCode
				+ "...");

		// Get time zone
		//String vTimeZoneId = mUnits.getTimeZone(buType, buCode);
		// Let BEF execute query
		
		Blob vSarecReportBlob = mBefSarecReport.generate(buType,
				buCode, sarecSalesdate);
		
		if (vSarecReportBlob == null) {
			mLog.info("Cannot write to database as no blob file found");
		} else {
									
			IpaySarecReport vIpaySarecReport = 	mBefSarecReport.create();
			vIpaySarecReport.setBuCode(buCode);
			vIpaySarecReport.setBuType(buType);
			vIpaySarecReport.setSalesDate(sarecSalesdate);
			vIpaySarecReport.setStatus("Waiting");
			vIpaySarecReport.setSarecFile(vSarecReportBlob);

			mBefSarecReport.save(vIpaySarecReport);
			
		}

		mLog.info("Generating  " + sarecSalesdate + " for " + buType + buCode+ " done.");

		return RepeatStatus.FINISHED;
		
	}
	
	private String objectToString(Object pObject) {
		return pObject == null ? null : pObject.toString();
	}


	/**
	 * @return the buCode
	 */
	public String getBuCode() {
		return buCode;
	}

	/**
	 * @param buCode the buCode to set
	 */
	public void setBuCode(String pBuCode) {
		this.buCode = pBuCode;
	}

	/**
	 * @return the buType
	 */
	public String getBuType() {
		return buType;
	}

	/**
	 * @param buType the buType to set
	 */
	public void setBuType(String pBuType) {
		this.buType = pBuType;
	}

	/**
	 * @return the sarecSalesdate
	 */
	public String getSarecSalesdate() {
		return sarecSalesdate;
	}

	/**
	 * @param sarecSalesdate the sarecSalesdate to set
	 */
	public void setSarecSalesdate(String pSarecSalesdate) {
		this.sarecSalesdate = pSarecSalesdate;
	}

	/**
	 * @return the mUnits
	 */
	public Units getUnits() {
		return mUnits;
	}

	/**
	 * @param units the mUnits to set
	 */
	public void setUnits(Units pUnits) {
		mUnits = pUnits;
	}

	/**
	 * @return the mBefSarecReport
	 */
	public BefSarecReport getBefSarecReport() {
		return mBefSarecReport;
	}

	/**
	 * @param befSarecReport the mBefSarecReport to set
	 */
	public void setBefSarecReport(BefSarecReport pBefSarecReport) {
		mBefSarecReport = pBefSarecReport;
	}

	/**
	 * @return the mBefIpayBusinessUnits
	 */
	public BefIpayBusinessUnits getBefIpayBusinessUnits() {
		return mBefIpayBusinessUnits;
	}

	/**
	 * @param befIpayBusinessUnits the mBefIpayBusinessUnits to set
	 */
	public void setBefIpayBusinessUnits(BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefIpayBusinessUnits = pBefIpayBusinessUnits;
	}

}
