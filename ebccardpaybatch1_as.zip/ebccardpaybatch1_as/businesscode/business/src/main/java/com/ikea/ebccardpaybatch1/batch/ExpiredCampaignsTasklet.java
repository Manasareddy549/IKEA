package com.ikea.ebccardpaybatch1.batch;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bec.BecCampaign;
import com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;



public class ExpiredCampaignsTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(ExpiredCampaignsTasklet.class);

	private String fromDate;
	private String toDate;
	private BecCampaign mBecCampaign;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {
		mLog.info("Executing ExpiredCampaignsTasklet......");
		mLog.info("Process start Time" + System.currentTimeMillis());
		int chunk=0;
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat dateFormater = new SimpleDateFormat(pattern);
		mLog.info("Dates: Executing ExpiredCampaigns from "+fromDate+" till "+toDate);
		Date vFromDate= dateFormater.parse(fromDate);
		Date vToDate= dateFormater.parse(toDate);
		List<Campaign> mCampaign=mBecCampaign.getExpiredCampaigns(vFromDate,vToDate);
		mBecCampaign.processExpiredCampaignslist(mCampaign);
		List<Campaign> mCampaignverify=mBecCampaign.getExpiredCampaigns(vFromDate,vToDate);
		if(mCampaignverify.size()!=0)
		{
			return RepeatStatus.CONTINUABLE;
		}
		else
		{
			mLog.info("Process End Time" + System.currentTimeMillis());
			mLog.info("ExpiredCampaignsTasklet normal exit ......");
			return RepeatStatus.FINISHED;
		}
		

	}

	private String objectToString(Object pObject) {
		return pObject == null ? null : pObject.toString();
	}



	public String getFromDate() {
		return fromDate;
	}


	public void setFromDate(String pFromDate) {
		this.fromDate = pFromDate;
	}


	public String getToDate() {
		return toDate;
	}

	/**
	 * @param buType the buType to set
	 */
	public void setToDate(String pToDate) {
		this.toDate = pToDate;
	}
	public BecCampaign getBecCampaign() {
		return mBecCampaign;
	}

	/**
	 * @param befSarecReport the mBefSarecReport to set
	 */
	public void setBecCampaign(BecCampaign pBecCampaign) {
		mBecCampaign = pBecCampaign;
	}


}
