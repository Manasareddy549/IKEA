package com.ikea.ebccardpaybatch1.china;

import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.be.CnCard;
import com.ikea.ebccardpay1.cardpayment.be.CnCardBatchJob;
import com.ikea.ebccardpay1.cardpayment.be.IpaySarecReport;
import com.ikea.ebccardpay1.cardpayment.bec.BecCard;
import com.ikea.ebccardpay1.cardpayment.bec.BecCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefCardNumber;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCardBatchJob;
import com.ikea.ebccardpay1.cardpayment.bef.BefSarecReport;
import com.ikea.ebcframework.services.EbcProperties;


public class ChinaBatchBlobCreationTasklet implements Tasklet{
	private static final Logger mLog = LoggerFactory
			.getLogger(ChinaBatchBlobCreationTasklet.class);

	private BefCnCardBatchJob befCnCardBatchJob;

	private BefCnCard befCnCard;

	private String batchjobType;

	private String salesDate;

	private int transactionCount;

	private RegisterCards registerCards;

	private RegisterDailyTransactions registerDailyTransactions;


	@Autowired
	EbcProperties ebcProperties;

	private int retry=0;

	private long retryInterval=0L;


	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		mLog.info("Executing Blob Creation Tasklet");
		//if(retry!=-1) throw new Exception("25114-Blob Creation Failed");

		setproperties();

		SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");

		String toDayDateString =dateFormater.format(new DateTime().toDate());
		String yesterdayDateString = dateFormater.format(new DateTime().minusDays(1).toDate());

		for(int i=1;i<=retry;i++)
		{
			if(i!=1)
			mLog.warn("Attempting Blob creation: "+(i+1)+" time");
			
			try{
				long noVal=0L;
				if(batchjobType.equalsIgnoreCase("HISTORICAL"))
				{
					mLog.info("Creating Blobfile for historical Cards");
					long cnBatchJobId=registerCards(toDayDateString,chunkContext.getStepContext().getStepExecution().getJobExecutionId(),transactionCount);
					if(cnBatchJobId>noVal)
						chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchJobIds", Long.toString(cnBatchJobId));
					return RepeatStatus.FINISHED;

				}

				else if(batchjobType.equalsIgnoreCase("DAILY"))
				{
					if(salesDate ==null)
					{
						mLog.info("Creating Blobfile for Yesterday");
						long cnBatchJobId= registerDailyTransactions(yesterdayDateString,chunkContext.getStepContext().getStepExecution().getJobExecutionId());
						if(cnBatchJobId>noVal)
							chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchJobIds", Long.toString(cnBatchJobId));
						return RepeatStatus.FINISHED;
					}
					else{
						mLog.info("Creating Blobfile for "+salesDate);
						long cnBatchJobId=registerDailyTransactions(salesDate,chunkContext.getStepContext().getStepExecution().getJobExecutionId());
						if(cnBatchJobId>noVal)
							chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchJobIds", Long.toString(cnBatchJobId));
						return RepeatStatus.FINISHED;
					}


				}

			}
			catch(Exception e)
			{
				mLog.warn("Blob Creation failed due to exception "+e.getLocalizedMessage());
			}
			Thread.sleep(retryInterval); // 5 Minutes
			
		}

		mLog.warn("Blob Creation failed even after "+retry +" count");
		CustomException.setException("25114-Blob Creation Failed");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
		return RepeatStatus.FINISHED;

	}



	private long registerCards(String pDate, long id, int transactionCount) throws ParseException, SQLException
	{
		List<Object[]> cardsToRegister=befCnCardBatchJob.registerCard(pDate, "CN", transactionCount);
		mLog.info("Historical Cards fethed from Database");
		long batchjobId=0L;
		if(cardsToRegister!=null)
		{
			if(cardsToRegister.size()>0)
			{
				//registerCards= new RegisterCards();
				mLog.info("Registering the Cards");
				registerCards.inputList(cardsToRegister);


				Date mbatchJobDate=null;
				String user=null;
				if(registerCards.getjSonList().toString().length()>0)
				{



					CnCardBatchJob mCnBatchJob = befCnCardBatchJob.create();
					Blob mChinaBlob=befCnCardBatchJob.createChinaBlobFile(registerCards.getjSonList().toString());
					mLog.debug(registerCards.getjSonList().toString());
					if(mChinaBlob.length()>0)
					{
						mCnBatchJob.setBatchType("HISTORICAL");
						mCnBatchJob.setBlobFile(mChinaBlob);
						mCnBatchJob.setJobExecutionIds(Long.toString(id));
						mCnBatchJob.setSalesDay(pDate);
						mCnBatchJob.setTransactionCount(registerCards.getCnCardList().size());
						mCnBatchJob.setStatus("PENDING");
						befCnCardBatchJob.save(mCnBatchJob);

						batchjobId=mCnBatchJob.getCnBatchJobId();
						mbatchJobDate=mCnBatchJob.getCreatedDateTime();
						user=mCnBatchJob.getCreatedBy();
					}

				}
				for(CnCard mCnCard:registerCards.getCnCardList())
				{
					mCnCard.setRegistered("N");
					mCnCard.setCnBatchJobId(batchjobId);
					mCnCard.setCreatedBy(user);
					mCnCard.setCreatedDateTime(mbatchJobDate);
					befCnCard.save(mCnCard);
					//mLog.debug("Card Registered "+mCnCard.getCardNumber());
				}

			}
			else{
				mLog.info("No China Gift Cards found to Register");
			}
		}
		registerCards=null;
		return batchjobId;
	}


	private long registerDailyTransactions(String pDate,long id) throws SQLException
	{
		List<Object[]> dailyTransactions = befCnCardBatchJob.getTransactions(pDate,"CN");		
		long batchjobId=0L;
		if(dailyTransactions!=null)
		{
			if(dailyTransactions.size()>0)
			{
				//registerDailyTransactions= new RegisterDailyTransactions();
				mLog.info("Registering the Daily Transactions");
				registerDailyTransactions.registerFunctionality(dailyTransactions);



				String user=null;
				Date mbatchJobDate=null;
				if(registerDailyTransactions.getjSonList().toString().length()>0)
				{
					CnCardBatchJob mCnBatchJob = befCnCardBatchJob.create();
					Blob mChinaBlob=befCnCardBatchJob.createChinaBlobFile(registerDailyTransactions.getjSonList().toString());
					mLog.debug(registerDailyTransactions.getjSonList().toString());
					if(mChinaBlob.length()>0)
					{
						mCnBatchJob.setBatchType("DAILY");
						mCnBatchJob.setBlobFile(mChinaBlob);
						mCnBatchJob.setJobExecutionIds(Long.toString(id));
						mCnBatchJob.setSalesDay(pDate);
						mCnBatchJob.setTransactionCount(registerDailyTransactions.getTransactionCount());
						mCnBatchJob.setStatus("PENDING");
						befCnCardBatchJob.save(mCnBatchJob);
						batchjobId=mCnBatchJob.getCnBatchJobId();
						user=mCnBatchJob.getCreatedBy();
						mbatchJobDate=mCnBatchJob.getCreatedDateTime();
						mLog.debug("Blob Registered "+mCnBatchJob.getCnBatchJobId());
					}


				}
				for(CnCard mCnCard:registerDailyTransactions.getCnCardList())
				{
					mCnCard.setRegistered("N");
					mCnCard.setCnBatchJobId(batchjobId);
					mCnCard.setCreatedBy(user);
					mCnCard.setCreatedDateTime(mbatchJobDate);
					befCnCard.save(mCnCard);
					//mLog.debug("Card Registered "+mCnCard.getCardNumber());
				}

			}
			else{
				mLog.info("No Transactions Found for the sales Date");
			}
		}
		dailyTransactions=null;
		return batchjobId;

	}

	public void setproperties()
	{
		retry=ebcProperties.getInt("retryCount",0);
		retryInterval=ebcProperties.getLong("retryInterval",0);


	}


	public BefCnCardBatchJob getBefCnCardBatchJob() {
		return befCnCardBatchJob;
	}



	public void setBefCnCardBatchJob(BefCnCardBatchJob befCnCardBatchJob) {
		this.befCnCardBatchJob = befCnCardBatchJob;
	}



	public BefCnCard getBefCnCard() {
		return befCnCard;
	}



	public void setBefCnCard(BefCnCard befCnCard) {
		this.befCnCard = befCnCard;
	}


	public String getBatchjobType() {
		return batchjobType;
	}



	public void setBatchjobType(String batchjobType) {
		this.batchjobType = batchjobType;
	}



	public String getSalesDate() {
		return salesDate;
	}



	public void setSalesDate(String salesDate) {
		this.salesDate = salesDate;
	}



	public int getTransactionCount() {
		return transactionCount;
	}



	public void setTransactionCount(int transactionCount) {
		this.transactionCount = transactionCount;
	}



	public RegisterCards getRegisterCards() {
		return registerCards;
	}



	public void setRegisterCards(RegisterCards registerCards) {
		this.registerCards = registerCards;
	}



	public RegisterDailyTransactions getRegisterDailyTransactions() {
		return registerDailyTransactions;
	}



	public void setRegisterDailyTransactions(RegisterDailyTransactions registerDailyTransactions) {
		this.registerDailyTransactions = registerDailyTransactions;
	}






}
