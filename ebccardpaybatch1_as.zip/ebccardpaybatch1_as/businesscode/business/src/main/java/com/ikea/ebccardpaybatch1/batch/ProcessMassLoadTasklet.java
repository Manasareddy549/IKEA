package com.ikea.ebccardpaybatch1.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bec.BecMassLoad;

public class ProcessMassLoadTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(ProcessMassLoadTasklet.class);

	private Long massLoadId;

	private BecMassLoad mBecMassLoad;
	
	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {

		int vProcessed = mBecMassLoad.process(massLoadId);

		if (vProcessed > 0) {
			mLog.info("More cards to process in the massload, will return CONTINUABLE");
			return RepeatStatus.CONTINUABLE;
		}

		return RepeatStatus.FINISHED;
	}

	public void setMassLoadId(Long pMassLoadId) {
		massLoadId = pMassLoadId;
	}

	public void setBecMassLoad(BecMassLoad pBecMassLoad) {
		mBecMassLoad = pBecMassLoad;
	}


}
