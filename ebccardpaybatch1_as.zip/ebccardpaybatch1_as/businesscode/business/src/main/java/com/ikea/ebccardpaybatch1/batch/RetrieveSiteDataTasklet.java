package com.ikea.ebccardpaybatch1.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.utils.Unit;
import com.ikea.ebccardpaybatch1.cbd.CbdService;

public class RetrieveSiteDataTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(RetrieveSiteDataTasklet.class);

	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	private CbdService mCbdService;
	//
	//	private CdsService mCdsService;

	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		mLog.info("Executing RetrieveSiteDataTasklet......");
		List<IpayBusinessUnits> dbList = mBefIpayBusinessUnits.findAll();

		Map<String, IpayBusinessUnits> dbMap = getMap(dbList);
		//mLog.info(dbMap);
		
		ArrayList<Unit> mBuList=mCbdService.iPaySitesfromCBD();
		
		for(Unit pUnit:mBuList)
		{
			IpayBusinessUnits dbEntity = dbMap.get(key(pUnit.getBuType(),pUnit.getBuCode()));
			if (dbEntity == null) {
				// Prepare for insert
				dbEntity = mBefIpayBusinessUnits.create();
				if(pUnit.getBuCode()!=null &&
						pUnit.getBuType()!=null &&
						pUnit.getSiteName()!=null &&
						pUnit.getCountryCode()!=null &&
						pUnit.getCompanyCode()!=null &&
						pUnit.getCompanyName()!=null &&
						pUnit.getTimeZone()!=null)
				{				
					mLog.debug("Bu_code: "+pUnit.getBuCode()+" , "
							+"Bu_Type: "+pUnit.getBuType()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Country: "+pUnit.getCountryCode()+" , "
							+"Company_code: "+pUnit.getCompanyCode()+" , "
							+"Company_name: "+pUnit.getCompanyName()+" , "
							+"Time_zone: "+pUnit.getTimeZone());
					
					dbEntity.getId().setBuCode(pUnit.getBuCode());
					dbEntity.getId().setBuType(pUnit.getBuType());
					dbEntity.setBuName(pUnit.getSiteName());
					dbEntity.setCountryCode(pUnit.getCountryCode());
					dbEntity.setCompanyCode(pUnit.getCompanyCode());
					dbEntity.setCompanyName(pUnit.getCompanyName());
					dbEntity.setTimeZone(pUnit.getTimeZone());
					mBefIpayBusinessUnits.saveOrUpdate(dbEntity);
				}
				else{
					mLog.error("Bu_code: "+pUnit.getBuCode()+" , "
							+"Bu_Type: "+pUnit.getBuType()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Country: "+pUnit.getCountryCode()+" , "
							+"Company_code: "+pUnit.getCompanyCode()+" , "
							+"Company_name: "+pUnit.getCompanyName()+" , "
							+"Time_zone: "+pUnit.getTimeZone());
				}

			}
			else{
				if(pUnit.getBuCode()!=null &&
						pUnit.getBuType()!=null &&
						pUnit.getSiteName()!=null &&
						pUnit.getCountryCode()!=null &&
						pUnit.getCompanyCode()!=null &&
						pUnit.getCompanyName()!=null &&
						pUnit.getTimeZone()!=null)
				{
					mLog.debug("Bu_code: "+pUnit.getBuCode()+" , "
							+"Bu_Type: "+pUnit.getBuType()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Country: "+pUnit.getCountryCode()+" , "
							+"Company_code: "+pUnit.getCompanyCode()+" , "
							+"Company_name: "+pUnit.getCompanyName()+" , "
							+"Time_zone: "+pUnit.getTimeZone());
					
					dbEntity.setCountryCode(pUnit.getCountryCode());
					dbEntity.setBuName(pUnit.getSiteName());
					dbEntity.setCompanyCode(pUnit.getCompanyCode());
					dbEntity.setCompanyName(pUnit.getCompanyName());
					dbEntity.setTimeZone(pUnit.getTimeZone());
					mBefIpayBusinessUnits.saveOrUpdate(dbEntity);
				}
				else{
					mLog.error("Bu_code: "+pUnit.getBuCode()+" , "
							+"Bu_Type: "+pUnit.getBuType()+" , "
							+"Bu_Name: "+pUnit.getSiteName()+" , "
							+"Country: "+pUnit.getCountryCode()+" , "
							+"Company_code: "+pUnit.getCompanyCode()+" , "
							+"Company_name: "+pUnit.getCompanyName()+" , "
							+"Time_zone: "+pUnit.getTimeZone());
				}

			}

		}

		mLog.info("RetrieveSiteDataTasklet Exit......");
		return RepeatStatus.FINISHED;
	}
	//		try {
	//			mLog.info("Executing RetrieveSiteDataTasklet......");
	//
	//			List<IpayBusinessUnits> dbList = mBefIpayBusinessUnits.findAll();
	//
	//			Map<String, IpayBusinessUnits> dbMap = getMap(dbList);
	//
	//			Map<String, Unit> cdsMap = mCdsService.GetAllBusinessUnitsForIpay();
	//
	//			for (Map.Entry<String, Unit> cdsEntry : cdsMap.entrySet()) {
	//
	//				IpayBusinessUnits dbEntity = dbMap.get(cdsEntry.getKey());
	//				mLog.debug("Handling store: Bucode="
	//						+ cdsEntry.getValue().getBuCode() + " BuType="
	//						+ cdsEntry.getValue().getBuType());
	//
	//				if (dbEntity == null) {
	//					// Prepare for insert
	//					dbEntity = mBefIpayBusinessUnits.create();
	//					dbEntity.getId().setBuType(cdsEntry.getValue().getBuType());
	//					dbEntity.getId().setBuCode(cdsEntry.getValue().getBuCode());
	//				}
	//				if (dbEntity.getCompanyCode() == null) {
	//					// Get company code and name
	//					Company vCompany = mCbdService.getCompanyForBusinessUnit(
	//							dbEntity.getId().getBuType(), dbEntity.getId()
	//									.getBuCode());
	//					// set company name and code
	//					dbEntity.setCompanyCode(vCompany == null ? null : vCompany
	//							.getCompanyCode());
	//					dbEntity.setCompanyName(vCompany == null ? null : vCompany
	//							.getCompanyName());
	//				}
	//
	//				dbEntity.setBuName(cdsEntry.getValue().getSiteName());
	//				dbEntity.setCountryCode(cdsEntry.getValue().getCountryCode());
	//				dbEntity.setTimeZone(cdsEntry.getValue().getTimeZone());
	//				if(dbEntity.getCompanyCode()!=null && dbEntity.getCompanyName()!=null)
	//					mBefIpayBusinessUnits.save(dbEntity);
	//				else
	//					mLog.warn("Error While inserting Values to iPay for ["+dbEntity.getId().getBuType()+","+dbEntity.getId().getBuCode()+"]: has insufficient data from CBD");
	//
	//			}
	//
	//			mLog.info("RetrieveSiteDataTasklet normal exit ......");
	//			return null;
	//
	//		} catch (Exception ex) {
	//			mLog.info("RetrieveSiteDataTasklet trew excpetion ......");
	//			throw new Exception("Error in RetrieveSiteDataTasklet", ex);
	//		}
	//	}
	//
	private Map<String, IpayBusinessUnits> getMap(
			List<IpayBusinessUnits> pIpayBusinessUnitsList) {

		Map<String, IpayBusinessUnits> vMap = new HashMap<String, IpayBusinessUnits>();

		if (pIpayBusinessUnitsList != null) {
			for (IpayBusinessUnits vIpayBusinessUnits : pIpayBusinessUnitsList) {
				vMap.put(key(vIpayBusinessUnits.getId().getBuType(),
						vIpayBusinessUnits.getId().getBuCode()),
						vIpayBusinessUnits);
			}
		}
		return vMap;

	}
	//
	//	/**
	//	 * Creates the key
	//	 * 
	//	 * @param pBuType
	//	 * @param pBuCode
	//	 * @return
	//	 */
	protected String key(String pBuType, String pBuCode) {
		return pBuType + "|" + pBuCode;
	}

	public void setBefIpayBusinessUnits(
			BefIpayBusinessUnits befIpayBusinessUnits) {
		mBefIpayBusinessUnits = befIpayBusinessUnits;
	}

	public void setCbdService(CbdService cbdService) {
		mCbdService = cbdService;
	}
	//
	//	public void setCdsService(CdsService cdsService) {
	//		mCdsService = cdsService;
	//	}

}
