package com.ikea.ebccardpaybatch1.batch;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.be.Country;
import com.ikea.ebccardpay1.cardpayment.be.ExchangeRate;
import com.ikea.ebccardpay1.cardpayment.bec.BecCountries;
import com.ikea.ebccardpay1.cardpayment.bec.BecCountry;
import com.ikea.ebccardpay1.cardpayment.bef.BefCountry;
import com.ikea.ebccardpay1.cardpayment.bef.BefExchangeRate;
import com.ikea.ebccardpay1.cardpayment.exception.ValueMissingException;
import com.ikea.ebccardpay1.cardpayment.vo.VoCountry;
import com.ikea.ebccardpaybatch1.cbd.CbdExchangeRates;
import com.ikea.ebccardpaybatch1.cbd.CbdExchangeRatesForCurrencies;
import com.ikea.ebccardpaybatch1.cbd.CbdService;
import com.ikea.ebcframework.exception.IkeaException;

public class UpdateExchangeRateFromCbdTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(UpdateExchangeRateFromCbdTasklet.class);

	private BefExchangeRate mBefExchangeRate;

	private BecCountry mBecCountry;

	private BecCountries mBecCountries;

	private CbdService mCbdService;

	private BefCountry mBefCountry;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {
		
		Set<String> vUniqueSetOfCurrenyCodes = getUniqueSetOfCurrenyCodes();
		CbdExchangeRatesForCurrencies vExchangeRatesForCurrencies = mCbdService
				.getExchangeRatesForCurrencies(vUniqueSetOfCurrenyCodes);
		updateRatesForAllCountries(vExchangeRatesForCurrencies);

		return RepeatStatus.FINISHED;
	}

	protected Set<String> getUniqueSetOfCurrenyCodes() throws IkeaException {
		Set<String> currencyCodes = new HashSet<String>();
		List<VoCountry> vCountries = null;
		try {
			vCountries = mBecCountries.findAllExchangeRateCountries();
		} catch (ValueMissingException e) {
			mLog.info("Error while reading country from database:" + e);
			return currencyCodes;
		}
		if (vCountries == null || vCountries.size() == 0) {
			return currencyCodes;
		}
		
		for (VoCountry vCountry : getList(vCountries)) {	
			currencyCodes.add(vCountry.getMainCurrencyNow());
		}
		return currencyCodes;
	}
	
	protected void updateRatesForAllCountries(CbdExchangeRatesForCurrencies pExchangeRatesForCurrencies)
			throws IkeaException, ValueMissingException {
		List<Country> vAllCountries = mBefCountry.findAll();

		for (Country vCountry : vAllCountries) {
			mBecCountry.init(vCountry);
			VoCountry vVoCountry = mBecCountry.getVoCountry();
			String vMainCurrencyNow = vVoCountry.getMainCurrencyNow();
			if (vMainCurrencyNow != null) {
				updateRatesForCountry(vCountry, vMainCurrencyNow,
						pExchangeRatesForCurrencies.getRatesForCurrency(vMainCurrencyNow));
			} else {
				mLog.warn("Country '" + vVoCountry.getCountryCode()
						+ "' does not have a Main Currency set.");
			}
		}
	}


	protected void updateRatesForCountry(Country pCountry,
			String pMainCurrencyNow, CbdExchangeRates pExchangeRatesForCurrency)
			throws IkeaException, ValueMissingException {

		Map<String, ExchangeRate> vExistingExchangeRatesForCountry = findExistingExchangeRatesForCountry(pCountry);

		for (String vToCurrencyCode : pExchangeRatesForCurrency.getAllCurrencyCode()) {
			
			Double vExchangeRateValue = (Double) pExchangeRatesForCurrency
					.getRate(vToCurrencyCode);

			ExchangeRate vExistingExchangeRate = vExistingExchangeRatesForCountry
					.get(vToCurrencyCode);
			if (vExistingExchangeRate == null) {
				vExistingExchangeRate = mBefExchangeRate.create();
				vExistingExchangeRate.setCountry(pCountry);
				vExistingExchangeRate.setFromCurrencyCode(pMainCurrencyNow);
				vExistingExchangeRate.setToCurrencyCode(vToCurrencyCode);
			}
			vExistingExchangeRate.setExchangeRate(new BigDecimal(
					vExchangeRateValue.toString()));
			vExistingExchangeRate.setFromDate(new Date());
			if (mLog.isDebugEnabled()) {
				mLog.debug("   "
						+ vExistingExchangeRate.getCountry().getCountryCode()
						+ " " + vExistingExchangeRate.getFromCurrencyCode()
						+ " " + vExistingExchangeRate.getToCurrencyCode() + " "
						+ vExistingExchangeRate.getExchangeRate());
			}
			mBefExchangeRate.save(
					vExistingExchangeRate);
		}

	}

	protected Map<String, ExchangeRate> findExistingExchangeRatesForCountry(Country pCountry)
			throws IkeaException {
		Map<String, ExchangeRate> vExistingExchangeRatesForCountry = new HashMap<String, ExchangeRate>();
		List<ExchangeRate> findCurrent = mBefExchangeRate.findCurrent(pCountry.getCountryId());
		for (ExchangeRate vCurrentExchangeRate : findCurrent) {
			vExistingExchangeRatesForCountry.put(vCurrentExchangeRate
					.getToCurrencyCode(), vCurrentExchangeRate);
		}
		return vExistingExchangeRatesForCountry;
	}

	@SuppressWarnings("unchecked")
	private List<VoCountry> getList(List<VoCountry> vCountries) {
		return vCountries;
	}
	
	public void setBefExchangeRate(BefExchangeRate pBefExchangeRate) {
		mBefExchangeRate = pBefExchangeRate;
	}

	public void setBecCountry(BecCountry pBecCountry) {
		mBecCountry = pBecCountry;
	}

	public void setBecCountries(BecCountries pBecCountries) {
		mBecCountries = pBecCountries;
	}

	public void setCbdService(CbdService pCbdService) {
		mCbdService = pCbdService;
	}

	public void setBefCountry(BefCountry pBefCountry) {
		mBefCountry = pBefCountry;
	}
}
