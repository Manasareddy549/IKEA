package com.ikea.ebccardpaybatch1.cbd;

import java.util.HashMap;
import java.util.Map;

public class CbdExchangeRatesForCurrencies {

	private Map<String, CbdExchangeRates> ratesForCurrencies = new HashMap<String, CbdExchangeRates>();
	
	public void setExchangeRatesForCurrency(String currencyCode, CbdExchangeRates rates){
		ratesForCurrencies.put(currencyCode, rates);
	}
	
	public CbdExchangeRates getRatesForCurrency(String currencyCode){
		CbdExchangeRates rateForCurrency = ratesForCurrencies.get(currencyCode);
		return rateForCurrency != null ? rateForCurrency : new CbdExchangeRates();
	}
	
}
