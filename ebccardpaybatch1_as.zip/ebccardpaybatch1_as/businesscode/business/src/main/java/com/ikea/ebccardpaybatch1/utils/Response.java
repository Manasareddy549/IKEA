package com.ikea.ebccardpaybatch1.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Response {
	
	public String _key;
	
	public String _code;
	
	public String _message;
	
	public String _requestId;
	
	public String _body_errorCode;
	
	public String _body_errorMsg;
	
	public String _body_dataMap_MQ_check_resultField;
	
	public String _body_dataMap_dataMD5;
	
	public String _body_dataMap_uploadFlowNo;
	
	public String _body_dataMap_MQ_executer_resultField;
	
	public String _body_dataMap_description;
	
	public String _body_dataMap_fileStatus;
	
	public String _body_dataMap_state;
	
	public String _body_dataMap_errorCode;
	
	public String _body_dataMap_errorMsg;
	
	
	
	
public String get_code() {
		return _code;
	}




	public String get_message() {
		return _message;
	}




	public String get_requestId() {
		return _requestId;
	}




	public String get_body_errorCode() {
		return _body_errorCode;
	}




	public String get_body_errorMsg() {
		return _body_errorMsg;
	}




	public String get_body_dataMap_MQ_check_resultField() {
		return _body_dataMap_MQ_check_resultField;
	}




	public String get_body_dataMap_dataMD5() {
		return _body_dataMap_dataMD5;
	}




	public String get_body_dataMap_uploadFlowNo() {
		return _body_dataMap_uploadFlowNo;
	}




	public String get_body_dataMap_MQ_executer_resultField() {
		return _body_dataMap_MQ_executer_resultField;
	}




	public String get_body_dataMap_description() {
		return _body_dataMap_description;
	}




	public String get_body_dataMap_fileStatus() {
		return _body_dataMap_fileStatus;
	}




	public String get_body_dataMap_state() {
		return _body_dataMap_state;
	}




	public String get_body_dataMap_errorCode() {
		return _body_dataMap_errorCode;
	}




	public String get_body_dataMap_errorMsg() {
		return _body_dataMap_errorMsg;
	}
	
	public Response(String jSonString)
	{
		json("",jSonString);
		
	}


	public Map json(String pParent,String pString)
	{
		Map opmap= new HashMap();
		JSONParser jsonParser = new JSONParser();
		Object obj;
		try {
			obj = jsonParser.parse(pString);
			JSONObject output = (JSONObject) obj;
			Set set=output.entrySet();

			for(Object key:set)
			{
				String data=key.toString();

				String[] datavalue=data.split("=");
				String Key=datavalue[0];
				String value;
				try{
					value=datavalue[1];
				}
				catch (ArrayIndexOutOfBoundsException e) {
					// TODO Auto-generated catch block
					value=null;
				}
				_key=pParent+"_"+Key;
				if(value!=null && value.contains("{"))
				{
					
					opmap.put(_key,json(_key,datavalue[1]));
				}
				else{
					opmap.put(_key, value);
					Field field=this.getClass().getField(_key);
					field.set(this, value);
					
				}
				_key="";
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return opmap;
	}


	

}

