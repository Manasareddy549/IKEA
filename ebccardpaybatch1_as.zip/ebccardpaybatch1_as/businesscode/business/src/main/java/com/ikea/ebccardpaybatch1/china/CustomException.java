package com.ikea.ebccardpaybatch1.china;

public class CustomException{
	   /**
	 * 
	 */
	private static final long serialVersionUID = -4746563175151106848L;
	private static String pException;
	
	public static String getException() {
		return pException;
	}
	public static void setException(String pException) {
		CustomException.pException = pException;
	}
	 

}