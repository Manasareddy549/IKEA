package com.ikea.ebccardpaybatch1.cbd;


/* Removed Compay Extract Function from existing Class,
 * Added implementation to fetch Active Business Units and Call CBD Company and TimeZone Business Service through Executor Service
 * CR-IKEA00901648 - anagc
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.utils.Unit;
import com.ikea.ebccbd1.client.bs.BsFindBusinessUnits;
import com.ikea.ebccbd1.client.bs.BsFindExcrtsByValidAt;
import com.ikea.ebccbd1.client.bs.BsFindParents1;
import com.ikea.ebccbd1.client.bs.BsGetBuFull;
import com.ikea.ebccbd1.client.bs.BsGetCompFunc;
import com.ikea.ebccbd1.client.bs.BsGetTimeZoneByBu;
import com.ikea.ebccbd1.client.vo.VoBuDesc;
import com.ikea.ebccbd1.client.vo.VoBuFind;
import com.ikea.ebccbd1.client.vo.VoBuFull;
import com.ikea.ebccbd1.client.vo.VoCluGet;
import com.ikea.ebccbd1.client.vo.VoCluStrMember;
import com.ikea.ebccbd1.client.vo.VoCompCompFuncDetails;
import com.ikea.ebccbd1.client.vo.VoCompFuncGet;
import com.ikea.ebccbd1.client.vo.VoExcrtByValidAt;
import com.ikea.ebccbd1.client.vo.VoExcrtFind;
import com.ikea.ebccbd1.client.vo.VoStructureGet;
import com.ikea.ebccbd1.client.vo.VoStructureResult;
import com.ikea.ebcframework.client.BsExecuter;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;
import com.ikea.ebcframework.services.AbstractBsClient;
import com.ikea.ebcframework.spring.BeanFactory;

public class CbdServiceBsImpl implements CbdService {

	private static final Logger mLog = LoggerFactory.getLogger(CbdServiceBsImpl.class);

	private static String BU_TYPE_STO = "STO";

	private static String BU_TYPE_SO = "SO";

	private static String BU_TYPE_CSC = "CSC";

	private Date mValidAt = new Date();

	private ArrayList<Unit> mBuList= new ArrayList<Unit>();
	private ArrayList<Unit> mUpdateBuList= new ArrayList<Unit>();
	
	public CbdExchangeRatesForCurrencies getExchangeRatesForCurrencies(
			Set<String> pCurrencyCodes) throws IkeaException {
		CbdExchangeRatesForCurrencies vExchangeRates = new CbdExchangeRatesForCurrencies();
		for (String vCurrencyCode : pCurrencyCodes) {

			BsFindExcrtsByValidAt vBsFindExcrtsByValidAt = new BsFindExcrtsByValidAt();
			VoExcrtFind vVoExcrtFind = new VoExcrtFind();
			vVoExcrtFind.setConvertFromCurCode(vCurrencyCode);
			vVoExcrtFind.setExcrtType("SPOT");

			vBsFindExcrtsByValidAt.setVoExcrtFindIn(vVoExcrtFind);
			BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
			vBsExecuter.executeBs(vBsFindExcrtsByValidAt);


			if (getApplicationErrorList(vBsFindExcrtsByValidAt) == null
					|| getApplicationErrorList(vBsFindExcrtsByValidAt)
					.isEmpty()) {
				List<VoExcrtByValidAt> vVoExcrtFindOutList = vBsFindExcrtsByValidAt
						.getVoExcrtFindOutList();

				if (vVoExcrtFindOutList != null
						&& !vVoExcrtFindOutList.isEmpty()) {
					vExchangeRates.setExchangeRatesForCurrency(vCurrencyCode,
							convertToCurrencyCodeAndRate(vVoExcrtFindOutList,
									pCurrencyCodes));
				}

			} else {
				for (ApplicationError vError : getApplicationErrorList(vBsFindExcrtsByValidAt)) {

					mLog
					.warn("Error when collecting currency exchange rate for "
							+ vCurrencyCode
							+ " from CBD: "
							+ vError.getMessage());
				}
			}
		}

		return vExchangeRates;
	}

	@SuppressWarnings("unchecked")
	private List<ApplicationError> getApplicationErrorList(
			BsFindExcrtsByValidAt vBsFindExcrtsByValidAt) {
		return vBsFindExcrtsByValidAt.getApplicationErrors();
	}

	public CbdExchangeRates convertToCurrencyCodeAndRate(
			List<VoExcrtByValidAt> vVoExcrtFindOutList, Set<String> pCurrencies) {
		CbdExchangeRates vCbdExchangeRates = new CbdExchangeRates();

		for (VoExcrtByValidAt vVoExcrtByValidAt : vVoExcrtFindOutList) {
			if (!vVoExcrtByValidAt.getConvertFromCurCode().equals(
					vVoExcrtByValidAt.getConvertToCurCode())
					&& pCurrencies.contains(vVoExcrtByValidAt
							.getConvertToCurCode())) {

				vCbdExchangeRates.setExchangeRate(vVoExcrtByValidAt
						.getConvertToCurCode(), new Double(vVoExcrtByValidAt
								.getExchangeRate()));
			}

		}
		return vCbdExchangeRates;
	}



	//	public Company getCompanyForBusinessUnit(String pBuType, String pBuCode)
	//			throws IkeaException {
	//		try{
	//			BsGetBuFull vBsGetBuFull = setupBsGetBuFull(pBuType, pBuCode);
	//
	//			BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
	//			vBsExecuter.executeBs(vBsGetBuFull);
	//			if (logError("Error getting BU[" + pBuType + ", " + pBuCode + "]",
	//					getApplicationErrorList(vBsGetBuFull)))
	//				return null;
	//
	//			String vClassUnitCode = extractClassUnitCode(pBuType, //
	//					vBsGetBuFull.getVoBuFullOut());
	//			if (vClassUnitCode == null) {
	//				mLog.warn("No ClassUnitCode found for [" + pBuType + ", " + pBuCode
	//						+ "]");
	//				return null;
	//			}
	//
	//			BsGetCompFunc vBsGetCompFunc = setupBsGetCompFunc(vClassUnitCode);
	//			vBsExecuter.executeBs(vBsGetCompFunc);
	//
	//			if (logError("Error getting CompFunc for BU[" + pBuType + ", "
	//					+ pBuCode + "], ClassUnitCode " + vClassUnitCode,
	//					getApplicationErrorList(vBsGetCompFunc)))
	//				return null;
	//
	//			String parentBuCode = extractParentBuCode(vBsGetCompFunc
	//					.getVoCompCompFuncOut());
	//
	//			BsFindParents1 vBsFindParents1 = setupBsFindParents1(vClassUnitCode);
	//			vBsExecuter.executeBs(vBsFindParents1);
	//
	//			if (logError("Error finding Parents for BU[" + pBuType + ", " + pBuCode
	//					+ "], ClassUnitCode " + vClassUnitCode,
	//					getApplicationErrorList(vBsFindParents1)))
	//				return null;
	//
	//			return extractCompany(parentBuCode, vBsFindParents1);
	//		}catch (Exception e) {
	//			mLog.error("RetrieveSiteDataJob ERROR : failed while retriving company information for ["+ pBuType + ", " + pBuCode	+"] from CBD. Error message : "+e.getMessage());
	//			return null;
	//		}
	//
	//	}

//	public BsGetBuFull setupBsGetBuFull(String pBuType, String pBuCode) {
//		BsGetBuFull vBsGetBuFull = new BsGetBuFull();
//		VoCluGet vVoCluGet = new VoCluGet();
//		vVoCluGet.setClutType(pBuType);
//		vVoCluGet.setCluCode(pBuCode);
//		vVoCluGet.setValidAt(mValidAt);
//		vBsGetBuFull.setVoCluGetIn(vVoCluGet);
//		return vBsGetBuFull;
//	}

//	public String extractClassUnitCode(String pBuType, VoBuFull pVoBuFull) {
//		String legClassUnitCode = null;
//		String orgClassUnitCode = null;
//		List<VoCluStrMember> vVoCluStrMemberList = pVoBuFull.getVoBuStructure()
//				.getVoCluStrParentList(); // or that
//
//		for (VoCluStrMember member : vVoCluStrMemberList) {
//			if (member.getStructureType().equals("LEG"))
//			{
//				if(member.getClassUnitType().equals("RET"))
//				{
//					legClassUnitCode = member.getClassUnitCode();
//				}
//			}	
//			if (member.getStructureType().equals("ORG"))
//			{
//
//				if(member.getClassUnitType().equals("RET"))
//				{
//					orgClassUnitCode = member.getClassUnitCode();
//				}
//			}
//		}
//		return pBuType.equals("STO") ? legClassUnitCode : orgClassUnitCode;
//	}

//	public BsGetCompFunc setupBsGetCompFunc(String pClassUnitCode) {
//		BsGetCompFunc vBsGetCompFunc = new BsGetCompFunc();
//		VoCompFuncGet vVoCompFuncGet = new VoCompFuncGet();
//		vVoCompFuncGet.setCUTClass("CF");
//		vVoCompFuncGet.setCUTType("RET");
//		vVoCompFuncGet.setCompFuncCode(pClassUnitCode);
//		vVoCompFuncGet.setValidAt(mValidAt);
//		vBsGetCompFunc.setVoCompFuncGetIn(vVoCompFuncGet);
//		return vBsGetCompFunc;
//	}

//	public String extractParentBuCode(
//			VoCompCompFuncDetails pVoCompCompFuncDetails) {
//		return pVoCompCompFuncDetails.getBUCode();
//	}

//	public BsFindParents1 setupBsFindParents1(String pClassUnitCode) {
//		BsFindParents1 vBsFindParents1 = new BsFindParents1();
//		List<VoStructureGet> vVoStructureGetList = new ArrayList<VoStructureGet>();
//		VoStructureGet vVoStructureGet = new VoStructureGet();
//		vVoStructureGet.setClassType("CF");
//		vVoStructureGet.setClassUnitType("RET");
//		vVoStructureGet.setClassUnitCode(pClassUnitCode);
//		vVoStructureGet.setStructureType("CFUNC");
//		vVoStructureGet.setClassTypeFound("BU");
//		vVoStructureGet.setClassUnitTypeFound("COM");
//		vVoStructureGetList.add(vVoStructureGet);
//		vBsFindParents1.setVoFindParents1InList(vVoStructureGetList);
//		return vBsFindParents1;
//	}

//	public Company extractCompany(String parentBuCode,
//			BsFindParents1 pBsFindParents1) {
//		Company vCompany = null;
//		List<VoStructureResult> parents = getList(pBsFindParents1);
//		if (parents.size() > 0) {
//			vCompany = new Company();
//			vCompany.setCompanyCode(parentBuCode);
//			vCompany.setCompanyName(parents.get(0).getClassUnitNameFound());
//		}
//		return vCompany;
//	}

	//@SuppressWarnings("unchecked")
//	private List<ApplicationError> getApplicationErrorList(
//			Object pEbcError) {
//		return ((AbstractBsClient) pEbcError).getApplicationErrors();
//	}


	@SuppressWarnings("unchecked")
	private List<VoStructureResult> getList(BsFindParents1 pBsFindParents1) {
		return pBsFindParents1.getVoFindParents1OutList();
	}

//	private boolean logError(String text, List<ApplicationError> list) {
//		if (list == null || list.isEmpty())
//			return false;
//		for (ApplicationError vError : list) {
//			mLog.error(text + ": " + vError.getMessage());
//		}
//		return true;
//	}

//	public void getCompanyAndTime()
//	{
//		ArrayList<Unit> pUpdatedBuList= new ArrayList<Unit>();
//		BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
//		mLog.info("Fetching Company and Time");
//		for(Unit mUnit:mBuList)
//		{
//
//			String pBu_Type=mUnit.getBuType();
//			String pBu_Code=mUnit.getBuCode();
//
//			//get Company info
//
//			//Get BU Full
//			BsGetBuFull vBsGetBuFull = setupBsGetBuFull(pBu_Type, pBu_Code);
//			vBsExecuter.executeBs(vBsGetBuFull);
//			if(logError("Error getting BU[" + pBu_Type + ", " + pBu_Code + "]",
//					getApplicationErrorList(vBsGetBuFull))){}
//			else{
//				String vClassUnitCode =extractClassUnitCode(pBu_Type, vBsGetBuFull.getVoBuFullOut());
//				if (vClassUnitCode == null) {
//					mLog.error("No ClassUnitCode found for [" + pBu_Type + ", " + pBu_Code+ "]");
//				}
//				else{
//					//get Company Code
//					BsGetCompFunc vBsGetCompFunc = setupBsGetCompFunc(vClassUnitCode);
//					vBsExecuter.executeBs(vBsGetCompFunc);
//					if(logError("Error getting Company for [" + pBu_Type + ", " + pBu_Code + "]",
//							getApplicationErrorList(vBsGetCompFunc))){}
//					else{
//						String pCompany_code = extractParentBuCode(vBsGetCompFunc
//								.getVoCompCompFuncOut());
//
//						//get Company Name
//						BsFindParents1 vBsFindParents1 = setupBsFindParents1(vClassUnitCode);
//						vBsExecuter.executeBs(vBsFindParents1);
//						if(logError("Error getting Parent Code for [" + pBu_Type + ", " + pBu_Code + "]",
//								getApplicationErrorList(vBsFindParents1))){}
//						else{
//							Company pCompany= extractCompany(pCompany_code, vBsFindParents1);
//							mUnit.setCompanyCode(pCompany.getCompanyCode());
//							mUnit.setCompanyName(pCompany.getCompanyName());
//						}
//
//					}
//				}
//			}
//			//End Company info
//
//			//start Time info
//			BsGetTimeZoneByBu vBsGetTimeZoneByBu= new BsGetTimeZoneByBu();
//			vBsGetTimeZoneByBu.setBuCode(pBu_Code);
//			vBsGetTimeZoneByBu.setBuType(pBu_Type);			
//			vBsExecuter.executeBs(vBsGetTimeZoneByBu);
//			if(logError("Error getting TimeZone for [" + pBu_Type + ", " + pBu_Code + "]",
//					getApplicationErrorList(vBsGetTimeZoneByBu))){}
//			else{
//				String mTimeZone=vBsGetTimeZoneByBu.getTimeZoneAddressInformationList().get(0).getTzCode();
//				if(mTimeZone.length()>1)
//				{
//					mUnit.setTimeZone(mTimeZone);
//				}
//			}
//			mLog.debug("Bu_code: "+mUnit.getBuCode()+" , "
//					+"Bu_Type: "+mUnit.getBuType()+" , "
//					+"Bu_Name: "+mUnit.getSiteName()+" , "
//					+"Bu_Name: "+mUnit.getSiteName()+" , "
//					+"Country: "+mUnit.getCountryCode()+" , "
//					+"Company_code: "+mUnit.getCompanyCode()+" , "
//					+"Company_name: "+mUnit.getCompanyName()+" , "
//					+"Time_zone: "+mUnit.getTimeZone());
//			
//		}
//		mLog.info("Fetching Company and Time Exit...");
//
//	}

	public void getSitesFromCBD()
	{
		// TODO Auto-generated method stub
		ArrayList<String> vBuTypes= new  ArrayList<String>();
		vBuTypes.add(BU_TYPE_STO);
		vBuTypes.add(BU_TYPE_SO);
		vBuTypes.add(BU_TYPE_CSC);
		for(String vBuType:vBuTypes) 
		{
			BsFindBusinessUnits vBsFindBusinessUnits= new BsFindBusinessUnits();
			try{
				mLog.info("Fetching Active sites for Bu_Type "+vBuType);		
				VoBuFind vVoBuFind= new VoBuFind();
				vVoBuFind.setBuType(vBuType);
				vBsFindBusinessUnits.setVoFindBuIn(vVoBuFind);
				BsExecuter vBsExecuter = BeanFactory.getBsExecuter();
				vBsExecuter.executeBs(vBsFindBusinessUnits);
				List<VoBuDesc> vBuTypeList=vBsFindBusinessUnits.getVoFindBuOutList();
				mLog.info("Found "+vBuTypeList.size()+" Active sites for Bu_Type "+vBuType);
				for(VoBuDesc vVoBuDesc:vBuTypeList)
				{
					Unit vUnit = new Unit();
					vUnit.setBuCode(vVoBuDesc.getBuCode());
					vUnit.setBuType(vVoBuDesc.getBuType());
					vUnit.setSiteName(vVoBuDesc.getBuName());
					vUnit.setCountryCode(vVoBuDesc.getVoCountryName().getGACodeCty());
					mBuList.add(vUnit);			
				}
			} catch (Exception e) {
				mLog.error("Error occured, Error While fetching BusinessUnits"+e);
				mLog.error("EBC error: " + vBsFindBusinessUnits.getApplicationErrors().toString());

			}
		}
	}

	public ArrayList<Unit> iPaySitesfromCBD()throws IkeaException
	{
		getSitesFromCBD();
		ExecutorService executorService = Executors.newFixedThreadPool(15);
		Set<Future<Unit>> set = new HashSet<Future<Unit>>();
		for(Unit mUnit:mBuList)
		{
		Callable<Unit> callable = new CbdFetchComAndTz(mUnit);
		Future<Unit> future = executorService.submit(callable);
		set.add(future);
		}
		for(Future<Unit> future : set)
		{
			try {
				mUpdateBuList.add(future.get());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		executorService.shutdown();
		//getCompanyAndTime();

		return mUpdateBuList;
	}



}
