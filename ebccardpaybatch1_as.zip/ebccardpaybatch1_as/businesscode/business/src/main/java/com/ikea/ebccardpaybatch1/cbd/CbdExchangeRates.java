package com.ikea.ebccardpaybatch1.cbd;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CbdExchangeRates {
	
	private Map<String, Double> rates = new HashMap<String, Double>();
	
	public void setExchangeRate(String currencyCode, Double rate){
		rates.put(currencyCode, rate);
	}
	
	public Double getRate(String currencyCode){
		return rates.get(currencyCode);
	}

	public Set<String> getAllCurrencyCode(){
		return rates.keySet();
	}
	
}
