package com.ikea.ebccardpaybatch1.batch;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.ebccardpay1.cardpayment.be.IpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.be.KPI;
import com.ikea.ebccardpay1.cardpayment.bef.BefIpayBusinessUnits;
import com.ikea.ebccardpay1.cardpayment.bef.BefKPI;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.utils.Units;

public class CalculateKpiTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(CalculateKpiTasklet.class);

	private String kpiType;
	private String buCode;
	private String buType;
	private String kpiInterval;

	private Units mUnits;
	
	@Autowired
	private BefKPI mBefKPI;
	
	@Autowired
	private BefIpayBusinessUnits mBefIpayBusinessUnits;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {

		mLog.info("Calculating " + kpiInterval + " for " + buType + buCode
				+ " " + kpiType + "...");

		// Get time zone
		String vTimeZoneId = mUnits.getTimeZone(buType, buCode);

		// Let BEF execute query (StartDate and EndDate will always be the same
		// day, therefore the same as kpiIntervall)
		List<Map<String, Object>> vKPIValues = mBefKPI.calculate(kpiType,
				buType, buCode, kpiInterval, kpiInterval);

		if (vKPIValues == null || vKPIValues.isEmpty()) {
			// Save an "empty" KPI entity for this day to indicate that it
			// has been calculated correctly but not found any values.
			KPI vKPI = createKpiEntity(vTimeZoneId, null, null);
			mBefKPI.save(vKPI);
		} else {
			// Retrieve rows
			for (Map<String, Object> vKPIValue : vKPIValues) {
				
				String vFromBuType = objectToString(vKPIValue.get("fromBuType"));
				String vFromBuCode = objectToString(vKPIValue.get("fromBuCode"));

				KPI vKPI = createKpiEntity(vTimeZoneId, vFromBuType, vFromBuCode);

				// Fetch values from object array, all queries must have some or
				// all of these values
				vKPI.setCardType(objectToString(vKPIValue.get("cardType")));
				vKPI.setSourceSystem(objectToString(vKPIValue
						.get("sourceSystem")));
				vKPI.setEmployee(objectToString(vKPIValue.get("employee")));
				vKPI.setFromCountryCode(objectToString(vKPIValue
						.get("fromCountryCode")));
				vKPI.setToCountryCode(objectToString(vKPIValue
						.get("toCountryCode")));
				vKPI.setFromCurrencyCode(objectToString(vKPIValue
						.get("fromCurrencyCode")));
				vKPI.setToCurrencyCode(objectToString(vKPIValue
						.get("toCurrencyCode")));		
				
				String vFinancialType = objectToString(vKPIValue
						.get("financialType"));

				BigDecimal vBalanceChange = (BigDecimal) vKPIValue
						.get("amountSum");
				BigDecimal vCardAmountSum = (BigDecimal) vKPIValue
						.get("cardAmountSum");
				if (vCardAmountSum == null){
					vCardAmountSum = Amounts.zero();
				}
				
				Long vTransactionNo = (Long) vKPIValue.get("transactionCount");

				// Set the amounts and count depending on financial type
				if (Constants.FINANCIAL_TYPE_CONSTANT_CREDIT
						.equals(vFinancialType)) {
					vKPI.setCreditAmount(vBalanceChange);
					vKPI.setCardCreditAmount(vCardAmountSum);
					vKPI.setCreditCount(vTransactionNo);
				} else if (Constants.FINANCIAL_TYPE_CONSTANT_DEBIT
						.equals(vFinancialType)) {
					vKPI.setDebitAmount(vBalanceChange);
					vKPI.setCardDebitAmount(vCardAmountSum);
					vKPI.setDebitCount(vTransactionNo);
				}

				mBefKPI.save(vKPI);
			}
		}

		mLog.info("Calculating " + kpiInterval + " for " + buType + buCode
				+ " " + kpiType + " done. Found " + vKPIValues.size()
				+ " values.");

		return RepeatStatus.FINISHED;
	}

	private KPI createKpiEntity(String vTimeZoneId, String pFromBuType, String pFromBuCode) {
		KPI vKPI = mBefKPI.create();

		// Set KPI information
		vKPI.setBuCode(buCode);
		vKPI.setBuType(buType);
		vKPI.setFromBuType(pFromBuType);
		vKPI.setFromBuCode(pFromBuCode);
		vKPI.setKpiInterval(kpiInterval);
		vKPI.setKpiTimeZone(vTimeZoneId);
		vKPI.setKpiType(kpiType);

		// Reset KPI values
		// TODO Set default values in field declaration?
		vKPI.setCreditAmount(Amounts.zero());
		vKPI.setCardCreditAmount(Amounts.zero());
		vKPI.setCreditCount(0);
		vKPI.setDebitAmount(Amounts.zero());
		vKPI.setCardDebitAmount(Amounts.zero());
		vKPI.setDebitCount(0);
		
		//Reference to business unit. ("To business unit")
		IpayBusinessUnits vIpayBusinessUnits = mBefIpayBusinessUnits.findByPrimaryKey(buType, buCode);		
		vKPI.setIpayBusinessUnits(vIpayBusinessUnits);
		
		//Reference to business unit. ("From business unit")
		if(pFromBuType!=null && pFromBuCode!=null){
			vIpayBusinessUnits =  mBefIpayBusinessUnits.findByPrimaryKey(pFromBuType, pFromBuCode);
			vKPI.setFromIpayBusinessUnits(vIpayBusinessUnits);
		}
		
		return vKPI;
	}

	private String objectToString(Object pObject) {
		return pObject == null ? null : pObject.toString();
	}

	public void setKpiType(String pKpiType) {
		kpiType = pKpiType;
	}

	public void setBuCode(String pBuCode) {
		buCode = pBuCode;
	}

	public void setBuTyp(String pBuTyp) {
		buType = pBuTyp;
	}

	public void setKpiInterval(String pKpiInterval) {
		kpiInterval = pKpiInterval;
	}
	
	public void setUnits(Units pUnits) {
		mUnits = pUnits;
	}

	public void setBefKPI(BefKPI pBefKPI) {
		mBefKPI = pBefKPI;
	}
	
	public void setBefIpayBusinessUnits(BefIpayBusinessUnits pBefIpayBusinessUnits) {
		mBefIpayBusinessUnits= pBefIpayBusinessUnits;
	}
	

}
