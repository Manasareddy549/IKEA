package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.bec.BecProcessExpiredCrads;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;


@Component
public class ExpiredCardsJobCreator extends AbstractJobCreator {

	private final static Logger expiredCardsJobCreator = LoggerFactory
			.getLogger(ExpiredCardsJobCreator.class);

	@Autowired
	private BecProcessExpiredCrads mBecProcessExpiredCrads;

	public void createNewJobs() {

		expiredCardsJobCreator.info("Executing the ExpiredCardsJobCreator ");
		try {
			
			//int size = mBecProcessExpiredCrads.getCardSize();
			
			List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

			VoJobParam vTimeParam = new VoJobParam();
			vTimeParam.setName(BatchJobArguments.EXPIRED_CARD_TIMESTAMP);
			vTimeParam.setValue(new Long(System.currentTimeMillis()).toString());
			vVoJobParamList.add(vTimeParam);

			sendAsyncJobExecutionRequest(BatchJobType.expiredCardsJob,vVoJobParamList);

		} catch (Exception e) {
			expiredCardsJobCreator.error(e.getMessage());
		}

		expiredCardsJobCreator
				.info("Executing the ExpiredCardsJobCreator  Ends");

	}

}
