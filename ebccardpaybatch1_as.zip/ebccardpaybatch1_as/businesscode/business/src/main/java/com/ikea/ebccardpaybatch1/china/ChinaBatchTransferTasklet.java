package com.ikea.ebccardpaybatch1.china;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import sun.misc.BASE64Encoder;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.csb.sdk.HttpCaller;
import com.alibaba.csb.sdk.HttpParameters;
import com.ikea.ebccardpay1.cardpayment.be.CnCardBatchJob;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCardBatchJob;
import com.ikea.ebccardpaybatch1.utils.Response;
import com.ikea.ebcframework.services.EbcProperties;

public class ChinaBatchTransferTasklet implements Tasklet{
	private static final Logger mLog = LoggerFactory
			.getLogger(ChinaBatchTransferTasklet.class);

	private BefCnCardBatchJob befCnCardBatchJob;

	private String cnCardBatchJobIds;

	@Autowired
	EbcProperties ebcProperties;

	private HashMap<String,String> mData=null;

	int length = 1024 * 20;

	private int retry=0;

	private long retryInterval=0L;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		mLog.info("Executing China BatchTransfer Tasklet");

		setproperties();
		List<CnCardBatchJob> mList= null;
		Exception finalException=null;
		for(int i=1;i<=retry;i++)
		{
			if(i!=1)
				mLog.warn("Attempting Batch Transfer: "+i+" time");

			mLog.info("Finding Blob Files to Transfer");
			try{
				mList=befCnCardBatchJob.getBlobFilesToRegister(cnCardBatchJobIds);
				if(mList!=null)
				{
					if(mList.size()>0)
					{
						mLog.info("Found Blob Files to Transfer");
						String[] output=null;

						//Generate Md5
						String md5String=generateMd5(mList);

						if(md5String==null)
						{
							CustomException.setException("25115-Md5 String Generation Error");

							chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
							return RepeatStatus.FINISHED;
						}
						//Get File Size
						String fileLength=getFileSize(mList);

						if(md5String==null)
							throw new Exception("25115-Md5 String Generation Error");

						ArrayList<String> mEncodedList=encodeBlobFile(mList);

						if(mEncodedList==null)
						{
							CustomException.setException("25115-Base64 Encoding failed");
							chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
							return RepeatStatus.FINISHED;
						}

						output=jsonStringTransfer(md5String,fileLength,mEncodedList);

						for(CnCardBatchJob mCnCardBatchJob:mList)
						{
							CnCardBatchJob pCnCardBatchJob=mCnCardBatchJob;
							StringBuffer job_id=new StringBuffer(pCnCardBatchJob.getJobExecutionIds());
							job_id.append(","+chunkContext.getStepContext().getStepExecution().getJobExecutionId());						
							pCnCardBatchJob.setJobExecutionIds(job_id.toString());
							pCnCardBatchJob.setFlowNumber(output[1]);
							pCnCardBatchJob.setMd5String(md5String);
							pCnCardBatchJob.setStatus("TRANSFERRED");//TRANSFERED
							pCnCardBatchJob.setErrorMessage(null);
							befCnCardBatchJob.update(pCnCardBatchJob);
						}
						chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("flowNumber",output[1]);

						return RepeatStatus.FINISHED;

					}
				}
				else{
					throw new Exception("25115-No blob file found for transfer.");
				}
			}
			catch(Exception e)
			{
				mLog.error("Batch Transfer Failed Due to: ",e);

				if(mList!=null)
				{
					for(CnCardBatchJob mCnCardBatchJob:mList)
					{
						CnCardBatchJob pCnCardBatchJob=mCnCardBatchJob;
						pCnCardBatchJob.setStatus("FAILED");
						pCnCardBatchJob.setErrorMessage(e.getLocalizedMessage());
						befCnCardBatchJob.update(pCnCardBatchJob);
					}
				}

				Thread.sleep(retryInterval); // 5 Minutes
				//mLog.warn("Attempting Batch Transfer: "+(i+1)+" time");
				finalException=e;
			}
		}
		if(finalException.getLocalizedMessage().equals("25115-No blob file found for transfer."))
		{
			return RepeatStatus.FINISHED;
		}
		else{
			mLog.warn("Blob Transfer failed");
			CustomException.setException(finalException.getLocalizedMessage());
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
			return RepeatStatus.FINISHED;
		}

	}


	public String generateMd5(List<CnCardBatchJob> mBlobList)
	{
		String fileMD5=null;
		try{
			MessageDigest digest=MessageDigest.getInstance("MD5");
			int len;
			byte buffer[] = new byte[1024];
			for(CnCardBatchJob mCnCardBatchJob:mBlobList)
			{
				Blob mBlobFile=mCnCardBatchJob.getBlobFile();
				InputStream in = mBlobFile.getBinaryStream();
				while ((len = in.read(buffer, 0, 1024)) != -1) {  
					digest.update(buffer, 0, len);  
				}  
			}

			BigInteger bigInt = new BigInteger(1, digest.digest()); 
			fileMD5=bigInt.toString(16);
			mLog.info("MD5 "+fileMD5);
			return fileMD5;
		}
		catch(Exception e)
		{
			mLog.error("Md5 String Generation failed due to exception: ",e);
		}
		return null;
	}

	public String getFileSize(List<CnCardBatchJob> mBlobList)
	{
		long size= 0L;
		String sizeString=null;
		try{


			for(CnCardBatchJob mCnCardBatchJob:mBlobList)
			{
				Blob mBlobFile=mCnCardBatchJob.getBlobFile();
				size=size+mBlobFile.length();
				sizeString=Long.toString(size);;
			}
			return sizeString;
		}
		catch(Exception e)
		{
			mLog.error("File Size Generation Error: ",e);
		}
		mLog.info("File Size "+size);
		return null;
	}

	public ArrayList<String> encodeBlobFile(List<CnCardBatchJob> mBlobList)
	{
		ArrayList<String> mEncodedDataList= new ArrayList<String>();
		try{
			for(CnCardBatchJob mCnCardBatchJob:mBlobList)
			{
				Blob mBlobFile=mCnCardBatchJob.getBlobFile();
				InputStream in = mBlobFile.getBinaryStream();
				byte[] buffer = new byte[length];
				int bytesRead = 0;
				bytesRead = in.read(buffer);
				if(bytesRead<length)
				{
					byte[] destbuff = new byte[bytesRead];
					System.arraycopy(buffer, 0, destbuff, 0, bytesRead);
					mEncodedDataList.add(encodeData(destbuff));
				}
				else
				{
					mEncodedDataList.add(encodeData(buffer));
					bytesRead=in.read(buffer);
					while(bytesRead !=-1)
					{
						byte[] destbuff = new byte[bytesRead];
						System.arraycopy(buffer, 0, destbuff, 0, bytesRead);				
						mEncodedDataList.add(encodeData(destbuff));			
						bytesRead=in.read(buffer);
					}

				}
			}
			return mEncodedDataList;
		}
		catch(Exception e)
		{
			mLog.error("Encoding Error: ",e);
		}
		return null;
	}

	public String encodeData(byte[] buffer)
	{
		int bytesRead = 0;
		bytesRead = buffer.length;
		BASE64Encoder encoder = new BASE64Encoder(); 
		byte[] destbuff = new byte[bytesRead];
		System.arraycopy(buffer, 0, destbuff, 0, bytesRead);
		String aesBase64 = encoder.encode(destbuff).replaceAll("[\r\n]", "");

		return aesBase64;
	}






	public String[] jsonStringTransfer(String pMd5String,String pFileLength,ArrayList<String> pEncodedList) throws Exception
	{
		mLog.info("Binding Card Data");
		SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");
		String toDayDateString =dateFormater.format(new DateTime().toDate());
		String fileName="file"+toDayDateString;
		int offSet=0;
		String[] output=null;
		if(pEncodedList.size()==1)
		{
			String endFileFlag="Y";

			String sendCardsJsonData = "{\"dataMap\":{\"fileMD5\":\"" + pMd5String + "\",\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\","
					+ "\"fileSize\":\"" + pFileLength + "\"," + "\"fileName\":\""+fileName+"\"," + "\"fileOffset\":\"" + offSet
					+ "\"," + "\"uploadEnd\":\"" + endFileFlag + "\"," + "\"fileContent\":\"" + pEncodedList.get(0).toString() + "\"}}";
			mLog.debug(sendCardsJsonData);
			List<String> mEncryptedString=getEncryptedString(sendCardsJsonData);
			output=sendData(mEncryptedString);
			if (output[1]==null)
			{
				mLog.error("FlowNumber null");
				throw new Exception("25115-Flow Number Recieved is null");
			}
			return output;

		}
		else{


			String sendCardsJsonData=null;
			for(int i=0;i<pEncodedList.size();i++)
			{
				if(i==0)
				{

					String endFileFlag="N";
					String aesBase64=pEncodedList.get(0).toString();
					sendCardsJsonData = "{\"dataMap\":{\"fileMD5\":\"" + pMd5String + "\",\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\","
							+ "\"fileSize\":\"" + pFileLength + "\"," +"\"fileName\":\""+fileName+"\","  + "\"fileOffset\":\"" + offSet
							+ "\"," + "\"uploadEnd\":\"" + endFileFlag + "\"," + "\"fileContent\":\"" + aesBase64 + "\"}}";
					mLog.debug(sendCardsJsonData);
					List<String> mEncryptedString=getEncryptedString(sendCardsJsonData);
					output=sendData(mEncryptedString);
					if (output[1]==null)
					{
						mLog.error("FlowNumber null");
						throw new Exception("25115-Flow Number Recieved is null");
					}
				}
				else if(i!=0 && i<(pEncodedList.size()-1))
				{
					offSet=offSet+pEncodedList.get(i).toString().length();
					String aesBase64=pEncodedList.get(i).toString();
					String endFileFlag="N";
					sendCardsJsonData = "{\"dataMap\":{\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\"," + "\"uploadFlowNo\":\"" + output[1]
							+ "\"," + "\"fileOffset\":\"" + offSet + "\"," + "\"uploadEnd\":\"" + endFileFlag + "\","
							+ "\"fileContent\":\"" + aesBase64 + "\"}}";
					mLog.debug(sendCardsJsonData);
					List<String> mEncryptedString=getEncryptedString(sendCardsJsonData);
					output=sendData(mEncryptedString);
				}
				else if(i==(pEncodedList.size()-1))
				{
					offSet=offSet+pEncodedList.get(i).toString().length();
					String aesBase64=pEncodedList.get(i).toString();
					String endFileFlag="Y";
					sendCardsJsonData = "{\"dataMap\":{\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\"," + "\"uploadFlowNo\":\"" + output[1]
							+ "\"," + "\"fileOffset\":\"" + offSet + "\"," + "\"uploadEnd\":\"" + endFileFlag + "\","
							+ "\"fileContent\":\"" + aesBase64 + "\"}}";
					mLog.debug(sendCardsJsonData);
					List<String> mEncryptedString=getEncryptedString(sendCardsJsonData);
					output=sendData(mEncryptedString);
				}
				
				if (output[1]==null)
				{
					mLog.error("FlowNumber null");
					throw new Exception("25115-Flow Number Recieved is null");
				}

			}
			return output;
		}

	}




	public String[] sendData(List<String> mEncryptedString) throws Exception
	{
		mLog.debug("Sending Card Data");
		String[] mOutput=new String[2];
		try{

			String jsonDataEncrypt = mEncryptedString.get(1);

			String subPasswordEncrpt = mEncryptedString.get(2);


			HttpParameters.Builder builder = new HttpParameters.Builder();
			String result = "";

			builder.api("fileUploadDataService").version("1.0.0").requestURL(mData.get("url").toString()).method("POST").accessKey(mData.get("ak").toString()).secretKey(mData.get("sk").toString())
			.putParamsMap("dataMap", "{\"dataMap\":{\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\",\"symmetricKeyEncrpt\":\""
					+ subPasswordEncrpt + "\",\"jsonDataEncrypt\":\"" + jsonDataEncrypt + "\"}}");
			HttpParameters mParameter=builder.build();
			mLog.debug(mParameter.toString());

			result = HttpCaller.invoke(mParameter);
			result = HttpCaller.changeCharset(result);
			mOutput[0]=result;
			mLog.debug(result);
			Response mResponse = new Response(result);
			//iPay 4.4R - 254264 feature - reverted
			if(mResponse.get_body_dataMap_errorCode()!=null && !(mResponse.get_body_dataMap_errorCode().equalsIgnoreCase("0")))
			{
				return mOutput;
			}
			else{
				mOutput[1]=mResponse.get_body_dataMap_uploadFlowNo();
				return mOutput;
			}
		}catch(Exception e)
		{
			mLog.error("Http Request Failed :",e);
			throw new Exception("25115-Client call failed");
		}
		//return mOutput;

	}

	public List<String> getEncryptedString(String jsonData) throws Exception 
	{
		String[] url=  mData.get("iPay_Exchange_Url").toString().split(":");
		ArrayList<String> output=null;
		try
		{

			//
			InetAddress ip = InetAddress.getByName(url[0]);

			// establish the connection with server port 5056
			Socket s = new Socket(ip, Integer.parseInt(url[1]));

			// obtaining input and out streams
			DataInputStream dis = new DataInputStream(s.getInputStream());
			DataOutputStream dos = new DataOutputStream(s.getOutputStream());

			// the following loop performs the exchange of
			// information between client and client handler

			output= new ArrayList<String>();

			//Get Random Key
			String check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("RandomKey");
				output.add(dis.readUTF());

			}

			//AES Encryption
			check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("AESEncryption\\n"+output.get(0)+"\\n"+jsonData);
				output.add(dis.readUTF());

			}

			//RSA Encryption
			check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("RSAEncryption\\n"+output.get(0));
				output.add(dis.readUTF());

			}

			dos.writeUTF("Exit");


			s.close();


			// closing resources
			dis.close();
			dos.close();
			return output;
		}catch(Exception e){
			mLog.error("Error in making Communication to iPay Exchange",e);
			throw new Exception("25115-AES/RSA Encryption issue");
		}
	}

	public void setproperties()
	{
		mData= new HashMap<String,String>();
		mData.put("uniqueNo", ebcProperties.getString("uniqueNo", ""));
		mData.put("url", ebcProperties.getString("url", ""));
		mData.put("ak", ebcProperties.getString("ak", ""));
		mData.put("sk", ebcProperties.getString("sk", ""));
		mData.put("iPay_Exchange_Url", ebcProperties.getString("iPay_Exchange_Url", ""));
		retry=ebcProperties.getInt("retryCount",0);
		retryInterval=ebcProperties.getLong("retryInterval",0);


	}


	public BefCnCardBatchJob getBefCnCardBatchJob() {
		return befCnCardBatchJob;
	}

	public void setBefCnCardBatchJob(BefCnCardBatchJob befCnCardBatchJob) {
		this.befCnCardBatchJob = befCnCardBatchJob;
	}



	public String getCnCardBatchJobIds() {
		return cnCardBatchJobIds;
	}



	public void setCnCardBatchJobIds(String cnCardBatchJobIds) {
		this.cnCardBatchJobIds = cnCardBatchJobIds;
	}




}

