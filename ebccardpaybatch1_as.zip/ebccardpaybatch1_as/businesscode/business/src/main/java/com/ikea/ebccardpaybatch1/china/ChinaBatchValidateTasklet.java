package com.ikea.ebccardpaybatch1.china;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.csb.sdk.HttpCaller;
import com.alibaba.csb.sdk.HttpParameters;
import com.ikea.ebccardpay1.cardpayment.be.CnCard;
import com.ikea.ebccardpay1.cardpayment.be.CnCardBatchJob;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCardBatchJob;
import com.ikea.ebccardpaybatch1.utils.Response;
import com.ikea.ebcframework.services.EbcProperties;

public class ChinaBatchValidateTasklet implements Tasklet{
	private static final Logger mLog = LoggerFactory
			.getLogger(ChinaBatchValidateTasklet.class);

	private String flowNumber;

	private BefCnCardBatchJob befCnCardBatchJob;

	private BefCnCard befCnCard;

	@Autowired
	EbcProperties ebcProperties;

	private HashMap<String,String> mData=null;

	private int retry=0;

	private long retryInterval=0L;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		mLog.info("Executing China Batch Validate Tasklet");

		setproperties();

		Exception final_Exception=null;
		
		if(flowNumber==null)
		{
			try{
			flowNumber=chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().getString("flowNumber");
			}
			catch(Exception e)
			{
				flowNumber=null;
			}
			
		}

		if(flowNumber!=null)
		{
			Thread.sleep(retryInterval);
			
			for(int i=1;i<=retry;i++)
			{
				if(i!=1)
					mLog.warn("Attempting Batch Validate: "+i+" time");
				
				mLog.info("Calling validate Function for flowNumber :"+flowNumber);
				String[] mOutput=new String[2];
				String sendCardsJsonData = "{\"dataMap\":{\"uploadFlowNo\":\"" + flowNumber+"\"}}";
				List<CnCardBatchJob> pCnCardBatchJobList=null;
				try{
					pCnCardBatchJobList=befCnCardBatchJob.findByFlowNumber(flowNumber);
					if(pCnCardBatchJobList !=null)
					{

						if(pCnCardBatchJobList.size()>0)
						{
							List<String> mEncryptedString=getEncryptedString(sendCardsJsonData);



							String jsonDataEncrypt = mEncryptedString.get(1);
							String subPasswordEncrpt = mEncryptedString.get(2);
							HttpParameters.Builder builder = new HttpParameters.Builder();
							String result = "";
							builder.api("recordFileUploadService").version("1.0.0").requestURL(mData.get("url").toString()).method("POST").accessKey(mData.get("ak").toString()).secretKey(mData.get("sk").toString())
							.putParamsMap("dataMap", "{\"dataMap\":{\"uniqueNo\":\"" + mData.get("uniqueNo").toString() + "\",\"symmetricKeyEncrpt\":\""
									+ subPasswordEncrpt + "\",\"jsonDataEncrypt\":\"" + jsonDataEncrypt + "\"}}");
							result = HttpCaller.invoke(builder.build());
							result = HttpCaller.changeCharset(result);

							mOutput[0]=result;

							mLog.debug(result);
							Response mResponse = new Response(result);
							if(mResponse.get_body_dataMap_errorCode()!=null && !(mResponse.get_body_dataMap_errorCode().equalsIgnoreCase("0"))) 
							{
								mOutput[1]="FAILED";
								throw new Exception(mOutput[0]);
							}
							else{

								if(mResponse.get_body_dataMap_fileStatus().equalsIgnoreCase("3"))
									//if(mOutput[1].equalsIgnoreCase("3"))
								{
									//mOutput[1]="SUCCESS";
									for(CnCardBatchJob mCnCardBatchJob:pCnCardBatchJobList)
									{
										befCnCard.registerTheCards(mCnCardBatchJob.getCnBatchJobId());
										mCnCardBatchJob.setFileStatus(mResponse.get_body_dataMap_fileStatus());
										StringBuffer job_id=new StringBuffer(mCnCardBatchJob.getJobExecutionIds());
										job_id.append(","+chunkContext.getStepContext().getStepExecution().getJobExecutionId());						
										mCnCardBatchJob.setJobExecutionIds(job_id.toString());
										mCnCardBatchJob.setErrorMessage(null);
										mCnCardBatchJob.setStatus("SUCCESS");
										befCnCardBatchJob.update(mCnCardBatchJob);

									}
									return RepeatStatus.FINISHED;
								}
								else{

									mOutput[1]="FAILED";
									throw new Exception(mOutput[0]);
								}	
							}
						}
					}
					else{
						CustomException.setException("25116-No Pending Files found to Validate.");
						chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
						return RepeatStatus.FINISHED;
					}
				}
				catch(Exception e)
				{
					mLog.error("Batch validation Failed Due to: ",e);

					if(pCnCardBatchJobList !=null)
					{
						if(pCnCardBatchJobList.size()>0 )
						{
							for(CnCardBatchJob mCnCardBatchJob:pCnCardBatchJobList)
							{
								CnCardBatchJob pCnCardBatchJob=mCnCardBatchJob;
								pCnCardBatchJob.setStatus("FAILED");
								StringBuffer job_id=new StringBuffer(mCnCardBatchJob.getJobExecutionIds());
								job_id.append(","+chunkContext.getStepContext().getStepExecution().getJobExecutionId());						
								mCnCardBatchJob.setJobExecutionIds(job_id.toString());
								pCnCardBatchJob.setErrorMessage(e.getLocalizedMessage());
								befCnCardBatchJob.update(pCnCardBatchJob);
							}
						}
					}

					Thread.sleep(retryInterval); // 5 Minutes
					mLog.warn("Attempting Batch Transfer: "+(i+1)+" time");
					final_Exception=e;
				}
			}

			if(!final_Exception.getLocalizedMessage().equals("25116-No Pending Files found to Validate."))
			{
				mLog.warn("Blob Validation failed");
				CustomException.setException(final_Exception.getLocalizedMessage());
				chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("batchjobError", "1");
				return RepeatStatus.FINISHED;
			}
			return RepeatStatus.FINISHED;
		}
		else{
			return RepeatStatus.FINISHED;
		}
	}


	public List<String> getEncryptedString(String jsonData) throws Exception 
	{
		String[] url=  mData.get("iPay_Exchange_Url").toString().split(":");
		ArrayList<String> output=null;
		try
		{

			//
			InetAddress ip = InetAddress.getByName(url[0]);

			// establish the connection with server port 5056
			Socket s = new Socket(ip, Integer.parseInt(url[1]));

			// obtaining input and out streams
			DataInputStream dis = new DataInputStream(s.getInputStream());
			DataOutputStream dos = new DataOutputStream(s.getOutputStream());

			// the following loop performs the exchange of
			// information between client and client handler

			output= new ArrayList<String>();

			//Get Random Key
			String check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("RandomKey");
				output.add(dis.readUTF());

			}

			//AES Encryption
			check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("AESEncryption\\n"+output.get(0)+"\\n"+jsonData);
				output.add(dis.readUTF());

			}

			//RSA Encryption
			check_connection=dis.readUTF();
			if(check_connection.length()>1)
			{
				dos.writeUTF("RSAEncryption\\n"+output.get(0));
				output.add(dis.readUTF());

			}

			dos.writeUTF("Exit");


			s.close();


			// closing resources
			dis.close();
			dos.close();
			return output;
		}catch(Exception e){
			mLog.error("Error in making Communication to iPay Exchange",e);
			throw new Exception("25115-AES/RSA Encryption issue");
		}
	}

	public void validateChinaBatchJob()
	{

	}

	public void setproperties()
	{
		mData= new HashMap<String,String>();
		mData.put("uniqueNo", ebcProperties.getString("uniqueNo", ""));
		mData.put("url", ebcProperties.getString("url", ""));
		mData.put("ak", ebcProperties.getString("ak", ""));
		mData.put("sk", ebcProperties.getString("sk", ""));
		mData.put("iPay_Exchange_Url", ebcProperties.getString("iPay_Exchange_Url", ""));
		retry=ebcProperties.getInt("retryCount",0);
		retryInterval=ebcProperties.getLong("retryInterval",0);


	}




	public String getFlowNumber() {
		return flowNumber;
	}


	public void setFlowNumber(String flowNumber) {
		this.flowNumber = flowNumber;
	}

	public BefCnCardBatchJob getBefCnCardBatchJob() {
		return befCnCardBatchJob;
	}


	public void setBefCnCardBatchJob(BefCnCardBatchJob befCnCardBatchJob) {
		this.befCnCardBatchJob = befCnCardBatchJob;
	}

	public BefCnCard getBefCnCard() {
		return befCnCard;
	}


	public void setBefCnCard(BefCnCard befCnCard) {
		this.befCnCard = befCnCard;
	}






}


