package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.bec.BecKPI;
import com.ikea.ebccardpay1.cardpayment.bef.BefConstants;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.cardpayment.vo.VoBusinessUnit;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;
import com.ikea.ebcframework.exception.IkeaException;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 *
 */
@Component
public class CalculateKpiJobCreator extends AbstractJobCreator{

	@Autowired
	private BefConstants mBefConstants;

	@Autowired
	private Units mUnits;
	
	@Autowired
	private BecKPI mBecKPI;
	
	@Autowired
	private BefFactory mBefFactory;

	private final static Logger kpiJobCreatorLogger = LoggerFactory.getLogger(CalculateKpiJobCreator.class);
	
	public void createNewJobs() {
		for (String vKpiType : mBefConstants.getKpiTypesToCalculate()) {
			createNewJobsForKpiType(vKpiType, false);
		}
	}
	
	public void createNewJobs(String pKpiType, boolean pOnlyYesterday) throws IkeaException {
		List<String> vKpiTypes = mBefConstants.getKpiTypeConstants();
		if (!vKpiTypes.contains(pKpiType)) {
			throw new IkeaException("Invalid kpi type: " + pKpiType);
		}
		
		createNewJobsForKpiType(pKpiType, pOnlyYesterday);
	}
	
	private void createNewJobsForKpiType(String pKpiType, boolean pOnlyYesterday) {
		/**
		 * Modified by Manu Varghese. 
		 * Added Exception so that the batch processing will continue even if one store encounters some issues. 
		 *  
		 * */
		int numberOfStoreHadErrors =0;
		//Exception exceptionProcessingStores = null;
		
		for (VoBusinessUnit vVoBusinessUnit : mUnits.allStores()) {
			
			kpiJobCreatorLogger.debug(
					"Next KPI type , butype  beginning : pKpiType : "
						+ pKpiType+" buType "+vVoBusinessUnit.getBuType()+" ,buCode : "+vVoBusinessUnit
						.getBuCode());
			try{
					// Find intervals to calculate KPI's for
					List<String> vKPIIntervals = mBecKPI.findUncalculatedKPIDates(
							pKpiType, vVoBusinessUnit.getBuType(), vVoBusinessUnit
									.getBuCode(), mBefFactory.getBefIpayBusinessUnits());
					
					if (pOnlyYesterday) {
						// Only calculate last day, i.e. get last entry from list vKPIIntervals
						if (vKPIIntervals != null && vKPIIntervals.size() > 0)
							createNewJob(pKpiType, vVoBusinessUnit.getBuCode(),
									vVoBusinessUnit.getBuType(), vKPIIntervals.get(vKPIIntervals.size()-1));
					} else {
						for (String vKpiInterval : vKPIIntervals) {
							createNewJob(pKpiType, vVoBusinessUnit.getBuCode(),
									vVoBusinessUnit.getBuType(), vKpiInterval);
						}
					}
			}catch(Exception e ){
				numberOfStoreHadErrors++;
				//exceptionProcessingStores=e;
				kpiJobCreatorLogger.debug(
						"Error  processing  KPI type , butype  beginning : pKpiType : "
							+ pKpiType+" buType "+vVoBusinessUnit.getBuType()+" ,buCode : "+vVoBusinessUnit
							.getBuCode()+" ,numberOfStoreHadErrors : "+numberOfStoreHadErrors);
				e.printStackTrace();
			}
		}
		
		/*if (numberOfStoreHadErrors>0){
			throw new IkeaException(" Error processing stores. No of Stores reported Error : " + numberOfStoreHadErrors+" Last Exception reported : "+exceptionProcessingStores.toString());
		}*/
	}
	
	private void createNewJob(String pKpiType, String pBuCode, String pBuType, String pKpiInterval) {
		List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

		VoJobParam vKpiTypeParam = new VoJobParam();
		vKpiTypeParam.setName(BatchJobArguments.KPI_TYPE);
		vKpiTypeParam.setValue(pKpiType);
		vVoJobParamList.add(vKpiTypeParam);

		VoJobParam vBuCodeParam = new VoJobParam();
		vBuCodeParam.setName(BatchJobArguments.KPI_BU_CODE);
		vBuCodeParam.setValue(pBuCode);
		vVoJobParamList.add(vBuCodeParam);

		VoJobParam vBuTypeParam = new VoJobParam();
		vBuTypeParam.setName(BatchJobArguments.KPI_BU_TYPE);
		vBuTypeParam.setValue(pBuType);
		vVoJobParamList.add(vBuTypeParam);

		VoJobParam vKpiIntervalParam = new VoJobParam();
		vKpiIntervalParam.setName(BatchJobArguments.KPI_INTERVAL);
		vKpiIntervalParam.setValue(pKpiInterval);
		vVoJobParamList.add(vKpiIntervalParam);

		sendAsyncJobExecutionRequest(BatchJobType.calculateKpiJob,	vVoJobParamList);
	}
}
