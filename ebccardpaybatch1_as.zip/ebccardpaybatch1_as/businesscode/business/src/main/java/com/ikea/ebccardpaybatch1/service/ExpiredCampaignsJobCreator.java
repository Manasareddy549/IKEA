package com.ikea.ebccardpaybatch1.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.bec.BecCampaign;
import com.ikea.ebccardpay1.cardpayment.bec.BecSarecReport;
import com.ikea.ebccardpay1.cardpayment.bef.BefFactory;
import com.ikea.ebccardpay1.cardpayment.utils.Units;
import com.ikea.ebccardpay1.client.vo.VoBusinessUnit;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author moans1
 * 
 */
@Component
public class ExpiredCampaignsJobCreator extends AbstractJobCreator {

	@Autowired
	private Units mUnits;

	@Autowired
	private BecCampaign mBecCampaign;


	private final static Logger expiredCamapignsJob = LoggerFactory
			.getLogger(ExpiredCampaignsJobCreator.class);

	public void createNewJobs() {

		createNewJobs(false);

	}

	public void createNewJobs(boolean pOnlyYesterday) {
		int errorsOccured = 0;
		expiredCamapignsJob
		.debug("ExpiredCampaignsJobCreator impl class running ");
		try {
			String pattern = "yyyy-MM-dd";
			SimpleDateFormat dateFormater = new SimpleDateFormat(pattern);  
				expiredCamapignsJob
				.debug("ExpiredCampaignsJobCreator impl class running for yesterday date ");

				createNewJob(dateFormater.format(new DateTime().minusDays(1).toDate())
						,dateFormater.format(new DateTime().toDate()));

		} catch (Exception e) {
			errorsOccured++;
			// exceptionProcessingStores=e;
			expiredCamapignsJob
			.debug("Error  processing  expiredcampaignjob "
					+ errorsOccured);
			e.printStackTrace();
		}
	}


	private void createNewJob(String pFromDate, String pToDate) {
		List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

		VoJobParam vCampaignFromDateParam = new VoJobParam();
		vCampaignFromDateParam.setName(BatchJobArguments.EXPIRED_CAMPAIGN_FROM_DATE);
		vCampaignFromDateParam.setValue(pFromDate);
		vVoJobParamList.add(vCampaignFromDateParam);

		VoJobParam vCampaignupToDateParam = new VoJobParam();
		vCampaignupToDateParam.setName(BatchJobArguments.EXPIRED_CAMPAIGN_TO_DATE);
		vCampaignupToDateParam.setValue(pToDate);
		vVoJobParamList.add(vCampaignupToDateParam);

		sendAsyncJobExecutionRequest(BatchJobType.expiredCampaignsJob,
				vVoJobParamList);
	}

}
