package com.ikea.ebccardpaybatch1.cbd;

import java.util.ArrayList;
import java.util.Set;

import com.ikea.ebccardpay1.cardpayment.utils.Unit;
import com.ikea.ebcframework.exception.IkeaException;


public interface CbdService {

	public CbdExchangeRatesForCurrencies getExchangeRatesForCurrencies(Set<String> pCurrencyCodes) throws IkeaException;

	public ArrayList<Unit> iPaySitesfromCBD() throws IkeaException;

}