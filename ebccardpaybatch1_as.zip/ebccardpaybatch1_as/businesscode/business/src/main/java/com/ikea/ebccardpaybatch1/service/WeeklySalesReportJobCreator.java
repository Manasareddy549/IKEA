package com.ikea.ebccardpaybatch1.service;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Period;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 * 
 */
@Component
public class WeeklySalesReportJobCreator extends AbstractJobCreator {

	public void createNewJobs() {
       	DateTime vNow = new DateTime();
       	DateTime vLastWeek = vNow.minus(Period.weeks(1));
       	
		List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

		VoJobParam vYearParam = new VoJobParam();
		vYearParam.setName(BatchJobArguments.WEEKLY_SALES_YEAR);
		vYearParam.setValue(Integer.toString(vLastWeek.getYear()));
		vVoJobParamList.add(vYearParam);

		VoJobParam vWeekParam = new VoJobParam();
		vWeekParam.setName(BatchJobArguments.WEEKLY_SALES_WEEK);
		NumberFormat paddingFormat = new DecimalFormat("00");
		vWeekParam.setValue(paddingFormat.format(vLastWeek.getWeekOfWeekyear()));
		vVoJobParamList.add(vWeekParam);
		
		sendAsyncJobExecutionRequest(BatchJobType.weeklySalesReportJob, vVoJobParamList);
	}

}
