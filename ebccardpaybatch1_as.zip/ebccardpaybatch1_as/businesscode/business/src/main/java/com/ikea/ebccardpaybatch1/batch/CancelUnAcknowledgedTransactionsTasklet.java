package com.ikea.ebccardpaybatch1.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.be.ReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.bec.BecReferenceCheck;
import com.ikea.ebccardpay1.cardpayment.bef.BefReferenceCheck;

public class CancelUnAcknowledgedTransactionsTasklet implements Tasklet {

	private static final int MINUTES = 60;

	private static final Logger mLog = LoggerFactory
			.getLogger(CancelUnAcknowledgedTransactionsTasklet.class);

	private BefReferenceCheck mBefReferenceCheck;

	private BecReferenceCheck mBecReferenceCheck;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {

		mLog.info("Cancelling unacknowledged transactions older than "
				+ MINUTES + " minutes.");

		List<ReferenceCheck> vList = mBefReferenceCheck.findByWaitingAckOlderThan(MINUTES);

		if (vList == null || vList.size() == 0) {
			mLog.info("No old transactions waiting for acknowledgement found.");
			return RepeatStatus.FINISHED;
		}

		mLog.info("Found " + vList.size()
				+ " unacknowledged transactions older than " + MINUTES
				+ " minutes.");

		for (ReferenceCheck vReferenceCheck : vList) {
			mBecReferenceCheck.cancelTransaction(vReferenceCheck);
		}

		return RepeatStatus.FINISHED;
	}

	public void setBefReferenceCheck(BefReferenceCheck pBefReferenceCheck) {
		mBefReferenceCheck = pBefReferenceCheck;
	}

	public void setBecReferenceCheck(BecReferenceCheck pBecReferenceCheck) {
		mBecReferenceCheck = pBecReferenceCheck;
	}

}
