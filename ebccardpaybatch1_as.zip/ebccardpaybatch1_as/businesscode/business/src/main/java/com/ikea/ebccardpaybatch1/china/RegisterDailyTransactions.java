package com.ikea.ebccardpaybatch1.china;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpay1.cardpayment.be.CnCard;
import com.ikea.ebccardpay1.cardpayment.bef.BefCnCardBatchJob;
import com.ikea.ebccardpaybatch1.utils.Request;

public class RegisterDailyTransactions {
	private static final Logger mLog = LoggerFactory
			.getLogger(RegisterDailyTransactions.class);

	private BefCnCardBatchJob befCnCardBatchJob;

	private String serialNo;
	private String financialType;
	private String registered;
	private String transactionType;
	private String cardID;
	private String cardNo;
	Set<String> mCardIdToRegister;
	private Timestamp mexpiryDateTimeStamp;
	private Timestamp mTransmissionDateTimeStamp;
	private String salesDay;
	private String cardBalanceChange;
	private String effectivebalance;
	private Timestamp mCreateDateTimeStamp;
	private Request mRequestObject;

	private StringBuffer jSonList= null;

	private ArrayList<CnCard> cnCardList = null;

	private int transactionCount=0;

	private  DateFormat sDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
	private  DateFormat sDateFormat2 = new SimpleDateFormat("yyyyMMddHHmmss");
	private  DateFormat sDateFormat3 = new SimpleDateFormat("yyyy-MM-dd");
	private  DateFormat sDateFormat4 = new SimpleDateFormat("yyyyMMdd");

	public void registerFunctionality(List<Object[]> pTransactions){
		cnCardList = new ArrayList<CnCard>();
		mRequestObject= new Request();
		jSonList= new StringBuffer();
		transactionCount=0;
		mCardIdToRegister=new HashSet<String>();
		cards(pTransactions);

	}

	private void cards(List<Object[]> pTransactions)
	{


		for(int i=0;i<pTransactions.size();i++)
		{
			Object[] pRow=pTransactions.get(i);
			try{			
				serialNo=pRow[0].toString();
				transactionType=pRow[1].toString();
				financialType=pRow[2].toString();
				cardID=pRow[3].toString();
				cardNo=pRow[4].toString();

				mexpiryDateTimeStamp=(Timestamp)pRow[5];
				String expiryDate=sDateFormat4.format(new Date(mexpiryDateTimeStamp.getTime()));

				mTransmissionDateTimeStamp=(Timestamp)pRow[6];
				String mTransmissionDateTime=sDateFormat2.format(new Date(mTransmissionDateTimeStamp.getTime()));

				salesDay=sDateFormat4.format(sDateFormat3.parse(pRow[7].toString()));
				cardBalanceChange=pRow[8].toString();
				registered=pRow[9].toString();

				mCreateDateTimeStamp=(Timestamp)pRow[10];
				Date createDate=new Date(mCreateDateTimeStamp.getTime());

				effectivebalance=pRow[11].toString();

				if(financialType.equalsIgnoreCase("CREDIT"))
				{
					if(registered.equalsIgnoreCase("N") && mCardIdToRegister.add(cardID) )
					{
						jSonList.append(mRequestObject.registerCard(serialNo, cardID, cardNo, effectivebalance, effectivebalance, mTransmissionDateTime, salesDay, expiryDate));
						CnCard mCnCard= new CnCard();
						mCnCard.setCardId(Long.parseLong(cardID));
						mCnCard.setCardNumber(cardNo);
						cnCardList.add(mCnCard);
						transactionCount++;
					}
					else{
						if(transactionType.equalsIgnoreCase("VOID_REDEEM"))
						{
							jSonList.append(mRequestObject.createReLoadTransaction(serialNo, cardID, cardNo, effectivebalance, effectivebalance,
									mTransmissionDateTime, cardBalanceChange, cardBalanceChange, transactionType, "TRANSACTION CANCELLATION"));
							transactionCount++;
						}
						else{
							jSonList.append(mRequestObject.createReLoadTransaction(serialNo, cardID, cardNo, effectivebalance, effectivebalance,
									mTransmissionDateTime, cardBalanceChange, cardBalanceChange,"", ""));
							transactionCount++;

						}
					}
				}
				else if(financialType.equalsIgnoreCase("DEBIT"))
				{
					if(registered.equalsIgnoreCase("N") && mCardIdToRegister.add(cardID) )
					{
						List<Object[]> mCardList=befCnCardBatchJob.getCreditTransaction(Long.parseLong(cardID),mCreateDateTimeStamp);
						creditTransaction(mCardList);
						jSonList.append(mRequestObject.createRedeemTransaction(serialNo, cardID, 
								cardNo, effectivebalance, effectivebalance, mTransmissionDateTime, cardBalanceChange, cardBalanceChange,""));
						transactionCount++;
					}
					else{
						if(transactionType.equalsIgnoreCase("VOID_LOAD"))
						{
							// create redeem transaction with cancellation 
							jSonList.append(mRequestObject.createRedeemTransaction(serialNo, cardID, 
									cardNo, effectivebalance, effectivebalance, mTransmissionDateTime, cardBalanceChange, cardBalanceChange, transactionType));
							transactionCount++;
						}
						else{
							jSonList.append(mRequestObject.createRedeemTransaction(serialNo, cardID, 
									cardNo, effectivebalance, effectivebalance, mTransmissionDateTime, cardBalanceChange, cardBalanceChange,""));
							transactionCount++;
						}
					}
				}
			}
			catch(Exception e)
			{
				mLog.warn("Exception while adding Data[ "+pRow[0].toString()+","+pRow[1].toString()+","+pRow[2].toString()+","+pRow[3].toString()+","+pRow[3].toString()+"," +pRow[4].toString()+","
						+pRow[5].toString()+","+pRow[6].toString()+","+pRow[7].toString()+","+pRow[8].toString()+","+pRow[9].toString()+
						","+pRow[10].toString()+","+pRow[11].toString()+" ] to the list. Exception Details: "+ e.getMessage());

			}
			
			if(i<(pTransactions.size()-1))
			{
				jSonList.append("\r\n");
			}

		}
	}

	private void creditTransaction(List<Object[]> pcardsList) throws Exception
	{
		if(pcardsList!=null)
		{
			for(int i=0;i<pcardsList.size();i++)
			{
				Object[] pRow=pcardsList.get(i);
				String serialNo_1=pRow[0].toString();
				String cardID_1=pRow[5].toString();
				String cardNo_1=pRow[4].toString();

				BigDecimal amount= new BigDecimal(pRow[3].toString());

				String cardMon_1=amount.toString();
				String cardBalance_1=cardMon_1;


				Timestamp mapplyTimeStamp=(Timestamp)pRow[1];
				String applyTime_1=sDateFormat2.format(new Date(mapplyTimeStamp.getTime()));

				String beginDate_1=sDateFormat4.format(sDateFormat3.parse(pRow[2].toString()));
				if(beginDate_1.startsWith("1900")) throw  new Exception("Wrong Sales Day");

				Timestamp mexpiryDateTimeStamp=(Timestamp)pRow[6];
				String expiryDate_1=sDateFormat4.format(new Date(mexpiryDateTimeStamp.getTime()));

				jSonList.append(mRequestObject.registerCard(serialNo_1, cardID_1, cardNo_1, cardMon_1, cardBalance_1, applyTime_1, beginDate_1, expiryDate_1));
				jSonList.append("\r\n");
				CnCard mCnCard= new CnCard();
				mCnCard.setCardId(Long.parseLong(cardID));
				mCnCard.setCardNumber(cardNo);
				cnCardList.add(mCnCard);
				transactionCount++;
				return;
			}
			throw  new Exception("No Cards Found");

		}
		else
		{
			throw  new Exception("No Cards Found");
		}

	}

	public BefCnCardBatchJob getBefCnCardBatchJob() {
		return befCnCardBatchJob;
	}

	public void setBefCnCardBatchJob(BefCnCardBatchJob befCnCardBatchJob) {
		this.befCnCardBatchJob = befCnCardBatchJob;
	}

	public StringBuffer getjSonList() {
		return jSonList;
	}


	public ArrayList<CnCard> getCnCardList() {
		return cnCardList;
	}
	
	public int getTransactionCount() {
		return transactionCount;
	}

}
