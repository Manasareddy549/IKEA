package com.ikea.ebccardpaybatch1.cds;


import java.util.Map;

import com.ikea.ebccardpay1.cardpayment.utils.Unit;

public interface CdsService {

	public  Map<String, Unit> GetAllBusinessUnitsForIpay() throws Exception;

}