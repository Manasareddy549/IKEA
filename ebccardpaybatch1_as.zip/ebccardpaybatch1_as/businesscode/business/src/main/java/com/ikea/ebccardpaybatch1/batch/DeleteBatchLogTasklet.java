package com.ikea.ebccardpaybatch1.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

public class DeleteBatchLogTasklet implements Tasklet {
	
	private static final Logger mLog = LoggerFactory
	.getLogger(DeleteBatchLogTasklet.class);

	private int numberOfDaysToKeep; 
	
	private JdbcTemplate simpleJdbcTemplate;

	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {

		mLog.info("Delete all info about executed batch-jobs that are "
				+ "older than " + getNumberOfDaysToKeep() + " days");

		// Delete items from batch_instance (with delete cascade)
		simpleJdbcTemplate
				.update("delete from batch_job_instance where job_instance_id in " +
						"	(select job_instance_id from batch_job_execution " +
						"		where status = 'COMPLETED' " +
						"			and to_char(create_time,'YYYY-MM-DD') < to_char((sysdate - ?),'YYYY-MM-DD'))",
						getNumberOfDaysToKeep());

		// Delete 'updateExchangeRateFromCbdJob' that are at least 5 days old.
		simpleJdbcTemplate
				.update(
						"delete from batch_job_instance where job_name='updateExchangeRateFromCbdJob' and job_instance_id in "
								+ "	(select job_instance_id from batch_job_execution "
								+ "		where status = 'COMPLETED' "
								+ "			and to_char(create_time,'YYYY-MM-DD') < to_char((sysdate - 5),'YYYY-MM-DD'))");
		
		mLog.info("Done deleting batch-info");

		return RepeatStatus.FINISHED;
	}

	private int getNumberOfDaysToKeep() {
		return numberOfDaysToKeep;
	}

	public void setSimpleJdbcTemplate(JdbcTemplate pSimpleJdbcTemplate) {
		simpleJdbcTemplate = pSimpleJdbcTemplate;
	}

	public void setNumberOfDaysToKeep(int pNumberOfDaysToKeep) {
		numberOfDaysToKeep = pNumberOfDaysToKeep;
	}

}
