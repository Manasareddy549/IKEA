package com.ikea.ebccardpaybatch1.utils;

public class Request {

	public String registerCard(
			String serialNo,
			String cardID,
			String cardNo,
			String cardMon,
			String cardBalance,
			String applyTime,
			String beginDate,
			String expiryDate)
	{
		String loadType="0";
		String isRegister="0";
		String isEntity="";
		String foregift="";
		String cardType="";
		String cardName="";
		String name="";
		String phone="";
		String certType="";
		String certNo="";
		String issueStore="";



		String cardRegisterString= new String(loadType+"||"+serialNo+"||"+cardID+"||"+cardNo+"||"+cardMon+"||"
				+cardBalance+"||"+applyTime+"||"+beginDate+"||"+expiryDate+"||"+isRegister+"||"+isEntity+"||"+foregift+"||"
				+cardType+"||"+cardName+"||"+name+"||"+phone+"||"+certType+"||"+certNo+"||"+issueStore);

		return cardRegisterString;
	}

	public String createReLoadTransaction(
			String serialNo,
			String cardID,
			String cardNo,
			String cardMon,
			String cardBalance,
			String chargeTime,
			String chargeMon,
			String chargeBalance,
			String chargeWay,
			String chargeWayDes)
	{

		String loadType="1";
		String isOpenAcc="0";
		String isRegister="";
		String beginDate="";
		String expiryDate="";
		String isEntity="";

		String cardReloadString= new String(loadType+"||"+serialNo+"||"+cardID+"||"+cardNo+"||"+cardMon+"||"
				+cardBalance+"||"+chargeTime+"||"+chargeMon+"||"+chargeBalance+"||"+isOpenAcc+"||"+chargeWay+"||"+chargeWayDes+"||"+isRegister+"||"
				+beginDate+"||"+expiryDate+"||"+isEntity);

		return cardReloadString;
	}

	public String createRedeemTransaction(
			String serialNo,
			String cardID,
			String cardNo,
			String cardMon,
			String cardBalance,
			String tranTime,
			String tranMon,
			String tranBalance,
			String tranTypeDes
			)
	{
		String loadType="2";
		String tranType="0";
		String tranPlace="";
		String isBack="";
		String backReason="";

		String cardRedeemString= new String(loadType+"||"+serialNo+"||"+cardID+"||"+cardNo+"||"+cardMon+"||"
				+cardBalance+"||"+tranTime+"||"+tranMon+"||"+tranBalance+"||"+tranType+"||"+tranTypeDes+"||"+tranPlace+"||"+isBack+"||"
				+backReason);

		return cardRedeemString;
	}

}
