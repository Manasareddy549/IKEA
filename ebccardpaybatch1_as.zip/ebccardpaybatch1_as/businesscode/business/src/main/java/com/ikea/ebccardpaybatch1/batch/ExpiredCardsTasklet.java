package com.ikea.ebccardpaybatch1.batch;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bec.BecCard;
import com.ikea.ebccardpay1.cardpayment.bec.BecProcessExpiredCrads;


public class ExpiredCardsTasklet implements Tasklet {
	
	private static final Logger mLog = LoggerFactory.getLogger(ExpiredCardsTasklet.class);
	private String triggerTimestamp;
	private BecCard mBecCard;


	
	
	
	
    public BecCard getBecCard() {
		return mBecCard;
	}


	public void setBecCard(BecCard becCard) {
		mBecCard = becCard;
	}



public String getTriggerTimestamp() {
	return triggerTimestamp;
}


public void setTriggerTimestamp(String triggerTimestamp) {
	this.triggerTimestamp = triggerTimestamp;
}




@Override
public RepeatStatus execute(StepContribution contribution,
		ChunkContext chunkContext) throws Exception {
	
	mLog.info("Executing ExpiredCardsTasklet......");

	mLog.info("Process start Time" + System.currentTimeMillis());
	

	mBecCard.expiredCardProcessing();
	
	mLog.info("Process End Time" + System.currentTimeMillis());
	mLog.info("ExpiredCardsTasklet normal exit ......");
	
	return RepeatStatus.FINISHED;
}


}
