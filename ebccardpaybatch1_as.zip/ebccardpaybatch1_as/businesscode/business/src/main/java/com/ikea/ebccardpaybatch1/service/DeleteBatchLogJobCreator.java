package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 *
 */
@Component
public class DeleteBatchLogJobCreator extends AbstractJobCreator{

	public void createNewJobs() {
		List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

		VoJobParam vDaysToKeepParam = new VoJobParam();
		vDaysToKeepParam.setName(BatchJobArguments.BATCH_LOG_DAYS_TO_KEEP);
		vDaysToKeepParam.setValue(BatchJobArguments.BATCH_LOG_DAYS_TO_KEEP_DEFAULT_VALUE);
		vVoJobParamList.add(vDaysToKeepParam);
		VoJobParam vTriggerTimestampParam = new VoJobParam();
		vTriggerTimestampParam.setName(BatchJobArguments.BATCH_LOG_TRIGGER_TIMESTAMP);
		vTriggerTimestampParam.setValue((new DateTime()).toString());
		vVoJobParamList.add(vTriggerTimestampParam);
		sendAsyncJobExecutionRequest(BatchJobType.deleteBatchLogJob, vVoJobParamList);
	}

}
