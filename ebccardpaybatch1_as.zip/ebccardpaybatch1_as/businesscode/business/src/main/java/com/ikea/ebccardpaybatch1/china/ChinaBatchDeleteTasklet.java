package com.ikea.ebccardpaybatch1.china;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bef.BefCnCardBatchJob;

public class ChinaBatchDeleteTasklet implements Tasklet{
	private static final Logger mLog = LoggerFactory
			.getLogger(ChinaBatchJobEndTasklet.class);

	private BefCnCardBatchJob befCnCardBatchJob;

	private String cnJobId;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		mLog.info("Executing ChinaBatchDeleteTasklet");
		try{
			befCnCardBatchJob.deleteBatchJob(Long.parseLong(cnJobId));
		}
		catch(Exception e)
		{
			mLog.error("Batch job Deletion failed due to ",e);
		}
		chunkContext.getStepContext().
		getStepExecution().setExitStatus(ExitStatus.COMPLETED);
		return RepeatStatus.FINISHED;
	}

	public String getCnJobId() {
		return cnJobId;
	}

	public void setCnJobId(String cnJobId) {
		this.cnJobId = cnJobId;
	}

	public BefCnCardBatchJob getBefCnCardBatchJob() {
		return befCnCardBatchJob;
	}

	public void setBefCnCardBatchJob(BefCnCardBatchJob befCnCardBatchJob) {
		this.befCnCardBatchJob = befCnCardBatchJob;
	}
}