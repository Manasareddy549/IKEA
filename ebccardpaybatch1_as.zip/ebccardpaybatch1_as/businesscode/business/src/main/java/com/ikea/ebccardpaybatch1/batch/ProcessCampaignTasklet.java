package com.ikea.ebccardpaybatch1.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.ikea.ebccardpay1.cardpayment.bec.BecCampaign;


public class ProcessCampaignTasklet implements Tasklet {

	private static final Logger mLog = LoggerFactory
			.getLogger(ProcessCampaignTasklet.class);

	private Long campaingId;

	private BecCampaign mBecCampaign;
	
	public RepeatStatus execute(StepContribution pContribution,
			ChunkContext pChunkContext) throws Exception {
		
		int vProcessed = mBecCampaign.process(campaingId);

		if (vProcessed > 0) {
			mLog.info("More cards to process in the campaign, will return CONTINUABLE");
			return RepeatStatus.CONTINUABLE;
		}

		return RepeatStatus.FINISHED;
	}

	public void setCampaingId(Long pCampaingId) {
		campaingId = pCampaingId;
	}

	public void setBecCampaign(BecCampaign pBecCampaign) {
		mBecCampaign = pBecCampaign;
	}


}
