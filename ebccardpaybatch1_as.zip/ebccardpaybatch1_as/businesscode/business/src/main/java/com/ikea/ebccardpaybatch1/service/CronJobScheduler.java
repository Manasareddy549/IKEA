package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.cardpayment.be.JobCreatorSchedule;
import com.ikea.ebccardpay1.cardpayment.bef.BefJobCreatorSchedule;

import hudson.scheduler.CronTab;
import hudson.scheduler.CronTabList;

import static org.apache.commons.lang.Validate.notNull;
/**
 * The CronJobScheduler reads the cron jobs from the database. Each time the
 * findActveJobCreators is invoked the cron expressions are validated and the
 * JobCreators for each valid job is added to the resulting list. The
 * JobCreators are picked from the Spring ApplicationContext.
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 * 
 */
@Component
public class CronJobScheduler implements JobScheduler, ApplicationContextAware, InitializingBean {

	private static final Logger mLog = LoggerFactory.getLogger(CronJobScheduler.class);
	
	@Autowired
	private BefJobCreatorSchedule mBefJobCreatorSchedule;
	
	private ApplicationContext mApplicationContext;

	private Calendar mExactCalendar = null;

	
	@Override
	public void afterPropertiesSet() throws Exception {
		notNull(mBefJobCreatorSchedule);
		notNull(mApplicationContext);
		
	} 
	
	public List<JobCreator> findActiveJobCreators() throws Exception {
		List<JobCreator> jobCreators = new LinkedList<JobCreator>();
		List<JobCreatorSchedule> jobCreatorSchedules = mBefJobCreatorSchedule.findAll();
		
		for (JobCreatorSchedule vJobCreatorSchedule : jobCreatorSchedules) {
			mLog.debug("Scheduled job: " + vJobCreatorSchedule.getJobName() + ", '" + vJobCreatorSchedule.getCronTab() + "'");
			List<CronTab> cronTabs = new ArrayList<CronTab>();
			CronTab cronTab = new CronTab(vJobCreatorSchedule.getCronTab());
			cronTabs.add(cronTab);
			CronTabList cronTabList = new CronTabList(cronTabs);
			
			if (cronTabList.check(getCalendarToCheck())) {
				mLog.info("The " + vJobCreatorSchedule.getJobName() + " is scheduled to run now.");
				try {
					JobCreator vCreator = (JobCreator) mApplicationContext.getBean(vJobCreatorSchedule.getJobName() + "Creator", JobCreator.class);
					if (vCreator != null){
						jobCreators.add(vCreator);
						mLog.info("Found the creator for " + vJobCreatorSchedule.getJobName());
					}
				}catch (BeansException be) {
					mLog.warn("Could not find the job creator for " + vJobCreatorSchedule.getJobName());
				}
			} else {
				mLog.info("The " + vJobCreatorSchedule.getJobName() + " is not scheduled to run now.");
				
			}
		}
		return jobCreators;
	}

	private Calendar getCalendarToCheck() {
		if (mExactCalendar != null){
			return mExactCalendar;
		} else {
			return new GregorianCalendar();
		}
	}
	
	protected void setExactCalendar(Calendar pExactCalendar) {
		mExactCalendar = pExactCalendar;
	}
	
	public void setApplicationContext(ApplicationContext pApplicationContext)
			throws BeansException {
				mApplicationContext = pApplicationContext;
	}

	

}
