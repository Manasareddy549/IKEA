package com.ikea.ebccardpaybatch1.service;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ikea.ebccardpay1.common.*;
import com.ikea.ebccardpay1.cardpayment.be.Campaign;
import com.ikea.ebccardpay1.cardpayment.bec.BecCampaigns;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

/**
 * 
 * @author Henrik Reinhold, external.henrik.reinhold2@ikea.com
 * 
 */
@Component
public class ProcessCampaignJobCreator extends AbstractJobCreator {

	@Autowired
	private BecCampaigns mBecCampaigns;
	
	public void createNewJobs() {
		List<Campaign> vUnprocessedCampaigns = mBecCampaigns
				.findUnprocessedCampaigns();

		for (Campaign vCampaign : vUnprocessedCampaigns) {
			List<VoJobParam> vVoJobParamList = new ArrayList<VoJobParam>();

			VoJobParam vCampaignIdParam = new VoJobParam();
			vCampaignIdParam.setName(BatchJobArguments.CAMPAIGN_ID);
			vCampaignIdParam.setValue(Long.toString(vCampaign.getCampaignId()));
			vVoJobParamList.add(vCampaignIdParam);
			VoJobParam vTriggerParam = new VoJobParam();
			vTriggerParam.setName(BatchJobArguments.CAMPAIGN_TRIGGER);
			vTriggerParam.setValue("BATCH");
			vVoJobParamList.add(vTriggerParam);
			VoJobParam vTriggerTimestampParam = new VoJobParam();
			vTriggerTimestampParam
					.setName(BatchJobArguments.CAMPAIGN_TRIGGER_TIMESTAMP);
			vTriggerTimestampParam.setValue((new DateTime()).toString());
			vVoJobParamList.add(vTriggerTimestampParam);
			sendAsyncJobExecutionRequest(BatchJobType.processCampaignJob,
					vVoJobParamList);
		}
	}

}
