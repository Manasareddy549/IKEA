package com.ikea.ebccardpaybatch1.eicom;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReport;
import com.ikea.ebccardpay1.cardpayment.entity.WeeklySalesReportRow;


public class EicOmServiceBsImplTest {

	@Test
	public void whenCreateXmlMessageAssertExpectedContent() throws Exception {
		EicOmServiceBsImpl vEicOmServiceBsImpl = new EicOmServiceBsImpl();
		
		WeeklySalesReport vSalesReport = new WeeklySalesReport();
		vSalesReport.setYear("2009");
		vSalesReport.setWeek("40");
		
		WeeklySalesReportRow vRow1 = new WeeklySalesReportRow();
		vRow1.setAMOUNTINLOCALCURRENCY(BigDecimal.valueOf(141233.4));
		vRow1.setBUCODE("085");
		vRow1.setBUTYPE("STO");
		vRow1.setCOUNTRYCODE("AT");
		vRow1.setCURRENCYCODE("EUR");
		vRow1.setNUMBEROFLOADTRANSACTIONS(BigDecimal.valueOf(306));
		vSalesReport.addRow(vRow1);
		
		WeeklySalesReportRow vRow2 = new WeeklySalesReportRow();
		vRow2.setAMOUNTINLOCALCURRENCY(BigDecimal.valueOf(227035.21));
		vRow2.setBUCODE("090");
		vRow2.setBUTYPE("STO");
		vRow2.setCOUNTRYCODE("AT");
		vRow2.setCURRENCYCODE("EUR");
		vRow2.setNUMBEROFLOADTRANSACTIONS(BigDecimal.valueOf(276));
		vSalesReport.addRow(vRow2);
		
		String vActualXmlMessage = vEicOmServiceBsImpl.createXmlMessage(vSalesReport);
		
		String vExpectedXmlMessage = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
		"<salesreport year=\"2009\" week=\"40\">\n" +
			"<report-row country-code=\"AT\" bu-code=\"085\" bu-type=\"STO\" currency-code=\"EUR\" in-local-currency=\"141233.4\" no-load-transactions=\"306\"/>\n" + 
			"<report-row country-code=\"AT\" bu-code=\"090\" bu-type=\"STO\" currency-code=\"EUR\" in-local-currency=\"227035.21\" no-load-transactions=\"276\"/>\n" +
		"</salesreport>";

		assertEquals(vExpectedXmlMessage, vActualXmlMessage);
		
	}
}
