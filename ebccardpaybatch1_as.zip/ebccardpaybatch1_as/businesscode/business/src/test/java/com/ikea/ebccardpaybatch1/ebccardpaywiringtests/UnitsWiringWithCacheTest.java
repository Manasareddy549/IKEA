package com.ikea.ebccardpaybatch1.ebccardpaywiringtests;

import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import com.ikea.ebccardpay1.cardpayment.utils.Units;
/**
 * Tests wiring with the real ikeacache implementations. When the test was created it was run successfully in Eclipse and IntelliJ but in a Linux
 * terminal Maven failed to run it.  Because of this it was ignored but kept since it is valuable as a test.s
 * 
 * @author Niklas Uhrberg
 *
 */
@Ignore
@ContextConfiguration(locations={"wiringwithcachestest-context.xml", "/caches-context.xml"})
public class UnitsWiringWithCacheTest extends AbstractJUnit4SpringContextTests  {

	
	@Autowired
	Units setups;
	
	
	@Test
	public void testUnitsWired() {
		
		assertNotNull(setups);
	}
		
	
	
	
	
	
	
}
