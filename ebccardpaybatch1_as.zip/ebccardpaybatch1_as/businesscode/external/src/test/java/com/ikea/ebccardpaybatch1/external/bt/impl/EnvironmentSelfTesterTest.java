
package com.ikea.ebccardpaybatch1.external.bt.impl;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;

import com.ikea.ebccardpay1.test.utils.EbcCardPay1TestSetup;
import com.ikea.ebccardpaybatch1.external.selftester.EnvironmentSelfTester;
import com.ikea.ebcframework.services.EbcProperties;

import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.util.ReflectionTestUtils;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.verify;

/**
 * @author anagc
 */
@RunWith(EasyMockRunner.class)
public class EnvironmentSelfTesterTest extends EbcCardPay1TestSetup {

  // Mock EbcPropertiesFactory

  @Mock
  public EbcProperties mEbcPropertiesMock;

  @Test
  final public void testRunSelfTest() throws Exception {
    // --- Set up mock behaviour ---

   
    
    expect(mEbcPropertiesMock.propertyExists("uniqueNo")).andReturn(true);
    expect(mEbcPropertiesMock.getString("uniqueNo", "")).andReturn("");
	
    expect(mEbcPropertiesMock.propertyExists("url")).andReturn(true);
    expect(mEbcPropertiesMock.getString("url", "")).andReturn("");
	
    expect(mEbcPropertiesMock.propertyExists("ak")).andReturn(true);
    expect(mEbcPropertiesMock.getString("ak", "")).andReturn("");
	
    expect(mEbcPropertiesMock.propertyExists("sk")).andReturn(true);
    expect(mEbcPropertiesMock.getString("sk", "")).andReturn("");
	
    expect(mEbcPropertiesMock.propertyExists("privateKey")).andReturn(true);
    expect(mEbcPropertiesMock.getString("privateKey", "")).andReturn("");

    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();

    EnvironmentSelfTester vEnvironmentSelfTester = new EnvironmentSelfTester();
    ReflectionTestUtils.setField(vEnvironmentSelfTester, "ebcProperties", mEbcPropertiesMock);
    vEnvironmentSelfTester.runSelfTest();

    // Verify Mocks and MockEbcControl
    verifyAll();

  }

  @Test
  final public void testRunSelfTest_noProp() throws Exception {
    // --- Set up mock behaviour ---

	  expect(mEbcPropertiesMock.propertyExists("uniqueNo")).andReturn(false);
	  expect(mEbcPropertiesMock.propertyExists("url")).andReturn(false);
	  expect(mEbcPropertiesMock.propertyExists("ak")).andReturn(false);
	  expect(mEbcPropertiesMock.propertyExists("sk")).andReturn(false);
	  expect(mEbcPropertiesMock.propertyExists("privateKey")).andReturn(false);
    // --- Run the test ---

    // Replay Mocks and MockEbcControl
    replayAll();

    EnvironmentSelfTester vEnvironmentSelfTester = new EnvironmentSelfTester();
    ReflectionTestUtils.setField(vEnvironmentSelfTester, "ebcProperties", mEbcPropertiesMock);
    vEnvironmentSelfTester.runSelfTest();

    // Verify Mocks and MockEbcControl
    verifyAll();

  }

}
