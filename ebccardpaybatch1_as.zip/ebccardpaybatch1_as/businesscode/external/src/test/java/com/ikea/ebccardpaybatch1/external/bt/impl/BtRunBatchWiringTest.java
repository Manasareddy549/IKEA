package com.ikea.ebccardpaybatch1.external.bt.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import com.ikea.ebccardpaybatch1.external.BtRunBatch;

@ContextConfiguration(locations="btwiringtest-context.xml")
public class BtRunBatchWiringTest extends AbstractJUnit4SpringContextTests {

	@Autowired
    private BtRunBatch bt;
    
    @Test
    public void testBtRunBatchWiring() {
            Assert.assertNotNull(bt);
    }
}
