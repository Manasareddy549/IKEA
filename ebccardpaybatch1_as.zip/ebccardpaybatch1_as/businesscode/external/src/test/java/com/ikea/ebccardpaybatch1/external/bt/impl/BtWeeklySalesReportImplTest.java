package com.ikea.ebccardpaybatch1.external.bt.impl;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.joda.time.DateTime;
import org.junit.Test;

import com.ikea.ebccardpay1.cardpayment.utils.Dates;
import com.ikea.ebccardpaybatch1.client.bs.BsRunBatch;
import com.ikea.ebccardpaybatch1.client.vo.VoJobParam;

public class BtWeeklySalesReportImplTest {

	@Test
	public void whenCreateBsRunBatchVerifyWeekWithZeroPadding() throws Exception {
		
		DateTime vLastWeek = Dates.parseDate("2010-01-05");
		BtWeeklySalesReportImpl vBt = new BtWeeklySalesReportImpl();
		BsRunBatch vBsRunBatch = vBt.createBsRunBatch(vLastWeek);
		
		List<VoJobParam> vJobList = vBsRunBatch.getJobParamList();
		for (VoJobParam vJobParam : vJobList) {
			if ("week".equals(vJobParam.getName())){
				assertEquals("01", vJobParam.getValue());
			} else {
				assertEquals("2010", vJobParam.getValue());
			}
		}
		
	}
}
