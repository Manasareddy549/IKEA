package com.ikea.ebccardpaybatch1.external.bt.impl;

import java.util.Collection;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.DuplicateJobException;
import org.springframework.batch.core.configuration.JobFactory;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.NoSuchJobException;

public class TestJobRegistry implements JobRegistry {

	@Override
	public Job getJob(String name) throws NoSuchJobException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void register(JobFactory jobFactory) throws DuplicateJobException {
		// TODO Auto-generated method stub

	}

	@Override
	public void unregister(String jobName) {
		// TODO Auto-generated method stub

	}

	@Override
	public Collection<String> getJobNames() {
		// TODO Auto-generated method stub
		return null;
	}

}
