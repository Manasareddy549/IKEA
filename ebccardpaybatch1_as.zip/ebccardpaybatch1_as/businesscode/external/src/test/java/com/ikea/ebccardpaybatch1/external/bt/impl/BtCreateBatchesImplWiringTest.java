package com.ikea.ebccardpaybatch1.external.bt.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import com.ikea.ebccardpaybatch1.external.BtCreateBatches;

@ContextConfiguration(locations="btwiringtest-context.xml")
public class BtCreateBatchesImplWiringTest extends AbstractJUnit4SpringContextTests {

	  @Autowired
      private BtCreateBatches bt;
      
      @Test
      public void testBtCreateBatchesWiring() {
              Assert.assertNotNull(bt);
      }

}
