package com.ikea.ebccardpaybatch1.external.bt.impl;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.exception.IkeaException;

import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpaybatch1.utils.EbccardpayBatchJobType;
import com.ikea.ebccardpaybatch1.china.CustomException;
import com.ikea.ebccardpaybatch1.external.BtChinaBatchJob;
import com.ikea.ebccardpaybatch1.external.VoJobOutput;
import com.ikea.ebccardpaybatch1.external.VoJobParam;
import com.ikea.ebccardpaybatch1.service.BatchExecutor;
import sun.misc.BASE64Encoder;
import sun.security.provider.Sun;

@Service
@Scope("prototype")
public class BtChinaBatchJobImpl extends BtChinaBatchJob{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6383541688668532124L;

	private final static Logger log = LoggerFactory.getLogger(BtChinaBatchJobImpl.class);

	@Autowired
	private BatchExecutor batchExecutor;

	public  BtChinaBatchJobImpl() {
		super();
	}

	public boolean performExecute()  throws IkeaException {
		log.debug("Running BtChinaBatchJob");
		batchExecutor.execute(EbccardpayBatchJobType.valueOf("chinaBatchJob"), createJobParameters(getJobParamList()));
		if(CustomException.getException()!=null)
		{
			if(CustomException.getException().length()>0)
			{
				VoJobOutput mVoJobOutput= new VoJobOutput();
				mVoJobOutput.setStatus("FAILURE");
				mVoJobOutput.setMessage(CustomException.getException());
				setJobOutput(mVoJobOutput);
				CustomException.setException(null);
			}
		}
		else{
			VoJobOutput mVoJobOutput= new VoJobOutput();
			mVoJobOutput.setStatus("SUCCESS");
			mVoJobOutput.setMessage("Executed Without any Exceptions");
			setJobOutput(mVoJobOutput);
		}

		return true;
	}

	public boolean validate() throws IkeaException {
		log.debug("Validating BtChinaBatchJobImpl");
		ValidateInputVo vValidateInputVo = new ValidateInputVo();
		vValidateInputVo.validateBatchjobParameter(this,getJobParamList());
		if(!vValidateInputVo.isValid())
		{
			for(ApplicationError pApplicationError: vValidateInputVo.getApplicationErrorList())
			{
				this.addApplicationError(pApplicationError);
			}
		}
		return vValidateInputVo.isValid();
	}

	private JobParameters createJobParameters(List<VoJobParam> pJobParamList) {
		JobParametersBuilder vJobParametersBuilder = new JobParametersBuilder();
		vJobParametersBuilder.addString("trigger.timestamp", new Date().toString());
		vJobParametersBuilder.addString("batchjobError","0");
		for (Iterator vIterator = pJobParamList.iterator(); vIterator
				.hasNext();) {
			VoJobParam vjobParam = (VoJobParam) vIterator.next();
			vJobParametersBuilder.addString(vjobParam.getName(), vjobParam.getValue());
		}
		return vJobParametersBuilder.toJobParameters();
	}


}
