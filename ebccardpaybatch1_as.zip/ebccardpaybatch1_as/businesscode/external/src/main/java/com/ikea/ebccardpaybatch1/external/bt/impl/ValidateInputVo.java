package com.ikea.ebccardpaybatch1.external.bt.impl;

import java.util.ArrayList;
import java.util.List;

import com.ikea.ebccardpay1.common.ApplicationErrorCodes;
import com.ikea.ebccardpaybatch1.external.VoJobParam;
import com.ikea.ebcframework.error.ApplicationError;
import com.ikea.ebcframework.services.BusinessTask;

public class ValidateInputVo {
	private boolean mValid = true;
	
	private List<ApplicationError> applicationErrorList;
	
	
	
	
	
	public boolean isValid() {
		return mValid;
	}
	

	public void validateBatchjobParameter(BusinessTask pBt,
			List<VoJobParam> pVoList) {
		if (pVoList.size()<0) {
			applicationErrorList= new ArrayList<ApplicationError>();
			applicationErrorList.add(new ApplicationError("EBCCARPAYBATCH1",25999,"Missing JobParameter List as input"));
			mValid = false;
		}
	}

	public List<ApplicationError> getApplicationErrorList() {
		return applicationErrorList;
	}

}
