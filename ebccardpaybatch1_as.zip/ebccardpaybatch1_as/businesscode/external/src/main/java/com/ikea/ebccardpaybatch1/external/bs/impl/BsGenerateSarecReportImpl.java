package com.ikea.ebccardpaybatch1.external.bs.impl;

import com.ikea.ebccardpaybatch1.external.AbstractBsCalculateKpi;
import com.ikea.ebccardpaybatch1.external.AbstractBsGenerateSarecReport;
import com.ikea.ebcframework.services.EbcContext;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;


@Scope("prototype")
@Service("BsGenerateSarecReport")
public class BsGenerateSarecReportImpl extends AbstractBsGenerateSarecReport{
	
	/**
	 * 
	 */
	 @Resource(name="ebcfwk.ebcContext")
	    private EbcContext ebcContext;

	    
	    /**
	    * @see AbstractBsCalculateKpi#validate()
	    */
	    public boolean validate() {
	        // Returns true by default.
	        return true;
	    }
}
