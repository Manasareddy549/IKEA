/*
 * Created on 2006-jun-07
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ikea.ebccardpaybatch1.external.selftester;

import com.ikea.ebccardpay1.cardpayment.utils.EbcEnvironment;
import com.ikea.ebcframework.exception.SelfTestFailedFwkException;
import com.ikea.ebcframework.services.EbcProperties;
import com.ikea.ebcframework.services.SelfTester;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author anms
 *         <p/>
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class EnvironmentSelfTester implements SelfTester {

	private final static Logger mLog =
			LoggerFactory.getLogger(EnvironmentSelfTester.class);
	@Autowired
	EbcProperties ebcProperties;

	/* (non-Javadoc)
	 * @see com.ikea.framework.ebc.SelfTester#runSelfTest()
	 */
	public void runSelfTest() throws SelfTestFailedFwkException {

		
		propertyCheck("uniqueNo", "");
		
		propertyCheck("url", "");
		
		propertyCheck("ak", "");
		
		propertyCheck("sk", "");
		
		propertyCheck("iPay_Exchange_Url", "");
		
		propertyCheck("retryCount", 0);
		
		propertyCheck("retryInterval", 0);
		

	}

	/**
	 * @param pProp
	 * @param pDefault
	 */
	protected void propertyCheck(String pProp, boolean pDefault) {

		// Test environment property
		if(!ebcProperties.propertyExists(pProp)) {
			mLog.info("The property '" + pProp + "' does not exist, will use default value '" + pDefault + "'.");
		} else {
			mLog.info("Property for '" + pProp + "' is set to '" + ebcProperties.getBoolean(pProp, pDefault) + "'.");
		}
	}

	/**
	 * @param pProp
	 * @param pDefault
	 */
	protected void propertyCheck(String pProp, int pDefault) {

		// Test environment property
		if(!ebcProperties.propertyExists(pProp)) {
			mLog.info("The property '" + pProp + "' does not exist, will use default value '" + pDefault + "'.");
		} else {
			mLog.info("Property for '" + pProp + "' is set to '" + ebcProperties.getInt(pProp, pDefault) + "'.");
		}
	}


	protected void propertyCheck(String pProp, String pDefault) {

		// Test environment property
		if(!ebcProperties.propertyExists(pProp)) {
			mLog.info("The property '" + pProp + "' does not exist, will use default value '" + pDefault + "'.");
		} else {
			mLog.info("Property for '" + pProp + "' is set to '" + ebcProperties.getString(pProp, pDefault) + "'.");
		}
	}
}
