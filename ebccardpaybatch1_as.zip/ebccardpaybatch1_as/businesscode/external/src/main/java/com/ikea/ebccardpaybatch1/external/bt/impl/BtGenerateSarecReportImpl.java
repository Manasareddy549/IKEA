package com.ikea.ebccardpaybatch1.external.bt.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import com.ikea.ebcframework.exception.IkeaException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ikea.ebccardpaybatch1.external.BtGenerateSarecReport;
import com.ikea.ebccardpaybatch1.service.GenerateSarecReportJobCreator;
import com.ikea.ebccardpaybatch1.service.JobCreator;

@Service
@Scope("prototype")
public class BtGenerateSarecReportImpl extends BtGenerateSarecReport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6383541688668532124L;

	private final static Logger log = LoggerFactory.getLogger(BtCalculateKpiImpl.class);

	@Autowired
	private ApplicationContext mApplicationContext;

    public  BtGenerateSarecReportImpl() {
        super();
    }
    
    public boolean performExecute()  throws IkeaException {
    	log.debug("Running BtGenerateSarecReport");

		JobCreator vCreator = (JobCreator) mApplicationContext.getBean("generateSarecReportJobCreator", JobCreator.class);
		
		if (vCreator != null){
			log.info("Found the creator for generateSarecReportJob");
			((GenerateSarecReportJobCreator)vCreator).createNewJobs(getOnlyYesterday());
		}
    
        return true;
    }

	public boolean validate() throws IkeaException {
		return true;
	}

    
}
